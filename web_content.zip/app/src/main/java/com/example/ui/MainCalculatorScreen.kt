package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.ui.animation.ParticleOverlay
import com.example.ui.components.*
import com.example.ui.theme.*

@Composable
fun MainCalculatorScreen(
    viewModel: CalculatorViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val historyList by viewModel.historyList.collectAsStateWithLifecycle()
    val isEvolutionBannerVisible by viewModel.evolutionBannerVisible.collectAsStateWithLifecycle()

    var isHistoryOpen by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(GalvanBlack)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // TOP SECTION: Ultimatrix Dial & Alien Info
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Interactive Ultimatrix Dial + Status Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Left: App Name & Series Badge
                    Column {
                        Text(
                            text = "BEN 10",
                            color = if (state.isUltimateMode) UltimateRedBright else OmnitrixGreenBright,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.5.sp
                        )
                        Text(
                            text = "ULTIMATE ALIEN CALCULATOR",
                            color = if (state.isUltimateMode) AlienGold else WhiteMuted,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }

                    // Center: Interactive Ultimatrix Rotating Dial
                    UltimatrixDial(
                        rotationAngle = state.omnitrixRotation,
                        isUltimateMode = state.isUltimateMode,
                        powerPercent = state.powerMeterPercent,
                        pulseTrigger = state.dialPulseTrigger,
                        onDialClick = {
                            viewModel.toggleUltimateMode()
                        }
                    )

                    // Right: Evolution Mode Quick Switch Button
                    Button(
                        onClick = { viewModel.toggleUltimateMode() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (state.isUltimateMode) UltimateRed else GalvanSurfaceLight,
                            contentColor = if (state.isUltimateMode) WhitePure else OmnitrixGreenBright
                        ),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier
                            .height(38.dp)
                            .border(
                                1.5.dp,
                                if (state.isUltimateMode) UltimateRedBright else OmnitrixGreenBright,
                                RoundedCornerShape(12.dp)
                            )
                    ) {
                        Text(
                            text = if (state.isUltimateMode) "ULTIMATE" else "EVOLVE",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.8.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Alien Horizontal DNA Codex Selector
                AlienSelectorBar(
                    selectedAlien = state.selectedAlien,
                    isUltimateMode = state.isUltimateMode,
                    onSelectAlien = { alien ->
                        viewModel.onSelectAlien(alien)
                    }
                )

                Spacer(modifier = Modifier.height(6.dp))

                // The Display Screen HUD
                UltimatrixDisplay(
                    state = state,
                    onHistoryClick = { isHistoryOpen = true },
                    onScientificToggle = { viewModel.toggleScientificPad() },
                    onSoundToggle = { viewModel.toggleSound() },
                    onBackspaceClick = { viewModel.onBackspaceClick() },
                    onClearClick = { viewModel.onClearClick() }
                )
            }

            // KEYPAD SECTION
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Scientific Functions Drawer (Expandable)
                AnimatedVisibility(
                    visible = state.isScientificOpen,
                    enter = expandVertically(animationSpec = tween(220)),
                    exit = shrinkVertically(animationSpec = tween(180))
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            KeypadButton(
                                text = if (state.isRadMode) "RAD" else "DEG",
                                role = ButtonRole.ACTION,
                                isUltimateMode = state.isUltimateMode,
                                onClick = { viewModel.toggleRadMode() },
                                modifier = Modifier.weight(1f),
                                height = 44.dp
                            )
                            KeypadButton(
                                text = "sin",
                                role = ButtonRole.FUNCTION,
                                isUltimateMode = state.isUltimateMode,
                                onClick = { offset -> viewModel.onScientificFunctionClick("sin", offset) },
                                modifier = Modifier.weight(1f),
                                height = 44.dp
                            )
                            KeypadButton(
                                text = "cos",
                                role = ButtonRole.FUNCTION,
                                isUltimateMode = state.isUltimateMode,
                                onClick = { offset -> viewModel.onScientificFunctionClick("cos", offset) },
                                modifier = Modifier.weight(1f),
                                height = 44.dp
                            )
                            KeypadButton(
                                text = "tan",
                                role = ButtonRole.FUNCTION,
                                isUltimateMode = state.isUltimateMode,
                                onClick = { offset -> viewModel.onScientificFunctionClick("tan", offset) },
                                modifier = Modifier.weight(1f),
                                height = 44.dp
                            )
                            KeypadButton(
                                text = "√",
                                role = ButtonRole.FUNCTION,
                                isUltimateMode = state.isUltimateMode,
                                onClick = { offset -> viewModel.onScientificFunctionClick("sqrt", offset) },
                                modifier = Modifier.weight(1f),
                                height = 44.dp
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            KeypadButton(
                                text = "^",
                                role = ButtonRole.FUNCTION,
                                isUltimateMode = state.isUltimateMode,
                                onClick = { offset -> viewModel.onScientificFunctionClick("^", offset) },
                                modifier = Modifier.weight(1f),
                                height = 44.dp
                            )
                            KeypadButton(
                                text = "log",
                                role = ButtonRole.FUNCTION,
                                isUltimateMode = state.isUltimateMode,
                                onClick = { offset -> viewModel.onScientificFunctionClick("log", offset) },
                                modifier = Modifier.weight(1f),
                                height = 44.dp
                            )
                            KeypadButton(
                                text = "ln",
                                role = ButtonRole.FUNCTION,
                                isUltimateMode = state.isUltimateMode,
                                onClick = { offset -> viewModel.onScientificFunctionClick("ln", offset) },
                                modifier = Modifier.weight(1f),
                                height = 44.dp
                            )
                            KeypadButton(
                                text = "π",
                                role = ButtonRole.FUNCTION,
                                isUltimateMode = state.isUltimateMode,
                                onClick = { offset -> viewModel.onScientificFunctionClick("pi", offset) },
                                modifier = Modifier.weight(1f),
                                height = 44.dp
                            )
                            KeypadButton(
                                text = "!",
                                role = ButtonRole.FUNCTION,
                                isUltimateMode = state.isUltimateMode,
                                onClick = { offset -> viewModel.onScientificFunctionClick("!", offset) },
                                modifier = Modifier.weight(1f),
                                height = 44.dp
                            )
                        }
                    }
                }

                // Standard Keypad Rows
                // Row 1: ( , ) , % , ÷
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    KeypadButton(
                        text = "(",
                        role = ButtonRole.OPERATOR,
                        isUltimateMode = state.isUltimateMode,
                        onClick = { offset -> viewModel.onScientificFunctionClick("(", offset) },
                        modifier = Modifier.weight(1f)
                    )
                    KeypadButton(
                        text = ")",
                        role = ButtonRole.OPERATOR,
                        isUltimateMode = state.isUltimateMode,
                        onClick = { offset -> viewModel.onScientificFunctionClick(")", offset) },
                        modifier = Modifier.weight(1f)
                    )
                    KeypadButton(
                        text = "%",
                        role = ButtonRole.OPERATOR,
                        isUltimateMode = state.isUltimateMode,
                        onClick = { offset -> viewModel.onOperatorClick("%", offset) },
                        modifier = Modifier.weight(1f)
                    )
                    KeypadButton(
                        text = "÷",
                        role = ButtonRole.OPERATOR,
                        isUltimateMode = state.isUltimateMode,
                        onClick = { offset -> viewModel.onOperatorClick("÷", offset) },
                        modifier = Modifier.weight(1f)
                    )
                }

                // Row 2: 7, 8, 9, ×
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    KeypadButton(
                        text = "7",
                        role = ButtonRole.NUMBER,
                        isUltimateMode = state.isUltimateMode,
                        onClick = { offset -> viewModel.onNumberClick("7", offset) },
                        modifier = Modifier.weight(1f)
                    )
                    KeypadButton(
                        text = "8",
                        role = ButtonRole.NUMBER,
                        isUltimateMode = state.isUltimateMode,
                        onClick = { offset -> viewModel.onNumberClick("8", offset) },
                        modifier = Modifier.weight(1f)
                    )
                    KeypadButton(
                        text = "9",
                        role = ButtonRole.NUMBER,
                        isUltimateMode = state.isUltimateMode,
                        onClick = { offset -> viewModel.onNumberClick("9", offset) },
                        modifier = Modifier.weight(1f)
                    )
                    KeypadButton(
                        text = "×",
                        role = ButtonRole.OPERATOR,
                        isUltimateMode = state.isUltimateMode,
                        onClick = { offset -> viewModel.onOperatorClick("×", offset) },
                        modifier = Modifier.weight(1f)
                    )
                }

                // Row 3: 4, 5, 6, -
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    KeypadButton(
                        text = "4",
                        role = ButtonRole.NUMBER,
                        isUltimateMode = state.isUltimateMode,
                        onClick = { offset -> viewModel.onNumberClick("4", offset) },
                        modifier = Modifier.weight(1f)
                    )
                    KeypadButton(
                        text = "5",
                        role = ButtonRole.NUMBER,
                        isUltimateMode = state.isUltimateMode,
                        onClick = { offset -> viewModel.onNumberClick("5", offset) },
                        modifier = Modifier.weight(1f)
                    )
                    KeypadButton(
                        text = "6",
                        role = ButtonRole.NUMBER,
                        isUltimateMode = state.isUltimateMode,
                        onClick = { offset -> viewModel.onNumberClick("6", offset) },
                        modifier = Modifier.weight(1f)
                    )
                    KeypadButton(
                        text = "-",
                        role = ButtonRole.OPERATOR,
                        isUltimateMode = state.isUltimateMode,
                        onClick = { offset -> viewModel.onOperatorClick("-", offset) },
                        modifier = Modifier.weight(1f)
                    )
                }

                // Row 4: 1, 2, 3, +
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    KeypadButton(
                        text = "1",
                        role = ButtonRole.NUMBER,
                        isUltimateMode = state.isUltimateMode,
                        onClick = { offset -> viewModel.onNumberClick("1", offset) },
                        modifier = Modifier.weight(1f)
                    )
                    KeypadButton(
                        text = "2",
                        role = ButtonRole.NUMBER,
                        isUltimateMode = state.isUltimateMode,
                        onClick = { offset -> viewModel.onNumberClick("2", offset) },
                        modifier = Modifier.weight(1f)
                    )
                    KeypadButton(
                        text = "3",
                        role = ButtonRole.NUMBER,
                        isUltimateMode = state.isUltimateMode,
                        onClick = { offset -> viewModel.onNumberClick("3", offset) },
                        modifier = Modifier.weight(1f)
                    )
                    KeypadButton(
                        text = "+",
                        role = ButtonRole.OPERATOR,
                        isUltimateMode = state.isUltimateMode,
                        onClick = { offset -> viewModel.onOperatorClick("+", offset) },
                        modifier = Modifier.weight(1f)
                    )
                }

                // Row 5: 0, ., AC, = (HERO TIME!)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    KeypadButton(
                        text = "0",
                        role = ButtonRole.NUMBER,
                        isUltimateMode = state.isUltimateMode,
                        onClick = { offset -> viewModel.onNumberClick("0", offset) },
                        modifier = Modifier.weight(1f)
                    )
                    KeypadButton(
                        text = ".",
                        role = ButtonRole.NUMBER,
                        isUltimateMode = state.isUltimateMode,
                        onClick = { offset -> viewModel.onDecimalClick(offset) },
                        modifier = Modifier.weight(1f)
                    )
                    KeypadButton(
                        text = "C",
                        role = ButtonRole.ACTION,
                        isUltimateMode = state.isUltimateMode,
                        onClick = { viewModel.onClearClick() },
                        modifier = Modifier.weight(1f)
                    )
                    KeypadButton(
                        text = "=",
                        role = ButtonRole.EQUALS,
                        isUltimateMode = state.isUltimateMode,
                        onClick = { offset -> viewModel.onEqualsClick(offset) },
                        modifier = Modifier.weight(1.3f)
                    )
                }
            }
        }

        // Particle Shockwave Overlay for click explosions!
        ParticleOverlay(
            particleManager = viewModel.particleManager,
            modifier = Modifier.fillMaxSize()
        )

        // Ultimate Evolution Banner Popup
        UltimateEvolutionBanner(
            visible = isEvolutionBannerVisible,
            alien = state.selectedAlien,
            isUltimate = state.isUltimateMode,
            modifier = Modifier.align(Alignment.TopCenter)
        )

        // Galvanic Archives Bottom Sheet
        if (isHistoryOpen) {
            HistorySheet(
                historyList = historyList,
                isUltimateMode = state.isUltimateMode,
                onSelectEntry = { recalledResult ->
                    viewModel.recallHistory(recalledResult)
                },
                onClearHistory = {
                    viewModel.clearAllHistory()
                },
                onDismiss = { isHistoryOpen = false }
            )
        }
    }
}
