package com.example.ui.screens.consumer

import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CheckoutScreen(
    cartItems: List<CartItem>,
    onBack: () -> Unit,
    onOrderPlaced: (DeliveryAddress, String) -> Order,
    onViewOrderTracking: (String) -> Unit
) {
    var currentStep by remember { mutableStateOf(1) } // 1: Address, 2: Summary, 3: Payment, 4: Confirmation

    // Address fields
    var fullName by remember { mutableStateOf("Maya Chen") }
    var phone by remember { mutableStateOf("+1 (555) 019-2834") }
    var street by remember { mutableStateOf("424 Pioneer Way, Suite 300") }
    var city by remember { mutableStateOf("New Tech City") }
    var state by remember { mutableStateOf("CA") }
    var postalCode by remember { mutableStateOf("94016") }
    var deliveryInstructions by remember { mutableStateOf("Leave at front reception or call upon arrival.") }

    // Payment fields
    var selectedPaymentMethod by remember { mutableStateOf("Ignis Pay (Instant Match)") }

    var createdOrder by remember { mutableStateOf<Order?>(null) }

    val subtotal = cartItems.sumOf { it.totalPrice }
    val deliveryCharge = 4.50
    val total = subtotal + deliveryCharge + (subtotal * 0.05)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = when (currentStep) {
                            1 -> "Delivery Address"
                            2 -> "Order Summary"
                            3 -> "Secure Payment"
                            else -> "Order Confirmed"
                        },
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                },
                navigationIcon = {
                    if (currentStep in 2..3) {
                        IconButton(onClick = { currentStep-- }) {
                            Icon(imageVector = Icons.Filled.ArrowBack, contentDescription = "Back")
                        }
                    } else if (currentStep == 1) {
                        IconButton(onClick = onBack) {
                            Icon(imageVector = Icons.Filled.Close, contentDescription = "Close")
                        }
                    }
                }
            )
        },
        bottomBar = {
            if (currentStep < 4) {
                Surface(
                    tonalElevation = 8.dp,
                    color = MaterialTheme.colorScheme.surface
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Button(
                            onClick = {
                                if (currentStep < 3) {
                                    currentStep++
                                } else {
                                    val address = DeliveryAddress(
                                        fullName = fullName,
                                        phone = phone,
                                        street = street,
                                        city = city,
                                        state = state,
                                        postalCode = postalCode,
                                        instructions = deliveryInstructions
                                    )
                                    val order = onOrderPlaced(address, selectedPaymentMethod)
                                    createdOrder = order
                                    currentStep = 4
                                }
                            },
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = IgnisOrangePrimary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("checkout_continue_button")
                        ) {
                            Text(
                                text = when (currentStep) {
                                    1 -> "Proceed to Order Summary"
                                    2 -> "Proceed to Payment"
                                    3 -> "Authorize & Place Order ($${"%.2f".format(total)})"
                                    else -> ""
                                },
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Steps indicator
            if (currentStep < 4) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf("1. Address", "2. Summary", "3. Payment").forEachIndexed { index, stepName ->
                        val active = currentStep == index + 1
                        Text(
                            text = stepName,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                                color = if (active) IgnisOrangePrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }
                LinearProgressIndicator(
                    progress = { currentStep / 3f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp)),
                    color = IgnisOrangePrimary
                )
                Spacer(modifier = Modifier.height(16.dp))
            }

            AnimatedContent(
                targetState = currentStep,
                label = "checkout_step"
            ) { step ->
                when (step) {
                    1 -> StepAddress(
                        fullName = fullName,
                        onNameChange = { fullName = it },
                        phone = phone,
                        onPhoneChange = { phone = it },
                        street = street,
                        onStreetChange = { street = it },
                        city = city,
                        onCityChange = { city = it },
                        state = state,
                        onStateChange = { state = it },
                        postalCode = postalCode,
                        onPostalCodeChange = { postalCode = it },
                        deliveryInstructions = deliveryInstructions,
                        onInstructionsChange = { deliveryInstructions = it }
                    )
                    2 -> StepSummary(
                        cartItems = cartItems,
                        subtotal = subtotal,
                        deliveryCharge = deliveryCharge,
                        total = total,
                        address = "$street, $city, $state $postalCode"
                    )
                    3 -> StepPayment(
                        selectedMethod = selectedPaymentMethod,
                        onSelectMethod = { selectedPaymentMethod = it },
                        total = total
                    )
                    4 -> StepConfirmation(
                        order = createdOrder,
                        onTrackOrder = { orderId -> onViewOrderTracking(orderId) }
                    )
                }
            }
        }
    }
}

@Composable
private fun StepAddress(
    fullName: String,
    onNameChange: (String) -> Unit,
    phone: String,
    onPhoneChange: (String) -> Unit,
    street: String,
    onStreetChange: (String) -> Unit,
    city: String,
    onCityChange: (String) -> Unit,
    state: String,
    onStateChange: (String) -> Unit,
    postalCode: String,
    onPostalCodeChange: (String) -> Unit,
    deliveryInstructions: String,
    onInstructionsChange: (String) -> Unit
) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Text(
                text = "Recipient & Drop-off Location",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
            Text(
                text = "Used by our local delivery partner for prompt dispatch.",
                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
            )
        }

        item {
            OutlinedTextField(
                value = fullName,
                onValueChange = onNameChange,
                label = { Text("Full Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )
        }

        item {
            OutlinedTextField(
                value = phone,
                onValueChange = onPhoneChange,
                label = { Text("Contact Phone") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )
        }

        item {
            OutlinedTextField(
                value = street,
                onValueChange = onStreetChange,
                label = { Text("Street Address & Unit") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = city,
                    onValueChange = onCityChange,
                    label = { Text("City") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                )
                OutlinedTextField(
                    value = state,
                    onValueChange = onStateChange,
                    label = { Text("State") },
                    modifier = Modifier.width(80.dp),
                    shape = RoundedCornerShape(12.dp)
                )
                OutlinedTextField(
                    value = postalCode,
                    onValueChange = onPostalCodeChange,
                    label = { Text("Zip") },
                    modifier = Modifier.width(90.dp),
                    shape = RoundedCornerShape(12.dp)
                )
            }
        }

        item {
            OutlinedTextField(
                value = deliveryInstructions,
                onValueChange = onInstructionsChange,
                label = { Text("Delivery Instructions (Optional)") },
                minLines = 2,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )
        }
    }
}

@Composable
private fun StepSummary(
    cartItems: List<CartItem>,
    subtotal: Double,
    deliveryCharge: Double,
    total: Double,
    address: String
) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Text(
                text = "Review Order & Delivery",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        }

        // Drop-off preview card
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.LocationOn,
                        contentDescription = null,
                        tint = IgnisOrangePrimary
                    )
                    Column {
                        Text(
                            text = "Deliver To",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                        Text(
                            text = address,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                        )
                    }
                }
            }
        }

        // Items breakdown
        item {
            Text(
                text = "Items (${cartItems.size})",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )
        }

        items(cartItems) { item ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.product.name,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Text(
                        text = "From ${item.product.sellerName} • Qty: ${item.quantity}",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                }
                Text(
                    text = "$${"%.2f".format(item.totalPrice)}",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                )
            }
        }

        item {
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Subtotal", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("$${"%.2f".format(subtotal)}")
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Local Delivery Fulfillment", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("$${"%.2f".format(deliveryCharge)}")
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Ignis Platform Fee (5%)", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("$${"%.2f".format(subtotal * 0.05)}")
                }
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Total", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    Text(
                        "$${"%.2f".format(total)}",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            color = IgnisOrangePrimary
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun StepPayment(
    selectedMethod: String,
    onSelectMethod: (String) -> Unit,
    total: Double
) {
    val methods = listOf(
        Triple("Ignis Pay (Instant Match)", "Zero-fee escrow payment with automatic partner split", Icons.Filled.Bolt),
        Triple("Credit / Debit Card", "Visa, Mastercard, Amex with 3D Secure", Icons.Filled.CreditCard),
        Triple("Digital Wallet", "Google Pay & Crypto Escrow", Icons.Filled.AccountBalanceWallet),
        Triple("Pay Upon Delivery", "Inspect item before confirming delivery code", Icons.Filled.Payments)
    )

    Column(
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        Text(
            text = "Select Payment Method",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
        )
        Text(
            text = "Total due: $${"%.2f".format(total)}. Funds are secured in escrow until delivery is verified.",
            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
        )

        Spacer(modifier = Modifier.height(4.dp))

        methods.forEach { (name, desc, icon) ->
            val isSelected = name == selectedMethod
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = if (isSelected) IgnisOrangePrimary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface,
                border = BorderStroke(
                    if (isSelected) 2.dp else 1.dp,
                    if (isSelected) IgnisOrangePrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { onSelectMethod(name) }
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = if (isSelected) IgnisOrangePrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(26.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = name,
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) IgnisOrangePrimary else MaterialTheme.colorScheme.onSurface
                            )
                        )
                        Text(
                            text = desc,
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }
                    RadioButton(
                        selected = isSelected,
                        onClick = { onSelectMethod(name) },
                        colors = RadioButtonDefaults.colors(selectedColor = IgnisOrangePrimary)
                    )
                }
            }
        }
    }
}

@Composable
private fun StepConfirmation(
    order: Order?,
    onTrackOrder: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(76.dp)
                .clip(CircleShape)
                .background(Color(0xFFDCFCE7)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.Check,
                contentDescription = null,
                tint = Color(0xFF166534),
                modifier = Modifier.size(44.dp)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "Order Placed Successfully!",
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "Order ID: ${order?.orderNumber ?: "IGN-84920"}",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = IgnisOrangePrimary
            )
        )

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = "Sent to ${order?.sellerName ?: "Seller"}. Ignis is preparing to match a nearby delivery partner for fulfillment.",
            style = MaterialTheme.typography.bodyMedium.copy(
                color = MaterialTheme.colorScheme.onSurfaceVariant
            ),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            modifier = Modifier.padding(horizontal = 24.dp)
        )

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = { onTrackOrder(order?.id ?: "ord_101") },
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = IgnisOrangePrimary),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("confirmation_track_button")
        ) {
            Icon(Icons.Filled.DirectionsRun, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Track Live Order Status", fontWeight = FontWeight.Bold)
        }
    }
}
