package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.media.MediaPlayer
import android.net.Uri
import android.os.ParcelFileDescriptor
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.example.core.ByteSizeFormatter
import com.example.data.model.FileKind
import com.example.data.model.FileNode
import com.example.data.storage.DeviceAndSafStorageAdapter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FilePreviewScreen(
    node: FileNode,
    storageAdapter: DeviceAndSafStorageAdapter,
    onOpenAiImageEditor: (FileNode) -> Unit,
    onOpenAiVideoEditor: (FileNode) -> Unit,
    onExtractZip: (FileNode) -> Unit,
    onShare: (FileNode) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(node.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                        Text(
                            "${node.kind.displayLabel} • ${ByteSizeFormatter.format(node.sizeBytes)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("preview_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (node.kind == FileKind.IMAGE) {
                        FilledTonalButton(
                            onClick = { onOpenAiImageEditor(node) },
                            modifier = Modifier
                                .padding(end = 6.dp)
                                .testTag("open_ai_image_editor_button")
                        ) {
                            Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("AI Edit")
                        }
                    }
                    if (node.kind == FileKind.VIDEO) {
                        FilledTonalButton(
                            onClick = { onOpenAiVideoEditor(node) },
                            modifier = Modifier
                                .padding(end = 6.dp)
                                .testTag("open_ai_video_editor_button")
                        ) {
                            Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("AI Studio")
                        }
                    }
                    IconButton(onClick = { onShare(node) }) {
                        Icon(Icons.Filled.Share, contentDescription = "Share")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (node.kind) {
                FileKind.IMAGE -> ImagePreviewBody(node)
                FileKind.VIDEO -> VideoPreviewBody(node)
                FileKind.AUDIO -> AudioPreviewBody(node, storageAdapter)
                FileKind.PDF -> PdfPreviewBody(node, storageAdapter)
                FileKind.TEXT -> TextPreviewBody(node, storageAdapter)
                FileKind.ZIP -> ZipPreviewBody(node, onExtractZip)
                FileKind.EXE, FileKind.MSI -> WindowsExecutableWarningBody(node)
                else -> GenericPreviewBody(node, onShare)
            }
        }
    }
}

@Composable
private fun ImagePreviewBody(node: FileNode) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = node.contentUriString,
            contentDescription = node.name,
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
private fun VideoPreviewBody(node: FileNode) {
    val context = LocalContext.current
    val exoPlayer = remember(node.path) {
        ExoPlayer.Builder(context).build().apply {
            val uri = node.contentUriString?.let { Uri.parse(it) }
            if (uri != null) {
                setMediaItem(MediaItem.fromUri(uri))
                prepare()
                playWhenReady = true
            }
        }
    }

    DisposableEffect(exoPlayer) {
        onDispose { exoPlayer.release() }
    }

    AndroidView(
        factory = { ctx ->
            PlayerView(ctx).apply {
                player = exoPlayer
            }
        },
        modifier = Modifier.fillMaxSize()
    )
}

@Composable
private fun AudioPreviewBody(
    node: FileNode,
    storageAdapter: DeviceAndSafStorageAdapter
) {
    val context = LocalContext.current
    var isPlaying by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var durationMs by remember { mutableStateOf(0) }
    val player = remember { MediaPlayer() }

    LaunchedEffect(node.path) {
        withContext(Dispatchers.IO) {
            runCatching {
                if (node.path.startsWith("file://")) {
                    player.setDataSource(node.path.removePrefix("file://"))
                } else {
                    val temp = File(context.cacheDir, "audio_preview_${node.name}")
                    temp.writeBytes(storageAdapter.read(node.path))
                    player.setDataSource(temp.absolutePath)
                }
                player.prepare()
                durationMs = player.duration
            }
        }
    }

    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            if (durationMs > 0 && player.isPlaying) {
                progress = (player.currentPosition.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
            } else if (!player.isPlaying) {
                isPlaying = false
            }
            delay(250L)
        }
    }

    DisposableEffect(player) {
        onDispose { runCatching { player.release() } }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(
            color = MaterialTheme.colorScheme.primaryContainer,
            shape = RoundedCornerShape(36.dp),
            modifier = Modifier.size(132.dp)
        ) {
            Icon(
                Icons.Filled.AudioFile,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(32.dp)
            )
        }
        Spacer(Modifier.height(22.dp))
        Text(node.name, style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(16.dp))
        Slider(
            value = progress,
            onValueChange = {
                progress = it
                if (durationMs > 0) player.seekTo((it * durationMs).toInt())
            },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = {
                if (player.isPlaying) {
                    player.pause()
                    isPlaying = false
                } else {
                    player.start()
                    isPlaying = true
                }
            },
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier.height(52.dp)
        ) {
            Icon(
                if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                contentDescription = if (isPlaying) "Pause" else "Play"
            )
            Spacer(Modifier.width(8.dp))
            Text(if (isPlaying) "Pause" else "Play Audio")
        }
    }
}

@Composable
private fun PdfPreviewBody(
    node: FileNode,
    storageAdapter: DeviceAndSafStorageAdapter
) {
    val context = LocalContext.current
    var pages by remember { mutableStateOf<List<Bitmap>?>(null) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(node.path) {
        withContext(Dispatchers.IO) {
            try {
                val pdfFile = if (node.path.startsWith("file://")) {
                    File(node.path.removePrefix("file://"))
                } else {
                    File(context.cacheDir, "preview_${node.name}").apply {
                        writeBytes(storageAdapter.read(node.path))
                    }
                }
                val pfd = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY)
                val renderer = PdfRenderer(pfd)
                val renderedList = mutableListOf<Bitmap>()
                val count = renderer.pageCount.coerceAtMost(20)
                for (i in 0 until count) {
                    renderer.openPage(i).use { page ->
                        val bmp = Bitmap.createBitmap(
                            (page.width * 1.5f).toInt().coerceAtLeast(1),
                            (page.height * 1.5f).toInt().coerceAtLeast(1),
                            Bitmap.Config.ARGB_8888
                        )
                        bmp.eraseColor(android.graphics.Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        renderedList.add(bmp)
                    }
                }
                renderer.close()
                pfd.close()
                pages = renderedList
            } catch (e: Exception) {
                errorMsg = e.localizedMessage ?: "Failed to render PDF document."
            }
        }
    }

    when {
        errorMsg != null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(errorMsg!!, color = MaterialTheme.colorScheme.error)
        }
        pages == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        else -> LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            itemsIndexed(pages!!) { idx, bmp ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column {
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = "Page ${idx + 1}",
                            contentScale = ContentScale.FillWidth,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(
                            "Page ${idx + 1}",
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TextPreviewBody(
    node: FileNode,
    storageAdapter: DeviceAndSafStorageAdapter
) {
    var textContent by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(node.path) {
        textContent = withContext(Dispatchers.IO) {
            val bytes = storageAdapter.read(node.path)
            if (bytes.size > 512_000) {
                bytes.copyOf(512_000).decodeToString() + "\n\n... [Truncated at 512 KB]"
            } else {
                bytes.decodeToString()
            }
        }
    }

    if (textContent == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
    } else {
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Text(
                text = textContent!!,
                fontFamily = FontFamily.Monospace,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            )
        }
    }
}

@Composable
private fun ZipPreviewBody(
    node: FileNode,
    onExtractZip: (FileNode) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(node.name, style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text(
            "ZIP Archive • ${ByteSizeFormatter.format(node.sizeBytes)}",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = { onExtractZip(node) },
            modifier = Modifier.testTag("preview_extract_zip_button")
        ) {
            Icon(Icons.Filled.FolderOpen, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Extract Archive Here")
        }
    }
}

@Composable
private fun WindowsExecutableWarningBody(node: FileNode) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(
            color = MaterialTheme.colorScheme.error.copy(alpha = 0.14f),
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier.size(84.dp)
        ) {
            Icon(
                Icons.Filled.Warning,
                contentDescription = "Incompatible format",
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(22.dp)
            )
        }
        Spacer(Modifier.height(18.dp))
        Text(
            "Cannot run on Android",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "\"${node.name}\" is a Windows executable/installer (${node.kind.displayLabel}${node.magicSignature?.let { " • $it" } ?: ""}). Windows PE binaries cannot be executed natively on Android devices.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun GenericPreviewBody(
    node: FileNode,
    onShare: (FileNode) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(node.name, style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text(
            "${node.kind.displayLabel} (${node.mimeType}) • ${ByteSizeFormatter.format(node.sizeBytes)}",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(20.dp))
        Button(onClick = { onShare(node) }) {
            Icon(Icons.Filled.Share, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Open / Share with External App")
        }
    }
}
