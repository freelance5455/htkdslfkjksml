package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.AppNotification
import com.example.model.ChatMessage
import com.example.model.Conversation
import com.example.model.JobListing
import com.example.model.PaymentTransaction
import com.example.model.UserProfile
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.JobCard
import com.example.ui.components.StatusPill
import com.example.ui.components.formatInr

@Composable
fun MessagesScreen(
  profile: UserProfile,
  conversations: List<Conversation>,
  activeConversationId: String?,
  messages: List<ChatMessage>,
  onOpenConversation: (String?) -> Unit,
  onSendMessage: (Conversation, String) -> Unit
) {
  val activeConv = remember(conversations, activeConversationId) {
    conversations.firstOrNull { it.id == activeConversationId }
  }

  if (activeConv != null) {
    BackHandler { onOpenConversation(null) }
    var draft by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize()) {
      Surface(color = MaterialTheme.colorScheme.surfaceVariant, tonalElevation = 1.dp) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          IconButton(onClick = { onOpenConversation(null) }) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to conversations")
          }
          Column(modifier = Modifier.weight(1f)) {
            val peer = if (profile.userId == activeConv.seekerId) activeConv.employerName else activeConv.seekerName
            Text(peer, style = MaterialTheme.typography.titleMedium)
            Text(activeConv.jobTitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
          }
        }
      }

      LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.weight(1f)
      ) {
        if (messages.isEmpty()) {
          item {
            EmptyStateCard(
              icon = Icons.Filled.Chat,
              title = "Start the conversation",
              subtitle = "Discuss role details, timings, or interview slots directly."
            )
          }
        } else {
          items(messages, key = { it.id }) { msg ->
            val isMine = msg.senderId == profile.userId
            Box(
              modifier = Modifier.fillMaxWidth(),
              contentAlignment = if (isMine) Alignment.CenterEnd else Alignment.CenterStart
            ) {
              Surface(
                color = if (isMine) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.padding(horizontal = 4.dp)
              ) {
                Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                  Text(
                    text = msg.text,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (isMine) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                  )
                  if (msg.attachmentLabel.isNotBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                      text = "Attachment: ${msg.attachmentLabel}",
                      style = MaterialTheme.typography.labelSmall,
                      color = if (isMine) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.primary
                    )
                  }
                }
              }
            }
          }
        }
      }

      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedTextField(
          value = draft,
          onValueChange = { draft = it },
          placeholder = { Text("Type message...") },
          singleLine = true,
          shape = RoundedCornerShape(24.dp),
          modifier = Modifier.weight(1f).testTag("chat_message_input")
        )
        Spacer(modifier = Modifier.width(8.dp))
        IconButton(
          onClick = {
            if (draft.isNotBlank()) {
              onSendMessage(activeConv, draft)
              draft = ""
            }
          },
          modifier = Modifier.testTag("chat_send_button")
        ) {
          Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send message", tint = MaterialTheme.colorScheme.primary)
        }
      }
    }
  } else {
    LazyColumn(
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
      modifier = Modifier.fillMaxSize()
    ) {
      item {
        Text("Messages", style = MaterialTheme.typography.headlineSmall)
      }
      if (conversations.isEmpty()) {
        item {
          EmptyStateCard(
            icon = Icons.Filled.Chat,
            title = "No messages yet",
            subtitle = "Tap Message on any job listing or candidate application to start chatting."
          )
        }
      } else {
        items(conversations, key = { it.id }) { conv ->
          val peerName = if (profile.userId == conv.seekerId) conv.employerName else conv.seekerName
          Card(
            onClick = { onOpenConversation(conv.id) },
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(peerName, style = MaterialTheme.typography.titleMedium)
                Text(conv.jobTitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
              }
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = conv.lastMessage,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2
              )
            }
          }
        }
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileAndSettingsScreen(
  profile: UserProfile,
  savedJobs: List<JobListing>,
  transactions: List<PaymentTransaction>,
  isAdminUser: Boolean,
  onEditProfile: () -> Unit,
  onSwitchRole: (String) -> Unit,
  onOpenAdminCenter: () -> Unit,
  onOpenWebPortal: () -> Unit,
  onSelectSavedJob: (JobListing) -> Unit,
  onToggleSave: (String) -> Unit,
  onSignOut: () -> Unit
) {
  LazyColumn(
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
    modifier = Modifier.fillMaxSize()
  ) {
    item {
      Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(profile.displayName, style = MaterialTheme.typography.titleLarge)
                if (profile.companyVerified) {
                  Spacer(modifier = Modifier.width(6.dp))
                  Icon(Icons.Filled.Verified, contentDescription = "Verified", tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(18.dp))
                }
              }
              Text(profile.email, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(
                text = "${profile.city}, ${profile.state} · Age ${profile.age}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary
              )
            }
            IconButton(onClick = onEditProfile, modifier = Modifier.testTag("edit_profile_button")) {
              Icon(Icons.Filled.Edit, contentDescription = "Edit Profile")
            }
          }

          if (profile.skills.isNotEmpty()) {
            Spacer(modifier = Modifier.height(10.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
              profile.skills.forEach { sk ->
                StatusPill(
                  text = sk,
                  containerColor = MaterialTheme.colorScheme.primaryContainer,
                  contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(14.dp))
          val nextRole = if (profile.role == "SEEKER") "EMPLOYER" else "SEEKER"
          OutlinedButton(
            onClick = { onSwitchRole(nextRole) },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().testTag("switch_role_button")
          ) {
            Icon(Icons.Filled.SwapHoriz, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Switch Mode to ${if (nextRole == "EMPLOYER") "Employer / Hirer" else "Job Seeker"}")
          }

          Spacer(modifier = Modifier.height(8.dp))
          OutlinedButton(
            onClick = onOpenWebPortal,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().testTag("open_web_portal_button")
          ) {
            Icon(Icons.Filled.Language, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Open JOBY Web Portal (index.html)")
          }

          if (isAdminUser) {
            Spacer(modifier = Modifier.height(8.dp))
            Button(
              onClick = onOpenAdminCenter,
              shape = RoundedCornerShape(12.dp),
              colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
              modifier = Modifier.fillMaxWidth().testTag("open_admin_center_button")
            ) {
              Icon(Icons.Filled.AdminPanelSettings, contentDescription = null)
              Spacer(modifier = Modifier.width(8.dp))
              Text("Open Admin Control Center")
            }
          }
        }
      }
    }

    if (profile.role == "SEEKER") {
      item {
        Text("Saved Bookmarks (${savedJobs.size})", style = MaterialTheme.typography.titleMedium)
      }
      if (savedJobs.isEmpty()) {
        item {
          EmptyStateCard(
            title = "No saved jobs",
            subtitle = "Tap the bookmark icon on any job to save it here."
          )
        }
      } else {
        items(savedJobs, key = { "saved_${it.id}" }) { job ->
          JobCard(
            job = job,
            isSaved = true,
            userAge = profile.age,
            onToggleSave = { onToggleSave(job.id) },
            onClick = { onSelectSavedJob(job) }
          )
        }
      }
    }

    item {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Filled.ReceiptLong, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.width(8.dp))
        Text("Invoices & Transactions (${transactions.size})", style = MaterialTheme.typography.titleMedium)
      }
    }
    if (transactions.isEmpty()) {
      item {
        EmptyStateCard(
          icon = Icons.Filled.ReceiptLong,
          title = "No transactions yet",
          subtitle = "Subscription upgrades and Side Quest payouts generate verified invoices here."
        )
      }
    } else {
      items(transactions, key = { it.id }) { txn ->
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(txn.title, style = MaterialTheme.typography.titleSmall)
              Text("${txn.invoiceNumber} · ${txn.paymentMethod}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(
              text = formatInr(txn.amountInr),
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.tertiary
            )
          }
        }
      }
    }

    item {
      OutlinedButton(
        onClick = onSignOut,
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("sign_out_button")
      ) {
        Icon(Icons.Filled.Logout, contentDescription = null)
        Spacer(modifier = Modifier.width(8.dp))
        Text("Sign Out")
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationsSheet(
  notifications: List<AppNotification>,
  onMarkRead: (String) -> Unit,
  onDismiss: () -> Unit
) {
  ModalBottomSheet(onDismissRequest = onDismiss) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp, vertical = 10.dp)
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Filled.Notifications, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.width(8.dp))
        Text("Notifications", style = MaterialTheme.typography.titleLarge)
      }
      Spacer(modifier = Modifier.height(12.dp))
      if (notifications.isEmpty()) {
        EmptyStateCard(
          icon = Icons.Filled.Notifications,
          title = "All caught up",
          subtitle = "Application updates, interview invites, and Side Quest payouts appear here."
        )
      } else {
        LazyColumn(
          verticalArrangement = Arrangement.spacedBy(8.dp),
          modifier = Modifier.height(340.dp)
        ) {
          items(notifications, key = { it.id }) { item ->
            Card(
              shape = RoundedCornerShape(14.dp),
              colors = CardDefaults.cardColors(
                containerColor = if (item.isRead) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
              ),
              modifier = Modifier
                .fillMaxWidth()
                .clickable { if (!item.isRead) onMarkRead(item.id) }
            ) {
              Column(modifier = Modifier.padding(12.dp)) {
                Text(item.title, style = MaterialTheme.typography.titleSmall)
                Spacer(modifier = Modifier.height(2.dp))
                Text(item.body, style = MaterialTheme.typography.bodySmall)
              }
            }
          }
        }
      }
      Spacer(modifier = Modifier.height(16.dp))
    }
  }
}
