package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.ai.AiWriteTone
import com.example.data.VelvetSettings
import com.example.keyboard.BuiltInThemeLibrary
import com.example.keyboard.ui.VelvetKeyboardView
import com.example.ui.AiPolishUiState
import com.example.ui.ImeStatus
import com.example.ui.VelvetMainViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StudioPlaygroundScreen(
    viewModel: VelvetMainViewModel,
    settings: VelvetSettings,
    imeStatus: ImeStatus,
    hasMicPermission: Boolean,
    playgroundText: String,
    aiPolishState: AiPolishUiState,
    onRequestMicPermission: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentView = LocalView.current
    val isTtsSpeaking by viewModel.isTtsSpeaking.collectAsStateWithLifecycle()
    val isTtsSynthesizing by viewModel.isTtsSynthesizing.collectAsStateWithLifecycle()
    val activeThemeName = (settings.customThemes + BuiltInThemeLibrary)
        .firstOrNull { it.id == settings.activeThemeId }?.name ?: "Alive Leaf"

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Minimalist Hero Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(top = 10.dp)
                .heightIn(min = 128.dp)
                .clip(RoundedCornerShape(24.dp))
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_hero_banner_1795026055241),
                contentDescription = "VelvetKey studio banner",
                contentScale = ContentScale.Crop,
                modifier = Modifier.matchParentSize()
            )
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color(0x550B0E17), Color(0xDD0B0E17))
                        )
                    )
            )
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    StatusPill(
                        text = when {
                            imeStatus.isSelected -> "Active"
                            imeStatus.isEnabled -> "Enabled"
                            else -> "Setup Needed"
                        },
                        isPositive = imeStatus.isSelected || imeStatus.isEnabled
                    )
                    StatusPill(text = activeThemeName, isPositive = true)
                    StatusPill(text = settings.activeLanguage.shortCode, isPositive = true)
                }
                Text(
                    text = "VelvetKey",
                    style = MaterialTheme.typography.headlineSmall,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Minimalist, alive, Velvet AI voice & grammar, clipboard & media themes",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFFCBD5E1)
                )
            }
        }

        // System Keyboard Activation Strip
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Keyboard,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = stringResource(R.string.setup_title),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilledTonalButton(
                        onClick = {
                            context.startActivity(
                                Intent(Settings.ACTION_INPUT_METHOD_SETTINGS).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                            )
                        },
                        contentPadding = PaddingValues(horizontal = 10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .testTag("enable_keyboard_button")
                    ) {
                        if (imeStatus.isEnabled) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                        }
                        Text(
                            text = if (imeStatus.isEnabled) "Enabled" else stringResource(R.string.setup_enable_btn),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Button(
                        onClick = {
                            val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
                            imm?.showInputMethodPicker()
                        },
                        contentPadding = PaddingValues(horizontal = 10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .testTag("select_keyboard_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SwapHoriz,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (imeStatus.isSelected) "Active" else "Select IME",
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                if (!hasMicPermission) {
                    OutlinedButton(
                        onClick = onRequestMicPermission,
                        contentPadding = PaddingValues(horizontal = 12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                            .testTag("grant_mic_permission_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Allow Mic for Velvet AI Voice",
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        // Interactive Playground Editor
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = stringResource(R.string.playground_title),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Row {
                        IconButton(
                            onClick = { viewModel.speakPlaygroundText() },
                            modifier = Modifier.testTag("playground_tts_button")
                        ) {
                            when {
                                isTtsSynthesizing -> CircularProgressIndicator(
                                    strokeWidth = 2.dp,
                                    modifier = Modifier.size(18.dp)
                                )
                                isTtsSpeaking -> Icon(
                                    imageVector = Icons.Default.Stop,
                                    contentDescription = "Stop reading aloud",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                else -> Icon(
                                    imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                    contentDescription = "Read aloud with AI voice"
                                )
                            }
                        }
                        IconButton(
                            onClick = { viewModel.copyPlaygroundToClipboard() },
                            modifier = Modifier.testTag("playground_copy_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy to clipboard"
                            )
                        }
                        IconButton(
                            onClick = { viewModel.clearPlaygroundText() },
                            modifier = Modifier.testTag("playground_clear_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteSweep,
                                contentDescription = "Clear text"
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = playgroundText,
                    onValueChange = { viewModel.updatePlaygroundText(it) },
                    placeholder = { Text(stringResource(R.string.playground_hint)) },
                    minLines = 2,
                    maxLines = 4,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("playground_text_field")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = { viewModel.fixPlaygroundGrammar() },
                        enabled = aiPolishState !is AiPolishUiState.Loading,
                        contentPadding = PaddingValues(horizontal = 10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .testTag("playground_grammar_button")
                    ) {
                        if (aiPolishState is AiPolishUiState.Loading) {
                            CircularProgressIndicator(
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.dp,
                                modifier = Modifier.size(16.dp)
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(5.dp))
                        Text("Fix Grammar", maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }

                    FilledTonalButton(
                        onClick = { viewModel.polishPlaygroundTextWithAi(AiWriteTone.NATURAL) },
                        enabled = aiPolishState !is AiPolishUiState.Loading,
                        contentPadding = PaddingValues(horizontal = 10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .testTag("playground_ai_polish_button")
                    ) {
                        Text("Make Better", maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }

                    FilledTonalIconButton(
                        onClick = {
                            viewModel.playgroundController.toggleInlineVoice(settings, currentView)
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("playground_ai_voice_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Inline Velvet AI voice",
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                // Velvet AI Auto-Writer (automatically creates text from a short idea)
                var aiDraftPrompt by remember { mutableStateOf("") }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = aiDraftPrompt,
                        onValueChange = { aiDraftPrompt = it },
                        placeholder = {
                            Text(
                                text = "Ask Velvet AI to write...",
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("playground_ai_write_input")
                    )
                    Button(
                        onClick = {
                            viewModel.autoWriteInPlayground(aiDraftPrompt, AiWriteTone.NATURAL)
                            aiDraftPrompt = ""
                        },
                        enabled = aiPolishState !is AiPolishUiState.Loading,
                        contentPadding = PaddingValues(horizontal = 14.dp),
                        modifier = Modifier
                            .heightIn(min = 48.dp)
                            .testTag("playground_ai_write_button")
                    ) {
                        Text("Write", maxLines = 1, softWrap = false)
                    }
                }

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf(
                        "Running 10 mins late" to "Tell a friend I'm running 10 minutes late casually",
                        "Polite decline" to "Politely decline dinner tonight and suggest this weekend",
                        "Pro follow-up" to "Write a crisp, friendly follow-up message"
                    ).forEach { (chipLabel, promptText) ->
                        AssistChip(
                            onClick = { viewModel.autoWriteInPlayground(promptText, AiWriteTone.NATURAL) },
                            label = { Text(chipLabel) }
                        )
                    }
                }

                AnimatedVisibility(visible = aiPolishState is AiPolishUiState.Success || aiPolishState is AiPolishUiState.Error) {
                    val isError = aiPolishState is AiPolishUiState.Error
                    val msg = when (aiPolishState) {
                        is AiPolishUiState.Success -> aiPolishState.message
                        is AiPolishUiState.Error -> aiPolishState.message
                        else -> ""
                    }
                    Surface(
                        color = if (isError) MaterialTheme.colorScheme.errorContainer
                        else MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = msg,
                            color = if (isError) MaterialTheme.colorScheme.onErrorContainer
                            else MaterialTheme.colorScheme.onPrimaryContainer,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }

        // Embedded Live Gboard-Style VelvetKey Keyboard
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp)
                .clip(RoundedCornerShape(20.dp))
                .border(
                    1.dp,
                    MaterialTheme.colorScheme.outline.copy(alpha = 0.28f),
                    RoundedCornerShape(20.dp)
                ),
            tonalElevation = 2.dp
        ) {
            VelvetKeyboardView(
                controller = viewModel.playgroundController,
                settings = settings,
                showImeSwitcher = false,
                showSettingsShortcut = true,
                applyNavigationBarsPadding = false,
                actionLabel = "Done"
            )
        }

        Spacer(modifier = Modifier.height(6.dp))
    }
}

@Composable
private fun StatusPill(text: String, isPositive: Boolean) {
    Box(
        modifier = Modifier
            .clip(CircleShape)
            .background(
                if (isPositive) Color(0xFF10B981).copy(alpha = 0.25f)
                else Color(0xFFF43F5E).copy(alpha = 0.28f)
            )
            .border(
                1.dp,
                if (isPositive) Color(0xFF34D399).copy(alpha = 0.6f)
                else Color(0xFFFB7185).copy(alpha = 0.6f),
                CircleShape
            )
            .padding(horizontal = 10.dp, vertical = 3.dp)
    ) {
        Text(
            text = text,
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
