package com.example.ui.camera

import android.content.Context
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Colorize
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.model.DetectionRegion
import com.example.ui.viewmodel.CameraViewModel
import java.util.concurrent.Executors

@Composable
fun CameraPreviewView(
    viewModel: CameraViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val lensFacing by viewModel.lensFacing.collectAsState()
    val detectionRegion by viewModel.detectionRegion.collectAsState()
    val detectionState by viewModel.detectionState.collectAsState()
    val isAutoCaptureActive by viewModel.isAutoCaptureActive.collectAsState()
    val isShutterFlashing by viewModel.isShutterFlashing.collectAsState()
    val isEyeDropperActive by viewModel.isEyeDropperActive.collectAsState()

    var previewView by remember { mutableStateOf<PreviewView?>(null) }
    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }

    DisposableEffect(Unit) {
        onDispose {
            cameraExecutor.shutdown()
        }
    }

    LaunchedEffect(lensFacing) {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder().build().also {
                it.surfaceProvider = previewView?.surfaceProvider
            }

            val imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()
            viewModel.imageCapture = imageCapture

            val imageAnalysis = ImageAnalysis.Builder()
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .setTargetResolution(Size(640, 480))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()

            imageAnalysis.setAnalyzer(cameraExecutor) { imageProxy ->
                try {
                    viewModel.processImageFrame(imageProxy)
                } finally {
                    imageProxy.close()
                }
            }

            val cameraSelector = CameraSelector.Builder()
                .requireLensFacing(lensFacing)
                .build()

            try {
                cameraProvider.unbindAll()
                val camera = cameraProvider.bindToLifecycle(
                    lifecycleOwner,
                    cameraSelector,
                    preview,
                    imageCapture,
                    imageAnalysis
                )
                viewModel.cameraControl = camera.cameraControl
                viewModel.cameraInfo = camera.cameraInfo
            } catch (exc: Exception) {
                exc.printStackTrace()
            }
        }, ContextCompat.getMainExecutor(context))
    }

    // Infinite breathing glow for active auto-capture or triggered states
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    val activeColor = detectionState.activeTrigger?.color ?: Color(0xFF00E5FF)
    val animatedBorderColor by animateColorAsState(
        targetValue = if (detectionState.isTriggered) activeColor else Color.White.copy(alpha = 0.35f),
        label = "borderColor"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("camera_preview_container")
            .pointerInput(isEyeDropperActive) {
                detectTapGestures {
                    if (isEyeDropperActive) {
                        viewModel.sampleCurrentColorAsTrigger()
                    }
                }
            }
    ) {
        // CameraX Live Preview Surface
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                PreviewView(ctx).apply {
                    scaleType = PreviewView.ScaleType.FILL_CENTER
                    implementationMode = PreviewView.ImplementationMode.PERFORMANCE
                    previewView = this
                }
            }
        )

        // Visual Reticle / Target Detection Overlay
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            if (detectionRegion == DetectionRegion.CENTER_RETICLE) {
                val boxWidth = width * 0.56f
                val boxHeight = height * 0.38f
                val left = (width - boxWidth) / 2f
                val top = (height - boxHeight) / 2f
                val cornerLength = 36.dp.toPx()
                val strokeWidth = if (detectionState.isTriggered) 5.dp.toPx() else 2.5.dp.toPx()

                val drawColor = if (detectionState.isTriggered) {
                    animatedBorderColor.copy(alpha = pulseAlpha)
                } else {
                    Color.White.copy(alpha = 0.45f)
                }

                // Draw central reticle brackets (corners)
                // Top-Left
                drawLine(drawColor, Offset(left, top), Offset(left + cornerLength, top), strokeWidth)
                drawLine(drawColor, Offset(left, top), Offset(left, top + cornerLength), strokeWidth)

                // Top-Right
                drawLine(drawColor, Offset(left + boxWidth, top), Offset(left + boxWidth - cornerLength, top), strokeWidth)
                drawLine(drawColor, Offset(left + boxWidth, top), Offset(left + boxWidth, top + cornerLength), strokeWidth)

                // Bottom-Left
                drawLine(drawColor, Offset(left, top + boxHeight), Offset(left + cornerLength, top + boxHeight), strokeWidth)
                drawLine(drawColor, Offset(left, top + boxHeight), Offset(left, top + boxHeight - cornerLength), strokeWidth)

                // Bottom-Right
                drawLine(drawColor, Offset(left + boxWidth, top + boxHeight), Offset(left + boxWidth - cornerLength, top + boxHeight), strokeWidth)
                drawLine(drawColor, Offset(left + boxWidth, top + boxHeight), Offset(left + boxWidth, top + boxHeight - cornerLength), strokeWidth)

                // Center crosshair
                val centerX = width / 2f
                val centerY = height / 2f
                val crossSize = 10.dp.toPx()
                drawLine(Color.White.copy(alpha = 0.5f), Offset(centerX - crossSize, centerY), Offset(centerX + crossSize, centerY), 1.5.dp.toPx())
                drawLine(Color.White.copy(alpha = 0.5f), Offset(centerX, centerY - crossSize), Offset(centerX, centerY + crossSize), 1.5.dp.toPx())

                // If triggered, draw a gentle tinted glow fill
                if (detectionState.isTriggered) {
                    drawRoundRect(
                        color = animatedBorderColor.copy(alpha = 0.12f),
                        topLeft = Offset(left, top),
                        size = androidx.compose.ui.geometry.Size(boxWidth, boxHeight),
                        cornerRadius = CornerRadius(16.dp.toPx(), 16.dp.toPx())
                    )
                }
            } else {
                // Full Frame Detection Mode - Border along whole viewport
                val strokeWidth = if (detectionState.isTriggered) 6.dp.toPx() else 2.dp.toPx()
                val drawColor = if (detectionState.isTriggered) {
                    animatedBorderColor.copy(alpha = pulseAlpha)
                } else {
                    Color.White.copy(alpha = 0.25f)
                }
                drawRect(
                    color = drawColor,
                    topLeft = Offset(8.dp.toPx(), 8.dp.toPx()),
                    size = androidx.compose.ui.geometry.Size(width - 16.dp.toPx(), height - 16.dp.toPx()),
                    style = Stroke(
                        width = strokeWidth,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(30f, 15f), 0f)
                    )
                )
            }
        }

        // Live Eyedropper indicator if active
        if (isEyeDropperActive) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(68.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.65f))
                    .border(2.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(detectionState.sampledColorRgb))
                        .border(2.dp, Color.White, CircleShape)
                )
                Icon(
                    imageVector = Icons.Default.Colorize,
                    contentDescription = "Sample Color",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }
            Text(
                text = "إضغط في أي مكان لأخذ عينة من اللون\nTap anywhere to lock color",
                color = Color.White,
                fontSize = 13.sp,
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(top = 100.dp)
                    .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            )
        }

        // Shutter flash effect
        if (isShutterFlashing) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.White.copy(alpha = 0.85f))
            )
        }
    }
}
