package com.example.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ZingBorder
import com.example.ui.theme.ZingDarkSurface
import com.example.ui.theme.ZingNeonPink
import com.example.ui.theme.ZingTextPrimary
import com.example.ui.theme.ZingTextSecondary

@Composable
fun AuthDialog(
    onDismiss: () -> Unit,
    onRegisterOrLogin: (String, String, String) -> Unit
) {
    var isSignUp by remember { mutableStateOf(true) }
    var username by remember { mutableStateOf("") }
    var displayName by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ZingDarkSurface,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Person, contentDescription = null, tint = ZingNeonPink, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isSignUp) "Join Sinji Shorts as Creator" else "Login to Sinji Shorts",
                    color = ZingTextPrimary,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text("Username (handle)", color = ZingTextSecondary) },
                    placeholder = { Text("e.g. viral_creator", color = ZingTextSecondary.copy(alpha = 0.5f)) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ZingTextPrimary,
                        unfocusedTextColor = ZingTextPrimary,
                        focusedBorderColor = ZingNeonPink,
                        unfocusedBorderColor = ZingBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = displayName,
                    onValueChange = { displayName = it },
                    label = { Text("Display Name", color = ZingTextSecondary) },
                    placeholder = { Text("e.g. Maya Roy", color = ZingTextSecondary.copy(alpha = 0.5f)) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ZingTextPrimary,
                        unfocusedTextColor = ZingTextPrimary,
                        focusedBorderColor = ZingNeonPink,
                        unfocusedBorderColor = ZingBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                if (isSignUp) {
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = bio,
                        onValueChange = { bio = it },
                        label = { Text("Bio", color = ZingTextSecondary) },
                        placeholder = { Text("Share your vibe with the world! ✨", color = ZingTextSecondary.copy(alpha = 0.5f)) },
                        minLines = 2,
                        maxLines = 3,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = ZingTextPrimary,
                            unfocusedTextColor = ZingTextPrimary,
                            focusedBorderColor = ZingNeonPink,
                            unfocusedBorderColor = ZingBorder
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                TextButton(
                    onClick = { isSignUp = !isSignUp },
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text(
                        text = if (isSignUp) "Already have an account? Login" else "New to Sinji Shorts? Sign Up",
                        color = ZingNeonPink,
                        fontSize = 12.sp
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (username.isNotBlank() && displayName.isNotBlank()) {
                        onRegisterOrLogin(username.trim(), displayName.trim(), bio.trim())
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = ZingNeonPink),
                enabled = username.isNotBlank() && displayName.isNotBlank()
            ) {
                Text(
                    text = if (isSignUp) "Register & Start Creating" else "Login",
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = ZingTextSecondary)
            }
        }
    )
}
