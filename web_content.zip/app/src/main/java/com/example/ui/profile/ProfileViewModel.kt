package com.example.ui.profile

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.ProfileEntity
import com.example.data.repository.ProfileRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ProfileUiState(
    val profile: ProfileEntity? = null,
    val isEditDialogOpen: Boolean = false,
    val editName: String = "",
    val editInstitute: String = "",
    val editPhotoUri: String? = null,
    val isSaving: Boolean = false
)

class ProfileViewModel(
    private val profileRepository: ProfileRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ProfileUiState())
    val uiState: StateFlow<ProfileUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            profileRepository.profileFlow.collect { profile ->
                _uiState.update { current ->
                    current.copy(
                        profile = profile,
                        editName = profile?.name ?: "",
                        editInstitute = profile?.instituteName ?: "",
                        editPhotoUri = profile?.photoUri
                    )
                }
            }
        }
    }

    fun openEditDialog() {
        val currentProfile = _uiState.value.profile
        _uiState.update {
            it.copy(
                isEditDialogOpen = true,
                editName = currentProfile?.name ?: "",
                editInstitute = currentProfile?.instituteName ?: "",
                editPhotoUri = currentProfile?.photoUri
            )
        }
    }

    fun closeEditDialog() {
        _uiState.update { it.copy(isEditDialogOpen = false) }
    }

    fun onEditNameChange(value: String) {
        _uiState.update { it.copy(editName = value) }
    }

    fun onEditInstituteChange(value: String) {
        _uiState.update { it.copy(editInstitute = value) }
    }

    fun onPhotoPicked(context: Context, uri: Uri) {
        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true) }
            val savedPath = profileRepository.savePhoto(context, uri)
            _uiState.update {
                it.copy(
                    isSaving = false,
                    editPhotoUri = savedPath
                )
            }
        }
    }

    fun onRemovePhoto() {
        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true) }
            profileRepository.removePhoto()
            _uiState.update {
                it.copy(
                    isSaving = false,
                    editPhotoUri = null
                )
            }
        }
    }

    fun saveProfile() {
        val state = _uiState.value
        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true) }
            profileRepository.updateProfileText(
                name = state.editName,
                instituteName = state.editInstitute
            )
            _uiState.update {
                it.copy(
                    isSaving = false,
                    isEditDialogOpen = false
                )
            }
        }
    }
}

class ProfileViewModelFactory(
    private val profileRepository: ProfileRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ProfileViewModel::class.java)) {
            return ProfileViewModel(profileRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
