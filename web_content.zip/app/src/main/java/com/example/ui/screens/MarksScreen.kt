package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.School
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.domain.AcademicCalculator
import com.example.model.Student
import com.example.model.Subject
import com.example.model.defaultReportLabels
import com.example.ui.components.AddStudentDialog
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.KpiStatTile
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.GoldSecondary
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.viewmodel.SchoolDashboardData
import com.example.viewmodel.SchoolViewModel

@Composable
fun MarksScreen(
    data: SchoolDashboardData,
    viewModel: SchoolViewModel,
    onNavigateToReports: () -> Unit,
) {
    val activeClass = data.activeClass
    if (activeClass == null) {
        Box(modifier = Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) {
            EmptyStateCard(
                icon = Icons.Rounded.School,
                title = "No Classes Found",
                subtitle = "Create a class in Customize to start recording student grades.",
            )
        }
        return
    }

    var showAddStudentDialog by remember { mutableStateOf(false) }

    if (showAddStudentDialog) {
        AddStudentDialog(
            className = activeClass.name,
            onDismiss = { showAddStudentDialog = false },
            onAdd = { name, idNo, conduct ->
                viewModel.addStudent(activeClass.id, name, idNo, conduct)
            },
        )
    }

    if (data.students.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) {
            EmptyStateCard(
                icon = Icons.Rounded.PersonAdd,
                title = "No Students in ${activeClass.name} Yet",
                subtitle = "Add your first student to begin entering marks and generating ranked report cards.",
                actionLabel = "+ Add First Student",
                onAction = { showAddStudentDialog = true },
            )
        }
        return
    }

    val stu = data.selectedStudent ?: data.students.first()
    val stuComp = data.analytics.byId[stu.id] ?: return
    val currentIndex = data.students.indexOfFirst { it.id == stu.id }.coerceAtLeast(0)
    val labels = defaultReportLabels() + data.config.labels
    val isPassing = stuComp.rawPct >= data.config.passMark.toDouble()

    var studentMenuExpanded by remember { mutableStateOf(false) }

    // Local draft state for metadata inputs keyed by student ID so typing is smooth
    var idNoDraft by remember(stu.id, stu.studentIdNo) { mutableStateOf(stu.studentIdNo) }
    var conductDraft by remember(stu.id, stu.conduct) { mutableStateOf(stu.conduct) }
    var latesDraft by remember(stu.id, stu.latesCount) { mutableStateOf(if (stu.latesCount > 0L) stu.latesCount.toString() else "") }
    var absencesDraft by remember(stu.id, stu.absencesCount) { mutableStateOf(if (stu.absencesCount > 0L) stu.absencesCount.toString() else "") }
    var obsDraft by remember(stu.id, stu.observation) { mutableStateOf(stu.observation) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        // 1. Student Switcher + Live KPIs
        item(key = "student_switcher") {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                tonalElevation = 1.dp,
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = "STUDENT ${currentIndex + 1} OF ${data.students.size} • ${activeClass.name}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        TextButton(
                            onClick = { showAddStudentDialog = true },
                            modifier = Modifier.testTag("marks_add_student_button"),
                        ) {
                            Icon(Icons.Rounded.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Add Student")
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        FilledTonalIconButton(
                            onClick = { viewModel.stepStudent(data.students, -1) },
                            modifier = Modifier.size(48.dp).testTag("prev_student_button"),
                        ) {
                            Icon(Icons.AutoMirrored.Rounded.KeyboardArrowLeft, contentDescription = "Previous student")
                        }

                        Box(modifier = Modifier.weight(1f)) {
                            OutlinedButton(
                                onClick = { studentMenuExpanded = true },
                                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("student_dropdown_button"),
                                shape = RoundedCornerShape(14.dp),
                            ) {
                                Text(
                                    text = "${stu.name} (${stuComp.formattedPct}%)",
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.titleSmall,
                                )
                            }
                            DropdownMenu(
                                expanded = studentMenuExpanded,
                                onDismissRequest = { studentMenuExpanded = false },
                            ) {
                                data.students.forEach { candidate ->
                                    val comp = data.analytics.byId[candidate.id]
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                "${candidate.name} — ${comp?.formattedPct ?: "0"}% (#${comp?.overallRank ?: 1})",
                                                maxLines = 1,
                                            )
                                        },
                                        onClick = {
                                            viewModel.selectStudent(candidate.id)
                                            studentMenuExpanded = false
                                        },
                                    )
                                }
                            }
                        }

                        FilledTonalIconButton(
                            onClick = { viewModel.stepStudent(data.students, 1) },
                            modifier = Modifier.size(48.dp).testTag("next_student_button"),
                        ) {
                            Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, contentDescription = "Next student")
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        KpiStatTile(
                            label = "Total",
                            value = "${AcademicCalculator.formatNumber(stuComp.studentTotGrand)}/${data.analytics.maxTotGrand}",
                            accentColor = MaterialTheme.colorScheme.onSurface,
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.weight(1f),
                        )
                        KpiStatTile(
                            label = "Average",
                            value = "${stuComp.formattedPct}%",
                            accentColor = if (isPassing) EmeraldSuccess else GoldSecondary,
                            containerColor = if (isPassing) EmeraldContainer else GoldContainer,
                            modifier = Modifier.weight(1f),
                        )
                        KpiStatTile(
                            label = "Position",
                            value = "#${stuComp.overallRank} / ${data.students.size}",
                            accentColor = MaterialTheme.colorScheme.primary,
                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.weight(1f),
                        )
                    }
                }
            }
        }

        // 2. Subject Score Input Cards
        items(data.subjects, key = { "${stu.id}_${it.id}" }) { subject ->
            val subRes = stuComp.subjectResults[subject.id]
            SubjectScoreCard(
                subject = subject,
                student = stu,
                subTot = subRes?.tot ?: 0.0,
                maxTot = subRes?.maxTot ?: (subject.maxTest + subject.maxExam),
                subRank = subRes?.rank ?: 1,
                testLabel = labels["test"] ?: "TEST",
                examLabel = labels["exam"] ?: "EXAM",
                onScoreChanged = { testScore, examScore ->
                    val newTestMap = stu.testScores.toMutableMap()
                    if (testScore == null) newTestMap.remove(subject.id) else newTestMap[subject.id] = testScore
                    val newExamMap = stu.examScores.toMutableMap()
                    if (examScore == null) newExamMap.remove(subject.id) else newExamMap[subject.id] = examScore

                    var updatedStu = stu.copy(testScores = newTestMap, examScores = newExamMap)
                    if (data.config.autoApplyObservations) {
                        val nextAnalytics = AcademicCalculator.computeClassAnalytics(
                            subjects = data.subjects,
                            students = data.students.map { if (it.id == stu.id) updatedStu else it },
                            config = data.config,
                        )
                        val pct = nextAnalytics.byId[stu.id]?.rawPct ?: 0.0
                        val autoObs = AcademicCalculator.resolveAutoObservation(pct, data.observationRules)
                        updatedStu = updatedStu.copy(observation = autoObs)
                        obsDraft = autoObs
                    }
                    viewModel.updateStudent(updatedStu, silent = true)
                },
            )
        }

        // 3. Conduct, Attendance Totals & Observation Card
        item(key = "metadata_${stu.id}") {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text(
                        text = "CONDUCT, ATTENDANCE & OBSERVATIONS",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = idNoDraft,
                            onValueChange = {
                                idNoDraft = it
                                viewModel.updateStudent(stu.copy(studentIdNo = it))
                            },
                            label = { Text(labels["idNo"] ?: "ID No.") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                        )
                        OutlinedTextField(
                            value = conductDraft,
                            onValueChange = {
                                conductDraft = it
                                viewModel.updateStudent(stu.copy(conduct = it))
                            },
                            label = { Text(labels["conduct"] ?: "Conduct") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = latesDraft,
                            onValueChange = { raw ->
                                val clean = raw.filter { it.isDigit() }
                                latesDraft = clean
                                val num = clean.toLongOrNull() ?: 0L
                                viewModel.updateStudent(stu.copy(latesCount = num.coerceIn(0L, 1000L)))
                            },
                            label = { Text(labels["lates"] ?: "Lates") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                        )
                        OutlinedTextField(
                            value = absencesDraft,
                            onValueChange = { raw ->
                                val clean = raw.filter { it.isDigit() }
                                absencesDraft = clean
                                val num = clean.toLongOrNull() ?: 0L
                                viewModel.updateStudent(stu.copy(absencesCount = num.coerceIn(0L, 1000L)))
                            },
                            label = { Text(labels["absences"] ?: "Absences") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = labels["observations"] ?: "Observations",
                            style = MaterialTheme.typography.labelMedium,
                        )
                        TextButton(
                            onClick = {
                                val autoObs = AcademicCalculator.resolveAutoObservation(
                                    stuComp.rawPct,
                                    data.observationRules,
                                )
                                obsDraft = autoObs
                                viewModel.updateStudent(stu.copy(observation = autoObs), silent = false)
                            },
                        ) {
                            Icon(Icons.Rounded.AutoAwesome, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Auto-Fill from %")
                        }
                    }

                    OutlinedTextField(
                        value = obsDraft,
                        onValueChange = {
                            obsDraft = it
                            viewModel.updateStudent(stu.copy(observation = it))
                        },
                        placeholder = { Text("e.g. Good You can do better") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )

                    Button(
                        onClick = onNavigateToReports,
                        modifier = Modifier.fillMaxWidth().height(50.dp).testTag("preview_student_report_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    ) {
                        Text("Preview ${stu.name.split(" ").firstOrNull() ?: "Student"}'s A4 Report Card")
                        Spacer(Modifier.width(8.dp))
                        Icon(Icons.AutoMirrored.Rounded.ArrowForward, contentDescription = null, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun SubjectScoreCard(
    subject: Subject,
    student: Student,
    subTot: Double,
    maxTot: Long,
    subRank: Int,
    testLabel: String,
    examLabel: String,
    onScoreChanged: (Double?, Double?) -> Unit,
) {
    val examEnabled = subject.maxExam > 0L
    val initialTest = student.testScores[subject.id]?.let { AcademicCalculator.formatNumber(it) } ?: ""
    val initialExam = student.examScores[subject.id]?.let { AcademicCalculator.formatNumber(it) } ?: ""

    var testText by remember(student.id, subject.id) { mutableStateOf(initialTest) }
    var examText by remember(student.id, subject.id) { mutableStateOf(initialExam) }

    LaunchedEffect(initialTest) {
        if (testText.toDoubleOrNull() != initialTest.toDoubleOrNull()) {
            testText = initialTest
        }
    }
    LaunchedEffect(initialExam) {
        if (examText.toDoubleOrNull() != initialExam.toDoubleOrNull()) {
            examText = initialExam
        }
    }

    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = subject.name,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = if (examEnabled) {
                            "Max: $testLabel ${subject.maxTest} + $examLabel ${subject.maxExam} = $maxTot"
                        } else {
                            "Max $testLabel: ${subject.maxTest} (Test Only)"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(10.dp),
                    ) {
                        Text(
                            text = "${AcademicCalculator.formatNumber(subTot)}/$maxTot",
                            fontFamily = JetBrainsMonoFamily,
                            style = MaterialTheme.typography.labelMedium,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        )
                    }
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(10.dp),
                    ) {
                        Text(
                            text = "#$subRank",
                            fontFamily = JetBrainsMonoFamily,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        )
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = testText,
                    onValueChange = { raw ->
                        val filtered = raw.filter { it.isDigit() || it == '.' }
                        val parsed = filtered.toDoubleOrNull()
                        val clamped = when {
                            filtered.isEmpty() -> {
                                testText = ""
                                null
                            }
                            parsed == null -> return@OutlinedTextField
                            parsed > subject.maxTest.toDouble() -> {
                                val maxD = subject.maxTest.toDouble()
                                testText = subject.maxTest.toString()
                                maxD
                            }
                            else -> {
                                testText = filtered
                                parsed
                            }
                        }
                        onScoreChanged(clamped, examText.toDoubleOrNull())
                    },
                    label = { Text("$testLabel (0–${subject.maxTest})") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                )

                if (examEnabled) {
                    OutlinedTextField(
                        value = examText,
                        onValueChange = { raw ->
                            val filtered = raw.filter { it.isDigit() || it == '.' }
                            val parsed = filtered.toDoubleOrNull()
                            val clamped = when {
                                filtered.isEmpty() -> {
                                    examText = ""
                                    null
                                }
                                parsed == null -> return@OutlinedTextField
                                parsed > subject.maxExam.toDouble() -> {
                                    val maxD = subject.maxExam.toDouble()
                                    examText = subject.maxExam.toString()
                                    maxD
                                }
                                else -> {
                                    examText = filtered
                                    parsed
                                }
                            }
                            onScoreChanged(testText.toDoubleOrNull(), clamped)
                        },
                        label = { Text("$examLabel (0–${subject.maxExam})") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }
    }
}
