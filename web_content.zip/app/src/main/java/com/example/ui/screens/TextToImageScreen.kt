package com.example.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.compose.SubcomposeAsyncImage
import com.example.data.models.MediaType
import com.example.data.models.ScreenDestination
import com.example.ui.theme.HazimCyan
import com.example.ui.theme.HazimCyanGlow
import com.example.ui.theme.HazimDarkBackground
import com.example.ui.theme.HazimDarkBorder
import com.example.ui.theme.HazimDarkSurface
import com.example.ui.theme.HazimDarkSurfaceVariant
import com.example.ui.theme.HazimPurple
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import com.example.ui.theme.TextTertiaryDark
import com.example.viewmodel.HazimAiViewModel

@Composable
fun TextToImageScreen(
    viewModel: HazimAiViewModel,
    onOpenDrawer: () -> Unit
) {
    val context = LocalContext.current
    val imagePrompt by viewModel.imagePrompt.collectAsState()
    val editPrompt by viewModel.editPrompt.collectAsState()
    val selectedStyle by viewModel.selectedStyle.collectAsState()
    val selectedAspectRatio by viewModel.selectedAspectRatio.collectAsState()
    val selectedResolution by viewModel.selectedResolution.collectAsState()
    val imageStudioMode by viewModel.imageStudioMode.collectAsState()
    val editSourceImage by viewModel.editSourceImage.collectAsState()
    val isGeneratingImage by viewModel.isGeneratingImage.collectAsState()
    val isProcessingNanoBanana by viewModel.isProcessingNanoBanana.collectAsState()
    val isEnhancingPrompt by viewModel.isEnhancingPrompt.collectAsState()
    val lastGeneratedImage by viewModel.lastGeneratedImage.collectAsState()
    val lastEditedImage by viewModel.lastEditedImage.collectAsState()
    val galleryItems by viewModel.galleryItems.collectAsState()

    var showCompareBeforeAfter by remember { mutableStateOf(false) }

    // Android Zero-permission Photo Picker for image editing
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            viewModel.loadEditImageFromUri(context, uri)
            Toast.makeText(context, "Image loaded for editing", Toast.LENGTH_SHORT).show()
        }
    }

    val galleryImages = galleryItems.filter { it.type == MediaType.IMAGE }

    val styles = listOf(
        "Photorealistic",
        "Cyberpunk",
        "Anime",
        "Cinematic",
        "Digital Art",
        "3D Render"
    )

    val editPresets = listOf(
        "⚡ Add Cyberpunk Neon Glow",
        "🏔️ Add Snowy Kashmir Background",
        "🌅 Cinematic Golden Hour Lighting",
        "🌸 Transform into Anime Aesthetic",
        "👓 Add Futuristic Tech Visor",
        "🎨 Oil Painting Masterpiece"
    )

    val resolutions = listOf("1K", "2K", "4K")

    val aspectRatios = listOf(
        Pair("1:1", "Square"),
        Pair("16:9", "Landscape"),
        Pair("9:16", "Story/Reel"),
        Pair("4:3", "Standard")
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(HazimDarkBackground)
            .imePadding()
            .navigationBarsPadding()
    ) {
        // Top Header Bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = HazimDarkBackground
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onOpenDrawer,
                    modifier = Modifier.testTag("tti_open_drawer_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Menu,
                        contentDescription = "Menu",
                        tint = TextPrimaryDark
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (imageStudioMode == "EDIT") "Edit Images" else "Create Images",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(HazimCyan.copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "gemini-nano-banana-2.1",
                                color = HazimCyan,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Text(
                        text = "High-Quality AI Creation & Editing (1K, 2K, 4K)",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondaryDark,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Mode Switcher: "Create New Image" vs "Edit Existing Image"
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .border(
                        1.dp,
                        if (imageStudioMode == "CREATE") HazimCyan else HazimDarkBorder,
                        RoundedCornerShape(12.dp)
                    )
                    .clickable { viewModel.setImageStudioMode("CREATE") }
                    .testTag("mode_create_button"),
                color = if (imageStudioMode == "CREATE") HazimCyan.copy(alpha = 0.15f) else HazimDarkSurface
            ) {
                Row(
                    modifier = Modifier.padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = if (imageStudioMode == "CREATE") HazimCyan else TextSecondaryDark,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Create Image",
                        fontWeight = if (imageStudioMode == "CREATE") FontWeight.Bold else FontWeight.Medium,
                        fontSize = 13.sp,
                        color = if (imageStudioMode == "CREATE") HazimCyan else TextSecondaryDark
                    )
                }
            }

            Surface(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .border(
                        1.dp,
                        if (imageStudioMode == "EDIT") HazimPurple else HazimDarkBorder,
                        RoundedCornerShape(12.dp)
                    )
                    .clickable { viewModel.setImageStudioMode("EDIT") }
                    .testTag("mode_edit_button"),
                color = if (imageStudioMode == "EDIT") HazimPurple.copy(alpha = 0.15f) else HazimDarkSurface
            ) {
                Row(
                    modifier = Modifier.padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoFixHigh,
                        contentDescription = null,
                        tint = if (imageStudioMode == "EDIT") HazimPurple else TextSecondaryDark,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Edit Image",
                        fontWeight = if (imageStudioMode == "EDIT") FontWeight.Bold else FontWeight.Medium,
                        fontSize = 13.sp,
                        color = if (imageStudioMode == "EDIT") HazimPurple else TextSecondaryDark
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Resolution (1K, 2K, 4K) & Aspect Ratio Configuration
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    color = HazimDarkSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, HazimDarkBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Model: gemini-nano-banana-2.1",
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryDark,
                                fontSize = 13.sp
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                resolutions.forEach { res ->
                                    val isSelected = selectedResolution == res
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(if (isSelected) HazimCyan else HazimDarkSurfaceVariant)
                                            .clickable { viewModel.setSelectedResolution(res) }
                                            .padding(horizontal = 8.dp, vertical = 3.dp)
                                    ) {
                                        Text(
                                            text = res,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = if (isSelected) Color.Black else TextSecondaryDark
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "Aspect Ratio",
                            fontWeight = FontWeight.SemiBold,
                            color = TextSecondaryDark,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            aspectRatios.forEach { (ratio, label) ->
                                val isSelected = selectedAspectRatio == ratio
                                Surface(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .border(
                                            1.dp,
                                            if (isSelected) HazimCyan else HazimDarkBorder,
                                            RoundedCornerShape(8.dp)
                                        )
                                        .clickable { viewModel.setSelectedAspectRatio(ratio) },
                                    color = if (isSelected) HazimCyan.copy(alpha = 0.2f) else HazimDarkSurfaceVariant
                                ) {
                                    Column(
                                        modifier = Modifier.padding(vertical = 6.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            text = ratio,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = if (isSelected) HazimCyan else TextPrimaryDark
                                        )
                                        Text(
                                            text = label,
                                            fontSize = 9.sp,
                                            color = TextSecondaryDark
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // === EDIT MODE SPECIFIC UI ===
            if (imageStudioMode == "EDIT") {
                // 1. Source Image Picker for Editing
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        color = HazimDarkSurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, HazimDarkBorder)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "1. Image to Edit",
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimaryDark,
                                    fontSize = 13.sp
                                )

                                Button(
                                    onClick = {
                                        photoPickerLauncher.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                    modifier = Modifier.height(34.dp).testTag("pick_device_photo_button"),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = HazimPurple,
                                        contentColor = Color.White
                                    )
                                ) {
                                    Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Pick from Device", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Show selected source or prompt to select
                            if (editSourceImage != null) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(70.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(HazimDarkSurfaceVariant)
                                    ) {
                                        AsyncImage(
                                            model = editSourceImage!!.mediaUrl,
                                            contentDescription = "Source Image",
                                            modifier = Modifier.fillMaxSize(),
                                            contentScale = ContentScale.Crop
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "Target Image Selected",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = HazimPurple
                                        )
                                        Text(
                                            text = editSourceImage!!.title,
                                            fontSize = 11.sp,
                                            color = TextSecondaryDark,
                                            maxLines = 1
                                        )
                                    }
                                }
                            } else {
                                Text(
                                    text = "Select an image from device or tap one below from your gallery to edit:",
                                    fontSize = 12.sp,
                                    color = TextSecondaryDark
                                )
                            }

                            if (galleryImages.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(text = "Or choose from gallery:", fontSize = 11.sp, color = TextTertiaryDark)
                                Spacer(modifier = Modifier.height(6.dp))
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    items(galleryImages) { item ->
                                        val isSelected = editSourceImage?.id == item.id
                                        Box(
                                            modifier = Modifier
                                                .size(60.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .border(
                                                    2.dp,
                                                    if (isSelected) HazimPurple else Color.Transparent,
                                                    RoundedCornerShape(8.dp)
                                                )
                                                .clickable { viewModel.setEditSourceImage(item) }
                                        ) {
                                            AsyncImage(
                                                model = item.mediaUrl,
                                                contentDescription = item.title,
                                                modifier = Modifier.fillMaxSize(),
                                                contentScale = ContentScale.Crop
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 2. Text Prompt for Editing
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        color = HazimDarkSurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, HazimDarkBorder)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "2. Text Prompt for Edit (gemini-nano-banana-2.1)",
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryDark,
                                fontSize = 13.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = editPrompt,
                                onValueChange = { viewModel.setEditPrompt(it) },
                                placeholder = {
                                    Text(
                                        text = "e.g., 'Add a glowing neon visor and cyberpunk reflections', 'Change background to snow-covered Kashmir mountains'...",
                                        color = TextTertiaryDark,
                                        fontSize = 13.sp
                                    )
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("edit_image_prompt_input"),
                                shape = RoundedCornerShape(12.dp),
                                minLines = 2,
                                maxLines = 4
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = "Quick Edit Presets:",
                                fontSize = 11.sp,
                                color = TextSecondaryDark,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(editPresets) { preset ->
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(HazimDarkSurfaceVariant)
                                            .clickable { viewModel.setEditPrompt(preset) }
                                            .padding(horizontal = 10.dp, vertical = 6.dp)
                                    ) {
                                        Text(text = preset, fontSize = 11.sp, color = HazimCyanGlow)
                                    }
                                }
                            }
                        }
                    }
                }

                // 3. Edit Action Button
                item {
                    Button(
                        onClick = { viewModel.executeCreateOrEditWithNanoBanana(isEdit = true) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("execute_edit_image_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = HazimPurple,
                            contentColor = Color.White
                        ),
                        enabled = !isProcessingNanoBanana && editPrompt.isNotBlank() && editSourceImage != null
                    ) {
                        if (isProcessingNanoBanana) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Editing with gemini-nano-banana-2.1 ($selectedResolution)...",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.AutoFixHigh,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Edit Image with gemini-nano-banana-2.1",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }

                // 4. Edit Output Display (Before / After Comparison)
                item {
                    val edited = lastEditedImage
                    if (edited != null) {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            color = HazimDarkSurface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, HazimDarkBorder)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Edited Result (gemini-nano-banana-2.1)",
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimaryDark,
                                        fontSize = 13.sp
                                    )

                                    // Before / After toggle button
                                    if (editSourceImage != null) {
                                        Surface(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(8.dp))
                                                .clickable { showCompareBeforeAfter = !showCompareBeforeAfter },
                                            color = HazimPurple.copy(alpha = 0.2f)
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(Icons.Default.Compare, contentDescription = null, tint = HazimPurple, modifier = Modifier.size(14.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(
                                                    text = if (showCompareBeforeAfter) "Show After" else "Compare Before",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = HazimPurple
                                                )
                                            }
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                val displayUrl = if (showCompareBeforeAfter && editSourceImage != null) {
                                    editSourceImage!!.mediaUrl
                                } else {
                                    edited.mediaUrl
                                }

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .aspectRatio(1f)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(HazimDarkSurfaceVariant)
                                ) {
                                    AsyncImage(
                                        model = displayUrl,
                                        contentDescription = edited.title,
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )

                                    Box(
                                        modifier = Modifier
                                            .padding(8.dp)
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(Color.Black.copy(alpha = 0.7f))
                                            .padding(horizontal = 8.dp, vertical = 3.dp)
                                            .align(Alignment.BottomStart)
                                    ) {
                                        Text(
                                            text = if (showCompareBeforeAfter) "ORIGINAL (BEFORE)" else "EDITED (gemini-nano-banana-2.1)",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (showCompareBeforeAfter) TextSecondaryDark else HazimCyan
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Text(
                                    text = edited.prompt,
                                    fontSize = 12.sp,
                                    color = TextSecondaryDark,
                                    maxLines = 2
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            viewModel.setItvSourceImage(edited)
                                            viewModel.navigateTo(ScreenDestination.IMAGE_TO_VIDEO)
                                        },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = HazimCyan,
                                            contentColor = Color.Black
                                        )
                                    ) {
                                        Icon(Icons.Default.Movie, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Send to ITV Video", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            val shareIntent = Intent().apply {
                                                action = Intent.ACTION_SEND
                                                putExtra(Intent.EXTRA_TEXT, "Edited with HAZIM AI (gemini-nano-banana-2.1):\n${edited.prompt}\n${edited.mediaUrl}")
                                                type = "text/plain"
                                            }
                                            context.startActivity(Intent.createChooser(shareIntent, "Share"))
                                        },
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = "Share", tint = TextSecondaryDark, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                // === CREATE MODE SPECIFIC UI ===
                // Prompt Input Card
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        color = HazimDarkSurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, HazimDarkBorder)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Text Prompt (gemini-nano-banana-2.1)",
                                    fontWeight = FontWeight.SemiBold,
                                    color = TextPrimaryDark,
                                    fontSize = 13.sp
                                )

                                Surface(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .clickable(enabled = !isEnhancingPrompt && imagePrompt.isNotBlank()) {
                                            viewModel.enhanceImagePrompt()
                                        }
                                        .testTag("tti_enhance_prompt_button"),
                                    color = HazimCyan.copy(alpha = 0.15f)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        if (isEnhancingPrompt) {
                                            CircularProgressIndicator(
                                                modifier = Modifier.size(12.dp),
                                                strokeWidth = 1.5.dp,
                                                color = HazimCyan
                                            )
                                        } else {
                                            Icon(
                                                imageVector = Icons.Default.AutoAwesome,
                                                contentDescription = null,
                                                tint = HazimCyan,
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = if (isEnhancingPrompt) "Enhancing..." else "AI Enhance",
                                            color = HazimCyan,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = imagePrompt,
                                onValueChange = { viewModel.setImagePrompt(it) },
                                placeholder = {
                                    Text(
                                        text = "e.g., A Kashmiri shikara boat floating on Dal Lake at neon sunset, 8k cinematic reflection...",
                                        color = TextTertiaryDark,
                                        fontSize = 13.sp
                                    )
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("tti_prompt_input"),
                                shape = RoundedCornerShape(12.dp),
                                minLines = 3,
                                maxLines = 5
                            )
                        }
                    }
                }

                // Visual Style Chips
                item {
                    Column {
                        Text(
                            text = "Visual Style Preset",
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(styles) { style ->
                                val isSelected = selectedStyle == style
                                Surface(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .border(
                                            1.dp,
                                            if (isSelected) HazimCyan else HazimDarkBorder,
                                            RoundedCornerShape(12.dp)
                                        )
                                        .clickable { viewModel.setSelectedStyle(style) },
                                    color = if (isSelected) HazimCyan.copy(alpha = 0.2f) else HazimDarkSurface
                                ) {
                                    Text(
                                        text = style,
                                        color = if (isSelected) HazimCyan else TextSecondaryDark,
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // Generate Button with gemini-nano-banana-2.1
                item {
                    Button(
                        onClick = { viewModel.executeCreateOrEditWithNanoBanana(isEdit = false) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("tti_generate_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = HazimCyan,
                            contentColor = Color.Black
                        ),
                        enabled = !isGeneratingImage && imagePrompt.isNotBlank()
                    ) {
                        if (isGeneratingImage) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = Color.Black,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Creating with gemini-nano-banana-2.1 ($selectedResolution)...",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Create with gemini-nano-banana-2.1",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }

                // Output Image Display Card
                item {
                    val image = lastGeneratedImage
                    if (image != null) {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            color = HazimDarkSurface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, HazimDarkBorder)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Generated with gemini-nano-banana-2.1",
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimaryDark,
                                        fontSize = 13.sp
                                    )
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(HazimCyan.copy(alpha = 0.2f))
                                            .padding(horizontal = 8.dp, vertical = 3.dp)
                                    ) {
                                        Text(
                                            text = "$selectedResolution Saved",
                                            color = HazimCyan,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .aspectRatio(1f)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(HazimDarkSurfaceVariant),
                                    contentAlignment = Alignment.Center
                                ) {
                                    SubcomposeAsyncImage(
                                        model = image.mediaUrl,
                                        contentDescription = image.title,
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop,
                                        loading = {
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .background(HazimDarkSurfaceVariant),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Column(
                                                    horizontalAlignment = Alignment.CenterHorizontally,
                                                    verticalArrangement = Arrangement.Center
                                                ) {
                                                    CircularProgressIndicator(
                                                        modifier = Modifier.size(32.dp),
                                                        color = HazimCyan,
                                                        strokeWidth = 2.5.dp
                                                    )
                                                    Spacer(modifier = Modifier.height(10.dp))
                                                    Text(
                                                        text = "Rendering AI Artwork...",
                                                        fontSize = 12.sp,
                                                        color = TextSecondaryDark,
                                                        fontWeight = FontWeight.Medium
                                                    )
                                                }
                                            }
                                        },
                                        error = {
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .background(HazimDarkSurfaceVariant),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Column(
                                                    horizontalAlignment = Alignment.CenterHorizontally,
                                                    verticalArrangement = Arrangement.Center,
                                                    modifier = Modifier.padding(16.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.AutoAwesome,
                                                        contentDescription = null,
                                                        tint = HazimCyan,
                                                        modifier = Modifier.size(36.dp)
                                                    )
                                                    Spacer(modifier = Modifier.height(6.dp))
                                                    Text(
                                                        text = "Generated Image Ready",
                                                        fontSize = 12.sp,
                                                        color = TextPrimaryDark,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }
                                        }
                                    )
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Text(
                                    text = image.prompt,
                                    fontSize = 12.sp,
                                    color = TextSecondaryDark,
                                    maxLines = 2
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    // Edit this image button!
                                    Button(
                                        onClick = {
                                            viewModel.setEditSourceImage(image)
                                            viewModel.setImageStudioMode("EDIT")
                                            Toast.makeText(context, "Loaded into Image Editor!", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = HazimPurple,
                                            contentColor = Color.White
                                        )
                                    ) {
                                        Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(text = "Edit with AI", fontSize = 12.sp)
                                    }

                                    Button(
                                        onClick = {
                                            viewModel.setItvSourceImage(image)
                                            viewModel.navigateTo(ScreenDestination.IMAGE_TO_VIDEO)
                                        },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = HazimCyan,
                                            contentColor = Color.Black
                                        )
                                    ) {
                                        Icon(Icons.Default.Movie, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(text = "Animate (ITV)", fontSize = 12.sp)
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            val shareIntent = Intent().apply {
                                                action = Intent.ACTION_SEND
                                                putExtra(
                                                    Intent.EXTRA_TEXT,
                                                    "Created with HAZIM AI (gemini-nano-banana-2.1):\n${image.prompt}\n${image.mediaUrl}"
                                                )
                                                type = "text/plain"
                                            }
                                            context.startActivity(Intent.createChooser(shareIntent, "Share Image"))
                                        },
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Share,
                                            contentDescription = "Share",
                                            tint = TextSecondaryDark,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(20.dp)) }
        }
    }
}
