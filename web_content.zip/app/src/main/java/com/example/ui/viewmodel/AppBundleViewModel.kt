package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.cloud.CloudSyncManager
import com.example.data.AppDatabase
import com.example.data.model.KeystoreEntity
import com.example.data.model.NotificationEntity
import com.example.data.model.ProjectEntity
import com.example.engine.AiAdvisorEngine
import com.example.engine.ApkSignerEngine
import com.example.engine.ArchiveConverterEngine
import com.example.engine.OptimizationEngine
import com.example.util.NotificationHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.ByteArrayInputStream

enum class AppScreen {
    DASHBOARD,
    PROJECTS,
    NEW_PROJECT,
    KEYSTORES,
    TOOLS
}

enum class ProjectFilter {
    ALL,
    APK_TO_AAB,
    ZIP_TO_APK,
    COMPLETED
}

class AppBundleViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application, viewModelScope)
    val cloudSyncManager = CloudSyncManager(application, database, viewModelScope)
    private val notificationHelper = NotificationHelper(application, database, viewModelScope)

    // Navigation & Global UI State
    private val _currentScreen = MutableStateFlow(AppScreen.DASHBOARD)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val _isArabic = MutableStateFlow(true)
    val isArabic: StateFlow<Boolean> = _isArabic.asStateFlow()

    private val _showNotificationDialog = MutableStateFlow(false)
    val showNotificationDialog: StateFlow<Boolean> = _showNotificationDialog.asStateFlow()

    private val _debugModeEnabled = MutableStateFlow(true)
    val debugModeEnabled: StateFlow<Boolean> = _debugModeEnabled.asStateFlow()

    // Data Streams
    val projects: StateFlow<List<ProjectEntity>> = database.projectDao().getAllProjects()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val keystores: StateFlow<List<KeystoreEntity>> = database.keystoreDao().getAllKeystores()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<NotificationEntity>> = database.notificationDao().getAllNotifications()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val unreadNotificationsCount: StateFlow<Int> = database.notificationDao().getUnreadCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // Project List Filters
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _activeFilter = MutableStateFlow(ProjectFilter.ALL)
    val activeFilter: StateFlow<ProjectFilter> = _activeFilter.asStateFlow()

    // Inspection & AI Modals
    private val _selectedProject = MutableStateFlow<ProjectEntity?>(null)
    val selectedProject: StateFlow<ProjectEntity?> = _selectedProject.asStateFlow()

    private val _activeAiAudit = MutableStateFlow<AiAdvisorEngine.AiAuditResult?>(null)
    val activeAiAudit: StateFlow<AiAdvisorEngine.AiAuditResult?> = _activeAiAudit.asStateFlow()

    private val _activeDiagnostic = MutableStateFlow<OptimizationEngine.DiagnosticReport?>(null)
    val activeDiagnostic: StateFlow<OptimizationEngine.DiagnosticReport?> = _activeDiagnostic.asStateFlow()

    // New Project Wizard State
    private val _wizardStep = MutableStateFlow(1) // 1: Select, 2: Options, 3: Signing, 4: Execute/Done
    val wizardStep: StateFlow<Int> = _wizardStep.asStateFlow()

    private val _sourceType = MutableStateFlow("APK") // "APK", "ZIP"
    val sourceType: StateFlow<String> = _sourceType.asStateFlow()

    private val _sourceFileName = MutableStateFlow("app-debug.apk")
    val sourceFileName: StateFlow<String> = _sourceFileName.asStateFlow()

    private val _sourceFileBytes = MutableStateFlow<ByteArray?>(null)
    val sourceFileBytes: StateFlow<ByteArray?> = _sourceFileBytes.asStateFlow()

    private val _targetType = MutableStateFlow("AAB") // "AAB", "APK"
    val targetType: StateFlow<String> = _targetType.asStateFlow()

    private val _autoSign = MutableStateFlow(true)
    val autoSign: StateFlow<Boolean> = _autoSign.asStateFlow()

    private val _selectedKeystore = MutableStateFlow<KeystoreEntity?>(null)
    val selectedKeystore: StateFlow<KeystoreEntity?> = _selectedKeystore.asStateFlow()

    private val _optimizeZipAlign = MutableStateFlow(true)
    val optimizeZipAlign: StateFlow<Boolean> = _optimizeZipAlign.asStateFlow()

    private val _removeDebuggable = MutableStateFlow(true)
    val removeDebuggable: StateFlow<Boolean> = _removeDebuggable.asStateFlow()

    private val _compressAssets = MutableStateFlow(true)
    val compressAssets: StateFlow<Boolean> = _compressAssets.asStateFlow()

    // Conversion Running State
    private val _isConverting = MutableStateFlow(false)
    val isConverting: StateFlow<Boolean> = _isConverting.asStateFlow()

    private val _conversionProgress = MutableStateFlow(0)
    val conversionProgress: StateFlow<Int> = _conversionProgress.asStateFlow()

    private val _conversionStatusText = MutableStateFlow("")
    val conversionStatusText: StateFlow<String> = _conversionStatusText.asStateFlow()

    private val _conversionLogs = MutableStateFlow<List<String>>(emptyList())
    val conversionLogs: StateFlow<List<String>> = _conversionLogs.asStateFlow()

    private val _lastConversionResult = MutableStateFlow<ArchiveConverterEngine.ConversionResult?>(null)
    val lastConversionResult: StateFlow<ArchiveConverterEngine.ConversionResult?> = _lastConversionResult.asStateFlow()

    init {
        // Initialize sample source file
        loadSampleSource("APK")
    }

    fun setScreen(screen: AppScreen) {
        _currentScreen.value = screen
    }

    fun toggleLanguage() {
        _isArabic.value = !_isArabic.value
    }

    fun toggleDebugMode() {
        _debugModeEnabled.value = !_debugModeEnabled.value
    }

    fun setNotificationDialogVisible(visible: Boolean) {
        _showNotificationDialog.value = visible
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setActiveFilter(filter: ProjectFilter) {
        _activeFilter.value = filter
    }

    fun setSelectedProject(project: ProjectEntity?) {
        _selectedProject.value = project
        if (project != null) {
            _activeAiAudit.value = AiAdvisorEngine.generateAudit(project)
        } else {
            _activeAiAudit.value = null
        }
    }

    fun setWizardStep(step: Int) {
        _wizardStep.value = step
    }

    fun setSourceType(type: String) {
        _sourceType.value = type
        if (type == "APK") {
            _targetType.value = "AAB"
            _sourceFileName.value = "app-release.apk"
        } else {
            _targetType.value = "APK"
            _sourceFileName.value = "webapp_archive.zip"
        }
        loadSampleSource(type)
    }

    fun setSourceFile(name: String, bytes: ByteArray) {
        _sourceFileName.value = name
        _sourceFileBytes.value = bytes
        // Run preliminary diagnostic
        try {
            _activeDiagnostic.value = OptimizationEngine.analyzeArchive(
                ByteArrayInputStream(bytes),
                bytes.size.toLong()
            )
        } catch (_: Exception) { }
    }

    fun loadSampleSource(type: String) {
        val bytes = if (type == "APK") {
            ArchiveConverterEngine.createSampleApk()
        } else {
            ArchiveConverterEngine.createSampleZip()
        }
        _sourceFileBytes.value = bytes
        try {
            _activeDiagnostic.value = OptimizationEngine.analyzeArchive(
                ByteArrayInputStream(bytes),
                bytes.size.toLong()
            )
        } catch (_: Exception) { }
    }

    fun setAutoSign(enabled: Boolean) {
        _autoSign.value = enabled
    }

    fun setSelectedKeystore(keystore: KeystoreEntity?) {
        _selectedKeystore.value = keystore
    }

    fun setOptimizeZipAlign(enabled: Boolean) {
        _optimizeZipAlign.value = enabled
    }

    fun setRemoveDebuggable(enabled: Boolean) {
        _removeDebuggable.value = enabled
    }

    fun setCompressAssets(enabled: Boolean) {
        _compressAssets.value = enabled
    }

    fun startConversion(projectNameInput: String? = null) {
        val bytes = _sourceFileBytes.value ?: return
        val type = _sourceType.value
        val name = if (!projectNameInput.isNullOrBlank()) projectNameInput else {
            if (type == "APK") "تحويل حزمة ${_sourceFileName.value}" else "تغليف حزمة ${_sourceFileName.value}"
        }

        viewModelScope.launch {
            _isConverting.value = true
            _conversionProgress.value = 5
            _conversionStatusText.value = "تهيئة محرك التحويل..."
            _conversionLogs.value = listOf("[INIT] بدء تهيئة جلسة تحويل جديدة للمشروع: $name")

            // Key info for signing
            val keyInfo = if (_autoSign.value) {
                val alias = _selectedKeystore.value?.alias ?: "androiddebugkey"
                ApkSignerEngine.generateKeyPair(alias = alias)
            } else null

            val options = ArchiveConverterEngine.ConverterOptions(
                autoSign = _autoSign.value,
                keyInfo = keyInfo,
                optimizeZipAlign = _optimizeZipAlign.value,
                removeDebuggable = _removeDebuggable.value,
                compressAssets = _compressAssets.value
            )

            val result = if (type == "APK") {
                ArchiveConverterEngine.convertApkToAab(
                    ByteArrayInputStream(bytes),
                    options
                ) { pct, msg ->
                    _conversionProgress.value = pct
                    _conversionStatusText.value = msg
                    _conversionLogs.value = _conversionLogs.value + "[PROGRESS $pct%] $msg"
                }
            } else {
                ArchiveConverterEngine.convertZipToApk(
                    ByteArrayInputStream(bytes),
                    options
                ) { pct, msg ->
                    _conversionProgress.value = pct
                    _conversionStatusText.value = msg
                    _conversionLogs.value = _conversionLogs.value + "[PROGRESS $pct%] $msg"
                }
            }

            _lastConversionResult.value = result
            _isConverting.value = false

            if (result.success) {
                // Save to Room
                val now = System.currentTimeMillis()
                val outName = if (type == "APK") {
                    _sourceFileName.value.replace(".apk", "_converted.aab")
                } else {
                    _sourceFileName.value.replace(".zip", "_signed.apk")
                }

                val project = ProjectEntity(
                    name = name,
                    type = if (type == "APK") "APK_TO_AAB" else "ZIP_TO_APK",
                    sourceFileName = _sourceFileName.value,
                    sourceFileSize = result.originalSize,
                    outputFileName = outName,
                    outputFileSize = result.outputSize,
                    status = "COMPLETED",
                    createdAt = now,
                    updatedAt = now,
                    compressionRatio = result.compressionRatio,
                    dexCount = result.dexCount,
                    signingKeyAlias = keyInfo?.alias ?: "بدون توقيع",
                    optimizationScore = 95,
                    isCloudSynced = false,
                    logMessages = result.logs.joinToString("\n"),
                    packageName = result.packageName,
                    versionName = result.versionName,
                    targetSdk = result.targetSdk
                )

                val id = database.projectDao().insertProject(project)

                // Trigger in-app + system notification & haptics!
                notificationHelper.notifyOperationCompleted(
                    title = "اكتمل التحويل بنجاح! 🚀",
                    message = "تم إنشاء حزمة $outName وتوفير ${"%.1f".format(result.compressionRatio)}% من الحجم.",
                    isSuccess = true
                )

                // Advance wizard to finished results
                _wizardStep.value = 4

                // Auto-sync to cloud if online
                if (cloudSyncManager.isOnline.value) {
                    cloudSyncManager.triggerSync()
                }
            } else {
                notificationHelper.notifyOperationCompleted(
                    title = "فشل التحويل!",
                    message = "حدث خطأ أثناء معالجة الحزمة، يرجى مراجعة سجل التصحيح.",
                    isSuccess = false
                )
            }
        }
    }

    fun createKeystore(
        alias: String,
        password: String,
        validity: Int,
        keyType: String,
        org: String,
        country: String
    ) {
        viewModelScope.launch {
            val keySize = if (keyType == "RSA_4096") 4096 else 2048
            val keyInfo = ApkSignerEngine.generateKeyPair(keySize, alias)

            val keystore = KeystoreEntity(
                alias = alias,
                storePassword = password,
                keyPassword = password,
                keyType = keyType,
                validityYears = validity,
                sha256Fingerprint = keyInfo.sha256Fingerprint,
                sha1Fingerprint = keyInfo.sha1Fingerprint,
                md5Fingerprint = keyInfo.md5Fingerprint,
                organization = org,
                countryCode = country,
                isDefault = false
            )
            database.keystoreDao().insertKeystore(keystore)

            notificationHelper.notifyOperationCompleted(
                title = "تم إنشاء مفتاح التوقيع 🔒",
                message = "تم إنشاء المفتاح '$alias' بصلاحية $validity سنة وتشفير $keyType.",
                isSuccess = true
            )
        }
    }

    fun deleteProject(project: ProjectEntity) {
        viewModelScope.launch {
            database.projectDao().deleteProject(project)
        }
    }

    fun deleteKeystore(keystore: KeystoreEntity) {
        viewModelScope.launch {
            database.keystoreDao().deleteKeystore(keystore)
        }
    }

    fun markNotificationsAsRead() {
        viewModelScope.launch {
            database.notificationDao().markAllAsRead()
        }
    }

    fun clearNotifications() {
        viewModelScope.launch {
            database.notificationDao().clearAll()
        }
    }

    fun triggerCloudSync() {
        viewModelScope.launch {
            cloudSyncManager.triggerSync()
        }
    }

    fun exportProjectsBackup(onDone: (String) -> Unit) {
        viewModelScope.launch {
            val list = projects.value
            val json = cloudSyncManager.exportProjectsToJson(list)
            onDone(json)
        }
    }

    fun importProjectsBackup(json: String, onDone: (Int) -> Unit) {
        viewModelScope.launch {
            val count = cloudSyncManager.importProjectsFromJson(json)
            onDone(count)
        }
    }
}
