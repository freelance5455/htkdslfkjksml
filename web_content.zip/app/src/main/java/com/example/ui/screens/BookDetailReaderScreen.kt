package com.example.ui.screens

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.FormatListBulleted
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TextDecrease
import androidx.compose.material.icons.filled.TextIncrease
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Book
import com.example.data.model.Chapter
import com.example.ui.components.TypographicBookCover
import com.example.ui.theme.LoraFontFamily
import com.example.ui.theme.PlayfairDisplayFontFamily
import com.example.ui.viewmodel.UiState
import kotlin.math.roundToInt

enum class ReaderPaperStyle(val labelTr: String, val bgColor: Color, val textColor: Color) {
    PARCHMENT("Parşömen", Color(0xFFF7F0E4), Color(0xFF231D18)),
    CLASSIC_WHITE("Klasik Beyaz", Color(0xFFFFFFFF), Color(0xFF1A1A1A)),
    NIGHT_OWL("Gece Okuması", Color(0xFF181D24), Color(0xFFEAE3D9))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookDetailReaderScreen(
    book: Book?,
    chaptersState: UiState<List<Chapter>>,
    isGeneratingAiChapter: Boolean,
    operationMessage: String?,
    onAddManualChapter: (book: Book, nextChapterNumber: Int, title: String, summary: String, content: String, onComplete: () -> Unit) -> Unit,
    onAddAiChapter: (book: Book, nextChapterNumber: Int, directionPrompt: String, onComplete: () -> Unit) -> Unit,
    onExpandChapterWithAi: (book: Book, chapter: Chapter, totalChapters: Int) -> Unit,
    onUpdateChapter: (book: Book, chapter: Chapter, newTitle: String, newSummary: String, newContent: String, onComplete: () -> Unit) -> Unit,
    onDeleteBook: (bookId: String, chapterIds: List<String>) -> Unit,
    onClearMessage: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler {
        onBack()
    }

    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    var selectedChapterIndex by rememberSaveable { mutableIntStateOf(0) }
    var fontSizeSp by rememberSaveable { mutableIntStateOf(17) }
    var paperStyle by rememberSaveable { mutableStateOf(ReaderPaperStyle.PARCHMENT) }

    var showAddManualDialog by remember { mutableStateOf(false) }
    var showAddAiDialog by remember { mutableStateOf(false) }
    var showTableOfContentsDialog by remember { mutableStateOf(false) }
    var editingChapter by remember { mutableStateOf<Chapter?>(null) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    LaunchedEffect(operationMessage) {
        if (!operationMessage.isNullOrBlank()) {
            snackbarHostState.showSnackbar(operationMessage)
            onClearMessage()
        }
    }

    val chapters = (chaptersState as? UiState.Success)?.data.orEmpty()
    val safeIndex = selectedChapterIndex.coerceIn(0, (chapters.size - 1).coerceAtLeast(0))
    val currentChapter = chapters.getOrNull(safeIndex)

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = book?.title ?: "Kitap Okuyucu",
                        style = MaterialTheme.typography.titleLarge,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("reader_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Geri"
                        )
                    }
                },
                actions = {
                    if (book != null) {
                        IconButton(
                            onClick = { showTableOfContentsDialog = true },
                            modifier = Modifier.testTag("toc_dialog_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.FormatListBulleted,
                                contentDescription = "Bölüm Fihristi"
                            )
                        }

                        IconButton(
                            onClick = {
                                val fullManuscript = buildString {
                                    appendLine(book.title.uppercase())
                                    if (book.subtitle.isNotBlank()) appendLine(book.subtitle)
                                    appendLine("Tür: ${book.genre} | Üslup: ${book.tone}")
                                    appendLine("====================================\n")
                                    if (book.synopsis.isNotBlank()) {
                                        appendLine("ÖZET:")
                                        appendLine(book.synopsis)
                                        appendLine("\n------------------------------------\n")
                                    }
                                    chapters.take(25).forEach { ch ->
                                        appendLine(ch.title)
                                        appendLine()
                                        appendLine(ch.content)
                                        appendLine("\n------------------------------------\n")
                                    }
                                }
                                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_SUBJECT, book.title)
                                    putExtra(Intent.EXTRA_TEXT, fullManuscript)
                                }
                                context.startActivity(Intent.createChooser(sendIntent, "Kitabı Paylaş"))
                            },
                            modifier = Modifier.testTag("share_book_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = stringResource(R.string.share_book)
                            )
                        }

                        IconButton(
                            onClick = { showDeleteConfirm = true },
                            modifier = Modifier.testTag("delete_book_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = stringResource(R.string.delete_book),
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        if (book == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 700.dp)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Book Cover & Metadata Banner
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            TypographicBookCover(
                                title = book.title,
                                subtitle = book.subtitle,
                                genre = book.genre,
                                coverTheme = book.coverTheme,
                                isAiCreated = book.isAiCreated,
                                width = 104.dp,
                                height = 152.dp
                            )

                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (book.isAiCreated) {
                                        MaterialTheme.colorScheme.primaryContainer
                                    } else {
                                        MaterialTheme.colorScheme.secondaryContainer
                                    }
                                ) {
                                    Text(
                                        text = if (book.isAiCreated) "✦ Ai ile oluşturuldu" else "✦ Kendin yazarak oluşturdun",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = if (book.isAiCreated) {
                                            MaterialTheme.colorScheme.onPrimaryContainer
                                        } else {
                                            MaterialTheme.colorScheme.onSecondaryContainer
                                        },
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }

                                Text(
                                    text = book.title,
                                    style = MaterialTheme.typography.headlineSmall,
                                    fontWeight = FontWeight.Bold
                                )

                                if (book.subtitle.isNotBlank()) {
                                    Text(
                                        text = book.subtitle,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                }

                                Text(
                                    text = "${book.genre} • ${book.tone}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                Text(
                                    text = "${chapters.size} Bölüm • ${book.totalWordCount} Kelime",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        if (book.synopsis.isNotBlank()) {
                            HorizontalDivider()
                            Text(
                                text = "Arka Kapak Özeti",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.secondary
                            )
                            Text(
                                text = book.synopsis,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        // Action buttons to add chapters (either with AI or Manually)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { showAddAiDialog = true },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("add_chapter_ai_button"),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = stringResource(R.string.add_chapter_ai),
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }

                            OutlinedButton(
                                onClick = { showAddManualDialog = true },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("add_chapter_manual_button"),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = stringResource(R.string.add_chapter_manual),
                                    style = MaterialTheme.typography.labelLarge
                                )
                            }
                        }
                    }
                }

                // Reading Controls (Paper style + Font size)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ReaderPaperStyle.entries.forEach { style ->
                            FilterChip(
                                selected = paperStyle == style,
                                onClick = { paperStyle = style },
                                label = { Text(style.labelTr) }
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { fontSizeSp = (fontSizeSp - 2).coerceAtLeast(13) }
                        ) {
                            Icon(
                                imageVector = Icons.Default.TextDecrease,
                                contentDescription = "Yazıyı Küçült"
                            )
                        }
                        Text(
                            text = "${fontSizeSp}sp",
                            style = MaterialTheme.typography.labelMedium
                        )
                        IconButton(
                            onClick = { fontSizeSp = (fontSizeSp + 2).coerceAtMost(26) }
                        ) {
                            Icon(
                                imageVector = Icons.Default.TextIncrease,
                                contentDescription = "Yazıyı Büyüt"
                            )
                        }
                    }
                }

                // Fast Chapter Navigation Bar (Supports 80-240 chapters effortlessly)
                if (chapters.isNotEmpty()) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Bölüm Geçişi: ${safeIndex + 1} / ${chapters.size}",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold
                                )
                                TextButton(
                                    onClick = { showTableOfContentsDialog = true },
                                    modifier = Modifier.testTag("open_toc_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.FormatListBulleted,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Tüm Bölümler (${chapters.size})")
                                }
                            }

                            if (chapters.size > 1) {
                                Slider(
                                    value = safeIndex.toFloat(),
                                    onValueChange = { value ->
                                        selectedChapterIndex = value.roundToInt()
                                            .coerceIn(0, chapters.size - 1)
                                    },
                                    valueRange = 0f..(chapters.size - 1).toFloat(),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("reader_chapter_slider")
                                )
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                val windowStart = (safeIndex - 4).coerceAtLeast(0)
                                val windowEnd = (windowStart + 12).coerceAtMost(chapters.size)
                                for (idx in windowStart until windowEnd) {
                                    FilterChip(
                                        selected = safeIndex == idx,
                                        onClick = { selectedChapterIndex = idx },
                                        label = {
                                            Text("${idx + 1}. Bölüm")
                                        },
                                        modifier = Modifier.testTag("chapter_tab_$idx")
                                    )
                                }
                            }
                        }
                    }
                }

                // Reader Page Content
                if (currentChapter != null) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("reader_page_card"),
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = paperStyle.bgColor
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 24.dp, vertical = 28.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "BÖLÜM ${currentChapter.chapterNumber} / ${chapters.size} • ${currentChapter.wordCount} KELİME",
                                    fontFamily = LoraFontFamily,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = paperStyle.textColor.copy(alpha = 0.65f),
                                    letterSpacing = 1.2.sp
                                )

                                TextButton(
                                    onClick = { editingChapter = currentChapter },
                                    modifier = Modifier.testTag("edit_current_chapter_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                        tint = paperStyle.textColor
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = stringResource(R.string.edit_chapter),
                                        color = paperStyle.textColor
                                    )
                                }
                            }

                            Text(
                                text = currentChapter.title,
                                fontFamily = PlayfairDisplayFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = (fontSizeSp + 6).sp,
                                lineHeight = (fontSizeSp + 14).sp,
                                color = paperStyle.textColor
                            )

                            if (currentChapter.summary.isNotBlank()) {
                                Text(
                                    text = currentChapter.summary,
                                    fontFamily = LoraFontFamily,
                                    fontSize = (fontSizeSp - 2).sp,
                                    lineHeight = (fontSizeSp + 4).sp,
                                    color = paperStyle.textColor.copy(alpha = 0.75f)
                                )
                            }

                            // AI Expand Button for lengthening any chapter on demand
                            FilledTonalButton(
                                onClick = {
                                    onExpandChapterWithAi(book, currentChapter, chapters.size)
                                },
                                enabled = !isGeneratingAiChapter,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("expand_chapter_ai_button"),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                if (isGeneratingAiChapter) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Yapay zeka bu bölümü uzatıp zenginleştiriyor…")
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("✦ Bu Bölümü AI ile Daha da Uzat ve Detaylandır")
                                }
                            }

                            HorizontalDivider(
                                color = paperStyle.textColor.copy(alpha = 0.2f)
                            )

                            Text(
                                text = currentChapter.content,
                                fontFamily = LoraFontFamily,
                                fontSize = fontSizeSp.sp,
                                lineHeight = (fontSizeSp + 10).sp,
                                color = paperStyle.textColor
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Previous / Next Chapter Pagination
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedButton(
                                    onClick = { if (safeIndex > 0) selectedChapterIndex = safeIndex - 1 },
                                    enabled = safeIndex > 0
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Önceki Bölüm")
                                }

                                Text(
                                    text = "${currentChapter.wordCount} kelime",
                                    fontFamily = LoraFontFamily,
                                    fontSize = 12.sp,
                                    color = paperStyle.textColor.copy(alpha = 0.6f)
                                )

                                OutlinedButton(
                                    onClick = {
                                        if (safeIndex < chapters.size - 1) {
                                            selectedChapterIndex = safeIndex + 1
                                        }
                                    },
                                    enabled = safeIndex < chapters.size - 1
                                ) {
                                    Text("Sonraki Bölüm")
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // Table of Contents Dialog (for jumping directly to any of 80-240 chapters)
    if (showTableOfContentsDialog) {
        AlertDialog(
            onDismissRequest = { showTableOfContentsDialog = false },
            title = { Text("Bölüm Fihristi (${chapters.size} Bölüm)") },
            text = {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 420.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    itemsIndexed(chapters, key = { _, ch -> ch.id.ifEmpty { ch.chapterNumber.toString() } }) { idx, ch ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedChapterIndex = idx
                                    showTableOfContentsDialog = false
                                },
                            shape = RoundedCornerShape(10.dp),
                            color = if (idx == safeIndex) {
                                MaterialTheme.colorScheme.primaryContainer
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                            }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = ch.title,
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = if (idx == safeIndex) FontWeight.Bold else FontWeight.Medium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${ch.wordCount} kelime",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                if (idx == safeIndex) {
                                    Text(
                                        text = "Okunuyor",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showTableOfContentsDialog = false }) {
                    Text("Kapat")
                }
            }
        )
    }

    // Add Manual Chapter Dialog
    if (showAddManualDialog && book != null) {
        val nextNum = chapters.size + 1
        var newChTitle by remember { mutableStateOf("$nextNum. Bölüm") }
        var newChSummary by remember { mutableStateOf("") }
        var newChContent by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddManualDialog = false },
            title = { Text("Kendin Yeni Bölüm Yaz") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = newChTitle,
                        onValueChange = { newChTitle = it },
                        label = { Text("Bölüm Başlığı") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newChSummary,
                        onValueChange = { newChSummary = it },
                        label = { Text("Kısa Bölüm Özeti (İsteğe Bağlı)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newChContent,
                        onValueChange = { newChContent = it },
                        label = { Text("Bölüm Metni") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onAddManualChapter(
                            book,
                            nextNum,
                            newChTitle,
                            newChSummary,
                            newChContent
                        ) {
                            showAddManualDialog = false
                            selectedChapterIndex = chapters.size
                        }
                    }
                ) {
                    Text("Kaydet")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddManualDialog = false }) {
                    Text("İptal")
                }
            }
        )
    }

    // Add AI Chapter Dialog
    if (showAddAiDialog && book != null) {
        val nextNum = chapters.size + 1
        var directionPrompt by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { if (!isGeneratingAiChapter) showAddAiDialog = false },
            title = { Text("AI ile $nextNum. Bölümü Oluştur") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Bu bölümde neler olmasını istediğinizi kısaca belirtebilir veya boş bırakarak yapay zekanın hikayeyi uzun ve detaylı biçimde sürdürmesini sağlayabilirsiniz.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = directionPrompt,
                        onValueChange = { directionPrompt = it },
                        enabled = !isGeneratingAiChapter,
                        label = { Text("Bölüm Yönlendirmesi (İsteğe Bağlı)") },
                        placeholder = { Text("Örn: Ana karakter gizli mektubu açar ve beklenmedik bir sırla karşılaşır…") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                    )
                    if (isGeneratingAiChapter) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp))
                            Text(
                                text = "Yapay zeka uzun bölümü yazıyor…",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onAddAiChapter(book, nextNum, directionPrompt) {
                            showAddAiDialog = false
                            selectedChapterIndex = chapters.size
                        }
                    },
                    enabled = !isGeneratingAiChapter
                ) {
                    Text("AI ile Yaz")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showAddAiDialog = false },
                    enabled = !isGeneratingAiChapter
                ) {
                    Text("İptal")
                }
            }
        )
    }

    // Edit Existing Chapter Dialog
    val chapterToEdit = editingChapter
    if (chapterToEdit != null && book != null) {
        var editedTitle by remember(chapterToEdit.id) { mutableStateOf(chapterToEdit.title) }
        var editedSummary by remember(chapterToEdit.id) { mutableStateOf(chapterToEdit.summary) }
        var editedContent by remember(chapterToEdit.id) { mutableStateOf(chapterToEdit.content) }

        AlertDialog(
            onDismissRequest = { editingChapter = null },
            title = { Text("Bölümü Düzenle") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = editedTitle,
                        onValueChange = { editedTitle = it },
                        label = { Text("Bölüm Başlığı") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = editedSummary,
                        onValueChange = { editedSummary = it },
                        label = { Text("Bölüm Özeti") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = editedContent,
                        onValueChange = { editedContent = it },
                        label = { Text("Bölüm Metni") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onUpdateChapter(
                            book,
                            chapterToEdit,
                            editedTitle,
                            editedSummary,
                            editedContent
                        ) {
                            editingChapter = null
                        }
                    }
                ) {
                    Text("Güncelle")
                }
            },
            dismissButton = {
                TextButton(onClick = { editingChapter = null }) {
                    Text("İptal")
                }
            }
        )
    }

    // Delete Confirmation Dialog
    if (showDeleteConfirm && book != null) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Kitabı Sil") },
            text = {
                Text(
                    text = "\"${book.title}\" adlı kitabı ve tüm bölümlerini silmek istediğinize emin misiniz?",
                    textAlign = TextAlign.Start
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirm = false
                        onDeleteBook(book.id, chapters.map { it.id })
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Text("Evet, Sil")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Vazgeç")
                }
            }
        )
    }
}
