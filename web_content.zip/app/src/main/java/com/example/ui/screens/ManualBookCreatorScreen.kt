package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.AiGeneratedChapterDraft
import com.example.data.model.BookCoverTheme
import com.example.data.model.LiteraryCatalog
import com.example.data.model.countWords
import com.example.ui.components.TypographicBookCover

data class EditableChapterInput(
    val title: String,
    val summary: String,
    val content: String
)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ManualBookCreatorScreen(
    isSaving: Boolean,
    onSaveManualBook: (
        title: String,
        subtitle: String,
        synopsis: String,
        genre: String,
        tone: String,
        coverTheme: String,
        chapters: List<AiGeneratedChapterDraft>,
        onValidationError: (String) -> Unit
    ) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(enabled = !isSaving) {
        onBack()
    }

    var title by rememberSaveable { mutableStateOf("") }
    var subtitle by rememberSaveable { mutableStateOf("") }
    var synopsis by rememberSaveable { mutableStateOf("") }
    var selectedGenre by rememberSaveable { mutableStateOf(LiteraryCatalog.genres.first()) }
    var selectedTone by rememberSaveable { mutableStateOf(LiteraryCatalog.tones.first()) }
    var selectedCoverTheme by rememberSaveable { mutableStateOf(BookCoverTheme.PARCHMENT.id) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val chapterInputs = remember {
        mutableStateListOf(
            EditableChapterInput(
                title = "1. Bölüm: Başlangıç",
                summary = "",
                content = ""
            )
        )
    }

    val totalWordCount = chapterInputs.sumOf { countWords(it.content) }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.EditNote,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.manual_studio_header),
                            style = MaterialTheme.typography.titleLarge
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        enabled = !isSaving,
                        modifier = Modifier.testTag("manual_creator_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Geri"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 640.dp)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer
                    ),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "Kendi Kaleminizle Eserinizi Yazın",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Text(
                            text = "Kitabınızın künyesini ve ilk bölümlerini oluşturun. Kaydettikten sonra istediğiniz zaman yeni bölümler ekleyebilir veya mevcut bölümleri düzenleyebilirsiniz.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                }

                // Book Title & Subtitle
                OutlinedTextField(
                    value = title,
                    onValueChange = {
                        title = it
                        errorMessage = null
                    },
                    label = { Text(stringResource(R.string.book_title_label)) },
                    placeholder = { Text("Örn: Gölgeler ve Saatler") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("manual_book_title_input"),
                    shape = RoundedCornerShape(14.dp)
                )

                OutlinedTextField(
                    value = subtitle,
                    onValueChange = { subtitle = it },
                    label = { Text(stringResource(R.string.book_subtitle_label)) },
                    placeholder = { Text("Örn: Bir İstanbul Romanı") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("manual_book_subtitle_input"),
                    shape = RoundedCornerShape(14.dp)
                )

                OutlinedTextField(
                    value = synopsis,
                    onValueChange = { synopsis = it },
                    label = { Text(stringResource(R.string.book_synopsis_label)) },
                    placeholder = { Text("Kitabınızın arka kapak yazısını veya genel özetini buraya yazın…") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                        .testTag("manual_book_synopsis_input"),
                    shape = RoundedCornerShape(14.dp)
                )

                // Genre & Cover Theme Preview
                Text(
                    text = stringResource(R.string.ai_genre_label),
                    style = MaterialTheme.typography.titleMedium
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    LiteraryCatalog.genres.forEach { genre ->
                        FilterChip(
                            selected = selectedGenre == genre,
                            onClick = { selectedGenre = genre },
                            label = { Text(genre) }
                        )
                    }
                }

                // Cover Theme Picker with Live Preview
                Text(
                    text = stringResource(R.string.ai_cover_theme_label),
                    style = MaterialTheme.typography.titleMedium
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    TypographicBookCover(
                        title = title.ifBlank { "Yeni Kitabım" },
                        subtitle = subtitle,
                        genre = selectedGenre,
                        coverTheme = selectedCoverTheme,
                        isAiCreated = false,
                        width = 100.dp,
                        height = 148.dp
                    )

                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        BookCoverTheme.entries.forEach { theme ->
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedCoverTheme = theme.id },
                                shape = RoundedCornerShape(10.dp),
                                color = if (selectedCoverTheme == theme.id) {
                                    MaterialTheme.colorScheme.secondaryContainer
                                } else {
                                    MaterialTheme.colorScheme.surface
                                },
                                border = BorderStroke(
                                    width = if (selectedCoverTheme == theme.id) 1.5.dp else 1.dp,
                                    color = if (selectedCoverTheme == theme.id) {
                                        MaterialTheme.colorScheme.secondary
                                    } else {
                                        MaterialTheme.colorScheme.surfaceVariant
                                    }
                                )
                            ) {
                                Text(
                                    text = "${theme.labelTr} — ${theme.subtitleTr}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }
                }

                // Chapters Section
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Bölümler (${chapterInputs.size} Bölüm • $totalWordCount Kelime)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    OutlinedButton(
                        onClick = {
                            val nextNum = chapterInputs.size + 1
                            chapterInputs.add(
                                EditableChapterInput(
                                    title = "$nextNum. Bölüm",
                                    summary = "",
                                    content = ""
                                )
                            )
                        },
                        modifier = Modifier.testTag("add_manual_chapter_draft_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Bölüm Ekle")
                    }
                }

                chapterInputs.forEachIndexed { index, chapterInput ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${index + 1}. Bölüm (${countWords(chapterInput.content)} kelime)",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )

                                if (chapterInputs.size > 1) {
                                    IconButton(
                                        onClick = { chapterInputs.removeAt(index) }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.DeleteOutline,
                                            contentDescription = "Bölümü Kaldır"
                                        )
                                    }
                                }
                            }

                            OutlinedTextField(
                                value = chapterInput.title,
                                onValueChange = { newTitle ->
                                    chapterInputs[index] = chapterInput.copy(title = newTitle)
                                },
                                label = { Text("Bölüm Başlığı") },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("manual_chapter_title_$index"),
                                shape = RoundedCornerShape(12.dp)
                            )

                            OutlinedTextField(
                                value = chapterInput.content,
                                onValueChange = { newContent ->
                                    chapterInputs[index] = chapterInput.copy(content = newContent)
                                },
                                label = { Text("Bölüm Metni") },
                                placeholder = { Text("Bölüm metnini buraya yazmaya başlayın…") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(190.dp)
                                    .testTag("manual_chapter_content_$index"),
                                shape = RoundedCornerShape(12.dp)
                            )
                        }
                    }
                }

                if (!errorMessage.isNullOrBlank()) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer
                        )
                    ) {
                        Text(
                            text = errorMessage!!,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }

                Button(
                    onClick = {
                        errorMessage = null
                        val drafts = chapterInputs.mapIndexed { idx, input ->
                            AiGeneratedChapterDraft(
                                chapterNumber = idx + 1,
                                title = input.title.ifBlank { "${idx + 1}. Bölüm" },
                                summary = input.summary,
                                content = input.content
                            )
                        }
                        onSaveManualBook(
                            title,
                            subtitle,
                            synopsis,
                            selectedGenre,
                            selectedTone,
                            selectedCoverTheme,
                            drafts
                        ) { err ->
                            errorMessage = err
                        }
                    },
                    enabled = !isSaving,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("manual_save_book_button"),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    if (isSaving) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            color = MaterialTheme.colorScheme.onPrimary,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Save,
                            contentDescription = null
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = stringResource(R.string.save_manual_book_button),
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
