package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.entity.LoanEntity
import com.example.data.entity.LoanRepaymentEntity
import com.example.ui.components.ConfirmDialog
import com.example.ui.components.DatePickerHelper
import com.example.ui.components.Elevated3DCard
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IslamicEmerald
import com.example.ui.theme.IslamicGreenPrimary
import com.example.ui.theme.LoanOrange
import com.example.ui.theme.LoanOrangeLight
import com.example.ui.theme.RepaidPurple
import com.example.ui.theme.RepaidPurpleLight
import com.example.ui.theme.TextPrimary
import com.example.ui.util.BanglaHelper
import com.example.ui.viewmodel.FinanceViewModel
import com.example.ui.viewmodel.LenderSummary

@Composable
fun LoanScreen(
    viewModel: FinanceViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val summary by viewModel.dashboardSummary.collectAsStateWithLifecycle()
    val loans by viewModel.allLoans.collectAsStateWithLifecycle()
    val repayments by viewModel.allRepayments.collectAsStateWithLifecycle()
    val lenderSummaries by viewModel.lenderSummaries.collectAsStateWithLifecycle()

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val tabs = listOf("নতুন ঋণ", "ঋণ পরিশোধ", "ঋণের তালিকা", "ব্যক্তিভিত্তিক হিসাব")

    // Loan Form states
    var lenderNameInput by remember { mutableStateOf("") }
    var loanAmountInput by remember { mutableStateOf("") }
    var loanDescInput by remember { mutableStateOf("") }
    var loanDate by remember { mutableStateOf(BanglaHelper.getTodayIso()) }

    // Repayment Form states
    var repayLenderNameInput by remember { mutableStateOf("") }
    var repayAmountInput by remember { mutableStateOf("") }
    var repayDescInput by remember { mutableStateOf("") }
    var repayDate by remember { mutableStateOf(BanglaHelper.getTodayIso()) }

    // Editing & Deleting
    var editingLoan by remember { mutableStateOf<LoanEntity?>(null) }
    var deleteLoanCandidate by remember { mutableStateOf<LoanEntity?>(null) }
    var deleteRepayCandidate by remember { mutableStateOf<LoanRepaymentEntity?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .imePadding()
    ) {
        // Top Total Outstanding Loan Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Elevated3DCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = LoanOrangeLight,
                borderColor = LoanOrange.copy(alpha = 0.3f),
                elevation = 2f
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "মোট বাকি ঋণ",
                            fontSize = 13.sp,
                            color = LoanOrange,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = BanglaHelper.formatCurrency(summary.remainingLoan),
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = LoanOrange
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "মোট গ্রহণ: ${BanglaHelper.formatCurrency(summary.totalLoan)} • পরিশোধ: ${BanglaHelper.formatCurrency(summary.totalLoanRepaid)}",
                            fontSize = 11.sp,
                            color = Color(0xFF7C2D12)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(LoanOrange),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Handshake,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }

        // Sub-menu Tabs
        ScrollableTabRow(
            selectedTabIndex = selectedTabIndex,
            containerColor = Color.Transparent,
            contentColor = LoanOrange,
            edgePadding = 16.dp,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                    color = LoanOrange,
                    height = 3.dp
                )
            }
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTabIndex == index,
                    onClick = {
                        selectedTabIndex = index
                    },
                    text = {
                        Text(
                            text = title,
                            fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 14.sp
                        )
                    },
                    modifier = Modifier.testTag("loan_tab_$index")
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        when (selectedTabIndex) {
            0 -> {
                // নতুন ঋণ নেওয়ার ফর্ম
                LoanAddForm(
                    lenderName = lenderNameInput,
                    amount = loanAmountInput,
                    date = loanDate,
                    description = loanDescInput,
                    editingLoan = editingLoan,
                    onLenderNameChange = { lenderNameInput = it },
                    onAmountChange = { loanAmountInput = it },
                    onDescriptionChange = { loanDescInput = it },
                    onDateClick = {
                        DatePickerHelper.showDatePicker(context, loanDate) { newDate ->
                            loanDate = newDate
                        }
                    },
                    onSave = {
                        val parsed = BanglaHelper.parseAmount(loanAmountInput)
                        if (parsed == null || parsed <= 0.0) {
                            Toast.makeText(context, "অনুগ্রহ করে সঠিক ঋণের পরিমাণ লিখুন", Toast.LENGTH_SHORT).show()
                            return@LoanAddForm
                        }
                        if (lenderNameInput.trim().isBlank()) {
                            Toast.makeText(context, "ঋণদাতার নাম লিখুন", Toast.LENGTH_SHORT).show()
                            return@LoanAddForm
                        }

                        if (editingLoan != null) {
                            viewModel.updateLoan(
                                editingLoan!!.copy(
                                    lenderName = lenderNameInput.trim(),
                                    amount = parsed,
                                    date = loanDate,
                                    description = loanDescInput.trim()
                                )
                            ) {
                                editingLoan = null
                                lenderNameInput = ""
                                loanAmountInput = ""
                                loanDescInput = ""
                                selectedTabIndex = 2
                            }
                        } else {
                            viewModel.addLoan(
                                lenderName = lenderNameInput.trim(),
                                amount = parsed,
                                date = loanDate,
                                description = loanDescInput.trim()
                            ) {
                                lenderNameInput = ""
                                loanAmountInput = ""
                                loanDescInput = ""
                                selectedTabIndex = 2
                            }
                        }
                    },
                    onCancelEdit = {
                        editingLoan = null
                        lenderNameInput = ""
                        loanAmountInput = ""
                        loanDescInput = ""
                    }
                )
            }
            1 -> {
                // ঋণ পরিশোধ ফর্ম
                LoanRepaymentForm(
                    lenderName = repayLenderNameInput,
                    amount = repayAmountInput,
                    date = repayDate,
                    description = repayDescInput,
                    existingLenders = lenderSummaries.map { it.lenderName },
                    onLenderNameChange = { repayLenderNameInput = it },
                    onAmountChange = { repayAmountInput = it },
                    onDescriptionChange = { repayDescInput = it },
                    onDateClick = {
                        DatePickerHelper.showDatePicker(context, repayDate) { newDate ->
                            repayDate = newDate
                        }
                    },
                    onSave = {
                        val parsed = BanglaHelper.parseAmount(repayAmountInput)
                        if (parsed == null || parsed <= 0.0) {
                            Toast.makeText(context, "অনুগ্রহ করে পরিশোধের সঠিক পরিমাণ লিখুন", Toast.LENGTH_SHORT).show()
                            return@LoanRepaymentForm
                        }
                        if (repayLenderNameInput.trim().isBlank()) {
                            Toast.makeText(context, "কার ঋণ পরিশোধ করা হলো তার নাম লিখুন", Toast.LENGTH_SHORT).show()
                            return@LoanRepaymentForm
                        }

                        viewModel.addRepayment(
                            lenderName = repayLenderNameInput.trim(),
                            amount = parsed,
                            date = repayDate,
                            description = repayDescInput.trim()
                        ) {
                            repayLenderNameInput = ""
                            repayAmountInput = ""
                            repayDescInput = ""
                            selectedTabIndex = 2
                        }
                    }
                )
            }
            2 -> {
                // ঋণের তালিকা (ঋণ গ্রহণ এবং ঋণ পরিশোধের তালিকা)
                LoanHistoryListView(
                    loans = loans,
                    repayments = repayments,
                    onEditLoan = { loan ->
                        editingLoan = loan
                        lenderNameInput = loan.lenderName
                        loanAmountInput = if (loan.amount % 1.0 == 0.0) loan.amount.toLong().toString() else loan.amount.toString()
                        loanDescInput = loan.description
                        loanDate = loan.date
                        selectedTabIndex = 0
                    },
                    onDeleteLoan = { deleteLoanCandidate = it },
                    onDeleteRepayment = { deleteRepayCandidate = it }
                )
            }
            3 -> {
                // ব্যক্তিভিত্তিক ঋণের হিসাব
                LenderBreakdownView(
                    summaries = lenderSummaries,
                    onPayLender = { summaryItem ->
                        repayLenderNameInput = summaryItem.lenderName
                        selectedTabIndex = 1
                    }
                )
            }
        }
    }

    if (deleteLoanCandidate != null) {
        ConfirmDialog(
            title = "ঋণের হিসাব মুছে ফেলবেন?",
            message = "আপনি কি নিশ্চিতভাবে এই ঋণ মুছে ফেলতে চান?\nঋণদাতা: ${deleteLoanCandidate!!.lenderName}\nপরিমাণ: ${BanglaHelper.formatCurrency(deleteLoanCandidate!!.amount)}",
            confirmText = "মুছে ফেলুন",
            dismissText = "বাতিল",
            isDanger = true,
            onConfirm = {
                viewModel.deleteLoan(deleteLoanCandidate!!.id)
                deleteLoanCandidate = null
            },
            onDismiss = {
                deleteLoanCandidate = null
            }
        )
    }

    if (deleteRepayCandidate != null) {
        ConfirmDialog(
            title = "ঋণ পরিশোধ তথ্য মুছে ফেলবেন?",
            message = "আপনি কি নিশ্চিতভাবে এই ঋণ পরিশোধ মুছে ফেলতে চান?\nপ্রাপক: ${deleteRepayCandidate!!.lenderName}\nপরিমাণ: ${BanglaHelper.formatCurrency(deleteRepayCandidate!!.amount)}",
            confirmText = "মুছে ফেলুন",
            dismissText = "বাতিল",
            isDanger = true,
            onConfirm = {
                viewModel.deleteRepayment(deleteRepayCandidate!!.id)
                deleteRepayCandidate = null
            },
            onDismiss = {
                deleteRepayCandidate = null
            }
        )
    }
}

@Composable
fun LoanAddForm(
    lenderName: String,
    amount: String,
    date: String,
    description: String,
    editingLoan: LoanEntity?,
    onLenderNameChange: (String) -> Unit,
    onAmountChange: (String) -> Unit,
    onDescriptionChange: (String) -> Unit,
    onDateClick: () -> Unit,
    onSave: () -> Unit,
    onCancelEdit: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Elevated3DCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("loan_form_card"),
                elevation = 3f
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = if (editingLoan != null) "ঋণ সম্পাদনা করুন" else "নতুন ঋণ গ্রহণ",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )

                    // Lender Name
                    Text(text = "কার কাছ থেকে ঋণ নেওয়া হয়েছে", fontSize = 13.sp, color = Color(0xFF4B5563))
                    OutlinedTextField(
                        value = lenderName,
                        onValueChange = onLenderNameChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("loan_lender_input"),
                        placeholder = { Text("যেমন: হাজী আব্দুর রহমান, ব্যাংক") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = LoanOrange,
                            unfocusedBorderColor = BorderSubtle
                        )
                    )

                    // Amount
                    Text(text = "ঋণের পরিমাণ (টাকা)", fontSize = 13.sp, color = Color(0xFF4B5563))
                    OutlinedTextField(
                        value = amount,
                        onValueChange = onAmountChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("loan_amount_input"),
                        placeholder = { Text("যেমন: ২০০০০ বা 20000") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = LoanOrange,
                            unfocusedBorderColor = BorderSubtle
                        )
                    )

                    // Date Picker
                    Text(text = "তারিখ নির্বাচন", fontSize = 13.sp, color = Color(0xFF4B5563))
                    Elevated3DCard(
                        modifier = Modifier.fillMaxWidth(),
                        elevation = 1f,
                        onClick = onDateClick
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = BanglaHelper.formatBanglaDate(date),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                            Icon(
                                imageVector = Icons.Default.CalendarMonth,
                                contentDescription = "তারিখ বাছুন",
                                tint = LoanOrange
                            )
                        }
                    }

                    // Description
                    Text(text = "ঋণের বিবরণ", fontSize = 13.sp, color = Color(0xFF4B5563))
                    OutlinedTextField(
                        value = description,
                        onValueChange = onDescriptionChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("loan_desc_input"),
                        placeholder = { Text("যেমন: জমি চাষের জন্য, জরুরি পারিবারিক ঋণ") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = LoanOrange,
                            unfocusedBorderColor = BorderSubtle
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (editingLoan != null) {
                            Button(
                                onClick = onCancelEdit,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9E9E9E)),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("বাতিল", color = Color.White)
                            }
                        }

                        Button(
                            onClick = onSave,
                            colors = ButtonDefaults.buttonColors(containerColor = LoanOrange),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("loan_save_button")
                        ) {
                            Text(if (editingLoan != null) "আপডেট করুন" else "সংরক্ষণ করুন", color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LoanRepaymentForm(
    lenderName: String,
    amount: String,
    date: String,
    description: String,
    existingLenders: List<String>,
    onLenderNameChange: (String) -> Unit,
    onAmountChange: (String) -> Unit,
    onDescriptionChange: (String) -> Unit,
    onDateClick: () -> Unit,
    onSave: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Elevated3DCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("repay_form_card"),
                elevation = 3f
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "ঋণ পরিশোধ করুন",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )

                    // Lender Name
                    Text(text = "কার ঋণ পরিশোধ করা হলো", fontSize = 13.sp, color = Color(0xFF4B5563))
                    OutlinedTextField(
                        value = lenderName,
                        onValueChange = onLenderNameChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("repay_lender_input"),
                        placeholder = { Text("ঋণদাতার নাম লিখুন") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = RepaidPurple,
                            unfocusedBorderColor = BorderSubtle
                        )
                    )

                    // Amount
                    Text(text = "পরিশোধের পরিমাণ (টাকা)", fontSize = 13.sp, color = Color(0xFF4B5563))
                    OutlinedTextField(
                        value = amount,
                        onValueChange = onAmountChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("repay_amount_input"),
                        placeholder = { Text("যেমন: ৫০০০ বা 5000") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = RepaidPurple,
                            unfocusedBorderColor = BorderSubtle
                        )
                    )

                    // Date Picker
                    Text(text = "তারিখ নির্বাচন", fontSize = 13.sp, color = Color(0xFF4B5563))
                    Elevated3DCard(
                        modifier = Modifier.fillMaxWidth(),
                        elevation = 1f,
                        onClick = onDateClick
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = BanglaHelper.formatBanglaDate(date),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                            Icon(
                                imageVector = Icons.Default.CalendarMonth,
                                contentDescription = "তারিখ বাছুন",
                                tint = RepaidPurple
                            )
                        }
                    }

                    // Description
                    Text(text = "বিবরণ", fontSize = 13.sp, color = Color(0xFF4B5563))
                    OutlinedTextField(
                        value = description,
                        onValueChange = onDescriptionChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("repay_desc_input"),
                        placeholder = { Text("যেমন: প্রথম কিস্তি পরিশোধ, নগদ পরিশোধ") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = RepaidPurple,
                            unfocusedBorderColor = BorderSubtle
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = onSave,
                        colors = ButtonDefaults.buttonColors(containerColor = RepaidPurple),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("repay_save_button")
                    ) {
                        Text("পরিশোধ নিশ্চিত করুন", color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun LoanHistoryListView(
    loans: List<LoanEntity>,
    repayments: List<LoanRepaymentEntity>,
    onEditLoan: (LoanEntity) -> Unit,
    onDeleteLoan: (LoanEntity) -> Unit,
    onDeleteRepayment: (LoanRepaymentEntity) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Taken Loans Section
        item {
            Text(
                text = "গৃহীত ঋণের তালিকা (${BanglaHelper.toBanglaDigits(loans.size)})",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        if (loans.isEmpty()) {
            item {
                Elevated3DCard(modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "কোনো ঋণ গ্রহণের হিসাব নেই", color = Color(0xFF6B7280))
                    }
                }
            }
        } else {
            items(loans, key = { "loan_${it.id}" }) { loan ->
                Elevated3DCard(
                    modifier = Modifier.fillMaxWidth(),
                    elevation = 2f
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = loan.lenderName,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            if (loan.description.isNotBlank()) {
                                Text(
                                    text = loan.description,
                                    fontSize = 12.sp,
                                    color = Color(0xFF4B5563)
                                )
                            }
                            Text(
                                text = BanglaHelper.formatBanglaDate(loan.date),
                                fontSize = 11.sp,
                                color = Color(0xFF6B7280)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "ঋণ: " + BanglaHelper.formatCurrency(loan.amount),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = LoanOrange
                            )
                        }

                        Row {
                            IconButton(onClick = { onEditLoan(loan) }, modifier = Modifier.size(36.dp)) {
                                Icon(Icons.Default.Edit, contentDescription = "সম্পাদনা", tint = IslamicGreenPrimary, modifier = Modifier.size(20.dp))
                            }
                            IconButton(onClick = { onDeleteLoan(loan) }, modifier = Modifier.size(36.dp)) {
                                Icon(Icons.Default.Delete, contentDescription = "মুছুন", tint = ExpenseRed, modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                }
            }
        }

        // Repaid Loans Section
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "ঋণ পরিশোধের তালিকা (${BanglaHelper.toBanglaDigits(repayments.size)})",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        if (repayments.isEmpty()) {
            item {
                Elevated3DCard(modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "এখনো কোনো ঋণ পরিশোধ করা হয়নি", color = Color(0xFF6B7280))
                    }
                }
            }
        } else {
            items(repayments, key = { "rep_${it.id}" }) { rep ->
                Elevated3DCard(
                    modifier = Modifier.fillMaxWidth(),
                    elevation = 2f
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "প্রাপক: ${rep.lenderName}",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            if (rep.description.isNotBlank()) {
                                Text(
                                    text = rep.description,
                                    fontSize = 12.sp,
                                    color = Color(0xFF4B5563)
                                )
                            }
                            Text(
                                text = BanglaHelper.formatBanglaDate(rep.date),
                                fontSize = 11.sp,
                                color = Color(0xFF6B7280)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "পরিশোধ: " + BanglaHelper.formatCurrency(rep.amount),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = RepaidPurple
                            )
                        }

                        IconButton(onClick = { onDeleteRepayment(rep) }, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Default.Delete, contentDescription = "মুছুন", tint = ExpenseRed, modifier = Modifier.size(20.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LenderBreakdownView(
    summaries: List<LenderSummary>,
    onPayLender: (LenderSummary) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (summaries.isEmpty()) {
            item {
                Elevated3DCard(modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("কোনো ব্যক্তিভিত্তিক ঋণের হিসাব পাওয়া যায়নি", color = Color(0xFF6B7280))
                    }
                }
            }
        } else {
            items(summaries) { item ->
                Elevated3DCard(
                    modifier = Modifier.fillMaxWidth(),
                    elevation = 3f
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = item.lenderName,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )

                            if (item.remainingLoan > 0) {
                                Button(
                                    onClick = { onPayLender(item) },
                                    colors = ButtonDefaults.buttonColors(containerColor = RepaidPurple),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Text("পরিশোধ", fontSize = 12.sp, color = Color.White)
                                }
                            } else {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color(0xFFDCFCE7)
                                ) {
                                    Text(
                                        text = "পরিশোধিত",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF15803D),
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(text = "মোট ঋণ", fontSize = 11.sp, color = Color(0xFF6B7280))
                                Text(
                                    text = BanglaHelper.formatCurrency(item.totalLoan),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = LoanOrange
                                )
                            }
                            Column {
                                Text(text = "পরিশোধ হয়েছে", fontSize = 11.sp, color = Color(0xFF6B7280))
                                Text(
                                    text = BanglaHelper.formatCurrency(item.totalRepaid),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = RepaidPurple
                                )
                            }
                            Column {
                                Text(text = "এখন বাকি আছে", fontSize = 11.sp, color = Color(0xFF6B7280))
                                Text(
                                    text = BanglaHelper.formatCurrency(item.remainingLoan),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (item.remainingLoan > 0) ExpenseRed else Color(0xFF15803D)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
