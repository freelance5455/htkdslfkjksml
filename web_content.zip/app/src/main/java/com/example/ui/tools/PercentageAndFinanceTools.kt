package com.example.ui.tools

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.engine.FormattingOptions
import com.example.engine.NumberFormatter
import com.example.tools.CompoundingFrequency
import com.example.tools.ToolId
import com.example.tools.ToolsEngine
import com.example.ui.components.AetherCard
import com.example.ui.components.AetherFilterChip
import com.example.ui.components.AetherNumberField
import com.example.ui.components.AetherResultRow
import com.example.ui.theme.AetherTheme

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PercentageAndFinanceToolView(
  toolId: ToolId,
  formatting: FormattingOptions,
  hapticsEnabled: Boolean,
  onCopy: (String) -> Unit,
) {
  val colors = AetherTheme.colors

  when (toolId) {
    ToolId.PERCENT_OF -> {
      var pct by remember { mutableStateOf("15") }
      var num by remember { mutableStateOf("200") }
      val result =
        remember(pct, num) {
          val p = pct.toDoubleOrNull()
          val n = num.toDoubleOrNull()
          if (p != null && n != null) ToolsEngine.percentOf(p, n) else null
        }

      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        AetherNumberField(pct, { pct = it }, "Percentage (%)", allowNegative = true)
        AetherNumberField(num, { num = it }, "Of number", allowNegative = true)
        AetherCard(backgroundColor = colors.surfaceElevated) {
          val formatted = result?.let { NumberFormatter.formatDouble(it, formatting) } ?: "—"
          AetherResultRow("Result", formatted, onCopy = result?.let { { onCopy(formatted) } }, highlight = true)
        }
      }
    }

    ToolId.PERCENT_INCREASE -> {
      var modeByValue by remember { mutableStateOf(true) } // true: base + %, false: from -> to
      var first by remember { mutableStateOf("100") }
      var second by remember { mutableStateOf("15") }

      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          AetherFilterChip("Add X%", modeByValue, { modeByValue = true }, hapticsEnabled = hapticsEnabled)
          AetherFilterChip("From → To", !modeByValue, { modeByValue = false }, hapticsEnabled = hapticsEnabled)
        }
        AetherNumberField(first, { first = it }, if (modeByValue) "Base value" else "Original value", allowNegative = true)
        AetherNumberField(second, { second = it }, if (modeByValue) "Increase (%)" else "New value", allowNegative = true)

        AetherCard(backgroundColor = colors.surfaceElevated) {
          val a = first.toDoubleOrNull()
          val b = second.toDoubleOrNull()
          if (a != null && b != null) {
            if (modeByValue) {
              val (finalVal, delta) = ToolsEngine.increaseByPercent(a, b)
              val fFinal = NumberFormatter.formatDouble(finalVal, formatting)
              val fDelta = NumberFormatter.formatDouble(delta, formatting)
              AetherResultRow("New value", fFinal, onCopy = { onCopy(fFinal) }, highlight = true)
              HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = colors.borderSubtle)
              AetherResultRow("Increase amount", "+$fDelta")
            } else {
              val change = ToolsEngine.percentChange(a, b)
              if (change != null) {
                val fPct = NumberFormatter.formatDouble(change.first, formatting) + "%"
                val fDelta = NumberFormatter.formatDouble(change.second, formatting)
                AetherResultRow("Percentage change", fPct, onCopy = { onCopy(fPct) }, highlight = true)
                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = colors.borderSubtle)
                AetherResultRow("Difference", fDelta)
              } else {
                Text("Original value cannot be zero.", color = colors.error, style = MaterialTheme.typography.bodyMedium)
              }
            }
          } else {
            AetherResultRow("Result", "—", highlight = true)
          }
        }
      }
    }

    ToolId.PERCENT_DECREASE -> {
      var modeByValue by remember { mutableStateOf(true) }
      var first by remember { mutableStateOf("100") }
      var second by remember { mutableStateOf("15") }

      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          AetherFilterChip("Subtract X%", modeByValue, { modeByValue = true }, hapticsEnabled = hapticsEnabled)
          AetherFilterChip("From → To", !modeByValue, { modeByValue = false }, hapticsEnabled = hapticsEnabled)
        }
        AetherNumberField(first, { first = it }, if (modeByValue) "Base value" else "Original value", allowNegative = true)
        AetherNumberField(second, { second = it }, if (modeByValue) "Decrease (%)" else "New value", allowNegative = true)

        AetherCard(backgroundColor = colors.surfaceElevated) {
          val a = first.toDoubleOrNull()
          val b = second.toDoubleOrNull()
          if (a != null && b != null) {
            if (modeByValue) {
              val (finalVal, delta) = ToolsEngine.decreaseByPercent(a, b)
              val fFinal = NumberFormatter.formatDouble(finalVal, formatting)
              val fDelta = NumberFormatter.formatDouble(delta, formatting)
              AetherResultRow("New value", fFinal, onCopy = { onCopy(fFinal) }, highlight = true)
              HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = colors.borderSubtle)
              AetherResultRow("Decrease amount", "−$fDelta")
            } else {
              val change = ToolsEngine.percentChange(a, b)
              if (change != null) {
                val dropPct = -change.first
                val fPct = NumberFormatter.formatDouble(dropPct, formatting) + "%"
                val fDelta = NumberFormatter.formatDouble(a - b, formatting)
                AetherResultRow("Percentage decrease", fPct, onCopy = { onCopy(fPct) }, highlight = true)
                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = colors.borderSubtle)
                AetherResultRow("Decrease amount", fDelta)
              } else {
                Text("Original value cannot be zero.", color = colors.error, style = MaterialTheme.typography.bodyMedium)
              }
            }
          } else {
            AetherResultRow("Result", "—", highlight = true)
          }
        }
      }
    }

    ToolId.PERCENT_DIFFERENCE -> {
      var valA by remember { mutableStateOf("80") }
      var valB by remember { mutableStateOf("100") }
      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        AetherNumberField(valA, { valA = it }, "Value A", allowNegative = true)
        AetherNumberField(valB, { valB = it }, "Value B", allowNegative = true)
        AetherCard(backgroundColor = colors.surfaceElevated) {
          val a = valA.toDoubleOrNull()
          val b = valB.toDoubleOrNull()
          if (a != null && b != null) {
            val diff = ToolsEngine.percentDifference(a, b)
            val fDiff = NumberFormatter.formatDouble(diff, formatting) + "%"
            AetherResultRow("Percentage difference", fDiff, onCopy = { onCopy(fDiff) }, highlight = true)
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = colors.borderSubtle)
            AetherResultRow("Absolute difference", NumberFormatter.formatDouble(kotlin.math.abs(a - b), formatting))
          } else {
            AetherResultRow("Percentage difference", "—", highlight = true)
          }
        }
      }
    }

    ToolId.SIMPLE_INTEREST -> {
      var principal by remember { mutableStateOf("10000") }
      var rate by remember { mutableStateOf("6.5") }
      var years by remember { mutableStateOf("3") }
      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        AetherNumberField(principal, { principal = it }, "Principal amount")
        AetherNumberField(rate, { rate = it }, "Annual interest rate (%)")
        AetherNumberField(years, { years = it }, "Time period (years)")
        AetherCard(backgroundColor = colors.surfaceElevated) {
          val p = principal.toDoubleOrNull()
          val r = rate.toDoubleOrNull()
          val t = years.toDoubleOrNull()
          if (p != null && r != null && t != null) {
            val (interest, total) = ToolsEngine.simpleInterest(p, r, t)
            val fInt = NumberFormatter.formatDouble(interest, formatting)
            val fTot = NumberFormatter.formatDouble(total, formatting)
            AetherResultRow("Total amount", fTot, onCopy = { onCopy(fTot) }, highlight = true)
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = colors.borderSubtle)
            AetherResultRow("Total interest", fInt, onCopy = { onCopy(fInt) })
          } else {
            AetherResultRow("Total amount", "—", highlight = true)
          }
        }
      }
    }

    ToolId.COMPOUND_INTEREST -> {
      var principal by remember { mutableStateOf("10000") }
      var rate by remember { mutableStateOf("8") }
      var years by remember { mutableStateOf("5") }
      var freq by remember { mutableStateOf(CompoundingFrequency.MONTHLY) }

      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        AetherNumberField(principal, { principal = it }, "Principal amount")
        AetherNumberField(rate, { rate = it }, "Annual interest rate (%)")
        AetherNumberField(years, { years = it }, "Time period (years)")
        Text("Compounding frequency", style = MaterialTheme.typography.labelMedium, color = colors.textSecondary)
        FlowRow(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          CompoundingFrequency.entries.forEach { item ->
            AetherFilterChip(item.label, freq == item, { freq = item }, hapticsEnabled = hapticsEnabled)
          }
        }
        Spacer(modifier = Modifier.height(2.dp))
        AetherCard(backgroundColor = colors.surfaceElevated) {
          val p = principal.toDoubleOrNull()
          val r = rate.toDoubleOrNull()
          val t = years.toDoubleOrNull()
          if (p != null && r != null && t != null) {
            val (interest, total) = ToolsEngine.compoundInterest(p, r, t, freq)
            val fInt = NumberFormatter.formatDouble(interest, formatting)
            val fTot = NumberFormatter.formatDouble(total, formatting)
            AetherResultRow("Maturity value", fTot, onCopy = { onCopy(fTot) }, highlight = true)
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = colors.borderSubtle)
            AetherResultRow("Compound interest", fInt, onCopy = { onCopy(fInt) })
          } else {
            AetherResultRow("Maturity value", "—", highlight = true)
          }
        }
      }
    }

    ToolId.EMI_CALCULATOR -> {
      var loan by remember { mutableStateOf("250000") }
      var rate by remember { mutableStateOf("8.5") }
      var tenure by remember { mutableStateOf("60") }
      var inYears by remember { mutableStateOf(false) }

      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        AetherNumberField(loan, { loan = it }, "Loan amount")
        AetherNumberField(rate, { rate = it }, "Annual interest rate (%)")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          AetherFilterChip("Months", !inYears, { inYears = false }, hapticsEnabled = hapticsEnabled)
          AetherFilterChip("Years", inYears, { inYears = true }, hapticsEnabled = hapticsEnabled)
        }
        AetherNumberField(tenure, { tenure = it }, if (inYears) "Tenure (years)" else "Tenure (months)")
        AetherCard(backgroundColor = colors.surfaceElevated) {
          val p = loan.toDoubleOrNull()
          val r = rate.toDoubleOrNull()
          val tVal = tenure.toDoubleOrNull()
          val months = if (tVal != null) if (inYears) (tVal * 12).toInt() else tVal.toInt() else 0
          val res = if (p != null && r != null && months > 0) ToolsEngine.calculateEmi(p, r, months) else null
          if (res != null) {
            val fEmi = NumberFormatter.formatDouble(res.first, formatting)
            val fInt = NumberFormatter.formatDouble(res.second, formatting)
            val fTot = NumberFormatter.formatDouble(res.third, formatting)
            AetherResultRow("Monthly EMI", fEmi, onCopy = { onCopy(fEmi) }, highlight = true)
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = colors.borderSubtle)
            AetherResultRow("Total interest", fInt, onCopy = { onCopy(fInt) })
            Spacer(modifier = Modifier.height(6.dp))
            AetherResultRow("Total payment", fTot, onCopy = { onCopy(fTot) })
          } else {
            AetherResultRow("Monthly EMI", "—", highlight = true)
          }
        }
      }
    }

    else -> Unit
  }
}
