package com.example.ui.screens.map

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.LocalAirport
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Airport
import com.example.data.repository.AirportRepository
import com.example.ui.components.FlightCategoryBadge
import com.example.ui.components.OperationalDisclaimerCard
import com.example.ui.navigation.Screen
import com.example.ui.theme.*
import com.example.ui.viewmodel.WeatherViewModel
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun WeatherMapScreen(
  viewModel: WeatherViewModel,
  onNavigateTo: (Screen) -> Unit,
  modifier: Modifier = Modifier
) {
  val selectedAirport by viewModel.selectedAirport.collectAsState()
  val sigmetsState by viewModel.sigmetsState.collectAsState()

  var selectedRegion by remember { mutableStateOf("IRAN") } // IRAN, MIDEAST, WORLD
  var showAirportsLayer by remember { mutableStateOf(true) }
  var showSigmetsLayer by remember { mutableStateOf(true) }
  var showWindLayer by remember { mutableStateOf(true) }

  var clickedAirport by remember { mutableStateOf<Airport?>(selectedAirport) }

  // Geographic bounds based on region
  val (minLat, maxLat, minLon, maxLon) = when (selectedRegion) {
    "IRAN" -> Quad(24.0, 40.0, 44.0, 64.0)
    "MIDEAST" -> Quad(12.0, 42.0, 32.0, 68.0)
    else -> Quad(0.0, 60.0, -10.0, 110.0)
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(16.dp)
      .testTag("weather_map_screen"),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // Header & Region Switcher
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column {
        Text(
          text = "نقشه عملیاتی هواشناسی هوانوردی",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "نمایش فرودگاه‌ها، رده‌های پروازی، و پهنه‌های فعال سیگمت",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        FilterChip(
          selected = selectedRegion == "IRAN",
          onClick = { selectedRegion = "IRAN" },
          label = { Text("ایران") },
          modifier = Modifier.testTag("filter_iran")
        )
        FilterChip(
          selected = selectedRegion == "MIDEAST",
          onClick = { selectedRegion = "MIDEAST" },
          label = { Text("خاورمیانه") }
        )
      }
    }

    // Layer Toggles
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      AssistChip(
        onClick = { showAirportsLayer = !showAirportsLayer },
        label = { Text("فرودگاه‌ها") },
        leadingIcon = { Icon(Icons.Default.LocalAirport, contentDescription = null, tint = if (showAirportsLayer) MaterialTheme.colorScheme.primary else Color.Gray) }
      )
      AssistChip(
        onClick = { showSigmetsLayer = !showSigmetsLayer },
        label = { Text("پهنه‌های SIGMET") },
        leadingIcon = { Icon(Icons.Default.Warning, contentDescription = null, tint = if (showSigmetsLayer) StatusYellow else Color.Gray) }
      )
      AssistChip(
        onClick = { showWindLayer = !showWindLayer },
        label = { Text("جریان باد") },
        leadingIcon = { Icon(Icons.Default.Air, contentDescription = null, tint = if (showWindLayer) AtcAeroBlueDark else Color.Gray) }
      )
    }

    // Interactive Map Canvas Card
    Card(
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = Color(0xFF0A131F)),
      border = CardDefaults.outlinedCardBorder(),
      modifier = Modifier
        .fillMaxWidth()
        .weight(1f)
        .testTag("aviation_map_canvas_container")
    ) {
      Box(modifier = Modifier.fillMaxSize()) {
        val airportsToDraw = remember(selectedRegion) {
          AirportRepository.INITIAL_AIRPORTS.filter {
            it.latitude in minLat..maxLat && it.longitude in minLon..maxLon
          }
        }

        Canvas(
          modifier = Modifier
            .fillMaxSize()
            .pointerInput(selectedRegion) {
              detectTapGestures { tapOffset ->
                // Find closest airport to tap
                val w = size.width
                val h = size.height
                val hit = airportsToDraw.minByOrNull { apt ->
                  val x = ((apt.longitude - minLon) / (maxLon - minLon)).toFloat() * w
                  val y = ((maxLat - apt.latitude) / (maxLat - minLat)).toFloat() * h
                  val dx = x - tapOffset.x
                  val dy = y - tapOffset.y
                  dx * dx + dy * dy
                }
                if (hit != null) {
                  clickedAirport = hit
                  viewModel.selectAirport(hit)
                }
              }
            }
        ) {
          val canvasW = size.width
          val canvasH = size.height

          // Draw FIR grid lines
          for (lat in minLat.toInt()..maxLat.toInt() step 5) {
            val y = ((maxLat - lat) / (maxLat - minLat)).toFloat() * canvasH
            drawLine(
              color = Color(0xFF1E2D42),
              start = Offset(0f, y),
              end = Offset(canvasW, y),
              strokeWidth = 1.dp.toPx()
            )
          }
          for (lon in minLon.toInt()..maxLon.toInt() step 5) {
            val x = ((lon - minLon) / (maxLon - minLon)).toFloat() * canvasW
            drawLine(
              color = Color(0xFF1E2D42),
              start = Offset(x, 0f),
              end = Offset(x, canvasH),
              strokeWidth = 1.dp.toPx()
            )
          }

          // Draw simulated active SIGMET area polygon over Persian Gulf / Zagros if active
          if (showSigmetsLayer) {
            val sigmetPath = Path().apply {
              val p1X = ((50.0 - minLon) / (maxLon - minLon)).toFloat() * canvasW
              val p1Y = ((maxLat - 28.0) / (maxLat - minLat)).toFloat() * canvasH
              val p2X = ((54.0 - minLon) / (maxLon - minLon)).toFloat() * canvasW
              val p2Y = ((maxLat - 26.0) / (maxLat - minLat)).toFloat() * canvasH
              val p3X = ((52.0 - minLon) / (maxLon - minLon)).toFloat() * canvasW
              val p3Y = ((maxLat - 24.5) / (maxLat - minLat)).toFloat() * canvasH
              moveTo(p1X, p1Y)
              lineTo(p2X, p2Y)
              lineTo(p3X, p3Y)
              close()
            }
            drawPath(
              path = sigmetPath,
              color = StatusYellow.copy(alpha = 0.2f)
            )
          }

          // Draw Airports
          if (showAirportsLayer) {
            airportsToDraw.forEach { apt ->
              val x = ((apt.longitude - minLon) / (maxLon - minLon)).toFloat() * canvasW
              val y = ((maxLat - apt.latitude) / (maxLat - minLat)).toFloat() * canvasH

              val isSelected = apt.icao == selectedAirport.icao
              val pinColor = if (isSelected) AtcAeroBlueDark else CategoryVfr

              // Circle pin
              drawCircle(
                color = pinColor,
                radius = if (isSelected) 8.dp.toPx() else 5.dp.toPx(),
                center = Offset(x, y)
              )
              if (isSelected) {
                drawCircle(
                  color = Color.White,
                  radius = 3.dp.toPx(),
                  center = Offset(x, y)
                )
              }
            }
          }
        }

        // Overlay Map Legend
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = Color(0xCC0E1A29),
          modifier = Modifier.align(Alignment.BottomStart).padding(10.dp)
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            LegendItem(color = CategoryVfr, text = "VFR")
            LegendItem(color = CategoryMvfr, text = "MVFR")
            LegendItem(color = CategoryIfr, text = "IFR")
            LegendItem(color = StatusYellow, text = "SIGMET")
          }
        }
      }
    }

    // Selected Airport Bottom Bar
    val apt = clickedAirport ?: selectedAirport
    Card(
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
      border = CardDefaults.outlinedCardBorder(),
      modifier = Modifier.fillMaxWidth().testTag("map_airport_details")
    ) {
      Row(
        modifier = Modifier.padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "${apt.icao} / ${apt.iata} • ${apt.nameFa}",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "${apt.cityFa} • ارتفاع ${apt.elevationFt} FT • منطقه ${apt.fir}",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Button(onClick = { onNavigateTo(Screen.AIRPORT_WEATHER) }) {
          Text("مشاهده اطلاعات")
        }
      }
    }

    OperationalDisclaimerCard()
  }
}

private data class Quad(val first: Double, val second: Double, val third: Double, val fourth: Double)

@Composable
private fun LegendItem(color: Color, text: String) {
  Row(verticalAlignment = Alignment.CenterVertically) {
    Box(
      modifier = Modifier
        .size(8.dp)
        .background(color, androidx.compose.foundation.shape.CircleShape)
    )
    Spacer(modifier = Modifier.width(4.dp))
    Text(text = text, style = MaterialTheme.typography.labelSmall, color = Color.White)
  }
}
