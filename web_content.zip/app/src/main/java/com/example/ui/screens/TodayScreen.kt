package com.example.ui.screens

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessAlarm
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.Bathtub
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.Wc
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.CareLogEntity
import com.example.data.local.ReminderScheduleEntity
import com.example.data.model.CareCategory
import com.example.data.model.HavenAward
import com.example.data.model.UserProfile
import com.example.localization.LocalizedStrings
import com.example.ui.components.AwardsShowcaseCard
import com.example.ui.components.DataModeToggleChip
import com.example.ui.components.LanguageBadgeChip
import com.example.ui.components.ProfileAvatarImage
import java.util.Calendar
import java.util.Locale
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TodayScreen(
    profile: UserProfile,
    strings: LocalizedStrings,
    todayLogs: List<CareLogEntity>,
    reminders: List<ReminderScheduleEntity>,
    awards: List<HavenAward>,
    onToggleDataFree: (Boolean) -> Unit,
    onCycleLanguage: () -> Unit,
    onExecuteCommand: (String) -> Unit,
    onToggleSleepQuietMode: (Boolean) -> Unit,
    onLogCare: (CareCategory) -> Unit,
    onUpdateReminder: (CareCategory, Int, Int, Boolean) -> Unit,
    onTestNotification: (CareCategory) -> Unit,
    onSetWakeAlarm: () -> Unit,
    onOpenProfile: () -> Unit
) {
    val context = LocalContext.current
    var commandText by remember { mutableStateOf("") }
    var editingReminderCategory by remember { mutableStateOf<CareCategory?>(null) }

    val notificationPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> }

    val voiceCommandLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                commandText = spoken
                onExecuteCommand(spoken)
            }
        }
    }

    val hourNow = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    val greeting = when {
        hourNow < 12 -> strings.greetingMorning
        hourNow < 18 -> strings.greetingAfternoon
        else -> strings.greetingEvening
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Hero Header
        item {
            Card(
                shape = RoundedCornerShape(26.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column {
                    Box(modifier = Modifier.fillMaxWidth().height(132.dp)) {
                        Image(
                            painter = painterResource(id = R.drawable.img_daily_haven),
                            contentDescription = "Morning wellness illustration",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp))
                        )
                    }
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                ProfileAvatarImage(
                                    photoPath = profile.profilePhotoPath,
                                    displayName = profile.name.ifBlank { "Friend" },
                                    size = 52.dp
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "$greeting, ${profile.name.ifBlank { "Friend" }}",
                                        style = MaterialTheme.typography.headlineSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    val studentPart = if (profile.isStudent) " • ${profile.gradeLevel}" else ""
                                    val locPart = if (profile.locationText.isNotBlank()) " • ${profile.locationText}" else ""
                                    Text(
                                        text = "Age ${profile.age} • ${profile.gender.label}$studentPart$locPart",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                                LanguageBadgeChip(language = profile.language, onClick = onCycleLanguage)
                                IconButton(
                                    onClick = onOpenProfile,
                                    modifier = Modifier.testTag("open_profile_button")
                                ) {
                                    Icon(Icons.Filled.Person, contentDescription = strings.navProfile)
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        DataModeToggleChip(
                            isDataFreeMode = profile.isDataFreeMode,
                            dataLabel = strings.dataModeLabel,
                            dataFreeLabel = strings.dataFreeModeLabel,
                            onToggle = onToggleDataFree
                        )
                    }
                }
            }
        }

        // Phone Control on Command
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Control Phone on Command",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    OutlinedTextField(
                        value = commandText,
                        onValueChange = { commandText = it },
                        placeholder = { Text(strings.commandHint) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("phone_command_input"),
                        trailingIcon = {
                            Row {
                                IconButton(
                                    onClick = {
                                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                                            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak a phone command...")
                                        }
                                        try {
                                            voiceCommandLauncher.launch(intent)
                                        } catch (_: Exception) {
                                            onExecuteCommand("help")
                                        }
                                    },
                                    modifier = Modifier.testTag("voice_command_button")
                                ) {
                                    Icon(Icons.Filled.Mic, contentDescription = "Voice phone command")
                                }
                                IconButton(
                                    onClick = {
                                        onExecuteCommand(commandText)
                                        commandText = ""
                                    },
                                    modifier = Modifier.testTag("send_command_button")
                                ) {
                                    Icon(Icons.Filled.Send, contentDescription = "Run command")
                                }
                            }
                        }
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf("Sleep mode", "Alarm 6:30", "Volume down", "Fresh air timer", "Call ${profile.emergencyAuthorityNumber}").forEach { quick ->
                            AssistChip(
                                onClick = { onExecuteCommand(quick) },
                                label = { Text(quick, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }
                }
            }
        }

        // Sleep Quiet Mode ("when sleeping turn other apps down")
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (profile.sleepQuietModeActive) Icons.Filled.NotificationsOff else Icons.Filled.Bedtime,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = strings.sleepQuietTitle,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                                Text(
                                    text = strings.sleepQuietSubtitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            }
                        }
                        Switch(
                            checked = profile.sleepQuietModeActive,
                            onCheckedChange = onToggleSleepQuietMode,
                            modifier = Modifier.testTag("sleep_quiet_switch")
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(
                            onClick = onSetWakeAlarm,
                            modifier = Modifier.testTag("set_wake_alarm_button")
                        ) {
                            Icon(Icons.Filled.AccessAlarm, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Set Wake Alarm")
                        }
                    }
                }
            }
        }

        // Daily Care Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = strings.dailyCareTitle,
                    style = MaterialTheme.typography.titleLarge
                )
                TextButton(
                    onClick = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            notificationPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    }
                ) {
                    Icon(Icons.Filled.NotificationsActive, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Allow Alerts")
                }
            }
        }

        // All 9 Daily Care Categories
        items(CareCategory.entries, key = { it.key }) { category ->
            val loggedCount = todayLogs.filter { it.categoryKey == category.key }.sumOf { it.countAdded }
            val schedule = reminders.firstOrNull { it.categoryKey == category.key }
            val progress = (loggedCount.toFloat() / category.dailyTarget.toFloat()).coerceIn(0f, 1f)
            val label = strings.careLabels[category] ?: category.name

            Card(
                modifier = Modifier.fillMaxWidth().testTag("care_card_${category.key}"),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(
                                imageVector = categoryIcon(category),
                                contentDescription = label,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(label, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    text = "$loggedCount / ${category.dailyTarget} ${category.unit} today",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            AssistChip(
                                onClick = { editingReminderCategory = category },
                                label = {
                                    val h = schedule?.hour ?: category.defaultHour
                                    val m = schedule?.minute ?: category.defaultMinute
                                    val on = schedule?.enabled ?: true
                                    Text(if (on) "%02d:%02d".format(h, m) else "Off")
                                }
                            )
                            IconButton(
                                onClick = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                        notificationPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                    }
                                    onTestNotification(category)
                                }
                            ) {
                                Icon(Icons.Filled.NotificationsActive, contentDescription = "Send $label reminder now")
                            }
                            FilledTonalButton(
                                onClick = { onLogCare(category) },
                                modifier = Modifier.testTag("log_care_${category.key}")
                            ) {
                                Icon(
                                    imageVector = if (loggedCount >= category.dailyTarget) Icons.Filled.CheckCircle else Icons.Filled.Add,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Log")
                            }
                        }
                    }
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))
                    )
                }
            }
        }

        // Awards & Achievements
        item {
            AwardsShowcaseCard(awards = awards)
        }
    }

    editingReminderCategory?.let { cat ->
        val existing = reminders.firstOrNull { it.categoryKey == cat.key }
        var hour by remember(cat) { mutableFloatStateOf((existing?.hour ?: cat.defaultHour).toFloat()) }
        var minute by remember(cat) { mutableFloatStateOf((existing?.minute ?: cat.defaultMinute).toFloat()) }
        var enabled by remember(cat) { mutableStateOf(existing?.enabled ?: true) }

        AlertDialog(
            onDismissRequest = { editingReminderCategory = null },
            title = { Text("Reminder: ${strings.careLabels[cat] ?: cat.name}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Daily Alert Enabled")
                        Switch(checked = enabled, onCheckedChange = { enabled = it })
                    }
                    Text("Time: %02d:%02d".format(hour.roundToInt(), minute.roundToInt()), style = MaterialTheme.typography.titleMedium)
                    Text("Hour", style = MaterialTheme.typography.labelMedium)
                    Slider(value = hour, onValueChange = { hour = it }, valueRange = 0f..23f)
                    Text("Minute", style = MaterialTheme.typography.labelMedium)
                    Slider(value = minute, onValueChange = { minute = it }, valueRange = 0f..55f, steps = 10)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onUpdateReminder(cat, hour.roundToInt(), minute.roundToInt(), enabled)
                        editingReminderCategory = null
                    }
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { editingReminderCategory = null }) { Text("Cancel") }
            }
        )
    }
}

private fun categoryIcon(category: CareCategory): ImageVector = when (category) {
    CareCategory.WAKE_UP -> Icons.Filled.WbSunny
    CareCategory.DRINK_WATER -> Icons.Filled.WaterDrop
    CareCategory.EAT_MEAL -> Icons.Filled.Restaurant
    CareCategory.PEE -> Icons.Filled.Wc
    CareCategory.POOP -> Icons.Filled.Spa
    CareCategory.BATH -> Icons.Filled.Bathtub
    CareCategory.EXERCISE -> Icons.Filled.DirectionsRun
    CareCategory.FRESH_AIR -> Icons.Filled.Air
    CareCategory.SLEEP -> Icons.Filled.Bedtime
}
