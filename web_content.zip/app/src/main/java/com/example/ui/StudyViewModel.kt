package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AmbientSound
import com.example.audio.SoundAndHapticsHelper
import com.example.data.StudyDatabase
import com.example.data.StudyRepository
import com.example.data.model.KawaiiSticker
import com.example.data.model.StickerCatalog
import com.example.data.model.StudySession
import com.example.data.model.Subject
import com.example.util.NotificationHelper
import com.example.util.PaymentSecurityManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class PomodoroMode(val title: String, val emoji: String) {
    FOCUS("Focus", "🎯"),
    SHORT_BREAK("Short Break", "☕"),
    LONG_BREAK("Long Break", "🌴")
}

data class TimerUiState(
    val mode: PomodoroMode = PomodoroMode.FOCUS,
    val isRunning: Boolean = false,
    val totalSeconds: Int = 25 * 60,
    val secondsRemaining: Int = 25 * 60,
    val selectedSubject: Subject? = null,
    val completedCycles: Int = 0,
    val ambientSound: AmbientSound = AmbientSound.NONE,
    val motivationalQuote: String = "One cute pomodoro at a time 💖",
    val activeStickerId: String = "bunny_pen",
    val newUnlockedSticker: KawaiiSticker? = null
)

data class SettingsUiState(
    val focusMinutes: Int = 25,
    val shortBreakMinutes: Int = 5,
    val longBreakMinutes: Int = 15,
    val longBreakInterval: Int = 4,
    val dailyGoalMinutes: Int = 180, // 3 hours
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val isVipActive: Boolean = false,
    val autoNotificationsEnabled: Boolean = true
)

data class DayStudyStat(
    val dayLabel: String, // e.g. "Mon"
    val dateLabel: String, // e.g. "Sep 28"
    val totalMinutes: Int,
    val isToday: Boolean
)

data class SubjectStudyStat(
    val subject: Subject,
    val totalMinutes: Int,
    val percentage: Float
)

class StudyViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: StudyRepository
    private val soundHelper = SoundAndHapticsHelper(application.applicationContext)

    private val _timerState = MutableStateFlow(TimerUiState())
    val timerState: StateFlow<TimerUiState> = _timerState.asStateFlow()

    private val _settingsState = MutableStateFlow(
        SettingsUiState(isVipActive = PaymentSecurityManager.isVipActive(application))
    )
    val settingsState: StateFlow<SettingsUiState> = _settingsState.asStateFlow()

    private var timerJob: Job? = null
    private var sessionStartTime: Long = 0

    val subjects: StateFlow<List<Subject>>
    val allSessions: StateFlow<List<StudySession>>

    private val quotes = listOf(
        "One cute pomodoro at a time 💖",
        "Little bunny steps every day lead to giant success 🐰",
        "Stay sweet, stay focused, stay curious ✨",
        "Your future self is smiling at your hard work 🌸",
        "Focus on progress, not perfection 🧼",
        "Pink dreams and productive routines 🎀",
        "Clean mind, clean notes, happy heart ⭐"
    )

    init {
        val database = StudyDatabase.getDatabase(application, viewModelScope)
        repository = StudyRepository(database.subjectDao(), database.studySessionDao())

        subjects = repository.allSubjects
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000),
                initialValue = emptyList()
            )

        allSessions = repository.allSessions
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000),
                initialValue = emptyList()
            )

        // Select first available subject when loaded if none selected
        viewModelScope.launch {
            subjects.collect { subjectList ->
                if (_timerState.value.selectedSubject == null && subjectList.isNotEmpty()) {
                    _timerState.update { it.copy(selectedSubject = subjectList.first()) }
                }
            }
        }
    }

    fun selectSubject(subject: Subject) {
        _timerState.update { it.copy(selectedSubject = subject) }
    }

    fun setMode(mode: PomodoroMode) {
        val settings = _settingsState.value
        val minutes = when (mode) {
            PomodoroMode.FOCUS -> settings.focusMinutes
            PomodoroMode.SHORT_BREAK -> settings.shortBreakMinutes
            PomodoroMode.LONG_BREAK -> settings.longBreakMinutes
        }
        val duration = minutes * 60

        timerJob?.cancel()
        timerJob = null
        _timerState.update {
            it.copy(
                mode = mode,
                isRunning = false,
                totalSeconds = duration,
                secondsRemaining = duration,
                motivationalQuote = quotes.random()
            )
        }
    }

    fun startTimer() {
        if (_timerState.value.isRunning) return

        if (_timerState.value.secondsRemaining <= 0) {
            resetTimer()
        }

        if (sessionStartTime == 0L) {
            sessionStartTime = System.currentTimeMillis()
        }

        if (_settingsState.value.vibrationEnabled) {
            soundHelper.triggerTickHaptic()
        }

        _timerState.update { it.copy(isRunning = true) }

        // Start ambient sound if selected
        if (_timerState.value.ambientSound != AmbientSound.NONE) {
            soundHelper.setAmbientSound(_timerState.value.ambientSound)
        }

        timerJob = viewModelScope.launch {
            while (isActive && _timerState.value.secondsRemaining > 0) {
                delay(1000L)
                _timerState.update { state ->
                    val nextSec = state.secondsRemaining - 1
                    state.copy(secondsRemaining = nextSec)
                }
            }

            if (_timerState.value.secondsRemaining <= 0) {
                onTimerFinished()
            }
        }
    }

    fun pauseTimer() {
        timerJob?.cancel()
        timerJob = null
        soundHelper.stopAmbientSound()
        if (_settingsState.value.vibrationEnabled) {
            soundHelper.triggerTickHaptic()
        }
        _timerState.update { it.copy(isRunning = false) }
    }

    fun resetTimer() {
        pauseTimer()
        val settings = _settingsState.value
        val minutes = when (_timerState.value.mode) {
            PomodoroMode.FOCUS -> settings.focusMinutes
            PomodoroMode.SHORT_BREAK -> settings.shortBreakMinutes
            PomodoroMode.LONG_BREAK -> settings.longBreakMinutes
        }
        sessionStartTime = 0L
        _timerState.update {
            it.copy(
                isRunning = false,
                totalSeconds = minutes * 60,
                secondsRemaining = minutes * 60
            )
        }
    }

    fun adjustTime(deltaMinutes: Int) {
        val currentRemaining = _timerState.value.secondsRemaining
        val currentTotal = _timerState.value.totalSeconds
        val deltaSeconds = deltaMinutes * 60
        val newRemaining = (currentRemaining + deltaSeconds).coerceAtLeast(60)
        val newTotal = (currentTotal + deltaSeconds).coerceAtLeast(60)

        _timerState.update {
            it.copy(
                secondsRemaining = newRemaining,
                totalSeconds = newTotal
            )
        }
    }

    fun setAmbientSound(sound: AmbientSound) {
        _timerState.update { it.copy(ambientSound = sound) }
        if (_timerState.value.isRunning) {
            soundHelper.setAmbientSound(sound)
        }
    }

    private fun onTimerFinished() {
        val currentMode = _timerState.value.mode
        val settings = _settingsState.value

        if (settings.vibrationEnabled) {
            soundHelper.triggerCompletionVibration()
        }
        if (settings.soundEnabled) {
            soundHelper.playCompletionChime()
        }
        soundHelper.stopAmbientSound()

        if (currentMode == PomodoroMode.FOCUS) {
            val subject = _timerState.value.selectedSubject
            val duration = _timerState.value.totalSeconds
            viewModelScope.launch {
                repository.insertSession(
                    StudySession(
                        subjectId = subject?.id ?: 0,
                        subjectName = subject?.name ?: "General Focus",
                        subjectColorHex = subject?.colorHex ?: "#F59E0B",
                        subjectIcon = subject?.icon ?: "🎯",
                        durationSeconds = duration,
                        sessionType = "FOCUS",
                        timestamp = System.currentTimeMillis(),
                        notes = "Completed Pomodoro session"
                    )
                )
            }

            val nextCycles = _timerState.value.completedCycles + 1
            val nextMode = if (nextCycles % settings.longBreakInterval == 0) {
                PomodoroMode.LONG_BREAK
            } else {
                PomodoroMode.SHORT_BREAK
            }

            val rewardSticker = StickerCatalog.allStickers.random()
            _timerState.update {
                it.copy(
                    completedCycles = nextCycles,
                    newUnlockedSticker = rewardSticker
                )
            }

            if (settings.autoNotificationsEnabled) {
                NotificationHelper.showStudyNotification(
                    getApplication(),
                    "🌸 Pomodoro Complete! +10 StudyCoins",
                    "You focused for ${duration / 60}m on ${subject?.name ?: "Focus"}! A cute reward sticker has unlocked ✨"
                )
            }
            setMode(nextMode)
        } else {
            // Break ended, prepare next focus session
            if (settings.autoNotificationsEnabled) {
                NotificationHelper.showStudyNotification(
                    getApplication(),
                    "☕ Break Ended • Ready for Next Focus",
                    "Your pastel study desk is ready! Tap to start your next interval 🐰"
                )
            }
            setMode(PomodoroMode.FOCUS)
        }
    }

    fun activateVip(licenseKey: String = "AUTHENTICATED_VIP") {
        PaymentSecurityManager.setVipActive(getApplication(), true, licenseKey)
        _settingsState.update { it.copy(isVipActive = true) }
    }

    fun deactivateVip() {
        PaymentSecurityManager.setVipActive(getApplication(), false)
        _settingsState.update { it.copy(isVipActive = false) }
    }

    fun toggleAutoNotifications(enabled: Boolean) {
        _settingsState.update { it.copy(autoNotificationsEnabled = enabled) }
    }

    fun triggerTestAutoNotification() {
        NotificationHelper.showStudyNotification(
            getApplication(),
            "🐰 Bunny Pen says: Keep your streak alive!",
            "You're only 1 session away from reaching your daily study goal! Keep shining ⭐"
        )
    }

    fun dismissUnlockedSticker() {
        _timerState.update { it.copy(newUnlockedSticker = null) }
    }

    fun setActiveSticker(id: String) {
        _timerState.update { it.copy(activeStickerId = id) }
    }

    /**
     * Complete and save session early if worked >= 1 min
     */
    fun completeSessionEarly(notes: String = "") {
        val elapsedSeconds = _timerState.value.totalSeconds - _timerState.value.secondsRemaining
        if (elapsedSeconds >= 60 && _timerState.value.mode == PomodoroMode.FOCUS) {
            val subject = _timerState.value.selectedSubject
            viewModelScope.launch {
                repository.insertSession(
                    StudySession(
                        subjectId = subject?.id ?: 0,
                        subjectName = subject?.name ?: "General Focus",
                        subjectColorHex = subject?.colorHex ?: "#F472B6",
                        subjectIcon = subject?.icon ?: "🎯",
                        durationSeconds = elapsedSeconds,
                        sessionType = "FOCUS",
                        timestamp = System.currentTimeMillis(),
                        notes = if (notes.isNotBlank()) notes else "Completed focus session"
                    )
                )
            }
            val rewardSticker = StickerCatalog.allStickers.random()
            _timerState.update { it.copy(newUnlockedSticker = rewardSticker) }
        }
        resetTimer()
    }

    // Subjects CRUD
    fun addSubject(name: String, icon: String, colorHex: String, dailyGoalMinutes: Int) {
        viewModelScope.launch {
            val newSubject = Subject(
                name = name.trim(),
                icon = icon.ifBlank { "📚" },
                colorHex = colorHex,
                dailyGoalMinutes = dailyGoalMinutes.coerceAtLeast(5)
            )
            val id = repository.insertSubject(newSubject)
            if (_timerState.value.selectedSubject == null) {
                _timerState.update { it.copy(selectedSubject = newSubject.copy(id = id)) }
            }
        }
    }

    fun updateSubject(subject: Subject) {
        viewModelScope.launch {
            repository.updateSubject(subject)
            if (_timerState.value.selectedSubject?.id == subject.id) {
                _timerState.update { it.copy(selectedSubject = subject) }
            }
        }
    }

    fun deleteSubject(subject: Subject) {
        viewModelScope.launch {
            repository.deleteSubject(subject)
            if (_timerState.value.selectedSubject?.id == subject.id) {
                val remaining = subjects.value.filter { it.id != subject.id }
                _timerState.update { it.copy(selectedSubject = remaining.firstOrNull()) }
            }
        }
    }

    fun deleteSession(sessionId: Long) {
        viewModelScope.launch {
            repository.deleteSessionById(sessionId)
        }
    }

    fun addManualSession(subject: Subject, durationMinutes: Int, notes: String, timestamp: Long = System.currentTimeMillis()) {
        viewModelScope.launch {
            repository.insertSession(
                StudySession(
                    subjectId = subject.id,
                    subjectName = subject.name,
                    subjectColorHex = subject.colorHex,
                    subjectIcon = subject.icon,
                    durationSeconds = durationMinutes * 60,
                    sessionType = "FOCUS",
                    timestamp = timestamp,
                    notes = notes.ifBlank { "Manual study entry" }
                )
            )
        }
    }

    // Settings
    fun updateSettings(
        focusMinutes: Int,
        shortBreakMinutes: Int,
        longBreakMinutes: Int,
        longBreakInterval: Int,
        dailyGoalMinutes: Int,
        soundEnabled: Boolean,
        vibrationEnabled: Boolean
    ) {
        _settingsState.update {
            it.copy(
                focusMinutes = focusMinutes,
                shortBreakMinutes = shortBreakMinutes,
                longBreakMinutes = longBreakMinutes,
                longBreakInterval = longBreakInterval,
                dailyGoalMinutes = dailyGoalMinutes,
                soundEnabled = soundEnabled,
                vibrationEnabled = vibrationEnabled
            )
        }
        // Update current timer if not running
        if (!_timerState.value.isRunning) {
            val minutes = when (_timerState.value.mode) {
                PomodoroMode.FOCUS -> focusMinutes
                PomodoroMode.SHORT_BREAK -> shortBreakMinutes
                PomodoroMode.LONG_BREAK -> longBreakMinutes
            }
            _timerState.update {
                it.copy(
                    totalSeconds = minutes * 60,
                    secondsRemaining = minutes * 60
                )
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        soundHelper.stopAmbientSound()
    }
}
