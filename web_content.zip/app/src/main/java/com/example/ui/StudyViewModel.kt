package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.LessonEntity
import com.example.data.local.PreferencesManager
import com.example.data.local.TaskEntity
import com.example.data.local.TrackLessonEntity
import com.example.data.local.TrackWithLessons
import com.example.data.model.AppConstants
import com.example.data.model.FocusStats
import com.example.data.model.MainTab
import com.example.data.model.PomodoroMode
import com.example.data.model.TaskFilter
import com.example.data.model.TaskPriority
import com.example.data.model.TimetableFilter
import com.example.data.model.TrackFilter
import com.example.data.repository.StudyRepository
import com.example.util.DateTimeUtils
import com.example.util.SoundPlayer
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PomodoroState(
    val mode: PomodoroMode = PomodoroMode.FOCUS_25,
    val remainingSeconds: Int = PomodoroMode.FOCUS_25.seconds,
    val totalSeconds: Int = PomodoroMode.FOCUS_25.seconds,
    val isRunning: Boolean = false,
    val subject: String = ""
)

data class ConfettiBurst(
    val id: Long = 0L,
    val particleCount: Int = 70
)

data class MainUiState(
    val lessons: List<LessonEntity> = emptyList(),
    val tracks: List<TrackWithLessons> = emptyList(),
    val tasks: List<TaskEntity> = emptyList(),
    val isDarkTheme: Boolean = true,
    val examDate: String = "2027-06-12",
    val countdownDays: Long = 0L,
    val countdownHours: Long = 0L,
    val todayArabicDate: String = "",
    val todayDayName: String = "",
    val currentQuote: String = AppConstants.MOTIVATIONAL_QUOTES.first(),
    val activeTab: MainTab = MainTab.TIMETABLE,
    val timetableFilter: TimetableFilter = TimetableFilter.ALL,
    val timetableSearch: String = "",
    val trackFilter: TrackFilter = TrackFilter.ALL,
    val taskFilter: TaskFilter = TaskFilter.ALL,
    val taskSearch: String = "",
    val focusStats: FocusStats = FocusStats(DateTimeUtils.todayIsoKey(), 0, 0),
    val pomodoro: PomodoroState = PomodoroState(),
    val confettiBurst: ConfettiBurst? = null
)

class StudyViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: StudyRepository by lazy {
        val db = AppDatabase.getInstance(application)
        val prefs = PreferencesManager(application)
        StudyRepository(db, prefs)
    }

    private val _activeTab = MutableStateFlow(MainTab.TIMETABLE)
    private val _timetableFilter = MutableStateFlow(TimetableFilter.ALL)
    private val _timetableSearch = MutableStateFlow("")
    private val _trackFilter = MutableStateFlow(TrackFilter.ALL)
    private val _taskFilter = MutableStateFlow(TaskFilter.ALL)
    private val _taskSearch = MutableStateFlow("")
    private val _quoteIndex = MutableStateFlow(
        (System.currentTimeMillis() % AppConstants.MOTIVATIONAL_QUOTES.size).toInt()
    )
    private val _countdown = MutableStateFlow(0L to 0L)
    private val _pomodoro = MutableStateFlow(PomodoroState())
    private val _confetti = MutableStateFlow<ConfettiBurst?>(null)

    private val _toastEvents = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val toastEvents: SharedFlow<String> = _toastEvents.asSharedFlow()

    private var timerJob: Job? = null

    private data class FilterSlice(
        val tab: MainTab,
        val ttFilter: TimetableFilter,
        val ttSearch: String,
        val trFilter: TrackFilter,
        val tkFilter: TaskFilter,
        val tkSearch: String
    )

    private data class PrefsSlice(
        val isDark: Boolean,
        val examDate: String,
        val focusStats: FocusStats,
        val quoteIdx: Int,
        val countdown: Pair<Long, Long>
    )

    private val filterFlow = combine(
        combine(_activeTab, _timetableFilter, _timetableSearch) { tab, ttFilter, ttSearch ->
            Triple(tab, ttFilter, ttSearch)
        },
        combine(_trackFilter, _taskFilter, _taskSearch) { trFilter, tkFilter, tkSearch ->
            Triple(trFilter, tkFilter, tkSearch)
        }
    ) { left, right ->
        FilterSlice(
            tab = left.first,
            ttFilter = left.second,
            ttSearch = left.third,
            trFilter = right.first,
            tkFilter = right.second,
            tkSearch = right.third
        )
    }

    private val prefsFlow = combine(
        repository.isDarkTheme,
        repository.examDate,
        repository.focusStats,
        _quoteIndex,
        _countdown
    ) { isDark, examDate, focusStats, qIdx, countdown ->
        PrefsSlice(isDark, examDate, focusStats, qIdx, countdown)
    }

    private val dataFlow = combine(
        repository.lessons,
        repository.tracks,
        repository.tasks
    ) { lessons, tracks, tasks ->
        Triple(lessons, tracks, tasks)
    }

    val uiState: StateFlow<MainUiState> = combine(
        dataFlow,
        filterFlow,
        prefsFlow,
        _pomodoro,
        _confetti
    ) { data, filters, prefs, pomo, confetti ->
        MainUiState(
            lessons = data.first,
            tracks = data.second,
            tasks = data.third,
            isDarkTheme = prefs.isDark,
            examDate = prefs.examDate,
            countdownDays = prefs.countdown.first,
            countdownHours = prefs.countdown.second,
            todayArabicDate = DateTimeUtils.todayArabicFullDate(),
            todayDayName = DateTimeUtils.todayArabicDayName(),
            currentQuote = AppConstants.MOTIVATIONAL_QUOTES[prefs.quoteIdx % AppConstants.MOTIVATIONAL_QUOTES.size],
            activeTab = filters.tab,
            timetableFilter = filters.ttFilter,
            timetableSearch = filters.ttSearch,
            trackFilter = filters.trFilter,
            taskFilter = filters.tkFilter,
            taskSearch = filters.tkSearch,
            focusStats = prefs.focusStats,
            pomodoro = pomo,
            confettiBurst = confetti
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = MainUiState(
            todayArabicDate = DateTimeUtils.todayArabicFullDate(),
            todayDayName = DateTimeUtils.todayArabicDayName()
        )
    )

    init {
        viewModelScope.launch {
            repository.seedInitialDataIfNeeded()
        }
        viewModelScope.launch {
            repository.examDate.collect { date ->
                _countdown.value = DateTimeUtils.countdownToExam(date)
            }
        }
        viewModelScope.launch {
            while (true) {
                delay(60_000L)
                _countdown.value = DateTimeUtils.countdownToExam(uiState.value.examDate)
            }
        }
    }

    fun switchTab(tab: MainTab) {
        _activeTab.value = tab
    }

    fun nextQuote() {
        _quoteIndex.update { (it + 1) % AppConstants.MOTIVATIONAL_QUOTES.size }
    }

    fun toggleDarkTheme() {
        viewModelScope.launch {
            repository.setDarkTheme(!uiState.value.isDarkTheme)
        }
    }

    fun setExamDate(dateIso: String) {
        viewModelScope.launch {
            repository.setExamDate(dateIso)
            _countdown.value = DateTimeUtils.countdownToExam(dateIso)
            emitToast("تم تحديث موعد الامتحان 📅")
        }
    }

    // Timetable actions
    fun setTimetableFilter(filter: TimetableFilter) {
        _timetableFilter.value = filter
    }

    fun setTimetableSearch(query: String) {
        _timetableSearch.value = query
    }

    fun saveLesson(
        id: String?,
        subject: String,
        day: String,
        mode: String,
        teacher: String,
        time: String,
        location: String,
        colorHex: String
    ) {
        val cleanSubject = subject.trim()
        if (cleanSubject.isEmpty()) return
        viewModelScope.launch {
            val existing = if (id != null) uiState.value.lessons.firstOrNull { it.id == id } else null
            val entity = LessonEntity(
                id = id ?: "ls_${System.currentTimeMillis()}",
                subject = cleanSubject,
                day = day,
                mode = mode,
                teacher = teacher.trim(),
                time = time.trim(),
                location = location.trim(),
                colorHex = colorHex,
                attended = existing?.attended ?: false
            )
            repository.saveLesson(entity)
            emitToast(if (id != null) "تم تعديل الدرس" else "تمت إضافة الدرس 📅")
        }
    }

    fun toggleLessonAttended(lesson: LessonEntity) {
        viewModelScope.launch {
            val newState = !lesson.attended
            repository.saveLesson(lesson.copy(attended = newState))
            if (newState) {
                triggerConfetti(45)
                emitToast("عاش! تم تسجيل حضور الحصة ✅")
            }
        }
    }

    fun deleteLesson(id: String) {
        viewModelScope.launch {
            repository.deleteLesson(id)
            emitToast("تم حذف الدرس")
        }
    }

    fun resetWeeklyAttendance() {
        viewModelScope.launch {
            repository.resetWeeklyAttendance()
            emitToast("تم تصفير الحضور.. أسبوع موفق! 🚀")
        }
    }

    // Tracks actions
    fun setTrackFilter(filter: TrackFilter) {
        _trackFilter.value = filter
    }

    fun saveTrack(id: String?, name: String, teacher: String, colorHex: String) {
        val cleanName = name.trim()
        if (cleanName.isEmpty()) return
        viewModelScope.launch {
            repository.saveTrack(id, cleanName, teacher.trim(), colorHex)
            emitToast(if (id != null) "تم تحديث المسار" else "تمت إضافة المسار 🚀")
        }
    }

    fun deleteTrack(id: String) {
        viewModelScope.launch {
            repository.deleteTrack(id)
            emitToast("تم حذف المسار")
        }
    }

    fun saveTrackLesson(trackId: String, lessonId: String?, title: String, note: String) {
        val cleanTitle = title.trim()
        if (cleanTitle.isEmpty()) {
            emitToast("أدخل عنوان الدرس")
            return
        }
        viewModelScope.launch {
            repository.saveTrackLesson(trackId, lessonId, cleanTitle, note.trim())
            emitToast(if (lessonId != null) "تم تعديل الدرس" else "تمت إضافة الدرس 📚")
        }
    }

    fun addBulkTrackLessons(trackId: String, rawLines: String) {
        val titles = rawLines.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (titles.isEmpty()) {
            emitToast("اكتب درساً واحداً على الأقل")
            return
        }
        viewModelScope.launch {
            repository.addBulkTrackLessons(trackId, titles)
            emitToast("تمت إضافة ${titles.size} دروس 📚")
        }
    }

    fun toggleTrackLesson(lesson: TrackLessonEntity) {
        viewModelScope.launch {
            val becomingDone = !lesson.completed
            repository.toggleTrackLesson(lesson)
            if (becomingDone) {
                triggerConfetti(70)
                emitToast("ممتاز! تم إنجاز الدرس بنجاح 🎉")
                SoundPlayer.playSuccessChime()
            }
        }
    }

    fun deleteTrackLesson(id: String) {
        viewModelScope.launch {
            repository.deleteTrackLesson(id)
        }
    }

    // Tasks actions
    fun setTaskFilter(filter: TaskFilter) {
        _taskFilter.value = filter
    }

    fun setTaskSearch(query: String) {
        _taskSearch.value = query
    }

    fun addTask(title: String, subject: String, priority: TaskPriority, dueDate: String) {
        val cleanTitle = title.trim()
        if (cleanTitle.isEmpty()) return
        viewModelScope.launch {
            repository.saveTask(
                TaskEntity(
                    id = "tk_${System.currentTimeMillis()}",
                    title = cleanTitle,
                    subject = subject.trim(),
                    priority = priority.key,
                    dueDate = dueDate.trim(),
                    completed = false,
                    createdAt = System.currentTimeMillis()
                )
            )
            emitToast("تمت إضافة المهمة ✅")
        }
    }

    fun toggleTask(task: TaskEntity) {
        viewModelScope.launch {
            repository.toggleTask(task)
        }
    }

    fun deleteTask(id: String) {
        viewModelScope.launch {
            repository.deleteTask(id)
        }
    }

    fun clearCompletedTasks() {
        val count = uiState.value.tasks.count { it.completed }
        if (count == 0) {
            emitToast("لا توجد مهام مكتملة لمسحها")
            return
        }
        viewModelScope.launch {
            repository.clearCompletedTasks()
            emitToast("تم تنظيف القائمة ✨")
        }
    }

    // Pomodoro Focus Room actions
    fun setPomodoroMode(mode: PomodoroMode) {
        timerJob?.cancel()
        _pomodoro.update {
            it.copy(
                mode = mode,
                remainingSeconds = mode.seconds,
                totalSeconds = mode.seconds,
                isRunning = false
            )
        }
    }

    fun setPomodoroSubject(subject: String) {
        _pomodoro.update { it.copy(subject = subject) }
    }

    fun togglePomodoro() {
        if (_pomodoro.value.isRunning) {
            timerJob?.cancel()
            _pomodoro.update { it.copy(isRunning = false) }
        } else {
            if (_pomodoro.value.remainingSeconds <= 0) {
                _pomodoro.update { it.copy(remainingSeconds = it.totalSeconds) }
            }
            _pomodoro.update { it.copy(isRunning = true) }
            timerJob?.cancel()
            timerJob = viewModelScope.launch {
                while (_pomodoro.value.isRunning && _pomodoro.value.remainingSeconds > 0) {
                    delay(1000L)
                    if (!_pomodoro.value.isRunning) break
                    val next = _pomodoro.value.remainingSeconds - 1
                    if (next <= 0) {
                        val currentMode = _pomodoro.value.mode
                        val totalMins = (_pomodoro.value.totalSeconds / 60).coerceAtLeast(1)
                        _pomodoro.update {
                            it.copy(remainingSeconds = 0, isRunning = false)
                        }
                        if (currentMode.isFocus) {
                            repository.recordFocusSession(totalMins)
                            triggerConfetti(90)
                            emitToast("عاش يا بطل! أتممت جلسة تركيز كاملة 🔥")
                        } else {
                            emitToast("انتهت الاستراحة.. جاهز نكمل؟ 💪")
                        }
                        SoundPlayer.playSuccessChime()
                        break
                    } else {
                        _pomodoro.update { it.copy(remainingSeconds = next) }
                    }
                }
            }
        }
    }

    fun resetPomodoro() {
        timerJob?.cancel()
        _pomodoro.update {
            it.copy(remainingSeconds = it.totalSeconds, isRunning = false)
        }
    }

    // Backup & Reset
    suspend fun exportBackupJson(): String = repository.exportBackupJson()

    fun importBackupJson(raw: String) {
        viewModelScope.launch {
            repository.importBackupJson(raw)
                .onSuccess { emitToast("تم استيراد البيانات بنجاح 🎉") }
                .onFailure { emitToast("ملف النسخة غير صالح!") }
        }
    }

    fun resetAllData() {
        viewModelScope.launch {
            repository.resetAllData()
            emitToast("تم مسح جميع البيانات")
        }
    }

    private fun triggerConfetti(count: Int) {
        _confetti.value = ConfettiBurst(id = System.nanoTime(), particleCount = count)
    }

    fun clearConfetti() {
        _confetti.value = null
    }

    private fun emitToast(message: String) {
        _toastEvents.tryEmit(message)
    }
}
