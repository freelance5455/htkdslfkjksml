package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.FolderZip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CodeBlockBg
import com.example.ui.theme.CodeBlockHeaderBg
import com.example.ui.theme.MonoFontFamily

private sealed interface MarkdownSegment {
    data class TextBlock(val text: String) : MarkdownSegment
    data class CodeBlock(val language: String, val code: String) : MarkdownSegment
}

@Composable
fun MarkdownMessageContent(
    markdown: String,
    textColor: Color,
    copyLabel: String,
    exportZipLabel: String,
    onCopyCode: (String) -> Unit,
    onExportZip: (() -> Unit)? = null
) {
    val segments = remember(markdown) { parseMarkdownSegments(markdown) }

    SelectionContainer {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            segments.forEach { segment ->
                when (segment) {
                    is MarkdownSegment.TextBlock -> {
                        if (segment.text.isNotBlank()) {
                            RichTextParagraphs(
                                raw = segment.text,
                                textColor = textColor
                            )
                        }
                    }
                    is MarkdownSegment.CodeBlock -> {
                        CodeBlockCard(
                            language = segment.language,
                            code = segment.code,
                            copyLabel = copyLabel,
                            exportZipLabel = exportZipLabel,
                            onCopy = { onCopyCode(segment.code) },
                            onExportZip = if (segment.language.lowercase() in setOf("html", "htm", "css", "js", "javascript")) {
                                onExportZip
                            } else null
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun RichTextParagraphs(
    raw: String,
    textColor: Color
) {
    val lines = raw.trimEnd().lines()
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        lines.forEach { line ->
            val trimmed = line.trimStart()
            when {
                trimmed.startsWith("### ") -> {
                    Text(
                        text = buildInlineAnnotated(trimmed.removePrefix("### "), textColor),
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = textColor,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                trimmed.startsWith("## ") -> {
                    Text(
                        text = buildInlineAnnotated(trimmed.removePrefix("## "), textColor),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = textColor,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
                trimmed.startsWith("# ") -> {
                    Text(
                        text = buildInlineAnnotated(trimmed.removePrefix("# "), textColor),
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = textColor,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
                trimmed.startsWith("- ") || trimmed.startsWith("* ") -> {
                    Row(modifier = Modifier.padding(start = 6.dp)) {
                        Text(
                            text = "•",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = buildInlineAnnotated(trimmed.drop(2), textColor),
                            style = MaterialTheme.typography.bodyLarge,
                            color = textColor
                        )
                    }
                }
                trimmed.isEmpty() -> {
                    Spacer(modifier = Modifier.height(4.dp))
                }
                else -> {
                    Text(
                        text = buildInlineAnnotated(line, textColor),
                        style = MaterialTheme.typography.bodyLarge,
                        color = textColor
                    )
                }
            }
        }
    }
}

@Composable
private fun CodeBlockCard(
    language: String,
    code: String,
    copyLabel: String,
    exportZipLabel: String,
    onCopy: () -> Unit,
    onExportZip: (() -> Unit)?
) {
    Surface(
        color = CodeBlockBg,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                MaterialTheme.colorScheme.outline.copy(alpha = 0.6f),
                RoundedCornerShape(14.dp)
            )
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CodeBlockHeaderBg)
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = language.ifBlank { "code" }.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (onExportZip != null) {
                        TextButton(onClick = onExportZip) {
                            Icon(
                                imageVector = Icons.Rounded.FolderZip,
                                contentDescription = exportZipLabel,
                                modifier = Modifier.size(16.dp),
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "ZIP",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    IconButton(onClick = onCopy) {
                        Icon(
                            imageVector = Icons.Rounded.ContentCopy,
                            contentDescription = copyLabel,
                            modifier = Modifier.size(16.dp),
                            tint = Color(0xFFCBD5E1)
                        )
                    }
                }
            }
            Text(
                text = code,
                fontFamily = MonoFontFamily,
                fontSize = 12.5.sp,
                lineHeight = 18.sp,
                color = Color(0xFFE2E8F0),
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(14.dp)
            )
        }
    }
}

private fun parseMarkdownSegments(markdown: String): List<MarkdownSegment> {
    val result = mutableListOf<MarkdownSegment>()
    val fenceRegex = Regex("```([a-zA-Z0-9_+.-]*)\\s*\\n([\\s\\S]*?)```")
    var lastIndex = 0
    for (match in fenceRegex.findAll(markdown)) {
        if (match.range.first > lastIndex) {
            result.add(MarkdownSegment.TextBlock(markdown.substring(lastIndex, match.range.first)))
        }
        val lang = match.groupValues[1].trim()
        val code = match.groupValues[2].trimEnd()
        result.add(MarkdownSegment.CodeBlock(lang, code))
        lastIndex = match.range.last + 1
    }
    if (lastIndex < markdown.length) {
        val tail = markdown.substring(lastIndex)
        // Handle unclosed streaming fence gracefully
        val openFenceIdx = tail.indexOf("```")
        if (openFenceIdx >= 0) {
            if (openFenceIdx > 0) {
                result.add(MarkdownSegment.TextBlock(tail.substring(0, openFenceIdx)))
            }
            val afterTicks = tail.substring(openFenceIdx + 3)
            val nl = afterTicks.indexOf('\n')
            if (nl >= 0) {
                val lang = afterTicks.substring(0, nl).trim()
                val code = afterTicks.substring(nl + 1)
                result.add(MarkdownSegment.CodeBlock(lang, code))
            } else {
                result.add(MarkdownSegment.TextBlock(tail.substring(openFenceIdx)))
            }
        } else {
            result.add(MarkdownSegment.TextBlock(tail))
        }
    }
    return result
}

private fun buildInlineAnnotated(text: String, baseColor: Color): AnnotatedString {
    val tokenRegex = Regex("(\\*\\*[^*]+\\*\\*|`[^`]+`|\\*[^*]+\\*)")
    return buildAnnotatedString {
        var cursor = 0
        for (match in tokenRegex.findAll(text)) {
            if (match.range.first > cursor) {
                append(text.substring(cursor, match.range.first))
            }
            val token = match.value
            when {
                token.startsWith("**") && token.endsWith("**") -> {
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = baseColor)) {
                        append(token.substring(2, token.length - 2))
                    }
                }
                token.startsWith("`") && token.endsWith("`") -> {
                    withStyle(
                        SpanStyle(
                            fontFamily = MonoFontFamily,
                            background = Color(0x3364748B),
                            fontSize = 13.5.sp
                        )
                    ) {
                        append(" ${token.substring(1, token.length - 1)} ")
                    }
                }
                token.startsWith("*") && token.endsWith("*") -> {
                    withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                        append(token.substring(1, token.length - 1))
                    }
                }
                else -> append(token)
            }
            cursor = match.range.last + 1
        }
        if (cursor < text.length) {
            append(text.substring(cursor))
        }
    }
}
