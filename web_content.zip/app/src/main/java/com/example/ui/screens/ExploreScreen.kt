package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Poll
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.ArkFeedIds
import com.example.data.model.ArkGroup
import com.example.data.model.ArkPost
import com.example.data.model.FollowEdge
import com.example.data.model.FollowRequest
import com.example.data.model.UserProfile
import com.example.ui.components.ArkAvatarBadge
import com.example.ui.components.EmptyStateGlassCard
import com.example.ui.components.FeedPostCard
import com.example.ui.components.GlowingPillButton
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.PostSkeletonCard
import com.example.ui.theme.ArkThemeTokens
import com.example.util.rememberDecodedImageBitmap
import kotlinx.coroutines.delay

@Composable
fun ExploreScreen(
    currentUser: UserProfile,
    posts: List<ArkPost>,
    selectedCategory: String,
    isLoading: Boolean,
    hasMore: Boolean,
    myReactions: Map<String, String>,
    myPollVotes: Map<String, Int>,
    bookmarkedIds: Set<String>,
    recommendedCreators: List<UserProfile>,
    userSearchResults: List<UserProfile>,
    postSearchResults: List<ArkPost>,
    selectedHashtag: String?,
    hashtagPosts: List<ArkPost>,
    publicCommunities: List<ArkGroup>,
    myGroups: List<ArkGroup>,
    myFollowing: List<FollowEdge>,
    outgoingFollowRequests: List<FollowRequest>,
    showBackButton: Boolean = false,
    onBack: () -> Unit,
    onSelectCategory: (String) -> Unit,
    onRefresh: () -> Unit,
    onLoadMore: () -> Unit,
    onSearchQuery: (String) -> Unit,
    onSelectHashtag: (String?) -> Unit,
    onClearSearch: () -> Unit,
    onFollowUser: (UserProfile) -> Unit,
    onUnfollowUser: (String, String) -> Unit,
    onCancelFollowRequest: (String) -> Unit,
    onOpenUserProfile: (String) -> Unit,
    onJoinCommunity: (String) -> Unit,
    onOpenGroup: (String) -> Unit,
    onReaction: (ArkPost, String) -> Unit,
    onOpenComments: (ArkPost) -> Unit,
    onShare: (ArkPost) -> Unit,
    onToggleBookmark: (String) -> Unit,
    onVotePoll: (String, Int) -> Unit,
    onEditCaption: (ArkPost) -> Unit,
    onToggleCommentsDisabled: (ArkPost) -> Unit,
    onDeletePost: (String) -> Unit,
    onHidePost: (String) -> Unit,
    onMuteAuthor: (String, String) -> Unit,
    onReportPost: (ArkPost) -> Unit,
    onOpenMedia: (ArkPost, Int) -> Unit,
    onOpenLikers: (ArkPost) -> Unit
) {
    val colors = ArkThemeTokens.colors
    var searchQuery by remember { mutableStateOf("") }
    var searchFilterTab by remember { mutableIntStateOf(0) } // 0: All, 1: People, 2: Posts, 3: Squads
    var gridMode by remember { mutableStateOf(true) }

    BackHandler(enabled = showBackButton || selectedHashtag != null || searchQuery.isNotBlank()) {
        when {
            selectedHashtag != null -> onSelectHashtag(null)
            searchQuery.isNotBlank() -> {
                searchQuery = ""
                onClearSearch()
            }
            showBackButton -> onBack()
        }
    }

    LaunchedEffect(searchQuery) {
        val trimmed = searchQuery.trim()
        if (trimmed.isEmpty()) {
            onClearSearch()
        } else {
            delay(260L)
            onSearchQuery(trimmed)
        }
    }

    val listState = rememberLazyListState()
    val categories = remember { listOf("All") + ArkFeedIds.feedCategories }
    val followingSet = remember(myFollowing) { myFollowing.map { it.peerUid }.toSet() }
    val outgoingReqByUid = remember(outgoingFollowRequests) { outgoingFollowRequests.associateBy { it.toUid } }
    val myGroupIds = remember(myGroups) { myGroups.map { it.id }.toSet() }

    val trendingTags = remember(posts) {
        posts.flatMap { it.hashtags }
            .groupingBy { it }
            .eachCount()
            .entries
            .sortedByDescending { it.value }
            .take(12)
            .map { it.key to it.value }
    }

    val displayedPosts = remember(selectedHashtag, hashtagPosts, searchQuery, postSearchResults, posts) {
        when {
            selectedHashtag != null -> hashtagPosts
            searchQuery.isNotBlank() -> postSearchResults
            else -> posts
        }
    }

    val matchingCommunities = remember(publicCommunities, searchQuery) {
        val q = searchQuery.trim().lowercase()
        if (q.isBlank()) publicCommunities
        else publicCommunities.filter {
            it.name.lowercase().contains(q) || it.description.lowercase().contains(q)
        }
    }

    val shouldLoadMore by remember {
        derivedStateOf {
            val total = listState.layoutInfo.totalItemsCount
            val lastVisible = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            total > 0 && lastVisible >= total - 3
        }
    }

    LaunchedEffect(shouldLoadMore, hasMore, isLoading, searchQuery, selectedHashtag) {
        if (shouldLoadMore && hasMore && !isLoading && searchQuery.isBlank() && selectedHashtag == null) {
            onLoadMore()
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Header + Search Bar
        Surface(color = colors.surface) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        if (showBackButton) {
                            IconButton(onClick = onBack, modifier = Modifier.testTag("explore_back_button")) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = colors.ink)
                            }
                        }
                        Column(modifier = Modifier.padding(start = if (showBackButton) 4.dp else 4.dp)) {
                            Text("Explore", style = MaterialTheme.typography.headlineSmall, color = colors.ink)
                            Text("Creators, hashtags, squads & moments", style = MaterialTheme.typography.bodySmall, color = colors.ink2)
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { gridMode = !gridMode },
                            modifier = Modifier.testTag("explore_toggle_view")
                        ) {
                            Icon(
                                imageVector = if (gridMode) Icons.AutoMirrored.Filled.ViewList else Icons.Default.GridView,
                                contentDescription = if (gridMode) "Switch to Feed view" else "Switch to Grid view",
                                tint = colors.accent
                            )
                        }
                        IconButton(onClick = onRefresh, modifier = Modifier.testTag("explore_refresh")) {
                            Icon(Icons.Default.Refresh, contentDescription = "Refresh explore", tint = colors.accent)
                        }
                    }
                }
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it.take(40) },
                    placeholder = { Text("Search @users, #hashtags, or squads...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = colors.ink2) },
                    trailingIcon = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(onClick = {
                                searchQuery = ""
                                onClearSearch()
                            }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear search")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("explore_search_input")
                )
            }
        }

        if (searchQuery.isNotBlank()) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val tabs = listOf("All", "People (${userSearchResults.size})", "Posts (${postSearchResults.size})", "Squads (${matchingCommunities.size})")
                items(tabs.indices.toList(), key = { "esearch_$it" }) { idx ->
                    FilterChip(
                        selected = searchFilterTab == idx,
                        onClick = { searchFilterTab = idx },
                        label = { Text(tabs[idx]) }
                    )
                }
            }
        } else if (selectedHashtag != null) {
            Surface(
                color = colors.accentSoft,
                border = BorderStroke(1.dp, colors.accent.copy(alpha = 0.35f)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Tag, contentDescription = null, tint = colors.accent, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("#$selectedHashtag (${hashtagPosts.size} posts)", style = MaterialTheme.typography.titleSmall, color = colors.ink)
                    }
                    TextButton(onClick = { onSelectHashtag(null) }) {
                        Text("Clear")
                    }
                }
            }
        } else {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories) { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { onSelectCategory(cat) },
                        label = { Text(cat) }
                    )
                }
            }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Trending Hashtags when browsing Explore
            if (searchQuery.isBlank() && selectedHashtag == null && trendingTags.isNotEmpty()) {
                item(key = "trending_hashtags") {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Trending Tags", style = MaterialTheme.typography.titleSmall, color = colors.ink)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(trendingTags, key = { it.first }) { (tag, count) ->
                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = colors.accentSoft,
                                    border = BorderStroke(1.dp, colors.accent.copy(alpha = 0.25f)),
                                    modifier = Modifier.clickable { onSelectHashtag(tag) }
                                ) {
                                    Text(
                                        text = "#$tag · $count",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = colors.accent,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Recommended Creators when browsing Explore
            if (searchQuery.isBlank() && selectedHashtag == null && recommendedCreators.isNotEmpty()) {
                item(key = "recommended_creators") {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Creators on ARK", style = MaterialTheme.typography.titleSmall, color = colors.ink)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(recommendedCreators, key = { it.userId }) { creator ->
                                val isFollowing = followingSet.contains(creator.userId)
                                val outgoingReq = outgoingReqByUid[creator.userId]
                                LiquidGlassCard(
                                    modifier = Modifier.width(156.dp),
                                    cornerRadius = 18.dp,
                                    contentPadding = PaddingValues(12.dp),
                                    onClick = { onOpenUserProfile(creator.userId) }
                                ) {
                                    Column(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        ArkAvatarBadge(
                                            avatarPreset = creator.avatarPreset,
                                            username = creator.username,
                                            imageBase64 = creator.avatarImageBase64,
                                            size = 52.dp
                                        )
                                        Spacer(Modifier.height(6.dp))
                                        Text(
                                            text = "@${creator.username}",
                                            style = MaterialTheme.typography.titleSmall,
                                            color = colors.ink,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "${creator.followersCount} followers",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = colors.ink2,
                                            maxLines = 1
                                        )
                                        Spacer(Modifier.height(8.dp))
                                        when {
                                            isFollowing -> OutlinedButton(
                                                onClick = { onUnfollowUser(creator.userId, creator.username) },
                                                modifier = Modifier.fillMaxWidth().height(36.dp),
                                                contentPadding = PaddingValues(horizontal = 8.dp)
                                            ) { Text("Following", style = MaterialTheme.typography.labelSmall) }
                                            outgoingReq != null -> OutlinedButton(
                                                onClick = { onCancelFollowRequest(outgoingReq.id) },
                                                modifier = Modifier.fillMaxWidth().height(36.dp),
                                                contentPadding = PaddingValues(horizontal = 8.dp)
                                            ) { Text("Requested", style = MaterialTheme.typography.labelSmall) }
                                            else -> GlowingPillButton(
                                                text = "Follow",
                                                onClick = { onFollowUser(creator) },
                                                modifier = Modifier.fillMaxWidth().height(36.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // People Search Results
            if (searchQuery.isNotBlank() && (searchFilterTab == 0 || searchFilterTab == 1)) {
                if (userSearchResults.isNotEmpty()) {
                    item(key = "people_results_header") {
                        Text("People", style = MaterialTheme.typography.titleSmall, color = colors.ink)
                    }
                    items(userSearchResults, key = { "usearch_${it.userId}" }) { user ->
                        val isFollowing = followingSet.contains(user.userId)
                        val outgoingReq = outgoingReqByUid[user.userId]
                        LiquidGlassCard(
                            modifier = Modifier.fillMaxWidth(),
                            onClick = { onOpenUserProfile(user.userId) }
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    ArkAvatarBadge(
                                        avatarPreset = user.avatarPreset,
                                        username = user.username,
                                        imageBase64 = user.avatarImageBase64,
                                        size = 44.dp
                                    )
                                    Spacer(Modifier.width(10.dp))
                                    Column {
                                        Text("@${user.username}", style = MaterialTheme.typography.titleSmall, color = colors.ink)
                                        Text(
                                            text = "${user.fullName.ifBlank { user.displayTag }} • ${user.followersCount} followers",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = colors.ink2,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                                if (user.userId != currentUser.userId) {
                                    when {
                                        isFollowing -> OutlinedButton(
                                            onClick = { onUnfollowUser(user.userId, user.username) }
                                        ) { Text("Following") }
                                        outgoingReq != null -> OutlinedButton(
                                            onClick = { onCancelFollowRequest(outgoingReq.id) }
                                        ) { Text("Requested") }
                                        else -> GlowingPillButton(
                                            text = if (user.isPrivateAccount) "Request" else "Follow",
                                            onClick = { onFollowUser(user) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                } else if (searchFilterTab == 1) {
                    item {
                        EmptyStateGlassCard(
                            icon = Icons.Default.Search,
                            title = "No People Found",
                            subtitle = "Try another username prefix."
                        )
                    }
                }
            }

            // Public Communities Strip / Results
            if ((searchQuery.isBlank() && selectedHashtag == null && matchingCommunities.isNotEmpty()) ||
                (searchQuery.isNotBlank() && (searchFilterTab == 0 || searchFilterTab == 3) && matchingCommunities.isNotEmpty())
            ) {
                item(key = "communities_discover") {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Public Communities", style = MaterialTheme.typography.titleSmall, color = colors.ink)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(matchingCommunities.take(10), key = { "comm_${it.id}" }) { grp ->
                                val alreadyIn = myGroupIds.contains(grp.id)
                                LiquidGlassCard(
                                    modifier = Modifier.width(210.dp),
                                    contentPadding = PaddingValues(12.dp),
                                    onClick = { if (alreadyIn) onOpenGroup(grp.id) }
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Groups, contentDescription = null, tint = colors.emerald, modifier = Modifier.size(20.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(grp.name, style = MaterialTheme.typography.titleSmall, color = colors.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                    Spacer(Modifier.height(4.dp))
                                    Text("${grp.memberCount} members • ${grp.theme}", style = MaterialTheme.typography.labelSmall, color = colors.ink2)
                                    Spacer(Modifier.height(8.dp))
                                    if (alreadyIn) {
                                        OutlinedButton(onClick = { onOpenGroup(grp.id) }, modifier = Modifier.fillMaxWidth().height(36.dp)) {
                                            Text("Open", style = MaterialTheme.typography.labelSmall)
                                        }
                                    } else {
                                        GlowingPillButton(
                                            text = "Join",
                                            accent = colors.emerald,
                                            onClick = { onJoinCommunity(grp.id) },
                                            modifier = Modifier.fillMaxWidth().height(36.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Posts Grid or Feed
            if (searchQuery.isBlank() || searchFilterTab == 0 || searchFilterTab == 2) {
                if (isLoading && displayedPosts.isEmpty()) {
                    items(3) { PostSkeletonCard() }
                } else if (displayedPosts.isEmpty()) {
                    item {
                        EmptyStateGlassCard(
                            icon = Icons.Default.Explore,
                            title = if (selectedHashtag != null) "No Posts for #$selectedHashtag"
                            else if (searchQuery.isNotBlank()) "No Matching Public Posts"
                            else "No Public Posts in $selectedCategory Yet",
                            subtitle = "Only public eligible posts appear here. Try another filter or share a public moment!"
                        )
                    }
                } else if (gridMode && searchQuery.isBlank() && selectedHashtag == null) {
                    val rows = displayedPosts.chunked(3)
                    items(rows.size, key = { "explore_grid_row_$it" }) { rowIdx ->
                        val rowPosts = rows[rowIdx]
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            rowPosts.forEach { post ->
                                ExploreMediaGridTile(
                                    post = post,
                                    onClick = {
                                        if (post.imageBase64List.isNotEmpty() || !post.videoThumbnailBase64.isNullOrBlank()) {
                                            onOpenMedia(post, 0)
                                        } else {
                                            onOpenComments(post)
                                        }
                                    },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            repeat(3 - rowPosts.size) {
                                Spacer(Modifier.weight(1f))
                            }
                        }
                    }
                } else {
                    items(displayedPosts, key = { it.id }) { post ->
                        FeedPostCard(
                            post = post,
                            currentUserId = currentUser.userId,
                            myReaction = myReactions[post.id],
                            myPollVote = myPollVotes[post.id],
                            isBookmarked = bookmarkedIds.contains(post.id),
                            onReaction = { react -> onReaction(post, react) },
                            onOpenComments = { onOpenComments(post) },
                            onShare = { onShare(post) },
                            onToggleBookmark = { onToggleBookmark(post.id) },
                            onVotePoll = { idx -> onVotePoll(post.id, idx) },
                            onEditCaption = { onEditCaption(post) },
                            onToggleCommentsDisabled = { onToggleCommentsDisabled(post) },
                            onDeletePost = { onDeletePost(post.id) },
                            onHidePost = { onHidePost(post.id) },
                            onMuteAuthor = { onMuteAuthor(post.authorId, post.authorUsername) },
                            onReportPost = { onReportPost(post) },
                            onOpenMedia = { page -> onOpenMedia(post, page) },
                            onOpenUserProfile = onOpenUserProfile,
                            onHashtagClick = { tag -> onSelectHashtag(tag) },
                            onOpenLikers = { onOpenLikers(post) }
                        )
                    }
                }
                if (isLoading && displayedPosts.isNotEmpty()) {
                    item {
                        Row(modifier = Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.Center) {
                            CircularProgressIndicator(color = colors.accent)
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(20.dp)) }
        }
    }
}

@Composable
private fun ExploreMediaGridTile(
    post: ArkPost,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = ArkThemeTokens.colors
    val previewB64 = post.imageBase64List.firstOrNull() ?: post.videoThumbnailBase64
    val bmp = rememberDecodedImageBitmap(previewB64)
    Box(
        modifier = modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(12.dp))
            .background(colors.surfaceSecondary)
            .clickable(onClick = onClick)
    ) {
        if (bmp != null) {
            Image(
                bitmap = bmp,
                contentDescription = post.altTexts.firstOrNull()?.takeIf { it.isNotBlank() } ?: post.caption.take(60),
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(8.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "@${post.authorUsername}",
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.accent,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = post.caption.ifBlank { post.pollQuestion ?: post.metaGameName ?: post.category },
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.ink,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        if (post.postType == "video") {
            Icon(
                imageVector = Icons.Default.PlayCircle,
                contentDescription = "Video",
                tint = Color.White,
                modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).size(20.dp)
            )
        } else if (post.imageBase64List.size > 1) {
            Icon(
                imageVector = Icons.Default.Collections,
                contentDescription = "Carousel",
                tint = Color.White,
                modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).size(18.dp)
            )
        } else if (post.postType == "poll") {
            Icon(
                imageVector = Icons.Default.Poll,
                contentDescription = "Poll",
                tint = colors.accent,
                modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).size(18.dp)
            )
        }
    }
}
