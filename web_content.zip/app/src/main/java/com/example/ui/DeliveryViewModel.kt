package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.model.CycleStatus
import com.example.data.model.CycleSummary
import com.example.data.model.DashboardPayoutSummary
import com.example.data.model.DeliveryEntry
import com.example.data.model.UserProfile
import com.example.data.repository.DeliveryRepository
import com.example.report.ReportExporter
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class DeliveryViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application)
    private val repository = DeliveryRepository(database.deliveryDao())

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private val monthFormat = SimpleDateFormat("yyyy-MM", Locale.getDefault())

    // Currently selected month (defaults to current month "yyyy-MM")
    private val _selectedMonth = MutableStateFlow(monthFormat.format(Date()))
    val selectedMonth: StateFlow<String> = _selectedMonth.asStateFlow()

    val todayDateString: String = dateFormat.format(Date())

    // User Profile
    val userProfile: StateFlow<UserProfile> = repository.userProfile
        .flatMapLatest { profile ->
            MutableStateFlow(profile ?: UserProfile(defaultRate = 14.0))
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = UserProfile(defaultRate = 14.0)
        )

    // Current month entries
    val currentMonthEntries: StateFlow<List<DeliveryEntry>> = _selectedMonth
        .flatMapLatest { monthKey ->
            repository.getEntriesForMonth(monthKey)
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Cycle Statuses for selected month
    val currentMonthCycleStatuses: StateFlow<List<CycleStatus>> = _selectedMonth
        .flatMapLatest { monthKey ->
            repository.getCycleStatusesForMonth(monthKey)
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Combined Dashboard Payout Summary
    val dashboardSummary: StateFlow<DashboardPayoutSummary> = combine(
        currentMonthEntries,
        currentMonthCycleStatuses,
        userProfile,
        _selectedMonth
    ) { entries, cycleStatuses, profile, monthKey ->
        computeDashboardSummary(entries, cycleStatuses, profile, monthKey)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = computeDashboardSummary(emptyList(), emptyList(), UserProfile(), monthFormat.format(Date()))
    )

    // UI Feedback message
    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    init {
        // Pre-seed or ensure default entry with 50 * 14 = ₹700
        viewModelScope.launch {
            val existing = repository.getEntryForDateSync(todayDateString)
            if (existing == null) {
                repository.saveDeliveryEntry(
                    dateString = todayDateString,
                    deliveriesCount = 50,
                    ratePerDelivery = 14.0,
                    notes = "Shift deliveries"
                )
            } else if (existing.ratePerDelivery == 18.0) {
                // Update to user's new preferred default rate of 14
                repository.saveDeliveryEntry(
                    dateString = todayDateString,
                    deliveriesCount = existing.deliveriesCount,
                    ratePerDelivery = 14.0,
                    notes = existing.notes,
                    existingId = existing.id
                )
            }
        }
    }

    fun setSelectedMonth(monthKey: String) {
        _selectedMonth.value = monthKey
    }

    fun changeMonth(offsetMonths: Int) {
        try {
            val parts = _selectedMonth.value.split("-")
            val cal = Calendar.getInstance()
            cal.set(Calendar.YEAR, parts[0].toInt())
            cal.set(Calendar.MONTH, parts[1].toInt() - 1)
            cal.add(Calendar.MONTH, offsetMonths)
            _selectedMonth.value = monthFormat.format(cal.time)
        } catch (_: Exception) {}
    }

    fun addOrUpdateEntry(
        dateString: String,
        count: Int,
        rate: Double,
        notes: String = "",
        existingId: Long = 0
    ) {
        viewModelScope.launch {
            repository.saveDeliveryEntry(
                dateString = dateString,
                deliveriesCount = count,
                ratePerDelivery = rate,
                notes = notes,
                existingId = existingId
            )
            _userMessage.value = "Saved: $count deliveries @ ₹${rate.toInt()} = ₹${(count * rate).toInt()}"
        }
    }

    fun quickIncrementToday(amount: Int) {
        viewModelScope.launch {
            val existing = repository.getEntryForDateSync(todayDateString)
            val currentCount = existing?.deliveriesCount ?: 0
            val rate = existing?.ratePerDelivery ?: userProfile.value.defaultRate
            val newCount = (currentCount + amount).coerceAtLeast(0)

            repository.saveDeliveryEntry(
                dateString = todayDateString,
                deliveriesCount = newCount,
                ratePerDelivery = rate,
                notes = existing?.notes ?: "",
                existingId = existing?.id ?: 0
            )
        }
    }

    fun deleteEntry(entry: DeliveryEntry) {
        viewModelScope.launch {
            repository.deleteEntry(entry)
            _userMessage.value = "Deleted entry for ${entry.dateString}"
        }
    }

    fun updateCycleStatus(cycleNumber: Int, newStatus: String, paidAmount: Double = 0.0) {
        viewModelScope.launch {
            repository.updateCycleStatus(
                monthKey = _selectedMonth.value,
                cycleNumber = cycleNumber,
                status = newStatus,
                paidAmount = paidAmount
            )
            _userMessage.value = "Cycle $cycleNumber status: $newStatus"
        }
    }

    fun saveProfile(agentName: String, defaultRate: Double, vehicleNumber: String) {
        viewModelScope.launch {
            val updated = userProfile.value.copy(
                agentName = agentName.trim().ifEmpty { "Delivery Partner" },
                defaultRate = if (defaultRate > 0) defaultRate else 14.0,
                vehicleNumber = vehicleNumber.trim()
            )
            repository.saveUserProfile(updated)
            _userMessage.value = "Profile updated: ₹${updated.defaultRate.toInt()}/delivery"
        }
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    fun exportPdf(context: Context, cycleFilter: Int? = null): File? {
        val entries = if (cycleFilter != null && cycleFilter in 1..3) {
            currentMonthEntries.value.filter { it.cycleNumber == cycleFilter }
        } else {
            currentMonthEntries.value
        }
        val summaries = listOf(
            dashboardSummary.value.cycle1Summary,
            dashboardSummary.value.cycle2Summary,
            dashboardSummary.value.cycle3Summary
        ).filter { cycleFilter == null || it.cycleNumber == cycleFilter }

        val periodTitle = if (cycleFilter != null) {
            "Cycle $cycleFilter (${DeliveryRepository.getCycleDateRangeLabel(cycleFilter, _selectedMonth.value)}) - ${_selectedMonth.value}"
        } else {
            "Full Month ${_selectedMonth.value}"
        }

        return ReportExporter.generatePdf(
            context = context,
            entries = entries,
            cycleSummaries = summaries,
            userProfile = userProfile.value,
            periodTitle = periodTitle
        )
    }

    fun exportExcelCsv(context: Context, cycleFilter: Int? = null): File? {
        val entries = if (cycleFilter != null && cycleFilter in 1..3) {
            currentMonthEntries.value.filter { it.cycleNumber == cycleFilter }
        } else {
            currentMonthEntries.value
        }
        val summaries = listOf(
            dashboardSummary.value.cycle1Summary,
            dashboardSummary.value.cycle2Summary,
            dashboardSummary.value.cycle3Summary
        ).filter { cycleFilter == null || it.cycleNumber == cycleFilter }

        val periodTitle = if (cycleFilter != null) {
            "Cycle $cycleFilter (${DeliveryRepository.getCycleDateRangeLabel(cycleFilter, _selectedMonth.value)}) - ${_selectedMonth.value}"
        } else {
            "Full Month ${_selectedMonth.value}"
        }

        return ReportExporter.generateCsvExcel(
            context = context,
            entries = entries,
            cycleSummaries = summaries,
            userProfile = userProfile.value,
            periodTitle = periodTitle
        )
    }

    private fun computeDashboardSummary(
        entries: List<DeliveryEntry>,
        cycleStatuses: List<CycleStatus>,
        profile: UserProfile,
        monthKey: String
    ): DashboardPayoutSummary {
        val todayEntry = entries.find { it.dateString == todayDateString }
        val todayDeliveries = todayEntry?.deliveriesCount ?: 0
        val todayRate = todayEntry?.ratePerDelivery ?: profile.defaultRate
        val todayEarnings = todayEntry?.totalEarnings ?: 0.0

        val cal = Calendar.getInstance()
        val currentDay = cal.get(Calendar.DAY_OF_MONTH)
        val currentCycle = DeliveryRepository.getCycleForDay(currentDay)

        fun buildCycleSummary(cycleNum: Int, label: String, dateRange: String): CycleSummary {
            val cycleEntries = entries.filter { it.cycleNumber == cycleNum }
            val totalDelivs = cycleEntries.sumOf { it.deliveriesCount }
            val totalEarnings = cycleEntries.sumOf { it.totalEarnings }
            val statusObj = cycleStatuses.find { it.cycleNumber == cycleNum }
            val status = statusObj?.status ?: "PENDING"
            val isCurrent = (monthKey == monthFormat.format(Date())) && (cycleNum == currentCycle)

            return CycleSummary(
                cycleNumber = cycleNum,
                label = label,
                dateRangeText = dateRange,
                totalDeliveries = totalDelivs,
                totalEarnings = totalEarnings,
                entryCount = cycleEntries.size,
                status = status,
                isCurrent = isCurrent
            )
        }

        val c1 = buildCycleSummary(1, "Cycle 1 (1 to 10)", "1st - 10th")
        val c2 = buildCycleSummary(2, "Cycle 2 (11 to 20)", "11th - 20th")
        val c3 = buildCycleSummary(3, "Cycle 3 (21 to 31)", "21st - End of Month")

        val monthDeliveries = entries.sumOf { it.deliveriesCount }
        val monthEarnings = entries.sumOf { it.totalEarnings }

        var settled = 0.0
        var pending = 0.0

        listOf(c1, c2, c3).forEach { c ->
            if (c.status == "PAID") {
                settled += c.totalEarnings
            } else {
                pending += c.totalEarnings
            }
        }

        return DashboardPayoutSummary(
            todayDeliveries = todayDeliveries,
            todayRate = todayRate,
            todayEarnings = todayEarnings,
            monthKey = monthKey,
            monthDeliveries = monthDeliveries,
            monthTotalEarnings = monthEarnings,
            cycle1Summary = c1,
            cycle2Summary = c2,
            cycle3Summary = c3,
            currentCycleNumber = currentCycle,
            pendingPayoutTotal = pending,
            settledPayoutTotal = settled
        )
    }
}
