package com.example.ui.screens

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BitDepth
import com.example.model.RecordingItem
import com.example.ui.components.DeleteConfirmDialog
import com.example.ui.components.PlaybackWaveformBar
import com.example.ui.components.RenameRecordingDialog
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.LedRed
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.StudioBlack
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioDarkBg
import com.example.ui.theme.StudioDivider
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.StudioScreen
import com.example.viewmodel.StudioViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordingsLibraryScreen(
    viewModel: StudioViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onNavigateBack() }

    val context = LocalContext.current
    val recordings by viewModel.recordings.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val currentPlayingId by viewModel.currentPlayingId.collectAsState()
    val currentPosMs by viewModel.playerCurrentPositionMs.collectAsState()
    val totalDurMs by viewModel.playerDurationMs.collectAsState()
    val waveformsMap by viewModel.recordingWaveforms.collectAsState()

    var itemToRename by remember { mutableStateOf<RecordingItem?>(null) }
    var itemToDelete by remember { mutableStateOf<RecordingItem?>(null) }

    if (itemToRename != null) {
        val item = itemToRename!!
        RenameRecordingDialog(
            initialName = item.fileName,
            onRename = { newName ->
                viewModel.renameRecording(item, newName)
                itemToRename = null
            },
            onDismiss = { itemToRename = null }
        )
    }

    if (itemToDelete != null) {
        val item = itemToDelete!!
        DeleteConfirmDialog(
            fileName = item.fileName,
            onConfirmDelete = {
                viewModel.deleteRecording(item)
                itemToDelete = null
            },
            onDismiss = { itemToDelete = null }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(StudioDarkBg)
    ) {
        // TOP HEADER
        Surface(
            color = StudioBlack,
            shadowElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("back_to_studio_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimary
                        )
                    }
                    Column {
                        Text(
                            text = "STUDIO LIBRARY",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = TextPrimary
                        )
                        Text(
                            text = "${recordings.size} High-Res WAV Master Tracks",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }
            }
        }

        // ACTIVE PLAYBACK CONTROL CONSOLE (visible when a track is chosen)
        val activePlayingItem = recordings.firstOrNull { it.id == currentPlayingId }
        AnimatedVisibility(visible = activePlayingItem != null) {
            if (activePlayingItem != null) {
                ActivePlayerConsole(
                    item = activePlayingItem,
                    isPlaying = isPlaying,
                    currentPosMs = currentPosMs,
                    totalDurMs = totalDurMs,
                    peaks = waveformsMap[activePlayingItem.id] ?: emptyList(),
                    onPlayPause = {
                        if (isPlaying) viewModel.pausePlayback() else viewModel.resumePlayback()
                    },
                    onSeek = { fraction ->
                        val targetMs = (fraction * totalDurMs).toInt()
                        viewModel.seekPlayback(targetMs)
                    },
                    onRewind = {
                        val newPos = (currentPosMs - 10000).coerceAtLeast(0)
                        viewModel.seekPlayback(newPos)
                    },
                    onFastForward = {
                        val newPos = (currentPosMs + 10000).coerceAtMost(totalDurMs)
                        viewModel.seekPlayback(newPos)
                    },
                    onStop = { viewModel.stopPlayback() }
                )
            }
        }

        // RECORDINGS LIST OR EMPTY STATE
        if (recordings.isEmpty()) {
            EmptyRecordingsState(onGoToStudio = onNavigateBack)
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 14.dp, vertical = 10.dp)
                    .navigationBarsPadding(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(recordings, key = { it.id }) { item ->
                    val isCurrent = item.id == currentPlayingId
                    RecordingCardItem(
                        item = item,
                        isCurrentPlaying = isCurrent,
                        isPlaying = isPlaying && isCurrent,
                        peaks = waveformsMap[item.id] ?: emptyList(),
                        onPlayClick = {
                            if (isCurrent && isPlaying) {
                                viewModel.pausePlayback()
                            } else if (isCurrent && !isPlaying) {
                                viewModel.resumePlayback()
                            } else {
                                viewModel.playRecording(item)
                            }
                        },
                        onShareClick = {
                            val shareIntent = viewModel.createShareIntent(item)
                            context.startActivity(shareIntent)
                        },
                        onRenameClick = { itemToRename = item },
                        onDeleteClick = { itemToDelete = item }
                    )
                }
            }
        }
    }
}

@Composable
private fun ActivePlayerConsole(
    item: RecordingItem,
    isPlaying: Boolean,
    currentPosMs: Int,
    totalDurMs: Int,
    peaks: List<Float>,
    onPlayPause: () -> Unit,
    onSeek: (Float) -> Unit,
    onRewind: () -> Unit,
    onFastForward: () -> Unit,
    onStop: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = StudioSurfaceElevated),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.5f)),
        modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.fileName.removeSuffix(".wav"),
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = TextPrimary,
                        maxLines = 1
                    )
                    Text(
                        text = "Now Playing • ${item.bitDepth.label}",
                        fontSize = 11.sp,
                        color = EmeraldLight
                    )
                }
                IconButton(onClick = onStop) {
                    Icon(imageVector = Icons.Default.Stop, contentDescription = "Stop", tint = TextSecondary)
                }
            }

            // Interactive Waveform Scrubber
            val progress = if (totalDurMs > 0) (currentPosMs.toFloat() / totalDurMs).coerceIn(0f, 1f) else 0f
            PlaybackWaveformBar(
                peaks = peaks,
                progress = progress,
                onSeek = onSeek,
                height = 54.dp
            )

            // Time & Controls Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Time elapsed / total
                Text(
                    text = "${formatTimeMs(currentPosMs.toLong())} / ${formatTimeMs(totalDurMs.toLong())}",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    color = TextSecondary
                )

                // Transport controls
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onRewind) {
                        Icon(imageVector = Icons.Default.FastRewind, contentDescription = "Rewind 10s", tint = TextPrimary)
                    }

                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(EmeraldPrimary)
                            .clickable { onPlayPause() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            tint = StudioBlack,
                            modifier = Modifier.size(26.dp)
                        )
                    }

                    IconButton(onClick = onFastForward) {
                        Icon(imageVector = Icons.Default.FastForward, contentDescription = "Forward 10s", tint = TextPrimary)
                    }
                }
            }
        }
    }
}

@Composable
private fun RecordingCardItem(
    item: RecordingItem,
    isCurrentPlaying: Boolean,
    isPlaying: Boolean,
    peaks: List<Float>,
    onPlayClick: () -> Unit,
    onShareClick: () -> Unit,
    onRenameClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isCurrentPlaying) StudioSurfaceElevated else StudioSurface
        ),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isCurrentPlaying) EmeraldPrimary else StudioBorder
        ),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("recording_card_${item.fileName}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Play / Pause Circle Button
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(if (isPlaying) EmeraldPrimary else StudioBlack)
                        .border(1.dp, if (isPlaying) EmeraldPrimary else StudioBorder, CircleShape)
                        .clickable { onPlayClick() }
                        .testTag("play_button_${item.fileName}"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = "Play/Pause",
                        tint = if (isPlaying) StudioBlack else EmeraldPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                // Title & Metadata
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.fileName.removeSuffix(".wav"),
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = TextPrimary,
                        maxLines = 1
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Bit depth badge
                        Text(
                            text = if (item.bitDepth == BitDepth.BIT_24) "24-BIT" else "16-BIT",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            color = if (item.bitDepth == BitDepth.BIT_24) MetallicGold else EmeraldPrimary
                        )
                        Text(text = "•", color = TextMuted, fontSize = 10.sp)
                        Text(
                            text = formatTimeMs(item.durationMs),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                        Text(text = "•", color = TextMuted, fontSize = 10.sp)
                        Text(
                            text = formatFileSize(item.fileSizeBytes),
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }
                }

                // Action Icons (Share, Rename, Delete)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onShareClick,
                        modifier = Modifier.size(34.dp).testTag("share_button_${item.fileName}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Share",
                            tint = TextSecondary,
                            modifier = Modifier.size(17.dp)
                        )
                    }
                    IconButton(
                        onClick = onRenameClick,
                        modifier = Modifier.size(34.dp).testTag("rename_button_${item.fileName}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Rename",
                            tint = TextSecondary,
                            modifier = Modifier.size(17.dp)
                        )
                    }
                    IconButton(
                        onClick = onDeleteClick,
                        modifier = Modifier.size(34.dp).testTag("delete_button_${item.fileName}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete",
                            tint = LedRed.copy(alpha = 0.8f),
                            modifier = Modifier.size(17.dp)
                        )
                    }
                }
            }

            // Mini Waveform Line Preview
            if (peaks.isNotEmpty()) {
                PlaybackWaveformBar(
                    peaks = peaks,
                    progress = if (isCurrentPlaying) 0.5f else 0f,
                    onSeek = {},
                    height = 24.dp
                )
            }

            // Formatted Date stamp
            val dateStr = SimpleDateFormat("MMM dd, yyyy • hh:mm a", Locale.getDefault()).format(Date(item.timestamp))
            Text(
                text = dateStr,
                fontSize = 10.sp,
                color = TextMuted
            )
        }
    }
}

@Composable
private fun EmptyRecordingsState(onGoToStudio: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(StudioSurface)
                    .border(1.dp, StudioBorder, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Mic,
                    contentDescription = null,
                    tint = EmeraldPrimary,
                    modifier = Modifier.size(38.dp)
                )
            }
            Text(
                text = "No Studio Recordings Yet",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = TextPrimary
            )
            Text(
                text = "Head to the Studio Dashboard to record your first Naat recitation with real-time DD-3 delay, hall reverb, and studio WAV export.",
                fontSize = 13.sp,
                color = TextSecondary,
                lineHeight = 18.sp,
                modifier = Modifier.padding(horizontal = 24.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Button(
                onClick = onGoToStudio,
                colors = ButtonDefaults.buttonColors(
                    containerColor = EmeraldPrimary,
                    contentColor = StudioBlack
                ),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Open Studio Console", fontWeight = FontWeight.Bold)
            }
        }
    }
}

private fun formatTimeMs(ms: Long): String {
    val totalSec = ms / 1000
    val min = totalSec / 60
    val sec = totalSec % 60
    return String.format("%02d:%02d", min, sec)
}

private fun formatFileSize(bytes: Long): String {
    val kb = bytes / 1024f
    val mb = kb / 1024f
    return if (mb >= 1.0f) {
        String.format("%.1f MB", mb)
    } else {
        String.format("%d KB", kb.toInt())
    }
}
