package com.example.ui

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.FlappyDroidCanvas
import com.example.game.GameUiState
import com.example.game.GameViewModel
import com.example.model.Difficulty
import com.example.model.GameStatus
import com.example.ui.theme.AndroidDarkGreen
import com.example.ui.theme.AndroidDarkNavy
import com.example.ui.theme.AndroidGreen
import com.example.ui.theme.AndroidLightGreen

@Composable
fun GameScreen(
    viewModel: GameViewModel,
    uiState: GameUiState,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(uiState.status) {
                detectTapGestures(
                    onTap = {
                        viewModel.onScreenTap()
                    }
                )
            }
    ) {
        val screenWidthDp = maxWidth.value
        val screenHeightDp = maxHeight.value

        // Continuous game physics loop
        LaunchedEffect(uiState.status) {
            var lastFrameTime = 0L
            while (true) {
                withFrameNanos { frameTimeNanos ->
                    if (lastFrameTime != 0L) {
                        val dt = ((frameTimeNanos - lastFrameTime) / 1_000_000_000.0f).coerceIn(0.001f, 0.05f)
                        viewModel.tick(dt, screenWidthDp, screenHeightDp)
                    }
                    lastFrameTime = frameTimeNanos
                }
            }
        }

        // 1. Core Canvas Game Layer
        FlappyDroidCanvas(
            mascot = uiState.mascot,
            pipes = uiState.pipes,
            particles = uiState.particles,
            skin = uiState.skin,
            groundOffset = uiState.groundOffset,
            cloudOffset = uiState.cloudOffset,
            modifier = Modifier.fillMaxSize()
        )

        // 2. Top HUD (Visible during Playing and Ready)
        TopGameBar(
            uiState = uiState,
            onOpenSettings = { viewModel.openSettings() },
            onPauseGame = { viewModel.pauseGame() },
            modifier = Modifier
                .align(Alignment.TopCenter)
                .windowInsetsPadding(WindowInsets.statusBars)
        )

        // 3. Ready / Start Overlay
        if (uiState.status == GameStatus.READY) {
            ReadyOverlay(
                uiState = uiState,
                onSelectDifficulty = { viewModel.setDifficulty(it) },
                onStartGame = { viewModel.startGame() },
                onOpenSettings = { viewModel.openSettings() },
                modifier = Modifier.align(Alignment.Center)
            )
        }

        // 4. Paused Overlay
        if (uiState.status == GameStatus.PAUSED) {
            PausedOverlay(
                onResume = { viewModel.resumeGame() },
                onRestart = { viewModel.readyGame() },
                onOpenSettings = { viewModel.openSettings() },
                modifier = Modifier.align(Alignment.Center)
            )
        }

        // 5. Game Over Overlay
        if (uiState.status == GameStatus.GAME_OVER) {
            GameOverOverlay(
                uiState = uiState,
                onPlayAgain = { viewModel.readyGame() },
                onOpenSettings = { viewModel.openSettings() },
                onShare = {
                    val shareText = "I scored ${uiState.score} points with the Android Mascot in Flappy Droid! Best: ${uiState.highScore}."
                    val sendIntent = Intent().apply {
                        action = Intent.ACTION_SEND
                        putExtra(Intent.EXTRA_TEXT, shareText)
                        type = "text/plain"
                    }
                    val shareIntent = Intent.createChooser(sendIntent, "Share Score")
                    context.startActivity(shareIntent)
                },
                modifier = Modifier.align(Alignment.Center)
            )
        }

        // 6. Settings Bottom Sheet
        if (uiState.isSettingsOpen) {
            SettingsSheet(
                uiState = uiState,
                viewModel = viewModel
            )
        }
    }
}

@Composable
private fun TopGameBar(
    uiState: GameUiState,
    onOpenSettings: () -> Unit,
    onPauseGame: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // High Score / Difficulty Pill
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color.Black.copy(alpha = 0.35f),
            modifier = Modifier.clip(RoundedCornerShape(20.dp))
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.EmojiEvents,
                    contentDescription = null,
                    tint = Color(0xFFFFD700),
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "BEST: ${uiState.highScore}",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .size(4.dp)
                        .background(Color.White.copy(alpha = 0.5f), CircleShape)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = uiState.difficulty.title.uppercase(),
                    color = AndroidLightGreen,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 11.sp
                )
            }
        }

        // Big Score Number while playing
        if (uiState.status == GameStatus.PLAYING) {
            Text(
                text = "${uiState.score}",
                fontSize = 48.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.testTag("game_current_score")
            )
        }

        // Action Buttons: Pause & Settings
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (uiState.status == GameStatus.PLAYING) {
                Surface(
                    shape = CircleShape,
                    color = Color.Black.copy(alpha = 0.4f),
                    modifier = Modifier.size(44.dp)
                ) {
                    IconButton(
                        onClick = onPauseGame,
                        modifier = Modifier.testTag("pause_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Pause,
                            contentDescription = "Pause Game",
                            tint = Color.White
                        )
                    }
                }
            }

            Surface(
                shape = CircleShape,
                color = Color.Black.copy(alpha = 0.4f),
                modifier = Modifier.size(44.dp)
            ) {
                IconButton(
                    onClick = onOpenSettings,
                    modifier = Modifier.testTag("settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Settings & Updates",
                        tint = Color.White
                    )
                }
            }
        }
    }
}

@Composable
private fun ReadyOverlay(
    uiState: GameUiState,
    onSelectDifficulty: (Difficulty) -> Unit,
    onStartGame: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val tapScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Column(
        modifier = modifier
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Title banner
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = AndroidDarkNavy.copy(alpha = 0.88f),
            border = androidx.compose.foundation.BorderStroke(2.dp, AndroidGreen),
            shadowElevation = 8.dp,
            modifier = Modifier.padding(bottom = 24.dp)
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 28.dp, vertical = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.FlightTakeoff,
                        contentDescription = null,
                        tint = AndroidGreen,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "FLAPPY DROID",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        letterSpacing = 2.sp
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Android Mascot Edition",
                    style = MaterialTheme.typography.bodySmall,
                    color = AndroidLightGreen
                )
            }
        }

        // Tap to fly prompt
        Surface(
            shape = RoundedCornerShape(30.dp),
            color = AndroidGreen,
            shadowElevation = 6.dp,
            modifier = Modifier
                .scale(tapScale)
                .clip(RoundedCornerShape(30.dp))
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = AndroidDarkNavy,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "TAP SCREEN TO FLY",
                    fontWeight = FontWeight.ExtraBold,
                    color = AndroidDarkNavy,
                    fontSize = 16.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Quick difficulty switcher
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color.Black.copy(alpha = 0.5f),
            modifier = Modifier.padding(bottom = 16.dp)
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "DIFFICULTY",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.White.copy(alpha = 0.7f)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Difficulty.values().forEach { diff ->
                        val selected = uiState.difficulty == diff
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (selected) AndroidGreen else Color.White.copy(alpha = 0.15f),
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .pointerInput(diff) {
                                    detectTapGestures { onSelectDifficulty(diff) }
                                }
                        ) {
                            Text(
                                text = diff.title,
                                color = if (selected) AndroidDarkNavy else Color.White,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }

        // Check for updates quick link
        OutlinedButton(
            onClick = onOpenSettings,
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = Color.White
            ),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.6f)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.testTag("ready_settings_button")
        ) {
            Icon(
                imageVector = Icons.Default.Settings,
                contentDescription = null,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text("Settings & Updates")
        }
    }
}

@Composable
private fun PausedOverlay(
    onResume: () -> Unit,
    onRestart: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = AndroidDarkNavy.copy(alpha = 0.92f),
        border = androidx.compose.foundation.BorderStroke(2.dp, AndroidGreen.copy(alpha = 0.5f)),
        shadowElevation = 16.dp,
        modifier = modifier
            .padding(24.dp)
            .fillMaxWidth()
            .testTag("paused_overlay")
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "GAME PAUSED",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = onResume,
                colors = ButtonDefaults.buttonColors(containerColor = AndroidGreen),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("resume_button")
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = AndroidDarkNavy
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Resume",
                    color = AndroidDarkNavy,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedButton(
                onClick = onRestart,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = null,
                    tint = Color.White
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Restart Game", color = Color.White)
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedButton(
                onClick = onOpenSettings,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = null,
                    tint = Color.White
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Settings & Updates", color = Color.White)
            }
        }
    }
}

@Composable
private fun GameOverOverlay(
    uiState: GameUiState,
    onPlayAgain: () -> Unit,
    onOpenSettings: () -> Unit,
    onShare: () -> Unit,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = true,
        enter = fadeIn() + scaleIn(),
        modifier = modifier
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = AndroidDarkNavy.copy(alpha = 0.95f),
            border = androidx.compose.foundation.BorderStroke(2.dp, AndroidGreen),
            shadowElevation = 20.dp,
            modifier = Modifier
                .padding(24.dp)
                .fillMaxWidth()
                .testTag("game_over_card")
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Game Over banner
                Text(
                    text = "GAME OVER",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFFFF5252),
                    letterSpacing = 2.sp
                )

                if (uiState.isNewHighScore) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFFFFD700)
                    ) {
                        Text(
                            text = "★ NEW BEST SCORE! ★",
                            color = AndroidDarkNavy,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Scoreboard Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.45f)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Medal badge
                        MedalBadge(score = uiState.score)

                        // Score
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "SCORE",
                                style = MaterialTheme.typography.labelMedium,
                                color = Color.White.copy(alpha = 0.7f),
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${uiState.score}",
                                fontSize = 42.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                        }

                        // Best
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "BEST",
                                style = MaterialTheme.typography.labelMedium,
                                color = Color.White.copy(alpha = 0.7f),
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${uiState.highScore}",
                                fontSize = 42.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFFFFD700)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(22.dp))

                // Play Again Button
                Button(
                    onClick = onPlayAgain,
                    colors = ButtonDefaults.buttonColors(containerColor = AndroidGreen),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("play_again_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = null,
                        tint = AndroidDarkNavy,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "PLAY AGAIN",
                        color = AndroidDarkNavy,
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onShare,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("share_score_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Share")
                    }

                    OutlinedButton(
                        onClick = onOpenSettings,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("game_over_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Updates")
                    }
                }
            }
        }
    }
}

@Composable
private fun MedalBadge(score: Int) {
    val (medalTitle, medalColor) = when {
        score >= 40 -> "PLATINUM" to Color(0xFFE5E4E2)
        score >= 25 -> "GOLD" to Color(0xFFFFD700)
        score >= 10 -> "SILVER" to Color(0xFFC0C0C0)
        score >= 3 -> "BRONZE" to Color(0xFFCD7F32)
        else -> "NO MEDAL" to Color.Gray
    }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .background(medalColor.copy(alpha = 0.25f), CircleShape)
                .border(2.dp, medalColor, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.EmojiEvents,
                contentDescription = null,
                tint = medalColor,
                modifier = Modifier.size(26.dp)
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = medalTitle,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = medalColor,
            fontSize = 10.sp
        )
    }
}
