package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.local.ProgramEntity
import com.example.ui.MainViewModel
import com.example.ui.components.CharghatEmblem
import com.example.ui.components.DropdownSelector
import com.example.ui.model.CharghatData
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.TextHint
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ProgramsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val programs by viewModel.allPrograms.collectAsState()
    val isAdminLoggedIn by viewModel.isAdminLoggedIn.collectAsState()

    var selectedFilter by remember { mutableStateOf("সকল") } // "সকল", "আসন্ন", "চলমান", "সম্পন্ন"
    var showCreateDialog by remember { mutableStateOf(false) }
    var selectedPhotoToEnlarge by remember { mutableStateOf<String?>(null) }
    var programToDelete by remember { mutableStateOf<ProgramEntity?>(null) }

    val filteredList = remember(programs, selectedFilter) {
        if (selectedFilter == "সকল") programs
        else programs.filter { it.status == selectedFilter }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF3F4F6))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            // Header Banner
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        CharghatEmblem(size = 44.dp)
                        Column {
                            Text(
                                text = "দলীয় কর্মসূচি ও ইভেন্ট গ্যালারি",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "ছবি ও ভিডিও সহ সাম্প্রতিক কার্যক্রম",
                                fontSize = 12.sp,
                                color = TextSecondary,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    Button(
                        onClick = { showCreateDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D)),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("btn_add_program_header")
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("পোস্ট করুন", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Status Filter Chips
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val filters = listOf("সকল", "আসন্ন", "চলমান", "সম্পন্ন")
                items(filters) { filter ->
                    val isSelected = selectedFilter == filter
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedFilter = filter },
                        label = {
                            Text(
                                text = filter,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 13.sp
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFFDCFCE7),
                            selectedLabelColor = Color(0xFF15803D),
                            containerColor = Color.White,
                            labelColor = TextPrimary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = if (isSelected) Color(0xFF16A34A) else Color(0xFFE5E7EB)
                        ),
                        shape = RoundedCornerShape(20.dp)
                    )
                }
            }

            // Programs List
            if (filteredList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Event,
                            contentDescription = null,
                            tint = TextMuted,
                            modifier = Modifier.size(48.dp)
                        )
                        Text(
                            text = "কোন কর্মসূচি পাওয়া যায়নি",
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "নতুন কর্মসূচি, ছবি ও ভিডিও আপলোড করতে ওপরের বাটনে চাপুন",
                            fontSize = 12.sp,
                            color = TextHint
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(filteredList, key = { it.id }) { program ->
                        ProgramCard(
                            program = program,
                            isAdminLoggedIn = isAdminLoggedIn,
                            onPhotoClick = { selectedPhotoToEnlarge = it },
                            onDeleteClick = { programToDelete = program }
                        )
                    }
                }
            }
        }

        // Floating Action Button to Add New Program
        FloatingActionButton(
            onClick = { showCreateDialog = true },
            containerColor = Color(0xFF15803D),
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .testTag("fab_add_program")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(imageVector = Icons.Default.AddPhotoAlternate, contentDescription = "ছবি ও ভিডিও সহ কর্মসূচি পোস্ট করুন")
                Text("নতুন কর্মসূচি", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }

        // Dialog: Create / Upload New Program
        if (showCreateDialog) {
            CreateProgramDialog(
                onDismiss = { showCreateDialog = false },
                onSubmit = { newProgram ->
                    viewModel.insertProgram(newProgram)
                    showCreateDialog = false
                    Toast.makeText(context, "কর্মসূচি সফলভাবে পোস্ট হয়েছে!", Toast.LENGTH_SHORT).show()
                }
            )
        }

        // Dialog: Enlarge Image
        if (selectedPhotoToEnlarge != null) {
            Dialog(onDismissRequest = { selectedPhotoToEnlarge = null }) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.Black)
                        .padding(8.dp)
                ) {
                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data(selectedPhotoToEnlarge)
                            .crossfade(true)
                            .build(),
                        contentDescription = "বড় করে প্রদর্শিত ছবি",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(380.dp)
                    )
                    IconButton(
                        onClick = { selectedPhotoToEnlarge = null },
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .background(Color(0x80000000), CircleShape)
                    ) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                }
            }
        }

        // Confirm Delete Dialog
        if (programToDelete != null) {
            AlertDialog(
                onDismissRequest = { programToDelete = null },
                title = { Text("কর্মসূচি মুছে ফেলতে চান?", fontWeight = FontWeight.Bold) },
                text = { Text("এই কর্মসূচিটি ড্যাশবোর্ড ও গ্যালারি থেকে স্থায়ীভাবে মুছে যাবে।") },
                confirmButton = {
                    Button(
                        onClick = {
                            programToDelete?.let { viewModel.deleteProgram(it) }
                            programToDelete = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                    ) {
                        Text("মুছে ফেলুন")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { programToDelete = null }) {
                        Text("বাতিল")
                    }
                }
            )
        }
    }
}

@Composable
fun ProgramCard(
    program: ProgramEntity,
    isAdminLoggedIn: Boolean,
    onPhotoClick: (String) -> Unit,
    onDeleteClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Status & Unit Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Unit Name badge
                Surface(
                    color = Color(0xFFF3F4F6),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = program.unit,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF374151),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Status Badge
                    val (statusBg, statusFg) = when (program.status) {
                        "আসন্ন" -> Pair(Color(0xFFDCFCE7), Color(0xFF15803D))
                        "চলমান" -> Pair(Color(0xFFDBEAFE), Color(0xFF1E40AF))
                        else -> Pair(Color(0xFFF3E8FF), Color(0xFF6B21A8))
                    }
                    Surface(
                        color = statusBg,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = program.status,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = statusFg,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }

                    if (isAdminLoggedIn) {
                        IconButton(
                            onClick = onDeleteClick,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete program",
                                tint = Color(0xFFDC2626),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Program Title
            Text(
                text = program.title,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                lineHeight = 22.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Meta Info: Date, Time & Location
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                if (program.date.isNotBlank()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(imageVector = Icons.Default.CalendarMonth, contentDescription = null, tint = Color(0xFF15803D), modifier = Modifier.size(15.dp))
                        Text(text = program.date, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextSecondary)
                    }
                }

                if (program.time.isNotBlank()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Schedule, contentDescription = null, tint = Color(0xFF2563EB), modifier = Modifier.size(15.dp))
                        Text(text = program.time, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextSecondary)
                    }
                }
            }

            if (program.location.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(imageVector = Icons.Default.LocationOn, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(15.dp))
                    Text(text = program.location, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = TextSecondary)
                }
            }

            if (program.description.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = program.description,
                    fontSize = 13.sp,
                    color = TextPrimary,
                    lineHeight = 18.sp
                )
            }

            // Attached Photo Section
            if (program.photoUri.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFF3F4F6))
                        .clickable { onPhotoClick(program.photoUri) }
                ) {
                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data(program.photoUri)
                            .crossfade(true)
                            .build(),
                        contentDescription = "কর্মসূচির ছবি",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                    // Zoom indicator badge
                    Surface(
                        color = Color(0x99000000),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Image, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                            Text("ছবি দেখুন", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }

            // Attached Video Section
            if (program.videoUri.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            try {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(program.videoUri))
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "ভিডিও লিংক ওপেন করা সম্ভব হয়নি", Toast.LENGTH_SHORT).show()
                            }
                        },
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E24))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .background(
                                Brush.horizontalGradient(
                                    listOf(Color(0xFF0F172A), Color(0xFF1E293B))
                                )
                            )
                            .padding(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFDC2626)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PlayArrow,
                                        contentDescription = "ভিডিও প্লে করুন",
                                        tint = Color.White,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }

                                Column {
                                    Text(
                                        text = "কর্মসূচির ভিডিও দেখুন",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = Color.White
                                    )
                                    Text(
                                        text = program.videoUri,
                                        fontSize = 11.sp,
                                        color = Color(0xFF94A3B8),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }

                            Icon(
                                imageVector = Icons.Default.OpenInNew,
                                contentDescription = null,
                                tint = Color(0xFFE2E8F0),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Dialog to add a new program with photo & video upload mechanisms
 */
@Composable
fun CreateProgramDialog(
    onDismiss: () -> Unit,
    onSubmit: (ProgramEntity) -> Unit
) {
    val context = LocalContext.current

    var title by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf(CharghatData.units.first()) }
    var date by remember {
        val today = SimpleDateFormat("dd MMMM, yyyy", Locale("bn", "BD")).format(Date())
        mutableStateOf(today)
    }
    var time by remember { mutableStateOf("বিকাল ৪:০০ টা") }
    var location by remember { mutableStateOf("চারঘাট উপজেলা") }
    var status by remember { mutableStateOf("আসন্ন") }
    var description by remember { mutableStateOf("") }

    // Media states
    var selectedPhotoUri by remember { mutableStateOf<Uri?>(null) }
    var photoUrlInput by remember { mutableStateOf("") }
    var selectedVideoUri by remember { mutableStateOf<Uri?>(null) }
    var videoUrlInput by remember { mutableStateOf("") }

    // Android Zero-permission Photo Picker for images
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedPhotoUri = uri
            photoUrlInput = "" // Clear manual URL if picked from gallery
        }
    }

    // Android Zero-permission Video Picker for videos
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedVideoUri = uri
            videoUrlInput = "" // Clear manual URL if picked from gallery
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp)),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Title & Close Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "নতুন কর্মসূচি ও মিডিয়া পোস্ট",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                // 1. Program Title
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("কর্মসূচির শিরোনাম *") },
                    placeholder = { Text("যেমন: ৭ই মার্চ ঐতিহাসিক সমাবেশ বা বৃক্ষরোপণ") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = Color(0xFF15803D),
                        unfocusedBorderColor = Color(0xFF9CA3AF)
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                // 2. Unit Dropdown
                DropdownSelector(
                    label = "শাখা / ইউনিট *",
                    items = CharghatData.units,
                    selectedItem = unit,
                    onItemSelected = { unit = it }
                )

                // 3. Status Dropdown
                DropdownSelector(
                    label = "অবস্থা *",
                    items = listOf("আসন্ন", "চলমান", "সম্পন্ন"),
                    selectedItem = status,
                    onItemSelected = { status = it }
                )

                // 4. Date & Time
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = date,
                        onValueChange = { date = it },
                        label = { Text("তারিখ") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = Color(0xFF15803D),
                            unfocusedBorderColor = Color(0xFF9CA3AF)
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = time,
                        onValueChange = { time = it },
                        label = { Text("সময়") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = Color(0xFF15803D),
                            unfocusedBorderColor = Color(0xFF9CA3AF)
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    )
                }

                // 5. Location
                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it },
                    label = { Text("স্থান") },
                    placeholder = { Text("যেমন: চারঘাট পাইলট স্কুল মাঠ") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = Color(0xFF15803D),
                        unfocusedBorderColor = Color(0xFF9CA3AF)
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                // 6. Description
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("বিস্তারিত বিবরণ") },
                    placeholder = { Text("কর্মসূচির বিস্তারিত এজেন্ডা, বক্তব্য ও তথ্যাবলী...") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = Color(0xFF15803D),
                        unfocusedBorderColor = Color(0xFF9CA3AF)
                    ),
                    shape = RoundedCornerShape(10.dp),
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )

                // 7. PHOTO UPLOAD SECTION
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF9FAFB)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE5E7EB))
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "📸 কর্মসূচির ছবি যুক্ত করুন",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = TextPrimary
                        )

                        // Button to pick from gallery
                        OutlinedButton(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.AddPhotoAlternate, contentDescription = null, tint = Color(0xFF15803D))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (selectedPhotoUri != null) "ছবি পরিবর্তন করুন" else "গ্যালারি থেকে ছবি নির্বাচন করুন",
                                color = Color(0xFF15803D),
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Preview picked image
                        if (selectedPhotoUri != null) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(140.dp)
                                    .clip(RoundedCornerShape(8.dp))
                            ) {
                                AsyncImage(
                                    model = ImageRequest.Builder(context)
                                        .data(selectedPhotoUri)
                                        .crossfade(true)
                                        .build(),
                                    contentDescription = "Selected Photo",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                                IconButton(
                                    onClick = { selectedPhotoUri = null },
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .background(Color(0x80000000), CircleShape)
                                        .size(32.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Close, contentDescription = "Remove", tint = Color.White, modifier = Modifier.size(18.dp))
                                }
                            }
                        }

                        // Or online image URL
                        OutlinedTextField(
                            value = photoUrlInput,
                            onValueChange = {
                                photoUrlInput = it
                                if (it.isNotBlank()) selectedPhotoUri = null
                            },
                            label = { Text("অথবা ছবির অনলাইন URL লিংক") },
                            placeholder = { Text("https://example.com/photo.jpg") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                focusedBorderColor = Color(0xFF15803D),
                                unfocusedBorderColor = Color(0xFF9CA3AF)
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                // 8. VIDEO UPLOAD & LINK SECTION
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF9FAFB)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE5E7EB))
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "🎥 কর্মসূচির ভিডিও যুক্ত করুন",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = TextPrimary
                        )

                        // Button to pick video from phone
                        OutlinedButton(
                            onClick = {
                                videoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                                )
                            },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.VideoLibrary, contentDescription = null, tint = Color(0xFFDC2626))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (selectedVideoUri != null) "ভিডিও পরিবর্তন করুন" else "ফোন থেকে ভিডিও ফাইল নির্বাচন করুন",
                                color = Color(0xFFDC2626),
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (selectedVideoUri != null) {
                            Surface(
                                color = Color(0xFFFEE2E2),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.PlayCircle, contentDescription = null, tint = Color(0xFFDC2626))
                                        Text("ভিডিও ফাইল সংযুক্ত করা হয়েছে", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF991B1B))
                                    }
                                    IconButton(onClick = { selectedVideoUri = null }, modifier = Modifier.size(24.dp)) {
                                        Icon(imageVector = Icons.Default.Close, contentDescription = "Remove", tint = Color(0xFF991B1B))
                                    }
                                }
                            }
                        }

                        // Or video link (YouTube, Facebook, etc.)
                        OutlinedTextField(
                            value = videoUrlInput,
                            onValueChange = {
                                videoUrlInput = it
                                if (it.isNotBlank()) selectedVideoUri = null
                            },
                            label = { Text("অথবা ভিডিও লিংক (YouTube / Facebook)") },
                            placeholder = { Text("https://www.youtube.com/watch?v=...") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                focusedBorderColor = Color(0xFF15803D),
                                unfocusedBorderColor = Color(0xFF9CA3AF)
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                // Submit & Cancel Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("বাতিল", color = TextSecondary)
                    }

                    Button(
                        onClick = {
                            if (title.isBlank()) {
                                Toast.makeText(context, "অনুগ্রহ করে কর্মসূচির শিরোনাম লিখুন", Toast.LENGTH_SHORT).show()
                                return@Button
                            }

                            val finalPhotoUri = selectedPhotoUri?.toString() ?: photoUrlInput.trim()
                            val finalVideoUri = selectedVideoUri?.toString() ?: videoUrlInput.trim()

                            val newProgram = ProgramEntity(
                                title = title.trim(),
                                unit = unit,
                                date = date.trim(),
                                time = time.trim(),
                                location = location.trim(),
                                status = status,
                                description = description.trim(),
                                photoUri = finalPhotoUri,
                                videoUri = finalVideoUri,
                                authorName = unit
                            )
                            onSubmit(newProgram)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_submit_program")
                    ) {
                        Text("পোস্ট করুন", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
