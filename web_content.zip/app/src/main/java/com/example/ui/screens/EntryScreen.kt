package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.MemberEntity
import com.example.ui.MainViewModel
import com.example.ui.components.DropdownSelector
import com.example.ui.components.OfficialBanner
import com.example.ui.model.CharghatData
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.TextHint
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun EntryScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val activeTab by viewModel.activeFormTab.collectAsState()
    val alertMessage by viewModel.alertMessage.collectAsState()

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF3F4F6)) // bg-gray-100
            .verticalScroll(scrollState)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Official Banner Card with Slogans & Emblem
        OfficialBanner()

        // Quick access card to Programs & Media Gallery
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { viewModel.currentView.value = "programs" },
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFDCFCE7)),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF86EFAC))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.PhotoLibrary,
                        contentDescription = null,
                        tint = Color(0xFF15803D),
                        modifier = Modifier.size(24.dp)
                    )
                    Column {
                        Text(
                            text = "দলীয় কর্মসূচি, ফটো ও ভিডিও গ্যালারি",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF14532D)
                        )
                        Text(
                            text = "সাম্প্রতিক ইভেন্ট দেখুন অথবা ছবি ও ভিডিও আপলোড করুন",
                            fontSize = 11.sp,
                            color = Color(0xFF166534)
                        )
                    }
                }
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = null,
                    tint = Color(0xFF15803D),
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        val isAdminLoggedIn by viewModel.isAdminLoggedIn.collectAsState()
        if (isAdminLoggedIn) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.currentView.value = "add_committee_member" }
                    .testTag("entry_open_committee_member_card"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBFDBFE))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PersonAdd,
                            contentDescription = null,
                            tint = Color(0xFF1D4ED8),
                            modifier = Modifier.size(22.dp)
                        )
                        Column {
                            Text(
                                text = "এডমিন: নতুন কমিটি সদস্য এন্ট্রি (Firestore)",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1E3A8A)
                            )
                            Text(
                                text = "নাম, পদবী, মোবাইল ও ওয়ার্ড নম্বর সহ ক্লাউডে সংরক্ষণ করুন",
                                fontSize = 11.sp,
                                color = Color(0xFF1E40AF)
                            )
                        }
                    }
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        tint = Color(0xFF1D4ED8),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // Alert Message Box
        AnimatedVisibility(visible = alertMessage != null) {
            alertMessage?.let { (msg, type) ->
                val isSuccess = type == "success"
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSuccess) Color(0xFFDCFCE7) else Color(0xFFFEE2E2))
                        .border(1.dp, if (isSuccess) Color(0xFF86EFAC) else Color(0xFFFCA5A5), RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Text(
                        text = msg,
                        color = if (isSuccess) Color(0xFF14532D) else Color(0xFF991B1B),
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }

        // Main White Form Container Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Tab Selection Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                ) {
                    // Tab 1: Leader Tab
                    val isLeaderActive = activeTab == "leader"
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { viewModel.activeFormTab.value = "leader" }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Shield,
                                    contentDescription = null,
                                    tint = if (isLeaderActive) Color(0xFF15803D) else TextMuted,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "দায়িত্বপ্রাপ্ত নেতার তথ্য",
                                    fontSize = 14.sp,
                                    fontWeight = if (isLeaderActive) FontWeight.ExtraBold else FontWeight.Bold,
                                    color = if (isLeaderActive) Color(0xFF15803D) else TextMuted
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(0.9f)
                                    .height(3.dp)
                                    .background(if (isLeaderActive) Color(0xFF15803D) else Color.Transparent)
                            )
                        }
                    }

                    // Tab 2: Worker Tab
                    val isWorkerActive = activeTab == "worker"
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { viewModel.activeFormTab.value = "worker" }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PersonAdd,
                                    contentDescription = null,
                                    tint = if (isWorkerActive) Color(0xFF7E22CE) else TextMuted,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "সাধারণ কর্মী এন্ট্রি",
                                    fontSize = 14.sp,
                                    fontWeight = if (isWorkerActive) FontWeight.ExtraBold else FontWeight.Bold,
                                    color = if (isWorkerActive) Color(0xFF7E22CE) else TextMuted
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(0.9f)
                                    .height(3.dp)
                                    .background(if (isWorkerActive) Color(0xFF7E22CE) else Color.Transparent)
                            )
                        }
                    }
                }

                if (activeTab == "leader") {
                    LeaderFormContent(
                        viewModel = viewModel,
                        onSubmit = { entity ->
                            viewModel.insertMember(entity)
                        }
                    )
                } else {
                    WorkerFormContent(
                        viewModel = viewModel,
                        onSubmit = { entity ->
                            viewModel.insertMember(entity)
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
private fun LeaderFormContent(
    viewModel: MainViewModel,
    onSubmit: (MemberEntity) -> Unit
) {
    var union by remember { mutableStateOf("") }
    var designation by remember { mutableStateOf("") }
    var customDesignation by remember { mutableStateOf("") }
    var leaderName by remember { mutableStateOf("") }
    var leaderMobile by remember { mutableStateOf("") }
    var leaderFb by remember { mutableStateOf("") }

    val isCustom = designation == "+ অন্যান্য/নতুন পদ লিখুন"

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = TextPrimary,
        unfocusedTextColor = TextPrimary,
        focusedLabelColor = TextPrimary,
        unfocusedLabelColor = TextSecondary,
        focusedPlaceholderColor = TextHint,
        unfocusedPlaceholderColor = TextHint,
        focusedBorderColor = EmeraldPrimary,
        unfocusedBorderColor = Color(0xFF9CA3AF),
        focusedContainerColor = Color.White,
        unfocusedContainerColor = Color.White
    )

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // 1. Unit Selector (ইউনিট নির্বাচন করুন)
        DropdownSelector(
            label = "ইউনিট নির্বাচন করুন",
            items = CharghatData.units,
            selectedItem = if (union.isEmpty()) "-- ইউনিট নির্বাচন করুন --" else union,
            onItemSelected = { union = it },
            testTag = "leader_unit_select"
        )

        // 2. Designation Selector (সকল পদবী ড্রপডাউন আকারে)
        DropdownSelector(
            label = "পদবী নির্বাচন করুন",
            items = listOf("-- পদবী নির্বাচন করুন --") + CharghatData.leaderDesignations,
            selectedItem = if (designation.isEmpty()) "-- পদবী নির্বাচন করুন --" else designation,
            onItemSelected = { designation = if (it.startsWith("--")) "" else it },
            testTag = "leader_designation_select"
        )

        // New Designation Custom Input Option (পদবী নতুন করে লেখার অপশন)
        AnimatedVisibility(visible = isCustom) {
            OutlinedTextField(
                value = customDesignation,
                onValueChange = { customDesignation = it },
                label = { Text("নতুন পদবী লিখুন", fontWeight = FontWeight.SemiBold, color = TextSecondary) },
                placeholder = { Text("যেমন: সহ-সম্পাদক, সদস্য ইত্যাদি", color = TextHint) },
                colors = fieldColors,
                textStyle = MaterialTheme.typography.bodyLarge.copy(color = TextPrimary, fontWeight = FontWeight.SemiBold),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("custom_designation_input")
            )
        }

        // 3. Leader Details Container (নেতার তথ্য)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xFFF0FDF4))
                .border(1.dp, Color(0xFF86EFAC), RoundedCornerShape(14.dp))
                .padding(14.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "নেতার তথ্য",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF14532D)
                )

                OutlinedTextField(
                    value = leaderName,
                    onValueChange = { leaderName = it },
                    label = { Text("নেতার নাম", fontWeight = FontWeight.SemiBold, color = TextSecondary) },
                    placeholder = { Text("নাম লিখুন", color = TextHint) },
                    colors = fieldColors,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(color = TextPrimary, fontWeight = FontWeight.SemiBold),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("leader_name_input")
                )

                OutlinedTextField(
                    value = leaderMobile,
                    onValueChange = { leaderMobile = it },
                    label = { Text("মোবাইল নম্বর", fontWeight = FontWeight.SemiBold, color = TextSecondary) },
                    placeholder = { Text("017XXXXXXXX", color = TextHint) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    colors = fieldColors,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(color = TextPrimary, fontWeight = FontWeight.SemiBold),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("leader_mobile_input")
                )

                OutlinedTextField(
                    value = leaderFb,
                    onValueChange = { leaderFb = it },
                    label = { Text("ফেসবুক আইডি লিংক (ঐচ্ছিক)", fontWeight = FontWeight.SemiBold, color = TextSecondary) },
                    placeholder = { Text("https://facebook.com/...", color = TextHint) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    colors = fieldColors,
                    textStyle = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("leader_fb_input")
                )
            }
        }

        // Submit Button (Green 700)
        Button(
            onClick = {
                val cleanUnion = union.trim()
                if (cleanUnion.isBlank() || cleanUnion.startsWith("--")) {
                    viewModel.showAlert("অনুগ্রহ করে ইউনিট নির্বাচন করুন!", "danger")
                    return@Button
                }

                val cleanDesignation = designation.trim()
                if (cleanDesignation.isBlank() || cleanDesignation.startsWith("--")) {
                    viewModel.showAlert("অনুগ্রহ করে পদবী নির্বাচন করুন!", "danger")
                    return@Button
                }

                val finalDesig = if (isCustom) {
                    customDesignation.trim().ifBlank { "অন্যান্য পদ" }
                } else {
                    cleanDesignation
                }

                if (leaderName.isBlank()) {
                    viewModel.showAlert("অনুগ্রহ করে নেতার নাম লিখুন!", "danger")
                    return@Button
                }

                if (leaderMobile.isBlank()) {
                    viewModel.showAlert("অনুগ্রহ করে নেতার মোবাইল নম্বর লিখুন!", "danger")
                    return@Button
                }

                val today = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())

                val entity = MemberEntity(
                    type = "leader",
                    union = cleanUnion,
                    ward = "",
                    sovapotiName = if (finalDesig == "সভাপতি") leaderName.trim() else "",
                    sovapotiMobile = if (finalDesig == "সভাপতি") leaderMobile.trim() else "",
                    sovapotiFb = if (finalDesig == "সভাপতি") leaderFb.trim() else "",
                    secretaryName = if (finalDesig == "সাধারণ সম্পাদক") leaderName.trim() else "",
                    secretaryMobile = if (finalDesig == "সাধারণ সম্পাদক") leaderMobile.trim() else "",
                    secretaryFb = if (finalDesig == "সাধারণ সম্পাদক") leaderFb.trim() else "",
                    otherDesignation = if (finalDesig != "সভাপতি" && finalDesig != "সাধারণ সম্পাদক") finalDesig else "",
                    otherName = if (finalDesig != "সভাপতি" && finalDesig != "সাধারণ সম্পাদক") leaderName.trim() else "",
                    otherMobile = if (finalDesig != "সভাপতি" && finalDesig != "সাধারণ সম্পাদক") leaderMobile.trim() else "",
                    otherFb = if (finalDesig != "সভাপতি" && finalDesig != "সাধারণ সম্পাদক") leaderFb.trim() else "",
                    createdAt = today
                )

                onSubmit(entity)

                // Reset form fields
                union = ""
                designation = ""
                customDesignation = ""
                leaderName = ""
                leaderMobile = ""
                leaderFb = ""
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("submit_leader_button")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(imageVector = Icons.Default.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                Text("তথ্য জমা দিন", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
            }
        }
    }
}

@Composable
private fun WorkerFormContent(
    viewModel: MainViewModel,
    onSubmit: (MemberEntity) -> Unit
) {
    var union by remember { mutableStateOf("") }
    var ward by remember { mutableStateOf("") }
    var workerName by remember { mutableStateOf("") }
    var workerDesignation by remember { mutableStateOf("") }
    var workerMobile by remember { mutableStateOf("") }
    var workerFb by remember { mutableStateOf("") }

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = TextPrimary,
        unfocusedTextColor = TextPrimary,
        focusedLabelColor = TextPrimary,
        unfocusedLabelColor = TextSecondary,
        focusedPlaceholderColor = TextHint,
        unfocusedPlaceholderColor = TextHint,
        focusedBorderColor = Color(0xFF7E22CE),
        unfocusedBorderColor = Color(0xFF9CA3AF),
        focusedContainerColor = Color.White,
        unfocusedContainerColor = Color.White
    )

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Unit Selector
        DropdownSelector(
            label = "ইউনিট নির্বাচন করুন",
            items = CharghatData.units,
            selectedItem = if (union.isEmpty()) "-- ইউনিট নির্বাচন করুন --" else union,
            onItemSelected = { union = it },
            testTag = "worker_unit_select"
        )

        // Ward Selector
        DropdownSelector(
            label = "ওয়ার্ড নির্বাচন করুন",
            items = listOf("-- ওয়ার্ড নির্বাচন করুন --") + CharghatData.wards,
            selectedItem = if (ward.isEmpty()) "-- ওয়ার্ড নির্বাচন করুন --" else ward,
            onItemSelected = { ward = if (it.startsWith("--")) "" else it },
            testTag = "worker_ward_select"
        )

        // Worker Info (Light Purple Container)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xFFFAF5FF))
                .border(1.dp, Color(0xFFE9D5FF), RoundedCornerShape(14.dp))
                .padding(14.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "সাধারণ কর্মীর তথ্য",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF6B21A8)
                )

                OutlinedTextField(
                    value = workerName,
                    onValueChange = { workerName = it },
                    label = { Text("কর্মীর পূর্ণ নাম", fontWeight = FontWeight.SemiBold, color = TextSecondary) },
                    placeholder = { Text("কর্মীর নাম লিখুন", color = TextHint) },
                    colors = fieldColors,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(color = TextPrimary, fontWeight = FontWeight.SemiBold),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("w_name_input")
                )

                OutlinedTextField(
                    value = workerDesignation,
                    onValueChange = { workerDesignation = it },
                    label = { Text("পদবী (না থাকলে সদস্য লিখুন)", fontWeight = FontWeight.SemiBold, color = TextSecondary) },
                    placeholder = { Text("যেমন: সদস্য, সহ-সভাপতি ইত্যাদি", color = TextHint) },
                    colors = fieldColors,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(color = TextPrimary, fontWeight = FontWeight.SemiBold),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = workerMobile,
                    onValueChange = { workerMobile = it },
                    label = { Text("মোবাইল নম্বর", fontWeight = FontWeight.SemiBold, color = TextSecondary) },
                    placeholder = { Text("017XXXXXXXX", color = TextHint) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    colors = fieldColors,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(color = TextPrimary, fontWeight = FontWeight.SemiBold),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("w_mobile_input")
                )

                OutlinedTextField(
                    value = workerFb,
                    onValueChange = { workerFb = it },
                    label = { Text("ফেসবুক আইডি লিংক", fontWeight = FontWeight.SemiBold, color = TextSecondary) },
                    placeholder = { Text("https://facebook.com/...", color = TextHint) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    colors = fieldColors,
                    textStyle = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Submit Button (Purple 700)
        Button(
            onClick = {
                val cleanUnion = union.trim()
                if (cleanUnion.isBlank() || cleanUnion.startsWith("--")) {
                    viewModel.showAlert("অনুগ্রহ করে ইউনিট নির্বাচন করুন!", "danger")
                    return@Button
                }

                val cleanName = workerName.trim()
                if (cleanName.isBlank()) {
                    viewModel.showAlert("অনুগ্রহ করে কর্মীর নাম লিখুন!", "danger")
                    return@Button
                }

                val today = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())
                val entity = MemberEntity(
                    type = "worker",
                    union = cleanUnion,
                    ward = ward.trim().ifBlank { "উল্লেখ নেই" },
                    workerName = cleanName,
                    workerDesignation = workerDesignation.trim().ifBlank { "সদস্য" },
                    workerMobile = workerMobile.trim().ifBlank { "উল্লেখ নেই" },
                    workerFb = workerFb.trim(),
                    createdAt = today
                )

                onSubmit(entity)

                // Reset form fields
                union = ""
                ward = ""
                workerName = ""
                workerDesignation = ""
                workerMobile = ""
                workerFb = ""
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7E22CE)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("submit_worker_button")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(imageVector = Icons.Default.VerifiedUser, contentDescription = null, modifier = Modifier.size(18.dp))
                Text("তথ্য জমা দিন", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
            }
        }
    }
}
