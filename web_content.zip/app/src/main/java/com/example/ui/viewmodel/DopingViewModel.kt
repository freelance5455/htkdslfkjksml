package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.ExamType
import com.example.data.model.Question
import com.example.data.model.StorageBreakdown
import com.example.data.model.StudyTask
import com.example.data.model.Subject
import com.example.data.model.SubjectProgress
import com.example.data.model.TestCategory
import com.example.data.model.TopicLecture
import com.example.data.model.UserProgress
import com.example.data.repository.DopingRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class ScreenTab {
  HOME,
  LECTURES,
  COACH_PLAN,
  QUESTION_BANK,
  QUIZ,
  ERROR_NOTEBOOK,
  POMODORO,
  SETTINGS_STORAGE
}

data class QuizSessionState(
  val quizTitle: String = "Genel Tarama Testi",
  val questions: List<Question> = emptyList(),
  val currentIndex: Int = 0,
  val selectedAnswers: Map<Int, Int> = emptyMap(), // questionIndex -> optionIndex
  val eliminatedOptions: Map<Int, Set<Int>> = emptyMap(), // questionIndex -> Set<optionIndex>
  val showSolution: Boolean = false,
  val isCompleted: Boolean = false,
  val timeElapsedSeconds: Int = 0
)

data class PomodoroState(
  val totalDurationSeconds: Int = 25 * 60,
  val secondsRemaining: Int = 25 * 60,
  val isRunning: Boolean = false,
  val isBreak: Boolean = false,
  val completedCycles: Int = 2
)

class DopingViewModel(
  application: Application
) : AndroidViewModel(application) {

  private val repository: DopingRepository = DopingRepository(application.applicationContext)

  val userProgress: StateFlow<UserProgress> = repository.userProgress
  val tasks: StateFlow<List<StudyTask>> = repository.tasks
  val topics: StateFlow<List<TopicLecture>> = repository.topics
  val questions: StateFlow<List<Question>> = repository.questions
  val subjectProgress: StateFlow<Map<Subject, SubjectProgress>> = repository.subjectProgress
  val storageBreakdown: StateFlow<StorageBreakdown> = repository.storageBreakdown
  val testCategories: List<TestCategory> get() = repository.testCategories
  val coachingTips: List<String> = repository.coachingTips
  val badges: List<com.example.data.model.AchievementBadge> get() = repository.getAchievementBadges()
  val dailyTrend: List<com.example.data.model.DailyTrendPoint> get() = repository.getDailySolvedTrend()

  private val _currentScreen = MutableStateFlow(ScreenTab.HOME)
  val currentScreen: StateFlow<ScreenTab> = _currentScreen.asStateFlow()

  private val _selectedTopic = MutableStateFlow<TopicLecture?>(null)
  val selectedTopic: StateFlow<TopicLecture?> = _selectedTopic.asStateFlow()

  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  private val _selectedSubjectFilter = MutableStateFlow<Subject?>(null)
  val selectedSubjectFilter: StateFlow<Subject?> = _selectedSubjectFilter.asStateFlow()

  // Selected Calendar Date for Study Planner (Default: "2026-11-12")
  private val _selectedCalendarDate = MutableStateFlow("2026-11-12")
  val selectedCalendarDate: StateFlow<String> = _selectedCalendarDate.asStateFlow()

  // Quiz State
  private val _quizState = MutableStateFlow(QuizSessionState())
  val quizState: StateFlow<QuizSessionState> = _quizState.asStateFlow()

  // Pomodoro State
  private val _pomodoroState = MutableStateFlow(PomodoroState())
  val pomodoroState: StateFlow<PomodoroState> = _pomodoroState.asStateFlow()
  private var pomodoroJob: Job? = null
  private var quizTimerJob: Job? = null

  init {
    loadQuizQuestions(questions.value, "Doping Karma Sınav Testi")
  }

  fun navigateTo(tab: ScreenTab) {
    _currentScreen.value = tab
    _selectedTopic.value = null
  }

  fun selectTopic(topic: TopicLecture?) {
    _selectedTopic.value = topic
  }

  fun updateSearchQuery(query: String) {
    _searchQuery.value = query
  }

  fun selectSubjectFilter(subject: Subject?) {
    _selectedSubjectFilter.value = subject
  }

  fun selectCalendarDate(date: String) {
    _selectedCalendarDate.value = date
  }

  fun setExam(exam: ExamType) {
    repository.setExam(exam)
  }

  fun toggleTask(taskId: String) {
    repository.toggleTask(taskId)
  }

  fun addTask(
    title: String,
    subject: Subject,
    questions: Int,
    minutes: Int,
    priority: String,
    scheduledDate: String = _selectedCalendarDate.value,
    reminderTime: String? = null,
    hasReminder: Boolean = false,
    notes: String = ""
  ) {
    repository.addTask(
      title = title,
      subject = subject,
      questions = questions,
      minutes = minutes,
      priority = priority,
      scheduledDate = scheduledDate,
      reminderTime = reminderTime,
      hasReminder = hasReminder,
      notes = notes
    )
  }

  fun toggleReminder(taskId: String) {
    repository.toggleReminder(taskId)
  }

  fun deleteTask(taskId: String) {
    repository.deleteTask(taskId)
  }

  fun toggleTopicComplete(topicId: String) {
    repository.toggleTopicComplete(topicId)
  }

  fun toggleTopicFavorite(topicId: String) {
    repository.toggleTopicFavorite(topicId)
  }

  fun generateSmartCoachPlan(weeklyHours: Int) {
    repository.generateSmartCoachPlan(weeklyHours, userProgress.value.selectedExam)
  }

  fun toggleOfflineDownload() {
    repository.toggleOfflineDownload()
  }

  fun clearCache() {
    repository.clearCache()
  }

  // --- Quiz Logic ---
  fun startQuizForSubject(subject: Subject?) {
    val filtered = if (subject == null) questions.value else questions.value.filter { it.subject == subject }
    val title = if (subject != null) "${subject.title} Testi" else "Genel Soru Bankası"
    loadQuizQuestions(if (filtered.isNotEmpty()) filtered else questions.value, title)
    _currentScreen.value = ScreenTab.QUIZ
  }

  fun startQuizForTestCategory(testCategory: TestCategory) {
    val qs = if (testCategory.questions.isNotEmpty()) testCategory.questions else questions.value.filter { it.subject == testCategory.subject }
    loadQuizQuestions(if (qs.isNotEmpty()) qs else questions.value, testCategory.title)
    _currentScreen.value = ScreenTab.QUIZ
  }

  fun startQuizForTopic(topicId: String) {
    val filtered = questions.value.filter { it.topicId == topicId }
    val topic = topics.value.find { it.id == topicId }
    val title = topic?.title ?: "Konu Pekiştirme Testi"
    loadQuizQuestions(if (filtered.isNotEmpty()) filtered else questions.value, title)
    _currentScreen.value = ScreenTab.QUIZ
  }

  fun startErrorNotebookQuiz() {
    val errorIds = userProgress.value.errorNotebookQuestionIds
    val filtered = questions.value.filter { errorIds.contains(it.id) }
    loadQuizQuestions(if (filtered.isNotEmpty()) filtered else questions.value, "Hata Defteri Eksik Kapatma Testi")
    _currentScreen.value = ScreenTab.QUIZ
  }

  private fun loadQuizQuestions(list: List<Question>, title: String = "Test") {
    _quizState.value = QuizSessionState(quizTitle = title, questions = list)
    startQuizTimer()
  }

  private fun startQuizTimer() {
    quizTimerJob?.cancel()
    quizTimerJob = viewModelScope.launch {
      while (!_quizState.value.isCompleted) {
        delay(1000)
        _quizState.update { it.copy(timeElapsedSeconds = it.timeElapsedSeconds + 1) }
      }
    }
  }

  fun selectAnswer(optionIndex: Int) {
    val currentIdx = _quizState.value.currentIndex
    val currentQuestion = _quizState.value.questions.getOrNull(currentIdx) ?: return
    val isCorrect = optionIndex == currentQuestion.correctOptionIndex

    val updatedAnswers = _quizState.value.selectedAnswers.toMutableMap()
    updatedAnswers[currentIdx] = optionIndex

    _quizState.update {
      it.copy(
        selectedAnswers = updatedAnswers,
        showSolution = true
      )
    }

    repository.recordQuestionAnswer(currentQuestion.id, isCorrect)
  }

  fun toggleEliminateOption(optionIndex: Int) {
    val currentIdx = _quizState.value.currentIndex
    val currentEliminated = _quizState.value.eliminatedOptions[currentIdx]?.toMutableSet() ?: mutableSetOf()
    if (currentEliminated.contains(optionIndex)) {
      currentEliminated.remove(optionIndex)
    } else {
      currentEliminated.add(optionIndex)
    }
    val updatedMap = _quizState.value.eliminatedOptions.toMutableMap()
    updatedMap[currentIdx] = currentEliminated
    _quizState.update { it.copy(eliminatedOptions = updatedMap) }
  }

  fun toggleSolutionVisibility() {
    _quizState.update { it.copy(showSolution = !it.showSolution) }
  }

  fun nextQuestion() {
    if (_quizState.value.currentIndex < _quizState.value.questions.size - 1) {
      _quizState.update {
        it.copy(
          currentIndex = it.currentIndex + 1,
          showSolution = it.selectedAnswers.containsKey(it.currentIndex + 1)
        )
      }
    } else {
      finishQuiz()
    }
  }

  fun previousQuestion() {
    if (_quizState.value.currentIndex > 0) {
      _quizState.update {
        it.copy(
          currentIndex = it.currentIndex - 1,
          showSolution = it.selectedAnswers.containsKey(it.currentIndex - 1)
        )
      }
    }
  }

  fun goToQuestion(index: Int) {
    if (index in _quizState.value.questions.indices) {
      _quizState.update {
        it.copy(
          currentIndex = index,
          showSolution = it.selectedAnswers.containsKey(index)
        )
      }
    }
  }

  fun finishQuiz() {
    _quizState.update { it.copy(isCompleted = true) }
    quizTimerJob?.cancel()
  }

  fun restartQuiz() {
    loadQuizQuestions(_quizState.value.questions, _quizState.value.quizTitle)
  }

  fun toggleErrorNotebookForCurrentQuestion() {
    val currentQuestion = _quizState.value.questions.getOrNull(_quizState.value.currentIndex) ?: return
    repository.toggleQuestionInErrorNotebook(currentQuestion.id)
  }

  fun toggleQuestionInErrorNotebook(questionId: String) {
    repository.toggleQuestionInErrorNotebook(questionId)
  }

  // --- Pomodoro Logic ---
  fun togglePomodoro() {
    if (_pomodoroState.value.isRunning) {
      pausePomodoro()
    } else {
      startPomodoro()
    }
  }

  private fun startPomodoro() {
    _pomodoroState.update { it.copy(isRunning = true) }
    pomodoroJob?.cancel()
    pomodoroJob = viewModelScope.launch {
      while (_pomodoroState.value.isRunning && _pomodoroState.value.secondsRemaining > 0) {
        delay(1000)
        _pomodoroState.update { it.copy(secondsRemaining = it.secondsRemaining - 1) }
      }
      if (_pomodoroState.value.secondsRemaining <= 0) {
        val wasBreak = _pomodoroState.value.isBreak
        if (!wasBreak) {
          repository.addStudyTime(25)
          _pomodoroState.update {
            it.copy(
              isBreak = true,
              totalDurationSeconds = 5 * 60,
              secondsRemaining = 5 * 60,
              isRunning = false,
              completedCycles = it.completedCycles + 1
            )
          }
        } else {
          _pomodoroState.update {
            it.copy(
              isBreak = false,
              totalDurationSeconds = 25 * 60,
              secondsRemaining = 25 * 60,
              isRunning = false
            )
          }
        }
      }
    }
  }

  private fun pausePomodoro() {
    _pomodoroState.update { it.copy(isRunning = false) }
    pomodoroJob?.cancel()
  }

  fun resetPomodoro() {
    pausePomodoro()
    val isBreak = _pomodoroState.value.isBreak
    val duration = if (isBreak) 5 * 60 else 25 * 60
    _pomodoroState.update {
      it.copy(
        totalDurationSeconds = duration,
        secondsRemaining = duration,
        isRunning = false
      )
    }
  }

  fun switchPomodoroMode(isBreak: Boolean) {
    pausePomodoro()
    val duration = if (isBreak) 5 * 60 else 25 * 60
    _pomodoroState.update {
      it.copy(
        isBreak = isBreak,
        totalDurationSeconds = duration,
        secondsRemaining = duration,
        isRunning = false
      )
    }
  }
}
