package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BrowserMode
import com.example.model.DisplayResolution
import com.example.model.EraSite
import com.example.model.EraSitesData
import com.example.ui.xp.WindowsXpTheme

@Composable
fun XpTitleBar(
    title: String,
    browserMode: BrowserMode,
    isWidescreen16x9: Boolean = true,
    displayResolution: DisplayResolution = DisplayResolution.RES_1080P_FHD,
    onToggleWidescreen: () -> Unit = {},
    onOpenResolutionDialog: () -> Unit = {},
    onRotateScreen: () -> Unit = {},
    onToggleBrowserMode: () -> Unit,
    onMinimize: () -> Unit,
    onClose: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(34.dp)
            .background(WindowsXpTheme.TitleBarGradient)
            .padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f, fill = false)
        ) {
            // Iconic Internet Explorer blue 'e' badge
            Box(
                modifier = Modifier
                    .size(20.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF1E88E5)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "e",
                    color = Color(0xFFFFD54F),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    fontFamily = FontFamily.Serif
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            Text(
                text = if (title.isBlank()) "Microsoft Internet Explorer" else "$title - Microsoft Internet Explorer",
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Resolution Badge (1080p FHD default)
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(3.dp))
                    .background(if (displayResolution == DisplayResolution.RES_1080P_FHD) Color(0xFF1B5E20) else Color(0xFF0058EE))
                    .border(1.dp, if (displayResolution == DisplayResolution.RES_1080P_FHD) Color(0xFF81C784) else Color(0xFF64B5F6), RoundedCornerShape(3.dp))
                    .clickable { onOpenResolutionDialog() }
                    .padding(horizontal = 5.dp, vertical = 2.dp)
                    .testTag("resolution_dialog_button"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = displayResolution.shortLabel,
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // 16:9 Widescreen Mode Toggle Badge
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(3.dp))
                    .background(if (isWidescreen16x9) Color(0xFF1B5E20) else Color(0xFF455A64))
                    .border(1.dp, if (isWidescreen16x9) Color(0xFF81C784) else Color(0xFF90A4AE), RoundedCornerShape(3.dp))
                    .clickable { onToggleWidescreen() }
                    .padding(horizontal = 5.dp, vertical = 2.dp)
                    .testTag("toggle_16x9_widescreen_button"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isWidescreen16x9) "16:9 ON" else "16:9 OFF",
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Rotate Screen to 16:9 Landscape Button
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color(0xFF0D47A1))
                    .border(1.dp, Color(0xFF64B5F6), RoundedCornerShape(3.dp))
                    .clickable { onRotateScreen() }
                    .padding(horizontal = 5.dp, vertical = 2.dp)
                    .testTag("rotate_screen_button"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "⤾ Rotate",
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Mode switcher button: switch between XP IE6 and Google Chrome
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color(0xFF0D47A1))
                    .border(1.dp, Color(0xFF64B5F6), RoundedCornerShape(3.dp))
                    .clickable { onToggleBrowserMode() }
                    .padding(horizontal = 6.dp, vertical = 2.dp)
                    .testTag("toggle_browser_mode_button"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.SwapHoriz,
                    contentDescription = "Switch to Chrome",
                    tint = Color.White,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(3.dp))
                Text(
                    text = "Chrome",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // XP Window Controls: Minimize, Maximize, Close
            Box(
                modifier = Modifier
                    .size(21.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color(0xFF2979FF))
                    .border(1.dp, Color.White.copy(alpha = 0.6f), RoundedCornerShape(3.dp))
                    .clickable { onMinimize() },
                contentAlignment = Alignment.Center
            ) {
                Text(text = "–", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            Box(
                modifier = Modifier
                    .size(21.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color(0xFF2979FF))
                    .border(1.dp, Color.White.copy(alpha = 0.6f), RoundedCornerShape(3.dp))
                    .clickable { onToggleWidescreen() },
                contentAlignment = Alignment.Center
            ) {
                Text(text = "□", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            Box(
                modifier = Modifier
                    .size(21.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(WindowsXpTheme.CloseRed)
                    .border(1.dp, Color.White.copy(alpha = 0.6f), RoundedCornerShape(3.dp))
                    .clickable { onClose() }
                    .testTag("close_window_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Close",
                    tint = Color.White,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}

@Composable
fun XpMenuBar(
    onNewTab: () -> Unit,
    onOpenUrlDialog: () -> Unit,
    onToggleCrt: () -> Unit,
    crtActive: Boolean,
    isWidescreen16x9: Boolean = true,
    displayResolution: DisplayResolution = DisplayResolution.RES_1080P_FHD,
    onToggleWidescreen: () -> Unit = {},
    onOpenResolutionDialog: () -> Unit = {},
    onRotateScreen: () -> Unit = {},
    onOpenFlashSettings: () -> Unit,
    onOpenUserAgentSwitcher: () -> Unit,
    onOpenWaybackDialog: () -> Unit,
    onOpenEraSites: () -> Unit,
    onViewSource: () -> Unit,
    onAbout: () -> Unit
) {
    var fileMenuExpanded by remember { mutableStateOf(false) }
    var viewMenuExpanded by remember { mutableStateOf(false) }
    var favoritesMenuExpanded by remember { mutableStateOf(false) }
    var toolsMenuExpanded by remember { mutableStateOf(false) }
    var helpMenuExpanded by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(WindowsXpTheme.Background)
            .border(width = 1.dp, color = WindowsXpTheme.BorderDark)
            .padding(horizontal = 4.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // File
        Box {
            MenuButton(label = "File", onClick = { fileMenuExpanded = true })
            DropdownMenu(
                expanded = fileMenuExpanded,
                onDismissRequest = { fileMenuExpanded = false }
            ) {
                DropdownMenuItem(
                    text = { Text("New Tab") },
                    onClick = { fileMenuExpanded = false; onNewTab() }
                )
                DropdownMenuItem(
                    text = { Text("Open URL...") },
                    onClick = { fileMenuExpanded = false; onOpenUrlDialog() }
                )
                DropdownMenuItem(
                    text = { Text("Wayback Machine Time Travel...") },
                    onClick = { fileMenuExpanded = false; onOpenWaybackDialog() }
                )
                DropdownMenuItem(
                    text = { Text("View Page Source (Notepad)") },
                    onClick = { fileMenuExpanded = false; onViewSource() }
                )
            }
        }

        // View
        Box {
            MenuButton(label = "View", onClick = { viewMenuExpanded = true })
            DropdownMenu(
                expanded = viewMenuExpanded,
                onDismissRequest = { viewMenuExpanded = false }
            ) {
                DropdownMenuItem(
                    text = { Text("Display Resolution (${displayResolution.shortLabel})...") },
                    onClick = { viewMenuExpanded = false; onOpenResolutionDialog() }
                )
                DropdownMenuItem(
                    text = { Text(if (isWidescreen16x9) "✓ 16:9 Widescreen Ratio" else "16:9 Widescreen Ratio") },
                    onClick = { viewMenuExpanded = false; onToggleWidescreen() }
                )
                DropdownMenuItem(
                    text = { Text("Rotate Screen to 16:9 Landscape") },
                    onClick = { viewMenuExpanded = false; onRotateScreen() }
                )
                DropdownMenuItem(
                    text = { Text(if (crtActive) "Disable CRT Monitor Filter" else "Enable CRT Monitor Scanlines") },
                    onClick = { viewMenuExpanded = false; onToggleCrt() }
                )
                DropdownMenuItem(
                    text = { Text("View HTML Source") },
                    onClick = { viewMenuExpanded = false; onViewSource() }
                )
            }
        }

        // Favorites
        Box {
            MenuButton(label = "Favorites", onClick = { favoritesMenuExpanded = true })
            DropdownMenu(
                expanded = favoritesMenuExpanded,
                onDismissRequest = { favoritesMenuExpanded = false }
            ) {
                DropdownMenuItem(
                    text = { Text("Browse All Era Sites...") },
                    onClick = { favoritesMenuExpanded = false; onOpenEraSites() }
                )
                DropdownMenuItem(
                    text = { Text("Adobe Flash Player 10 Hub") },
                    onClick = {
                        favoritesMenuExpanded = false
                        onOpenUrlDialog()
                    }
                )
            }
        }

        // Tools
        Box {
            MenuButton(label = "Tools", onClick = { toolsMenuExpanded = true })
            DropdownMenu(
                expanded = toolsMenuExpanded,
                onDismissRequest = { toolsMenuExpanded = false }
            ) {
                DropdownMenuItem(
                    text = { Text("Adobe Flash Player v10 Settings...") },
                    onClick = { toolsMenuExpanded = false; onOpenFlashSettings() }
                )
                DropdownMenuItem(
                    text = { Text("User-Agent Browser Compatibility...") },
                    onClick = { toolsMenuExpanded = false; onOpenUserAgentSwitcher() }
                )
            }
        }

        // Help
        Box {
            MenuButton(label = "Help", onClick = { helpMenuExpanded = true })
            DropdownMenu(
                expanded = helpMenuExpanded,
                onDismissRequest = { helpMenuExpanded = false }
            ) {
                DropdownMenuItem(
                    text = { Text("About Internet Explorer 6.0 & Flash 10") },
                    onClick = { helpMenuExpanded = false; onAbout() }
                )
            }
        }

        Spacer(modifier = Modifier.weight(1f))
    }
}

@Composable
private fun MenuButton(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clickable { onClick() }
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            color = Color.Black,
            fontFamily = FontFamily.SansSerif
        )
    }
}

@Composable
fun XpStandardToolbar(
    canGoBack: Boolean,
    canGoForward: Boolean,
    isLoading: Boolean,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onStop: () -> Unit,
    onRefresh: () -> Unit,
    onHome: () -> Unit,
    onSearch: () -> Unit,
    onFavorites: () -> Unit,
    onHistory: () -> Unit,
    onFlashHub: () -> Unit,
    onWayback: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ie_spin")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "spin_angle"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(WindowsXpTheme.Background)
            .border(1.dp, WindowsXpTheme.BorderDark)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 4.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // Big Classic XP Back Button (Green Circle)
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(3.dp))
                .clickable(enabled = canGoBack) { onBack() }
                .padding(horizontal = 4.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(26.dp)
                    .clip(CircleShape)
                    .background(if (canGoBack) Color(0xFF43A047) else Color(0xFFA5D6A7)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.width(2.dp))
            Text(
                text = "Back",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (canGoBack) Color.Black else Color.Gray
            )
        }

        // Forward Button
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(3.dp))
                .clickable(enabled = canGoForward) { onForward() }
                .padding(horizontal = 4.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(if (canGoForward) Color(0xFF43A047) else Color(0xFFA5D6A7)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = "Forward",
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        ToolbarDivider()

        // Stop
        ToolbarButton(
            icon = Icons.Default.Stop,
            label = "Stop",
            tint = Color(0xFFD32F2F),
            onClick = onStop
        )

        // Refresh
        ToolbarButton(
            icon = Icons.Default.Refresh,
            label = "Refresh",
            tint = Color(0xFF2E7D32),
            onClick = onRefresh
        )

        // Home
        ToolbarButton(
            icon = Icons.Default.Home,
            label = "Home",
            tint = Color(0xFF1565C0),
            onClick = onHome
        )

        ToolbarDivider()

        // Search
        ToolbarButton(
            icon = Icons.Default.Search,
            label = "Search",
            tint = Color(0xFFE65100),
            onClick = onSearch
        )

        // Favorites
        ToolbarButton(
            icon = Icons.Default.Star,
            label = "Favorites",
            tint = Color(0xFFF57F17),
            onClick = onFavorites
        )

        // History
        ToolbarButton(
            icon = Icons.Default.History,
            label = "History",
            tint = Color(0xFF5D4037),
            onClick = onHistory
        )

        ToolbarDivider()

        // Adobe Flash Player 10 Hub
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(3.dp))
                .background(WindowsXpTheme.FlashRed)
                .clickable { onFlashHub() }
                .padding(horizontal = 6.dp, vertical = 4.dp)
                .testTag("flash_hub_toolbar_button"),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "f",
                color = Color.White,
                fontWeight = FontWeight.Black,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "Flash 10",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Wayback Time Travel Button
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(3.dp))
                .background(Color(0xFF37474F))
                .clickable { onWayback() }
                .padding(horizontal = 6.dp, vertical = 4.dp)
                .testTag("wayback_toolbar_button"),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Public,
                contentDescription = "Wayback",
                tint = Color.White,
                modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(3.dp))
            Text(
                text = "Wayback",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        // Spinning Windows XP / IE Globe
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(Color(0xFF003399))
                .border(1.dp, Color(0xFF64B5F6), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Public,
                contentDescription = "Globe",
                tint = Color(0xFFFFEB3B),
                modifier = Modifier
                    .size(20.dp)
                    .rotate(if (isLoading) rotation else 0f)
            )
        }
    }
}

@Composable
private fun ToolbarButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(3.dp))
            .clickable { onClick() }
            .padding(horizontal = 4.dp, vertical = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = tint,
            modifier = Modifier.size(18.dp)
        )
        Text(
            text = label,
            fontSize = 9.sp,
            color = Color.Black
        )
    }
}

@Composable
private fun ToolbarDivider() {
    Box(
        modifier = Modifier
            .width(1.dp)
            .height(26.dp)
            .background(WindowsXpTheme.BorderDark)
    )
}

@Composable
fun XpAddressBar(
    currentUrl: String,
    onNavigate: (String) -> Unit,
    onOpenWaybackPicker: () -> Unit
) {
    var textInput by remember(currentUrl) { mutableStateOf(currentUrl) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(WindowsXpTheme.Background)
            .border(1.dp, WindowsXpTheme.BorderDark)
            .padding(horizontal = 6.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "Address",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF333333)
        )

        Spacer(modifier = Modifier.width(6.dp))

        // Input Box with Favicon and Dropdown
        Row(
            modifier = Modifier
                .weight(1f)
                .height(28.dp)
                .background(Color.White)
                .border(1.dp, WindowsXpTheme.AddressBorder)
                .padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Public,
                contentDescription = "Page Icon",
                tint = Color(0xFF1E88E5),
                modifier = Modifier.size(14.dp)
            )

            Spacer(modifier = Modifier.width(6.dp))

            BasicTextField(
                value = textInput,
                onValueChange = { textInput = it },
                modifier = Modifier
                    .weight(1f)
                    .testTag("url_input_field"),
                singleLine = true,
                textStyle = TextStyle(
                    fontSize = 12.sp,
                    color = Color.Black,
                    fontFamily = FontFamily.SansSerif
                ),
                cursorBrush = SolidColor(Color.Black),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { onNavigate(textInput) })
            )

            Icon(
                imageVector = Icons.Default.ArrowDropDown,
                contentDescription = "History dropdown",
                tint = Color.Gray,
                modifier = Modifier
                    .size(18.dp)
                    .clickable { /* Show recent */ }
            )
        }

        Spacer(modifier = Modifier.width(6.dp))

        // Luna Green "Go" Button
        Row(
            modifier = Modifier
                .height(26.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(WindowsXpTheme.GreenGo)
                .border(1.dp, Color(0xFF1B5E20), RoundedCornerShape(3.dp))
                .clickable { onNavigate(textInput) }
                .padding(horizontal = 10.dp)
                .testTag("go_button"),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Go",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
            Spacer(modifier = Modifier.width(3.dp))
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = "Go",
                tint = Color.White,
                modifier = Modifier.size(14.dp)
            )
        }
    }
}

@Composable
fun XpLinksBar(onSelectSite: (EraSite) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(WindowsXpTheme.Background)
            .border(1.dp, WindowsXpTheme.BorderDark)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 6.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "Links »",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF003399),
            modifier = Modifier.padding(end = 6.dp)
        )

        EraSitesData.SITES.take(7).forEach { site ->
            Text(
                text = site.title.split(" (")[0],
                fontSize = 10.sp,
                color = Color(0xFF000080),
                modifier = Modifier
                    .clickable { onSelectSite(site) }
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            )
            Text(text = "|", fontSize = 10.sp, color = Color.Gray)
        }
    }
}

@Composable
fun XpStatusBar(
    statusText: String,
    isLoading: Boolean,
    progress: Int,
    isSecure: Boolean,
    hasFlash: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(24.dp)
            .background(WindowsXpTheme.Background)
            .border(1.dp, WindowsXpTheme.BorderDark)
            .padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Status message
        Text(
            text = if (isLoading) "Opening page... ($progress%)" else statusText.ifEmpty { "Done" },
            fontSize = 11.sp,
            color = Color.Black,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )

        // Windows XP Segmented Progress Bar
        if (isLoading) {
            Row(
                modifier = Modifier
                    .width(90.dp)
                    .height(12.dp)
                    .background(Color.White)
                    .border(1.dp, Color(0xFF7F9DB9))
                    .padding(1.dp),
                horizontalArrangement = Arrangement.spacedBy(1.dp)
            ) {
                val segmentCount = (progress / 10).coerceIn(0, 8)
                repeat(segmentCount) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .weight(1f)
                            .background(Color(0xFF316AC5))
                    )
                }
            }
            Spacer(modifier = Modifier.width(6.dp))
        }

        // Zone: Internet
        Row(
            modifier = Modifier
                .border(1.dp, WindowsXpTheme.BorderDark)
                .padding(horizontal = 4.dp, vertical = 1.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Public,
                contentDescription = "Internet Zone",
                tint = Color(0xFF1565C0),
                modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(3.dp))
            Text(text = "Internet", fontSize = 10.sp, color = Color.Black)
        }

        Spacer(modifier = Modifier.width(4.dp))

        // Padlock indicator
        Icon(
            imageVector = if (isSecure) Icons.Default.Lock else Icons.Default.LockOpen,
            contentDescription = if (isSecure) "Secure" else "Archive / Unencrypted",
            tint = if (isSecure) Color(0xFF2E7D32) else Color(0xFF757575),
            modifier = Modifier.size(14.dp)
        )

        Spacer(modifier = Modifier.width(4.dp))

        // Flash indicator badge
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(2.dp))
                .background(WindowsXpTheme.FlashRed)
                .padding(horizontal = 3.dp, vertical = 1.dp)
        ) {
            Text(
                text = "Flash 10",
                color = Color.White,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
