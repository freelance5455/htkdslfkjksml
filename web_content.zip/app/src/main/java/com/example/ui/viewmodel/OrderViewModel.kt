package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.StudioPreferences
import com.example.data.model.Order
import com.example.data.repository.OrderRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class OrderFormState(
    val clientName: String = "",
    val clientContact: String = "",
    val serviceType: String = "Video Editing",
    val fileLink: String = "",
    val budget: String = "",
    val deadline: String = "2 Days",
    val notes: String = "",
    val paymentMarkedAsPaid: Boolean = false,
    val isSubmitting: Boolean = false,
    val submittedOrderId: Long? = null,
    val errorMessage: String? = null
)

data class StudioMetrics(
    val totalOrders: Int = 0,
    val totalRevenue: Double = 0.0,
    val pendingOrders: Int = 0,
    val completedOrders: Int = 0,
    val paidOrders: Int = 0
)

class OrderViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: OrderRepository

    private val _formState = MutableStateFlow(OrderFormState())
    val formState: StateFlow<OrderFormState> = _formState.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedStatusFilter = MutableStateFlow("All")
    val selectedStatusFilter: StateFlow<String> = _selectedStatusFilter.asStateFlow()

    private val _selectedServiceFilter = MutableStateFlow("All")
    val selectedServiceFilter: StateFlow<String> = _selectedServiceFilter.asStateFlow()

    private val _upiId = MutableStateFlow(StudioPreferences.DEFAULT_UPI_ID)
    val upiId: StateFlow<String> = _upiId.asStateFlow()

    private val _telegramBotToken = MutableStateFlow("")
    val telegramBotToken: StateFlow<String> = _telegramBotToken.asStateFlow()

    private val _telegramChatId = MutableStateFlow("")
    val telegramChatId: StateFlow<String> = _telegramChatId.asStateFlow()

    private val _trackedOrder = MutableStateFlow<Order?>(null)
    val trackedOrder: StateFlow<Order?> = _trackedOrder.asStateFlow()

    private val _trackingSearchQuery = MutableStateFlow("")
    val trackingSearchQuery: StateFlow<String> = _trackingSearchQuery.asStateFlow()

    private val _hasAttemptedTracking = MutableStateFlow(false)
    val hasAttemptedTracking: StateFlow<Boolean> = _hasAttemptedTracking.asStateFlow()

    init {
        val database = AppDatabase.getDatabase(application)
        val preferences = StudioPreferences(application)
        repository = OrderRepository(database.orderDao(), preferences)

        _upiId.value = preferences.upiId
        _telegramBotToken.value = preferences.telegramBotToken
        _telegramChatId.value = preferences.telegramChatId
    }

    val allOrders: StateFlow<List<Order>> = repository.allOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredOrders: StateFlow<List<Order>> = combine(
        allOrders,
        _searchQuery,
        _selectedStatusFilter,
        _selectedServiceFilter
    ) { orders, query, status, service ->
        orders.filter { order ->
            val matchesQuery = query.isBlank() ||
                order.clientName.contains(query, ignoreCase = true) ||
                order.clientContact.contains(query, ignoreCase = true) ||
                order.id.toString() == query.trim().removePrefix("#") ||
                order.notes?.contains(query, ignoreCase = true) == true

            val matchesStatus = status == "All" || order.paymentStatus.equals(status, ignoreCase = true)
            val matchesService = service == "All" || order.serviceType.equals(service, ignoreCase = true)

            matchesQuery && matchesStatus && matchesService
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val metrics: StateFlow<StudioMetrics> = allOrders.combine(MutableStateFlow(Unit)) { orders, _ ->
        val total = orders.size
        val revenue = orders.sumOf { it.budgetAmount }
        val pending = orders.count { it.paymentStatus == Order.STATUS_PENDING_PAYMENT }
        val completed = orders.count { it.paymentStatus == Order.STATUS_COMPLETED || it.paymentStatus == Order.STATUS_DELIVERED }
        val paid = orders.count { it.paymentStatus == Order.STATUS_PAID_UPI || it.paymentStatus == Order.STATUS_COMPLETED }

        StudioMetrics(
            totalOrders = total,
            totalRevenue = revenue,
            pendingOrders = pending,
            completedOrders = completed,
            paidOrders = paid
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), StudioMetrics())

    // Form Handlers
    fun onClientNameChange(name: String) = _formState.update { it.copy(clientName = name, errorMessage = null) }
    fun onClientContactChange(contact: String) = _formState.update { it.copy(clientContact = contact, errorMessage = null) }
    fun onServiceTypeChange(service: String) = _formState.update { it.copy(serviceType = service) }
    fun onFileLinkChange(link: String) = _formState.update { it.copy(fileLink = link) }
    fun onBudgetChange(budget: String) = _formState.update { it.copy(budget = budget, errorMessage = null) }
    fun onDeadlineChange(deadline: String) = _formState.update { it.copy(deadline = deadline) }
    fun onNotesChange(notes: String) = _formState.update { it.copy(notes = notes) }
    fun onPaymentMarkedChange(paid: Boolean) = _formState.update { it.copy(paymentMarkedAsPaid = paid) }

    fun submitOrder(onSuccess: (Long) -> Unit) {
        val state = _formState.value

        if (state.clientName.isBlank()) {
            _formState.update { it.copy(errorMessage = "Please enter your full name.") }
            return
        }
        if (state.clientContact.isBlank()) {
            _formState.update { it.copy(errorMessage = "Please enter a valid phone number or WhatsApp contact.") }
            return
        }
        if (state.serviceType.isBlank()) {
            _formState.update { it.copy(errorMessage = "Please select the required service.") }
            return
        }
        if (state.budget.isBlank()) {
            _formState.update { it.copy(errorMessage = "Please specify the agreed budget/amount.") }
            return
        }

        viewModelScope.launch {
            _formState.update { it.copy(isSubmitting = true, errorMessage = null) }
            try {
                val newOrder = Order(
                    clientName = state.clientName.trim(),
                    clientContact = state.clientContact.trim(),
                    serviceType = state.serviceType,
                    fileLink = state.fileLink.trim().ifBlank { null },
                    budget = state.budget.trim(),
                    deadline = state.deadline.trim().ifBlank { "Standard (2-3 Days)" },
                    notes = state.notes.trim().ifBlank { null },
                    paymentStatus = if (state.paymentMarkedAsPaid) Order.STATUS_PAID_UPI else Order.STATUS_PENDING_PAYMENT
                )

                val generatedId = repository.createOrder(newOrder)
                _formState.update {
                    it.copy(
                        isSubmitting = false,
                        submittedOrderId = generatedId
                    )
                }
                onSuccess(generatedId)
            } catch (e: Exception) {
                _formState.update {
                    it.copy(
                        isSubmitting = false,
                        errorMessage = "Failed to submit order: ${e.localizedMessage}"
                    )
                }
            }
        }
    }

    fun resetForm() {
        _formState.value = OrderFormState()
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setStatusFilter(status: String) {
        _selectedStatusFilter.value = status
    }

    fun setServiceFilter(service: String) {
        _selectedServiceFilter.value = service
    }

    fun updateOrderStatus(orderId: Long, newStatus: String) {
        viewModelScope.launch {
            repository.updateOrderStatus(orderId, newStatus)
        }
    }

    fun toggleOrderStatus(order: Order) {
        val nextStatus = Order.getNextToggleStatus(order.paymentStatus)
        updateOrderStatus(order.id, nextStatus)
    }

    fun deleteOrder(order: Order) {
        viewModelScope.launch {
            repository.deleteOrder(order)
        }
    }

    fun updateStudioSettings(upi: String, botToken: String, chatId: String) {
        val prefs = repository.getPreferences()
        prefs.upiId = upi.trim()
        prefs.telegramBotToken = botToken.trim()
        prefs.telegramChatId = chatId.trim()

        _upiId.value = prefs.upiId
        _telegramBotToken.value = prefs.telegramBotToken
        _telegramChatId.value = prefs.telegramChatId
    }

    fun formatOrderShareText(order: Order): String = repository.formatOrderShareText(order)

    // Tracker
    fun setTrackingQuery(query: String) {
        _trackingSearchQuery.value = query
    }

    fun lookupOrder() {
        val q = _trackingSearchQuery.value.trim()
        _hasAttemptedTracking.value = true
        if (q.isBlank()) {
            _trackedOrder.value = null
            return
        }

        val idCandidate = q.removePrefix("#").toLongOrNull()
        val currentOrders = allOrders.value

        val found = currentOrders.firstOrNull { order ->
            (idCandidate != null && order.id == idCandidate) ||
            order.clientContact.replace(Regex("[^0-9]"), "").endsWith(q.replace(Regex("[^0-9]"), "")) ||
            order.clientName.equals(q, ignoreCase = true)
        }

        _trackedOrder.value = found
    }
}
