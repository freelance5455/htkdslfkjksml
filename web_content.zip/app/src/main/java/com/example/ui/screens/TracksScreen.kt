package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.TrackEntity
import com.example.data.local.TrackLessonEntity
import com.example.data.local.TrackWithLessons
import com.example.data.model.AppConstants
import com.example.data.model.TrackFilter
import com.example.ui.MainUiState
import com.example.ui.theme.BrandIndigo
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.RoseFocus

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TracksScreen(
    uiState: MainUiState,
    isWide: Boolean,
    onFilterChange: (TrackFilter) -> Unit,
    onAddTrackClick: () -> Unit,
    onEditTrackClick: (TrackEntity) -> Unit,
    onDeleteTrackClick: (TrackEntity) -> Unit,
    onOpenMultiLessonModal: (String) -> Unit,
    onQuickAddLesson: (trackId: String, title: String) -> Unit,
    onToggleLesson: (TrackLessonEntity) -> Unit,
    onEditLesson: (trackId: String, TrackLessonEntity) -> Unit,
    onDeleteLesson: (TrackLessonEntity) -> Unit
) {
    val totalAll = uiState.tracks.sumOf { it.lessons.size }
    val doneAll = uiState.tracks.sumOf { t -> t.lessons.count { it.completed } }
    val overallPct = if (totalAll > 0) (doneAll * 100 / totalAll) else 0
    val levelBadge = when {
        overallPct == 100 && totalAll > 0 -> "بطل التفوق 🏆"
        overallPct >= 75 -> "على أعتاب القمة 🔥"
        overallPct >= 40 -> "أداء ممتاز 💪"
        else -> "بداية موفقة 🌱"
    }

    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.School,
                            contentDescription = null,
                            tint = EmeraldSuccess
                        )
                        Text(
                            text = "مسارات المناهج ومتابع التقدم",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Text(
                        text = "أضف موادك ودروسك بسرعة، وعلم على ما أنجزته 🎉",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Button(
                    onClick = onAddTrackClick,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldDark),
                    modifier = Modifier.testTag("add_track_button")
                ) {
                    Icon(Icons.Filled.AddCircle, contentDescription = "إضافة مسار مادة", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("إضافة مسار", style = MaterialTheme.typography.labelLarge)
                }
            }

            // Overall Progress Box
            Surface(
                color = MaterialTheme.colorScheme.background,
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Filled.PieChart, contentDescription = null, tint = BrandIndigo, modifier = Modifier.size(18.dp))
                            Text(
                                text = "متوسط إنجاز المناهج",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Surface(
                                color = EmeraldSuccess.copy(alpha = 0.14f),
                                shape = CircleShape
                            ) {
                                Text(
                                    text = levelBadge,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Black,
                                    color = EmeraldSuccess,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "$doneAll / $totalAll درس",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "$overallPct%",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Black,
                                color = EmeraldSuccess
                            )
                        }
                    }

                    LinearProgressIndicator(
                        progress = { (overallPct / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(CircleShape),
                        color = EmeraldSuccess,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                }
            }

            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = uiState.trackFilter == TrackFilter.ALL,
                    onClick = { onFilterChange(TrackFilter.ALL) },
                    label = { Text("الكل") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = EmeraldDark,
                        selectedLabelColor = Color.White
                    ),
                    modifier = Modifier.testTag("filter_tracks_all")
                )
                FilterChip(
                    selected = uiState.trackFilter == TrackFilter.ACTIVE,
                    onClick = { onFilterChange(TrackFilter.ACTIVE) },
                    label = { Text("قيد الإنجاز") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = EmeraldDark,
                        selectedLabelColor = Color.White
                    ),
                    modifier = Modifier.testTag("filter_tracks_active")
                )
                FilterChip(
                    selected = uiState.trackFilter == TrackFilter.COMPLETED,
                    onClick = { onFilterChange(TrackFilter.COMPLETED) },
                    label = { Text("مكتملة 100%") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = EmeraldDark,
                        selectedLabelColor = Color.White
                    ),
                    modifier = Modifier.testTag("filter_tracks_completed")
                )
            }

            val filtered = uiState.tracks.filter { track ->
                val len = track.lessons.size
                val done = track.lessons.count { it.completed }
                val isCompleted = len > 0 && done == len
                when (uiState.trackFilter) {
                    TrackFilter.ALL -> true
                    TrackFilter.ACTIVE -> !isCompleted
                    TrackFilter.COMPLETED -> isCompleted
                }
            }

            if (filtered.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                        .padding(vertical = 36.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (uiState.tracks.isEmpty()) {
                            "لا توجد مسارات حالياً.. أضف أول مادة!"
                        } else {
                            "لا توجد مسارات مطابقة"
                        },
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else if (isWide) {
                val rows = filtered.chunked(2)
                rows.forEach { pair ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        pair.forEach { track ->
                            TrackCard(
                                trackWithLessons = track,
                                onEditTrack = { onEditTrackClick(track.track) },
                                onDeleteTrack = { onDeleteTrackClick(track.track) },
                                onOpenMultiLessonModal = { onOpenMultiLessonModal(track.track.id) },
                                onQuickAddLesson = { title -> onQuickAddLesson(track.track.id, title) },
                                onToggleLesson = onToggleLesson,
                                onEditLesson = { lesson -> onEditLesson(track.track.id, lesson) },
                                onDeleteLesson = onDeleteLesson,
                                modifier = Modifier.weight(1f)
                            )
                        }
                        if (pair.size == 1) Spacer(modifier = Modifier.weight(1f))
                    }
                }
            } else {
                filtered.forEach { track ->
                    TrackCard(
                        trackWithLessons = track,
                        onEditTrack = { onEditTrackClick(track.track) },
                        onDeleteTrack = { onDeleteTrackClick(track.track) },
                        onOpenMultiLessonModal = { onOpenMultiLessonModal(track.track.id) },
                        onQuickAddLesson = { title -> onQuickAddLesson(track.track.id, title) },
                        onToggleLesson = onToggleLesson,
                        onEditLesson = { lesson -> onEditLesson(track.track.id, lesson) },
                        onDeleteLesson = onDeleteLesson,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

@Composable
private fun TrackCard(
    trackWithLessons: TrackWithLessons,
    onEditTrack: () -> Unit,
    onDeleteTrack: () -> Unit,
    onOpenMultiLessonModal: () -> Unit,
    onQuickAddLesson: (String) -> Unit,
    onToggleLesson: (TrackLessonEntity) -> Unit,
    onEditLesson: (TrackLessonEntity) -> Unit,
    onDeleteLesson: (TrackLessonEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val track = trackWithLessons.track
    val lessons = trackWithLessons.lessons
    val total = lessons.size
    val done = lessons.count { it.completed }
    val pct = if (total > 0) (done * 100 / total) else 0
    val isComplete = total > 0 && pct == 100
    val accent = AppConstants.parseHexColor(track.colorHex, EmeraldSuccess)

    var quickTitle by remember(track.id) { mutableStateOf("") }

    Surface(
        color = MaterialTheme.colorScheme.background,
        shape = RoundedCornerShape(22.dp),
        border = BorderStroke(
            width = if (isComplete) 1.5.dp else 1.dp,
            color = if (isComplete) EmeraldSuccess.copy(alpha = 0.7f) else MaterialTheme.colorScheme.outlineVariant
        ),
        modifier = modifier.testTag("track_card_${track.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Surface(
                        color = accent,
                        shape = CircleShape
                    ) {
                        Text(
                            text = if (isComplete) "مكتمل ✓" else "مسار مادة",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = track.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black
                    )
                    if (track.teacher.isNotBlank()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Person,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = track.teacher,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    IconButton(
                        onClick = onOpenMultiLessonModal,
                        modifier = Modifier.testTag("track_add_lessons_${track.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Layers,
                            contentDescription = "إضافة دروس للمسار",
                            tint = EmeraldSuccess
                        )
                    }
                    IconButton(
                        onClick = onEditTrack,
                        modifier = Modifier.testTag("edit_track_${track.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Edit,
                            contentDescription = "تعديل المسار",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(
                        onClick = onDeleteTrack,
                        modifier = Modifier.testTag("delete_track_${track.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.DeleteOutline,
                            contentDescription = "حذف المسار",
                            tint = RoseFocus
                        )
                    }
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.outlineVariant)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "$done من $total درس",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "$pct%",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Black,
                    color = accent
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { (pct / 100f).coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(CircleShape),
                color = accent,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            if (lessons.isEmpty()) {
                Text(
                    text = "أضف دروس هذا المسار من الأسفل",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    lessons.forEach { lesson ->
                        Surface(
                            color = if (lesson.completed) {
                                EmeraldSuccess.copy(alpha = 0.10f)
                            } else {
                                MaterialTheme.colorScheme.surface
                            },
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(
                                1.dp,
                                if (lesson.completed) EmeraldSuccess.copy(alpha = 0.35f) else MaterialTheme.colorScheme.outlineVariant
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .clickable { onToggleLesson(lesson) }
                                .testTag("track_lesson_item_${lesson.id}")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(22.dp)
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(
                                                if (lesson.completed) EmeraldSuccess else Color.Transparent
                                            )
                                            .then(
                                                if (!lesson.completed) {
                                                    Modifier.background(MaterialTheme.colorScheme.surfaceVariant)
                                                } else Modifier
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (lesson.completed) {
                                            Icon(
                                                imageVector = Icons.Filled.Check,
                                                contentDescription = "منجز",
                                                tint = Color.White,
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                    }

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = lesson.title,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            textDecoration = if (lesson.completed) TextDecoration.LineThrough else TextDecoration.None,
                                            color = if (lesson.completed) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        if (lesson.note.isNotBlank()) {
                                            Text(
                                                text = lesson.note,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }

                                Row {
                                    IconButton(
                                        onClick = { onEditLesson(lesson) },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Edit,
                                            contentDescription = "تعديل الدرس",
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                    IconButton(
                                        onClick = { onDeleteLesson(lesson) },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.DeleteOutline,
                                            contentDescription = "حذف الدرس",
                                            tint = RoseFocus,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.outlineVariant)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = quickTitle,
                    onValueChange = { quickTitle = it },
                    placeholder = { Text("+ أضف درس سريع...") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = {
                        if (quickTitle.isNotBlank()) {
                            onQuickAddLesson(quickTitle)
                            quickTitle = ""
                        }
                    }),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("quick_add_lesson_input_${track.id}")
                )
                Button(
                    onClick = {
                        if (quickTitle.isNotBlank()) {
                            onQuickAddLesson(quickTitle)
                            quickTitle = ""
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldDark),
                    modifier = Modifier
                        .height(52.dp)
                        .testTag("quick_add_lesson_submit_${track.id}")
                ) {
                    Icon(Icons.Filled.Add, contentDescription = "إضافة درس")
                }
            }
        }
    }
}
