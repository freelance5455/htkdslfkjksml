package com.example.ui.screens

import android.annotation.SuppressLint
import android.net.Uri
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdUnits
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Html
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.SettingsApplications
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.data.model.StudioProject
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.util.ArchiveExportSummary
import com.example.util.ConvertedAppConfig
import com.example.util.ConverterIconPreset
import com.example.util.ConverterSourceType
import com.example.util.ExtractedWebBundle
import com.example.util.ProjectArchiveExporter
import com.example.util.WebToAndroidAppPackager
import kotlinx.coroutines.launch

private val ICON_BG_SWATCHES = listOf("#0F172A", "#064E3B", "#1E1B4B", "#311042", "#451A03", "#111827")
private val ICON_FG_SWATCHES = listOf("#38BDF8", "#34D399", "#818CF8", "#F472B6", "#FBBF24", "#F87171")

@OptIn(ExperimentalLayoutApi::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun HtmlZipToAppConverterScreen(
    savedProjects: List<StudioProject>,
    exportBanner: ArchiveExportSummary?,
    onDismissExportBanner: () -> Unit,
    onSaveConvertedAppToWorkspace: (ConvertedAppConfig, ExtractedWebBundle) -> Unit,
    onExportConvertedZipToUri: (ConvertedAppConfig, ExtractedWebBundle, Uri) -> Unit,
    onExportConvertedZipToWorkspace: (ConvertedAppConfig, ExtractedWebBundle) -> Unit,
    onShowMessage: (String) -> Unit,
    onNavigateBackToStudio: () -> Unit
) {
    BackHandler {
        onNavigateBackToStudio()
    }

    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    // Source selection & extracted bundle state
    var selectedSourceType by rememberSaveable { mutableStateOf(ConverterSourceType.PASTED_HTML) }
    var appName by rememberSaveable { mutableStateOf("OmniWeb Native App") }
    var packageName by rememberSaveable { mutableStateOf("com.omniprompt.converted.webapp") }
    var versionName by rememberSaveable { mutableStateOf("1.0.0") }
    var versionCodeStr by rememberSaveable { mutableStateOf("1") }

    var htmlEditorText by rememberSaveable {
        mutableStateOf(WebToAndroidAppPackager.defaultStarterHtml("OmniWeb Native App"))
    }
    var bundleSourceLabel by rememberSaveable { mutableStateOf("Pasted / Edited HTML5") }
    var bundleEntryFileName by rememberSaveable { mutableStateOf("index.html") }
    var extractedZipFiles by remember { mutableStateOf<Map<String, ByteArray>>(emptyMap()) }
    var selectedStudioProjectId by rememberSaveable { mutableStateOf("") }

    // Icon configuration
    var selectedIconPresetId by rememberSaveable { mutableStateOf(ConverterIconPreset.ROCKET.id) }
    var customIconBgHex by rememberSaveable { mutableStateOf("#0F172A") }
    var customIconFgHex by rememberSaveable { mutableStateOf("#38BDF8") }
    var customIconUriString by rememberSaveable { mutableStateOf("") }

    // Ads / Monetization configuration
    var adsEnabled by rememberSaveable { mutableStateOf(false) }
    var adMobAppId by rememberSaveable { mutableStateOf("") }
    var bannerAdUnitId by rememberSaveable { mutableStateOf("") }
    var bannerPlacement by rememberSaveable { mutableStateOf("BOTTOM") }
    var interstitialAdUnitId by rememberSaveable { mutableStateOf("") }
    var interstitialOnLaunch by rememberSaveable { mutableStateOf(false) }
    var rewardedAdUnitId by rememberSaveable { mutableStateOf("") }

    // Native WebView Shell & Permissions configuration
    var orientation by rememberSaveable { mutableStateOf("PORTRAIT") }
    var fullscreenImmersive by rememberSaveable { mutableStateOf(false) }
    var enablePullToRefresh by rememberSaveable { mutableStateOf(true) }
    var enableSplashHeader by rememberSaveable { mutableStateOf(true) }
    var enableJavaScript by rememberSaveable { mutableStateOf(true) }
    var enableDomStorage by rememberSaveable { mutableStateOf(true) }
    var enableOfflineCache by rememberSaveable { mutableStateOf(true) }
    var enableFileUpload by rememberSaveable { mutableStateOf(true) }
    var enableZoomControls by rememberSaveable { mutableStateOf(false) }

    var permCamera by rememberSaveable { mutableStateOf(false) }
    var permLocation by rememberSaveable { mutableStateOf(false) }
    var permVibrate by rememberSaveable { mutableStateOf(true) }
    var permNotifications by rememberSaveable { mutableStateOf(false) }

    var previewRefreshTick by remember { mutableIntStateOf(0) }

    val currentConfig = remember(
        appName, packageName, versionName, versionCodeStr, selectedIconPresetId,
        customIconBgHex, customIconFgHex, customIconUriString, adsEnabled, adMobAppId,
        bannerAdUnitId, bannerPlacement, interstitialAdUnitId, interstitialOnLaunch,
        rewardedAdUnitId, orientation, fullscreenImmersive, enablePullToRefresh,
        enableSplashHeader, enableJavaScript, enableDomStorage, enableOfflineCache,
        enableFileUpload, enableZoomControls, permCamera, permLocation, permVibrate, permNotifications
    ) {
        ConvertedAppConfig(
            appName = appName.ifBlank { "OmniWeb Native App" },
            packageName = packageName.ifBlank { "com.omniprompt.converted.webapp" },
            versionName = versionName.ifBlank { "1.0.0" },
            versionCode = versionCodeStr.toIntOrNull()?.coerceAtLeast(1) ?: 1,
            themeColorHex = customIconFgHex,
            iconPresetId = selectedIconPresetId,
            customIconBgHex = customIconBgHex,
            customIconFgHex = customIconFgHex,
            customIconUriString = customIconUriString,
            adsEnabled = adsEnabled,
            adMobAppId = adMobAppId.trim(),
            bannerAdUnitId = bannerAdUnitId.trim(),
            bannerPlacement = bannerPlacement,
            interstitialAdUnitId = interstitialAdUnitId.trim(),
            interstitialOnLaunch = interstitialOnLaunch,
            rewardedAdUnitId = rewardedAdUnitId.trim(),
            orientation = orientation,
            fullscreenImmersive = fullscreenImmersive,
            enablePullToRefresh = enablePullToRefresh,
            enableSplashHeader = enableSplashHeader,
            enableJavaScript = enableJavaScript,
            enableDomStorage = enableDomStorage,
            enableOfflineCache = enableOfflineCache,
            enableFileUpload = enableFileUpload,
            enableZoomControls = enableZoomControls,
            permCamera = permCamera,
            permLocation = permLocation,
            permVibrate = permVibrate,
            permNotifications = permNotifications
        )
    }

    val currentBundle = remember(bundleSourceLabel, bundleEntryFileName, htmlEditorText, extractedZipFiles) {
        ExtractedWebBundle(
            sourceLabel = bundleSourceLabel,
            entryHtmlFileName = bundleEntryFileName,
            mainHtmlContent = htmlEditorText,
            additionalFiles = extractedZipFiles
        )
    }

    // Launchers for external HTML, external ZIP, custom icon image, and ZIP export destination
    val htmlFilePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val res = WebToAndroidAppPackager.readExternalHtmlUri(context, uri)
                res.onSuccess { bundle ->
                    bundleSourceLabel = bundle.sourceLabel
                    bundleEntryFileName = bundle.entryHtmlFileName
                    htmlEditorText = bundle.mainHtmlContent
                    extractedZipFiles = emptyMap()
                    previewRefreshTick++
                    onShowMessage("Loaded ${bundle.sourceLabel} into converter!")
                }.onFailure { err ->
                    onShowMessage(err.localizedMessage ?: "Failed to read HTML file.")
                }
            }
        }
    }

    val zipFilePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val res = WebToAndroidAppPackager.parseExternalZipUri(context, uri)
                res.onSuccess { bundle ->
                    bundleSourceLabel = bundle.sourceLabel
                    bundleEntryFileName = bundle.entryHtmlFileName
                    htmlEditorText = bundle.mainHtmlContent
                    extractedZipFiles = bundle.additionalFiles
                    previewRefreshTick++
                    onShowMessage("Extracted ${bundle.additionalFiles.size} files from ZIP archive!")
                }.onFailure { err ->
                    onShowMessage(err.localizedMessage ?: "Failed to parse ZIP archive.")
                }
            }
        }
    }

    val iconPhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            customIconUriString = uri.toString()
            onShowMessage("Custom launcher icon image selected!")
        }
    }

    val exportZipCreator = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip")
    ) { uri: Uri? ->
        if (uri != null) {
            onExportConvertedZipToUri(currentConfig, currentBundle, uri)
        }
    }

    val exportApkCreator = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/vnd.android.package-archive")
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val res = ProjectArchiveExporter.exportInstalledStudioApkToUri(context, uri)
                res.onSuccess { summary ->
                    onShowMessage("Saved Signed APK: ${summary.archiveFileName} (${summary.totalBytes / 1024} KB)")
                }.onFailure { err ->
                    onShowMessage(err.localizedMessage ?: "Failed to save APK.")
                }
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("html_zip_converter_list"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Header Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PhoneAndroid,
                                contentDescription = "HTML & ZIP to App Converter",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "HTML-to-App & ZIP-to-App Studio",
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Convert apps/websites made here, external .zip bundles, .html files, or pasted HTML into native Android apps with full Icon & AdMob control.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // Export summary banner if present
        if (exportBanner != null) {
            item {
                Surface(
                    color = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            width = 1.dp,
                            color = MaterialTheme.colorScheme.tertiary,
                            shape = RoundedCornerShape(14.dp)
                        )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Exported: ${exportBanner.archiveFileName}",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.tertiary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${exportBanner.packagedFiles.size} files (${exportBanner.totalBytes / 1024} KB) • ${exportBanner.destinationDescription}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        TextButton(onClick = onDismissExportBanner) {
                            Text("Dismiss")
                        }
                    }
                }
            }
        }

        // 2. Input Source Selector (Made Here, Paste HTML, External .html, External .zip)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.FolderZip,
                            contentDescription = "Select Input Source",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "1. Select App Source (Made Here, HTML, or ZIP)",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ConverterSourceType.entries.forEach { src ->
                            FilterChip(
                                selected = selectedSourceType == src,
                                onClick = { selectedSourceType = src },
                                label = {
                                    Text(src.label, style = MaterialTheme.typography.labelSmall)
                                },
                                modifier = Modifier.testTag("converter_source_chip_${src.id.lowercase()}")
                            )
                        }
                    }

                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Active Bundle: $bundleSourceLabel",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "Entry File: $bundleEntryFileName • Extra ZIP Assets: ${extractedZipFiles.size} files",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    when (selectedSourceType) {
                        ConverterSourceType.MADE_HERE -> {
                            if (savedProjects.isEmpty()) {
                                Text(
                                    text = "No projects generated in Studio or Web Maker yet. Generate an app or website first, or switch to Paste HTML / Import ZIP.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            } else {
                                Text(
                                    text = "Tap any project made in OmniPrompt Studio to load it into the converter:",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    savedProjects.take(8).forEach { proj ->
                                        val isSelected = selectedStudioProjectId == proj.id
                                        Surface(
                                            color = if (isSelected) {
                                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                                            } else {
                                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                                            },
                                            shape = RoundedCornerShape(10.dp),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable {
                                                    selectedStudioProjectId = proj.id
                                                    val extracted = WebToAndroidAppPackager.extractFromStudioProject(proj)
                                                    bundleSourceLabel = extracted.sourceLabel
                                                    bundleEntryFileName = extracted.entryHtmlFileName
                                                    htmlEditorText = extracted.mainHtmlContent
                                                    extractedZipFiles = emptyMap()
                                                    appName = proj.title.take(40)
                                                    previewRefreshTick++
                                                    onShowMessage("Loaded '${proj.title}' into Web→App Converter!")
                                                }
                                                .testTag("converter_pick_project_${proj.id}")
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(12.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = proj.title,
                                                        style = MaterialTheme.typography.labelLarge,
                                                        color = MaterialTheme.colorScheme.onSurface
                                                    )
                                                    Text(
                                                        text = if (proj.isWebsiteProject()) "Website Maker Project" else "Android Studio Project",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.primary
                                                    )
                                                }
                                                if (isSelected) {
                                                    Icon(
                                                        imageVector = Icons.Default.CheckCircle,
                                                        contentDescription = "Selected Project",
                                                        tint = MaterialTheme.colorScheme.tertiary,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        ConverterSourceType.EXTERNAL_HTML -> {
                            Button(
                                onClick = { htmlFilePicker.launch("text/html") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("import_external_html_button"),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Html,
                                    contentDescription = "Select HTML File",
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Select External .html File from Device")
                            }
                        }

                        ConverterSourceType.EXTERNAL_ZIP -> {
                            Button(
                                onClick = { zipFilePicker.launch("application/zip") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("import_external_zip_button"),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FolderZip,
                                    contentDescription = "Select ZIP File",
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Select External Website .zip Archive")
                            }

                            if (extractedZipFiles.isNotEmpty()) {
                                Text(
                                    text = "Extracted Files (${extractedZipFiles.size}): ${extractedZipFiles.keys.take(6).joinToString(", ")}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.tertiary
                                )
                            }
                        }

                        ConverterSourceType.PASTED_HTML -> {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        val clip = clipboardManager.getText()?.text.orEmpty()
                                        if (clip.isNotBlank()) {
                                            htmlEditorText = clip
                                            bundleSourceLabel = "Pasted HTML from Clipboard"
                                            extractedZipFiles = emptyMap()
                                            previewRefreshTick++
                                            onShowMessage("Pasted HTML from clipboard into converter!")
                                        } else {
                                            onShowMessage("Clipboard is empty. Copy your HTML code first.")
                                        }
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("paste_html_clipboard_button"),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ContentPaste,
                                        contentDescription = "Paste HTML",
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Paste HTML")
                                }

                                OutlinedButton(
                                    onClick = {
                                        htmlEditorText = WebToAndroidAppPackager.defaultStarterHtml(appName)
                                        bundleSourceLabel = "Starter HTML5 Template"
                                        extractedZipFiles = emptyMap()
                                        previewRefreshTick++
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Code,
                                        contentDescription = "Reset Template",
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Starter HTML")
                                }
                            }
                        }
                    }

                    // Inline HTML5 Source Inspector / Editor (Always available to tweak any imported source)
                    OutlinedTextField(
                        value = htmlEditorText,
                        onValueChange = {
                            htmlEditorText = it
                            previewRefreshTick++
                        },
                        label = { Text("Entry HTML5 Code ($bundleEntryFileName)") },
                        textStyle = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = JetBrainsMonoFontFamily
                        ),
                        minLines = 5,
                        maxLines = 10,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("converter_html_editor_input"),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }
        }

        // 3. App Identity & Custom App Icon Studio
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Palette,
                            contentDescription = "App Identity and Icon",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "2. App Identity & Custom Launcher Icon",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    OutlinedTextField(
                        value = appName,
                        onValueChange = { appName = it.take(50) },
                        label = { Text("Android App Name (Launcher Label)") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("converter_app_name_input"),
                        shape = RoundedCornerShape(10.dp)
                    )

                    OutlinedTextField(
                        value = packageName,
                        onValueChange = { packageName = it.take(70) },
                        label = { Text("Android Package ID (applicationId)") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("converter_package_name_input"),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = versionName,
                            onValueChange = { versionName = it.take(15) },
                            label = { Text("Version Name") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                        OutlinedTextField(
                            value = versionCodeStr,
                            onValueChange = { input ->
                                versionCodeStr = input.filter { it.isDigit() }.take(5)
                            },
                            label = { Text("Version Code") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

                    // Live Adaptive Icon Preview + Custom Photo Picker
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        val bgCol = remember(customIconBgHex) { parseSafeHexColor(customIconBgHex, Color(0xFF0F172A)) }
                        val fgCol = remember(customIconFgHex) { parseSafeHexColor(customIconFgHex, Color(0xFF38BDF8)) }

                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(RoundedCornerShape(18.dp))
                                .background(bgCol)
                                .border(2.dp, fgCol.copy(alpha = 0.7f), RoundedCornerShape(18.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Android,
                                contentDescription = "Live Adaptive App Icon Preview",
                                tint = fgCol,
                                modifier = Modifier.size(34.dp)
                            )
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Adaptive Icon Preview",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (customIconUriString.isNotBlank()) {
                                    "Custom Photo Icon attached + Adaptive Vector fallback"
                                } else {
                                    "Preset: ${ConverterIconPreset.fromId(selectedIconPresetId).label} ($customIconBgHex / $customIconFgHex)"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedButton(
                                onClick = {
                                    iconPhotoPicker.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("pick_custom_icon_photo_button"),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Image,
                                    contentDescription = "Pick Custom Icon Image",
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Pick Custom Icon Image")
                            }
                        }
                    }

                    Text(
                        text = "Adaptive Icon Vector Style:",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ConverterIconPreset.entries.forEach { preset ->
                            FilterChip(
                                selected = selectedIconPresetId == preset.id,
                                onClick = {
                                    selectedIconPresetId = preset.id
                                    customIconBgHex = preset.bgHex
                                    customIconFgHex = preset.fgHex
                                },
                                label = {
                                    Text(preset.label, style = MaterialTheme.typography.labelSmall)
                                }
                            )
                        }
                    }

                    Text(
                        text = "Icon Background & Foreground Swatches:",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ICON_BG_SWATCHES.forEachIndexed { idx, bgHex ->
                            val fgHex = ICON_FG_SWATCHES.getOrElse(idx) { "#38BDF8" }
                            val isSelected = customIconBgHex.equals(bgHex, ignoreCase = true)
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    customIconBgHex = bgHex
                                    customIconFgHex = fgHex
                                },
                                label = {
                                    Text("$bgHex / $fgHex", style = MaterialTheme.typography.labelSmall)
                                }
                            )
                        }
                    }
                }
            }
        }

        // 4. AdMob & Monetization Controls (Full Control over Ads in Exported App)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AdUnits,
                                contentDescription = "AdMob Monetization Controls",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "3. AdMob & App Monetization Controls",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Inject Banner, Interstitial, and Rewarded Ads into your converted app",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Switch(
                            checked = adsEnabled,
                            onCheckedChange = { adsEnabled = it },
                            modifier = Modifier.testTag("converter_ads_enabled_switch")
                        )
                    }

                    if (adsEnabled) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Configure AdMob Unit IDs:",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                            TextButton(
                                onClick = {
                                    adMobAppId = "ca-app-pub-3940256099942544~3347511713"
                                    bannerAdUnitId = "ca-app-pub-3940256099942544/6300978111"
                                    interstitialAdUnitId = "ca-app-pub-3940256099942544/1033173712"
                                    rewardedAdUnitId = "ca-app-pub-3940256099942544/5224354917"
                                    onShowMessage("Filled official Google AdMob sample test unit IDs!")
                                },
                                modifier = Modifier.testTag("fill_sample_admob_ids_button")
                            ) {
                                Text("Fill Test Ad IDs", style = MaterialTheme.typography.labelSmall)
                            }
                        }

                        OutlinedTextField(
                            value = adMobAppId,
                            onValueChange = { adMobAppId = it.trim() },
                            label = { Text("AdMob Application ID (ca-app-pub-...~...)") },
                            placeholder = { Text("ca-app-pub-XXXXXXXXXXXXXXXX~YYYYYYYYYY") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("converter_admob_app_id_input"),
                            shape = RoundedCornerShape(10.dp)
                        )

                        OutlinedTextField(
                            value = bannerAdUnitId,
                            onValueChange = { bannerAdUnitId = it.trim() },
                            label = { Text("Banner Ad Unit ID") },
                            placeholder = { Text("ca-app-pub-XXXXXXXXXXXXXXXX/ZZZZZZZZZZ") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("converter_banner_ad_unit_input"),
                            shape = RoundedCornerShape(10.dp)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Banner Placement:",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            listOf("BOTTOM", "TOP").forEach { pos ->
                                FilterChip(
                                    selected = bannerPlacement == pos,
                                    onClick = { bannerPlacement = pos },
                                    label = { Text(pos, style = MaterialTheme.typography.labelSmall) }
                                )
                            }
                        }

                        OutlinedTextField(
                            value = interstitialAdUnitId,
                            onValueChange = { interstitialAdUnitId = it.trim() },
                            label = { Text("Interstitial Ad Unit ID (Optional)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Show Interstitial Ad on App Launch",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Switch(
                                checked = interstitialOnLaunch,
                                onCheckedChange = { interstitialOnLaunch = it }
                            )
                        }

                        OutlinedTextField(
                            value = rewardedAdUnitId,
                            onValueChange = { rewardedAdUnitId = it.trim() },
                            label = { Text("Rewarded Ad Unit ID (Optional JS Bridge)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }
            }
        }

        // 5. Native WebView Shell, Orientation & Permissions Controls
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.SettingsApplications,
                            contentDescription = "Native Shell Settings",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "4. Orientation, Capabilities & Permissions",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Text(
                        text = "Screen Orientation:",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(
                            "PORTRAIT" to "Portrait Locked",
                            "LANDSCAPE" to "Landscape Locked",
                            "SENSOR" to "Auto-Rotate (Sensor)"
                        ).forEach { (id, label) ->
                            FilterChip(
                                selected = orientation == id,
                                onClick = { orientation = id },
                                label = { Text(label, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }

                    Text(
                        text = "WebView & Shell Toggles:",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(
                            selected = fullscreenImmersive,
                            onClick = { fullscreenImmersive = !fullscreenImmersive },
                            label = { Text("Fullscreen Mode", style = MaterialTheme.typography.labelSmall) }
                        )
                        FilterChip(
                            selected = enableJavaScript,
                            onClick = { enableJavaScript = !enableJavaScript },
                            label = { Text("JavaScript Bridge", style = MaterialTheme.typography.labelSmall) }
                        )
                        FilterChip(
                            selected = enableDomStorage,
                            onClick = { enableDomStorage = !enableDomStorage },
                            label = { Text("DOM LocalStorage", style = MaterialTheme.typography.labelSmall) }
                        )
                        FilterChip(
                            selected = enableOfflineCache,
                            onClick = { enableOfflineCache = !enableOfflineCache },
                            label = { Text("Offline Asset Cache", style = MaterialTheme.typography.labelSmall) }
                        )
                        FilterChip(
                            selected = enableFileUpload,
                            onClick = { enableFileUpload = !enableFileUpload },
                            label = { Text("File Upload Access", style = MaterialTheme.typography.labelSmall) }
                        )
                        FilterChip(
                            selected = enableZoomControls,
                            onClick = { enableZoomControls = !enableZoomControls },
                            label = { Text("Pinch Zoom", style = MaterialTheme.typography.labelSmall) }
                        )
                    }

                    Text(
                        text = "Android Manifest Permissions:",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(
                            selected = permCamera,
                            onClick = { permCamera = !permCamera },
                            label = { Text("Camera", style = MaterialTheme.typography.labelSmall) }
                        )
                        FilterChip(
                            selected = permLocation,
                            onClick = { permLocation = !permLocation },
                            label = { Text("Fine Location", style = MaterialTheme.typography.labelSmall) }
                        )
                        FilterChip(
                            selected = permVibrate,
                            onClick = { permVibrate = !permVibrate },
                            label = { Text("Vibrate", style = MaterialTheme.typography.labelSmall) }
                        )
                        FilterChip(
                            selected = permNotifications,
                            onClick = { permNotifications = !permNotifications },
                            label = { Text("Notifications", style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
            }
        }

        // 6. Live Converted Android App Interactive Preview + Export Actions
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "5. Live Converted Android App Preview & Export",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    // Simulated Android Phone Frame
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(18.dp))
                            .border(
                                width = 2.dp,
                                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                                shape = RoundedCornerShape(18.dp)
                            )
                            .background(Color(0xFF0B1120))
                    ) {
                        if (!fullscreenImmersive) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(parseSafeHexColor(customIconBgHex, Color(0xFF0F172A)))
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Android,
                                        contentDescription = "App Icon",
                                        tint = parseSafeHexColor(customIconFgHex, Color(0xFF38BDF8)),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = appName.ifBlank { "OmniWeb Native App" },
                                        style = MaterialTheme.typography.labelLarge,
                                        color = Color.White
                                    )
                                }
                                Text(
                                    text = orientation,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFF94A3B8)
                                )
                            }
                        }

                        if (adsEnabled && bannerPlacement == "TOP") {
                            SimulatedAdBannerBar(unitId = bannerAdUnitId)
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(320.dp)
                                .testTag("converted_app_preview_webview")
                        ) {
                            val htmlSnapshot = remember(htmlEditorText, previewRefreshTick) { htmlEditorText }
                            AndroidView(
                                modifier = Modifier.fillMaxSize(),
                                factory = { ctx ->
                                    WebView(ctx).apply {
                                        settings.javaScriptEnabled = enableJavaScript
                                        settings.domStorageEnabled = enableDomStorage
                                        webViewClient = WebViewClient()
                                        webChromeClient = WebChromeClient()
                                        loadDataWithBaseURL(
                                            "https://omniprompt.converted.local/",
                                            htmlSnapshot,
                                            "text/html",
                                            "UTF-8",
                                            null
                                        )
                                    }
                                },
                                update = { webView ->
                                    webView.settings.javaScriptEnabled = enableJavaScript
                                    webView.settings.domStorageEnabled = enableDomStorage
                                    webView.loadDataWithBaseURL(
                                        "https://omniprompt.converted.local/",
                                        htmlSnapshot,
                                        "text/html",
                                        "UTF-8",
                                        null
                                    )
                                }
                            )
                        }

                        if (adsEnabled && bannerPlacement == "BOTTOM") {
                            SimulatedAdBannerBar(unitId = bannerAdUnitId)
                        }
                    }

                    // Export & Save Buttons
                    Button(
                        onClick = {
                            onSaveConvertedAppToWorkspace(currentConfig, currentBundle)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("save_converted_app_workspace_button"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Save,
                            contentDescription = "Save Converted App to Workspace",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Save Converted Android App to Studio Workspace")
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                val fileSlug = appName.trim().lowercase().replace(Regex("[^a-z0-9]+"), "_").ifBlank { "converted_app" }
                                exportZipCreator.launch("${fileSlug}_android_project.zip")
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("export_converted_zip_device_button"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Download,
                                contentDescription = "Download Android Project ZIP",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Download App .zip")
                        }

                        OutlinedButton(
                            onClick = {
                                onExportConvertedZipToWorkspace(currentConfig, currentBundle)
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("export_converted_zip_internal_button"),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Archive,
                                contentDescription = "Package in Workspace",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Package in App")
                        }
                    }

                    OutlinedButton(
                        onClick = {
                            val fileSlug = appName.trim().lowercase().replace(Regex("[^a-z0-9]+"), "_").ifBlank { "converted_app" }
                            exportApkCreator.launch("${fileSlug}_signed.apk")
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("export_signed_apk_device_button"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Android,
                            contentDescription = "Download Signed APK",
                            tint = Color(0xFF10B981),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Download Signed Android .APK to Device")
                    }
                }
            }
        }
    }
}

@Composable
private fun SimulatedAdBannerBar(unitId: String) {
    Surface(
        color = Color(0xFF1E293B),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Surface(
                color = Color(0xFFFBBF24),
                shape = RoundedCornerShape(4.dp)
            ) {
                Text(
                    text = "Ad",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.Black,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "AdMob Banner Active • ${unitId.ifBlank { "Test Unit ID" }.take(28)}",
                style = MaterialTheme.typography.labelSmall,
                color = Color(0xFFE2E8F0),
                modifier = Modifier.weight(1f)
            )
        }
    }
}

private fun parseSafeHexColor(hex: String, fallback: Color): Color {
    return try {
        val clean = hex.trim().removePrefix("#")
        val longVal = clean.toLong(16)
        if (clean.length == 6) {
            Color(0xFF000000 or longVal)
        } else {
            fallback
        }
    } catch (_: Exception) {
        fallback
    }
}
