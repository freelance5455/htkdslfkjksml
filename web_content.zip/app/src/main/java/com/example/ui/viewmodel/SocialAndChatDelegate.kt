package com.example.ui.viewmodel

import android.content.Context
import com.example.data.model.ArkPost
import com.example.data.model.ArkStory
import com.example.data.model.BlockedUser
import com.example.data.model.DirectConversation
import com.example.data.model.DirectMessage
import com.example.data.model.FollowEdge
import com.example.data.model.FollowRequest
import com.example.data.model.FriendEdge
import com.example.data.model.RestrictedUser
import com.example.data.model.StoryHighlight
import com.example.data.model.UserProfile
import com.example.data.repository.DirectMessageRepository
import com.example.data.repository.FeedRepository
import com.example.data.repository.FollowRepository
import com.example.data.repository.StoryRepository
import com.example.data.repository.UserRepository
import com.example.data.repository.unwrapFirestoreException
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalCoroutinesApi::class)
class SocialAndChatDelegate(
    private val currentUserId: String,
    private val scope: CoroutineScope,
    private val userRepo: UserRepository,
    private val followRepo: FollowRepository,
    private val feedRepo: FeedRepository,
    private val storyRepo: StoryRepository,
    private val dmRepo: DirectMessageRepository,
    private val blockedUsersFlow: StateFlow<UiState<List<BlockedUser>>>,
    private val postMessage: (String) -> Unit
) {
    val followers: StateFlow<List<FollowEdge>> = followRepo.observeFollowers(currentUserId)
        .catch { emit(emptyList()) }
        .stateIn(scope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val following: StateFlow<List<FollowEdge>> = followRepo.observeFollowing(currentUserId)
        .catch { emit(emptyList()) }
        .stateIn(scope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val incomingFollowRequests: StateFlow<List<FollowRequest>> = followRepo.observeIncomingFollowRequests(currentUserId)
        .catch { emit(emptyList()) }
        .stateIn(scope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val outgoingFollowRequests: StateFlow<List<FollowRequest>> = followRepo.observeOutgoingFollowRequests(currentUserId)
        .catch { emit(emptyList()) }
        .stateIn(scope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val restrictedUsers: StateFlow<List<RestrictedUser>> = followRepo.observeRestrictedUsers(currentUserId)
        .catch { emit(emptyList()) }
        .stateIn(scope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val myHighlights: StateFlow<List<StoryHighlight>> = storyRepo.observeUserHighlights(currentUserId, currentUserId)
        .catch { emit(emptyList()) }
        .stateIn(scope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val pendingTagRequests: StateFlow<List<ArkPost>> = feedRepo.observePendingTagRequests(currentUserId)
        .catch { emit(emptyList()) }
        .stateIn(scope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val conversations: StateFlow<List<DirectConversation>> = combine(
        dmRepo.observeConversations(currentUserId).catch { emit(emptyList()) },
        blockedUsersFlow
    ) { list, blockedState ->
        val blockedSet = (blockedState as? UiState.Success)?.data?.map { it.blockedUid }?.toSet() ?: emptySet()
        list.filter { conv ->
            val otherUid = conv.participantUids.firstOrNull { it != currentUserId }
            otherUid == null || !blockedSet.contains(otherUid)
        }
    }.stateIn(scope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val activeConversations: StateFlow<List<DirectConversation>> = conversations
        .map { list -> list.filter { it.status == "active" || it.requesterUid == currentUserId } }
        .stateIn(scope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val messageRequests: StateFlow<List<DirectConversation>> = conversations
        .map { list -> list.filter { it.status == "request" && it.requesterUid != currentUserId } }
        .stateIn(scope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val unreadDmCount: StateFlow<Int> = conversations
        .map { list ->
            list.sumOf { (it.unreadCounts[currentUserId] ?: 0L).coerceAtLeast(0L) }.toInt()
        }
        .stateIn(scope, SharingStarted.WhileSubscribed(5000L), 0)

    private val _selectedConversationId = MutableStateFlow<String?>(null)
    val selectedConversationId = _selectedConversationId.asStateFlow()

    val selectedConversation: StateFlow<DirectConversation?> = combine(
        conversations,
        _selectedConversationId
    ) { list, cid ->
        if (cid == null) null else list.firstOrNull { it.id == cid }
    }.stateIn(scope, SharingStarted.WhileSubscribed(5000L), null)

    val activeMessages: StateFlow<List<DirectMessage>> = _selectedConversationId.flatMapLatest { cid ->
        if (cid == null) flowOf(emptyList()) else dmRepo.observeMessages(cid)
    }.catch { emit(emptyList()) }
        .stateIn(scope, SharingStarted.WhileSubscribed(5000L), emptyList())

    // Explore discovery & search state
    private val _recommendedCreators = MutableStateFlow<List<UserProfile>>(emptyList())
    val recommendedCreators = _recommendedCreators.asStateFlow()

    private val _exploreUserSearchResults = MutableStateFlow<List<UserProfile>>(emptyList())
    val exploreUserSearchResults = _exploreUserSearchResults.asStateFlow()

    private val _explorePostSearchResults = MutableStateFlow<List<ArkPost>>(emptyList())
    val explorePostSearchResults = _explorePostSearchResults.asStateFlow()

    private val _selectedHashtag = MutableStateFlow<String?>(null)
    val selectedHashtag = _selectedHashtag.asStateFlow()

    val hashtagPosts: StateFlow<List<ArkPost>> = _selectedHashtag.flatMapLatest { tag ->
        if (tag.isNullOrBlank()) flowOf(emptyList()) else feedRepo.observeExplorePostsByHashtag(tag)
    }.catch { emit(emptyList()) }
        .stateIn(scope, SharingStarted.WhileSubscribed(5000L), emptyList())

    // Inspected external user profile state
    private val _inspectedUserId = MutableStateFlow<String?>(null)
    val inspectedUserId = _inspectedUserId.asStateFlow()

    val inspectedProfile: StateFlow<UserProfile?> = _inspectedUserId.flatMapLatest { uid ->
        if (uid == null) flowOf(null) else userRepo.observeUserProfile(uid)
    }.catch { emit(null) }
        .stateIn(scope, SharingStarted.WhileSubscribed(5000L), null)

    val inspectedPosts: StateFlow<List<ArkPost>> = _inspectedUserId.flatMapLatest { uid ->
        if (uid == null) flowOf(emptyList()) else feedRepo.observeProfilePostsForViewer(uid, currentUserId)
    }.catch { emit(emptyList()) }
        .stateIn(scope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val inspectedTaggedPosts: StateFlow<List<ArkPost>> = _inspectedUserId.flatMapLatest { uid ->
        if (uid == null) flowOf(emptyList()) else feedRepo.observeTaggedPosts(uid, currentUserId)
    }.catch { emit(emptyList()) }
        .stateIn(scope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val inspectedHighlights: StateFlow<List<StoryHighlight>> = _inspectedUserId.flatMapLatest { uid ->
        if (uid == null) flowOf(emptyList()) else storyRepo.observeUserHighlights(uid, currentUserId)
    }.catch { emit(emptyList()) }
        .stateIn(scope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val myTaggedPosts: StateFlow<List<ArkPost>> = feedRepo.observeTaggedPosts(currentUserId, currentUserId)
        .catch { emit(emptyList()) }
        .stateIn(scope, SharingStarted.WhileSubscribed(5000L), emptyList())

    private val _inspectedFollowers = MutableStateFlow<List<FollowEdge>>(emptyList())
    val inspectedFollowers = _inspectedFollowers.asStateFlow()

    private val _inspectedFollowing = MutableStateFlow<List<FollowEdge>>(emptyList())
    val inspectedFollowing = _inspectedFollowing.asStateFlow()

    init {
        refreshExploreDiscovery()
    }

    fun openUserProfile(targetUid: String) {
        _inspectedUserId.value = targetUid
        scope.launch {
            _inspectedFollowers.value = followRepo.fetchFollowersOnce(targetUid)
            _inspectedFollowing.value = followRepo.fetchFollowingOnce(targetUid)
        }
    }

    fun refreshExploreDiscovery() {
        scope.launch {
            val exclude = following.value.map { it.peerUid }.toSet()
            _recommendedCreators.value = userRepo.fetchRecommendedCreators(currentUserId, exclude)
        }
    }

    fun searchExplore(query: String) {
        scope.launch {
            val clean = query.trim()
            if (clean.isBlank()) {
                _exploreUserSearchResults.value = emptyList()
                _explorePostSearchResults.value = emptyList()
                return@launch
            }
            userRepo.searchUsersExplore(clean, currentUserId)
                .onSuccess { _exploreUserSearchResults.value = it }
            _explorePostSearchResults.value = feedRepo.searchExplorePosts(clean)
        }
    }

    fun searchByHashtag(tag: String?) {
        val clean = tag?.trim()?.lowercase()?.removePrefix("#")?.takeIf { it.isNotBlank() }
        _selectedHashtag.value = clean
    }

    fun clearExploreSearch() {
        _exploreUserSearchResults.value = emptyList()
        _explorePostSearchResults.value = emptyList()
        _selectedHashtag.value = null
    }

    fun followOrRequest(currentUser: UserProfile, targetUser: UserProfile) {
        scope.launch {
            followRepo.followOrRequestUser(currentUser, targetUser)
                .onSuccess { outcome ->
                    if (outcome == "following") {
                        userRepo.sendNotification(
                            recipientUid = targetUser.userId,
                            senderUsername = currentUser.username,
                            type = "follow",
                            title = "New Follower",
                            body = "@${currentUser.username} started following you",
                            refId = currentUser.userId
                        )
                        postMessage("Following @${targetUser.username}")
                    } else {
                        userRepo.sendNotification(
                            recipientUid = targetUser.userId,
                            senderUsername = currentUser.username,
                            type = "follow_request",
                            title = "Follow Request",
                            body = "@${currentUser.username} requested to follow you",
                            refId = currentUser.userId
                        )
                        postMessage("Follow request sent to @${targetUser.username}")
                    }
                    if (_inspectedUserId.value == targetUser.userId) {
                        _inspectedFollowers.value = followRepo.fetchFollowersOnce(targetUser.userId)
                    }
                }
                .onFailure { err ->
                    val fs = err.unwrapFirestoreException()
                    val msg = if (fs?.code == FirebaseFirestoreException.Code.PERMISSION_DENIED) {
                        "Unable to follow @${targetUser.username} due to block or account restrictions."
                    } else {
                        err.message ?: "Follow action failed."
                    }
                    postMessage(msg)
                }
        }
    }

    fun acceptFollowRequest(request: FollowRequest, currentUser: UserProfile) {
        scope.launch {
            followRepo.acceptFollowRequest(request, currentUser)
                .onSuccess {
                    userRepo.sendNotification(
                        recipientUid = request.fromUid,
                        senderUsername = currentUser.username,
                        type = "follow_accept",
                        title = "Request Accepted",
                        body = "@${currentUser.username} approved your follow request",
                        refId = currentUser.userId
                    )
                    postMessage("@${request.fromUsername} is now following you")
                }
                .onFailure { postMessage(it.message ?: "Could not accept follow request.") }
        }
    }

    fun rejectFollowRequest(requestId: String) {
        scope.launch {
            followRepo.rejectFollowRequest(requestId)
                .onSuccess { postMessage("Follow request declined.") }
        }
    }

    fun cancelFollowRequest(requestId: String) {
        scope.launch {
            followRepo.cancelFollowRequest(requestId)
                .onSuccess { postMessage("Follow request cancelled.") }
        }
    }

    fun unfollowUser(targetUid: String, targetUsername: String) {
        scope.launch {
            followRepo.unfollowUser(targetUid)
                .onSuccess {
                    postMessage("Unfollowed @$targetUsername")
                    if (_inspectedUserId.value == targetUid) {
                        _inspectedFollowers.value = followRepo.fetchFollowersOnce(targetUid)
                    }
                }
                .onFailure { postMessage(it.message ?: "Could not unfollow.") }
        }
    }

    fun removeFollower(followerUid: String, followerUsername: String) {
        scope.launch {
            followRepo.removeFollower(followerUid)
                .onSuccess { postMessage("Removed @$followerUsername from followers") }
                .onFailure { postMessage(it.message ?: "Failed to remove follower.") }
        }
    }

    fun restrictUser(targetUid: String, targetUsername: String) {
        scope.launch {
            followRepo.restrictUser(targetUid, targetUsername)
                .onSuccess { postMessage("Restricted @$targetUsername") }
        }
    }

    fun unrestrictUser(targetUid: String) {
        scope.launch {
            followRepo.unrestrictUser(targetUid)
                .onSuccess { postMessage("User unrestricted.") }
        }
    }

    fun selectConversation(conversationId: String?) {
        _selectedConversationId.value = conversationId
        if (conversationId != null) {
            scope.launch { dmRepo.markConversationRead(conversationId, currentUserId) }
        }
    }

    fun openOrStartDm(
        currentUser: UserProfile,
        targetUser: UserProfile,
        myFriends: List<FriendEdge>,
        onReady: (String) -> Unit
    ) {
        val isBlocked = (blockedUsersFlow.value as? UiState.Success)?.data
            ?.any { it.blockedUid == targetUser.userId } == true
        scope.launch {
            dmRepo.openOrStartConversation(
                currentUser = currentUser,
                targetUser = targetUser,
                myFollowing = following.value,
                myFriends = myFriends,
                isBlocked = isBlocked
            ).onSuccess { conv ->
                _selectedConversationId.value = conv.id
                dmRepo.markConversationRead(conv.id, currentUserId)
                onReady(conv.id)
            }.onFailure {
                postMessage(it.message ?: "Cannot message @${targetUser.username}")
            }
        }
    }

    fun sendDm(
        conversation: DirectConversation,
        sender: UserProfile,
        text: String,
        imageBase64: String? = null,
        videoThumbnailBase64: String? = null,
        videoDurationMs: Long = 0L,
        videoChunksBase64: List<String> = emptyList(),
        replyToId: String? = null,
        replyToPreview: String? = null
    ) {
        scope.launch {
            dmRepo.sendDirectMessage(
                conversation = conversation,
                sender = sender,
                text = text,
                imageBase64 = imageBase64,
                videoThumbnailBase64 = videoThumbnailBase64,
                videoDurationMs = videoDurationMs,
                videoChunksBase64 = videoChunksBase64,
                replyToId = replyToId,
                replyToPreview = replyToPreview
            ).onFailure { postMessage(it.message ?: "Failed to send message.") }
        }
    }

    fun acceptMessageRequest(conversationId: String) {
        scope.launch {
            dmRepo.acceptMessageRequest(conversationId)
                .onSuccess { postMessage("Message request accepted.") }
        }
    }

    fun declineMessageRequest(conversationId: String, onDone: () -> Unit = {}) {
        scope.launch {
            dmRepo.declineMessageRequest(conversationId)
                .onSuccess {
                    if (_selectedConversationId.value == conversationId) {
                        _selectedConversationId.value = null
                    }
                    postMessage("Message request declined.")
                    onDone()
                }
        }
    }

    fun markDmRead(conversationId: String) {
        scope.launch { dmRepo.markConversationRead(conversationId, currentUserId) }
    }

    fun setDmTyping(conversationId: String, isTyping: Boolean) {
        scope.launch { dmRepo.setTyping(conversationId, isTyping) }
    }

    fun reactToDm(conversationId: String, messageId: String, emoji: String) {
        scope.launch { dmRepo.reactToDirectMessage(conversationId, messageId, emoji) }
    }

    fun deleteDm(conversationId: String, messageId: String) {
        scope.launch { dmRepo.deleteDirectMessage(conversationId, messageId) }
    }

    suspend fun loadDmVideoFile(context: Context, conversationId: String, messageId: String): File? =
        dmRepo.fetchMessageVideoFile(context, conversationId, messageId)

    fun createHighlight(owner: UserProfile, title: String, story: ArkStory, friends: List<FriendEdge>) {
        scope.launch {
            storyRepo.createHighlight(owner, title, story, followers.value, friends)
                .onSuccess { postMessage("Saved to '$title' Highlight!") }
                .onFailure { postMessage(it.message ?: "Could not create highlight.") }
        }
    }

    fun addToHighlight(highlight: StoryHighlight, story: ArkStory) {
        scope.launch {
            storyRepo.addStoryToHighlight(highlight, story)
                .onSuccess { postMessage("Added to '${highlight.title}'!") }
                .onFailure { postMessage(it.message ?: "Failed to update highlight.") }
        }
    }

    fun renameHighlight(highlightId: String, newTitle: String) {
        scope.launch {
            storyRepo.renameHighlight(highlightId, newTitle)
                .onSuccess { postMessage("Highlight renamed.") }
        }
    }

    fun deleteHighlight(highlightId: String) {
        scope.launch {
            storyRepo.deleteHighlight(highlightId)
                .onSuccess { postMessage("Highlight removed.") }
        }
    }

    fun approvePostTag(postId: String) {
        scope.launch {
            feedRepo.approvePostTag(postId)
                .onSuccess { postMessage("Post added to your Tagged grid.") }
        }
    }

    fun declineOrRemovePostTag(postId: String) {
        scope.launch {
            feedRepo.declineOrRemovePostTag(postId)
                .onSuccess { postMessage("Tag removed.") }
        }
    }
}
