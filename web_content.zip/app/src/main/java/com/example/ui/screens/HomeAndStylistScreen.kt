package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Checkroom
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.data.model.AiOutfitRecommendation
import com.example.data.model.ChatMessage
import com.example.data.model.FashionProduct
import com.example.data.model.UserProfile
import com.example.ui.viewmodel.ChatUiState
import com.example.ui.viewmodel.StylistUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    userProfile: UserProfile?,
    userPhotoBitmap: Bitmap?,
    catalogProducts: List<FashionProduct>,
    stylistUiState: StylistUiState,
    chatMessages: List<ChatMessage>,
    chatUiState: ChatUiState,
    onNavigateToTryOn: () -> Unit,
    onNavigateToDiscover: () -> Unit,
    onSelectProductForDetail: (FashionProduct) -> Unit,
    onSelectProductForTryOn: (FashionProduct) -> Unit,
    onSaveProduct: (FashionProduct, String?) -> Unit,
    onGenerateRecommendations: (
        style: String,
        occasion: String,
        clothingPrefs: String,
        colors: String,
        budgetInr: Int,
        retailers: String,
        skipped: Boolean
    ) -> Unit,
    onSendChatMessage: (String) -> Unit
) {
    var showStylistQuestionnaire by remember { mutableStateOf(false) }
    var showChatStylistSheet by remember { mutableStateOf(false) }

    val trendingOutfits = remember(catalogProducts) {
        catalogProducts.filter { it.isTrending || it.isOutfitCombo }
    }
    val bestDeals = remember(catalogProducts) {
        catalogProducts.sortedByDescending { p ->
            val maxDisc = p.retailerOffers.mapNotNull { it.discountPercent }.maxOrNull() ?: 0
            maxDisc
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("home_screen_list"),
        contentPadding = PaddingValues(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // 1. Editorial Hero Banner & Welcome Message
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    MaterialTheme.colorScheme.surface,
                                    MaterialTheme.colorScheme.surfaceVariant
                                )
                            )
                        )
                        .padding(22.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            shape = RoundedCornerShape(50)
                        ) {
                            Text(
                                text = if (userProfile?.membershipTier == "PREMIUM") "NOIR ATELIER PREMIUM" else "STYLE AI ATELIER",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                            )
                        }

                        if (userPhotoBitmap != null) {
                            Image(
                                bitmap = userPhotoBitmap.asImageBitmap(),
                                contentDescription = "Your uploaded personal photo",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Welcome, ${userProfile?.displayName ?: "Style Connoisseur"}",
                        style = MaterialTheme.typography.headlineLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Discover real designer & street looks, generate realistic AI Virtual Try-Ons on your own photo, and compare live prices across Amazon, Flipkart, Myntra & AJIO.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    // Primary Action Buttons: Upload Your Photo & AI Stylist
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = onNavigateToTryOn,
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("home_upload_photo_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddAPhoto,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (userPhotoBitmap == null) "Upload Photo" else "Try-On Studio",
                                style = MaterialTheme.typography.labelLarge
                            )
                        }

                        Button(
                            onClick = { showStylistQuestionnaire = true },
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.secondary,
                                contentColor = MaterialTheme.colorScheme.onSecondary
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("home_ai_stylist_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "AI Stylist",
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedButton(
                        onClick = { showChatStylistSheet = true },
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("home_chat_stylist_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Chat,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Ask AI Chat Stylist (Type or Speak)",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        // 2. Recommended For You (AI Personal Fashion Stylist Section)
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Recommended For You",
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    TextButton(onClick = { showStylistQuestionnaire = true }) {
                        Text("Customize Style", color = MaterialTheme.colorScheme.secondary)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                when (stylistUiState) {
                    is StylistUiState.Idle -> {
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(18.dp)) {
                                Text(
                                    text = "Your Personal AI Fashion Director",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Get tailored outfit recommendations for College, Casual, Formal, Office, Wedding, Party, Traditional Indian, or Streetwear — with full stylist reasoning.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Button(
                                        onClick = { showStylistQuestionnaire = true },
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text("Start Style Quiz")
                                    }
                                    OutlinedButton(
                                        onClick = {
                                            onGenerateRecommendations(
                                                userProfile?.preferredStyle ?: "Luxury Minimalist",
                                                userProfile?.preferredOccasion ?: "Casual",
                                                "Versatile shirts, jackets, trousers, and ethnic sets",
                                                userProfile?.preferredColors ?: "Black, White, Navy",
                                                (userProfile?.budgetMaxInr ?: 5000L).toInt(),
                                                userProfile?.preferredRetailers ?: "Myntra, AJIO, Amazon, Flipkart",
                                                true
                                            )
                                        },
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.testTag("skip_questions_instant_recs_button")
                                    ) {
                                        Text("Skip & Recommend Now")
                                    }
                                }
                            }
                        }
                    }

                    is StylistUiState.Loading -> {
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(20.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(28.dp),
                                    color = MaterialTheme.colorScheme.secondary,
                                    strokeWidth = 2.5.dp
                                )
                                Spacer(modifier = Modifier.width(16.dp))
                                Column {
                                    Text(
                                        text = "Curating Your Personal Lookbook...",
                                        style = MaterialTheme.typography.titleMedium
                                    )
                                    Text(
                                        text = "Analyzing colour harmony, silhouettes, budget & retailer deals.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    is StylistUiState.Error -> {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.12f)
                            ),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.error)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = stylistUiState.message,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.error
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedButton(onClick = { showStylistQuestionnaire = true }) {
                                    Text("Try Again")
                                }
                            }
                        }
                    }

                    is StylistUiState.Success -> {
                        Text(
                            text = stylistUiState.summaryHeadline,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            stylistUiState.recommendations.forEach { rec ->
                                val matchedProduct = catalogProducts.find { it.id == rec.matchedProductId }
                                    ?: catalogProducts.find {
                                        it.occasion.equals(rec.occasion, ignoreCase = true) ||
                                            it.category.equals(rec.category, ignoreCase = true)
                                    }
                                    ?: catalogProducts.first()

                                AiRecommendationCard(
                                    recommendation = rec,
                                    matchedProduct = matchedProduct,
                                    onTryOn = { onSelectProductForTryOn(matchedProduct) },
                                    onComparePrices = { onSelectProductForDetail(matchedProduct) },
                                    onSave = { onSaveProduct(matchedProduct, rec.whyRecommended) }
                                )
                            }
                        }
                    }
                }
            }
        }

        // 3. Trending Outfits Carousel
        item {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.TrendingUp,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Trending Outfits",
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    TextButton(onClick = onNavigateToDiscover) {
                        Text("View Catalogue", color = MaterialTheme.colorScheme.secondary)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(trendingOutfits, key = { it.id }) { product ->
                        TrendingOutfitCard(
                            product = product,
                            onSelect = { onSelectProductForDetail(product) },
                            onTryOn = { onSelectProductForTryOn(product) }
                        )
                    }
                }
            }
        }

        // 4. Best Deals Across Platforms
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocalOffer,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Best Multi-Retailer Deals",
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Verified discounts across Myntra, AJIO, Amazon & Flipkart",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        items(bestDeals.take(5), key = { "deal_${it.id}" }) { product ->
            val bestOffer = product.retailerOffers
                .filter { it.listedPriceInr != null }
                .minByOrNull { it.listedPriceInr ?: Int.MAX_VALUE }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clickable { onSelectProductForDetail(product) },
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AsyncImage(
                        model = product.imageUrl,
                        contentDescription = product.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(84.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    )
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = product.brand.uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.secondary
                            )
                            Surface(
                                color = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.16f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                val discount = bestOffer?.discountPercent ?: 35
                                Text(
                                    text = "$discount% OFF on ${bestOffer?.platformName ?: product.primaryRetailer}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.tertiary,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = product.name,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "₹${bestOffer?.listedPriceInr ?: product.priceInr}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "₹${bestOffer?.originalPriceInr ?: product.originalPriceInr}",
                                style = MaterialTheme.typography.bodyMedium,
                                textDecoration = TextDecoration.LineThrough,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = bestOffer?.availableOffers ?: "Compare across 4 platforms",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }

    if (showStylistQuestionnaire) {
        ModalBottomSheet(
            onDismissRequest = { showStylistQuestionnaire = false },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            AiStylistQuestionnaireSheet(
                initialStyle = userProfile?.preferredStyle ?: "Luxury Minimalist",
                initialOccasion = userProfile?.preferredOccasion ?: "College",
                initialColors = userProfile?.preferredColors ?: "Obsidian Black, White, Olive",
                initialBudget = (userProfile?.budgetMaxInr ?: 2500L).toInt(),
                initialRetailers = userProfile?.preferredRetailers ?: "Myntra, AJIO, Amazon, Flipkart",
                onSubmit = { style, occasion, clothingPrefs, colors, budget, retailers, skipped ->
                    showStylistQuestionnaire = false
                    onGenerateRecommendations(style, occasion, clothingPrefs, colors, budget, retailers, skipped)
                },
                onClose = { showStylistQuestionnaire = false }
            )
        }
    }

    if (showChatStylistSheet) {
        ModalBottomSheet(
            onDismissRequest = { showChatStylistSheet = false },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            AiChatStylistSheet(
                messages = chatMessages,
                chatUiState = chatUiState,
                onSendMessage = onSendChatMessage,
                onSelectProduct = { product ->
                    showChatStylistSheet = false
                    onSelectProductForDetail(product)
                },
                onTryOnProduct = { product ->
                    showChatStylistSheet = false
                    onSelectProductForTryOn(product)
                }
            )
        }
    }
}

@Composable
private fun AiRecommendationCard(
    recommendation: AiOutfitRecommendation,
    matchedProduct: FashionProduct,
    onTryOn: () -> Unit,
    onComparePrices: () -> Unit,
    onSave: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.45f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AsyncImage(
                    model = matchedProduct.imageUrl,
                    contentDescription = recommendation.outfitTitle,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(88.dp)
                        .clip(RoundedCornerShape(14.dp))
                )
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "${recommendation.occasion.uppercase()} • ₹${matchedProduct.priceInr}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = recommendation.outfitTitle,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${matchedProduct.brand} • ${recommendation.colorPalette}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onSave) {
                    Icon(
                        imageVector = Icons.Default.FavoriteBorder,
                        contentDescription = "Save recommended outfit",
                        tint = MaterialTheme.colorScheme.secondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "WHY STYLE AI RECOMMENDS THIS:",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = recommendation.whyRecommended,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Pair with: ${recommendation.matchingFootwear} & ${recommendation.matchingAccessories}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onTryOn,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Checkroom, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Virtual Try-On")
                }
                OutlinedButton(
                    onClick = onComparePrices,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Compare Prices")
                }
            }
        }
    }
}

@Composable
private fun TrendingOutfitCard(
    product: FashionProduct,
    onSelect: () -> Unit,
    onTryOn: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(235.dp)
            .clickable { onSelect() },
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp)
            ) {
                AsyncImage(
                    model = product.imageUrl,
                    contentDescription = product.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Surface(
                    color = MaterialTheme.colorScheme.background.copy(alpha = 0.82f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(10.dp)
                ) {
                    Text(
                        text = product.occasion.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = product.brand.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = product.name,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "₹${product.priceInr}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    TextButton(onClick = onTryOn) {
                        Text("Try On", color = MaterialTheme.colorScheme.secondary)
                    }
                }
            }
        }
    }
}

@Composable
private fun AiStylistQuestionnaireSheet(
    initialStyle: String,
    initialOccasion: String,
    initialColors: String,
    initialBudget: Int,
    initialRetailers: String,
    onSubmit: (
        style: String,
        occasion: String,
        clothingPrefs: String,
        colors: String,
        budget: Int,
        retailers: String,
        skipped: Boolean
    ) -> Unit,
    onClose: () -> Unit
) {
    val styles = listOf("Luxury Minimalist", "Streetwear", "Casual", "Formal", "Traditional Indian", "Seasonal")
    val occasions = listOf("College", "Casual", "Formal", "Office", "Wedding", "Party", "Traditional Indian", "Streetwear", "Seasonal")

    var selectedStyle by remember { mutableStateOf(initialStyle) }
    var selectedOccasion by remember { mutableStateOf(initialOccasion) }
    var clothingPreferences by remember { mutableStateOf("Tailored shirts, overshirts, structured blazers & relaxed denim") }
    var preferredColors by remember { mutableStateOf(initialColors) }
    var budgetInr by remember { mutableIntStateOf(initialBudget.coerceIn(500, 25000)) }
    var preferredRetailers by remember { mutableStateOf(initialRetailers) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "AI Personal Fashion Stylist",
                style = MaterialTheme.typography.headlineMedium
            )
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "Close")
            }
        }

        Text(
            text = "Customize your preferences or skip directly to receive instant AI outfit recommendations.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text("1. Preferred Fashion Style", style = MaterialTheme.typography.titleSmall)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            styles.forEach { style ->
                FilterChip(
                    selected = selectedStyle == style,
                    onClick = { selectedStyle = style },
                    label = { Text(style) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.secondary,
                        selectedLabelColor = MaterialTheme.colorScheme.onSecondary
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text("2. Target Occasion", style = MaterialTheme.typography.titleSmall)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            occasions.forEach { occ ->
                FilterChip(
                    selected = selectedOccasion == occ,
                    onClick = { selectedOccasion = occ },
                    label = { Text(occ) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = clothingPreferences,
            onValueChange = { clothingPreferences = it },
            label = { Text("3. Clothing Preferences (e.g., Shirts, Kurtas, Jackets)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = preferredColors,
            onValueChange = { preferredColors = it },
            label = { Text("4. Preferred Colours") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "5. Maximum Budget: ₹$budgetInr",
            style = MaterialTheme.typography.titleSmall
        )
        Slider(
            value = budgetInr.toFloat(),
            onValueChange = { budgetInr = it.toInt() },
            valueRange = 500f..15000f
        )

        OutlinedTextField(
            value = preferredRetailers,
            onValueChange = { preferredRetailers = it },
            label = { Text("6. Shopping Platforms (Myntra, AJIO, Amazon, Flipkart)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = {
                    onSubmit(
                        selectedStyle,
                        selectedOccasion,
                        clothingPreferences,
                        preferredColors,
                        budgetInr,
                        preferredRetailers,
                        true
                    )
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("Skip Questions")
            }

            Button(
                onClick = {
                    onSubmit(
                        selectedStyle,
                        selectedOccasion,
                        clothingPreferences,
                        preferredColors,
                        budgetInr,
                        preferredRetailers,
                        false
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("submit_stylist_quiz_button")
            ) {
                Text("Get AI Recommendations")
            }
        }
        Spacer(modifier = Modifier.height(20.dp))
    }
}

@Composable
private fun AiChatStylistSheet(
    messages: List<ChatMessage>,
    chatUiState: ChatUiState,
    onSendMessage: (String) -> Unit,
    onSelectProduct: (FashionProduct) -> Unit,
    onTryOnProduct: (FashionProduct) -> Unit
) {
    var inputText by remember { mutableStateOf("") }
    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                inputText = spoken
                onSendMessage(spoken)
                inputText = ""
            }
        }
    }

    val quickPrompts = listOf(
        "Suggest a stylish college outfit under ₹1,000.",
        "Recommend an executive office blazer outfit.",
        "Show traditional Indian wedding kurta sets.",
        "Best monochrome streetwear look."
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(600.dp)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            text = "Conversational AI Fashion Stylist",
            style = MaterialTheme.typography.headlineMedium
        )
        Text(
            text = "Type or speak naturally for personalized outfit pairings & shopping links.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            quickPrompts.forEach { prompt ->
                FilterChip(
                    selected = false,
                    onClick = { onSendMessage(prompt) },
                    label = { Text(prompt, maxLines = 1) }
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(messages, key = { it.id }) { msg ->
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = if (msg.isUser) Alignment.End else Alignment.Start
                ) {
                    Surface(
                        color = if (msg.isUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.padding(horizontal = 4.dp)
                    ) {
                        Text(
                            text = msg.text,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (msg.isUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(14.dp)
                        )
                    }

                    if (!msg.isUser && msg.recommendedProducts.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(msg.recommendedProducts, key = { "${msg.id}_${it.id}" }) { prod ->
                                Card(
                                    modifier = Modifier
                                        .width(210.dp)
                                        .clickable { onSelectProduct(prod) },
                                    shape = RoundedCornerShape(14.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        AsyncImage(
                                            model = prod.imageUrl,
                                            contentDescription = prod.name,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(105.dp)
                                                .clip(RoundedCornerShape(10.dp))
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = prod.name,
                                            style = MaterialTheme.typography.titleSmall,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "₹${prod.priceInr} • ${prod.primaryRetailer}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.secondary
                                        )
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            TextButton(onClick = { onTryOnProduct(prod) }) {
                                                Text("Try On")
                                            }
                                            TextButton(onClick = { onSelectProduct(prod) }) {
                                                Text("Shop")
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (chatUiState is ChatUiState.Streaming) {
                item {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text(
                            text = chatUiState.partialText.ifBlank { "StyleAI is thinking..." },
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(14.dp)
                        )
                    }
                }
            }

            if (chatUiState is ChatUiState.Error) {
                item {
                    Text(
                        text = chatUiState.message,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = {
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_PROMPT, "Ask StyleAI for an outfit recommendation...")
                    }
                    try {
                        speechLauncher.launch(intent)
                    } catch (e: Exception) {
                        // Speech recognition unavailable on device
                    }
                },
                modifier = Modifier.testTag("chat_voice_input_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Mic,
                    contentDescription = "Speak to AI Stylist",
                    tint = MaterialTheme.colorScheme.secondary
                )
            }

            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                placeholder = { Text("Ask e.g. College outfit under ₹1,000...") },
                singleLine = true,
                modifier = Modifier
                    .weight(1f)
                    .testTag("chat_stylist_input")
            )

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = {
                    if (inputText.isNotBlank()) {
                        onSendMessage(inputText)
                        inputText = ""
                    }
                },
                modifier = Modifier.testTag("chat_stylist_send_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Send message",
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }
        Spacer(modifier = Modifier.height(12.dp))
    }
}
