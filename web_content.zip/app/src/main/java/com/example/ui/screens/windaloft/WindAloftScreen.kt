package com.example.ui.screens.windaloft

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.WindAloftLevel
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.UiState
import com.example.ui.viewmodel.WeatherViewModel

/**
 * Predefined ATC Airspace Regions for Upper-air Wind Aloft Analysis
 */
data class AirspaceRegion(
  val id: String,
  val nameEn: String,
  val nameFa: String,
  val primaryIcao: String,
  val fir: String,
  val lat: Double,
  val lon: Double
)

val ATC_REGIONS = listOf(
  AirspaceRegion("tehran", "Tehran FIR / Central", "تهران و مرکز", "OIIE", "OIIX", 35.416, 51.152),
  AirspaceRegion("caspian", "North & Caspian Coast", "شمال و کاسپین", "OIGG", "OIIX", 37.325, 49.623),
  AirspaceRegion("azerbaijan", "North-West & Azerbaijan", "شمال غرب و آذربایجان", "OITT", "OIIX", 38.133, 46.235),
  AirspaceRegion("khorasan", "North-East & Khorasan", "شمال شرق و خراسان", "OIMM", "OIIX", 36.235, 59.641),
  AirspaceRegion("isfehan", "Central Plateau & Isfahan", "فلات مرکزی و اصفهان", "OIFM", "OIIX", 32.750, 51.861),
  AirspaceRegion("shiraz", "South & Fars Airspace", "جنوب و استان فارس", "OISS", "OIIX", 29.540, 52.590),
  AirspaceRegion("hormuz", "Persian Gulf & Hormuz", "خلیج فارس و هرمزگان", "OIKB", "OIIX", 27.218, 56.378),
  AirspaceRegion("kish", "Kish Island TMA", "کیش و جزایر", "OIBK", "OIIX", 26.526, 53.980),
  AirspaceRegion("bushehr", "Bushehr Coastal Sector", "بوشهر و ساحل خلیج", "OIBP", "OIIX", 28.945, 50.835),
  AirspaceRegion("zagros", "West & Zagros Mountains", "غرب و زاگرس", "OICI", "OIIX", 34.346, 47.158),
  AirspaceRegion("khuzestan", "South-West & Khuzestan", "جنوب غرب و خوزستان", "OIAW", "OIIX", 31.337, 48.762),
  AirspaceRegion("baluchestan", "South-East & Sistan", "جنوب شرق و بلوچستان", "OIZH", "OIIX", 29.475, 60.905),
  AirspaceRegion("dubai", "Dubai & UAE TMA", "دبی و امارات", "OMDB", "OMAE", 25.253, 55.364),
  AirspaceRegion("doha", "Doha & Qatar Airspace", "دوحه و قطر", "OTHH", "OTBD", 25.273, 51.608),
  AirspaceRegion("kuwait", "Kuwait FIR", "کویت", "OKBK", "OKAC", 29.226, 47.978)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WindAloftScreen(
  viewModel: WeatherViewModel,
  modifier: Modifier = Modifier
) {
  val selectedAirport by viewModel.selectedAirport.collectAsState()
  val windState by viewModel.windAloftState.collectAsState()
  val isOffline by viewModel.isOffline.collectAsState()

  // 1. Region Selection State (انتخاب منطقه)
  var currentRegion by remember {
    mutableStateOf(
      ATC_REGIONS.firstOrNull { it.primaryIcao == selectedAirport.icao }
        ?: ATC_REGIONS[0]
    )
  }

  // 2. Altitude Level Filter State (انتخاب ارتفاع)
  var selectedAltitudeFilter by remember { mutableStateOf<String>("ALL") }
  var highlightedLevel by remember { mutableStateOf<WindAloftLevel?>(null) }

  // Trigger loading when region changes
  LaunchedEffect(currentRegion) {
    viewModel.loadWindAloftForLocation(
      icao = currentRegion.primaryIcao,
      name = currentRegion.nameEn,
      lat = currentRegion.lat,
      lon = currentRegion.lon
    )
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp)
      .testTag("wind_aloft_screen"),
    verticalArrangement = Arrangement.spacedBy(14.dp),
    contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
  ) {
    if (isOffline) {
      item { OfflineNoticeBanner() }
    }

    // Top Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "WIND & TEMPERATURE ALOFT",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = OceanBlueDark
          )
          Text(
            text = "Upper-Air Winds Profile for Flight Planning & En-Route ATC",
            style = MaterialTheme.typography.labelSmall,
            color = AtcTextMuted
          )
        }

        IconButton(
          onClick = {
            viewModel.loadWindAloftForLocation(
              icao = currentRegion.primaryIcao,
              name = currentRegion.nameEn,
              lat = currentRegion.lat,
              lon = currentRegion.lon
            )
          },
          modifier = Modifier.testTag("btn_refresh_wind_aloft")
        ) {
          Icon(Icons.Default.Refresh, contentDescription = "Refresh Wind Aloft", tint = OceanBlue)
        }
      }
    }

    // =========================================================================
    // 1. REGION SELECTION CARD (انتخاب منطقه)
    // =========================================================================
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DashboardSearchCardBg),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, DashboardSearchCardBorder),
        modifier = Modifier.fillMaxWidth().testTag("region_selector_card")
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.Public,
                contentDescription = null,
                tint = DashboardSearchCardText,
                modifier = Modifier.size(20.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "Select Airspace Region / Sector (انتخاب منطقه)",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = DashboardSearchCardText
              )
            }

            Surface(
              shape = RoundedCornerShape(4.dp),
              color = OceanBlue
            ) {
              Text(
                text = "${currentRegion.primaryIcao} • ${currentRegion.fir}",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Region Horizontal Selectable Chips
          LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(horizontal = 2.dp)
          ) {
            items(ATC_REGIONS) { region ->
              val isSelected = currentRegion.id == region.id
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (isSelected) OceanBlue else Color.White.copy(alpha = 0.8f),
                border = androidx.compose.foundation.BorderStroke(
                  1.dp,
                  if (isSelected) OceanBlueDark else DashboardSearchCardBorder
                ),
                modifier = Modifier
                  .clickable { currentRegion = region }
                  .testTag("region_chip_${region.id}")
              ) {
                Column(
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                  horizontalAlignment = Alignment.CenterHorizontally
                ) {
                  Text(
                    text = region.nameEn,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                    color = if (isSelected) Color.White else DashboardSearchCardText
                  )
                  Text(
                    text = "${region.primaryIcao} (${region.nameFa})",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 10.sp,
                    color = if (isSelected) Color(0xFFBAE6FD) else AtcTextMuted
                  )
                }
              }
            }
          }
        }
      }
    }

    // =========================================================================
    // 2. ALTITUDE LEVEL SELECTOR (انتخاب ارتفاع)
    // =========================================================================
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFCBD5E1)),
        modifier = Modifier.fillMaxWidth().testTag("altitude_selector_card")
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.Height,
                contentDescription = null,
                tint = OceanBlue,
                modifier = Modifier.size(20.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "Select Altitude / Flight Level (انتخاب ارتفاع)",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = AtcTextMain
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Altitude Levels Chips: ALL, SFC, FL050, FL100, FL180, FL300, FL340, FL390
          val standardLevels = listOf(
            "ALL" to "All Levels Profile",
            "Surface (1000 hPa)" to "SFC (~300 FT)",
            "FL050 (850 hPa)" to "5,000 FT",
            "FL100 (700 hPa)" to "10,000 FT",
            "FL180 (500 hPa)" to "18,000 FT",
            "FL300 (300 hPa)" to "30,000 FT",
            "FL340 (250 hPa)" to "34,000 FT",
            "FL390 (200 hPa)" to "39,000 FT"
          )

          LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            contentPadding = PaddingValues(horizontal = 2.dp)
          ) {
            items(standardLevels) { (lvlCode, lvlAlt) ->
              val isSelected = selectedAltitudeFilter == lvlCode
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (isSelected) OceanBlue else Color(0xFFF1F5F9),
                border = androidx.compose.foundation.BorderStroke(
                  1.dp,
                  if (isSelected) OceanBlueDark else Color(0xFFCBD5E1)
                ),
                modifier = Modifier
                  .clickable { selectedAltitudeFilter = lvlCode }
                  .testTag("altitude_pill_${lvlCode.take(5)}")
              ) {
                Column(
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                  horizontalAlignment = Alignment.CenterHorizontally
                ) {
                  Text(
                    text = if (lvlCode == "ALL") "ALL LEVELS" else lvlCode.substringBefore(" ("),
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) Color.White else AtcTextMain
                  )
                  Text(
                    text = lvlAlt,
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 9.sp,
                    color = if (isSelected) Color(0xFFBAE6FD) else AtcTextMuted
                  )
                }
              }
            }
          }
        }
      }
    }

    // =========================================================================
    // 3. UPPER AIR DATA CONTENT & SPOTLIGHT
    // =========================================================================
    when (val state = windState) {
      is UiState.Success -> {
        val report = state.data
        val levels = report.levels

        val filteredLevels = remember(levels, selectedAltitudeFilter) {
          if (selectedAltitudeFilter == "ALL") {
            levels
          } else {
            levels.filter { it.flightLevelName.startsWith(selectedAltitudeFilter.substringBefore(" ("), ignoreCase = true) }
          }
        }

        val activeLevel = highlightedLevel
          ?: filteredLevels.firstOrNull()
          ?: levels.getOrNull(3)
          ?: levels.firstOrNull()

        // SPOTLIGHT CARD: Soft Turquoise/Teal Wind Aloft Card (خود کارت کاملاً رنگی)
        if (activeLevel != null) {
          item {
            Card(
              shape = RoundedCornerShape(16.dp),
              colors = CardDefaults.cardColors(containerColor = WindAloftCardBg),
              border = androidx.compose.foundation.BorderStroke(1.5.dp, WindAloftCardBorder),
              modifier = Modifier.fillMaxWidth().testTag("wind_level_spotlight")
            ) {
              Column(modifier = Modifier.padding(16.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                      Icon(
                        imageVector = Icons.Default.Air,
                        contentDescription = null,
                        tint = WindAloftCardText,
                        modifier = Modifier.size(24.dp)
                      )
                      Spacer(modifier = Modifier.width(8.dp))
                      Text(
                        text = activeLevel.flightLevelName,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = WindAloftCardText
                      )
                    }
                    Text(
                      text = "Pressure: ${activeLevel.pressureHpa} hPa • Altitude: ~${activeLevel.altitudeFt} FT (FL${activeLevel.altitudeFt / 100})",
                      style = MaterialTheme.typography.labelSmall,
                      color = WindAloftCardText.copy(alpha = 0.85f)
                    )
                  }

                  // Circular Visual Wind Compass Direction Arrow
                  WindArrowCompass(
                    windDirDeg = activeLevel.windDirDeg,
                    windSpeedKt = activeLevel.windSpeedKt
                  )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Translucent box to show wind specs without hiding card color
                Surface(
                  shape = RoundedCornerShape(10.dp),
                  color = Color.White.copy(alpha = 0.35f),
                  border = androidx.compose.foundation.BorderStroke(1.dp, WindAloftCardBorder),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                  ) {
                    Column {
                      Text(
                        text = "WIND VECTOR",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = WindAloftCardText.copy(alpha = 0.8f)
                      )
                      Text(
                        text = "${activeLevel.windDirDeg}° / ${activeLevel.windSpeedKt} KT",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = WindAloftCardText
                      )
                      Text(
                        text = "${(activeLevel.windSpeedKt * 0.5144).toInt()} m/s",
                        style = MaterialTheme.typography.labelSmall,
                        color = WindAloftCardText.copy(alpha = 0.8f)
                      )
                    }

                    Column {
                      Text(
                        text = "TEMPERATURE",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = WindAloftCardText.copy(alpha = 0.8f)
                      )
                      Text(
                        text = "${activeLevel.tempC}°C",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = WindAloftCardText
                      )
                      Text(
                        text = "${(activeLevel.tempC * 9 / 5 + 32).toInt()}°F",
                        style = MaterialTheme.typography.labelSmall,
                        color = WindAloftCardText.copy(alpha = 0.8f)
                      )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                      Text(
                        text = "CATEGORY",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = WindAloftCardText.copy(alpha = 0.8f)
                      )
                      val speedKt = activeLevel.windSpeedKt
                      val (catLabel, catBg, catText) = when {
                        speedKt >= 65 -> Triple("SEVERE JET", StatusRed, Color.White)
                        speedKt >= 45 -> Triple("JET STREAM", Color(0xFFC2410C), Color.White)
                        speedKt >= 25 -> Triple("STRONG", Color(0xFFD97706), Color.White)
                        speedKt >= 10 -> Triple("MODERATE", OceanBlue, Color.White)
                        else -> Triple("LIGHT", Color(0xFF15803D), Color.White)
                      }
                      Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = catBg
                      ) {
                        Text(
                          text = catLabel,
                          style = MaterialTheme.typography.labelSmall,
                          fontWeight = FontWeight.Bold,
                          color = catText,
                          modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                      }
                    }
                  }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text(
                    text = "Region: ${currentRegion.nameEn} (${currentRegion.lat}, ${currentRegion.lon})",
                    style = MaterialTheme.typography.labelSmall,
                    color = WindAloftCardText.copy(alpha = 0.85f)
                  )
                  Text(
                    text = "Valid: ${activeLevel.validTimeUtc}",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = WindAloftCardText
                  )
                }
              }
            }
          }
        }

        // =====================================================================
        // 4. VERTICAL ATMOSPHERIC WIND & TEMP PROFILE TABLE
        // =====================================================================
        item {
          Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFCBD5E1)),
            modifier = Modifier.fillMaxWidth().testTag("vertical_profile_table_card")
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = "Vertical Wind & Temperature Profile Table",
                  style = MaterialTheme.typography.titleSmall,
                  fontWeight = FontWeight.Bold,
                  color = AtcTextMain
                )
                Text(
                  text = "${filteredLevels.size} Levels Available",
                  style = MaterialTheme.typography.labelSmall,
                  color = AtcTextMuted
                )
              }
              Text(
                text = "Tap on any flight level row to inspect detailed vectors and thermal deviation.",
                style = MaterialTheme.typography.labelSmall,
                color = AtcTextMuted
              )

              Spacer(modifier = Modifier.height(12.dp))

              // Table Header
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .background(OceanBlue.copy(alpha = 0.1f), RoundedCornerShape(6.dp))
                  .padding(horizontal = 10.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(text = "LEVEL", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.3f))
                Text(text = "DIR (°)", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.9f))
                Text(text = "SPEED", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.1f))
                Text(text = "TEMP", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.9f))
                Text(text = "VECTOR", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.8f))
              }

              Spacer(modifier = Modifier.height(6.dp))

              filteredLevels.forEach { lvl ->
                val isSelected = activeLevel?.flightLevelName == lvl.flightLevelName
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (isSelected) OceanBlue.copy(alpha = 0.15f) else Color.Transparent)
                    .clickable { highlightedLevel = lvl }
                    .padding(horizontal = 10.dp, vertical = 9.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text(
                    text = lvl.flightLevelName,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) OceanBlueDark else AtcTextMain,
                    modifier = Modifier.weight(1.3f)
                  )
                  Text(
                    text = "${lvl.windDirDeg}°",
                    style = MaterialTheme.typography.bodySmall,
                    color = AtcTextMain,
                    modifier = Modifier.weight(0.9f)
                  )
                  Text(
                    text = "${lvl.windSpeedKt} KT",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = if (lvl.windSpeedKt >= 45) StatusRed else OceanBlue,
                    modifier = Modifier.weight(1.1f)
                  )
                  Text(
                    text = "${lvl.tempC}°C",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (lvl.tempC <= 0.0) Color(0xFF0284C7) else Color(0xFFEA580C),
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(0.9f)
                  )
                  Box(modifier = Modifier.weight(0.8f)) {
                    WindArrowCompass(windDirDeg = lvl.windDirDeg, windSpeedKt = lvl.windSpeedKt, sizeDp = 28)
                  }
                }
                Divider(color = Color(0xFFE2E8F0))
              }

              Spacer(modifier = Modifier.height(10.dp))

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(
                  text = "Source: ${report.source}",
                  style = MaterialTheme.typography.labelSmall,
                  fontSize = 10.sp,
                  color = AtcTextMuted
                )
                Text(
                  text = "Retrieved: ${report.retrievalTimeUtc}",
                  style = MaterialTheme.typography.labelSmall,
                  fontSize = 10.sp,
                  color = OceanBlue
                )
              }
            }
          }
        }
      }

      is UiState.Loading -> {
        item {
          Card(modifier = Modifier.fillMaxWidth()) {
            Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
              CircularProgressIndicator(color = OceanBlue)
            }
          }
        }
      }

      is UiState.Error -> {
        item {
          Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
              Text("Wind Aloft Error: ${state.message}", color = StatusRed, fontWeight = FontWeight.Bold)
              Text("Numeric atmospheric prediction model temporarily unreachable for this sector.", style = MaterialTheme.typography.bodySmall)
            }
          }
        }
      }
    }

    item { OperationalDisclaimerCard() }
  }
}

/**
 * Visual Directional Wind Arrow inside Compass Circle
 */
@Composable
fun WindArrowCompass(
  windDirDeg: Int,
  windSpeedKt: Int,
  modifier: Modifier = Modifier,
  sizeDp: Int = 46
) {
  Box(
    modifier = modifier
      .size(sizeDp.dp)
      .clip(CircleShape)
      .background(Color.White)
      .border(1.5.dp, OceanBlue.copy(alpha = 0.5f), CircleShape),
    contentAlignment = Alignment.Center
  ) {
    Icon(
      imageVector = Icons.Default.Navigation,
      contentDescription = "Wind direction: $windDirDeg°",
      tint = if (windSpeedKt >= 45) StatusRed else OceanBlue,
      modifier = Modifier
        .size((sizeDp * 0.65).dp)
        .rotate(windDirDeg.toFloat())
    )
  }
}
