package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.RotateRight
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.FileNode
import com.example.data.storage.DeviceAndSafStorageAdapter
import com.example.ui.viewmodel.AiStudioViewModel
import com.example.ui.viewmodel.AiTaskState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

enum class ImageColorFilter(val label: String) {
    NONE("Original"),
    VIVID("Vivid"),
    WARM("Warm Glow"),
    COOL("Cool Slate"),
    MONO("Monochrome"),
    SEPIA("Sepia")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiImageEditorScreen(
    node: FileNode,
    storageAdapter: DeviceAndSafStorageAdapter,
    aiViewModel: AiStudioViewModel,
    aiState: AiTaskState<Bitmap>,
    onSavedMessage: (String) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val scope = rememberCoroutineScope()

    var baseBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var rotationDegrees by remember { mutableIntStateOf(0) }
    var cropSquare by remember { mutableStateOf(false) }
    var selectedFilter by remember { mutableStateOf(ImageColorFilter.NONE) }
    var brightness by remember { mutableFloatStateOf(0f) } // -80 to +80
    var contrast by remember { mutableFloatStateOf(1f) }   // 0.5 to 1.8
    var promptText by remember { mutableStateOf("") }

    LaunchedEffect(node.path) {
        aiViewModel.resetImageAiState()
        baseBitmap = withContext(Dispatchers.IO) {
            val bytes = storageAdapter.read(node.path)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        }
    }

    // Apply AI-generated Bitmap onto working canvas when Gemini Nano Banana succeeds
    LaunchedEffect(aiState) {
        if (aiState is AiTaskState.Success) {
            baseBitmap = aiState.data
            rotationDegrees = 0
            cropSquare = false
            selectedFilter = ImageColorFilter.NONE
            brightness = 0f
            contrast = 1f
        }
    }

    val renderedBitmap = remember(baseBitmap, rotationDegrees, cropSquare, selectedFilter, brightness, contrast) {
        baseBitmap?.let {
            renderImageAdjustments(it, rotationDegrees, cropSquare, selectedFilter, brightness, contrast)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("AI Image Editor", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("img_editor_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Live Image Canvas
            item {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp)
                ) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        when {
                            aiState is AiTaskState.Loading -> {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    CircularProgressIndicator()
                                    Spacer(Modifier.height(10.dp))
                                    Text(aiState.label, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            renderedBitmap != null -> {
                                Image(
                                    bitmap = renderedBitmap.asImageBitmap(),
                                    contentDescription = "Edited preview",
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(12.dp)
                                )
                            }
                            else -> CircularProgressIndicator()
                        }
                    }
                }
            }

            if (aiState is AiTaskState.Error) {
                item {
                    Surface(
                        color = MaterialTheme.colorScheme.error.copy(alpha = 0.14f),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = aiState.message,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            }

            // Gemini Nano Banana AI Actions
            item {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(8.dp))
                            Text("Gemini AI Studio", style = MaterialTheme.typography.titleMedium)
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilledTonalButton(
                                onClick = {
                                    renderedBitmap?.let {
                                        aiViewModel.editImageWithGemini(
                                            it,
                                            "Remove the background cleanly and isolate the main subject on a crisp clean studio white backdrop."
                                        )
                                    }
                                },
                                enabled = renderedBitmap != null && aiState !is AiTaskState.Loading,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("ai_remove_bg_button")
                            ) {
                                Text("Remove BG")
                            }
                            FilledTonalButton(
                                onClick = {
                                    renderedBitmap?.let {
                                        aiViewModel.editImageWithGemini(
                                            it,
                                            "AI Enhance: sharpen fine details, balance dynamic range lighting, and naturally enrich colors while preserving exact subject fidelity."
                                        )
                                    }
                                },
                                enabled = renderedBitmap != null && aiState !is AiTaskState.Loading,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("ai_enhance_button")
                            ) {
                                Text("AI Enhance")
                            }
                        }

                        OutlinedTextField(
                            value = promptText,
                            onValueChange = { promptText = it },
                            placeholder = { Text("Edit with prompt (e.g. turn background into sunset beach)") },
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("ai_image_prompt_input")
                        )

                        Button(
                            onClick = {
                                val bmp = renderedBitmap
                                if (bmp != null && promptText.isNotBlank()) {
                                    aiViewModel.editImageWithGemini(bmp, promptText)
                                }
                            },
                            enabled = renderedBitmap != null && promptText.isNotBlank() && aiState !is AiTaskState.Loading,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("ai_edit_with_prompt_button")
                        ) {
                            Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Edit with Prompt")
                        }
                    }
                }
            }

            // Manual Crop, Rotate, Filters, Brightness & Contrast
            item {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("Transform & Color Adjustments", style = MaterialTheme.typography.titleMedium)

                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(
                                onClick = { rotationDegrees = (rotationDegrees + 90) % 360 },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.AutoMirrored.Filled.RotateRight, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Rotate 90°")
                            }
                            OutlinedButton(
                                onClick = { cropSquare = !cropSquare },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Filled.Crop, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(if (cropSquare) "Uncrop" else "1:1 Crop")
                            }
                        }

                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(ImageColorFilter.entries) { filter ->
                                FilterChip(
                                    selected = selectedFilter == filter,
                                    onClick = { selectedFilter = filter },
                                    label = { Text(filter.label) }
                                )
                            }
                        }

                        Text("Brightness (${brightness.toInt()})", style = MaterialTheme.typography.labelMedium)
                        Slider(
                            value = brightness,
                            onValueChange = { brightness = it },
                            valueRange = -80f..80f
                        )

                        Text("Contrast (${String.format("%.2f", contrast)}x)", style = MaterialTheme.typography.labelMedium)
                        Slider(
                            value = contrast,
                            onValueChange = { contrast = it },
                            valueRange = 0.5f..1.8f
                        )
                    }
                }
            }

            // Save Copy or Overwrite
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val bmp = renderedBitmap ?: return@OutlinedButton
                            scope.launch {
                                saveEditedBitmap(bmp, node, storageAdapter, overwrite = true, onSavedMessage)
                            }
                        },
                        enabled = renderedBitmap != null && !node.isReadOnly,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("img_overwrite_button")
                    ) {
                        Text("Overwrite")
                    }
                    Button(
                        onClick = {
                            val bmp = renderedBitmap ?: return@Button
                            scope.launch {
                                saveEditedBitmap(bmp, node, storageAdapter, overwrite = false, onSavedMessage)
                            }
                        },
                        enabled = renderedBitmap != null,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("img_save_copy_button")
                    ) {
                        Icon(Icons.Filled.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Save a Copy")
                    }
                }
            }
        }
    }
}

private suspend fun saveEditedBitmap(
    bitmap: Bitmap,
    originalNode: FileNode,
    storageAdapter: DeviceAndSafStorageAdapter,
    overwrite: Boolean,
    onDone: (String) -> Unit
) {
    val parent = originalNode.parentPath ?: storageAdapter.workspaceRootPath
    val bytes = withContext(Dispatchers.IO) {
        val out = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 95, out)
        out.toByteArray()
    }
    val targetName = if (overwrite) {
        originalNode.name
    } else {
        val base = originalNode.name.substringBeforeLast('.')
        "${base}_edited.png"
    }
    runCatching {
        storageAdapter.write(parent, targetName, bytes, "image/png", overwrite = overwrite)
    }.onSuccess { saved ->
        onDone("Saved ${saved.name}")
    }.onFailure { e ->
        onDone("Save failed: ${e.localizedMessage}")
    }
}

private fun renderImageAdjustments(
    src: Bitmap,
    rotationDegrees: Int,
    cropSquare: Boolean,
    filter: ImageColorFilter,
    brightness: Float,
    contrast: Float
): Bitmap {
    var working = src
    if (rotationDegrees != 0) {
        val matrix = Matrix().apply { postRotate(rotationDegrees.toFloat()) }
        working = Bitmap.createBitmap(working, 0, 0, working.width, working.height, matrix, true)
    }
    if (cropSquare) {
        val side = minOf(working.width, working.height)
        val x = (working.width - side) / 2
        val y = (working.height - side) / 2
        working = Bitmap.createBitmap(working, x, y, side, side)
    }

    val out = Bitmap.createBitmap(working.width, working.height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(out)

    val cm = ColorMatrix()
    when (filter) {
        ImageColorFilter.NONE -> {}
        ImageColorFilter.VIVID -> cm.setSaturation(1.45f)
        ImageColorFilter.MONO -> cm.setSaturation(0f)
        ImageColorFilter.SEPIA -> {
            cm.setSaturation(0f)
            val sepia = ColorMatrix(
                floatArrayOf(
                    1.2f, 0f, 0f, 0f, 18f,
                    0f, 1.02f, 0f, 0f, 8f,
                    0f, 0f, 0.82f, 0f, -10f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            cm.postConcat(sepia)
        }
        ImageColorFilter.WARM -> {
            cm.postConcat(
                ColorMatrix(
                    floatArrayOf(
                        1.12f, 0f, 0f, 0f, 12f,
                        0f, 1.03f, 0f, 0f, 4f,
                        0f, 0f, 0.9f, 0f, -8f,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
            )
        }
        ImageColorFilter.COOL -> {
            cm.postConcat(
                ColorMatrix(
                    floatArrayOf(
                        0.92f, 0f, 0f, 0f, -6f,
                        0f, 1.0f, 0f, 0f, 2f,
                        0f, 0f, 1.15f, 0f, 14f,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
            )
        }
    }

    val translate = (-0.5f * contrast + 0.5f) * 255f + brightness
    val bcMatrix = ColorMatrix(
        floatArrayOf(
            contrast, 0f, 0f, 0f, translate,
            0f, contrast, 0f, 0f, translate,
            0f, 0f, contrast, 0f, translate,
            0f, 0f, 0f, 1f, 0f
        )
    )
    cm.postConcat(bcMatrix)

    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        colorFilter = ColorMatrixColorFilter(cm)
    }
    canvas.drawBitmap(working, 0f, 0f, paint)
    return out
}
