package com.example.ui.settings

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.backup.BackupManager
import com.example.data.backup.RestoreResult
import com.example.data.model.AppSettingsEntity
import com.example.data.repository.SettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class SettingsUiState(
    val appliedThemeMode: String = AppSettingsEntity.THEME_NORMAL,
    val selectedPreviewThemeMode: String = AppSettingsEntity.THEME_NORMAL,
    val isSaving: Boolean = false,
    val isBackupProcessing: Boolean = false,
    val backupSuccessMessage: String? = null,
    val backupErrorMessage: String? = null
)

class SettingsViewModel(
    private val settingsRepository: SettingsRepository,
    private val backupManager: BackupManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            settingsRepository.settingsFlow.collect { settings ->
                val currentMode = settings?.themeMode ?: AppSettingsEntity.THEME_NORMAL
                _uiState.update {
                    it.copy(
                        appliedThemeMode = currentMode,
                        selectedPreviewThemeMode = currentMode
                    )
                }
            }
        }
    }

    fun onSelectPreviewTheme(themeMode: String) {
        _uiState.update { it.copy(selectedPreviewThemeMode = themeMode) }
    }

    fun applyTheme(themeMode: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true) }
            settingsRepository.setThemeMode(themeMode)
            _uiState.update {
                it.copy(
                    appliedThemeMode = themeMode,
                    selectedPreviewThemeMode = themeMode,
                    isSaving = false
                )
            }
        }
    }

    fun exportBackup(context: Context, destinationUri: Uri) {
        viewModelScope.launch {
            _uiState.update { it.copy(isBackupProcessing = true, backupSuccessMessage = null, backupErrorMessage = null) }
            try {
                val jsonString = backupManager.generateBackupJson()
                withContext(Dispatchers.IO) {
                    context.contentResolver.openOutputStream(destinationUri)?.use { outputStream ->
                        outputStream.bufferedWriter().use { writer ->
                            writer.write(jsonString)
                            writer.flush()
                        }
                    } ?: throw IllegalStateException("Could not open destination file for writing.")
                }
                _uiState.update {
                    it.copy(
                        isBackupProcessing = false,
                        backupSuccessMessage = "Data successfully exported! Your subjects, study sessions, exams, notes, and preferences are safely saved in the chosen file."
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isBackupProcessing = false,
                        backupErrorMessage = "Export failed: ${e.localizedMessage ?: "Unknown error"}"
                    )
                }
            }
        }
    }

    fun restoreBackup(context: Context, sourceUri: Uri) {
        viewModelScope.launch {
            _uiState.update { it.copy(isBackupProcessing = true, backupSuccessMessage = null, backupErrorMessage = null) }
            try {
                val jsonContent = withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(sourceUri)?.bufferedReader()?.use { it.readText() }
                        ?: throw IllegalStateException("Could not read selected backup file.")
                }

                val result = backupManager.restoreFromJson(jsonContent)
                when (result) {
                    is RestoreResult.Success -> {
                        val s = result.summary
                        _uiState.update {
                            it.copy(
                                isBackupProcessing = false,
                                backupSuccessMessage = "Data restored successfully!\n" +
                                        "• ${s.subjectCount} subjects\n" +
                                        "• ${s.sessionCount} study sessions\n" +
                                        "• ${s.examCount} exams\n" +
                                        "• ${s.noteCount} notes\n" +
                                        "• Profile & workspace settings"
                            )
                        }
                    }
                    is RestoreResult.Error -> {
                        _uiState.update {
                            it.copy(
                                isBackupProcessing = false,
                                backupErrorMessage = "Restore failed: ${result.message}"
                            )
                        }
                    }
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isBackupProcessing = false,
                        backupErrorMessage = "Restore failed: ${e.localizedMessage ?: "Invalid file format"}"
                    )
                }
            }
        }
    }

    fun dismissBackupFeedback() {
        _uiState.update { it.copy(backupSuccessMessage = null, backupErrorMessage = null) }
    }
}

class SettingsViewModelFactory(
    private val settingsRepository: SettingsRepository,
    private val backupManager: BackupManager
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SettingsViewModel::class.java)) {
            return SettingsViewModel(settingsRepository, backupManager) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
