package com.example.ui.components

import android.content.Intent
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.ArkFeedIds
import com.example.data.model.ArkGroup
import com.example.data.model.ArkPost
import com.example.data.model.FollowEdge
import com.example.data.model.FriendEdge
import com.example.data.model.PostReaction
import com.example.ui.theme.ArkThemeTokens
import com.example.util.rememberDecodedImageBitmap
import java.io.File

@Composable
fun ArkVideoPlayerView(
    videoFile: File?,
    thumbnailBase64: String?,
    isLoading: Boolean,
    modifier: Modifier = Modifier
) {
    val colors = ArkThemeTokens.colors
    Box(
        modifier = modifier.background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        if (videoFile != null && videoFile.exists()) {
            key(videoFile.absolutePath) {
                AndroidView(
                    factory = { ctx ->
                        VideoView(ctx).apply {
                            setVideoPath(videoFile.absolutePath)
                            setOnErrorListener { _, _, _ -> true }
                            setOnPreparedListener { mp ->
                                mp.isLooping = true
                                post {
                                    val mc = MediaController(ctx)
                                    mc.setAnchorView(this)
                                    setMediaController(mc)
                                }
                                start()
                            }
                        }
                    },
                    onRelease = { view ->
                        runCatching { view.stopPlayback() }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        } else {
            val bmp = rememberDecodedImageBitmap(thumbnailBase64)
            if (bmp != null) {
                Image(
                    bitmap = bmp,
                    contentDescription = "Video preview",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit
                )
            }
            if (isLoading) {
                CircularProgressIndicator(color = colors.accent)
            } else {
                Text("Video unavailable", color = Color.White, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
fun FullscreenPostMediaDialog(
    post: ArkPost,
    initialPage: Int,
    onLoadVideoFile: suspend () -> File?,
    onDismiss: () -> Unit
) {
    BackHandler(onBack = onDismiss)
    var videoFile by remember(post.id) { mutableStateOf<File?>(null) }
    var loadingVideo by remember(post.id) { mutableStateOf(post.postType == "video") }

    LaunchedEffect(post.id) {
        if (post.postType == "video") {
            loadingVideo = true
            videoFile = onLoadVideoFile()
            loadingVideo = false
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            if (post.postType == "video") {
                ArkVideoPlayerView(
                    videoFile = videoFile,
                    thumbnailBase64 = post.videoThumbnailBase64,
                    isLoading = loadingVideo,
                    modifier = Modifier.fillMaxSize()
                )
            } else if (post.imageBase64List.isNotEmpty()) {
                val pagerState = rememberPagerState(
                    initialPage = initialPage.coerceIn(0, post.imageBase64List.lastIndex),
                    pageCount = { post.imageBase64List.size }
                )
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxSize()
                ) { page ->
                    val bmp = rememberDecodedImageBitmap(post.imageBase64List[page])
                    if (bmp != null) {
                        Image(
                            bitmap = bmp,
                            contentDescription = post.altTexts.getOrNull(page)?.takeIf { it.isNotBlank() }
                                ?: "Fullscreen post photo",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Fit
                        )
                    }
                }
            }

            IconButton(
                onClick = onDismiss,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(16.dp)
            ) {
                Icon(Icons.Default.Close, contentDescription = "Close media viewer", tint = Color.White)
            }
        }
    }
}

@Composable
fun SharePostDialog(
    post: ArkPost,
    friends: List<FriendEdge>,
    groups: List<ArkGroup>,
    followers: List<FollowEdge> = emptyList(),
    onShareToFriend: (FriendEdge) -> Unit,
    onShareToGroup: (ArkGroup) -> Unit,
    onSendViaDm: ((uid: String, username: String, avatar: String) -> Unit)? = null,
    onExternalShareRecorded: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = ArkThemeTokens.colors
    val context = LocalContext.current
    val isPublic = post.visibility == "public"
    val eligibleFriends = friends.filter { isPublic || post.visibleToUids.contains(it.friendUid) }
    val eligibleGroups = groups.filter { isPublic || post.groupIds.contains(it.id) }
    val dmTargets = remember(friends, followers, post.id) {
        val seen = linkedMapOf<String, Pair<String, String>>()
        friends.forEach { if (isPublic || post.visibleToUids.contains(it.friendUid)) seen[it.friendUid] = it.friendUsername to it.friendAvatar }
        followers.forEach { if (isPublic || post.visibleToUids.contains(it.peerUid)) seen.putIfAbsent(it.peerUid, it.peerUsername to it.peerAvatar) }
        seen.entries.map { Triple(it.key, it.value.first, it.value.second) }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Share Post") },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().heightIn(max = 380.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (!isPublic) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = colors.accentSoft,
                            border = BorderStroke(1.dp, colors.accent.copy(alpha = 0.35f))
                        ) {
                            Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = colors.accent)
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    "Privacy Guard: Private posts can only be shared with their original audience.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = colors.ink
                                )
                            }
                        }
                    }
                }

                if (onSendViaDm != null && dmTargets.isNotEmpty()) {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, tint = colors.accent)
                            Spacer(Modifier.width(6.dp))
                            Text("Send via Direct Message", style = MaterialTheme.typography.titleSmall)
                        }
                    }
                    items(dmTargets.take(8), key = { "dm_${it.first}" }) { (uid, uname, avatar) ->
                        OutlinedButton(
                            onClick = { onSendViaDm(uid, uname, avatar); onDismiss() },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("DM @$uname")
                        }
                    }
                }

                if (eligibleFriends.isNotEmpty()) {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.People, contentDescription = null, tint = colors.accent)
                            Spacer(Modifier.width(6.dp))
                            Text("Notify Friends", style = MaterialTheme.typography.titleSmall)
                        }
                    }
                    items(eligibleFriends.take(6), key = { it.friendUid }) { friend ->
                        OutlinedButton(
                            onClick = { onShareToFriend(friend); onDismiss() },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("@${friend.friendUsername}")
                        }
                    }
                }

                if (eligibleGroups.isNotEmpty()) {
                    item {
                        Spacer(Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Groups, contentDescription = null, tint = colors.emerald)
                            Spacer(Modifier.width(6.dp))
                            Text("Share to Squads", style = MaterialTheme.typography.titleSmall)
                        }
                    }
                    items(eligibleGroups.take(6), key = { it.id }) { grp ->
                        OutlinedButton(
                            onClick = { onShareToGroup(grp); onDismiss() },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(grp.name)
                        }
                    }
                }

                if (isPublic) {
                    item {
                        Spacer(Modifier.height(4.dp))
                        GlowingPillButton(
                            text = "Share Externally",
                            icon = Icons.Default.Share,
                            modifier = Modifier.fillMaxWidth(),
                            onClick = {
                                val text = buildString {
                                    append("@${post.authorUsername} on ARK: ")
                                    append(post.caption.ifBlank { post.metaGameName ?: "Check out this ARK post!" })
                                }
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, text)
                                }
                                context.startActivity(Intent.createChooser(intent, "Share ARK Post"))
                                onExternalShareRecorded()
                                onDismiss()
                            }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}

@Composable
fun LikersListDialog(
    post: ArkPost,
    reactions: List<PostReaction>,
    isLoading: Boolean,
    onOpenUserProfile: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val colors = ArkThemeTokens.colors
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Favorite, contentDescription = null, tint = colors.coral)
                Spacer(Modifier.width(8.dp))
                Text("Reactions (${post.likeCount})")
            }
        },
        text = {
            if (isLoading) {
                Box(modifier = Modifier.fillMaxWidth().height(100.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = colors.accent)
                }
            } else if (reactions.isEmpty()) {
                Text("No likes or reactions yet.", style = MaterialTheme.typography.bodyMedium, color = colors.ink2)
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxWidth().heightIn(max = 300.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(reactions, key = { it.userId.ifBlank { it.id } }) { react ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onDismiss()
                                    if (react.userId.isNotBlank()) onOpenUserProfile(react.userId)
                                }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(shape = CircleShape, color = colors.accentSoft) {
                                    Text(
                                        text = ArkFeedIds.reactionEmoji(react.reaction),
                                        modifier = Modifier.padding(8.dp)
                                    )
                                }
                                Spacer(Modifier.width(10.dp))
                                Text("@${react.username}", style = MaterialTheme.typography.titleSmall, color = colors.ink)
                            }
                            Text("View", style = MaterialTheme.typography.labelMedium, color = colors.accent)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}

@Composable
fun EditPostCaptionDialog(
    initialCaption: String,
    onSave: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var caption by remember(initialCaption) { mutableStateOf(initialCaption) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Post Caption") },
        text = {
            OutlinedTextField(
                value = caption,
                onValueChange = { caption = it.take(600) },
                label = { Text("Caption") },
                maxLines = 4,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(onClick = { onSave(caption); onDismiss() }) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
