package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PersonRemove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.BlockedUser
import com.example.data.model.FriendEdge
import com.example.data.model.FriendRequest
import com.example.data.model.UserProfile
import com.example.ui.components.ArkAvatarBadge
import com.example.ui.components.EmptyStateGlassCard
import com.example.ui.components.GlowingPillButton
import com.example.ui.components.LiquidGlassCard
import com.example.ui.theme.ArkThemeTokens

@Composable
fun FriendsScreen(
    currentUser: UserProfile,
    friends: List<FriendEdge>,
    incomingRequests: List<FriendRequest>,
    outgoingRequests: List<FriendRequest>,
    blockedUsers: List<BlockedUser>,
    searchResults: List<UserProfile>,
    onSearchUsername: (String) -> Unit,
    onSendRequest: (UserProfile) -> Unit,
    onAcceptRequest: (FriendRequest) -> Unit,
    onRejectRequest: (String) -> Unit,
    onCancelRequest: (String) -> Unit,
    onRemoveFriend: (String) -> Unit,
    onBlockUser: (String, String) -> Unit,
    onUnblockUser: (String) -> Unit,
    onReportUser: (String, String, String) -> Unit,
    onBack: (() -> Unit)? = null
) {
    BackHandler(enabled = onBack != null) { onBack?.invoke() }
    val colors = ArkThemeTokens.colors
    var selectedTab by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }
    var reportTarget by remember { mutableStateOf<Pair<String, String>?>(null) }
    var reportReason by remember { mutableStateOf("Harassment or Spam") }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = if (onBack != null) 8.dp else 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (onBack != null) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                }
            }
            Column {
                Text("Friends & Squads", style = MaterialTheme.typography.headlineMedium, color = colors.textPrimary)
                Text(
                    "Safe username-based connections • Privacy controls active",
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary
                )
            }
        }

        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = colors.glassSurface
        ) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Friends (${friends.size})") })
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Requests (${incomingRequests.size})") })
            Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Find & Safety") })
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (selectedTab) {
                0 -> {
                    if (friends.isEmpty()) {
                        item {
                            EmptyStateGlassCard(
                                icon = Icons.Default.PersonAdd,
                                title = "No Friends Added Yet",
                                subtitle = "Switch to 'Find & Safety' to search by exact username and invite your real-life friends.",
                                actionLabel = "Search Username",
                                onAction = { selectedTab = 2 }
                            )
                        }
                    } else {
                        items(friends, key = { it.friendUid }) { friend ->
                            LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                        ArkAvatarBadge(
                                            avatarPreset = friend.friendAvatar,
                                            username = friend.friendUsername,
                                            size = 44.dp
                                        )
                                        Spacer(Modifier.width(12.dp))
                                        Column {
                                            Text("@${friend.friendUsername}", style = MaterialTheme.typography.titleMedium, color = colors.textPrimary)
                                            Text("Level ${friend.friendLevel} • Connected", style = MaterialTheme.typography.bodySmall, color = colors.emerald)
                                        }
                                    }
                                    Row {
                                        IconButton(onClick = { reportTarget = friend.friendUid to friend.friendUsername }) {
                                            Icon(Icons.Default.Flag, contentDescription = "Report user", tint = colors.gold)
                                        }
                                        IconButton(onClick = { onBlockUser(friend.friendUid, friend.friendUsername) }) {
                                            Icon(Icons.Default.Block, contentDescription = "Block user", tint = colors.coral)
                                        }
                                        IconButton(onClick = { onRemoveFriend(friend.friendUid) }) {
                                            Icon(Icons.Default.PersonRemove, contentDescription = "Remove friend", tint = colors.textSecondary)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                1 -> {
                    if (incomingRequests.isEmpty() && outgoingRequests.isEmpty()) {
                        item {
                            EmptyStateGlassCard(
                                icon = Icons.Default.PersonAdd,
                                title = "No Pending Requests",
                                subtitle = "Incoming and outgoing friend invitations appear here."
                            )
                        }
                    } else {
                        if (incomingRequests.isNotEmpty()) {
                            item {
                                Text("Incoming Requests", style = MaterialTheme.typography.titleMedium, color = colors.textPrimary)
                            }
                            items(incomingRequests, key = { it.id }) { req ->
                                LiquidGlassCard(modifier = Modifier.fillMaxWidth(), accentColor = colors.cyan) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            ArkAvatarBadge(avatarPreset = req.fromAvatar, username = req.fromUsername, size = 40.dp)
                                            Spacer(Modifier.width(10.dp))
                                            Column {
                                                Text("@${req.fromUsername}", style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                                                Text("Wants to connect", style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
                                            }
                                        }
                                        Row {
                                            IconButton(onClick = { onAcceptRequest(req) }) {
                                                Icon(Icons.Default.Check, contentDescription = "Accept", tint = colors.emerald)
                                            }
                                            IconButton(onClick = { onRejectRequest(req.id) }) {
                                                Icon(Icons.Default.Close, contentDescription = "Decline", tint = colors.coral)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        if (outgoingRequests.isNotEmpty()) {
                            item {
                                Text("Sent Requests", style = MaterialTheme.typography.titleMedium, color = colors.textPrimary)
                            }
                            items(outgoingRequests, key = { it.id }) { req ->
                                LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("@${req.toUsername}", style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text("Pending", style = MaterialTheme.typography.labelSmall, color = colors.gold)
                                            Spacer(Modifier.width(8.dp))
                                            IconButton(
                                                onClick = { onCancelRequest(req.id) },
                                                modifier = Modifier.testTag("cancel_outgoing_${req.id}")
                                            ) {
                                                Icon(Icons.Default.Close, contentDescription = "Cancel request", tint = colors.coral)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                2 -> {
                    item {
                        LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                            Text("Find Friend by Exact Username", style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "To protect minor safety and prevent unsolicited browsing, ARK requires searching exact usernames.",
                                style = MaterialTheme.typography.bodySmall,
                                color = colors.textSecondary
                            )
                            Spacer(Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = searchQuery,
                                    onValueChange = { searchQuery = it.lowercase().trim() },
                                    label = { Text("Exact username") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f).testTag("friend_search_input")
                                )
                                Spacer(Modifier.width(8.dp))
                                GlowingPillButton(
                                    text = "Find",
                                    icon = Icons.Default.Search,
                                    onClick = { onSearchUsername(searchQuery) },
                                    modifier = Modifier.testTag("friend_search_button")
                                )
                            }
                        }
                    }

                    items(searchResults, key = { it.userId }) { user ->
                        val alreadyFriend = friends.any { it.friendUid == user.userId }
                        val alreadyBlocked = blockedUsers.any { it.blockedUid == user.userId }
                        val outgoingPending = outgoingRequests.firstOrNull { it.toUid == user.userId }
                        val incomingPending = incomingRequests.firstOrNull { it.fromUid == user.userId }
                        LiquidGlassCard(modifier = Modifier.fillMaxWidth(), accentColor = colors.violet) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    ArkAvatarBadge(avatarPreset = user.avatarPreset, username = user.username, size = 44.dp)
                                    Spacer(Modifier.width(10.dp))
                                    Column {
                                        Text("@${user.username}", style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                                        Text("${user.displayTag} • LVL ${user.level}", style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
                                    }
                                }
                                when {
                                    user.userId == currentUser.userId -> {
                                        Text("You", style = MaterialTheme.typography.labelMedium, color = colors.textSecondary)
                                    }
                                    alreadyFriend -> {
                                        Text("Friends", style = MaterialTheme.typography.labelMedium, color = colors.emerald)
                                    }
                                    alreadyBlocked -> {
                                        Text("Blocked", style = MaterialTheme.typography.labelMedium, color = colors.coral)
                                    }
                                    incomingPending != null -> {
                                        GlowingPillButton(
                                            text = "Accept",
                                            icon = Icons.Default.Check,
                                            onClick = { onAcceptRequest(incomingPending) },
                                            modifier = Modifier.testTag("accept_search_friend_${user.userId}")
                                        )
                                    }
                                    outgoingPending != null -> {
                                        OutlinedButton(
                                            onClick = { onCancelRequest(outgoingPending.id) },
                                            modifier = Modifier.testTag("requested_friend_${user.userId}")
                                        ) {
                                            Text("Requested")
                                        }
                                    }
                                    else -> {
                                        GlowingPillButton(
                                            text = "Add",
                                            icon = Icons.Default.PersonAdd,
                                            onClick = { onSendRequest(user) },
                                            modifier = Modifier.testTag("add_friend_${user.userId}")
                                        )
                                    }
                                }
                            }
                        }
                    }

                    item {
                        LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Shield, contentDescription = null, tint = colors.emerald)
                                Spacer(Modifier.width(8.dp))
                                Text("Blocked Accounts (${blockedUsers.size})", style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                            }
                            Spacer(Modifier.height(8.dp))
                            if (blockedUsers.isEmpty()) {
                                Text("No blocked users.", style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
                            } else {
                                blockedUsers.forEach { b ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("@${b.blockedUsername}", style = MaterialTheme.typography.bodyMedium, color = colors.textPrimary)
                                        OutlinedButton(onClick = { onUnblockUser(b.blockedUid) }) {
                                            Text("Unblock")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (reportTarget != null) {
        val (targetUid, targetName) = reportTarget!!
        AlertDialog(
            onDismissRequest = { reportTarget = null },
            title = { Text("Report @$targetName") },
            text = {
                Column {
                    Text("Describe why you are reporting this account:", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = reportReason,
                        onValueChange = { reportReason = it.take(100) },
                        label = { Text("Reason") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    onReportUser(targetUid, reportReason, "Reported via Friends tab")
                    reportTarget = null
                }) { Text("Submit Report", color = colors.coral) }
            },
            dismissButton = {
                TextButton(onClick = { reportTarget = null }) { Text("Cancel") }
            }
        )
    }
}
