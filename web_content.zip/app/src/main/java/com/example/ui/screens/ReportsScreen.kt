package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.print.PrintAttributes
import android.print.PrintManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Leaderboard
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Print
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.AcademicCalculator
import com.example.domain.ReportPdfGenerator
import com.example.model.ClassAnalytics
import com.example.model.SchoolClass
import com.example.model.SchoolConfig
import com.example.model.StudentComputedResult
import com.example.model.Subject
import com.example.model.defaultReportLabels
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.KpiStatTile
import com.example.ui.components.SchoolEmblemView
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.GoldSecondary
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.MerriweatherFamily
import com.example.ui.theme.PlusJakartaSansFamily
import com.example.viewmodel.SchoolDashboardData
import com.example.viewmodel.SchoolViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

private enum class ReportsSubTab(val label: String) {
    REPORT_CARD("Report Card"),
    RANKINGS("Class Rankings"),
}

private enum class RankingSortMode(val label: String) {
    RANK_ASC("Rank 1st → Last"),
    RANK_DESC("Lowest → Highest"),
    NAME_ASC("Name A → Z"),
}

@Composable
fun ReportsScreen(
    data: SchoolDashboardData,
    viewModel: SchoolViewModel,
    onOpenStudentMarks: (String) -> Unit,
    showBatchPdfDialogExternal: Boolean = false,
    onDismissBatchPdfDialogExternal: () -> Unit = {},
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val brandingRev by viewModel.brandingRevision.collectAsStateWithLifecycle()

    var activeSubTab by remember { mutableStateOf(ReportsSubTab.REPORT_CARD) }
    var searchQuery by remember { mutableStateOf("") }
    var sortMode by remember { mutableStateOf(RankingSortMode.RANK_ASC) }
    var studentMenuExpanded by remember { mutableStateOf(false) }

    var showBatchDialog by remember(showBatchPdfDialogExternal) { mutableStateOf(showBatchPdfDialogExternal) }
    var batchSortOption by remember { mutableStateOf("rank") }
    var pendingPdfStudents by remember { mutableStateOf<List<StudentComputedResult>>(emptyList()) }

    val activeClass = data.activeClass
    val logoBitmap = remember(data.config.logoFileName, brandingRev) {
        viewModel.loadLogoBitmap(data.config.logoFileName)
    }
    val signatureBitmap = remember(data.config.signatureFileName, brandingRev) {
        viewModel.loadSignatureBitmap(data.config.signatureFileName)
    }

    val createPdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri != null && activeClass != null && pendingPdfStudents.isNotEmpty()) {
            scope.launch {
                try {
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openOutputStream(uri)?.use { out ->
                            ReportPdfGenerator.generatePdfToStream(
                                context = context,
                                outputStream = out,
                                schoolClass = activeClass,
                                subjects = data.subjects,
                                studentsToExport = pendingPdfStudents,
                                analytics = data.analytics,
                                config = data.config,
                                totalStudentsInClass = data.students.size,
                                logoBitmap = logoBitmap,
                                signatureBitmap = signatureBitmap,
                            )
                        }
                    }
                    viewModel.notifyMessage("Saved ${pendingPdfStudents.size}-page A4 PDF")
                } catch (e: Exception) {
                    viewModel.notifyMessage("PDF export failed: ${e.localizedMessage}")
                }
            }
        }
    }

    fun launchSharePdf(studentsToExport: List<StudentComputedResult>, fileName: String) {
        val cls = activeClass ?: return
        scope.launch {
            try {
                val file = withContext(Dispatchers.IO) {
                    ReportPdfGenerator.generateTempPdfFile(
                        context = context,
                        fileName = fileName,
                        schoolClass = cls,
                        subjects = data.subjects,
                        studentsToExport = studentsToExport,
                        analytics = data.analytics,
                        config = data.config,
                        totalStudentsInClass = data.students.size,
                        logoBitmap = logoBitmap,
                        signatureBitmap = signatureBitmap,
                    )
                }
                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "application/pdf"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(shareIntent, "Share Report Card PDF"))
            } catch (e: Exception) {
                viewModel.notifyMessage("Unable to share PDF: ${e.localizedMessage}")
            }
        }
    }

    fun launchSystemPrint(studentsToExport: List<StudentComputedResult>, jobName: String) {
        val cls = activeClass ?: return
        scope.launch {
            try {
                val file = withContext(Dispatchers.IO) {
                    ReportPdfGenerator.generateTempPdfFile(
                        context = context,
                        fileName = "print_preview.pdf",
                        schoolClass = cls,
                        subjects = data.subjects,
                        studentsToExport = studentsToExport,
                        analytics = data.analytics,
                        config = data.config,
                        totalStudentsInClass = data.students.size,
                        logoBitmap = logoBitmap,
                        signatureBitmap = signatureBitmap,
                    )
                }
                val printManager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
                val adapter = ReportPdfGenerator.createPrintAdapter(file, jobName)
                printManager.print(
                    jobName,
                    adapter,
                    PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build(),
                )
            } catch (e: Exception) {
                viewModel.notifyMessage("Unable to open print dialog: ${e.localizedMessage}")
            }
        }
    }

    fun sortedBatchList(mode: String): List<StudentComputedResult> {
        val base = data.analytics.studentsComputed
        return when (mode) {
            "rank" -> base.sortedWith(compareBy<StudentComputedResult> { it.overallRank }.thenBy { it.student.name })
            "name" -> base.sortedBy { it.student.name }
            else -> base
        }
    }

    if (showBatchDialog && activeClass != null) {
        AlertDialog(
            onDismissRequest = {
                showBatchDialog = false
                onDismissBatchPdfDialogExternal()
            },
            title = { Text("Export All ${activeClass.name} Reports (${data.students.size} Pages)") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Generates a multi-page A4 PDF with strictly 1 student per page.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    listOf(
                        "rank" to "By Class Rank (1st Place → Last)",
                        "name" to "Alphabetical by Name (A → Z)",
                        "roster" to "Current Roster Order",
                    ).forEach { (key, label) ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(
                                selected = batchSortOption == key,
                                onClick = { batchSortOption = key },
                            )
                            Text(label, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val list = sortedBatchList(batchSortOption)
                        pendingPdfStudents = list
                        showBatchDialog = false
                        onDismissBatchPdfDialogExternal()
                        val safeCls = activeClass.name.replace(Regex("[^a-zA-Z0-9_-]"), "_")
                        createPdfLauncher.launch("${safeCls}_All_Reports.pdf")
                    },
                    enabled = data.students.isNotEmpty(),
                ) {
                    Text("Save ${data.students.size}-Page PDF")
                }
            },
            dismissButton = {
                Row {
                    TextButton(
                        onClick = {
                            val list = sortedBatchList(batchSortOption)
                            showBatchDialog = false
                            onDismissBatchPdfDialogExternal()
                            val safeCls = activeClass.name.replace(Regex("[^a-zA-Z0-9_-]"), "_")
                            launchSharePdf(list, "${safeCls}_All_Reports.pdf")
                        },
                        enabled = data.students.isNotEmpty(),
                    ) {
                        Text("Share")
                    }
                    TextButton(
                        onClick = {
                            showBatchDialog = false
                            onDismissBatchPdfDialogExternal()
                        },
                    ) {
                        Text("Cancel")
                    }
                }
            },
        )
    }

    if (activeClass == null || data.students.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) {
            EmptyStateCard(
                icon = Icons.Rounded.Description,
                title = "No Report Cards Available",
                subtitle = "Add students in Marks or Customize to preview rankings and export A4 PDF report cards.",
            )
        }
        return
    }

    val stu = data.selectedStudent ?: data.students.first()
    val stuComp = data.analytics.byId[stu.id] ?: return

    Column(modifier = Modifier.fillMaxSize()) {
        // Sub-Tab Segmented Switcher
        Box(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                ReportsSubTab.entries.forEachIndexed { index, tab ->
                    SegmentedButton(
                        selected = activeSubTab == tab,
                        onClick = { activeSubTab = tab },
                        shape = SegmentedButtonDefaults.itemShape(index, ReportsSubTab.entries.size),
                        icon = {
                            Icon(
                                imageVector = if (tab == ReportsSubTab.REPORT_CARD) {
                                    Icons.Rounded.Description
                                } else {
                                    Icons.Rounded.Leaderboard
                                },
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                            )
                        },
                    ) {
                        Text(tab.label, style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        }

        when (activeSubTab) {
            ReportsSubTab.REPORT_CARD -> {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    // Student Selector & Export Controls
                    item(key = "report_controls") {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    FilledTonalIconButton(
                                        onClick = { viewModel.stepStudent(data.students, -1) },
                                        modifier = Modifier.size(48.dp),
                                    ) {
                                        Icon(Icons.AutoMirrored.Rounded.KeyboardArrowLeft, contentDescription = "Previous student")
                                    }

                                    Box(modifier = Modifier.weight(1f)) {
                                        OutlinedButton(
                                            onClick = { studentMenuExpanded = true },
                                            modifier = Modifier.fillMaxWidth().height(48.dp),
                                            shape = RoundedCornerShape(14.dp),
                                        ) {
                                            Text(
                                                text = "${stu.name} • #${stuComp.overallRank} (${stuComp.formattedPct}%)",
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                style = MaterialTheme.typography.titleSmall,
                                            )
                                        }
                                        DropdownMenu(
                                            expanded = studentMenuExpanded,
                                            onDismissRequest = { studentMenuExpanded = false },
                                        ) {
                                            data.students.forEach { cand ->
                                                val comp = data.analytics.byId[cand.id]
                                                DropdownMenuItem(
                                                    text = { Text("${cand.name} (Pos #${comp?.overallRank ?: 1} • ${comp?.formattedPct ?: "0"}%)") },
                                                    onClick = {
                                                        viewModel.selectStudent(cand.id)
                                                        studentMenuExpanded = false
                                                    },
                                                )
                                            }
                                        }
                                    }

                                    FilledTonalIconButton(
                                        onClick = { viewModel.stepStudent(data.students, 1) },
                                        modifier = Modifier.size(48.dp),
                                    ) {
                                        Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, contentDescription = "Next student")
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    Button(
                                        onClick = {
                                            pendingPdfStudents = listOf(stuComp)
                                            val safeName = stu.name.replace(Regex("[^a-zA-Z0-9_-]"), "_")
                                            createPdfLauncher.launch("${safeName}_Report.pdf")
                                        },
                                        modifier = Modifier.weight(1f).height(46.dp).testTag("save_student_pdf_button"),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.onSurface),
                                    ) {
                                        Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("Save PDF", maxLines = 1)
                                    }

                                    Button(
                                        onClick = { showBatchDialog = true },
                                        modifier = Modifier.weight(1f).height(46.dp).testTag("export_all_pdf_button"),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                    ) {
                                        Icon(Icons.Rounded.PictureAsPdf, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("All (${data.students.size})", maxLines = 1)
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    FilledTonalButton(
                                        onClick = {
                                            val safeName = stu.name.replace(Regex("[^a-zA-Z0-9_-]"), "_")
                                            launchSharePdf(listOf(stuComp), "${safeName}_Report.pdf")
                                        },
                                        modifier = Modifier.weight(1f).height(44.dp),
                                        shape = RoundedCornerShape(12.dp),
                                    ) {
                                        Icon(Icons.Rounded.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("Share PDF")
                                    }

                                    FilledTonalButton(
                                        onClick = {
                                            launchSystemPrint(
                                                sortedBatchList("rank"),
                                                "${activeClass.name} Report Cards",
                                            )
                                        },
                                        modifier = Modifier.weight(1f).height(44.dp),
                                        shape = RoundedCornerShape(12.dp),
                                    ) {
                                        Icon(Icons.Rounded.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("Print All")
                                    }
                                }
                            }
                        }
                    }

                    // Live Official Report Card Sheet Preview
                    item(key = "a4_sheet_${stu.id}") {
                        ReportCardSheetPreview(
                            schoolClass = activeClass,
                            subjects = data.subjects,
                            studentResult = stuComp,
                            analytics = data.analytics,
                            config = data.config,
                            totalStudentsInClass = data.students.size,
                            logoBitmap = logoBitmap,
                            signatureBitmap = signatureBitmap,
                        )
                    }
                }
            }

            ReportsSubTab.RANKINGS -> {
                val decimals = data.config.decimalPlaces.toInt().coerceIn(0, 2)
                val passMark = data.config.passMark.toDouble()
                val filtered = data.analytics.studentsComputed
                    .filter {
                        searchQuery.isBlank() ||
                            it.student.name.contains(searchQuery.trim(), ignoreCase = true) ||
                            it.student.studentIdNo.contains(searchQuery.trim(), ignoreCase = true)
                    }
                    .let { list ->
                        when (sortMode) {
                            RankingSortMode.RANK_ASC -> list.sortedWith(compareBy<StudentComputedResult> { it.overallRank }.thenBy { it.student.name })
                            RankingSortMode.RANK_DESC -> list.sortedWith(compareByDescending<StudentComputedResult> { it.overallRank }.thenBy { it.student.name })
                            RankingSortMode.NAME_ASC -> list.sortedBy { it.student.name }
                        }
                    }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    item(key = "rankings_kpis") {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                KpiStatTile(
                                    label = "Class Avg",
                                    value = "${String.format(Locale.US, "%.${decimals}f", data.analytics.classAvgPct)}%",
                                    accentColor = MaterialTheme.colorScheme.primary,
                                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                                    modifier = Modifier.weight(1f),
                                )
                                KpiStatTile(
                                    label = "Top Score",
                                    value = "${String.format(Locale.US, "%.${decimals}f", data.analytics.highestPct)}%",
                                    accentColor = EmeraldSuccess,
                                    containerColor = EmeraldContainer,
                                    modifier = Modifier.weight(1f),
                                )
                                KpiStatTile(
                                    label = "Pass (≥${data.config.passMark}%)",
                                    value = "${data.analytics.passRatePct.toInt()}%",
                                    accentColor = GoldSecondary,
                                    containerColor = GoldContainer,
                                    modifier = Modifier.weight(1f),
                                )
                            }

                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                placeholder = { Text("Search student name or ID...") },
                                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                RankingSortMode.entries.forEach { mode ->
                                    FilterChip(
                                        selected = sortMode == mode,
                                        onClick = { sortMode = mode },
                                        label = { Text(mode.label, style = MaterialTheme.typography.labelSmall) },
                                    )
                                }
                            }
                        }
                    }

                    items(filtered, key = { it.student.id }) { item ->
                        val isPass = item.rawPct >= passMark
                        val (posBg, posFg) = when (item.overallRank) {
                            1 -> GoldContainer to GoldSecondary
                            2 -> Color(0xFFE2E8F0) to Color(0xFF1E293B)
                            3 -> Color(0xFFFFEDD5) to Color(0xFF9A3412)
                            else -> MaterialTheme.colorScheme.surfaceVariant to MaterialTheme.colorScheme.onSurfaceVariant
                        }

                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                Surface(
                                    color = posBg,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.size(48.dp),
                                ) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center,
                                    ) {
                                        Text("POS", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = posFg.copy(alpha = 0.7f))
                                        Text("#${item.overallRank}", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = posFg)
                                    }
                                }

                                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(
                                        text = item.student.name,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.ExtraBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                    Text(
                                        text = "Total: ${AcademicCalculator.formatNumber(item.studentTotGrand)}/${data.analytics.maxTotGrand} • Conduct: ${item.student.conduct.ifBlank { "-" }}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                    LinearProgressIndicator(
                                        progress = { (item.rawPct.toFloat() / 100f).coerceIn(0f, 1f) },
                                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(4.dp)),
                                        color = if (isPass) EmeraldSuccess else CrimsonAlert,
                                        trackColor = MaterialTheme.colorScheme.surfaceVariant,
                                    )
                                }

                                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(
                                        text = "${item.formattedPct}%",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (isPass) EmeraldSuccess else CrimsonAlert,
                                    )
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        TextButton(onClick = { onOpenStudentMarks(item.student.id) }) {
                                            Text("Marks")
                                        }
                                        TextButton(
                                            onClick = {
                                                viewModel.selectStudent(item.student.id)
                                                activeSubTab = ReportsSubTab.REPORT_CARD
                                            },
                                        ) {
                                            Text("Report")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReportCardSheetPreview(
    schoolClass: SchoolClass,
    subjects: List<Subject>,
    studentResult: StudentComputedResult,
    analytics: ClassAnalytics,
    config: SchoolConfig,
    totalStudentsInClass: Int,
    logoBitmap: Bitmap?,
    signatureBitmap: Bitmap?,
) {
    val borderColor = remember(config.borderColorHex) {
        try { Color(android.graphics.Color.parseColor(config.borderColorHex)) } catch (_: Exception) { Color(0xFF1F2937) }
    }
    val headerBg = remember(config.headerBgHex) {
        try { Color(android.graphics.Color.parseColor(config.headerBgHex)) } catch (_: Exception) { Color(0xFFF8FAFC) }
    }
    val reportFont: FontFamily = if (config.reportFont == "sans") PlusJakartaSansFamily else MerriweatherFamily
    val labels = defaultReportLabels() + config.labels
    val stu = studentResult.student
    val orderedSubjects = subjects.sortedBy { it.sortOrder }

    val totalDisplay = config.manualStudentCount.ifBlank { totalStudentsInClass.toString() }
    val conductDisplay = when {
        stu.conduct.isBlank() -> "-"
        config.conductMax.isNotBlank() -> "${stu.conduct}/${config.conductMax}"
        else -> stu.conduct
    }
    val posDisplay = if (config.positionFormat == "fraction") {
        "${studentResult.overallRank} / $totalDisplay"
    } else {
        studentResult.overallRank.toString()
    }
    val latesDisplay = if (stu.latesCount > 0L) stu.latesCount.toString() else "-"
    val absencesDisplay = if (stu.absencesCount > 0L) stu.absencesCount.toString() else "-"

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(6.dp),
        color = Color.White,
        shadowElevation = 4.dp,
        border = BorderStroke(1.dp, Color(0xFFCBD5E1)),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (config.showLogo) {
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    SchoolEmblemView(
                        logoBitmap = logoBitmap,
                        schoolName = config.schoolName,
                        size = config.logoSizeDp.toInt().coerceIn(48, 100).dp,
                        circular = config.logoCircular,
                    )
                }
            }

            // Header 2-Column Metadata
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(config.country.uppercase(), fontFamily = reportFont, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF111827))
                    Text("${labels["schoolPrefix"].orEmpty()} ${config.schoolName.uppercase()}", fontFamily = reportFont, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF111827))
                    Text("${labels["poBoxPrefix"].orEmpty()} ${config.poBox}", fontFamily = reportFont, fontSize = 9.5.sp, color = Color(0xFF111827))
                    Text("${labels["telPrefix"].orEmpty()} ${config.tel}", fontFamily = reportFont, fontSize = 9.5.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF111827))
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(config.ministry.uppercase(), fontFamily = reportFont, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF111827))
                    Text(config.academicYear, fontFamily = reportFont, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF111827))
                    Text(config.term, fontFamily = reportFont, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF111827))
                }
            }

            // Full-Width Bordered Banner Title
            Column {
                HorizontalDivider(thickness = 1.6.dp, color = borderColor)
                Text(
                    text = config.reportTitle.uppercase(),
                    fontFamily = reportFont,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF111827),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
                )
                HorizontalDivider(thickness = 1.2.dp, color = borderColor)
            }

            // Student Info Grid
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("${labels["studentName"].orEmpty()} ${stu.name.uppercase()}", fontFamily = reportFont, fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFF111827))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text("${labels["className"].orEmpty()} ${schoolClass.name.uppercase()}", fontFamily = reportFont, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF111827))
                    Text("${labels["numStudents"].orEmpty()} $totalDisplay", fontFamily = reportFont, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF111827))
                    Text("${labels["conduct"].orEmpty()} $conductDisplay", fontFamily = reportFont, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF111827))
                }
                Text("${labels["idNo"].orEmpty()} ${stu.studentIdNo}", fontFamily = reportFont, fontSize = 10.sp, color = Color(0xFF111827))
            }

            // 8-Column Marks Table
            Column(modifier = Modifier.fillMaxWidth().border(1.2.dp, borderColor)) {
                ReportTableRow(
                    cells = listOf(
                        labels["subjects"].orEmpty(),
                        labels["test"].orEmpty(),
                        labels["exam"].orEmpty(),
                        labels["tot"].orEmpty(),
                        labels["test"].orEmpty(),
                        labels["exam"].orEmpty(),
                        labels["tot"].orEmpty(),
                        labels["rank"].orEmpty(),
                    ),
                    bgColor = headerBg,
                    borderColor = borderColor,
                    fontFamily = reportFont,
                    boldCols = setOf(0, 1, 2, 3, 4, 5, 6, 7),
                )

                orderedSubjects.forEach { sub ->
                    val res = studentResult.subjectResults[sub.id]
                    val examEnabled = (res?.maxExam ?: 0L) > 0L
                    ReportTableRow(
                        cells = listOf(
                            sub.name.uppercase(),
                            (res?.maxTest ?: sub.maxTest).toString(),
                            if (examEnabled) (res?.maxExam ?: sub.maxExam).toString() else "-",
                            (res?.maxTot ?: (sub.maxTest + sub.maxExam)).toString(),
                            if (res?.hasTest == true) AcademicCalculator.formatNumber(res.test) else "0",
                            if (examEnabled) {
                                if (res?.hasExam == true) AcademicCalculator.formatNumber(res.exam) else "0"
                            } else "-",
                            AcademicCalculator.formatNumber(res?.tot ?: 0.0),
                            (res?.rank ?: 1).toString(),
                        ),
                        bgColor = Color.White,
                        borderColor = borderColor,
                        fontFamily = reportFont,
                        boldCols = setOf(0, 3, 6, 7),
                    )
                }

                // Total Row
                ReportTableRow(
                    cells = listOf(
                        labels["totalRow"].orEmpty(),
                        analytics.maxTestGrand.toString(),
                        if (analytics.anyExamEnabled) analytics.maxExamGrand.toString() else "-",
                        analytics.maxTotGrand.toString(),
                        AcademicCalculator.formatNumber(studentResult.studentTestGrand),
                        if (analytics.anyExamEnabled) AcademicCalculator.formatNumber(studentResult.studentExamGrand) else "-",
                        AcademicCalculator.formatNumber(studentResult.studentTotGrand),
                        "",
                    ),
                    bgColor = headerBg,
                    borderColor = borderColor,
                    fontFamily = reportFont,
                    boldCols = setOf(0, 1, 2, 3, 4, 5, 6),
                    shadeLastCol = true,
                )

                // Summary Row
                ReportTableRow(
                    cells = listOf(
                        labels["average"].orEmpty(),
                        "${studentResult.formattedPct}%",
                        labels["position"].orEmpty(),
                        posDisplay,
                        labels["lates"].orEmpty(),
                        latesDisplay,
                        labels["absences"].orEmpty(),
                        absencesDisplay,
                    ),
                    bgColor = Color.White,
                    borderColor = borderColor,
                    fontFamily = reportFont,
                    boldCols = setOf(1, 3),
                )
            }

            // Footer Box: Observations & Teacher/Parent Signatures
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(IntrinsicSize.Min)
                    .border(1.2.dp, borderColor),
            ) {
                Column(
                    modifier = Modifier.weight(1f).fillMaxHeight().padding(8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        text = labels["observations"].orEmpty(),
                        fontFamily = reportFont,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF111827),
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = stu.observation,
                        fontFamily = reportFont,
                        fontSize = 10.5.sp,
                        textAlign = TextAlign.Center,
                        color = Color(0xFF111827),
                    )
                }

                VerticalDivider(thickness = 1.2.dp, color = borderColor)

                Column(modifier = Modifier.weight(1f)) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text(
                            text = labels["teacherSignature"].orEmpty(),
                            fontFamily = reportFont,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF111827),
                        )
                        Spacer(Modifier.height(6.dp))
                        if (signatureBitmap != null) {
                            Image(
                                bitmap = signatureBitmap.asImageBitmap(),
                                contentDescription = "Teacher Signature",
                                modifier = Modifier.height(32.dp),
                                contentScale = ContentScale.Fit,
                            )
                        } else if (config.teacherName.isNotBlank()) {
                            Text(
                                text = config.teacherName,
                                fontFamily = reportFont,
                                fontStyle = FontStyle.Italic,
                                fontSize = 10.sp,
                                color = Color(0xFF111827),
                            )
                        } else {
                            Spacer(Modifier.height(20.dp))
                        }
                    }
                    HorizontalDivider(thickness = 1.2.dp, color = borderColor)
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text(
                            text = labels["parentSignature"].orEmpty(),
                            fontFamily = reportFont,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF111827),
                        )
                        Spacer(Modifier.height(22.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun ReportTableRow(
    cells: List<String>,
    bgColor: Color,
    borderColor: Color,
    fontFamily: FontFamily,
    boldCols: Set<Int> = emptySet(),
    shadeLastCol: Boolean = false,
) {
    val weights = listOf(2.6f, 0.85f, 0.85f, 0.9f, 0.85f, 0.85f, 0.95f, 0.95f)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(IntrinsicSize.Min)
            .background(bgColor),
    ) {
        cells.forEachIndexed { idx, value ->
            val cellBg = if (shadeLastCol && idx == cells.lastIndex) Color(0xFFE2E8F0) else Color.Transparent
            Box(
                modifier = Modifier
                    .weight(weights[idx])
                    .fillMaxHeight()
                    .background(cellBg)
                    .padding(horizontal = 3.dp, vertical = 5.dp),
                contentAlignment = if (idx == 0) Alignment.CenterStart else Alignment.Center,
            ) {
                Text(
                    text = value,
                    fontFamily = fontFamily,
                    fontSize = if (idx == 0) 8.5.sp else 9.sp,
                    fontWeight = if (idx in boldCols) FontWeight.Bold else FontWeight.Normal,
                    color = Color(0xFF111827),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = if (idx == 0) TextAlign.Start else TextAlign.Center,
                )
            }
            if (idx < cells.lastIndex) {
                VerticalDivider(thickness = 1.dp, color = borderColor)
            }
        }
    }
    HorizontalDivider(thickness = 1.dp, color = borderColor)
}
