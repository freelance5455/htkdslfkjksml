package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.ProfitLossBadge
import com.example.ui.viewmodel.BusinessViewModel
import com.example.util.BackupManager
import com.example.util.CsvDownloadResult
import com.example.util.CsvExportHelper
import com.example.util.DateFilter
import com.example.util.FinancialMath

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReportsScreen(
    viewModel: BusinessViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val summary by viewModel.dashboardSummary.collectAsStateWithLifecycle()
    val dateFilter by viewModel.dateFilter.collectAsStateWithLifecycle()
    val transactions by viewModel.filteredTransactions.collectAsStateWithLifecycle()
    val expenses by viewModel.filteredExpenses.collectAsStateWithLifecycle()

    var downloadDialogData by remember { mutableStateOf<CsvDownloadResult?>(null) }
    var lastExportedCsvContent by remember { mutableStateOf("") }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                Text(
                    text = "Reports & Statements",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Business financials, profit & loss analysis & CSV export",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Period filter chips
        Text(
            text = "Select Report Period",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp)
        ) {
            DateFilter.entries.forEach { filter ->
                FilterChip(
                    selected = dateFilter == filter,
                    onClick = { viewModel.setDateFilter(filter) },
                    label = { Text(filter.label, fontSize = 12.sp) }
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Export Actions Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "DOWNLOAD SPREADSHEETS & CSV",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Downloads CSV files directly to your phone's Downloads folder, compatible with Excel and Google Sheets.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Button(
                        onClick = {
                            val csv = BackupManager.exportTransactionsToCsv(transactions)
                            lastExportedCsvContent = csv
                            val fileName = "CredPay_Transactions_${dateFilter.name}_${System.currentTimeMillis()}.csv"
                            val result = CsvExportHelper.downloadAndShareCsv(
                                context = context,
                                csvContent = csv,
                                fileName = fileName,
                                title = "CredPay Transactions CSV"
                            )
                            downloadDialogData = result
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("export_transactions_csv_button")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Download Tx CSV", fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = {
                            val csv = BackupManager.exportExpensesToCsv(expenses)
                            lastExportedCsvContent = csv
                            val fileName = "CredPay_Expenses_${dateFilter.name}_${System.currentTimeMillis()}.csv"
                            val result = CsvExportHelper.downloadAndShareCsv(
                                context = context,
                                csvContent = csv,
                                fileName = fileName,
                                title = "CredPay Expenses CSV"
                            )
                            downloadDialogData = result
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("export_expenses_csv_button")
                    ) {
                        Icon(Icons.Default.ReceiptLong, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Download Exp CSV", fontSize = 12.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Executive Financial Summary
        ElevatedCard(
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "FINANCIAL PERFORMANCE SUMMARY (${dateFilter.label.uppercase()})",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                ReportRow("Gross Transaction Volume", FinancialMath.formatInr(summary.totalVolume))
                ReportRow("  • Withdrawal Volume", FinancialMath.formatInr(summary.withdrawalVolume))
                ReportRow("  • Bill Payment Volume", FinancialMath.formatInr(summary.billPaymentVolume))

                HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))

                ReportRow("Customer Payouts (Withdrawals)", FinancialMath.formatInr(summary.totalCustomerPayouts))
                ReportRow("Customer Charges Collected", FinancialMath.formatInr(summary.totalCustomerCharges))
                ReportRow("Platform Fees Incurred", FinancialMath.formatInr(summary.totalPlatformFees))

                HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))

                ReportRow("Bill Service Charges Retained", FinancialMath.formatInr(summary.totalBillServiceCharges))
                ReportRow("Total Commission Earned", FinancialMath.formatInr(summary.totalCommissionReceived))
                ReportRow("Withdrawal Tx Charges Retained", FinancialMath.formatInr(summary.totalTransactionCharges))

                HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))

                ReportRow("Gross Business Profit", FinancialMath.formatInr(summary.grossProfit), isBold = true)
                ReportRow("Operating Expenses (Overhead)", FinancialMath.formatInr(summary.operatingExpenses), color = MaterialTheme.colorScheme.error)

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Consolidated Net Profit", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    ProfitLossBadge(amount = summary.netProfit, label = "Net")
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }

    // Success dialog after downloading CSV
    downloadDialogData?.let { res ->
        AlertDialog(
            onDismissRequest = { downloadDialogData = null },
            icon = { Icon(Icons.Default.Download, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
            title = { Text(if (res.isSuccess) "CSV Downloaded Successfully" else "Export Status") },
            text = {
                Column {
                    if (res.isSuccess) {
                        Text("File saved to device Downloads:")
                        Text(
                            text = res.filePath,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(vertical = 6.dp)
                        )
                        Text(
                            text = "You can view this file in your Files / Downloads app, open in Excel, or copy raw data to clipboard.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        Text("Could not save to Downloads: ${res.errorMessage}")
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        CsvExportHelper.copyToClipboard(context, lastExportedCsvContent, res.fileName)
                    }
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Copy CSV")
                }
            },
            dismissButton = {
                TextButton(onClick = { downloadDialogData = null }) {
                    Text("Done")
                }
            }
        )
    }
}

@Composable
private fun ReportRow(
    label: String,
    value: String,
    isBold: Boolean = false,
    color: Color = Color.Unspecified
) {
    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
            color = if (color != Color.Unspecified) color else MaterialTheme.colorScheme.onSurface
        )
    }
}
