package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.TableView
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.ReportPreview
import com.example.data.model.ReportType
import com.example.ui.components.DatePickerTextField
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.SdTopAppBar
import com.example.ui.components.SectionHeaderCard
import com.example.ui.theme.BackgroundWhite
import com.example.ui.theme.BorderLight
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.GoldSecondary
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.StatusConfirmedFg
import com.example.ui.theme.SurfaceLightGray
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ReportsScreen(
    selectedType: ReportType,
    fromDate: String,
    toDate: String,
    preview: ReportPreview,
    isBusy: Boolean,
    onSelectType: (ReportType) -> Unit,
    onDateRangeChange: (String, String) -> Unit,
    onExportExcel: () -> Unit,
    onExportPdf: () -> Unit,
    onBack: () -> Unit,
) {
    Scaffold(
        containerColor = SurfaceLightGray,
        topBar = {
            SdTopAppBar(
                title = "التقارير المالية والإدارية",
                subtitle = "10 تقارير شاملة • تصدير Excel و PDF",
                onBack = onBack,
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (isBusy) {
                item {
                    LinearProgressIndicator(
                        color = GoldSecondary,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }

            // 1. Report Selector (All 10 reports)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = BackgroundWhite),
                    border = BorderStroke(1.dp, BorderLight),
                    shape = RoundedCornerShape(16.dp),
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        SectionHeaderCard(title = "اختر نوع التقرير", icon = Icons.Default.Assessment)

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            ReportType.entries.forEach { type ->
                                FilterChip(
                                    selected = selectedType == type,
                                    onClick = { onSelectType(type) },
                                    label = { Text("${type.id}. ${type.title}") },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = NavyPrimary,
                                        selectedLabelColor = GoldSecondary,
                                    ),
                                    modifier = Modifier.testTag("report_chip_${type.id}"),
                                )
                            }
                        }

                        Text(
                            text = selectedType.subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                        )
                    }
                }
            }

            // 2. Date Range Filter
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = BackgroundWhite),
                    border = BorderStroke(1.dp, BorderLight),
                    shape = RoundedCornerShape(16.dp),
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            SectionHeaderCard(
                                title = "تصفية حسب الفترة الزمنية",
                                icon = Icons.Default.DateRange,
                                modifier = Modifier.weight(1f),
                            )
                            if (fromDate.isNotBlank() || toDate.isNotBlank()) {
                                OutlinedButton(onClick = { onDateRangeChange("", "") }) {
                                    Icon(Icons.Default.Clear, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Text("مسح")
                                }
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            DatePickerTextField(
                                label = "من تاريخ",
                                value = fromDate,
                                onValueSelected = { onDateRangeChange(it, toDate) },
                                modifier = Modifier.weight(1f),
                                testTag = "report_from_date",
                            )
                            DatePickerTextField(
                                label = "إلى تاريخ",
                                value = toDate,
                                onValueSelected = { onDateRangeChange(fromDate, it) },
                                modifier = Modifier.weight(1f),
                                testTag = "report_to_date",
                            )
                        }
                    }
                }
            }

            // 3. Export Actions (Excel + PDF)
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Button(
                        enabled = !isBusy,
                        onClick = onExportExcel,
                        colors = ButtonDefaults.buttonColors(containerColor = StatusConfirmedFg),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("export_excel_button"),
                    ) {
                        Icon(Icons.Default.TableView, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تصدير Excel", fontWeight = FontWeight.Bold)
                    }

                    Button(
                        enabled = !isBusy,
                        onClick = onExportPdf,
                        colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("export_pdf_button"),
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = GoldSecondary)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تصدير PDF", fontWeight = FontWeight.Bold)
                    }
                }
            }

            // 4. Summary Metrics Strip
            if (preview.summaryMetrics.isNotEmpty()) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        preview.summaryMetrics.forEach { (label, value) ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = GoldContainer,
                                border = BorderStroke(1.dp, GoldSecondary),
                            ) {
                                Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                                    Text(label, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                                    Text(
                                        text = value,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = NavyPrimary,
                                        fontWeight = FontWeight.Bold,
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 5. Data Table Preview
            item {
                if (preview.rows.isEmpty()) {
                    EmptyStateCard(
                        icon = Icons.Default.Assessment,
                        title = "لا توجد سجلات في هذا التقرير",
                        subtitle = "لم يتم العثور على بيانات مطابقة للفترة الزمنية أو نوع التقرير المحدد.",
                    )
                } else {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = BackgroundWhite),
                        border = BorderStroke(1.dp, BorderLight),
                        shape = RoundedCornerShape(16.dp),
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                        ) {
                            // Header Row
                            Row(
                                modifier = Modifier
                                    .background(NavyPrimary)
                                    .padding(vertical = 10.dp, horizontal = 12.dp),
                            ) {
                                preview.headers.forEach { h ->
                                    Text(
                                        text = h,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = GoldSecondary,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier
                                            .width(120.dp)
                                            .padding(horizontal = 4.dp),
                                    )
                                }
                            }

                            preview.rows.forEachIndexed { idx, row ->
                                val bg = if (idx % 2 == 1) SurfaceLightGray else BackgroundWhite
                                Row(
                                    modifier = Modifier
                                        .background(bg)
                                        .padding(vertical = 10.dp, horizontal = 12.dp),
                                ) {
                                    row.forEach { cell ->
                                        Text(
                                            text = cell,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextPrimary,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier
                                                .width(120.dp)
                                                .padding(horizontal = 4.dp),
                                        )
                                    }
                                }
                                HorizontalDivider(color = BorderLight.copy(alpha = 0.5f))
                            }
                        }
                    }
                }
            }
        }
    }
}
