package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.KawaiiSticker
import com.example.data.model.StickerCatalog
import com.example.ui.theme.AestheticBlack
import com.example.ui.theme.BorderGrey
import com.example.ui.theme.CardGrey
import com.example.ui.theme.DeepPink
import com.example.ui.theme.KawaiiPink
import com.example.ui.theme.MutedGrey
import com.example.ui.theme.PastelPinkBg
import com.example.ui.theme.PastelPinkContainer
import com.example.ui.theme.PureWhite
import com.example.ui.theme.TextGrey

@Composable
fun DieCutSticker(
    sticker: KawaiiSticker,
    isUnlocked: Boolean = true,
    isSelected: Boolean = false,
    sizeDp: Int = 72,
    modifier: Modifier = Modifier
) {
    val accentColor = try {
        Color(android.graphics.Color.parseColor(sticker.accentColorHex))
    } catch (_: Exception) {
        KawaiiPink
    }

    Box(
        modifier = modifier
            .shadow(
                elevation = if (isUnlocked) 4.dp else 1.dp,
                shape = RoundedCornerShape(22.dp),
                ambientColor = Color.Black.copy(alpha = 0.08f),
                spotColor = Color.Black.copy(alpha = 0.15f)
            )
            .background(PureWhite, RoundedCornerShape(22.dp))
            .border(
                width = 3.dp,
                color = PureWhite,
                shape = RoundedCornerShape(22.dp)
            )
            .clip(RoundedCornerShape(22.dp))
            .background(
                if (isUnlocked) PastelPinkContainer.copy(alpha = 0.7f) else CardGrey
            )
            .border(
                width = 1.dp,
                color = if (isSelected) DeepPink else if (isUnlocked) BorderGrey else BorderGrey.copy(alpha = 0.5f),
                shape = RoundedCornerShape(22.dp)
            )
            .size(sizeDp.dp),
        contentAlignment = Alignment.Center
    ) {
        if (isUnlocked) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = sticker.emoji,
                    fontSize = (sizeDp * 0.45).sp
                )
            }
            if (isSelected) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(4.dp)
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(DeepPink),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = PureWhite,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }
        } else {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = "Locked",
                tint = MutedGrey,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
fun StickerRewardPopupDialog(
    sticker: KawaiiSticker,
    onDismiss: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "sticker_bob")
    val rotation by infiniteTransition.animateFloat(
        initialValue = -5f,
        targetValue = 5f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "rotation"
    )
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = PureWhite,
        shape = RoundedCornerShape(28.dp),
        modifier = Modifier.testTag("sticker_reward_popup_dialog"),
        title = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = PastelPinkContainer,
                    border = androidx.compose.foundation.BorderStroke(1.dp, KawaiiPink.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = "✨ NEW STICKER UNLOCKED! ✨",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        ),
                        color = DeepPink,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Big Animated Sticker
                Box(
                    modifier = Modifier
                        .padding(vertical = 12.dp)
                        .scale(scale)
                        .rotate(rotation)
                ) {
                    DieCutSticker(
                        sticker = sticker,
                        isUnlocked = true,
                        sizeDp = 100
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = sticker.name,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp
                    ),
                    color = AestheticBlack,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = sticker.tagline,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextGrey,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(12.dp))

                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = PastelPinkBg,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Added to your Study Sticker Board! Tap the 🎀 icon anytime to browse your collection.",
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                        color = AestheticBlack,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AestheticBlack,
                    contentColor = PureWhite
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("dismiss_sticker_reward_btn")
            ) {
                Text("Yay! Collect Sticker ⭐", fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
fun StickerBookDialog(
    totalFocusMinutes: Int,
    activeStickerId: String,
    onSelectActiveSticker: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val allStickers = StickerCatalog.allStickers
    val unlockedCount = allStickers.count { totalFocusMinutes >= it.requiredMinutes }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = PureWhite,
        shape = RoundedCornerShape(28.dp),
        modifier = Modifier.testTag("sticker_book_dialog"),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "🎀 Study Sticker Board",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = AestheticBlack
                    )
                    Text(
                        text = "$unlockedCount of ${allStickers.size} stickers collected",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextGrey
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = TextGrey)
                }
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = PastelPinkBg,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Tap any unlocked sticker to set it as your study companion on the timer!",
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                        color = AestheticBlack,
                        modifier = Modifier.padding(10.dp),
                        textAlign = TextAlign.Center
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                ) {
                    items(allStickers) { sticker ->
                        val isUnlocked = totalFocusMinutes >= sticker.requiredMinutes
                        val isSelected = sticker.id == activeStickerId

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .clip(RoundedCornerShape(18.dp))
                                .clickable(enabled = isUnlocked) {
                                    onSelectActiveSticker(sticker.id)
                                }
                                .padding(4.dp)
                        ) {
                            DieCutSticker(
                                sticker = sticker,
                                isUnlocked = isUnlocked,
                                isSelected = isSelected,
                                sizeDp = 64
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = sticker.name,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 10.sp
                                ),
                                color = if (isUnlocked) AestheticBlack else MutedGrey,
                                textAlign = TextAlign.Center,
                                maxLines = 1
                            )

                            Text(
                                text = if (isUnlocked) (if (isSelected) "Active" else "Unlocked") else "${sticker.requiredMinutes}m goal",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                color = if (isSelected) DeepPink else TextGrey,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AestheticBlack,
                    contentColor = PureWhite
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Done", fontWeight = FontWeight.Bold)
            }
        }
    )
}
