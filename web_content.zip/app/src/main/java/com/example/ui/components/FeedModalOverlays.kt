package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.data.model.ArkGroup
import com.example.data.model.ArkPost
import com.example.data.model.FollowEdge
import com.example.data.model.FriendEdge
import com.example.data.model.PostComment
import com.example.data.model.PostReaction
import com.example.data.model.UserProfile
import com.example.ui.screens.AddStoryDialog
import com.example.ui.screens.CommentBottomSheet
import com.example.ui.theme.ArkThemeTokens
import com.example.ui.viewmodel.FeedViewModelDelegate

@Composable
fun FeedModalOverlays(
    profile: UserProfile,
    friends: List<FriendEdge>,
    followers: List<FollowEdge> = emptyList(),
    groups: List<ArkGroup>,
    feedDelegate: FeedViewModelDelegate,
    showAddStory: Boolean,
    onDismissAddStory: () -> Unit,
    commentsPost: ArkPost?,
    activeComments: List<PostComment>,
    sharingPost: ArkPost?,
    onDismissShare: () -> Unit,
    editingPost: ArkPost?,
    onDismissEdit: () -> Unit,
    fullscreenMedia: Pair<ArkPost, Int>?,
    onDismissFullscreen: () -> Unit,
    likersPost: ArkPost? = null,
    onDismissLikers: () -> Unit = {},
    reportingTarget: Pair<String, String>?,
    onRequestReport: (targetType: String, targetId: String) -> Unit,
    onDismissReport: () -> Unit,
    onSubmitReport: (targetType: String, targetId: String, reason: String, details: String) -> Unit,
    onOpenUserProfile: (String) -> Unit = {},
    onSendPostViaDm: ((post: ArkPost, targetUid: String, targetUsername: String, targetAvatar: String) -> Unit)? = null
) {
    val context = LocalContext.current
    val colors = ArkThemeTokens.colors

    val hideCandidates = remember(friends, followers) {
        val map = linkedMapOf<String, String>()
        friends.forEach { map[it.friendUid] = it.friendUsername }
        followers.forEach { map.putIfAbsent(it.peerUid, it.peerUsername) }
        map.entries.map { it.key to it.value }
    }

    if (showAddStory) {
        AddStoryDialog(
            profile = profile,
            groups = groups,
            hideCandidates = hideCandidates,
            onDismiss = onDismissAddStory,
            onCreateStory = { mediaType, imageB64, caption, vis, selGroups, hiddenUids, durMs, chunks ->
                feedDelegate.createStory(
                    author = profile,
                    mediaType = mediaType,
                    imageBase64 = imageB64,
                    caption = caption,
                    visibility = vis,
                    friends = friends,
                    selectedGroups = selGroups,
                    hiddenFromUids = hiddenUids,
                    videoDurationMs = durMs,
                    videoChunksBase64 = chunks
                )
            }
        )
    }

    if (commentsPost != null) {
        CommentBottomSheet(
            post = commentsPost,
            comments = activeComments,
            currentUser = profile,
            onDismiss = { feedDelegate.closeComments() },
            onAddComment = { text, parentId, replyToUser ->
                feedDelegate.addComment(commentsPost, profile, text, parentId, replyToUser)
            },
            onLikeComment = { cid ->
                feedDelegate.toggleCommentLike(commentsPost.id, cid)
            },
            onEditComment = { cid, newText ->
                feedDelegate.updateComment(commentsPost.id, cid, newText)
            },
            onDeleteComment = { cid ->
                feedDelegate.deleteComment(commentsPost.id, cid)
            },
            onReportComment = { cid ->
                onRequestReport("comment", cid)
            },
            onToggleCommentsDisabled = { disabled ->
                feedDelegate.toggleCommentsDisabled(commentsPost.id, disabled)
            },
            onOpenUserProfile = onOpenUserProfile
        )
    }

    if (sharingPost != null) {
        SharePostDialog(
            post = sharingPost,
            friends = friends,
            groups = groups,
            followers = followers,
            onShareToFriend = { friend ->
                feedDelegate.sharePostToFriend(sharingPost, profile, friend)
            },
            onShareToGroup = { group ->
                feedDelegate.sharePostToGroup(sharingPost, profile, group)
            },
            onSendViaDm = if (onSendPostViaDm != null) {
                { uid, uname, avatar -> onSendPostViaDm(sharingPost, uid, uname, avatar) }
            } else null,
            onExternalShareRecorded = {
                feedDelegate.recordExternalShare(sharingPost)
            },
            onDismiss = onDismissShare
        )
    }

    if (editingPost != null) {
        EditPostCaptionDialog(
            initialCaption = editingPost.caption,
            onSave = { newCaption ->
                feedDelegate.updatePostCaption(editingPost.id, newCaption)
            },
            onDismiss = onDismissEdit
        )
    }

    if (fullscreenMedia != null) {
        val (mediaPost, initialPage) = fullscreenMedia
        FullscreenPostMediaDialog(
            post = mediaPost,
            initialPage = initialPage,
            onLoadVideoFile = { feedDelegate.loadPostVideoFile(context, mediaPost.id) },
            onDismiss = onDismissFullscreen
        )
    }

    if (likersPost != null) {
        var reactionsList by remember(likersPost.id) { mutableStateOf<List<PostReaction>>(emptyList()) }
        var loadingLikers by remember(likersPost.id) { mutableStateOf(true) }
        LaunchedEffect(likersPost.id) {
            loadingLikers = true
            reactionsList = feedDelegate.fetchLikers(likersPost.id)
            loadingLikers = false
        }
        LikersListDialog(
            post = likersPost,
            reactions = reactionsList,
            isLoading = loadingLikers,
            onOpenUserProfile = onOpenUserProfile,
            onDismiss = onDismissLikers
        )
    }

    if (reportingTarget != null) {
        val (targetType, targetId) = reportingTarget
        var reason by remember(targetId) { mutableStateOf("Inappropriate content") }
        var details by remember(targetId) { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = onDismissReport,
            title = { Text("Report ${targetType.replaceFirstChar { it.uppercase() }}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = reason,
                        onValueChange = { reason = it.take(80) },
                        label = { Text("Reason") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = details,
                        onValueChange = { details = it.take(240) },
                        label = { Text("Optional context") },
                        maxLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = reason.trim().length >= 3,
                    onClick = {
                        onSubmitReport(targetType, targetId, reason.trim(), details.trim())
                        onDismissReport()
                    }
                ) { Text("Submit Report", color = colors.coral) }
            },
            dismissButton = {
                TextButton(onClick = onDismissReport) { Text("Cancel") }
            }
        )
    }
}
