package com.example.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.CalendarToday
import androidx.compose.material.icons.outlined.Cake
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AppTopBar
import com.example.ui.components.BannerAdView
import com.example.ui.localization.AppStrings
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.SoftViolet
import com.example.ui.theme.SubtleMint
import com.example.ui.viewmodel.MainUiState
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

@Composable
fun AgeCalculatorScreen(
    uiState: MainUiState,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val language = uiState.language
    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }

    var birthCal by remember {
        mutableStateOf(Calendar.getInstance().apply { set(2000, Calendar.JANUARY, 1) })
    }
    var targetCal by remember {
        mutableStateOf(Calendar.getInstance())
    }

    // Calculations
    val (years, months, days, nextBirthdayDays, totalDays, totalHours) = remember(birthCal, targetCal) {
        calculateAgeDetails(birthCal, targetCal)
    }

    val cardShape = RoundedCornerShape(18.dp)

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        AppTopBar(
            title = AppStrings.get("tool_age", language),
            navigationIcon = Icons.AutoMirrored.Outlined.ArrowBack,
            onNavigationClick = onBack
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Input Selectors Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(cardShape)
                    .background(MaterialTheme.colorScheme.surface)
                    .border(
                        0.8.dp,
                        MaterialTheme.colorScheme.outline.copy(alpha = 0.35f),
                        cardShape
                    )
                    .padding(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    // Date of Birth Row
                    Column {
                        Text(
                            text = AppStrings.get("dob", language),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier
                                .testTag("btn_select_dob")
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                .border(
                                    0.5.dp,
                                    MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable {
                                    DatePickerDialog(
                                        context,
                                        { _, y, m, d ->
                                            val cal = Calendar.getInstance().apply { set(y, m, d) }
                                            birthCal = cal
                                        },
                                        birthCal.get(Calendar.YEAR),
                                        birthCal.get(Calendar.MONTH),
                                        birthCal.get(Calendar.DAY_OF_MONTH)
                                    ).show()
                                }
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = dateFormat.format(birthCal.time),
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Icon(
                                imageVector = Icons.Outlined.CalendarToday,
                                contentDescription = null,
                                tint = ElectricBlue,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    // Target Date Row
                    Column {
                        Text(
                            text = AppStrings.get("target_date", language),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier
                                .testTag("btn_select_target_date")
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                .border(
                                    0.5.dp,
                                    MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable {
                                    DatePickerDialog(
                                        context,
                                        { _, y, m, d ->
                                            val cal = Calendar.getInstance().apply { set(y, m, d) }
                                            targetCal = cal
                                        },
                                        targetCal.get(Calendar.YEAR),
                                        targetCal.get(Calendar.MONTH),
                                        targetCal.get(Calendar.DAY_OF_MONTH)
                                    ).show()
                                }
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = dateFormat.format(targetCal.time),
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Icon(
                                imageVector = Icons.Outlined.CalendarToday,
                                contentDescription = null,
                                tint = ElectricBlue,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }

            // Primary Age Result Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(cardShape)
                    .background(ElectricBlue.copy(alpha = 0.08f))
                    .border(1.dp, ElectricBlue.copy(alpha = 0.25f), cardShape)
                    .padding(20.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Your Age",
                        style = MaterialTheme.typography.titleMedium,
                        color = ElectricBlue,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        AgeMetricItem(value = years.toString(), label = AppStrings.get("years", language))
                        AgeMetricItem(value = months.toString(), label = AppStrings.get("months", language))
                        AgeMetricItem(value = days.toString(), label = AppStrings.get("days", language))
                    }
                }
            }

            // Next Birthday Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(cardShape)
                    .background(MaterialTheme.colorScheme.surface)
                    .border(0.8.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f), cardShape)
                    .padding(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(SoftViolet.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Cake,
                            contentDescription = null,
                            tint = SoftViolet,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = AppStrings.get("next_birthday", language),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "$nextBirthdayDays ${AppStrings.get("days", language)}",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = SoftViolet
                        )
                    }
                }
            }

            // Life Milestones Breakdown
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(cardShape)
                    .background(MaterialTheme.colorScheme.surface)
                    .border(0.8.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f), cardShape)
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(SubtleMint.copy(alpha = 0.12f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Schedule,
                                contentDescription = null,
                                tint = SubtleMint,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text(
                                text = AppStrings.get("total_days_lived", language),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "%,d".format(totalDays),
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = AppStrings.get("total_hours", language),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "%,d".format(totalHours),
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        BannerAdView()
    }
}

@Composable
private fun AgeMetricItem(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            style = MaterialTheme.typography.displaySmall.copy(fontWeight = FontWeight.Bold),
            color = ElectricBlue
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

private data class AgeResult(
    val years: Int,
    val months: Int,
    val days: Int,
    val nextBirthdayDays: Long,
    val totalDays: Long,
    val totalHours: Long
)

private fun calculateAgeDetails(birth: Calendar, target: Calendar): AgeResult {
    var bYear = birth.get(Calendar.YEAR)
    var bMonth = birth.get(Calendar.MONTH)
    var bDay = birth.get(Calendar.DAY_OF_MONTH)

    val tYear = target.get(Calendar.YEAR)
    var tMonth = target.get(Calendar.MONTH)
    var tDay = target.get(Calendar.DAY_OF_MONTH)

    if (tDay < bDay) {
        tMonth -= 1
        val prevMonth = (tMonth + 12) % 12
        val cal = Calendar.getInstance().apply {
            set(Calendar.MONTH, prevMonth)
            set(Calendar.YEAR, tYear)
        }
        tDay += cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    }

    if (tMonth < bMonth) {
        bYear += 1
        tMonth += 12
    }

    val years = maxOf(0, tYear - bYear)
    val months = maxOf(0, tMonth - bMonth)
    val days = maxOf(0, tDay - bDay)

    val diffMillis = maxOf(0L, target.timeInMillis - birth.timeInMillis)
    val totalDays = TimeUnit.MILLISECONDS.toDays(diffMillis)
    val totalHours = TimeUnit.MILLISECONDS.toHours(diffMillis)

    // Next birthday calculation
    val nextBday = Calendar.getInstance().apply {
        set(Calendar.MONTH, birth.get(Calendar.MONTH))
        set(Calendar.DAY_OF_MONTH, birth.get(Calendar.DAY_OF_MONTH))
        set(Calendar.YEAR, target.get(Calendar.YEAR))
    }
    if (nextBday.before(target)) {
        nextBday.add(Calendar.YEAR, 1)
    }
    val nextBirthdayMillis = maxOf(0L, nextBday.timeInMillis - target.timeInMillis)
    val nextBirthdayDays = TimeUnit.MILLISECONDS.toDays(nextBirthdayMillis)

    return AgeResult(years, months, days, nextBirthdayDays, totalDays, totalHours)
}
