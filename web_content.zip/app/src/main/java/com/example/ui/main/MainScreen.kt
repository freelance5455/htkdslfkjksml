package com.example.ui.main

import android.content.Context
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.EventNote
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.School
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.ExamEntity
import com.example.data.model.NoteEntity
import com.example.data.model.StudySessionEntity
import com.example.data.model.SubjectEntity
import com.example.data.model.UserEntity
import com.example.data.notes.BlockType
import com.example.data.notes.NoteAlignment
import com.example.data.notes.RichNoteDocument
import com.example.ui.analytics.PerformanceTrackingScreen
import com.example.ui.exam.ExamCountdownScreen
import com.example.ui.notes.NoteSortMode
import com.example.ui.notes.NotesTabScreen
import com.example.ui.notes.NotesUiState
import com.example.ui.profile.ProfileEditDialog
import com.example.ui.profile.ProfileSummaryHeader
import com.example.ui.profile.ProfileUiState
import com.example.ui.settings.SettingsScreen
import com.example.ui.settings.SettingsUiState
import com.example.ui.study.StudyUiState
import kotlinx.coroutines.launch

enum class MainDestination {
    STUDY,
    PERFORMANCE,
    EXAMS,
    NOTES,
    SETTINGS
}

@Composable
fun MainScreen(
    currentUser: UserEntity?,
    profileState: ProfileUiState,
    settingsState: SettingsUiState,
    studyState: StudyUiState,
    notesState: NotesUiState,
    // Profile callbacks
    onNameChange: (String) -> Unit,
    onInstituteChange: (String) -> Unit,
    onPhotoSelected: (android.net.Uri) -> Unit,
    onRemovePhoto: () -> Unit,
    onOpenProfileEdit: () -> Unit,
    onCloseProfileEdit: () -> Unit,
    onSaveProfile: () -> Unit,
    // Settings & Backup callbacks
    onSelectPreviewTheme: (String) -> Unit,
    onApplyTheme: (String) -> Unit,
    onExportBackup: (Context, Uri) -> Unit,
    onRestoreBackup: (Context, Uri) -> Unit,
    onDismissBackupFeedback: () -> Unit,
    onLogout: () -> Unit,
    // Timer callbacks
    onStartTimer: (Long?) -> Unit,
    onPauseTimer: () -> Unit,
    onResumeTimer: () -> Unit,
    onStopTimer: () -> Unit,
    onResetTimer: () -> Unit,
    onSelectTimerSubject: (Long) -> Unit,
    // Subject callbacks
    onOpenAddSubject: () -> Unit,
    onOpenEditSubject: (SubjectEntity) -> Unit,
    onCloseSubjectDialog: () -> Unit,
    onSubjectNameChange: (String) -> Unit,
    onSubjectColorChange: (String) -> Unit,
    onSubjectIconChange: (String) -> Unit,
    onSubjectTargetHoursChange: (String) -> Unit,
    onSaveSubject: () -> Unit,
    onOpenArchiveConfirm: (SubjectEntity) -> Unit,
    onCloseArchiveConfirm: () -> Unit,
    onConfirmArchiveSubject: () -> Unit,
    onRestoreSubject: (Long) -> Unit,
    onToggleArchivedSection: (Boolean) -> Unit,
    // Session callbacks
    onOpenAddManualSession: () -> Unit,
    onOpenEditSession: (StudySessionEntity) -> Unit,
    onCloseSessionDialog: () -> Unit,
    onSessionSubjectChange: (Long) -> Unit,
    onSessionDateChange: (String) -> Unit,
    onSessionStartTimeChange: (String) -> Unit,
    onSessionHoursChange: (String) -> Unit,
    onSessionMinutesChange: (String) -> Unit,
    onSessionTopicChange: (String) -> Unit,
    onSessionRemarkChange: (String) -> Unit,
    onSaveSession: () -> Unit,
    onOpenDeleteSessionConfirm: (StudySessionEntity) -> Unit,
    onCloseDeleteSessionConfirm: () -> Unit,
    onConfirmDeleteSession: () -> Unit,
    // Exam callbacks (PRD section 5.5)
    onAddExam: (String, String, Long?, Boolean, Boolean, Boolean) -> Unit,
    onUpdateExam: (ExamEntity) -> Unit,
    onDeleteExam: (Long) -> Unit,
    // Note callbacks (PRD section 6)
    onNotesSearchChange: (String) -> Unit,
    onNotesSortChange: (NoteSortMode) -> Unit,
    onNotesSubjectFilterChange: (Long?) -> Unit,
    onOpenNewNote: () -> Unit,
    onOpenEditNote: (NoteEntity) -> Unit,
    onCloseNoteEditor: () -> Unit,
    onTogglePinInList: (NoteEntity) -> Unit,
    onNoteTitleChange: (String) -> Unit,
    onNoteDocumentChange: (RichNoteDocument, Boolean) -> Unit,
    onNoteSubjectChange: (Long?) -> Unit,
    onTogglePinInEditor: () -> Unit,
    onFontFamilyChange: (String) -> Unit,
    onFontSizeChange: (Int) -> Unit,
    onAlignmentChange: (NoteAlignment) -> Unit,
    onBlockTypeChange: (Int, BlockType) -> Unit,
    onBlockTextChange: (Int, String) -> Unit,
    onToggleChecklist: (String) -> Unit,
    onAddBlock: (Int, BlockType) -> Unit,
    onRemoveBlock: (Int) -> Unit,
    onApplyInlineSpan: (Int, Int, Int, Boolean?, Boolean?, Boolean?, Boolean?, String?, String?) -> Unit,
    onUndoNote: () -> Unit,
    onRedoNote: () -> Unit,
    onSaveNote: () -> Unit,
    onDeleteNote: (NoteEntity) -> Unit,
    onDeleteCurrentEditingNote: () -> Unit
) {
    var currentDestination by remember { mutableStateOf(MainDestination.STUDY) }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    // Handle Android system Back button
    BackHandler(enabled = drawerState.isOpen || notesState.isEditorOpen || currentDestination != MainDestination.STUDY) {
        if (drawerState.isOpen) {
            scope.launch { drawerState.close() }
        } else if (notesState.isEditorOpen) {
            onCloseNoteEditor()
        } else if (currentDestination != MainDestination.STUDY) {
            currentDestination = MainDestination.STUDY
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                modifier = Modifier
                    .widthIn(max = 320.dp)
                    .fillMaxHeight(),
                drawerContainerColor = MaterialTheme.colorScheme.surface
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 20.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = "Account & Settings",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    // Profile Summary Header at the top of the sidebar (PRD section 4.1)
                    ProfileSummaryHeader(
                        profile = profileState.profile,
                        fallbackUsername = currentUser?.username,
                        onEditClick = {
                            scope.launch { drawerState.close() }
                            onOpenProfileEdit()
                        }
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Navigation",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                    )

                    // Navigation Drawer Item: Study Tracker
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.School, contentDescription = null) },
                        label = { Text("Study Tracker") },
                        selected = currentDestination == MainDestination.STUDY,
                        onClick = {
                            currentDestination = MainDestination.STUDY
                            scope.launch { drawerState.close() }
                        },
                        modifier = Modifier
                            .padding(NavigationDrawerItemDefaults.ItemPadding)
                            .testTag("drawer_study_tracker_item")
                    )

                    // Navigation Drawer Item: Performance Tracking (PRD section 5.4)
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.BarChart, contentDescription = null) },
                        label = { Text("Performance Tracking") },
                        selected = currentDestination == MainDestination.PERFORMANCE,
                        onClick = {
                            currentDestination = MainDestination.PERFORMANCE
                            scope.launch { drawerState.close() }
                        },
                        modifier = Modifier
                            .padding(NavigationDrawerItemDefaults.ItemPadding)
                            .testTag("drawer_performance_item")
                    )

                    // Navigation Drawer Item: Exam Countdown (PRD section 5.5)
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.EventNote, contentDescription = null) },
                        label = { Text("Exam Countdown (${studyState.activeExams.size})") },
                        selected = currentDestination == MainDestination.EXAMS,
                        onClick = {
                            currentDestination = MainDestination.EXAMS
                            scope.launch { drawerState.close() }
                        },
                        modifier = Modifier
                            .padding(NavigationDrawerItemDefaults.ItemPadding)
                            .testTag("drawer_exams_item")
                    )

                    // Navigation Drawer Item: Notes
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.Description, contentDescription = null) },
                        label = { Text("Notes Space") },
                        selected = currentDestination == MainDestination.NOTES,
                        onClick = {
                            currentDestination = MainDestination.NOTES
                            scope.launch { drawerState.close() }
                        },
                        modifier = Modifier
                            .padding(NavigationDrawerItemDefaults.ItemPadding)
                            .testTag("drawer_notes_item")
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Preferences",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                    )

                    // Navigation Drawer Item: Settings Entry
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                        label = { Text("Settings (Themes & Session)") },
                        selected = currentDestination == MainDestination.SETTINGS,
                        onClick = {
                            currentDestination = MainDestination.SETTINGS
                            scope.launch { drawerState.close() }
                        },
                        modifier = Modifier
                            .padding(NavigationDrawerItemDefaults.ItemPadding)
                            .testTag("drawer_settings_item")
                    )

                    Spacer(modifier = Modifier.weight(1f))
                    Spacer(modifier = Modifier.height(24.dp))

                    // Footer with session info & logout button
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                            .padding(12.dp)
                    ) {
                        Column {
                            Text(
                                text = "Signed in as @${currentUser?.username ?: "user"}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "14-day offline session active",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            TextButton(
                                onClick = {
                                    scope.launch { drawerState.close() }
                                    onLogout()
                                },
                                modifier = Modifier.testTag("drawer_logout_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Logout,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Log Out",
                                    color = MaterialTheme.colorScheme.error,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    ) {
        when (currentDestination) {
            MainDestination.SETTINGS -> {
                SettingsScreen(
                    settingsState = settingsState,
                    currentUser = currentUser,
                    onSelectPreviewTheme = onSelectPreviewTheme,
                    onApplyTheme = onApplyTheme,
                    onExportBackup = onExportBackup,
                    onRestoreBackup = onRestoreBackup,
                    onDismissBackupFeedback = onDismissBackupFeedback,
                    onLogoutClick = onLogout,
                    onBackClick = { currentDestination = MainDestination.STUDY }
                )
            }
            MainDestination.PERFORMANCE -> {
                PerformanceTrackingScreen(
                    sessions = studyState.sessions,
                    activeSubjects = studyState.activeSubjects,
                    subjectsMap = studyState.subjectsMap,
                    onOpenDrawer = { scope.launch { drawerState.open() } }
                )
            }
            MainDestination.EXAMS -> {
                ExamCountdownScreen(
                    activeExams = studyState.activeExams,
                    archivedExams = studyState.archivedExams,
                    subjectsMap = studyState.subjectsMap,
                    activeSubjects = studyState.activeSubjects,
                    onOpenDrawer = { scope.launch { drawerState.open() } },
                    onAddExam = onAddExam,
                    onUpdateExam = onUpdateExam,
                    onDeleteExam = onDeleteExam
                )
            }
            else -> {
                Scaffold(
                    bottomBar = {
                        NavigationBar(
                            windowInsets = WindowInsets.navigationBars,
                            containerColor = MaterialTheme.colorScheme.surface,
                            tonalElevation = 4.dp
                        ) {
                            NavigationBarItem(
                                selected = currentDestination == MainDestination.STUDY,
                                onClick = { currentDestination = MainDestination.STUDY },
                                icon = {
                                    Icon(
                                        imageVector = if (currentDestination == MainDestination.STUDY) Icons.Default.School else Icons.Outlined.School,
                                        contentDescription = "Study Tracker"
                                    )
                                },
                                label = { Text("Study") },
                                modifier = Modifier.testTag("bottom_nav_study_item")
                            )

                            NavigationBarItem(
                                selected = currentDestination == MainDestination.NOTES,
                                onClick = { currentDestination = MainDestination.NOTES },
                                icon = {
                                    Icon(
                                        imageVector = if (currentDestination == MainDestination.NOTES) Icons.Default.Description else Icons.Outlined.Description,
                                        contentDescription = "Notes"
                                    )
                                },
                                label = { Text("Notes") },
                                modifier = Modifier.testTag("bottom_nav_notes_item")
                            )
                        }
                    }
                ) { scaffoldPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(scaffoldPadding)
                    ) {
                        when (currentDestination) {
                            MainDestination.STUDY -> {
                                StudyTabScreen(
                                    state = studyState,
                                    onOpenDrawer = { scope.launch { drawerState.open() } },
                                    onNavigateToExams = { currentDestination = MainDestination.EXAMS },
                                    onNavigateToPerformance = { currentDestination = MainDestination.PERFORMANCE },
                                    onStartTimer = onStartTimer,
                                    onPauseTimer = onPauseTimer,
                                    onResumeTimer = onResumeTimer,
                                    onStopTimer = onStopTimer,
                                    onResetTimer = onResetTimer,
                                    onSelectTimerSubject = onSelectTimerSubject,
                                    onOpenAddSubject = onOpenAddSubject,
                                    onOpenEditSubject = onOpenEditSubject,
                                    onCloseSubjectDialog = onCloseSubjectDialog,
                                    onSubjectNameChange = onSubjectNameChange,
                                    onSubjectColorChange = onSubjectColorChange,
                                    onSubjectIconChange = onSubjectIconChange,
                                    onSubjectTargetHoursChange = onSubjectTargetHoursChange,
                                    onSaveSubject = onSaveSubject,
                                    onOpenArchiveConfirm = onOpenArchiveConfirm,
                                    onCloseArchiveConfirm = onCloseArchiveConfirm,
                                    onConfirmArchiveSubject = onConfirmArchiveSubject,
                                    onRestoreSubject = onRestoreSubject,
                                    onToggleArchivedSection = onToggleArchivedSection,
                                    onOpenAddManualSession = onOpenAddManualSession,
                                    onOpenEditSession = onOpenEditSession,
                                    onCloseSessionDialog = onCloseSessionDialog,
                                    onSessionSubjectChange = onSessionSubjectChange,
                                    onSessionDateChange = onSessionDateChange,
                                    onSessionStartTimeChange = onSessionStartTimeChange,
                                    onSessionHoursChange = onSessionHoursChange,
                                    onSessionMinutesChange = onSessionMinutesChange,
                                    onSessionTopicChange = onSessionTopicChange,
                                    onSessionRemarkChange = onSessionRemarkChange,
                                    onSaveSession = onSaveSession,
                                    onOpenDeleteSessionConfirm = onOpenDeleteSessionConfirm,
                                    onCloseDeleteSessionConfirm = onCloseDeleteSessionConfirm,
                                    onConfirmDeleteSession = onConfirmDeleteSession
                                )
                            }
                            MainDestination.NOTES -> {
                                NotesTabScreen(
                                    notesState = notesState,
                                    subjects = studyState.activeSubjects.map { it.subject },
                                    subjectsMap = studyState.subjectsMap,
                                    onOpenDrawer = { scope.launch { drawerState.open() } },
                                    onSearchChange = onNotesSearchChange,
                                    onSortChange = onNotesSortChange,
                                    onSubjectFilterChange = onNotesSubjectFilterChange,
                                    onOpenNewNote = onOpenNewNote,
                                    onOpenEditNote = onOpenEditNote,
                                    onCloseEditor = onCloseNoteEditor,
                                    onTogglePinInList = onTogglePinInList,
                                    onTitleChange = onNoteTitleChange,
                                    onDocumentChange = onNoteDocumentChange,
                                    onSubjectChange = onNoteSubjectChange,
                                    onTogglePinInEditor = onTogglePinInEditor,
                                    onFontFamilyChange = onFontFamilyChange,
                                    onFontSizeChange = onFontSizeChange,
                                    onAlignmentChange = onAlignmentChange,
                                    onBlockTypeChange = onBlockTypeChange,
                                    onBlockTextChange = onBlockTextChange,
                                    onToggleChecklist = onToggleChecklist,
                                    onAddBlock = onAddBlock,
                                    onRemoveBlock = onRemoveBlock,
                                    onApplyInlineSpan = onApplyInlineSpan,
                                    onUndoClick = onUndoNote,
                                    onRedoClick = onRedoNote,
                                    onSaveClick = onSaveNote,
                                    onDeleteNote = onDeleteNote,
                                    onDeleteCurrentEditingNote = onDeleteCurrentEditingNote
                                )
                            }
                            else -> {}
                        }
                    }
                }
            }
        }
    }

    // Profile Edit Dialog
    if (profileState.isEditDialogOpen) {
        ProfileEditDialog(
            state = profileState,
            onNameChange = onNameChange,
            onInstituteChange = onInstituteChange,
            onPhotoSelected = onPhotoSelected,
            onRemovePhoto = onRemovePhoto,
            onDismiss = onCloseProfileEdit,
            onSave = onSaveProfile
        )
    }
}
