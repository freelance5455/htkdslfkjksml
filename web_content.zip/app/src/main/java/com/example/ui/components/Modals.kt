package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.LessonEntity
import com.example.data.local.TrackEntity
import com.example.data.local.TrackLessonEntity
import com.example.data.model.AppConstants
import com.example.data.model.LessonMode
import com.example.ui.theme.BrandIndigo
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.RoseFocus
import com.example.util.DateTimeUtils
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun LessonEditorDialog(
    initialLesson: LessonEntity?,
    prefillDay: String,
    onDismiss: () -> Unit,
    onSave: (
        id: String?,
        subject: String,
        day: String,
        mode: String,
        teacher: String,
        time: String,
        location: String,
        colorHex: String
    ) -> Unit
) {
    var subject by remember { mutableStateOf(initialLesson?.subject ?: "") }
    var day by remember { mutableStateOf(initialLesson?.day ?: prefillDay) }
    var mode by remember { mutableStateOf(initialLesson?.mode ?: LessonMode.CENTER.key) }
    var teacher by remember { mutableStateOf(initialLesson?.teacher ?: "") }
    var time by remember { mutableStateOf(DateTimeUtils.parseTo24h(initialLesson?.time)) }
    var location by remember { mutableStateOf(initialLesson?.location ?: "") }
    var colorHex by remember { mutableStateOf(initialLesson?.colorHex ?: AppConstants.LESSON_PRESET_COLORS.first()) }
    var dayExpanded by remember { mutableStateOf(false) }
    var showTimePicker by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialLesson == null) "إضافة درس جديد" else "تعديل الدرس",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("اسم المادة *") },
                    placeholder = { Text("فيزياء، كيمياء، عربي...") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("lesson_subject_input")
                )

                ExposedDropdownMenuBox(
                    expanded = dayExpanded,
                    onExpandedChange = { dayExpanded = !dayExpanded }
                ) {
                    OutlinedTextField(
                        value = day,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("اليوم *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = dayExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                            .testTag("lesson_day_dropdown")
                    )
                    ExposedDropdownMenu(
                        expanded = dayExpanded,
                        onDismissRequest = { dayExpanded = false }
                    ) {
                        AppConstants.DAYS_OF_WEEK.forEach { d ->
                            DropdownMenuItem(
                                text = { Text(d) },
                                onClick = {
                                    day = d
                                    dayExpanded = false
                                }
                            )
                        }
                    }
                }

                Text("نوع الحصة", style = MaterialTheme.typography.labelMedium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    LessonMode.entries.forEach { m ->
                        FilterChip(
                            selected = mode == m.key,
                            onClick = { mode = m.key },
                            label = { Text(m.label, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                OutlinedTextField(
                    value = teacher,
                    onValueChange = { teacher = it },
                    label = { Text("اسم المدرس") },
                    placeholder = { Text("أ/ محمد عبد المعبود") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("lesson_teacher_input")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = { showTimePicker = true },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f).height(54.dp).testTag("lesson_time_button")
                    ) {
                        Icon(Icons.Filled.Schedule, contentDescription = "اختر التوقيت", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (time.isBlank()) "التوقيت" else DateTimeUtils.formatTime12h(time),
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                    OutlinedTextField(
                        value = location,
                        onValueChange = { location = it },
                        label = { Text("المكان / المنصة") },
                        singleLine = true,
                        modifier = Modifier.weight(1.2f).testTag("lesson_location_input")
                    )
                }

                Text("لون البطاقة", style = MaterialTheme.typography.labelMedium)
                ColorSwatchRow(
                    colors = AppConstants.LESSON_PRESET_COLORS,
                    selected = colorHex,
                    onSelect = { colorHex = it }
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (subject.isNotBlank()) {
                        onSave(initialLesson?.id, subject, day, mode, teacher, time, location, colorHex)
                    }
                },
                enabled = subject.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = BrandIndigo),
                modifier = Modifier.testTag("lesson_save_button")
            ) {
                Text("حفظ الدرس")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )

    if (showTimePicker) {
        val parts = time.split(":")
        val initHour = parts.getOrNull(0)?.toIntOrNull() ?: 16
        val initMinute = parts.getOrNull(1)?.toIntOrNull() ?: 0
        val timeState = rememberTimePickerState(initialHour = initHour, initialMinute = initMinute, is24Hour = false)
        AlertDialog(
            onDismissRequest = { showTimePicker = false },
            title = { Text("تحديد التوقيت") },
            text = { TimePicker(state = timeState) },
            confirmButton = {
                TextButton(onClick = {
                    time = String.format(Locale.US, "%02d:%02d", timeState.hour, timeState.minute)
                    showTimePicker = false
                }) { Text("تم") }
            },
            dismissButton = {
                TextButton(onClick = { showTimePicker = false }) { Text("إلغاء") }
            }
        )
    }
}

@Composable
fun TrackEditorDialog(
    initialTrack: TrackEntity?,
    onDismiss: () -> Unit,
    onSave: (id: String?, name: String, teacher: String, colorHex: String) -> Unit
) {
    var name by remember { mutableStateOf(initialTrack?.name ?: "") }
    var teacher by remember { mutableStateOf(initialTrack?.teacher ?: "") }
    var colorHex by remember { mutableStateOf(initialTrack?.colorHex ?: AppConstants.TRACK_PRESET_COLORS.first()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialTrack == null) "إضافة مسار مادة" else "تعديل المسار",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black,
                color = EmeraldSuccess
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم المسار / المادة *") },
                    placeholder = { Text("الفيزياء - الكهربية") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("track_name_input")
                )
                OutlinedTextField(
                    value = teacher,
                    onValueChange = { teacher = it },
                    label = { Text("اسم المدرس / المنصة") },
                    placeholder = { Text("أ/ محمد عبد المعبود") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("track_teacher_input")
                )
                Text("لون المسار", style = MaterialTheme.typography.labelMedium)
                ColorSwatchRow(
                    colors = AppConstants.TRACK_PRESET_COLORS,
                    selected = colorHex,
                    onSelect = { colorHex = it }
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) onSave(initialTrack?.id, name, teacher, colorHex)
                },
                enabled = name.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldSuccess),
                modifier = Modifier.testTag("track_save_button")
            ) {
                Text("حفظ المسار")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun TrackLessonEditorDialog(
    trackId: String,
    initialLesson: TrackLessonEntity?,
    onDismiss: () -> Unit,
    onSaveSingle: (trackId: String, lessonId: String?, title: String, note: String) -> Unit,
    onSaveBulk: (trackId: String, lines: String) -> Unit
) {
    var title by remember { mutableStateOf(initialLesson?.title ?: "") }
    var note by remember { mutableStateOf(initialLesson?.note ?: "") }
    var isBulkMode by remember { mutableStateOf(false) }
    var bulkText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialLesson != null) "تعديل الدرس" else "إضافة دروس للمسار",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (!isBulkMode) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("عنوان الدرس *") },
                        placeholder = { Text("الدرس الأول: التيار الكهربي") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("track_lesson_title_input")
                    )
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("ملاحظة (اختياري)") },
                        placeholder = { Text("حل شيت الدرس") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("track_lesson_note_input")
                    )
                } else {
                    OutlinedTextField(
                        value = bulkText,
                        onValueChange = { bulkText = it },
                        label = { Text("أضف عدة دروس (كل سطر درس)") },
                        placeholder = { Text("الدرس الأول\nالدرس الثاني\nالدرس الثالث") },
                        minLines = 5,
                        maxLines = 8,
                        modifier = Modifier.fillMaxWidth().testTag("track_lesson_bulk_input")
                    )
                }

                if (initialLesson == null) {
                    TextButton(
                        onClick = { isBulkMode = !isBulkMode },
                        modifier = Modifier.testTag("toggle_bulk_lesson_mode")
                    ) {
                        Text(
                            text = if (isBulkMode) "العودة لإضافة درس واحد" else "+ إضافة عدة دروس دفعة واحدة",
                            color = BrandIndigo
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (isBulkMode) {
                        onSaveBulk(trackId, bulkText)
                    } else {
                        onSaveSingle(trackId, initialLesson?.id, title, note)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = BrandIndigo),
                modifier = Modifier.testTag("track_lesson_save_button")
            ) {
                Text("حفظ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsBackupDialog(
    currentExamDate: String,
    onDismiss: () -> Unit,
    onSaveExamDate: (String) -> Unit,
    onExportBackup: () -> Unit,
    onImportBackup: () -> Unit,
    onPrintTimetable: () -> Unit,
    onRequestResetAll: () -> Unit
) {
    var showDatePicker by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "الإعدادات والنسخ الاحتياطي",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("تاريخ بداية الامتحانات", style = MaterialTheme.typography.labelLarge)
                    OutlinedButton(
                        onClick = { showDatePicker = true },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().testTag("settings_pick_exam_date")
                    ) {
                        Icon(Icons.Filled.CalendarMonth, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(currentExamDate, fontWeight = FontWeight.Bold)
                    }
                }

                HorizontalDivider()

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("النسخ الاحتياطي المحلي (JSON)", style = MaterialTheme.typography.labelLarge)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = onExportBackup,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.5f)),
                            modifier = Modifier.weight(1f).testTag("settings_export_backup")
                        ) {
                            Icon(Icons.Filled.Download, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تصدير", color = EmeraldSuccess, style = MaterialTheme.typography.labelMedium)
                        }
                        OutlinedButton(
                            onClick = onImportBackup,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, BrandIndigo.copy(alpha = 0.5f)),
                            modifier = Modifier.weight(1f).testTag("settings_import_backup")
                        ) {
                            Icon(Icons.Filled.Upload, contentDescription = null, tint = BrandIndigo, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("استيراد", color = BrandIndigo, style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }

                HorizontalDivider()

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            onDismiss()
                            onPrintTimetable()
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f).testTag("settings_print_button")
                    ) {
                        Icon(Icons.Filled.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("طباعة الجدول", style = MaterialTheme.typography.labelMedium)
                    }
                    OutlinedButton(
                        onClick = onRequestResetAll,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, RoseFocus.copy(alpha = 0.5f)),
                        modifier = Modifier.weight(1f).testTag("settings_reset_all_button")
                    ) {
                        Icon(Icons.Filled.DeleteForever, contentDescription = null, tint = RoseFocus, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("مسح الكل", color = RoseFocus, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("إغلاق") }
        }
    )

    if (showDatePicker) {
        val initialMillis = remember(currentExamDate) {
            try {
                SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
                    timeZone = TimeZone.getTimeZone("UTC")
                }.parse(currentExamDate)?.time
            } catch (_: Exception) {
                null
            }
        }
        val state = rememberDatePickerState(initialSelectedDateMillis = initialMillis)
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { millis ->
                        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
                            timeZone = TimeZone.getTimeZone("UTC")
                        }
                        onSaveExamDate(sdf.format(Date(millis)))
                    }
                    showDatePicker = false
                }) { Text("حفظ") }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) { Text("إلغاء") }
            }
        ) {
            DatePicker(state = state)
        }
    }
}

@Composable
fun ConfirmActionDialog(
    message: String,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Surface(
                color = RoseFocus.copy(alpha = 0.14f),
                shape = CircleShape,
                modifier = Modifier.size(48.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.Warning, contentDescription = null, tint = RoseFocus)
                }
            }
        },
        title = {
            Text("تأكيد الإجراء", fontWeight = FontWeight.Black)
        },
        text = {
            Text(message, style = MaterialTheme.typography.bodyMedium)
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm()
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = RoseFocus),
                modifier = Modifier.testTag("confirm_dialog_ok")
            ) {
                Text("تأكيد")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
private fun ColorSwatchRow(
    colors: List<String>,
    selected: String,
    onSelect: (String) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        colors.forEach { hex ->
            val color = AppConstants.parseHexColor(hex)
            val isSelected = hex.equals(selected, ignoreCase = true)
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(color)
                    .then(
                        if (isSelected) {
                            Modifier.border(2.5.dp, Color.White, RoundedCornerShape(10.dp))
                        } else {
                            Modifier
                        }
                    )
                    .clickable { onSelect(hex) }
            )
        }
    }
}
