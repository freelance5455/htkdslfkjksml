package com.example.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Text
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.ByteSizeFormatter
import com.example.data.model.BreadcrumbSegment
import com.example.data.model.FileKind
import com.example.data.model.FileNode
import com.example.ui.theme.LocalAnimationSpecs
import com.example.ui.viewmodel.DirectoryUiState
import com.example.ui.viewmodel.FileManagerViewModel

/**
 * Stateful overload of [FileList] bound directly to [FileManagerViewModel],
 * providing out-of-the-box directory traversal, breadcrumb navigation, and BackHandler support.
 */
@Composable
fun FileList(
    viewModel: FileManagerViewModel,
    modifier: Modifier = Modifier,
    showExtensions: Boolean = true,
    onOpenFile: (FileNode) -> Unit = {}
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    BackHandler(enabled = uiState.canNavigateUp) {
        viewModel.navigateUp()
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("file_manager_container")
    ) {
        // Directory Navigation Header & Breadcrumb Trail
        DirectoryBreadcrumbBar(
            breadcrumbs = uiState.breadcrumbs,
            canNavigateUp = uiState.canNavigateUp,
            onNavigateUp = { viewModel.navigateUp() },
            onSelectBreadcrumb = { path -> viewModel.navigateToBreadcrumb(path) }
        )

        when (val dirState = uiState.directoryState) {
            is DirectoryUiState.Loading -> {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("file_list_loading"),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            }

            is DirectoryUiState.Error -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp)
                        .testTag("file_list_error"),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = dirState.message,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.error
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { viewModel.refresh() }) {
                        Text("Retry")
                    }
                }
            }

            is DirectoryUiState.Success -> {
                FileList(
                    items = dirState.items,
                    onItemClick = { node ->
                        viewModel.onItemClicked(node, onOpenFile = onOpenFile)
                    },
                    showExtensions = showExtensions,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

/**
 * Reusable stateless [FileList] composable using [LazyColumn] to display files and folders
 * with Samsung One UI styling, optional multi-selection, swipe-to-delete, and detail badges.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FileList(
    items: List<FileNode>,
    onItemClick: (FileNode) -> Unit,
    modifier: Modifier = Modifier,
    selectedPaths: Set<String> = emptySet(),
    inSelectionMode: Boolean = selectedPaths.isNotEmpty(),
    isDetailMode: Boolean = false,
    showExtensions: Boolean = true,
    onItemLongClick: ((FileNode) -> Unit)? = null,
    onShowDetails: ((FileNode) -> Unit)? = null,
    onSwipeDelete: ((FileNode) -> Unit)? = null,
    emptyContent: (@Composable () -> Unit)? = null
) {
    val animSpecs = LocalAnimationSpecs.current

    if (items.isEmpty()) {
        if (emptyContent != null) {
            emptyContent()
        } else {
            Column(
                modifier = modifier
                    .fillMaxSize()
                    .padding(32.dp)
                    .testTag("file_list_empty_state"),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(28.dp),
                    modifier = Modifier.size(76.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.FolderOpen,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(18.dp)
                    )
                }
                Spacer(Modifier.height(14.dp))
                Text("No files", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(4.dp))
                Text(
                    "This folder is empty.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        return
    }

    LazyColumn(
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
        modifier = modifier
            .fillMaxSize()
            .testTag("file_list_lazy_column")
    ) {
        items(items, key = { it.path }) { node ->
            val selected = node.path in selectedPaths
            val rowModifier = Modifier.animateItem(placementSpec = animSpecs.placementSpec())

            if (onSwipeDelete != null && !inSelectionMode) {
                val dismissState = rememberSwipeToDismissBoxState(
                    confirmValueChange = { value ->
                        if (value == SwipeToDismissBoxValue.EndToStart) {
                            onSwipeDelete(node)
                            true
                        } else {
                            false
                        }
                    }
                )
                SwipeToDismissBox(
                    state = dismissState,
                    enableDismissFromStartToEnd = false,
                    backgroundContent = {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(RoundedCornerShape(18.dp))
                                .background(MaterialTheme.colorScheme.error.copy(alpha = 0.85f))
                                .padding(end = 20.dp),
                            contentAlignment = Alignment.CenterEnd
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Delete,
                                contentDescription = "Move to Trash",
                                tint = MaterialTheme.colorScheme.onPrimary
                            )
                        }
                    },
                    modifier = rowModifier
                ) {
                    FileListRowCard(
                        node = node,
                        selected = selected,
                        inSelectionMode = inSelectionMode,
                        isDetailMode = isDetailMode,
                        showExtensions = showExtensions,
                        onClick = { onItemClick(node) },
                        onLongClick = onItemLongClick?.let { handler -> { handler(node) } },
                        onShowDetails = onShowDetails?.let { handler -> { handler(node) } }
                    )
                }
            } else {
                FileListRowCard(
                    node = node,
                    selected = selected,
                    inSelectionMode = inSelectionMode,
                    isDetailMode = isDetailMode,
                    showExtensions = showExtensions,
                    onClick = { onItemClick(node) },
                    onLongClick = onItemLongClick?.let { handler -> { handler(node) } },
                    onShowDetails = onShowDetails?.let { handler -> { handler(node) } },
                    modifier = rowModifier
                )
            }
        }
    }
}

@Composable
fun DirectoryBreadcrumbBar(
    breadcrumbs: List<BreadcrumbSegment>,
    canNavigateUp: Boolean,
    onNavigateUp: () -> Unit,
    onSelectBreadcrumb: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (canNavigateUp) {
            IconButton(
                onClick = onNavigateUp,
                modifier = Modifier.testTag("navigate_up_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Navigate up"
                )
            }
        }

        LazyRow(
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .weight(1f)
                .testTag("breadcrumb_row")
        ) {
            items(breadcrumbs.size) { index ->
                val seg = breadcrumbs[index]
                val isLast = index == breadcrumbs.lastIndex
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = seg.label,
                        style = MaterialTheme.typography.labelLarge,
                        color = if (isLast) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        fontWeight = if (isLast) FontWeight.Bold else FontWeight.Medium,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onSelectBreadcrumb(seg.path) }
                            .padding(horizontal = 6.dp, vertical = 4.dp)
                            .testTag("breadcrumb_${seg.label}")
                    )
                    if (!isLast) {
                        Icon(
                            imageVector = Icons.Filled.ChevronRight,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FileListRowCard(
    node: FileNode,
    selected: Boolean,
    inSelectionMode: Boolean,
    isDetailMode: Boolean,
    showExtensions: Boolean,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)?,
    onShowDetails: (() -> Unit)?,
    modifier: Modifier = Modifier
) {
    val containerColor = if (selected) {
        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.72f)
    } else {
        MaterialTheme.colorScheme.surface
    }

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .testTag("file_item_${node.name}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (inSelectionMode) {
                Icon(
                    imageVector = if (selected) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                    contentDescription = if (selected) "Selected" else "Unselected",
                    tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(Modifier.width(12.dp))
            }

            FileTypeThumbnail(node = node, size = 46.dp)
            Spacer(Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = node.displayName(showExtensions),
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (node.isFavorite) {
                        Icon(
                            imageVector = Icons.Filled.Star,
                            contentDescription = "Favorite",
                            tint = Color(0xFFF59E0B),
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }

                val metaText = if (node.isDirectory) {
                    val itemCount = node.childFolderCount + node.childFileCount
                    val datePart = ByteSizeFormatter.formatShortDate(node.lastModified)
                    if (datePart.isNotEmpty()) "$itemCount items • $datePart" else "$itemCount items"
                } else {
                    val datePart = ByteSizeFormatter.formatShortDate(node.lastModified)
                    if (datePart.isNotEmpty()) {
                        "${ByteSizeFormatter.format(node.sizeBytes)} • $datePart"
                    } else {
                        ByteSizeFormatter.format(node.sizeBytes)
                    }
                }
                Text(
                    text = metaText,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                val badge = node.kind.badgeText
                if (badge != null || node.hasSuspiciousDoubleExtension || isDetailMode) {
                    Spacer(Modifier.height(4.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (badge != null) {
                            FileBadgePill(
                                text = badge,
                                isWarning = node.kind == FileKind.EXE || node.kind == FileKind.MSI
                            )
                        }
                        if (node.hasSuspiciousDoubleExtension) {
                            FileBadgePill(text = "Suspicious double ext", isWarning = true)
                        }
                        if (isDetailMode && node.magicSignature != null) {
                            FileBadgePill(text = node.magicSignature)
                        }
                    }
                }
            }

            if (node.isDirectory && !inSelectionMode && onShowDetails == null) {
                Icon(
                    imageVector = Icons.Filled.ChevronRight,
                    contentDescription = "Open ${node.name}",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(20.dp)
                )
            } else if (!inSelectionMode && onShowDetails != null) {
                IconButton(onClick = onShowDetails) {
                    Icon(
                        imageVector = Icons.Filled.Info,
                        contentDescription = "Details for ${node.name}",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}
