package com.example.ui.converter

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Backspace
import androidx.compose.material.icons.outlined.Clear
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.SwapVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.converter.ConversionUnit
import com.example.converter.ConverterCategory
import com.example.engine.FormattingOptions
import com.example.ui.components.AetherCard
import com.example.ui.components.AetherFilterChip
import com.example.ui.components.AetherNumberField
import com.example.ui.components.TactileKey
import com.example.ui.theme.AetherTheme
import com.example.ui.theme.InterFamily

@Composable
fun ConverterScreen(
  state: ConverterUiState,
  formatting: FormattingOptions,
  hapticsEnabled: Boolean,
  onSelectCategory: (ConverterCategory) -> Unit,
  onSelectFromUnit: (ConversionUnit) -> Unit,
  onSelectToUnit: (ConversionUnit) -> Unit,
  onSwapUnits: () -> Unit,
  onDigit: (String) -> Unit,
  onDecimal: () -> Unit,
  onToggleSign: () -> Unit,
  onBackspace: () -> Unit,
  onClear: () -> Unit,
  onCustomRateChanged: (String) -> Unit,
  onCopyResult: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val colors = AetherTheme.colors
  val outputText = remember(state, formatting) { state.computeOutput(formatting) }

  Box(
    modifier = modifier.fillMaxSize().background(colors.background),
    contentAlignment = Alignment.TopCenter,
  ) {
    Column(
      modifier = Modifier.fillMaxSize().widthIn(max = 560.dp).padding(horizontal = 16.dp).padding(bottom = 8.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      // Compact header
      Row(
        modifier = Modifier.fillMaxWidth().height(48.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = stringResource(R.string.nav_convert),
          style = MaterialTheme.typography.headlineSmall,
          color = colors.textPrimary,
        )
        Text(
          text = state.effectiveRateLabel(),
          style =
            TextStyle(
              fontFamily = InterFamily,
              fontSize = 12.sp,
              fontWeight = FontWeight.Medium,
              color = colors.lavender,
              fontFeatureSettings = "tnum",
            ),
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }

      // Category chips
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(end = 8.dp),
      ) {
        items(ConverterCategory.entries) { category ->
          AetherFilterChip(
            label = category.title,
            selected = state.category == category,
            onClick = { onSelectCategory(category) },
            hapticsEnabled = hapticsEnabled,
            modifier = Modifier.testTag("converter_cat_${category.name}"),
          )
        }
      }

      if (state.category.isCurrency) {
        AetherCard(
          backgroundColor = colors.surfaceElevated,
          contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Outlined.Info,
              contentDescription = null,
              tint = colors.lavender,
              modifier = Modifier.size(16.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = stringResource(R.string.offline_currency_notice),
              style = MaterialTheme.typography.bodySmall,
              color = colors.textSecondary,
            )
          }
          Spacer(modifier = Modifier.height(8.dp))
          AetherNumberField(
            value = state.customRateText,
            onValueChange = onCustomRateChanged,
            label = "Custom rate (1 ${state.fromUnit.symbol} → ${state.toUnit.symbol})",
            placeholder = "Using offline reference rate",
          )
        }
      }

      // From & To Conversion Cards with overlapping swap button
      Box(modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          UnitInputCard(
            label = "From",
            selectedUnit = state.fromUnit,
            units = state.units,
            valueText = state.inputText,
            isInput = true,
            onSelectUnit = onSelectFromUnit,
            onTrailingAction = onClear,
          )

          UnitInputCard(
            label = "To",
            selectedUnit = state.toUnit,
            units = state.units,
            valueText = outputText,
            isInput = false,
            onSelectUnit = onSelectToUnit,
            onTrailingAction = {
              if (outputText != "—") onCopyResult(outputText)
            },
          )
        }

        TactileKey(
          onClick = onSwapUnits,
          backgroundColor = colors.accent,
          pressedColor = colors.accentPressed,
          borderColor = colors.background,
          shape = CircleShape,
          hapticsEnabled = hapticsEnabled,
          testTag = "converter_swap_button",
          modifier = Modifier.align(Alignment.Center).size(44.dp),
        ) {
          Icon(
            imageVector = Icons.Rounded.SwapVert,
            contentDescription = stringResource(R.string.cd_swap_units),
            tint = Color(0xFFF1F0F5),
            modifier = Modifier.size(22.dp),
          )
        }
      }

      // Built-in keyboard-free converter numeric keypad
      ConverterKeypad(
        allowSign = state.category == ConverterCategory.TEMPERATURE,
        hapticsEnabled = hapticsEnabled,
        onDigit = onDigit,
        onDecimal = onDecimal,
        onToggleSign = onToggleSign,
        onBackspace = onBackspace,
        onClear = onClear,
        onCopy = {
          if (outputText != "—") onCopyResult(outputText)
        },
        modifier = Modifier.weight(1f).fillMaxWidth(),
      )
    }
  }
}

@Composable
private fun UnitInputCard(
  label: String,
  selectedUnit: ConversionUnit,
  units: List<ConversionUnit>,
  valueText: String,
  isInput: Boolean,
  onSelectUnit: (ConversionUnit) -> Unit,
  onTrailingAction: () -> Unit,
) {
  val colors = AetherTheme.colors
  var menuExpanded by remember { mutableStateOf(false) }

  AetherCard(
    backgroundColor = colors.surface,
    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Box {
        Row(
          modifier =
            Modifier
              .clip(RoundedCornerShape(10.dp))
              .background(colors.surfaceElevated)
              .border(1.dp, colors.borderSubtle, RoundedCornerShape(10.dp))
              .clickable { menuExpanded = true }
              .padding(horizontal = 10.dp, vertical = 6.dp)
              .testTag("unit_picker_${label.lowercase()}"),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = "${selectedUnit.symbol} · ${selectedUnit.name}",
            style = MaterialTheme.typography.labelLarge,
            color = colors.textPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          Spacer(modifier = Modifier.width(4.dp))
          Icon(
            imageVector = Icons.Rounded.KeyboardArrowDown,
            contentDescription = null,
            tint = colors.lavender,
            modifier = Modifier.size(18.dp),
          )
        }

        DropdownMenu(
          expanded = menuExpanded,
          onDismissRequest = { menuExpanded = false },
          containerColor = colors.surfaceElevated,
        ) {
          units.forEach { unit ->
            DropdownMenuItem(
              text = {
                Text(
                  text = "${unit.name} (${unit.symbol})",
                  color = if (unit.id == selectedUnit.id) colors.lavender else colors.textPrimary,
                )
              },
              onClick = {
                onSelectUnit(unit)
                menuExpanded = false
              },
            )
          }
        }
      }

      IconButton(
        onClick = onTrailingAction,
        modifier = Modifier.size(36.dp),
      ) {
        Icon(
          imageVector = if (isInput) Icons.Outlined.Clear else Icons.Outlined.ContentCopy,
          contentDescription =
            stringResource(if (isInput) R.string.cd_clear_input else R.string.cd_copy_result),
          tint = colors.textSecondary,
          modifier = Modifier.size(18.dp),
        )
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    Text(
      text = valueText,
      style =
        TextStyle(
          fontFamily = InterFamily,
          fontSize = if (valueText.length > 14) 24.sp else 30.sp,
          fontWeight = FontWeight.SemiBold,
          color = if (isInput) colors.textPrimary else colors.lavender,
          fontFeatureSettings = "tnum",
        ),
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
      modifier = Modifier.fillMaxWidth().testTag("converter_${label.lowercase()}_value"),
    )
  }
}

@Composable
private fun ConverterKeypad(
  allowSign: Boolean,
  hapticsEnabled: Boolean,
  onDigit: (String) -> Unit,
  onDecimal: () -> Unit,
  onToggleSign: () -> Unit,
  onBackspace: () -> Unit,
  onClear: () -> Unit,
  onCopy: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val colors = AetherTheme.colors

  Column(
    modifier = modifier,
    verticalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    val rows =
      listOf(
        listOf("7", "8", "9"),
        listOf("4", "5", "6"),
        listOf("1", "2", "3"),
      )

    rows.forEachIndexed { idx, digits ->
      Row(
        modifier = Modifier.weight(1f).fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        digits.forEach { d ->
          TactileKey(
            onClick = { onDigit(d) },
            backgroundColor = colors.surface,
            pressedColor = colors.surfaceElevated,
            hapticsEnabled = hapticsEnabled,
            testTag = "conv_key_$d",
            modifier = Modifier.weight(1f).fillMaxHeight(),
          ) {
            Text(
              text = d,
              style =
                TextStyle(
                  fontFamily = InterFamily,
                  fontSize = 22.sp,
                  fontWeight = FontWeight.Medium,
                  color = colors.textPrimary,
                  fontFeatureSettings = "tnum",
                ),
            )
          }
        }

        // Right column action per row
        when (idx) {
          0 ->
            TactileKey(
              onClick = onBackspace,
              backgroundColor = colors.surfaceElevated,
              pressedColor = colors.surfaceHighest,
              hapticsEnabled = hapticsEnabled,
              testTag = "conv_key_del",
              modifier = Modifier.weight(1f).fillMaxHeight(),
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Outlined.Backspace,
                contentDescription = stringResource(R.string.cd_backspace),
                tint = colors.lavender,
                modifier = Modifier.size(20.dp),
              )
            }
          1 ->
            TactileKey(
              onClick = onClear,
              backgroundColor = colors.surfaceElevated,
              pressedColor = colors.surfaceHighest,
              hapticsEnabled = hapticsEnabled,
              testTag = "conv_key_clear",
              modifier = Modifier.weight(1f).fillMaxHeight(),
            ) {
              Text(
                text = "C",
                style =
                  TextStyle(
                    fontFamily = InterFamily,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.lavender,
                  ),
              )
            }
          else ->
            TactileKey(
              onClick = onCopy,
              backgroundColor = colors.surfaceElevated,
              pressedColor = colors.surfaceHighest,
              hapticsEnabled = hapticsEnabled,
              testTag = "conv_key_copy",
              modifier = Modifier.weight(1f).fillMaxHeight(),
            ) {
              Icon(
                imageVector = Icons.Outlined.ContentCopy,
                contentDescription = stringResource(R.string.cd_copy_result),
                tint = colors.lavender,
                modifier = Modifier.size(20.dp),
              )
            }
        }
      }
    }

    // Bottom row: +/- (or 00) | 0 | . | Swap
    Row(
      modifier = Modifier.weight(1f).fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      TactileKey(
        onClick = if (allowSign) onToggleSign else ({ onDigit("00") }),
        backgroundColor = colors.surface,
        pressedColor = colors.surfaceElevated,
        hapticsEnabled = hapticsEnabled,
        modifier = Modifier.weight(1f).fillMaxHeight(),
      ) {
        Text(
          text = if (allowSign) "+/−" else "00",
          style =
            TextStyle(
              fontFamily = InterFamily,
              fontSize = 18.sp,
              fontWeight = FontWeight.Medium,
              color = colors.textPrimary,
            ),
        )
      }
      TactileKey(
        onClick = { onDigit("0") },
        backgroundColor = colors.surface,
        pressedColor = colors.surfaceElevated,
        hapticsEnabled = hapticsEnabled,
        testTag = "conv_key_0",
        modifier = Modifier.weight(1f).fillMaxHeight(),
      ) {
        Text(
          text = "0",
          style =
            TextStyle(
              fontFamily = InterFamily,
              fontSize = 22.sp,
              fontWeight = FontWeight.Medium,
              color = colors.textPrimary,
              fontFeatureSettings = "tnum",
            ),
        )
      }
      TactileKey(
        onClick = onDecimal,
        backgroundColor = colors.surface,
        pressedColor = colors.surfaceElevated,
        hapticsEnabled = hapticsEnabled,
        testTag = "conv_key_dot",
        modifier = Modifier.weight(1f).fillMaxHeight(),
      ) {
        Text(
          text = ".",
          style =
            TextStyle(
              fontFamily = InterFamily,
              fontSize = 24.sp,
              fontWeight = FontWeight.Medium,
              color = colors.textPrimary,
            ),
        )
      }
      TactileKey(
        onClick = onCopy,
        backgroundColor = colors.accent,
        pressedColor = colors.accentPressed,
        borderColor = colors.accent,
        hapticsEnabled = hapticsEnabled,
        modifier = Modifier.weight(1f).fillMaxHeight(),
      ) {
        Text(
          text = "Copy",
          style = MaterialTheme.typography.labelLarge,
          color = Color(0xFFF1F0F5),
        )
      }
    }
  }
}
