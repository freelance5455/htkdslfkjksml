package com.example.ui.viewmodel

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AdhanAlertType
import com.example.data.model.AdhkarCategory
import com.example.data.model.CityInfo
import com.example.data.model.DhikrItem
import com.example.data.model.IslamicEvent
import com.example.data.model.PrayerDataState
import com.example.data.model.PrayerOffsets
import com.example.data.model.PrayerType
import com.example.data.model.RamadanCountdownState
import com.example.data.model.ReminderTime
import com.example.data.preferences.AppThemeMode
import com.example.data.preferences.PrayerPreferences
import com.example.data.repository.PrayerRepository
import com.example.data.service.AdhanAudioPlayer
import com.example.data.service.OfflinePrayerCalculator
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

enum class AppTab {
    PRAYERS, RAMADAN, ADHKAR, TASBEEH, QIBLA, SETTINGS
}

class PrayerViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = PrayerRepository(application)
    private val preferences = PrayerPreferences(application)

    private val _uiState = MutableStateFlow(PrayerDataState(isLoading = true))
    val uiState: StateFlow<PrayerDataState> = _uiState.asStateFlow()

    private val _currentTab = MutableStateFlow(AppTab.PRAYERS)
    val currentTab: StateFlow<AppTab> = _currentTab.asStateFlow()

    private val _themeMode = MutableStateFlow(preferences.themeMode)
    val themeMode: StateFlow<AppThemeMode> = _themeMode.asStateFlow()

    private val _offsets = MutableStateFlow(preferences.getOffsets())
    val offsets: StateFlow<PrayerOffsets> = _offsets.asStateFlow()

    private val _selectedCity = MutableStateFlow(preferences.selectedCity)
    val selectedCity: StateFlow<String> = _selectedCity.asStateFlow()

    private val _isUsingGps = MutableStateFlow(preferences.isUsingGps)
    val isUsingGps: StateFlow<Boolean> = _isUsingGps.asStateFlow()

    private val _selectedMethodId = MutableStateFlow(preferences.calculationMethodId)
    val selectedMethodId: StateFlow<Int> = _selectedMethodId.asStateFlow()

    // Adhan and Audio Alert State
    private val audioPlayer = AdhanAudioPlayer(application)
    val isAdhanAudioPlaying: StateFlow<Boolean> = audioPlayer.isPlaying
    val currentlyPlayingAdhanKey: StateFlow<String?> = audioPlayer.currentPlayingKey

    private val _selectedAdhanAlert = MutableStateFlow(AdhanAlertType.fromKey(preferences.adhanAlertTypeKey))
    val selectedAdhanAlert: StateFlow<AdhanAlertType> = _selectedAdhanAlert.asStateFlow()

    private val _selectedReminderTime = MutableStateFlow(ReminderTime.fromMinutes(preferences.reminderMinutes))
    val selectedReminderTime: StateFlow<ReminderTime> = _selectedReminderTime.asStateFlow()

    private val _isAdhanNotificationEnabled = MutableStateFlow(preferences.isAdhanNotificationEnabled)
    val isAdhanNotificationEnabled: StateFlow<Boolean> = _isAdhanNotificationEnabled.asStateFlow()

    private val _currentTimeFormatted = MutableStateFlow(getCurrentFormattedTime())
    val currentTimeFormatted: StateFlow<String> = _currentTimeFormatted.asStateFlow()

    // Adhkar State
    private val _selectedAdhkarCategory = MutableStateFlow(AdhkarCategory.MORNING)
    val selectedAdhkarCategory: StateFlow<AdhkarCategory> = _selectedAdhkarCategory.asStateFlow()

    private val _adhkarMap = MutableStateFlow(createDefaultAdhkar())
    val adhkarMap: StateFlow<Map<AdhkarCategory, List<DhikrItem>>> = _adhkarMap.asStateFlow()

    // Tasbeeh State
    private val _tasbeehCount = MutableStateFlow(0)
    val tasbeehCount: StateFlow<Int> = _tasbeehCount.asStateFlow()

    private val _tasbeehTotal = MutableStateFlow(0)
    val tasbeehTotal: StateFlow<Int> = _tasbeehTotal.asStateFlow()

    private val _tasbeehTarget = MutableStateFlow(33)
    val tasbeehTarget: StateFlow<Int> = _tasbeehTarget.asStateFlow()

    val tasbeehPhrases = listOf(
        "سُبْحَانَ اللَّهِ",
        "الْحَمْدُ لِلَّهِ",
        "لَا إِلَهَ إِلَّا اللَّهُ",
        "اللَّهُ أَكْبَرُ",
        "أَسْتَغْفِرُ اللَّهَ",
        "اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ"
    )

    private val _selectedPhraseIndex = MutableStateFlow(0)
    val selectedPhraseIndex: StateFlow<Int> = _selectedPhraseIndex.asStateFlow()

    val currentTasbeehPhrase: String
        get() = tasbeehPhrases.getOrElse(_selectedPhraseIndex.value) { tasbeehPhrases.first() }

    val supportedCities = repository.supportedCities
    val availableMethods = OfflinePrayerCalculator.AVAILABLE_METHODS

    private var countdownJob: Job? = null

    init {
        refreshData()
        startCountdownTicker()
    }

    fun selectTab(tab: AppTab) {
        _currentTab.value = tab
    }

    fun refreshData() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val state = repository.getPrayerData(
                calendar = Calendar.getInstance(),
                offsets = _offsets.value
            )
            _uiState.value = state
        }
    }

    private fun startCountdownTicker() {
        countdownJob?.cancel()
        countdownJob = viewModelScope.launch {
            while (isActive) {
                delay(1000)
                updateCountdown()
            }
        }
    }

    private fun getCurrentFormattedTime(): String {
        val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        return sdf.format(Calendar.getInstance().time)
    }

    private fun updateCountdown() {
        _currentTimeFormatted.value = getCurrentFormattedTime()
        val nowMillis = System.currentTimeMillis()
        val ramadanCountdown = repository.calculateRamadanCountdown(nowMillis)

        val next = _uiState.value.nextPrayer
        if (next == null) {
            _uiState.update { current ->
                current.copy(ramadanCountdown = ramadanCountdown)
            }
            return
        }

        val remainingSeconds = ((next.epochMillis - nowMillis) / 1000).coerceAtLeast(0)

        if (remainingSeconds <= 0) {
            // Recalculate when next prayer time arrives
            refreshData()
            return
        }

        val hours = remainingSeconds / 3600
        val mins = (remainingSeconds % 3600) / 60
        val secs = remainingSeconds % 60
        val formatted = String.format(Locale.US, "%02d:%02d:%02d", hours, mins, secs)

        _uiState.update { current ->
            current.copy(
                countdownFormatted = formatted,
                countdownSecondsRemaining = remainingSeconds,
                ramadanCountdown = ramadanCountdown
            )
        }
    }

    fun setAdhanAlertType(type: AdhanAlertType) {
        _selectedAdhanAlert.value = type
    }

    fun setReminderTime(time: ReminderTime) {
        _selectedReminderTime.value = time
    }

    fun setAdhanNotificationEnabled(enabled: Boolean) {
        _isAdhanNotificationEnabled.value = enabled
    }

    fun playAdhanPreview(alertType: AdhanAlertType) {
        audioPlayer.playPreview(alertType)
    }

    fun stopAdhanPreview() {
        audioPlayer.stop()
    }

    fun saveAdhanSettings() {
        preferences.adhanAlertTypeKey = _selectedAdhanAlert.value.key
        preferences.reminderMinutes = _selectedReminderTime.value.minutes
        preferences.isAdhanNotificationEnabled = _isAdhanNotificationEnabled.value
    }

    override fun onCleared() {
        super.onCleared()
        audioPlayer.stop()
    }

    fun adjustOffset(type: PrayerType, delta: Int) {
        val currentOffset = _offsets.value.getOffset(type)
        val newOffset = currentOffset + delta
        val updatedOffsets = _offsets.value.withOffset(type, newOffset)
        _offsets.value = updatedOffsets
        preferences.saveOffset(type, newOffset)
        refreshData()
    }

    fun selectCity(cityName: String) {
        _selectedCity.value = cityName
        preferences.selectedCity = cityName
        _isUsingGps.value = false
        preferences.isUsingGps = false
        preferences.gpsCityName = ""
        refreshData()
    }

    fun selectCalculationMethod(methodId: Int) {
        _selectedMethodId.value = methodId
        preferences.calculationMethodId = methodId
        refreshData()
    }

    fun setTheme(theme: AppThemeMode) {
        _themeMode.value = theme
        preferences.themeMode = theme
    }

    @SuppressLint("MissingPermission")
    fun requestGpsLocation() {
        val context = getApplication<Application>()
        try {
            val fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)
            val cancellationTokenSource = CancellationTokenSource()

            fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, cancellationTokenSource.token)
                .addOnSuccessListener { loc ->
                    if (loc != null) {
                        applyLocation(loc)
                    } else {
                        fusedLocationClient.lastLocation.addOnSuccessListener { lastLoc ->
                            if (lastLoc != null) {
                                applyLocation(lastLoc)
                            } else {
                                fallbackToLegacyLocation(context)
                            }
                        }.addOnFailureListener {
                            fallbackToLegacyLocation(context)
                        }
                    }
                }
                .addOnFailureListener {
                    fallbackToLegacyLocation(context)
                }
        } catch (e: Exception) {
            fallbackToLegacyLocation(context)
        }
    }

    @SuppressLint("MissingPermission")
    private fun fallbackToLegacyLocation(context: Context) {
        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        if (locationManager == null) {
            refreshData()
            return
        }

        try {
            val isGpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
            val isNetworkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)

            val provider = when {
                isGpsEnabled -> LocationManager.GPS_PROVIDER
                isNetworkEnabled -> LocationManager.NETWORK_PROVIDER
                else -> null
            }

            if (provider != null) {
                val lastKnown = locationManager.getLastKnownLocation(provider)
                if (lastKnown != null) {
                    applyLocation(lastKnown)
                } else {
                    locationManager.requestSingleUpdate(
                        provider,
                        object : LocationListener {
                            override fun onLocationChanged(loc: Location) {
                                applyLocation(loc)
                            }
                            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                            override fun onProviderEnabled(provider: String) {}
                            override fun onProviderDisabled(provider: String) {}
                        },
                        null
                    )
                }
            } else {
                refreshData()
            }
        } catch (e: SecurityException) {
            refreshData()
        }
    }

    private fun applyLocation(location: Location) {
        preferences.isUsingGps = true
        preferences.gpsLatitude = location.latitude
        preferences.gpsLongitude = location.longitude
        _isUsingGps.value = true

        val context = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            var detectedCity = ""
            try {
                val geocoder = Geocoder(context, Locale("ar"))
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    geocoder.getFromLocation(location.latitude, location.longitude, 1) { addresses ->
                        val address = addresses.firstOrNull()
                        val cityName = address?.locality ?: address?.subAdminArea ?: address?.adminArea
                        val countryName = address?.countryName
                        if (!cityName.isNullOrBlank()) {
                            detectedCity = if (!countryName.isNullOrBlank()) "$cityName، $countryName" else cityName
                        } else {
                            val nearest = repository.findNearestCity(location.latitude, location.longitude)
                            detectedCity = "${nearest.nameAr}، ${nearest.countryAr}"
                        }
                        preferences.gpsCityName = detectedCity
                        refreshData()
                    }
                    return@launch
                } else {
                    @Suppress("DEPRECATION")
                    val addresses = geocoder.getFromLocation(location.latitude, location.longitude, 1)
                    val address = addresses?.firstOrNull()
                    val cityName = address?.locality ?: address?.subAdminArea ?: address?.adminArea
                    val countryName = address?.countryName
                    if (!cityName.isNullOrBlank()) {
                        detectedCity = if (!countryName.isNullOrBlank()) "$cityName، $countryName" else cityName
                    }
                }
            } catch (e: Exception) {
                // Ignore geocoding failure and fallback
            }

            if (detectedCity.isBlank()) {
                val nearest = repository.findNearestCity(location.latitude, location.longitude)
                detectedCity = "${nearest.nameAr}، ${nearest.countryAr}"
            }
            preferences.gpsCityName = detectedCity
            refreshData()
        }
    }

    // Adhkar functions
    fun selectAdhkarCategory(category: AdhkarCategory) {
        _selectedAdhkarCategory.value = category
    }

    fun decrementDhikr(id: Int) {
        val currentCategory = _selectedAdhkarCategory.value
        _adhkarMap.update { map ->
            val list = map[currentCategory] ?: return@update map
            val updated = list.map { item ->
                if (item.id == id && item.remainingCount > 0) {
                    item.copy(remainingCount = item.remainingCount - 1)
                } else {
                    item
                }
            }
            map + (currentCategory to updated)
        }
    }

    fun resetAdhkarCategory(category: AdhkarCategory) {
        val defaults = createDefaultAdhkar()[category] ?: return
        _adhkarMap.update { map ->
            map + (category to defaults)
        }
    }

    // Tasbeeh functions
    fun incrementTasbeeh() {
        _tasbeehCount.update { it + 1 }
        _tasbeehTotal.update { it + 1 }
    }

    fun resetTasbeeh() {
        _tasbeehCount.value = 0
    }

    fun selectTasbeehPhrase(index: Int) {
        _selectedPhraseIndex.value = index
        _tasbeehCount.value = 0
    }

    companion object {
        fun createDefaultAdhkar(): Map<AdhkarCategory, List<DhikrItem>> {
            return mapOf(
                AdhkarCategory.MORNING to listOf(
                    DhikrItem(1, AdhkarCategory.MORNING, "أَصْبَحْنَا وَأَصْبَحَ المُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ لا إِلَهَ إِلا اللَّهُ وَحْدَهُ لا شَرِيكَ لَهُ، لَهُ المُلْكُ وَلَهُ الحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ.", 1, 1),
                    DhikrItem(2, AdhkarCategory.MORNING, "آيَةُ الْكُرْسِيِّ: اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ لَّهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ...", 1, 1),
                    DhikrItem(3, AdhkarCategory.MORNING, "قُلْ هُوَ اللَّهُ أَحَدٌ، وقُلْ أَعُوذُ بِرَبِّ الْفَلَقِ، وقُلْ أَعُوذُ بِرَبِّ النَّاسِ (ثلاث مرات).", 3, 3),
                    DhikrItem(4, AdhkarCategory.MORNING, "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ: عَدَدَ خَلْقِهِ، وَرِضَا نَفْسِهِ، وَزِنَةَ عَرْشِهِ، وَمِدَادَ كَلِمَاتِهِ (ثلاث مرات).", 3, 3),
                    DhikrItem(5, AdhkarCategory.MORNING, "اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ وَإِلَيْكَ النُّشُورُ.", 1, 1),
                    DhikrItem(6, AdhkarCategory.MORNING, "حَسْبِيَ اللَّهُ لَا إِلَهَ إِلَّا هُوَ عَلَيْهِ تَوَكَّلْتُ وَهُوَ رَبُّ الْعَرْشِ الْعَظِيمِ (سبع مرات).", 7, 7),
                    DhikrItem(7, AdhkarCategory.MORNING, "اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ.", 1, 1)
                ),
                AdhkarCategory.EVENING to listOf(
                    DhikrItem(8, AdhkarCategory.EVENING, "أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ لا إِلَهَ إِلا اللَّهُ وَحْدَهُ لا شَرِيكَ لَهُ.", 1, 1),
                    DhikrItem(9, AdhkarCategory.EVENING, "اللَّهُمَّ بكَ أمْسَيْنَا، وبِكَ أصْبَحْنَا، وبِكَ نَحْيَا، وبِكَ نَمُوتُ، وإلَيْكَ المَصِيرُ.", 1, 1),
                    DhikrItem(10, AdhkarCategory.EVENING, "أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ (ثلاث مرات).", 3, 3),
                    DhikrItem(11, AdhkarCategory.EVENING, "أَمْسَيْنَا عَلَى فِطْرَةِ الإِسْلامِ، وَعَلَى كَلِمَةِ الإِخْلاصِ، وَعَلَى دِينِ نَبِيِّنَا مُحَمَّدٍ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ.", 1, 1),
                    DhikrItem(12, AdhkarCategory.EVENING, "اللَّهُمَّ مَا أَمْسَى بِي مِنْ نِعْمَةٍ أَوْ بِأَحَدٍ مِنْ خَلْقِكَ فَمِنْكَ وَحْدَكَ لَا شَرِيكَ لَكَ، فَلَكَ الْحَمْدُ وَلَكَ الشُّكْرُ.", 1, 1)
                ),
                AdhkarCategory.POST_PRAYER to listOf(
                    DhikrItem(13, AdhkarCategory.POST_PRAYER, "أَسْتَغْفِرُ اللَّهَ (ثَلاثاً)، اللَّهُمَّ أَنْتَ السَّلامُ وَمِنْكَ السَّلامُ، تَبَارَكْتَ يَا ذَا الجَلالِ وَالإِكْرَامِ.", 1, 1),
                    DhikrItem(14, AdhkarCategory.POST_PRAYER, "سُبْحَانَ اللَّهِ (33) ، الْحَمْدُ لِلَّهِ (33) ، اللَّهُ أَكْبَرُ (33).", 33, 33),
                    DhikrItem(15, AdhkarCategory.POST_PRAYER, "لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ.", 1, 1),
                    DhikrItem(16, AdhkarCategory.POST_PRAYER, "اللَّهُمَّ لَا مَانِعَ لِمَا أَعْطَيْتَ، وَلَا مُعْطِيَ لِمَا مَنَعْتَ، وَلَا يَنْفَعُ ذَا الْجَدِّ مِنْكَ الْجَدُّ.", 1, 1)
                ),
                AdhkarCategory.SLEEP to listOf(
                    DhikrItem(17, AdhkarCategory.SLEEP, "بِاسْمِكَ رَبِّي وَضَعْتُ جَنْبِي، وَبِكَ أَرْفَعُهُ، إِنْ أَمْسَكْتَ نَفْسِي فَارْحَمْهَا، وَإِنْ أَرْسَلْتَهَا فَاحْفَظْهَا بِمَا تَحْفَظُ بِهِ عِبَادَكَ الصَّالِحِينَ.", 1, 1),
                    DhikrItem(18, AdhkarCategory.SLEEP, "اللَّهُمَّ قِنِي عَذَابَكَ يَوْمَ تَبْعَثُ عِبَادَكَ (ثلاث مرات).", 3, 3),
                    DhikrItem(19, AdhkarCategory.SLEEP, "بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا.", 1, 1),
                    DhikrItem(20, AdhkarCategory.SLEEP, "سُبْحَانَ اللَّهِ (33) وَالْحَمْدُ لِلَّهِ (33) وَاللَّهُ أَكْبَرُ (34).", 34, 34)
                )
            )
        }
    }
}
