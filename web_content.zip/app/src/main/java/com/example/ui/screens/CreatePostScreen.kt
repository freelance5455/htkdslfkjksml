package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Drafts
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Poll
import androidx.compose.material.icons.filled.Preview
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.ArkFeedIds
import com.example.data.model.ArkGroup
import com.example.data.model.ArkPost
import com.example.data.model.PostDraft
import com.example.data.model.UserProfile
import com.example.ui.components.FeedPostCard
import com.example.ui.components.GlowingPillButton
import com.example.ui.components.LiquidGlassCard
import com.example.ui.theme.ArkThemeTokens
import com.example.util.ImageCompressionHelper
import com.example.util.PreparedArkVideo
import com.example.util.rememberDecodedImageBitmap
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CreatePostScreen(
    profile: UserProfile,
    groups: List<ArkGroup>,
    drafts: List<PostDraft>,
    taggableUsers: List<Pair<String, String>> = emptyList(),
    initialDraft: PostDraft? = null,
    isPublishing: Boolean = false,
    onBack: () -> Unit,
    onPublish: (
        postType: String,
        category: String,
        caption: String,
        imagesBase64: List<String>,
        visibility: String,
        selectedGroups: List<ArkGroup>,
        locationLabel: String?,
        altTexts: List<String>,
        taggedUids: List<String>,
        pollQuestion: String?,
        pollOptions: List<String>?,
        videoThumb: String?,
        videoDurationMs: Long,
        videoChunks: List<String>,
        draftIdToDelete: String?
    ) -> Unit,
    onSaveDraft: (
        draftId: String?,
        postType: String,
        category: String,
        caption: String,
        imagesBase64: List<String>,
        visibility: String,
        pollQuestion: String,
        pollOptions: List<String>,
        locationLabel: String,
        altTexts: List<String>
    ) -> Unit,
    onDeleteDraft: (String) -> Unit
) {
    BackHandler(onBack = onBack)
    val colors = ArkThemeTokens.colors
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var activeDraftId by remember { mutableStateOf(initialDraft?.id) }
    var postType by remember { mutableStateOf(initialDraft?.postType ?: "photo") }
    var category by remember { mutableStateOf(initialDraft?.category ?: "Friends") }
    var caption by remember { mutableStateOf(initialDraft?.caption ?: "") }
    var locationLabel by remember { mutableStateOf(initialDraft?.locationLabel ?: "") }
    val selectedImages = remember {
        mutableStateListOf<String>().apply {
            initialDraft?.imageBase64List?.let { addAll(it) }
        }
    }
    val altTexts = remember {
        mutableStateListOf<String>().apply {
            val savedAlts = initialDraft?.altTexts.orEmpty()
            repeat(4) { i -> add(savedAlts.getOrElse(i) { "" }) }
        }
    }
    val selectedTaggedUids = remember { mutableStateListOf<String>() }
    var preparedVideo by remember { mutableStateOf<PreparedArkVideo?>(null) }
    var isProcessingVideo by remember { mutableStateOf(false) }
    var videoError by remember { mutableStateOf<String?>(null) }

    val canGoPublic = profile.ageBracket != "under_13" && !profile.isPrivateAccount
    var visibility by remember {
        mutableStateOf(
            when {
                initialDraft?.visibility == "public" && canGoPublic -> "public"
                initialDraft?.visibility in setOf("group", "followers", "only_me", "friends") -> initialDraft?.visibility ?: "friends"
                else -> "friends"
            }
        )
    }
    val selectedGroupIds = remember { mutableStateListOf<String>() }

    var pollQuestion by remember { mutableStateOf(initialDraft?.pollQuestion ?: "") }
    val pollOptions = remember {
        mutableStateListOf<String>().apply {
            val existing = initialDraft?.pollOptions.orEmpty()
            if (existing.size >= 2) addAll(existing) else addAll(listOf("", ""))
        }
    }
    var previewMode by remember { mutableStateOf(false) }
    var showAltEditor by remember { mutableStateOf(false) }

    val multiImagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(4)
    ) { uris ->
        if (uris.isNotEmpty()) {
            scope.launch {
                val compressed = uris.take(4).mapNotNull { uri ->
                    ImageCompressionHelper.compressUriToBase64(context, uri, maxDim = 480, maxBytes = 42_000)
                }
                selectedImages.clear()
                selectedImages.addAll(compressed.take(4))
                if (compressed.isNotEmpty() && postType == "text") postType = "photo"
            }
        }
    }

    val videoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                isProcessingVideo = true
                videoError = null
                ImageCompressionHelper.extractVideoForArk(context, uri)
                    .onSuccess {
                        preparedVideo = it
                        postType = "video"
                    }
                    .onFailure {
                        videoError = it.message ?: "Could not load video."
                    }
                isProcessingVideo = false
            }
        }
    }

    val parsedHashtags = remember(caption) { ArkFeedIds.extractHashtags(caption) }
    val pickedGroups = groups.filter { selectedGroupIds.contains(it.id) }
    val canSubmit = !isProcessingVideo && !isPublishing && when (postType) {
        "photo" -> selectedImages.isNotEmpty() || caption.trim().isNotBlank()
        "video" -> preparedVideo != null
        "poll" -> pollQuestion.trim().isNotBlank() && pollOptions.count { it.trim().isNotBlank() } >= 2
        "group_memory" -> (selectedImages.isNotEmpty() || caption.trim().isNotBlank()) && pickedGroups.isNotEmpty()
        else -> caption.trim().isNotBlank()
    } && (visibility != "group" || pickedGroups.isNotEmpty())

    Column(modifier = Modifier.fillMaxSize()) {
        Surface(color = colors.surface) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = colors.ink)
                    }
                    Text(
                        if (previewMode) "Preview Post" else "Create Post",
                        style = MaterialTheme.typography.titleLarge,
                        color = colors.ink
                    )
                }
                Row {
                    IconButton(
                        onClick = { previewMode = !previewMode },
                        modifier = Modifier.testTag("toggle_post_preview")
                    ) {
                        Icon(
                            Icons.Default.Preview,
                            contentDescription = "Preview post",
                            tint = if (previewMode) colors.accent else colors.ink
                        )
                    }
                    TextButton(
                        onClick = {
                            onSaveDraft(
                                activeDraftId,
                                postType,
                                category,
                                caption,
                                selectedImages.toList(),
                                visibility,
                                pollQuestion,
                                pollOptions.toList(),
                                locationLabel,
                                altTexts.take(selectedImages.size)
                            )
                        },
                        modifier = Modifier.testTag("save_draft_button")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Draft")
                    }
                }
            }
        }

        if (previewMode) {
            val previewPost = ArkPost(
                id = "preview",
                authorId = profile.userId,
                authorUsername = profile.username,
                authorAvatar = profile.avatarPreset,
                authorAvatarBase64 = profile.avatarImageBase64,
                postType = postType,
                category = category,
                caption = caption,
                hashtags = parsedHashtags,
                locationLabel = locationLabel.trim().takeIf { it.isNotBlank() },
                altTexts = altTexts.take(selectedImages.size),
                approvedTagUids = selectedTaggedUids.toList(),
                imageBase64List = selectedImages.toList(),
                videoThumbnailBase64 = preparedVideo?.thumbnailBase64,
                videoDurationMs = preparedVideo?.durationMs ?: 0L,
                visibility = visibility,
                groupNames = pickedGroups.map { it.name },
                pollQuestion = pollQuestion.takeIf { postType == "poll" },
                pollOptions = pollOptions.filter { it.isNotBlank() }.takeIf { postType == "poll" }
            )
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    FeedPostCard(
                        post = previewPost,
                        currentUserId = profile.userId,
                        myReaction = null,
                        myPollVote = null,
                        isBookmarked = false,
                        onReaction = {},
                        onOpenComments = {},
                        onShare = {},
                        onToggleBookmark = {},
                        onVotePoll = {},
                        onEditCaption = {},
                        onToggleCommentsDisabled = {},
                        onDeletePost = {},
                        onHidePost = {},
                        onMuteAuthor = {},
                        onReportPost = {},
                        onOpenMedia = {}
                    )
                }
                item {
                    GlowingPillButton(
                        text = if (isPublishing) "Publishing..." else "Publish Now",
                        icon = Icons.AutoMirrored.Filled.Send,
                        enabled = canSubmit,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            onPublish(
                                postType,
                                category,
                                caption,
                                selectedImages.toList(),
                                visibility,
                                pickedGroups,
                                locationLabel.trim().takeIf { it.isNotBlank() },
                                altTexts.take(selectedImages.size),
                                selectedTaggedUids.toList(),
                                pollQuestion,
                                pollOptions.toList(),
                                preparedVideo?.thumbnailBase64,
                                preparedVideo?.durationMs ?: 0L,
                                preparedVideo?.chunksBase64 ?: emptyList(),
                                activeDraftId
                            )
                        }
                    )
                }
            }
            return@Column
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (drafts.isNotEmpty()) {
                item {
                    LiquidGlassCard(modifier = Modifier.fillMaxWidth(), accentColor = colors.gold) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Drafts, contentDescription = null, tint = colors.gold)
                            Spacer(Modifier.width(8.dp))
                            Text("Saved Drafts (${drafts.size})", style = MaterialTheme.typography.titleSmall, color = colors.ink)
                        }
                        Spacer(Modifier.height(8.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(drafts, key = { it.id }) { d ->
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = colors.surfaceSecondary,
                                    border = BorderStroke(1.dp, colors.gold.copy(alpha = 0.4f)),
                                    modifier = Modifier.clickable {
                                        activeDraftId = d.id
                                        postType = d.postType
                                        category = d.category
                                        caption = d.caption
                                        locationLabel = d.locationLabel
                                        selectedImages.clear()
                                        selectedImages.addAll(d.imageBase64List)
                                        altTexts.clear()
                                        repeat(4) { i -> altTexts.add(d.altTexts.getOrElse(i) { "" }) }
                                        pollQuestion = d.pollQuestion
                                        pollOptions.clear()
                                        if (d.pollOptions.size >= 2) pollOptions.addAll(d.pollOptions) else pollOptions.addAll(listOf("", ""))
                                    }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            d.caption.ifBlank { d.postType }.take(20),
                                            style = MaterialTheme.typography.labelMedium,
                                            color = colors.ink
                                        )
                                        Spacer(Modifier.width(6.dp))
                                        Icon(
                                            Icons.Default.Delete,
                                            contentDescription = "Delete draft",
                                            tint = colors.coral,
                                            modifier = Modifier.size(16.dp).clickable { onDeleteDraft(d.id) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item {
                LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Post Format", style = MaterialTheme.typography.titleSmall, color = colors.ink)
                    Spacer(Modifier.height(8.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(
                            "photo" to "Photos",
                            "video" to "Video",
                            "text" to "Text",
                            "poll" to "Poll",
                            "group_memory" to "Squad Memory"
                        ).forEach { (key, label) ->
                            FilterChip(
                                selected = postType == key,
                                onClick = {
                                    postType = key
                                    if (key == "group_memory") visibility = "group"
                                },
                                label = { Text(label) }
                            )
                        }
                    }
                }
            }

            item {
                LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = caption,
                        onValueChange = { caption = it.take(600) },
                        label = { Text("Write a caption... (supports #hashtags)") },
                        minLines = 3,
                        maxLines = 5,
                        modifier = Modifier.fillMaxWidth().testTag("create_post_caption_input")
                    )
                    if (parsedHashtags.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            parsedHashtags.forEach { tag ->
                                Surface(shape = RoundedCornerShape(50), color = colors.accentSoft) {
                                    Text(
                                        text = "#$tag",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = colors.accent,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = locationLabel,
                        onValueChange = { locationLabel = it.take(60) },
                        leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null) },
                        label = { Text("Add place label (optional, manual text)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = {
                                multiImagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            },
                            modifier = Modifier.weight(1f).testTag("pick_post_photos_button")
                        ) {
                            Icon(Icons.Default.AddPhotoAlternate, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text("Photos (${selectedImages.size}/4)")
                        }
                        OutlinedButton(
                            enabled = !isProcessingVideo && !isPublishing,
                            onClick = {
                                videoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                            },
                            modifier = Modifier.weight(1f).testTag("pick_post_video_button")
                        ) {
                            Icon(Icons.Default.Videocam, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text(
                                when {
                                    isProcessingVideo -> "Loading..."
                                    preparedVideo != null -> "Video ✓"
                                    else -> "Short Video"
                                }
                            )
                        }
                    }
                    if (isProcessingVideo) {
                        Spacer(Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = colors.accent)
                            Text("Preparing video clip...", style = MaterialTheme.typography.bodySmall, color = colors.ink2)
                        }
                    }
                    if (videoError != null) {
                        Spacer(Modifier.height(6.dp))
                        Text(videoError!!, style = MaterialTheme.typography.bodySmall, color = colors.coral)
                    }
                    if (selectedImages.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            itemsIndexed(selectedImages) { idx, b64 ->
                                val bmp = rememberDecodedImageBitmap(b64)
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Box(modifier = Modifier.size(96.dp).clip(RoundedCornerShape(14.dp))) {
                                        if (bmp != null) {
                                            Image(
                                                bitmap = bmp,
                                                contentDescription = "Selected photo ${idx + 1}",
                                                modifier = Modifier.fillMaxSize(),
                                                contentScale = ContentScale.Crop
                                            )
                                        }
                                        Box(
                                            modifier = Modifier
                                                .align(Alignment.TopEnd)
                                                .padding(4.dp)
                                                .size(22.dp)
                                                .clip(CircleShape)
                                                .background(Color.Black.copy(alpha = 0.65f))
                                                .clickable {
                                                    selectedImages.removeAt(idx)
                                                    if (idx < altTexts.size) {
                                                        altTexts.removeAt(idx)
                                                        altTexts.add("")
                                                    }
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.Close, contentDescription = "Remove photo", tint = Color.White, modifier = Modifier.size(14.dp))
                                        }
                                    }
                                    if (selectedImages.size > 1) {
                                        Row(horizontalArrangement = Arrangement.Center) {
                                            IconButton(
                                                enabled = idx > 0,
                                                onClick = {
                                                    val img = selectedImages.removeAt(idx)
                                                    selectedImages.add(idx - 1, img)
                                                    val alt = altTexts[idx]
                                                    altTexts[idx] = altTexts[idx - 1]
                                                    altTexts[idx - 1] = alt
                                                },
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Move photo left", modifier = Modifier.size(18.dp))
                                            }
                                            IconButton(
                                                enabled = idx < selectedImages.lastIndex,
                                                onClick = {
                                                    val img = selectedImages.removeAt(idx)
                                                    selectedImages.add(idx + 1, img)
                                                    val alt = altTexts[idx]
                                                    altTexts[idx] = altTexts[idx + 1]
                                                    altTexts[idx + 1] = alt
                                                },
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Move photo right", modifier = Modifier.size(18.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        TextButton(onClick = { showAltEditor = !showAltEditor }) {
                            Text(if (showAltEditor) "Hide Alt Text" else "Edit Accessibility Alt Text")
                        }
                        if (showAltEditor) {
                            selectedImages.indices.forEach { idx ->
                                OutlinedTextField(
                                    value = altTexts.getOrElse(idx) { "" },
                                    onValueChange = { v ->
                                        if (idx < altTexts.size) altTexts[idx] = v.take(140)
                                    },
                                    label = { Text("Alt text for photo ${idx + 1}") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
                                )
                            }
                        }
                    }
                    if (preparedVideo != null) {
                        Spacer(Modifier.height(10.dp))
                        val thumbBmp = rememberDecodedImageBitmap(preparedVideo?.thumbnailBase64)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (thumbBmp != null) {
                                Image(
                                    bitmap = thumbBmp,
                                    contentDescription = "Video thumbnail",
                                    modifier = Modifier.size(72.dp).clip(RoundedCornerShape(12.dp)),
                                    contentScale = ContentScale.Crop
                                )
                                Spacer(Modifier.width(10.dp))
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Video Clip Ready", style = MaterialTheme.typography.titleSmall, color = colors.success)
                                Text(
                                    "Duration: ${(preparedVideo!!.durationMs / 1000L).coerceAtLeast(1L)}s • ${preparedVideo!!.chunksBase64.size} chunks",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = colors.ink2
                                )
                            }
                            IconButton(onClick = { preparedVideo = null }) {
                                Icon(Icons.Default.Close, contentDescription = "Remove video", tint = colors.coral)
                            }
                        }
                    }
                }
            }

            if (postType == "poll") {
                item {
                    LiquidGlassCard(modifier = Modifier.fillMaxWidth(), accentColor = colors.accent) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Poll, contentDescription = null, tint = colors.accent)
                            Spacer(Modifier.width(6.dp))
                            Text("Poll Setup", style = MaterialTheme.typography.titleSmall, color = colors.ink)
                        }
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = pollQuestion,
                            onValueChange = { pollQuestion = it.take(200) },
                            label = { Text("Ask a question...") },
                            modifier = Modifier.fillMaxWidth().testTag("poll_question_input")
                        )
                        Spacer(Modifier.height(8.dp))
                        pollOptions.forEachIndexed { idx, opt ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(vertical = 3.dp)
                            ) {
                                OutlinedTextField(
                                    value = opt,
                                    onValueChange = { pollOptions[idx] = it.take(80) },
                                    label = { Text("Option ${idx + 1}") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )
                                if (pollOptions.size > 2) {
                                    IconButton(onClick = { pollOptions.removeAt(idx) }) {
                                        Icon(Icons.Default.Close, contentDescription = "Remove option")
                                    }
                                }
                            }
                        }
                        if (pollOptions.size < 4) {
                            TextButton(onClick = { pollOptions.add("") }) {
                                Icon(Icons.Default.Add, contentDescription = null)
                                Spacer(Modifier.width(4.dp))
                                Text("Add Option")
                            }
                        }
                    }
                }
            }

            if (taggableUsers.isNotEmpty()) {
                item {
                    LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PersonAdd, contentDescription = null, tint = colors.accent)
                            Spacer(Modifier.width(6.dp))
                            Text("Tag People (${selectedTaggedUids.size}/10)", style = MaterialTheme.typography.titleSmall, color = colors.ink)
                        }
                        Spacer(Modifier.height(8.dp))
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            taggableUsers.take(16).forEach { (uid, uname) ->
                                val picked = selectedTaggedUids.contains(uid)
                                FilterChip(
                                    selected = picked,
                                    onClick = {
                                        if (picked) selectedTaggedUids.remove(uid)
                                        else if (selectedTaggedUids.size < 10) selectedTaggedUids.add(uid)
                                    },
                                    label = { Text("@$uname") }
                                )
                            }
                        }
                    }
                }
            }

            item {
                LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Category", style = MaterialTheme.typography.titleSmall, color = colors.ink)
                    Spacer(Modifier.height(8.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        ArkFeedIds.feedCategories.forEach { cat ->
                            FilterChip(
                                selected = category == cat,
                                onClick = { category = cat },
                                label = { Text(cat) }
                            )
                        }
                    }
                }
            }

            item {
                LiquidGlassCard(modifier = Modifier.fillMaxWidth(), accentColor = colors.accent) {
                    Text("Audience & Privacy", style = MaterialTheme.typography.titleSmall, color = colors.ink)
                    Spacer(Modifier.height(8.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(
                            selected = visibility == "only_me",
                            onClick = { visibility = "only_me" },
                            leadingIcon = { Icon(Icons.Default.VisibilityOff, contentDescription = null, modifier = Modifier.size(16.dp)) },
                            label = { Text("Only Me") }
                        )
                        FilterChip(
                            selected = visibility == "friends",
                            onClick = { visibility = "friends" },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp)) },
                            label = { Text("Friends") }
                        )
                        FilterChip(
                            selected = visibility == "followers",
                            onClick = { visibility = "followers" },
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(16.dp)) },
                            label = { Text("Followers") }
                        )
                        FilterChip(
                            selected = visibility == "group",
                            onClick = { visibility = "group" },
                            leadingIcon = { Icon(Icons.Default.Groups, contentDescription = null, modifier = Modifier.size(16.dp)) },
                            label = { Text("Squads") }
                        )
                        FilterChip(
                            selected = visibility == "public",
                            enabled = canGoPublic,
                            onClick = { if (canGoPublic) visibility = "public" },
                            leadingIcon = { Icon(Icons.Default.Public, contentDescription = null, modifier = Modifier.size(16.dp)) },
                            label = { Text("Public") }
                        )
                    }
                    if (!canGoPublic) {
                        Spacer(Modifier.height(6.dp))
                        Text(
                            if (profile.ageBracket == "under_13") {
                                "Child Safety: Under-13 accounts cannot publish Public posts."
                            } else {
                                "Private Account is enabled in Settings. Disable it in Privacy Settings to post Publicly."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.ink2
                        )
                    }

                    if (visibility == "group" || postType == "group_memory") {
                        Spacer(Modifier.height(10.dp))
                        Text("Select Target Squads:", style = MaterialTheme.typography.labelMedium, color = colors.accent)
                        Spacer(Modifier.height(6.dp))
                        if (groups.isEmpty()) {
                            Text("Join or create a squad first.", style = MaterialTheme.typography.bodySmall, color = colors.coral)
                        } else {
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                groups.forEach { grp ->
                                    val chosen = selectedGroupIds.contains(grp.id)
                                    FilterChip(
                                        selected = chosen,
                                        onClick = {
                                            if (chosen) selectedGroupIds.remove(grp.id) else selectedGroupIds.add(grp.id)
                                        },
                                        label = { Text(grp.name) }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item {
                GlowingPillButton(
                    text = if (isPublishing) "Publishing..." else "Publish Post",
                    icon = Icons.AutoMirrored.Filled.Send,
                    enabled = canSubmit,
                    modifier = Modifier.fillMaxWidth().testTag("publish_post_button"),
                    onClick = {
                        onPublish(
                            postType,
                            category,
                            caption,
                            selectedImages.toList(),
                            visibility,
                            pickedGroups,
                            locationLabel.trim().takeIf { it.isNotBlank() },
                            altTexts.take(selectedImages.size),
                            selectedTaggedUids.toList(),
                            pollQuestion,
                            pollOptions.toList(),
                            preparedVideo?.thumbnailBase64,
                            preparedVideo?.durationMs ?: 0L,
                            preparedVideo?.chunksBase64 ?: emptyList(),
                            activeDraftId
                        )
                    }
                )
            }
        }
    }
}
