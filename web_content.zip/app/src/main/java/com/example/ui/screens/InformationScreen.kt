package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Numbers
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.VaultRepository
import com.example.ui.components.SilverButton
import com.example.ui.components.SlantedShape
import com.example.ui.components.TopBarWithClose
import com.example.ui.components.YmTextField
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.BlackCharcoal
import com.example.ui.theme.BlackPure
import com.example.ui.theme.SilverDark
import com.example.ui.theme.SilverLight
import com.example.ui.theme.SilverSurface
import com.example.ui.theme.SilverSurfaceVariant
import kotlinx.coroutines.launch

@Composable
fun InformationScreen(
    repository: VaultRepository,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // Observe next transaction number atomically from DB
    val nextTxNumber by repository.nextTransactionNumber.collectAsState(initial = 1L)

    var name by remember { mutableStateOf("") }
    var age by remember { mutableStateOf("") }
    var place by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var phone1 by remember { mutableStateOf("") }
    var phone2 by remember { mutableStateOf("") }
    var emailPrefix by remember { mutableStateOf("") }

    var lastSavedTx by remember { mutableStateOf<Long?>(null) }
    var isSaving by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SilverLight)
    ) {
        // Mandatory X button at top
        TopBarWithClose(
            title = "Information",
            subtitle = "Encrypted Local Records",
            onCloseClick = onBack
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
            // Transaction Number Header Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(SlantedShape)
                    .background(
                        Brush.verticalGradient(
                            listOf(SilverSurface, SilverSurfaceVariant)
                        )
                    )
                    .border(BorderStroke(1.5.dp, BlackPure), SlantedShape)
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "TRANSACTION NUMBER",
                            style = MaterialTheme.typography.labelSmall,
                            color = SilverDark,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "#$nextTxNumber",
                            style = MaterialTheme.typography.headlineLarge.copy(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 28.sp
                            ),
                            color = BlackPure,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(SlantedShape)
                            .background(BlackPure)
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "AUTO-INCREMENT",
                            style = MaterialTheme.typography.labelSmall,
                            color = SilverLight,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Success Banner if just saved
            if (lastSavedTx != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(SlantedShape)
                        .background(AccentGreen.copy(alpha = 0.12f))
                        .border(BorderStroke(1.5.dp, AccentGreen), SlantedShape)
                        .padding(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Saved",
                            tint = AccentGreen,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Record #$lastSavedTx successfully saved locally!",
                            style = MaterialTheme.typography.titleMedium.copy(fontSize = 14.sp),
                            fontWeight = FontWeight.Bold,
                            color = AccentGreen
                        )
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Input Fields
            InformationTextField(
                label = "Name:",
                value = name,
                onValueChange = { name = it },
                icon = Icons.Default.Person,
                testTag = "input_name"
            )

            Spacer(modifier = Modifier.height(12.dp))

            InformationTextField(
                label = "The age:",
                value = age,
                onValueChange = { age = it },
                icon = Icons.Default.Numbers,
                keyboardType = KeyboardType.Number,
                testTag = "input_age"
            )

            Spacer(modifier = Modifier.height(12.dp))

            InformationTextField(
                label = "The place:",
                value = place,
                onValueChange = { place = it },
                icon = Icons.Default.LocationOn,
                testTag = "input_place"
            )

            Spacer(modifier = Modifier.height(12.dp))

            InformationTextField(
                label = "The address:",
                value = address,
                onValueChange = { address = it },
                icon = Icons.Default.Home,
                singleLine = false,
                testTag = "input_address"
            )

            Spacer(modifier = Modifier.height(12.dp))

            InformationTextField(
                label = "Phone number 1:",
                value = phone1,
                onValueChange = { phone1 = it },
                icon = Icons.Default.Phone,
                keyboardType = KeyboardType.Phone,
                testTag = "input_phone1"
            )

            Spacer(modifier = Modifier.height(12.dp))

            InformationTextField(
                label = "Phone number 2:",
                value = phone2,
                onValueChange = { phone2 = it },
                icon = Icons.Default.Phone,
                keyboardType = KeyboardType.Phone,
                testTag = "input_phone2"
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Email Address Field with auto-displaying @gmail.com
            YmTextField(
                value = emailPrefix,
                onValueChange = { input ->
                    // If user enters or pastes something containing @gmail.com, strip it for clean typing
                    emailPrefix = if (input.endsWith("@gmail.com")) {
                        input.removeSuffix("@gmail.com")
                    } else {
                        input
                    }
                },
                label = "Email address:",
                suffix = {
                    Text(
                        text = "@gmail.com",
                        style = MaterialTheme.typography.bodyLarge,
                        color = BlackPure,
                        fontWeight = FontWeight.Bold
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Email,
                        contentDescription = "Email",
                        tint = BlackPure
                    )
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                testTag = "input_email",
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Save Button
            SilverButton(
                text = if (isSaving) "Saving Record..." else "Save Record",
                icon = Icons.Default.Save,
                isDark = true,
                enabled = !isSaving,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("btn_save_information"),
                onClick = {
                    if (name.isBlank() && place.isBlank() && address.isBlank() && phone1.isBlank() && emailPrefix.isBlank()) {
                        Toast.makeText(context, "Please enter at least one field", Toast.LENGTH_SHORT).show()
                        return@SilverButton
                    }

                    isSaving = true
                    scope.launch {
                        try {
                            val savedRecord = repository.saveInformationRecord(
                                name = name,
                                age = age,
                                place = place,
                                address = address,
                                phone1 = phone1,
                                phone2 = phone2,
                                emailPrefix = emailPrefix
                            )

                            lastSavedTx = savedRecord.transactionNumber

                            // Clear inputs for next record
                            name = ""
                            age = ""
                            place = ""
                            address = ""
                            phone1 = ""
                            phone2 = ""
                            emailPrefix = ""

                            Toast.makeText(
                                context,
                                "Record #${savedRecord.transactionNumber} saved successfully!",
                                Toast.LENGTH_LONG
                            ).show()
                        } catch (e: Exception) {
                            Toast.makeText(context, "Error saving: ${e.message}", Toast.LENGTH_LONG).show()
                        } finally {
                            isSaving = false
                        }
                    }
                }
            )

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun InformationTextField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    icon: ImageVector,
    testTag: String,
    keyboardType: KeyboardType = KeyboardType.Text,
    singleLine: Boolean = true
) {
    YmTextField(
        value = value,
        onValueChange = onValueChange,
        label = label,
        leadingIcon = {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = BlackPure
            )
        },
        singleLine = singleLine,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        testTag = testTag,
        modifier = Modifier.fillMaxWidth()
    )
}
