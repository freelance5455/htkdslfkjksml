package com.example.ui.screens

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.storage.DeviceAndSafStorageAdapter
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CameraCaptureScreen(
    targetFolderPath: String,
    storageAdapter: DeviceAndSafStorageAdapter,
    onMediaSaved: (String) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    var hasCameraPerm by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    var hasMicPerm by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { map ->
        hasCameraPerm = map[Manifest.permission.CAMERA] == true
        hasMicPerm = map[Manifest.permission.RECORD_AUDIO] == true
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPerm) {
            permLauncher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
        }
    }

    var isVideoMode by remember { mutableStateOf(false) }
    var useFrontCamera by remember { mutableStateOf(false) }
    var activeRecording by remember { mutableStateOf<Recording?>(null) }

    val destinationFolder = remember(targetFolderPath) {
        if (targetFolderPath == storageAdapter.workspaceRootPath) {
            val dcim = File(storageAdapter.workspaceRootDir, "DCIM/Camera").apply { mkdirs() }
            "file://${dcim.absolutePath}"
        } else {
            targetFolderPath
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Camera Capture", fontWeight = FontWeight.SemiBold)
                        Text(
                            text = "Saving to: ${destinationFolder.substringAfterLast('/')}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("camera_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        if (!hasCameraPerm) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("Camera access required", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Allow Camera (and Microphone for video audio) to capture photos and videos directly into your selected folder.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(20.dp))
                Button(
                    onClick = {
                        permLauncher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
                    },
                    modifier = Modifier.testTag("camera_grant_button")
                ) {
                    Text("Grant Camera Permission")
                }
            }
            return@Scaffold
        }

        val previewView = remember { PreviewView(context) }
        val imageCapture = remember { ImageCapture.Builder().build() }
        val recorder = remember {
            Recorder.Builder()
                .setQualitySelector(QualitySelector.from(Quality.HD))
                .build()
        }
        val videoCapture = remember { VideoCapture.withOutput(recorder) }

        DisposableEffect(useFrontCamera, lifecycleOwner) {
            val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
            val executor = ContextCompat.getMainExecutor(context)
            val listener = Runnable {
                runCatching {
                    val provider = cameraProviderFuture.get()
                    val preview = Preview.Builder().build().also {
                        it.surfaceProvider = previewView.surfaceProvider
                    }
                    val selector = if (useFrontCamera) {
                        CameraSelector.DEFAULT_FRONT_CAMERA
                    } else {
                        CameraSelector.DEFAULT_BACK_CAMERA
                    }
                    provider.unbindAll()
                    provider.bindToLifecycle(lifecycleOwner, selector, preview, imageCapture, videoCapture)
                }
            }
            cameraProviderFuture.addListener(listener, executor)
            onDispose {
                runCatching { activeRecording?.stop() }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AndroidView(
                factory = { previewView },
                modifier = Modifier.fillMaxSize()
            )

            Surface(
                color = Color.Black.copy(alpha = 0.62f),
                shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(vertical = 18.dp, horizontal = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        FilterChip(
                            selected = !isVideoMode,
                            onClick = { if (activeRecording == null) isVideoMode = false },
                            label = { Text("Photo") },
                            leadingIcon = { Icon(Icons.Filled.CameraAlt, contentDescription = null, modifier = Modifier.size(16.dp)) }
                        )
                        FilterChip(
                            selected = isVideoMode,
                            onClick = { if (activeRecording == null) isVideoMode = true },
                            label = { Text("Video") },
                            leadingIcon = { Icon(Icons.Filled.Videocam, contentDescription = null, modifier = Modifier.size(16.dp)) }
                        )
                    }

                    Spacer(Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Spacer(Modifier.width(48.dp))

                        // Shutter / Record Button
                        IconButton(
                            onClick = {
                                if (!isVideoMode) {
                                    capturePhotoToFolder(
                                        context = context,
                                        imageCapture = imageCapture,
                                        destinationFolder = destinationFolder,
                                        storageAdapter = storageAdapter,
                                        scope = scope,
                                        onSaved = onMediaSaved
                                    )
                                } else {
                                    if (activeRecording != null) {
                                        activeRecording?.stop()
                                        activeRecording = null
                                    } else {
                                        activeRecording = startVideoCaptureToFolder(
                                            context = context,
                                            videoCapture = videoCapture,
                                            hasAudioPerm = hasMicPerm,
                                            destinationFolder = destinationFolder,
                                            storageAdapter = storageAdapter,
                                            scope = scope,
                                            onSaved = { msg ->
                                                activeRecording = null
                                                onMediaSaved(msg)
                                            }
                                        )
                                    }
                                }
                            },
                            modifier = Modifier
                                .size(74.dp)
                                .background(
                                    if (isVideoMode) Color(0xFFEF4444) else Color.White,
                                    CircleShape
                                )
                                .testTag("camera_shutter_button")
                        ) {
                            Icon(
                                imageVector = when {
                                    !isVideoMode -> Icons.Filled.CameraAlt
                                    activeRecording != null -> Icons.Filled.Stop
                                    else -> Icons.Filled.FiberManualRecord
                                },
                                contentDescription = "Capture",
                                tint = if (isVideoMode) Color.White else Color.Black,
                                modifier = Modifier.size(34.dp)
                            )
                        }

                        IconButton(
                            onClick = { useFrontCamera = !useFrontCamera },
                            modifier = Modifier
                                .size(48.dp)
                                .background(Color.White.copy(alpha = 0.2f), CircleShape)
                        ) {
                            Icon(
                                Icons.Filled.Cameraswitch,
                                contentDescription = "Switch camera",
                                tint = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun capturePhotoToFolder(
    context: Context,
    imageCapture: ImageCapture,
    destinationFolder: String,
    storageAdapter: DeviceAndSafStorageAdapter,
    scope: kotlinx.coroutines.CoroutineScope,
    onSaved: (String) -> Unit
) {
    val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    val fileName = "IMG_$stamp.jpg"
    val tempFile = File(context.cacheDir, fileName)
    val outputOptions = ImageCapture.OutputFileOptions.Builder(tempFile).build()

    imageCapture.takePicture(
        outputOptions,
        ContextCompat.getMainExecutor(context),
        object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                scope.launch {
                    val bytes = tempFile.readBytes()
                    tempFile.delete()
                    runCatching {
                        storageAdapter.write(destinationFolder, fileName, bytes, "image/jpeg", overwrite = false)
                    }.onSuccess {
                        onSaved("Saved photo $fileName")
                    }.onFailure { e ->
                        onSaved("Failed saving photo: ${e.localizedMessage}")
                    }
                }
            }

            override fun onError(exception: ImageCaptureException) {
                onSaved("Photo capture error: ${exception.localizedMessage}")
            }
        }
    )
}

@SuppressLint("MissingPermission")
private fun startVideoCaptureToFolder(
    context: Context,
    videoCapture: VideoCapture<Recorder>,
    hasAudioPerm: Boolean,
    destinationFolder: String,
    storageAdapter: DeviceAndSafStorageAdapter,
    scope: kotlinx.coroutines.CoroutineScope,
    onSaved: (String) -> Unit
): Recording {
    val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    val fileName = "VID_$stamp.mp4"
    val tempFile = File(context.cacheDir, fileName)
    val fileOutput = FileOutputOptions.Builder(tempFile).build()

    val pending = videoCapture.output.prepareRecording(context, fileOutput).apply {
        if (hasAudioPerm) withAudioEnabled()
    }
    return pending.start(ContextCompat.getMainExecutor(context)) { event ->
        if (event is VideoRecordEvent.Finalize) {
            if (!event.hasError() && tempFile.exists()) {
                scope.launch {
                    val bytes = tempFile.readBytes()
                    tempFile.delete()
                    runCatching {
                        storageAdapter.write(destinationFolder, fileName, bytes, "video/mp4", overwrite = false)
                    }.onSuccess {
                        onSaved("Saved video $fileName")
                    }.onFailure { e ->
                        onSaved("Failed saving video: ${e.localizedMessage}")
                    }
                }
            } else {
                tempFile.delete()
                onSaved("Video recording stopped (${event.error})")
            }
        }
    }
}
