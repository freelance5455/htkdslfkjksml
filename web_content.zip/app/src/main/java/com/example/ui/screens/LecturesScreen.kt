package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Subject
import com.example.data.model.TopicLecture
import com.example.ui.theme.DopingAmber
import com.example.ui.theme.DopingAmberDark
import com.example.ui.theme.DopingAmberLight
import com.example.ui.theme.DopingGreen
import com.example.ui.theme.DopingPrimary
import com.example.ui.theme.DopingPrimaryContainer
import com.example.ui.theme.DopingPrimaryVariant

@Composable
fun LecturesScreen(
  topics: List<TopicLecture>,
  selectedTopic: TopicLecture?,
  searchQuery: String,
  selectedSubject: Subject?,
  onTopicSelected: (TopicLecture?) -> Unit,
  onSearchQueryChanged: (String) -> Unit,
  onSubjectFilterChanged: (Subject?) -> Unit,
  onToggleComplete: (String) -> Unit,
  onToggleFavorite: (String) -> Unit,
  onStartQuizForTopic: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  if (selectedTopic != null) {
    TopicDetailView(
      topic = selectedTopic,
      onBack = { onTopicSelected(null) },
      onToggleComplete = { onToggleComplete(selectedTopic.id) },
      onToggleFavorite = { onToggleFavorite(selectedTopic.id) },
      onStartQuiz = { onStartQuizForTopic(selectedTopic.id) }
    )
    return
  }

  val filteredTopics = topics.filter { topic ->
    val matchesSubject = selectedSubject == null || topic.subject == selectedSubject
    val matchesSearch = searchQuery.isBlank() ||
      topic.title.contains(searchQuery, ignoreCase = true) ||
      topic.mnemonicCode.contains(searchQuery, ignoreCase = true) ||
      topic.unitTitle.contains(searchQuery, ignoreCase = true)
    matchesSubject && matchesSearch
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .testTag("lectures_screen")
  ) {
    // Search Field
    OutlinedTextField(
      value = searchQuery,
      onValueChange = onSearchQueryChanged,
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 8.dp)
        .testTag("lecture_search_input"),
      placeholder = { Text("Konu, kodlama veya şifre ara (örn: HAMAS, İPMAT)...") },
      leadingIcon = {
        Icon(imageVector = Icons.Default.Search, contentDescription = "Ara", tint = DopingPrimary)
      },
      trailingIcon = {
        if (searchQuery.isNotEmpty()) {
          IconButton(onClick = { onSearchQueryChanged("") }) {
            Icon(imageVector = Icons.Default.Clear, contentDescription = "Temizle")
          }
        }
      },
      shape = RoundedCornerShape(12.dp),
      singleLine = true,
      colors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = DopingPrimary,
        unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
      )
    )

    // Subject Filter Pills
    LazyRow(
      contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      item {
        FilterChip(
          selected = selectedSubject == null,
          onClick = { onSubjectFilterChanged(null) },
          label = { Text("Tüm Dersler") },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = DopingPrimary,
            selectedLabelColor = Color.White
          ),
          modifier = Modifier.testTag("filter_all_subjects")
        )
      }
      items(Subject.values()) { subject ->
        FilterChip(
          selected = selectedSubject == subject,
          onClick = { onSubjectFilterChanged(if (selectedSubject == subject) null else subject) },
          label = { Text("${subject.iconEmoji} ${subject.title}") },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = subject.primaryColor,
            selectedLabelColor = Color.White
          ),
          modifier = Modifier.testTag("filter_subject_${subject.id}")
        )
      }
    }

    // Topics List
    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "${filteredTopics.size} Konu & Hafıza Tekniği",
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontWeight = FontWeight.Bold
          )
        }
      }

      if (filteredTopics.isEmpty()) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Icon(
                imageVector = Icons.Default.Psychology,
                contentDescription = null,
                tint = DopingPrimary,
                modifier = Modifier.size(48.dp)
              )
              Spacer(modifier = Modifier.height(12.dp))
              Text(
                text = "Aradığınız kriterde konu bulunamadı.",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = "Farklı bir arama terimi deneyin veya ders filtresini temizleyin.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }
      } else {
        items(filteredTopics) { topic ->
          TopicItemCard(
            topic = topic,
            onClick = { onTopicSelected(topic) },
            onToggleFavorite = { onToggleFavorite(topic.id) }
          )
        }
      }
    }
  }
}

@Composable
private fun TopicItemCard(
  topic: TopicLecture,
  onClick: () -> Unit,
  onToggleFavorite: () -> Unit
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onClick() }
      .testTag("topic_card_${topic.id}"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            color = topic.subject.primaryColor.copy(alpha = 0.15f),
            shape = RoundedCornerShape(6.dp)
          ) {
            Text(
              text = "${topic.subject.iconEmoji} ${topic.subject.title}",
              color = topic.subject.primaryColor,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
            )
          }

          Spacer(modifier = Modifier.width(8.dp))

          Text(
            text = "• ${topic.durationMinutes} Dk",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        IconButton(
          onClick = onToggleFavorite,
          modifier = Modifier.size(28.dp)
        ) {
          Icon(
            imageVector = if (topic.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
            contentDescription = "Favoriye Ekle",
            tint = if (topic.isFavorite) DopingAmber else MaterialTheme.colorScheme.outline
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = topic.unitTitle,
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      Text(
        text = topic.title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )

      Spacer(modifier = Modifier.height(10.dp))

      // Mnemonic Code Box
      Surface(
        color = Color(0xFFFEF3C7),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = Icons.Default.AutoAwesome,
            contentDescription = null,
            tint = DopingAmberDark,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Column {
            Text(
              text = "HAFIZA ŞİFRESİ",
              fontSize = 9.sp,
              fontWeight = FontWeight.Black,
              color = Color(0xFFB45309)
            )
            Text(
              text = topic.mnemonicCode,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFF92400E)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          if (topic.isCompleted) {
            Icon(
              imageVector = Icons.Default.CheckCircle,
              contentDescription = "Tamamlandı",
              tint = DopingGreen,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "Tamamlandı",
              color = DopingGreen,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold
            )
          } else {
            Icon(
              imageVector = Icons.Default.RadioButtonUnchecked,
              contentDescription = "Çalışılmadı",
              tint = MaterialTheme.colorScheme.outline,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "Henüz Çalışılmadı",
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              fontSize = 11.sp
            )
          }
        }

        Text(
          text = "Konuyu İncele >",
          color = DopingPrimary,
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold
        )
      }
    }
  }
}

@Composable
fun TopicDetailView(
  topic: TopicLecture,
  onBack: () -> Unit,
  onToggleComplete: () -> Unit,
  onToggleFavorite: () -> Unit,
  onStartQuiz: () -> Unit
) {
  BackHandler { onBack() }

  var showFlashcardFlipped by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .testTag("topic_detail_view"),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Header Bar with Back Button
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        IconButton(
          onClick = onBack,
          modifier = Modifier.testTag("topic_detail_back_btn")
        ) {
          Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Geri")
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          IconButton(onClick = onToggleFavorite) {
            Icon(
              imageVector = if (topic.isFavorite) Icons.Default.Star else Icons.Default.StarBorder,
              contentDescription = "Favori",
              tint = if (topic.isFavorite) DopingAmber else MaterialTheme.colorScheme.outline
            )
          }

          Button(
            onClick = onToggleComplete,
            colors = ButtonDefaults.buttonColors(
              containerColor = if (topic.isCompleted) DopingGreen else DopingPrimary
            ),
            shape = RoundedCornerShape(20.dp),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            modifier = Modifier.testTag("toggle_topic_complete_btn")
          ) {
            Icon(
              imageVector = Icons.Default.CheckCircle,
              contentDescription = null,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = if (topic.isCompleted) "Tamamlandı" else "Bitirdim",
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }
    }

    // Title & Unit
    item {
      Column {
        Surface(
          color = topic.subject.primaryColor.copy(alpha = 0.15f),
          shape = RoundedCornerShape(6.dp)
        ) {
          Text(
            text = "${topic.subject.iconEmoji} ${topic.subject.title} • ${topic.unitTitle}",
            color = topic.subject.primaryColor,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
          )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = topic.title,
          style = MaterialTheme.typography.headlineSmall,
          fontWeight = FontWeight.ExtraBold
        )
      }
    }

    // 1. "Görsel Doping Hafıza Kodlaması" HERO CARD
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
      ) {
        Box(
          modifier = Modifier
            .background(
              Brush.linearGradient(
                colors = listOf(
                  Color(0xFF312E81),
                  DopingPrimary,
                  Color(0xFF4338CA)
                )
              )
            )
            .padding(18.dp)
        ) {
          Column(modifier = Modifier.fillMaxWidth()) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Default.Psychology,
                  contentDescription = null,
                  tint = DopingAmberLight,
                  modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "DOPİNG HAFIZA TEKNİĞİ",
                  color = DopingAmberLight,
                  fontWeight = FontWeight.Black,
                  fontSize = 13.sp,
                  letterSpacing = 1.sp
                )
              }
              Surface(
                color = Color.White.copy(alpha = 0.2f),
                shape = RoundedCornerShape(8.dp)
              ) {
                Text(
                  text = "Akılda Kalıcı",
                  color = Color.White,
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Surface(
              color = Color.White,
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                Text(
                  text = "ŞİFRELİ KODLAMA",
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Black,
                  color = DopingPrimary
                )
                Text(
                  text = topic.mnemonicCode,
                  fontSize = 18.sp,
                  fontWeight = FontWeight.Black,
                  color = Color(0xFF1E1B4B)
                )
              }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
              text = "Zihinsel Canlandırma ve Hikaye:",
              color = DopingAmberLight,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = topic.mnemonicStory,
              color = Color.White,
              fontSize = 13.sp,
              lineHeight = 20.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            Surface(
              color = Color.Black.copy(alpha = 0.25f),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                  imageVector = Icons.Default.AutoAwesome,
                  contentDescription = null,
                  tint = DopingAmber,
                  modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = topic.dopingReflex,
                  color = Color.White,
                  fontSize = 12.sp,
                  fontWeight = FontWeight.SemiBold
                )
              }
            }
          }
        }
      }
    }

    // 2. "ÖSYM Ne Sorar? Püf Noktaları"
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "🎯 ÖSYM Sınav Taktikleri",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = DopingPrimary
          )
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = topic.osymTips,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface
          )

          Spacer(modifier = Modifier.height(14.dp))

          Text(
            text = "Kritik Bilgiler & Maddeler:",
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
          )
          Spacer(modifier = Modifier.height(8.dp))

          topic.keyPoints.forEach { point ->
            Row(
              modifier = Modifier.padding(vertical = 4.dp),
              verticalAlignment = Alignment.Top
            ) {
              Text(
                text = "⚡",
                fontSize = 14.sp,
                modifier = Modifier.padding(top = 1.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = point,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }
      }
    }

    // 3. Örnek Soru & Doping Çözümü
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "📝 Model Soru & Doping Çözümü",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = topic.exampleQuestion,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium
          )

          Spacer(modifier = Modifier.height(12.dp))

          Surface(
            color = DopingGreen.copy(alpha = 0.1f),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Text(
                text = "Doping Çözüm Refleksi:",
                color = DopingGreen,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = topic.exampleSolution,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface
              )
            }
          }
        }
      }
    }

    // 4. Action Button: "Bu Konunun Sorularını Çöz"
    item {
      Button(
        onClick = onStartQuiz,
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp)
          .testTag("start_topic_quiz_btn"),
        colors = ButtonDefaults.buttonColors(containerColor = DopingPrimary),
        shape = RoundedCornerShape(14.dp)
      ) {
        Icon(imageVector = Icons.Default.Quiz, contentDescription = null)
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "Bu Konunun Sorularını Çöz",
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold
        )
      }
    }
  }
}
