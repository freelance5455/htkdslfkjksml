package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AssistantState
import com.example.ui.theme.XtraAlertRed
import com.example.ui.theme.XtraCyanGlow
import com.example.ui.theme.XtraCyanPrimary
import com.example.ui.theme.XtraNeonGreen
import com.example.ui.theme.XtraPurpleAccent
import com.example.ui.theme.XtraTextHigh
import com.example.ui.theme.XtraTextMed
import com.example.ui.theme.XtraWarningGold
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun ArcReactorCore(
    state: AssistantState,
    modifier: Modifier = Modifier,
    size: Dp = 220.dp,
    onClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ArcReactorRotation")

    // Outer ring clockwise rotation
    val outerRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "outerRot"
    )

    // Inner ring counter-clockwise rotation
    val innerRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "innerRot"
    )

    // Core pulsing scale
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (state) {
                    AssistantState.LISTENING -> 600
                    AssistantState.THINKING -> 800
                    AssistantState.SPEAKING -> 450
                    AssistantState.EXECUTING -> 500
                    AssistantState.IDLE -> 2000
                },
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    // Dynamic glow color depending on current assistant state
    val coreColor by animateColorAsState(
        targetValue = when (state) {
            AssistantState.IDLE -> XtraCyanPrimary
            AssistantState.LISTENING -> XtraWarningGold
            AssistantState.THINKING -> XtraPurpleAccent
            AssistantState.SPEAKING -> XtraCyanGlow
            AssistantState.EXECUTING -> XtraNeonGreen
        },
        animationSpec = tween(400),
        label = "coreColor"
    )

    val stateText = when (state) {
        AssistantState.IDLE -> "XTRA READY"
        AssistantState.LISTENING -> "LISTENING..."
        AssistantState.THINKING -> "THINKING..."
        AssistantState.SPEAKING -> "SPEAKING"
        AssistantState.EXECUTING -> "EXECUTING..."
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(size)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onClick
                )
                .testTag("arc_reactor_core")
        ) {
            Canvas(modifier = Modifier.size(size)) {
                val center = Offset(this.size.width / 2f, this.size.height / 2f)
                val maxRadius = (this.size.minDimension / 2f) * 0.95f

                // 1. Ambient outer aura
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            coreColor.copy(alpha = 0.25f),
                            coreColor.copy(alpha = 0.05f),
                            Color.Transparent
                        ),
                        center = center,
                        radius = maxRadius * 1.05f
                    ),
                    radius = maxRadius * 1.05f,
                    center = center
                )

                // 2. Outermost static circular HUD guide
                drawCircle(
                    color = coreColor.copy(alpha = 0.2f),
                    radius = maxRadius * 0.98f,
                    center = center,
                    style = Stroke(
                        width = 1.5.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 8f), 0f)
                    )
                )

                // 3. Outer rotating segment ring
                rotate(outerRotation, pivot = center) {
                    val segments = 6
                    val anglePerSegment = 360f / segments
                    for (i in 0 until segments) {
                        drawArc(
                            color = coreColor.copy(alpha = 0.65f),
                            startAngle = i * anglePerSegment,
                            sweepAngle = anglePerSegment * 0.55f,
                            useCenter = false,
                            topLeft = Offset(center.x - maxRadius * 0.88f, center.y - maxRadius * 0.88f),
                            size = androidx.compose.ui.geometry.Size(maxRadius * 1.76f, maxRadius * 1.76f),
                            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                        )

                        // Small tick nodes on segment edge
                        val rad = Math.toRadians((i * anglePerSegment + anglePerSegment * 0.27f).toDouble())
                        val nodeX = center.x + (maxRadius * 0.88f) * cos(rad).toFloat()
                        val nodeY = center.y + (maxRadius * 0.88f) * sin(rad).toFloat()
                        drawCircle(
                            color = Color.White,
                            radius = 2.dp.toPx(),
                            center = Offset(nodeX, nodeY)
                        )
                    }
                }

                // 4. Middle counter-rotating precision ring
                rotate(innerRotation, pivot = center) {
                    val middleRadius = maxRadius * 0.72f
                    drawCircle(
                        color = coreColor.copy(alpha = 0.4f),
                        radius = middleRadius,
                        center = center,
                        style = Stroke(
                            width = 2.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 6f), 0f)
                        )
                    )

                    // Tri-node energy focus anchors
                    for (i in 0 until 3) {
                        val angleDeg = i * 120.0
                        val rad = Math.toRadians(angleDeg)
                        val anchorX = center.x + middleRadius * cos(rad).toFloat()
                        val anchorY = center.y + middleRadius * sin(rad).toFloat()
                        drawCircle(
                            color = coreColor,
                            radius = 4.dp.toPx(),
                            center = Offset(anchorX, anchorY)
                        )
                    }
                }

                // 5. Inner pulsing arc reactor energy core
                val innerRadius = (maxRadius * 0.50f) * pulseScale

                // Gradient plasma fill
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.95f),
                            coreColor,
                            coreColor.copy(alpha = 0.3f),
                            Color.Transparent
                        ),
                        center = center,
                        radius = innerRadius
                    ),
                    radius = innerRadius,
                    center = center
                )

                // Glowing inner core outline
                drawCircle(
                    color = Color.White.copy(alpha = 0.8f),
                    radius = innerRadius * 0.82f,
                    center = center,
                    style = Stroke(width = 2.5.dp.toPx())
                )

                // Core crosshair lines
                drawLine(
                    color = Color.White.copy(alpha = 0.5f),
                    start = Offset(center.x - innerRadius * 0.4f, center.y),
                    end = Offset(center.x + innerRadius * 0.4f, center.y),
                    strokeWidth = 1.5.dp.toPx()
                )
                drawLine(
                    color = Color.White.copy(alpha = 0.5f),
                    start = Offset(center.x, center.y - innerRadius * 0.4f),
                    end = Offset(center.x, center.y + innerRadius * 0.4f),
                    strokeWidth = 1.5.dp.toPx()
                )
            }

            // Central holographic identity label
            Text(
                text = "XTRA",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 2.sp
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // State indicator badge
        Text(
            text = stateText,
            color = coreColor,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.5.sp
        )
    }
}
