package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AestheticBlack
import com.example.ui.theme.BorderGrey
import com.example.ui.theme.DeepPink
import com.example.ui.theme.PastelPinkBg
import com.example.ui.theme.PastelPinkContainer
import com.example.ui.theme.PureWhite
import com.example.ui.theme.TextGrey

@Composable
fun PrivacyPolicyDialog(
    onDismiss: () -> Unit
) {
    val scrollState = rememberScrollState()

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = PureWhite,
        shape = RoundedCornerShape(28.dp),
        modifier = Modifier.testTag("privacy_policy_dialog"),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = DeepPink,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Privacy & Legal Disclaimers",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = AestheticBlack
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = TextGrey)
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(scrollState),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Trust badge banner
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = PastelPinkContainer,
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderGrey),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🔒", fontSize = 22.sp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Your Study Privacy Is 100% Protected",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                color = DeepPink
                            )
                            Text(
                                text = "Zero data harvesting. Offline-first local security architecture.",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                                color = AestheticBlack
                            )
                        }
                    }
                }

                PrivacySection(
                    icon = Icons.Default.Storage,
                    title = "1. Local-Only Storage Guarantee",
                    content = "All your study sessions, subject names, notes, and streak calculations are stored locally on your device in an encrypted Room SQLite database. We never upload your personal study logs to external cloud servers."
                )

                PrivacySection(
                    icon = Icons.Default.Payment,
                    title = "2. Transparent Billing & Payment Verification",
                    content = "The ₹199 VIP Pass provides 60 calendar days of premium features (stickers, reports, soundscapes). Payments are completed via direct UPI transfer. To prevent unauthorized activation and fraud, payments are verified against the bank settlement ledger. Random or fictitious reference submissions are rejected, and legitimate payments are activated securely."
                )

                PrivacySection(
                    icon = Icons.Default.Security,
                    title = "3. Zero Third-Party Tracking",
                    content = "Study Timer does not sell, license, or transmit your information to third-party ad networks or data brokers. You will never see intrusive pop-up ads or tracking trackers within the app."
                )

                PrivacySection(
                    icon = Icons.Default.Lock,
                    title = "4. Device Permissions Disclaimer",
                    content = "Notification permission is requested exclusively to send you scheduled study alarms, break completions, and streak reminders. Vibration is used solely for tactile timer alarms. No access to contacts, location, microphone, or media files is ever required."
                )

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = PastelPinkBg,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Last updated: September 2026. For inquiries or data reset support, contact our student support team anytime.",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                        color = TextGrey,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AestheticBlack,
                    contentColor = PureWhite
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Understood & Agreed 👍", fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
private fun PrivacySection(
    icon: ImageVector,
    title: String,
    content: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(PastelPinkBg)
                .border(1.dp, BorderGrey, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = DeepPink, modifier = Modifier.size(16.dp))
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                color = AestheticBlack
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = content,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, lineHeight = 16.sp),
                color = TextGrey
            )
        }
    }
}
