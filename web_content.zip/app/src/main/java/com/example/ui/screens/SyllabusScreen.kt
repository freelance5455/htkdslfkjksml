package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.Chapter
import com.example.data.Subject
import com.example.ui.ChapterFilter
import com.example.ui.DojoUiState
import com.example.ui.theme.ChakraCyan
import com.example.ui.theme.NarutoFlame
import com.example.ui.theme.NarutoOrange
import com.example.ui.theme.SuccessGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SyllabusScreen(
  uiState: DojoUiState,
  onToggleChapter: (String) -> Unit,
  onAddChapter: (Subject, String) -> Unit,
  onRenameChapter: (String, String) -> Unit,
  onDeleteChapter: (String) -> Unit,
  onSelectSubjectFilter: (Subject?) -> Unit,
  onSelectStatusFilter: (ChapterFilter) -> Unit,
  onSearchQueryChanged: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  var showAddDialog by remember { mutableStateOf(false) }
  var editingChapter by remember { mutableStateOf<Chapter?>(null) }
  var deletingChapter by remember { mutableStateOf<Chapter?>(null) }

  val filteredChapters = uiState.chapters.filter { chapter ->
    val matchesSubject = uiState.selectedSubjectFilter == null || chapter.subject == uiState.selectedSubjectFilter
    val matchesStatus = when (uiState.chapterFilter) {
      ChapterFilter.ALL -> true
      ChapterFilter.COMPLETED -> chapter.isCompleted
      ChapterFilter.PENDING -> !chapter.isCompleted
    }
    val matchesSearch = uiState.syllabusSearchQuery.isBlank() ||
      chapter.title.contains(uiState.syllabusSearchQuery, ignoreCase = true) ||
      chapter.subject.displayName.contains(uiState.syllabusSearchQuery, ignoreCase = true)

    matchesSubject && matchesStatus && matchesSearch
  }

  Box(modifier = modifier.fillMaxSize()) {
    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(bottom = 96.dp)
    ) {
      // Hero Banner with Dojo Scene and Overall Progress
      item {
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
          ),
          elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .height(180.dp)
          ) {
            Image(
              painter = painterResource(id = R.drawable.img_dojo_banner),
              contentDescription = "Study Dojo Academy Banner",
              modifier = Modifier.fillMaxSize(),
              contentScale = ContentScale.Crop
            )

            // Gradient scrim for text readability
            Box(
              modifier = Modifier
                .fillMaxSize()
                .background(
                  Brush.verticalGradient(
                    colors = listOf(
                      Color.Transparent,
                      Color.Black.copy(alpha = 0.85f)
                    )
                  )
                )
            )

            Column(
              modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(16.dp)
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
              ) {
                Column {
                  Text(
                    text = "Kerala DHSE Plus Two",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = ChakraCyan
                  )
                  Text(
                    text = "Computer Science Ninja Mastery",
                    style = MaterialTheme.typography.titleMedium.copy(
                      fontWeight = FontWeight.Black,
                      color = Color.White
                    )
                  )
                }
                Surface(
                  shape = RoundedCornerShape(12.dp),
                  color = NarutoOrange
                ) {
                  Text(
                    text = "${uiState.overallProgressPercent}%",
                    style = MaterialTheme.typography.titleMedium.copy(
                      fontWeight = FontWeight.Black,
                      color = Color.White
                    ),
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                  )
                }
              }

              Spacer(modifier = Modifier.height(8.dp))

              LinearProgressIndicator(
                progress = { uiState.overallProgressPercent / 100f },
                modifier = Modifier
                  .fillMaxWidth()
                  .height(8.dp)
                  .clip(RoundedCornerShape(4.dp)),
                color = NarutoOrange,
                trackColor = Color.White.copy(alpha = 0.3f)
              )
            }
          }
        }
      }

      // Subject Progress Overview Cards
      item {
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
          Text(
            text = "Subject Masteries",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onBackground
          )
          Spacer(modifier = Modifier.height(8.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Subject.entries.forEach { subject ->
              val progress = uiState.getSubjectProgress(subject)
              Card(
                modifier = Modifier
                  .weight(1f)
                  .clickable {
                    if (uiState.selectedSubjectFilter == subject) {
                      onSelectSubjectFilter(null)
                    } else {
                      onSelectSubjectFilter(subject)
                    }
                  },
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                  containerColor = if (uiState.selectedSubjectFilter == subject)
                    subject.color.copy(alpha = 0.2f)
                  else MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
              ) {
                Column(
                  modifier = Modifier.padding(8.dp),
                  horizontalAlignment = Alignment.CenterHorizontally
                ) {
                  Text(
                    text = subject.shortCode,
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Black),
                    color = subject.color
                  )
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(
                    text = "$progress%",
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                  )
                  Spacer(modifier = Modifier.height(4.dp))
                  LinearProgressIndicator(
                    progress = { progress / 100f },
                    modifier = Modifier
                      .fillMaxWidth()
                      .height(4.dp)
                      .clip(RoundedCornerShape(2.dp)),
                    color = subject.color,
                    trackColor = subject.color.copy(alpha = 0.2f)
                  )
                }
              }
            }
          }
        }
      }

      // Filter and Search Bar
      item {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
        ) {
          // Search TextField
          OutlinedTextField(
            value = uiState.syllabusSearchQuery,
            onValueChange = onSearchQueryChanged,
            placeholder = { Text("Search syllabus chapters...") },
            leadingIcon = {
              Icon(
                imageVector = Icons.Default.Search,
                contentDescription = "Search",
                tint = MaterialTheme.colorScheme.onSurfaceVariant
              )
            },
            trailingIcon = {
              if (uiState.syllabusSearchQuery.isNotEmpty()) {
                IconButton(onClick = { onSearchQueryChanged("") }) {
                  Icon(imageVector = Icons.Default.Close, contentDescription = "Clear search")
                }
              }
            },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("syllabus_search_input"),
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = NarutoOrange,
              unfocusedBorderColor = MaterialTheme.colorScheme.outline
            )
          )

          Spacer(modifier = Modifier.height(10.dp))

          // Subject Chips
          LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            item {
              FilterChip(
                selected = uiState.selectedSubjectFilter == null,
                onClick = { onSelectSubjectFilter(null) },
                label = { Text("All Subjects") },
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = NarutoOrange,
                  selectedLabelColor = Color.White
                ),
                modifier = Modifier.testTag("filter_all_subjects")
              )
            }
            items(Subject.entries) { sub ->
              FilterChip(
                selected = uiState.selectedSubjectFilter == sub,
                onClick = { onSelectSubjectFilter(sub) },
                label = { Text(sub.displayName) },
                colors = FilterChipDefaults.filterChipColors(
                  selectedContainerColor = sub.color,
                  selectedLabelColor = Color.White
                ),
                modifier = Modifier.testTag("filter_${sub.name.lowercase()}")
              )
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          // Status Filter Chips (All, Completed, Pending)
          Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            ChapterFilter.entries.forEach { status ->
              FilterChip(
                selected = uiState.chapterFilter == status,
                onClick = { onSelectStatusFilter(status) },
                label = {
                  Text(
                    when (status) {
                      ChapterFilter.ALL -> "All Status"
                      ChapterFilter.COMPLETED -> "Completed"
                      ChapterFilter.PENDING -> "Pending"
                    }
                  )
                },
                modifier = Modifier.testTag("filter_status_${status.name.lowercase()}")
              )
            }
          }
        }
      }

      // Chapters List Section
      item {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Chapters (${filteredChapters.size})",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onBackground
          )
          TextButton(
            onClick = { showAddDialog = true },
            modifier = Modifier.testTag("add_chapter_text_button")
          ) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Add Chapter")
          }
        }
      }

      if (filteredChapters.isEmpty()) {
        item {
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Text("📜", fontSize = 42.sp)
              Spacer(modifier = Modifier.height(12.dp))
              Text(
                text = "No chapters found",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
              )
              Text(
                text = "Try adjusting your search query or subject filters.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }
      } else {
        items(filteredChapters, key = { it.id }) { chapter ->
          ChapterItemCard(
            chapter = chapter,
            onToggle = { onToggleChapter(chapter.id) },
            onEdit = { editingChapter = chapter },
            onDelete = { deletingChapter = chapter }
          )
        }
      }
    }

    // Floating Action Button to Add Chapter
    FloatingActionButton(
      onClick = { showAddDialog = true },
      modifier = Modifier
        .align(Alignment.BottomEnd)
        .padding(bottom = 100.dp, end = 20.dp)
        .testTag("add_chapter_fab"),
      containerColor = NarutoOrange,
      contentColor = Color.White
    ) {
      Icon(Icons.Default.Add, contentDescription = "Add Custom Chapter")
    }
  }

  // Add Chapter Dialog
  if (showAddDialog) {
    AddChapterDialog(
      initialSubject = uiState.selectedSubjectFilter ?: Subject.COMPUTER_SCIENCE,
      onDismiss = { showAddDialog = false },
      onConfirm = { subject, title ->
        onAddChapter(subject, title)
        showAddDialog = false
      }
    )
  }

  // Edit Chapter Dialog
  editingChapter?.let { chapter ->
    RenameChapterDialog(
      chapter = chapter,
      onDismiss = { editingChapter = null },
      onConfirm = { newTitle ->
        onRenameChapter(chapter.id, newTitle)
        editingChapter = null
      }
    )
  }

  // Delete Chapter Confirmation Dialog
  deletingChapter?.let { chapter ->
    AlertDialog(
      onDismissRequest = { deletingChapter = null },
      title = { Text("Delete Chapter?") },
      text = { Text("Are you sure you want to remove \"${chapter.title}\" from your syllabus?") },
      confirmButton = {
        Button(
          onClick = {
            onDeleteChapter(chapter.id)
            deletingChapter = null
          },
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
        ) {
          Text("Delete")
        }
      },
      dismissButton = {
        TextButton(onClick = { deletingChapter = null }) {
          Text("Cancel")
        }
      }
    )
  }
}

@Composable
fun ChapterItemCard(
  chapter: Chapter,
  onToggle: () -> Unit,
  onEdit: () -> Unit,
  onDelete: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 6.dp)
      .testTag("chapter_item_${chapter.id}"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (chapter.isCompleted)
        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
      else MaterialTheme.colorScheme.surface
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = if (chapter.isCompleted) 1.dp else 2.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .clickable { onToggle() }
        .padding(14.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Custom Checkbox
      Box(
        modifier = Modifier
          .size(32.dp)
          .clip(CircleShape)
          .background(
            if (chapter.isCompleted) SuccessGreen
            else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
          )
          .clickable { onToggle() },
        contentAlignment = Alignment.Center
      ) {
        if (chapter.isCompleted) {
          Icon(
            imageVector = Icons.Default.Check,
            contentDescription = "Completed",
            tint = Color.White,
            modifier = Modifier.size(20.dp)
          )
        }
      }

      Spacer(modifier = Modifier.width(14.dp))

      Column(modifier = Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = chapter.subject.color.copy(alpha = 0.15f)
          ) {
            Text(
              text = chapter.subject.displayName,
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = chapter.subject.color,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }

          if (chapter.isCustom) {
            Spacer(modifier = Modifier.width(6.dp))
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = NarutoOrange.copy(alpha = 0.15f)
            ) {
              Text(
                text = "Custom",
                style = MaterialTheme.typography.labelSmall,
                color = NarutoOrange,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
          text = chapter.title,
          style = MaterialTheme.typography.bodyMedium.copy(
            fontWeight = if (chapter.isCompleted) FontWeight.Normal else FontWeight.SemiBold,
            textDecoration = if (chapter.isCompleted) TextDecoration.LineThrough else TextDecoration.None
          ),
          color = if (chapter.isCompleted)
            MaterialTheme.colorScheme.onSurfaceVariant
          else MaterialTheme.colorScheme.onSurface,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis
        )
      }

      // Actions: Edit & Delete
      IconButton(
        onClick = onEdit,
        modifier = Modifier.size(36.dp)
      ) {
        Icon(
          imageVector = Icons.Default.Edit,
          contentDescription = "Rename Chapter",
          tint = MaterialTheme.colorScheme.onSurfaceVariant,
          modifier = Modifier.size(18.dp)
        )
      }

      IconButton(
        onClick = onDelete,
        modifier = Modifier.size(36.dp)
      ) {
        Icon(
          imageVector = Icons.Default.Delete,
          contentDescription = "Delete Chapter",
          tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f),
          modifier = Modifier.size(18.dp)
        )
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddChapterDialog(
  initialSubject: Subject,
  onDismiss: () -> Unit,
  onConfirm: (Subject, String) -> Unit
) {
  var title by remember { mutableStateOf("") }
  var selectedSubject by remember { mutableStateOf(initialSubject) }
  var expanded by remember { mutableStateOf(false) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        text = "Add Syllabus Chapter",
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
      )
    },
    text = {
      Column {
        Text("Select Subject:", style = MaterialTheme.typography.labelMedium)
        Spacer(modifier = Modifier.height(6.dp))

        ExposedDropdownMenuBox(
          expanded = expanded,
          onExpandedChange = { expanded = it }
        ) {
          OutlinedTextField(
            value = selectedSubject.displayName,
            onValueChange = {},
            readOnly = true,
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
              .menuAnchor(MenuAnchorType.PrimaryNotEditable)
              .fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
          )
          ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
          ) {
            Subject.entries.forEach { sub ->
              DropdownMenuItem(
                text = { Text(sub.displayName) },
                onClick = {
                  selectedSubject = sub
                  expanded = false
                }
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text("Chapter Title") },
          placeholder = { Text("e.g., Computer Networks, Integration") },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("add_chapter_title_input"),
          shape = RoundedCornerShape(12.dp)
        )
      }
    },
    confirmButton = {
      Button(
        onClick = { onConfirm(selectedSubject, title) },
        enabled = title.isNotBlank(),
        colors = ButtonDefaults.buttonColors(containerColor = NarutoOrange),
        modifier = Modifier.testTag("confirm_add_chapter_button")
      ) {
        Text("Add to Syllabus")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel")
      }
    }
  )
}

@Composable
fun RenameChapterDialog(
  chapter: Chapter,
  onDismiss: () -> Unit,
  onConfirm: (String) -> Unit
) {
  var title by remember { mutableStateOf(chapter.title) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Rename Chapter") },
    text = {
      OutlinedTextField(
        value = title,
        onValueChange = { title = it },
        label = { Text("Chapter Title") },
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp)
      )
    },
    confirmButton = {
      Button(
        onClick = { onConfirm(title) },
        enabled = title.isNotBlank(),
        colors = ButtonDefaults.buttonColors(containerColor = NarutoOrange)
      ) {
        Text("Save")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel")
      }
    }
  )
}
