package com.example.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SufiLanguage
import com.example.ui.theme.CandleGlow
import com.example.ui.theme.GoldGleam
import com.example.ui.theme.GoldLuster
import com.example.ui.theme.GoldLusterBright
import com.example.ui.theme.GoldLusterDark
import com.example.ui.theme.SufiMaroon
import com.example.ui.theme.SufiMaroonDark
import com.example.ui.theme.SufiMutedText
import com.example.ui.theme.TerracottaBackground
import com.example.ui.theme.TerracottaDark
import com.example.ui.theme.TerracottaWarm
import kotlin.math.PI
import kotlin.math.sin

/**
 * 2D Hand Passing Inscribed Antique Scroll Animation:
 * Sage hand from left gives the scroll, seeker hand from right receives it.
 */
@Composable
fun ParchmentPassingAnimation(
    language: SufiLanguage,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "parchment_passing")

    val passingProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "passingProgress"
    )

    val glowFlicker by infiniteTransition.animateFloat(
        initialValue = 0.75f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowFlicker"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .shadow(14.dp, RoundedCornerShape(26.dp))
            .testTag("parchment_passing_card"),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = TerracottaBackground.copy(alpha = 0.95f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.5.dp, GoldLuster.copy(alpha = 0.75f), RoundedCornerShape(26.dp))
                .padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = if (language == SufiLanguage.MALAYALAM)
                    "സൂഫി ജ്ഞാനത്തിന്റെ ചുരുൾ കൈമാറുന്നു..."
                else
                    "Passing the sacred parchment of wisdom...",
                style = MaterialTheme.typography.labelLarge,
                fontFamily = FontFamily.Serif,
                fontStyle = FontStyle.Italic,
                color = GoldLusterBright,
                fontSize = 15.sp,
                letterSpacing = 1.2.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(TerracottaDark)
                    .border(1.2.dp, GoldLuster.copy(alpha = 0.4f), RoundedCornerShape(18.dp)),
                contentAlignment = Alignment.Center
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(8.dp)
                ) {
                    val w = size.width
                    val h = size.height
                    val p = passingProgress

                    drawRect(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                CandleGlow.copy(alpha = 0.35f * glowFlicker),
                                Color.Transparent
                            ),
                            center = Offset(w * 0.5f, h * 0.5f),
                            radius = w * 0.6f
                        )
                    )

                    val leftHandX = when {
                        p < 0.45f -> -w * 0.15f + (p / 0.45f) * (w * 0.35f)
                        p < 0.75f -> w * 0.20f - ((p - 0.45f) / 0.30f) * (w * 0.08f)
                        else -> w * 0.12f - ((p - 0.75f) / 0.25f) * (w * 0.25f)
                    }

                    val rightHandX = when {
                        p < 0.35f -> w * 1.15f - (p / 0.35f) * (w * 0.20f)
                        p < 0.75f -> w * 0.95f - ((p - 0.35f) / 0.40f) * (w * 0.22f)
                        else -> w * 0.73f + ((p - 0.75f) / 0.25f) * (w * 0.35f)
                    }

                    val scrollCenterX = when {
                        p < 0.45f -> leftHandX + w * 0.18f
                        p < 0.75f -> w * 0.38f + ((p - 0.45f) / 0.30f) * (w * 0.24f)
                        else -> rightHandX - w * 0.08f
                    }

                    val scrollCenterY = h * 0.5f + sin(p * 2 * PI.toFloat()) * 6f

                    drawSufiGiverHand(wristX = leftHandX, centerY = h * 0.52f)
                    drawSeekerReceiverHand(wristX = rightHandX, centerY = h * 0.50f)
                    drawAntiqueScroll(centerX = scrollCenterX, centerY = scrollCenterY, progress = p, glowFlicker = glowFlicker)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = if (language == SufiLanguage.MALAYALAM)
                    "ഹൃദയത്തിൽ നിന്നും ഹൃദയത്തിലേക്ക്..."
                else
                    "From heart to heart...",
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Serif,
                color = SufiMutedText,
                fontSize = 13.sp,
                fontStyle = FontStyle.Italic
            )
        }
    }
}

private fun DrawScope.drawSufiGiverHand(wristX: Float, centerY: Float) {
    val skinTone = Color(0xFFD8AB82)
    val skinShadow = Color(0xFFB88559)
    val sleeveColor = SufiMaroon
    val sleeveGold = GoldLusterBright

    val sleevePath = Path().apply {
        moveTo(wristX - 80f, centerY - 45f)
        lineTo(wristX + 10f, centerY - 30f)
        lineTo(wristX + 10f, centerY + 30f)
        lineTo(wristX - 80f, centerY + 45f)
        close()
    }
    drawPath(sleevePath, sleeveColor)

    drawLine(
        color = sleeveGold,
        start = Offset(wristX + 10f, centerY - 30f),
        end = Offset(wristX + 10f, centerY + 30f),
        strokeWidth = 4.dp.toPx(),
        cap = StrokeCap.Round
    )

    val palmX = wristX + 22f
    drawRoundRect(
        color = skinTone,
        topLeft = Offset(palmX, centerY - 18f),
        size = Size(42f, 36f),
        cornerRadius = CornerRadius(8f, 8f)
    )

    for (f in 0..3) {
        val fingerY = centerY - 15f + f * 9f
        val fingerLen = 38f - kotlin.math.abs(f - 1.5f) * 4f
        drawRoundRect(
            color = if (f % 2 == 0) skinTone else skinShadow,
            topLeft = Offset(palmX + 32f, fingerY),
            size = Size(fingerLen, 7.5f),
            cornerRadius = CornerRadius(4f, 4f)
        )
    }

    drawRoundRect(
        color = skinTone,
        topLeft = Offset(palmX + 14f, centerY - 28f),
        size = Size(24f, 8.5f),
        cornerRadius = CornerRadius(4f, 4f)
    )
}

private fun DrawScope.drawSeekerReceiverHand(wristX: Float, centerY: Float) {
    val skinTone = Color(0xFFE2B792)
    val skinShadow = Color(0xFFC4936B)
    val sleeveColor = Color(0xFF38150D)
    val sleeveTrim = GoldLuster

    val sleevePath = Path().apply {
        moveTo(wristX + 80f, centerY - 45f)
        lineTo(wristX - 10f, centerY - 28f)
        lineTo(wristX - 10f, centerY + 28f)
        lineTo(wristX + 80f, centerY + 45f)
        close()
    }
    drawPath(sleevePath, sleeveColor)

    drawLine(
        color = sleeveTrim,
        start = Offset(wristX - 10f, centerY - 28f),
        end = Offset(wristX - 10f, centerY + 28f),
        strokeWidth = 3.5.dp.toPx(),
        cap = StrokeCap.Round
    )

    val palmX = wristX - 45f
    drawRoundRect(
        color = skinTone,
        topLeft = Offset(palmX, centerY - 16f),
        size = Size(40f, 34f),
        cornerRadius = CornerRadius(8f, 8f)
    )

    for (f in 0..3) {
        val fingerY = centerY - 14f + f * 8.5f
        val fingerLen = 36f - kotlin.math.abs(f - 1.5f) * 4f
        drawRoundRect(
            color = if (f % 2 == 0) skinTone else skinShadow,
            topLeft = Offset(palmX - fingerLen + 8f, fingerY),
            size = Size(fingerLen, 7f),
            cornerRadius = CornerRadius(4f, 4f)
        )
    }

    drawRoundRect(
        color = skinTone,
        topLeft = Offset(palmX - 12f, centerY - 24f),
        size = Size(20f, 8f),
        cornerRadius = CornerRadius(4f, 4f)
    )
}

private fun DrawScope.drawAntiqueScroll(
    centerX: Float,
    centerY: Float,
    progress: Float,
    glowFlicker: Float
) {
    val scrollW = 95.dp.toPx()
    val scrollH = 135.dp.toPx()
    val left = centerX - scrollW / 2
    val top = centerY - scrollH / 2
    val tilt = -4f + sin(progress * 2 * PI.toFloat()) * 5f

    rotate(degrees = tilt, pivot = Offset(centerX, centerY)) {
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    CandleGlow.copy(alpha = 0.55f * glowFlicker),
                    GoldLusterBright.copy(alpha = 0.25f * glowFlicker),
                    Color.Transparent
                ),
                center = Offset(centerX, centerY),
                radius = scrollW * 0.95f
            ),
            center = Offset(centerX, centerY),
            radius = scrollW * 0.95f
        )

        drawRoundRect(
            color = Color.Black.copy(alpha = 0.22f),
            topLeft = Offset(left + 5f, top + 6f),
            size = Size(scrollW, scrollH),
            cornerRadius = CornerRadius(12f, 12f)
        )

        drawRoundRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color(0xFFFFF7EB),
                    Color(0xFFF4E5CF),
                    Color(0xFFE5CEAA)
                ),
                startY = top,
                endY = top + scrollH
            ),
            topLeft = Offset(left, top),
            size = Size(scrollW, scrollH),
            cornerRadius = CornerRadius(10f, 10f)
        )

        drawRoundRect(
            color = GoldLuster,
            topLeft = Offset(left + 6f, top + 6f),
            size = Size(scrollW - 12f, scrollH - 12f),
            cornerRadius = CornerRadius(6f, 6f),
            style = Stroke(width = 1.5.dp.toPx())
        )

        val numLines = 6
        for (i in 0 until numLines) {
            val lineY = top + 22f + i * 16f
            val lineStartX = left + 14f
            val lineEndX = left + scrollW - 14f
            val lineWidth = (lineEndX - lineStartX) * (if (i == 0 || i == numLines - 1) 0.65f else 0.92f)

            drawLine(
                color = GoldLuster.copy(alpha = 0.75f),
                start = Offset(lineStartX, lineY),
                end = Offset(lineStartX + lineWidth, lineY),
                strokeWidth = 2.2.dp.toPx(),
                cap = StrokeCap.Round
            )
            drawLine(
                color = SufiMaroonDark.copy(alpha = 0.65f),
                start = Offset(lineStartX, lineY),
                end = Offset(lineStartX + lineWidth, lineY),
                strokeWidth = 1.2.dp.toPx(),
                cap = StrokeCap.Round
            )
        }

        val sealX = left + scrollW - 20f
        val sealY = top + scrollH - 22f
        drawCircle(color = SufiMaroon, radius = 11.dp.toPx(), center = Offset(sealX, sealY))
        drawCircle(color = GoldLusterBright, radius = 9.dp.toPx(), center = Offset(sealX, sealY), style = Stroke(width = 1.2.dp.toPx()))
        drawCircle(color = GoldLuster, radius = 4.dp.toPx(), center = Offset(sealX, sealY))
    }
}
