package com.example.ui.xp

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

object WindowsXpTheme {
    val TitleBarGradient = Brush.verticalGradient(
        colors = listOf(
            Color(0xFF0058EE),
            Color(0xFF3593FF),
            Color(0xFF288EFF),
            Color(0xFF0055EA)
        )
    )

    val ChromeTabActiveGradient = Brush.verticalGradient(
        colors = listOf(
            Color(0xFFFFFFFF),
            Color(0xFFF0F4F9)
        )
    )

    val ChromeTabInactiveGradient = Brush.verticalGradient(
        colors = listOf(
            Color(0xFFDDE3EA),
            Color(0xFFCED4DA)
        )
    )

    val ChromeToolbarBg = Color(0xFFF1F3F4)
    val ChromeOmniboxBg = Color(0xFFFFFFFF)
    val ChromeBorder = Color(0xFFCBD5E1)

    // Classic Windows XP Colors
    val Background = Color(0xFFECE9D8)
    val Surface = Color(0xFFECE9D8)
    val BorderDark = Color(0xFFACA899)
    val BorderLight = Color(0xFFFFFFFF)
    val BorderShadow = Color(0xFF716F64)
    val TextColor = Color(0xFF000000)
    val TextDisabled = Color(0xFF888888)

    // Selection
    val SelectionBlue = Color(0xFF316AC5)
    val SelectionText = Color(0xFFFFFFFF)

    // Controls
    val AddressBorder = Color(0xFF7F9DB9)
    val ButtonFace = Color(0xFFECE9D8)
    val GreenGo = Color(0xFF2E8B57)
    val GreenGoHover = Color(0xFF3CB371)
    val CloseRed = Color(0xFFE81123)
    val CloseRedHover = Color(0xFFF1404B)

    // Flash Colors
    val FlashRed = Color(0xFFED1C24)
    val FlashRedDark = Color(0xFFB71C1C)
}
