package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.ArkGameType
import com.example.data.model.GameRoom
import com.example.ui.components.GlowingPillButton
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.UserBadgeChip
import com.example.ui.theme.ArkThemeTokens

@Composable
fun GamesZoneScreen(
    publicLobbies: List<GameRoom>,
    myRooms: List<GameRoom>,
    onCreateRoom: (gameType: ArkGameType, isPrivate: Boolean) -> Unit,
    onJoinByCode: (String) -> Unit,
    onJoinRoom: (String) -> Unit,
    onBack: (() -> Unit)? = null
) {
    BackHandler(enabled = onBack != null) { onBack?.invoke() }
    val colors = ArkThemeTokens.colors
    var showJoinCodeDialog by remember { mutableStateOf(false) }
    var roomCodeInput by remember { mutableStateOf("") }
    var selectedGameForCreate by remember { mutableStateOf<ArkGameType?>(null) }
    var createPrivateRoom by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    if (onBack != null) {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                        }
                    }
                    Column {
                        Text("ARK Games Zone", style = MaterialTheme.typography.headlineMedium, color = colors.textPrimary)
                        Text("10 Real-Time Multiplayer Party Games", style = MaterialTheme.typography.bodySmall, color = colors.cyan)
                    }
                }
                OutlinedButton(
                    onClick = { showJoinCodeDialog = true },
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.testTag("games_join_code_button")
                ) {
                    Icon(Icons.Default.Key, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Join Code")
                }
            }
        }

        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(145.dp)
                    .clip(RoundedCornerShape(24.dp))
            ) {
                AsyncImage(
                    model = R.drawable.img_games_banner,
                    contentDescription = "ARK Games Arena",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.Bottom
                ) {
                    Text("Squad Arena Live", style = MaterialTheme.typography.titleLarge, color = colors.textPrimary)
                    Text("Invite friends by 6-digit code or jump into an open room", style = MaterialTheme.typography.bodySmall, color = colors.cyan)
                }
            }
        }

        if (myRooms.isNotEmpty()) {
            item {
                Text("Your Active Rooms", style = MaterialTheme.typography.titleMedium, color = colors.textPrimary)
            }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(myRooms.take(6), key = { it.id }) { room ->
                        val game = ArkGameType.fromId(room.gameType)
                        LiquidGlassCard(
                            modifier = Modifier.width(210.dp),
                            accentColor = colors.emerald,
                            onClick = { onJoinRoom(room.id) }
                        ) {
                            Text(game.title, style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                            Text("Code: ${room.roomCode} • ${room.status.uppercase()}", style = MaterialTheme.typography.labelSmall, color = colors.emerald)
                            Spacer(Modifier.height(6.dp))
                            Text("${room.playerUids.size} players", style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
                        }
                    }
                }
            }
        }

        if (publicLobbies.isNotEmpty()) {
            item {
                Text("Open Public Lobbies", style = MaterialTheme.typography.titleMedium, color = colors.textPrimary)
            }
            items(publicLobbies.take(5), key = { it.id }) { room ->
                val game = ArkGameType.fromId(room.gameType)
                LiquidGlassCard(modifier = Modifier.fillMaxWidth(), accentColor = colors.cyan) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("${game.title} • #${room.roomCode}", style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                            Text("Host: @${room.hostUsername} • ${room.playerUids.size} players", style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
                        }
                        GlowingPillButton(text = "Join", onClick = { onJoinRoom(room.id) })
                    }
                }
            }
        }

        item {
            Text("All 10 Multiplayer Games", style = MaterialTheme.typography.titleLarge, color = colors.textPrimary)
        }

        items(ArkGameType.entries, key = { it.id }) { game ->
            val accent = when (game.ordinal % 4) {
                0 -> colors.cyan
                1 -> colors.violet
                2 -> colors.coral
                else -> colors.emerald
            }
            LiquidGlassCard(
                modifier = Modifier.fillMaxWidth().testTag("game_card_${game.id}"),
                accentColor = accent,
                onClick = { selectedGameForCreate = game }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.SportsEsports, contentDescription = null, tint = accent)
                            Spacer(Modifier.width(8.dp))
                            Text(game.title, style = MaterialTheme.typography.titleMedium, color = colors.textPrimary)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(game.tagline, style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            UserBadgeChip(label = "${game.maxRounds} Rounds", accent = accent)
                            UserBadgeChip(label = "Min ${game.minPlayers}P", accent = colors.gold)
                        }
                    }
                    Spacer(Modifier.width(8.dp))
                    GlowingPillButton(
                        text = "Host",
                        icon = Icons.Default.PlayArrow,
                        accent = accent,
                        onClick = { selectedGameForCreate = game }
                    )
                }
            }
        }

        item { Spacer(Modifier.height(16.dp)) }
    }

    if (selectedGameForCreate != null) {
        val game = selectedGameForCreate!!
        AlertDialog(
            onDismissRequest = { selectedGameForCreate = null },
            title = { Text("Host ${game.title}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(game.rules, style = MaterialTheme.typography.bodyMedium)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (createPrivateRoom) Icons.Default.Lock else Icons.Default.Public, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text(if (createPrivateRoom) "Private Room (Invite Code)" else "Public Lobby")
                        }
                        Switch(checked = createPrivateRoom, onCheckedChange = { createPrivateRoom = it })
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onCreateRoom(game, createPrivateRoom)
                        selectedGameForCreate = null
                    }
                ) { Text("Create Lobby") }
            },
            dismissButton = {
                TextButton(onClick = { selectedGameForCreate = null }) { Text("Cancel") }
            }
        )
    }

    if (showJoinCodeDialog) {
        AlertDialog(
            onDismissRequest = { showJoinCodeDialog = false },
            title = { Text("Join Game Room") },
            text = {
                OutlinedTextField(
                    value = roomCodeInput,
                    onValueChange = { roomCodeInput = it.uppercase().take(10) },
                    label = { Text("6-character Room Code") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("join_room_code_input")
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onJoinByCode(roomCodeInput)
                        roomCodeInput = ""
                        showJoinCodeDialog = false
                    }
                ) { Text("Join Room") }
            },
            dismissButton = {
                TextButton(onClick = { showJoinCodeDialog = false }) { Text("Cancel") }
            }
        )
    }
}
