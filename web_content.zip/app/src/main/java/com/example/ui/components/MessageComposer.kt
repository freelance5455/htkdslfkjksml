package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AddPhotoAlternate
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.DesignSystem
import com.example.core.FlamiStrings
import com.example.ui.theme.LocalFlamiDesign
import com.example.ui.viewmodel.AttachedVideo

@Composable
fun MessageComposer(
    strings: FlamiStrings,
    text: String,
    attachedBitmap: Bitmap?,
    attachedVideo: AttachedVideo?,
    isGenerating: Boolean,
    designSystem: DesignSystem = LocalFlamiDesign.current,
    onTextChange: (String) -> Unit,
    onOpenMediaPicker: () -> Unit,
    onOpenVoiceAssistant: () -> Unit,
    onRemoveImage: () -> Unit,
    onRemoveVideo: () -> Unit,
    onSend: () -> Unit,
    onCancelGeneration: () -> Unit,
    modifier: Modifier = Modifier
) {
    val canSend = text.isNotBlank() || attachedBitmap != null || attachedVideo != null

    val containerShape = when (designSystem) {
        DesignSystem.ANIME_WORLD -> RoundedCornerShape(24.dp)
        DesignSystem.FLAMI_ORIGINAL -> RoundedCornerShape(22.dp)
        DesignSystem.CLASSIC_AI -> RoundedCornerShape(28.dp)
    }

    val containerColor = when (designSystem) {
        DesignSystem.ANIME_WORLD -> MaterialTheme.colorScheme.surface.copy(alpha = 0.72f)
        DesignSystem.FLAMI_ORIGINAL -> MaterialTheme.colorScheme.surface.copy(alpha = 0.96f)
        DesignSystem.CLASSIC_AI -> MaterialTheme.colorScheme.surfaceVariant
    }

    val containerPaddingModifier = modifier
        .fillMaxWidth()
        .padding(horizontal = 12.dp, vertical = 8.dp)

    val borderModifier = when (designSystem) {
        DesignSystem.ANIME_WORLD -> Modifier.border(
            width = 1.dp,
            brush = Brush.horizontalGradient(
                listOf(
                    MaterialTheme.colorScheme.primary.copy(alpha = 0.65f),
                    MaterialTheme.colorScheme.secondary.copy(alpha = 0.65f)
                )
            ),
            shape = containerShape
        )
        DesignSystem.FLAMI_ORIGINAL -> Modifier.border(
            width = 1.dp,
            brush = Brush.horizontalGradient(
                listOf(
                    MaterialTheme.colorScheme.primary.copy(alpha = 0.45f),
                    MaterialTheme.colorScheme.secondary.copy(alpha = 0.45f)
                )
            ),
            shape = containerShape
        )
        DesignSystem.CLASSIC_AI -> Modifier.border(
            width = 1.dp,
            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f),
            shape = containerShape
        )
    }

    Surface(
        color = containerColor,
        tonalElevation = if (designSystem == DesignSystem.CLASSIC_AI) 0.dp else 4.dp,
        shape = containerShape,
        modifier = containerPaddingModifier.then(borderModifier)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(
                    horizontal = if (designSystem == DesignSystem.FLAMI_ORIGINAL) 8.dp else 10.dp,
                    vertical = if (designSystem == DesignSystem.FLAMI_ORIGINAL) 6.dp else 8.dp
                )
        ) {
            if (isGenerating && designSystem == DesignSystem.ANIME_WORLD) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "${strings.generatingLabel} • ${strings.interruptingNotice}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }

            if (attachedBitmap != null) {
                Box(
                    modifier = Modifier
                        .padding(start = 6.dp, bottom = 8.dp)
                        .size(72.dp)
                ) {
                    Image(
                        bitmap = attachedBitmap.asImageBitmap(),
                        contentDescription = strings.imageAttachedLabel,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(68.dp)
                            .clip(RoundedCornerShape(12.dp))
                    )
                    IconButton(
                        onClick = onRemoveImage,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .size(28.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Close,
                                contentDescription = strings.cancel,
                                modifier = Modifier
                                    .padding(3.dp)
                                    .size(16.dp)
                            )
                        }
                    }
                }
            }

            if (attachedVideo != null) {
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.7f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.padding(start = 6.dp, bottom = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Videocam,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = attachedVideo.label,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(
                            onClick = onRemoveVideo,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Close,
                                contentDescription = strings.cancel,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onOpenMediaPicker,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("attach_image_button")
                ) {
                    Icon(
                        imageVector = if (designSystem == DesignSystem.CLASSIC_AI) {
                            Icons.Rounded.Add
                        } else {
                            Icons.Rounded.AddPhotoAlternate
                        },
                        contentDescription = strings.attachImageDesc,
                        tint = if (designSystem == DesignSystem.CLASSIC_AI) {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        } else {
                            MaterialTheme.colorScheme.secondary
                        }
                    )
                }

                // Explicit KeyboardType.Text + Sentences prevents numeric-only keyboard bugs
                OutlinedTextField(
                    value = text,
                    onValueChange = onTextChange,
                    placeholder = {
                        Text(
                            text = strings.inputHint,
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    maxLines = if (designSystem == DesignSystem.FLAMI_ORIGINAL) 4 else 5,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                        capitalization = KeyboardCapitalization.Sentences,
                        autoCorrectEnabled = true,
                        imeAction = ImeAction.Default
                    ),
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent,
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("message_input_field")
                )

                if (!canSend && !isGenerating) {
                    IconButton(
                        onClick = onOpenVoiceAssistant,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("voice_mic_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Mic,
                            contentDescription = strings.voiceAssistantTitle,
                            tint = if (designSystem == DesignSystem.CLASSIC_AI) {
                                MaterialTheme.colorScheme.onSurface
                            } else {
                                MaterialTheme.colorScheme.primary
                            }
                        )
                    }
                }

                if (isGenerating) {
                    Spacer(modifier = Modifier.width(2.dp))
                    IconButton(
                        onClick = onCancelGeneration,
                        colors = IconButtonDefaults.iconButtonColors(
                            containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.16f),
                            contentColor = MaterialTheme.colorScheme.error
                        ),
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("stop_generation_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Stop,
                            contentDescription = strings.stopDesc
                        )
                    }
                }

                if (canSend || isGenerating) {
                    Spacer(modifier = Modifier.width(4.dp))
                    IconButton(
                        onClick = onSend,
                        enabled = canSend,
                        colors = IconButtonDefaults.iconButtonColors(
                            containerColor = if (canSend) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant
                            },
                            contentColor = if (canSend) {
                                MaterialTheme.colorScheme.onPrimary
                            } else {
                                MaterialTheme.colorScheme.onSurfaceVariant
                            }
                        ),
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("send_message_button")
                    ) {
                        Icon(
                            imageVector = if (designSystem == DesignSystem.CLASSIC_AI) {
                                Icons.Rounded.ArrowUpward
                            } else {
                                Icons.AutoMirrored.Rounded.Send
                            },
                            contentDescription = strings.sendDesc
                        )
                    }
                }
            }
        }
    }
}
