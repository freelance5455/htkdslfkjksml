package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.SuggestionChipDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.util.FinancialMath
import com.example.util.ValidationResult
import java.util.Locale

/**
 * Standard financial input field supporting decimal values with real-time validation error/warning feedback.
 */
@Composable
fun FinancialInputField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    placeholder: String = "0.00",
    prefixText: String? = "₹",
    suffixText: String? = null,
    validationResult: ValidationResult = ValidationResult(isValid = true),
    keyboardType: KeyboardType = KeyboardType.Decimal,
    imeAction: ImeAction = ImeAction.Next,
    onImeAction: () -> Unit = {},
    testTag: String = ""
) {
    val isError = !validationResult.isValid
    val hasWarning = validationResult.isValid && validationResult.warningMessage != null

    Column(modifier = modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = value,
            onValueChange = { input ->
                // Allow digits, single decimal dot, commas, backspaces
                val sanitized = input.filter { it.isDigit() || it == '.' || it == ',' }
                // Avoid multiple dots
                val dotCount = sanitized.count { it == '.' }
                if (dotCount <= 1) {
                    onValueChange(sanitized)
                }
            },
            label = { Text(label) },
            placeholder = { Text(placeholder) },
            leadingIcon = prefixText?.let {
                {
                    Text(
                        text = it,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(start = 12.dp, end = 4.dp)
                    )
                }
            },
            trailingIcon = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(end = 4.dp)
                ) {
                    if (suffixText != null) {
                        Text(
                            text = suffixText,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (value.isNotEmpty()) {
                        IconButton(
                            onClick = { onValueChange("") },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Clear,
                                contentDescription = "Clear input",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            },
            isError = isError,
            singleLine = true,
            keyboardOptions = KeyboardOptions(
                keyboardType = keyboardType,
                imeAction = imeAction
            ),
            keyboardActions = KeyboardActions(onDone = { onImeAction() }, onNext = { onImeAction() }),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = if (hasWarning) Color(0xFFF59E0B) else MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = if (hasWarning) Color(0xFFF59E0B) else MaterialTheme.colorScheme.outline
            ),
            modifier = Modifier
                .fillMaxWidth()
                .then(if (testTag.isNotEmpty()) Modifier.testTag(testTag) else Modifier)
        )

        // Error message
        AnimatedVisibility(visible = isError && validationResult.errorMessage != null) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(start = 8.dp, top = 4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ErrorOutline,
                    contentDescription = "Error",
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = validationResult.errorMessage ?: "",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        // Warning message
        AnimatedVisibility(visible = hasWarning && validationResult.warningMessage != null) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(start = 8.dp, top = 4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = "Warning",
                    tint = Color(0xFFD97706),
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = validationResult.warningMessage ?: "",
                    color = Color(0xFFD97706),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

/**
 * Range slider paired with a decimal text field and quick preset chips.
 * Enables both fluid dragging and exact manual decimal entry (e.g. 1.25%).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DecimalSliderField(
    valueText: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    rangeMin: Float = 0.0f,
    rangeMax: Float = 5.0f,
    presets: List<Double> = listOf(0.1, 0.2, 0.5, 1.0, 1.5, 2.0, 3.0),
    suffix: String = "%",
    validationResult: ValidationResult = ValidationResult(isValid = true),
    testTag: String = ""
) {
    val currentVal = valueText.toDoubleOrNull() ?: 0.0
    val sliderVal = currentVal.toFloat().coerceIn(rangeMin, rangeMax)

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
        ),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "$valueText$suffix",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Numerical decimal text input
            FinancialInputField(
                value = valueText,
                onValueChange = onValueChange,
                label = "$label ($suffix)",
                placeholder = "0.00",
                prefixText = null,
                suffixText = suffix,
                validationResult = validationResult,
                testTag = testTag
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Range slider
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = String.format(Locale.US, "%.1f%s", rangeMin, suffix),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Slider(
                    value = sliderVal,
                    onValueChange = { newFloat ->
                        // format with 2 decimals
                        val formatted = String.format(Locale.US, "%.2f", newFloat)
                        onValueChange(formatted)
                    },
                    valueRange = rangeMin..rangeMax,
                    colors = SliderDefaults.colors(
                        thumbColor = MaterialTheme.colorScheme.primary,
                        activeTrackColor = MaterialTheme.colorScheme.primary,
                        inactiveTrackColor = MaterialTheme.colorScheme.surfaceVariant
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 8.dp)
                )
                Text(
                    text = String.format(Locale.US, "%.1f%s", rangeMax, suffix),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Quick preset chips
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.padding(top = 4.dp)
            ) {
                presets.forEach { preset ->
                    val isSelected = Math.abs(currentVal - preset) < 0.001
                    val presetStr = String.format(Locale.US, "%.2f", preset)
                    SuggestionChip(
                        onClick = { onValueChange(presetStr) },
                        label = {
                            Text(
                                text = "$presetStr$suffix",
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = SuggestionChipDefaults.suggestionChipColors(
                            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                            labelColor = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                        ),
                        border = SuggestionChipDefaults.suggestionChipBorder(
                            enabled = true,
                            borderColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                        ),
                        modifier = Modifier.height(28.dp)
                    )
                }
            }
        }
    }
}

/**
 * Profit & Loss badge indicator with distinctive emerald (Profit) or coral red (Loss).
 */
@Composable
fun ProfitLossBadge(
    amount: Double,
    label: String = "Net Profit",
    modifier: Modifier = Modifier
) {
    val isProfit = amount >= 0
    val bgColor = if (isProfit) Color(0xFFE6F4EA) else Color(0xFFFDE8E8)
    val textColor = if (isProfit) Color(0xFF0D652D) else Color(0xFFC5221F)
    val icon = if (isProfit) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward

    Surface(
        shape = RoundedCornerShape(8.dp),
        color = bgColor,
        modifier = modifier
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = if (isProfit) "Profit" else "Loss",
                tint = textColor,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "$label: ${FinancialMath.formatInr(amount)}",
                color = textColor,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

/**
 * Status Chip (COMPLETED, PENDING, CANCELLED)
 */
@Composable
fun TransactionStatusBadge(
    status: String,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor) = when (status.uppercase()) {
        "COMPLETED" -> Color(0xFFE6F4EA) to Color(0xFF137333)
        "PENDING" -> Color(0xFFFEF7E0) to Color(0xFFB06000)
        "CANCELLED" -> Color(0xFFFCE8E6) to Color(0xFFC5221F)
        else -> MaterialTheme.colorScheme.surfaceVariant to MaterialTheme.colorScheme.onSurfaceVariant
    }

    Surface(
        shape = RoundedCornerShape(6.dp),
        color = bgColor,
        modifier = modifier
    ) {
        Text(
            text = status,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}
