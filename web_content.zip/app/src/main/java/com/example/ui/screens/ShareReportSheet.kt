package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.export.PdfAndShareHelper
import com.example.ui.theme.WhatsAppGreen
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShareReportSheet(
    title: String,
    showDetailToggle: Boolean,
    defaultFileName: String,
    buildText: (Boolean) -> String,
    generatePdf: () -> File,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var includeDetails by remember { mutableStateOf(true) }
    var previewText by remember(includeDetails) { mutableStateOf(buildText(includeDetails)) }
    var pendingSaveFile by remember { mutableStateOf<File?>(null) }

    val savePdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        val src = pendingSaveFile
        if (uri != null && src != null) {
            val ok = PdfAndShareHelper.copyPdfToUri(context, src, uri)
            Toast.makeText(
                context,
                if (ok) "PDF محفوظ ہو گئی ✓" else "PDF محفوظ کرنے میں خرابی",
                Toast.LENGTH_SHORT
            ).show()
        }
        pendingSaveFile = null
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.primary
            )

            // Primary WhatsApp Share as PDF File + Export PDF
            Button(
                onClick = {
                    val pdf = generatePdf()
                    PdfAndShareHelper.shareFileToWhatsApp(
                        context = context,
                        file = pdf,
                        mimeType = "application/pdf",
                        captionText = previewText.lineSequence().take(5).joinToString("\n")
                    )
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = WhatsAppGreen,
                    contentColor = Color.White
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("share_whatsapp_pdf_button")
            ) {
                Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("واٹس ایپ پر PDF فائل شیئر کریں · Share PDF to WhatsApp")
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        val pdf = generatePdf()
                        pendingSaveFile = pdf
                        savePdfLauncher.launch(defaultFileName)
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("export_pdf_button")
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("PDF محفوظ کریں")
                }

                OutlinedButton(
                    onClick = {
                        val pdf = generatePdf()
                        PdfAndShareHelper.shareFileSystem(context, pdf, "application/pdf", title)
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("share_pdf_system_button")
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("PDF شیئر…")
                }
            }

            OutlinedButton(
                onClick = {
                    val txtFile = PdfAndShareHelper.writeReportTextFile(
                        context,
                        defaultFileName.removeSuffix(".pdf") + ".txt",
                        previewText
                    )
                    PdfAndShareHelper.shareFileToWhatsApp(
                        context = context,
                        file = txtFile,
                        mimeType = "text/plain"
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("share_whatsapp_txt_button")
            ) {
                Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("واٹس ایپ پر ٹیکسٹ فائل (.txt) شیئر کریں")
            }

            HorizontalDivider()

            if (showDetailToggle) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Checkbox(
                        checked = includeDetails,
                        onCheckedChange = {
                            includeDetails = it
                            previewText = buildText(it)
                        }
                    )
                    Text(
                        text = "ہر طالب علم کی تفصیل شامل کریں",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            OutlinedTextField(
                value = previewText,
                onValueChange = { previewText = it },
                label = { Text("رپورٹ کا خلاصہ (Text Preview)") },
                minLines = 5,
                maxLines = 9,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedButton(
                onClick = {
                    PdfAndShareHelper.copyTextToClipboard(context, "Hifz Report", previewText)
                    Toast.makeText(context, "کاپی ہو گیا ✓", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("copy_report_text_button")
            ) {
                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("متن کاپی کریں · Copy Text")
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}
