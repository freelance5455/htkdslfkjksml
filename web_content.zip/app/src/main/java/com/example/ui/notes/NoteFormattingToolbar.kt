package com.example.ui.notes

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckBox
import androidx.compose.material.icons.filled.FormatAlignCenter
import androidx.compose.material.icons.filled.FormatAlignLeft
import androidx.compose.material.icons.filled.FormatAlignRight
import androidx.compose.material.icons.filled.FormatBold
import androidx.compose.material.icons.filled.FormatColorFill
import androidx.compose.material.icons.filled.FormatColorText
import androidx.compose.material.icons.filled.FormatItalic
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.FormatListNumbered
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.FormatStrikethrough
import androidx.compose.material.icons.filled.FormatUnderlined
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.notes.BlockType
import com.example.data.notes.NoteAlignment
import com.example.data.notes.NoteFontFamily

object NoteColorPalette {
    val TEXT_COLORS = listOf(
        Pair("Default", null),
        Pair("Dark", "#1E293B"),
        Pair("Red", "#DC2626"),
        Pair("Blue", "#2563EB"),
        Pair("Green", "#16A34A"),
        Pair("Purple", "#9333EA"),
        Pair("Orange", "#EA580C"),
        Pair("Teal", "#0D9488"),
        Pair("Amber", "#D97706")
    )

    val HIGHLIGHT_COLORS = listOf(
        Pair("None", null),
        Pair("Yellow", "#FEF08A"),
        Pair("Green", "#BBF7D0"),
        Pair("Blue", "#BFDBFE"),
        Pair("Pink", "#FBCFE8"),
        Pair("Orange", "#FED7AA"),
        Pair("Purple", "#E9D5FF")
    )
}

@Composable
fun NoteFormattingToolbar(
    currentFontFamily: String,
    currentFontSize: Int,
    currentAlignment: NoteAlignment,
    activeBlockType: BlockType,
    isBoldActive: Boolean,
    isItalicActive: Boolean,
    isUnderlineActive: Boolean,
    isStrikeActive: Boolean,
    currentTextColor: String?,
    currentHighlightColor: String?,
    canUndo: Boolean,
    canRedo: Boolean,
    onFontFamilySelected: (String) -> Unit,
    onFontSizeChange: (Int) -> Unit,
    onAlignmentSelected: (NoteAlignment) -> Unit,
    onBlockTypeSelected: (BlockType) -> Unit,
    onToggleBold: () -> Unit,
    onToggleItalic: () -> Unit,
    onToggleUnderline: () -> Unit,
    onToggleStrike: () -> Unit,
    onTextColorSelected: (String?) -> Unit,
    onHighlightColorSelected: (String?) -> Unit,
    onUndoClick: () -> Unit,
    onRedoClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showFontMenu by remember { mutableStateOf(false) }
    var showTextColorMenu by remember { mutableStateOf(false) }
    var showHighlightMenu by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            // Row 1: Typography, Font Size, Alignment, Color Pickers
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Font Family Dropdown Button
                Box {
                    val activeFont = NoteFontFamily.fromKey(currentFontFamily)
                    Surface(
                        onClick = { showFontMenu = true },
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surface,
                        tonalElevation = 1.dp,
                        modifier = Modifier.testTag("font_family_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.TextFields,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = activeFont.displayName,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                fontFamily = activeFont.toComposeFontFamily()
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = showFontMenu,
                        onDismissRequest = { showFontMenu = false }
                    ) {
                        NoteFontFamily.entries.forEach { font ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = font.displayName,
                                        fontFamily = font.toComposeFontFamily(),
                                        fontWeight = if (font.key == currentFontFamily) FontWeight.Bold else FontWeight.Normal,
                                        color = if (font.key == currentFontFamily) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                    )
                                },
                                onClick = {
                                    onFontFamilySelected(font.key)
                                    showFontMenu = false
                                }
                            )
                        }
                    }
                }

                // Font Size Adjuster: [-] XXsp [+]
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    IconButton(
                        onClick = { onFontSizeChange(currentFontSize - 2) },
                        enabled = currentFontSize > 10,
                        modifier = Modifier
                            .size(28.dp)
                            .testTag("decrease_font_size_button")
                    ) {
                        Icon(imageVector = Icons.Default.Remove, contentDescription = "Decrease font size", modifier = Modifier.size(14.dp))
                    }

                    Text(
                        text = "${currentFontSize}sp",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )

                    IconButton(
                        onClick = { onFontSizeChange(currentFontSize + 2) },
                        enabled = currentFontSize < 36,
                        modifier = Modifier
                            .size(28.dp)
                            .testTag("increase_font_size_button")
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Increase font size", modifier = Modifier.size(14.dp))
                    }
                }

                // Text Color Picker
                Box {
                    ToolbarIconButton(
                        icon = Icons.Default.FormatColorText,
                        description = "Text Color",
                        isActive = currentTextColor != null,
                        activeTint = currentTextColor?.let { try { Color(android.graphics.Color.parseColor(it)) } catch (_: Exception) { null } } ?: MaterialTheme.colorScheme.primary,
                        onClick = { showTextColorMenu = true }
                    )

                    DropdownMenu(
                        expanded = showTextColorMenu,
                        onDismissRequest = { showTextColorMenu = false }
                    ) {
                        Text(
                            text = "Text Color",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                        NoteColorPalette.TEXT_COLORS.forEach { (name, hex) ->
                            val color = hex?.let { try { Color(android.graphics.Color.parseColor(it)) } catch (_: Exception) { null } } ?: MaterialTheme.colorScheme.onSurface
                            val isSelected = currentTextColor == hex
                            DropdownMenuItem(
                                leadingIcon = {
                                    Box(
                                        modifier = Modifier
                                            .size(18.dp)
                                            .clip(CircleShape)
                                            .background(color)
                                            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), CircleShape)
                                    )
                                },
                                text = {
                                    Text(
                                        text = name,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                trailingIcon = {
                                    if (isSelected) {
                                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                    }
                                },
                                onClick = {
                                    onTextColorSelected(hex)
                                    showTextColorMenu = false
                                }
                            )
                        }
                    }
                }

                // Highlight Color Picker
                Box {
                    ToolbarIconButton(
                        icon = Icons.Default.FormatColorFill,
                        description = "Highlight Color",
                        isActive = currentHighlightColor != null,
                        activeTint = currentHighlightColor?.let { try { Color(android.graphics.Color.parseColor(it)) } catch (_: Exception) { null } } ?: Color(0xFFF59E0B),
                        onClick = { showHighlightMenu = true }
                    )

                    DropdownMenu(
                        expanded = showHighlightMenu,
                        onDismissRequest = { showHighlightMenu = false }
                    ) {
                        Text(
                            text = "Highlight Color",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                        NoteColorPalette.HIGHLIGHT_COLORS.forEach { (name, hex) ->
                            val color = hex?.let { try { Color(android.graphics.Color.parseColor(it)) } catch (_: Exception) { null } } ?: Color.Transparent
                            val isSelected = currentHighlightColor == hex
                            DropdownMenuItem(
                                leadingIcon = {
                                    Box(
                                        modifier = Modifier
                                            .size(18.dp)
                                            .clip(CircleShape)
                                            .background(if (hex == null) MaterialTheme.colorScheme.surfaceVariant else color)
                                            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), CircleShape)
                                    )
                                },
                                text = {
                                    Text(
                                        text = name,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                trailingIcon = {
                                    if (isSelected) {
                                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                    }
                                },
                                onClick = {
                                    onHighlightColorSelected(hex)
                                    showHighlightMenu = false
                                }
                            )
                        }
                    }
                }

                // Alignments
                ToolbarIconButton(
                    icon = Icons.Default.FormatAlignLeft,
                    description = "Align Left",
                    isActive = currentAlignment == NoteAlignment.LEFT,
                    onClick = { onAlignmentSelected(NoteAlignment.LEFT) }
                )
                ToolbarIconButton(
                    icon = Icons.Default.FormatAlignCenter,
                    description = "Align Center",
                    isActive = currentAlignment == NoteAlignment.CENTER,
                    onClick = { onAlignmentSelected(NoteAlignment.CENTER) }
                )
                ToolbarIconButton(
                    icon = Icons.Default.FormatAlignRight,
                    description = "Align Right",
                    isActive = currentAlignment == NoteAlignment.RIGHT,
                    onClick = { onAlignmentSelected(NoteAlignment.RIGHT) }
                )
            }

            Spacer(modifier = Modifier.height(6.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
            Spacer(modifier = Modifier.height(6.dp))

            // Row 2: Inline Styles (B, I, U, S), Block Types (H1, H2, H3, Bullet, Numbered, Checklist), Undo/Redo
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Undo / Redo
                ToolbarIconButton(
                    icon = Icons.AutoMirrored.Filled.Undo,
                    description = "Undo",
                    isEnabled = canUndo,
                    onClick = onUndoClick
                )
                ToolbarIconButton(
                    icon = Icons.AutoMirrored.Filled.Redo,
                    description = "Redo",
                    isEnabled = canRedo,
                    onClick = onRedoClick
                )

                Box(
                    modifier = Modifier
                        .height(20.dp)
                        .width(1.dp)
                        .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                )

                // Inline Styles
                ToolbarIconButton(
                    icon = Icons.Default.FormatBold,
                    description = "Bold",
                    isActive = isBoldActive,
                    onClick = onToggleBold
                )
                ToolbarIconButton(
                    icon = Icons.Default.FormatItalic,
                    description = "Italic",
                    isActive = isItalicActive,
                    onClick = onToggleItalic
                )
                ToolbarIconButton(
                    icon = Icons.Default.FormatUnderlined,
                    description = "Underline",
                    isActive = isUnderlineActive,
                    onClick = onToggleUnderline
                )
                ToolbarIconButton(
                    icon = Icons.Default.FormatStrikethrough,
                    description = "Strikethrough",
                    isActive = isStrikeActive,
                    onClick = onToggleStrike
                )

                Box(
                    modifier = Modifier
                        .height(20.dp)
                        .width(1.dp)
                        .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                )

                // Block Formats: Body, H1, H2, H3, Bullet, Numbered, Checklist
                FormatChip(
                    text = "¶",
                    description = "Normal Paragraph",
                    isActive = activeBlockType == BlockType.PARAGRAPH,
                    onClick = { onBlockTypeSelected(BlockType.PARAGRAPH) }
                )
                FormatChip(
                    text = "H1",
                    description = "Heading 1",
                    isActive = activeBlockType == BlockType.HEADING_1,
                    onClick = { onBlockTypeSelected(BlockType.HEADING_1) }
                )
                FormatChip(
                    text = "H2",
                    description = "Heading 2",
                    isActive = activeBlockType == BlockType.HEADING_2,
                    onClick = { onBlockTypeSelected(BlockType.HEADING_2) }
                )
                FormatChip(
                    text = "H3",
                    description = "Heading 3",
                    isActive = activeBlockType == BlockType.HEADING_3,
                    onClick = { onBlockTypeSelected(BlockType.HEADING_3) }
                )

                ToolbarIconButton(
                    icon = Icons.Default.FormatListBulleted,
                    description = "Bullet List",
                    isActive = activeBlockType == BlockType.BULLET,
                    onClick = { onBlockTypeSelected(BlockType.BULLET) }
                )

                ToolbarIconButton(
                    icon = Icons.Default.FormatListNumbered,
                    description = "Numbered List",
                    isActive = activeBlockType == BlockType.NUMBERED,
                    onClick = { onBlockTypeSelected(BlockType.NUMBERED) }
                )

                ToolbarIconButton(
                    icon = Icons.Default.CheckBox,
                    description = "Checklist",
                    isActive = activeBlockType == BlockType.CHECKLIST,
                    onClick = { onBlockTypeSelected(BlockType.CHECKLIST) }
                )
            }
        }
    }
}

@Composable
private fun ToolbarIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    isActive: Boolean = false,
    isEnabled: Boolean = true,
    activeTint: Color? = null,
    onClick: () -> Unit
) {
    val containerColor = if (isActive) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
    val contentColor = if (isActive) (activeTint ?: MaterialTheme.colorScheme.primary) else MaterialTheme.colorScheme.onSurfaceVariant
    val alpha = if (isEnabled) 1f else 0.35f

    Box(
        modifier = Modifier
            .size(36.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(containerColor.copy(alpha = if (isActive) 1f else 0.8f))
            .clickable(enabled = isEnabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = description,
            tint = contentColor.copy(alpha = alpha),
            modifier = Modifier.size(18.dp)
        )
    }
}

@Composable
private fun FormatChip(
    text: String,
    description: String,
    isActive: Boolean,
    onClick: () -> Unit
) {
    val containerColor = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
    val contentColor = if (isActive) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface

    Box(
        modifier = Modifier
            .height(36.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(containerColor)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = contentColor
        )
    }
}
