package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ScoreGauge(
    score: Int,
    label: String = "",
    size: Int = 90
) {
    val color = when {
        score >= 75 -> Color(0xFF10B981) // Emerald
        score >= 50 -> Color(0xFFFBBF24) // Amber
        else -> Color(0xFFF43F5E)        // Red
    }

    val stroke = if (size > 80) 8f else 6f

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier.size(size.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(size.dp)) {
                val radius = (size.dp.toPx() / 2) - stroke * 2
                drawCircle(
                    color = Color(0xFF1E293B),
                    radius = radius,
                    style = Stroke(width = stroke * 2)
                )
                drawArc(
                    color = color,
                    startAngle = -90f,
                    sweepAngle = (score / 100f) * 360f,
                    useCenter = false,
                    style = Stroke(width = stroke * 2, cap = StrokeCap.Round)
                )
            }
            Text(
                text = score.toString(),
                color = color,
                fontWeight = FontWeight.Bold,
                fontSize = if (size > 80) 20.sp else 14.sp
            )
        }
        if (label.isNotBlank()) {
            Text(
                text = label,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}
