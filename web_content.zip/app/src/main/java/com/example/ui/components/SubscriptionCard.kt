package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.SubscriptionPlan
import com.example.data.model.UserProfile
import com.example.ui.theme.FreshAirGreenSoft
import com.example.ui.theme.LavenderContainer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class SubscribeMethodTab { WEB, VOUCHER, AIRTIME }

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SubscriptionStatusCard(
    profile: UserProfile,
    onOpenSubscribeSheet: () -> Unit,
    modifier: Modifier = Modifier
) {
    val active = profile.hasActiveSubscription
    Card(
        modifier = modifier.fillMaxWidth().testTag("subscription_status_card"),
        colors = CardDefaults.cardColors(
            containerColor = if (active) FreshAirGreenSoft else LavenderContainer
        )
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (active) Icons.Filled.CheckCircle else Icons.Filled.Bolt,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = if (active) "Haven Plus Active ⚡" else "Free Plan (Slow AI • Voice Control Locked)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    val subtitle = if (active) {
                        val exp = if (profile.subscriptionExpiresAtMillis > 0L) {
                            " • Until ${SimpleDateFormat("MMM d", Locale.getDefault()).format(Date(profile.subscriptionExpiresAtMillis))}"
                        } else ""
                        "Fast AI + Voice Control Unlocked (${profile.subscriptionMethod}$exp)"
                    } else {
                        "Subscribe via haven-rand-subscribe.lovable.app (from R5/wk)"
                    }
                    Text(text = subtitle, style = MaterialTheme.typography.bodySmall)
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            Button(
                onClick = onOpenSubscribeSheet,
                modifier = Modifier.testTag("open_subscribe_dialog_button")
            ) {
                Text(if (active) "Manage" else "Subscribe R5+")
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SubscriptionDialog(
    profile: UserProfile,
    isSyncing: Boolean,
    syncStatusMessage: String?,
    onOpenSubscriptionWebsite: (subscriberIdentifier: String, plan: SubscriptionPlan) -> Unit,
    onSyncWithWeb: (subscriberIdentifier: String, plan: SubscriptionPlan, confirmationCode: String) -> Unit,
    onLaunchAirtimeTransfer: (SubscriptionPlan) -> Unit,
    onActivateWithAirtimeRef: (plan: SubscriptionPlan, senderOrRef: String, subscriberIdentifier: String) -> Unit,
    onActivateWithOneForYou: (plan: SubscriptionPlan, voucherPin: String, subscriberIdentifier: String) -> Unit,
    onDismiss: () -> Unit
) {
    var subscriberContact by remember {
        mutableStateOf(profile.backupEmail.ifBlank { profile.phoneNumber })
    }
    var selectedPlan by remember { mutableStateOf(SubscriptionPlan.WEEKLY) }
    var selectedMethod by remember { mutableStateOf(SubscribeMethodTab.WEB) }
    var webConfirmCode by remember { mutableStateOf("") }
    var airtimeRefInput by remember { mutableStateOf("") }
    var voucherPinInput by remember { mutableStateOf("") }
    var validationError by remember { mutableStateOf<String?>(null) }

    fun isValidContact(input: String): Boolean {
        val c = input.trim()
        return (c.contains("@") && c.contains(".")) || c.count { it.isDigit() } >= 6
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Subscribe to Haven Plus ⚡") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Enter your email or phone number to subscribe via haven-rand-subscribe.lovable.app and unlock AI Fast Mode, Voice Control, and full Phone Automation.",
                    style = MaterialTheme.typography.bodySmall
                )

                OutlinedTextField(
                    value = subscriberContact,
                    onValueChange = { subscriberContact = it; validationError = null },
                    label = { Text("Your Email or Phone Number *") },
                    placeholder = { Text("you@gmail.com or +27821234567") },
                    leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("subscribe_contact_input")
                )

                Text("1. Choose Plan:", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SubscriptionPlan.entries.forEach { plan ->
                        FilterChip(
                            selected = selectedPlan == plan,
                            onClick = { selectedPlan = plan },
                            label = { Text("${plan.label} (${plan.priceLabel})") }
                        )
                    }
                }

                Text("2. Subscribe & Sync:", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    FilterChip(
                        selected = selectedMethod == SubscribeMethodTab.WEB,
                        onClick = { selectedMethod = SubscribeMethodTab.WEB; validationError = null },
                        leadingIcon = { Icon(Icons.Filled.Language, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        label = { Text("Haven Website") }
                    )
                    FilterChip(
                        selected = selectedMethod == SubscribeMethodTab.VOUCHER,
                        onClick = { selectedMethod = SubscribeMethodTab.VOUCHER; validationError = null },
                        leadingIcon = { Icon(Icons.Filled.CardGiftcard, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        label = { Text("1ForYou Voucher") }
                    )
                    FilterChip(
                        selected = selectedMethod == SubscribeMethodTab.AIRTIME,
                        onClick = { selectedMethod = SubscribeMethodTab.AIRTIME; validationError = null },
                        leadingIcon = { Icon(Icons.Filled.PhoneAndroid, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        label = { Text("Airtime Billing") }
                    )
                }

                when (selectedMethod) {
                    SubscribeMethodTab.WEB -> {
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(
                                    text = "Official Portal: haven-rand-subscribe.lovable.app",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Button(
                                    onClick = {
                                        if (!isValidContact(subscriberContact)) {
                                            validationError = "Enter your email or phone number first."
                                        } else {
                                            onOpenSubscriptionWebsite(subscriberContact, selectedPlan)
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth().testTag("open_subscribe_website_button")
                                ) {
                                    Icon(Icons.Filled.Language, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Open haven-rand-subscribe.lovable.app")
                                }
                                OutlinedButton(
                                    onClick = {
                                        if (!isValidContact(subscriberContact)) {
                                            validationError = "Enter your email or phone number to check web status."
                                        } else {
                                            onSyncWithWeb(subscriberContact, selectedPlan, webConfirmCode)
                                        }
                                    },
                                    enabled = !isSyncing,
                                    modifier = Modifier.fillMaxWidth().testTag("sync_web_subscription_button")
                                ) {
                                    if (isSyncing) {
                                        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                    } else {
                                        Icon(Icons.Filled.Sync, contentDescription = null, modifier = Modifier.size(18.dp))
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("I Subscribed — Talk to Web & Sync")
                                }
                            }
                        }
                        OutlinedTextField(
                            value = webConfirmCode,
                            onValueChange = { webConfirmCode = it },
                            label = { Text("Website Receipt / Confirmation Code (if needed)") },
                            placeholder = { Text("e.g. HAVEN-94821") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("web_confirm_code_input")
                        )
                    }

                    SubscribeMethodTab.VOUCHER -> {
                        OutlinedTextField(
                            value = voucherPinInput,
                            onValueChange = { raw -> voucherPinInput = raw.filter { it.isDigit() }.take(16) },
                            label = { Text("16-Digit 1ForYou Voucher PIN") },
                            placeholder = { Text("Enter 12–16 digit 1ForYou PIN") },
                            supportingText = { Text("${voucherPinInput.length} / 16 digits • Synced with Haven Plus") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("voucher_pin_input")
                        )
                    }

                    SubscribeMethodTab.AIRTIME -> {
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = "Airtime Subscription (${selectedPlan.priceLabel})",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Vodacom *135# • MTN *136*3# • Telkom *180# • Cell C *147#. Tap below to open airtime billing helper.",
                                    style = MaterialTheme.typography.bodySmall
                                )
                                OutlinedButton(onClick = { onLaunchAirtimeTransfer(selectedPlan) }) {
                                    Text("Open Airtime Payment Helper")
                                }
                            }
                        }
                        OutlinedTextField(
                            value = airtimeRefInput,
                            onValueChange = { airtimeRefInput = it },
                            label = { Text("Airtime Confirmation Ref") },
                            placeholder = { Text("e.g. Ref #") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("airtime_ref_input")
                        )
                    }
                }

                syncStatusMessage?.let { msg ->
                    Text(msg, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                }

                validationError?.let { err ->
                    Text(err, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (!isValidContact(subscriberContact)) {
                        validationError = "Please enter your email or phone number first."
                        return@Button
                    }
                    when (selectedMethod) {
                        SubscribeMethodTab.WEB -> {
                            onSyncWithWeb(subscriberContact, selectedPlan, webConfirmCode)
                        }
                        SubscribeMethodTab.AIRTIME -> {
                            val cleaned = airtimeRefInput.trim()
                            if (cleaned.length < 4) {
                                validationError = "Enter your airtime confirmation reference."
                            } else {
                                onActivateWithAirtimeRef(selectedPlan, cleaned, subscriberContact)
                                onDismiss()
                            }
                        }
                        SubscribeMethodTab.VOUCHER -> {
                            val pin = voucherPinInput.filter { it.isDigit() }
                            if (pin.length < 12) {
                                validationError = "Enter a valid 12–16 digit 1ForYou Voucher PIN."
                            } else {
                                onActivateWithOneForYou(selectedPlan, pin, subscriberContact)
                                onDismiss()
                            }
                        }
                    }
                },
                enabled = !isSyncing,
                modifier = Modifier.testTag("confirm_subscribe_button")
            ) {
                Icon(Icons.Filled.LockOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    when (selectedMethod) {
                        SubscribeMethodTab.WEB -> "Verify & Unlock Plus"
                        SubscribeMethodTab.VOUCHER -> "Send Voucher & Unlock"
                        SubscribeMethodTab.AIRTIME -> "Activate Plus Now"
                    }
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}
