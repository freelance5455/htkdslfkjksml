package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.model.BreadcrumbSegment
import com.example.data.model.FileNode
import com.example.data.model.SortField
import com.example.data.storage.FileTypeInspector
import com.example.data.storage.StorageProvider
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

sealed interface DirectoryUiState {
    data object Loading : DirectoryUiState
    data class Success(val items: List<FileNode>) : DirectoryUiState
    data class Error(val message: String) : DirectoryUiState
}

data class FileManagerUiState(
    val rootPath: String,
    val currentPath: String,
    val breadcrumbs: List<BreadcrumbSegment> = emptyList(),
    val backStack: List<String> = emptyList(),
    val showHiddenFiles: Boolean = false,
    val sortField: SortField = SortField.NAME,
    val sortAscending: Boolean = true,
    val directoryState: DirectoryUiState = DirectoryUiState.Loading
) {
    val canNavigateUp: Boolean
        get() = backStack.isNotEmpty() || currentPath != rootPath
}

/**
 * Dedicated ViewModel for directory traversal, breadcrumb path resolution,
 * backstack history, and reactive file/folder listing over a StorageProvider
 * or direct java.io.File root directory.
 */
class FileManagerViewModel(
    private val rootPath: String,
    private val storageProvider: StorageProvider? = null,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) : ViewModel() {

    private val _uiState = MutableStateFlow(
        FileManagerUiState(
            rootPath = normalizePath(rootPath),
            currentPath = normalizePath(rootPath),
            breadcrumbs = computeBreadcrumbs(normalizePath(rootPath), normalizePath(rootPath))
        )
    )
    val uiState: StateFlow<FileManagerUiState> = _uiState.asStateFlow()

    init {
        loadDirectory(_uiState.value.currentPath)
    }

    /**
     * Opens a directory and pushes the previous path onto the navigation backstack.
     */
    fun openDirectory(targetPath: String) {
        val normalizedTarget = normalizePath(targetPath)
        val current = _uiState.value.currentPath
        if (normalizedTarget == current) {
            refresh()
            return
        }
        _uiState.update { state ->
            state.copy(
                currentPath = normalizedTarget,
                backStack = state.backStack + current,
                breadcrumbs = computeBreadcrumbs(state.rootPath, normalizedTarget),
                directoryState = DirectoryUiState.Loading
            )
        }
        loadDirectory(normalizedTarget)
    }

    /**
     * Handles tapping a FileNode: enters directories automatically, or invokes [onOpenFile] for files.
     */
    fun onItemClicked(node: FileNode, onOpenFile: (FileNode) -> Unit = {}) {
        if (node.isDirectory) {
            openDirectory(node.path)
        } else {
            onOpenFile(node)
        }
    }

    /**
     * Jumps directly to a breadcrumb segment, trimming any deeper backstack history.
     */
    fun navigateToBreadcrumb(segmentPath: String) {
        val normalizedTarget = normalizePath(segmentPath)
        val current = _uiState.value.currentPath
        if (normalizedTarget == current) return

        _uiState.update { state ->
            val existingIdx = state.backStack.indexOf(normalizedTarget)
            val updatedStack = if (existingIdx >= 0) {
                state.backStack.take(existingIdx)
            } else if (normalizedTarget == state.rootPath) {
                emptyList()
            } else {
                state.backStack + current
            }
            state.copy(
                currentPath = normalizedTarget,
                backStack = updatedStack,
                breadcrumbs = computeBreadcrumbs(state.rootPath, normalizedTarget),
                directoryState = DirectoryUiState.Loading
            )
        }
        loadDirectory(normalizedTarget)
    }

    /**
     * Navigates up/back through the directory traversal history, or to the parent directory
     * if not yet at [rootPath]. Returns `true` if navigation occurred, or `false` at root.
     */
    fun navigateUp(): Boolean {
        val state = _uiState.value
        if (state.backStack.isNotEmpty()) {
            val previousPath = state.backStack.last()
            _uiState.update {
                it.copy(
                    currentPath = previousPath,
                    backStack = it.backStack.dropLast(1),
                    breadcrumbs = computeBreadcrumbs(it.rootPath, previousPath),
                    directoryState = DirectoryUiState.Loading
                )
            }
            loadDirectory(previousPath)
            return true
        }

        val parentPath = resolveParentPath(state.rootPath, state.currentPath)
        if (parentPath != null && parentPath != state.currentPath) {
            _uiState.update {
                it.copy(
                    currentPath = parentPath,
                    breadcrumbs = computeBreadcrumbs(it.rootPath, parentPath),
                    directoryState = DirectoryUiState.Loading
                )
            }
            loadDirectory(parentPath)
            return true
        }

        return false
    }

    fun setShowHiddenFiles(showHidden: Boolean) {
        _uiState.update { it.copy(showHiddenFiles = showHidden) }
        refresh()
    }

    fun setSortOrder(field: SortField, ascending: Boolean) {
        _uiState.update { it.copy(sortField = field, sortAscending = ascending) }
        val currentItems = (_uiState.value.directoryState as? DirectoryUiState.Success)?.items
        if (currentItems != null) {
            _uiState.update {
                it.copy(directoryState = DirectoryUiState.Success(sortItems(currentItems, field, ascending)))
            }
        } else {
            refresh()
        }
    }

    fun refresh() {
        loadDirectory(_uiState.value.currentPath)
    }

    private fun loadDirectory(path: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(directoryState = DirectoryUiState.Loading) }
            val snapshot = _uiState.value
            runCatching {
                val rawItems = if (storageProvider != null) {
                    storageProvider.list(path, snapshot.showHiddenFiles)
                } else {
                    withContext(ioDispatcher) {
                        listLocalJavaIoDirectory(path, snapshot.showHiddenFiles)
                    }
                }
                sortItems(rawItems, snapshot.sortField, snapshot.sortAscending)
            }.onSuccess { sorted ->
                _uiState.update { state ->
                    if (state.currentPath == path) {
                        state.copy(directoryState = DirectoryUiState.Success(sorted))
                    } else state
                }
            }.onFailure { error ->
                _uiState.update { state ->
                    if (state.currentPath == path) {
                        state.copy(
                            directoryState = DirectoryUiState.Error(
                                error.localizedMessage ?: "Unable to read directory."
                            )
                        )
                    } else state
                }
            }
        }
    }

    private fun listLocalJavaIoDirectory(path: String, showHidden: Boolean): List<FileNode> {
        val dir = File(path.removePrefix("file://"))
        require(dir.exists() && dir.isDirectory) { "Directory does not exist: ${dir.path}" }
        val children = dir.listFiles() ?: emptyArray()
        return children.mapNotNull { file ->
            val hidden = file.name.startsWith(".") || file.isHidden
            if (!showHidden && hidden) return@mapNotNull null

            val header = if (file.isFile) FileTypeInspector.readHeaderBytes(file) else null
            val analysis = FileTypeInspector.inspect(file.name, file.isDirectory, header)
            val subChildren = if (file.isDirectory) file.listFiles() else null
            val fullPath = "file://${file.absolutePath}"
            val parent = file.parentFile?.let { "file://${it.absolutePath}" }

            FileNode(
                id = fullPath,
                name = file.name,
                path = fullPath,
                parentPath = parent,
                isDirectory = file.isDirectory,
                sizeBytes = if (file.isDirectory) {
                    subChildren?.filter { it.isFile }?.sumOf { it.length() } ?: 0L
                } else {
                    file.length()
                },
                lastModified = file.lastModified(),
                mimeType = analysis.mimeType,
                extension = file.extension.lowercase(),
                kind = analysis.kind,
                magicSignature = analysis.magicSignature,
                hasSuspiciousDoubleExtension = analysis.hasSuspiciousDoubleExtension,
                doubleExtensionWarning = analysis.doubleExtensionWarning,
                isHidden = hidden,
                isReadOnly = !file.canWrite(),
                childFolderCount = subChildren?.count { it.isDirectory } ?: 0,
                childFileCount = subChildren?.count { it.isFile } ?: 0,
                contentUriString = fullPath
            )
        }
    }

    private fun sortItems(
        items: List<FileNode>,
        field: SortField,
        ascending: Boolean
    ): List<FileNode> {
        return items.sortedWith { a, b ->
            // Folders always appear before files
            if (a.isDirectory != b.isDirectory) {
                if (a.isDirectory) -1 else 1
            } else {
                val cmp = when (field) {
                    SortField.NAME -> a.name.compareTo(b.name, ignoreCase = true)
                    SortField.DATE -> a.lastModified.compareTo(b.lastModified)
                    SortField.TYPE -> a.extension.compareTo(b.extension, ignoreCase = true)
                    SortField.SIZE -> a.sizeBytes.compareTo(b.sizeBytes)
                }
                if (ascending) cmp else -cmp
            }
        }
    }

    companion object {
        fun normalizePath(rawPath: String): String {
            return when {
                rawPath.startsWith("saf://") -> rawPath.trimEnd('/')
                rawPath.startsWith("file://") -> {
                    val clean = File(rawPath.removePrefix("file://")).absolutePath
                    "file://$clean"
                }
                else -> "file://${File(rawPath).absolutePath}"
            }
        }

        fun resolveParentPath(rootPath: String, currentPath: String): String? {
            if (currentPath == rootPath) return null
            return if (currentPath.startsWith("saf://")) {
                val rootPrefix = currentPath.substringBefore("|") + "|"
                val rel = currentPath.substringAfter("|", "").trim('/')
                if (rel.isEmpty()) null
                else {
                    val parentRel = rel.substringBeforeLast('/', "")
                    "$rootPrefix$parentRel"
                }
            } else {
                val currentFile = File(currentPath.removePrefix("file://"))
                val rootFile = File(rootPath.removePrefix("file://"))
                val parent = currentFile.parentFile ?: return null
                if (!parent.absolutePath.startsWith(rootFile.absolutePath)) null
                else "file://${parent.absolutePath}"
            }
        }

        fun computeBreadcrumbs(rootPath: String, currentPath: String): List<BreadcrumbSegment> {
            if (currentPath.startsWith("saf://")) {
                val rootPrefix = currentPath.substringBefore("|") + "|"
                val segments = mutableListOf(BreadcrumbSegment("Folder Root", rootPrefix))
                val rel = currentPath.substringAfter("|", "").trim('/')
                if (rel.isNotEmpty()) {
                    var accum = ""
                    for (part in rel.split('/').filter { it.isNotBlank() }) {
                        accum = if (accum.isEmpty()) part else "$accum/$part"
                        segments.add(BreadcrumbSegment(part, "$rootPrefix$accum"))
                    }
                }
                return segments
            }

            val rootRaw = File(rootPath.removePrefix("file://")).absolutePath
            val currRaw = File(currentPath.removePrefix("file://")).absolutePath
            val rootTitle = File(rootRaw).name.let {
                if (it.isBlank() || it == "MyFilesWorkspace") "Internal storage" else it
            }
            val segments = mutableListOf(BreadcrumbSegment(rootTitle, "file://$rootRaw"))
            if (currRaw.startsWith(rootRaw) && currRaw.length > rootRaw.length) {
                val rel = currRaw.removePrefix(rootRaw).trim('/')
                var running = File(rootRaw)
                for (part in rel.split('/').filter { it.isNotBlank() }) {
                    running = File(running, part)
                    segments.add(BreadcrumbSegment(part, "file://${running.absolutePath}"))
                }
            }
            return segments
        }

        fun provideFactory(
            rootPath: String,
            storageProvider: StorageProvider? = null
        ): ViewModelProvider.Factory = viewModelFactory {
            initializer {
                FileManagerViewModel(
                    rootPath = rootPath,
                    storageProvider = storageProvider
                )
            }
        }
    }
}
