package com.example.ui.menu

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.testTag

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LevelSelectScreen(
    onStageSelected: (Int) -> Unit,
    onBack: () -> Unit
) {
    val stages = (1..10).toList()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("اختر المرحلة", color = Color(0xFFf1c40f), fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF1a2634))
            )
        },
        containerColor = Color(0xFF0f172a)
    ) { innerPadding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(stages) { stage ->
                Card(
                    onClick = { onStageSelected(stage) },
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2c3e50)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                    modifier = Modifier
                        .height(110.dp)
                        .testTag("stage_card_$stage")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "المرحلة $stage",
                            color = Color(0xFFf1c40f),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = when (stage) {
                                1 -> "بناء المملكة"
                                2 -> "تدريب المشاة"
                                3 -> "مواجهة الدوريات"
                                4 -> "بناء الدفاعات"
                                5 -> "الرماة والفرسان"
                                6 -> "الهجوم الأول"
                                7 -> "الجيش الكبير"
                                8 -> "تدمير القلعة"
                                9 -> "مملكتان معادية"
                                else -> "المعركة الكبرى"
                            },
                            color = Color(0xFFbdc3c7),
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}
