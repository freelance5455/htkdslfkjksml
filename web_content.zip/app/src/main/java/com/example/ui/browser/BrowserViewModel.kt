package com.example.ui.browser

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Bookmark
import com.example.data.model.BrowserTab
import com.example.data.model.SearchHistory
import com.example.data.repository.BrowserRepository
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import com.google.firebase.firestore.FirebaseFirestoreException
import java.net.URLEncoder
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

private const val TAG = "BrowserViewModel"

sealed interface DataUiState<out T> {
    data object Loading : DataUiState<Nothing>
    data class Success<T>(val data: T) : DataUiState<T>
    data class Error(val message: String) : DataUiState<Nothing>
}

sealed interface GeminiUiState {
    data object Idle : GeminiUiState
    data class Loading(val query: String) : GeminiUiState
    data class Streaming(val query: String, val partialText: String) : GeminiUiState
    data class Success(
        val query: String,
        val responseText: String,
        val generatedHtmlSnippet: String = ""
    ) : GeminiUiState
    data class Error(val query: String, val message: String) : GeminiUiState
}

enum class BrowserBottomDestination {
    BROWSER,
    GEMINI,
    VAULT,
    HISTORY
}

class BrowserViewModel(
    private val repository: BrowserRepository,
    private val currentUserId: String
) : ViewModel() {

    private val textModel by lazy {
        Firebase.ai.generativeModel("gemini-3.8-flash")
    }

    private val htmlSchema = Schema.obj(
        properties = mapOf(
            "headline" to Schema.string(description = "Başlık"),
            "summary" to Schema.string(description = "Konunun net ve anlaşılır özeti"),
            "keyPoints" to Schema.array(
                items = Schema.string(),
                description = "Önemli maddeler listesi"
            ),
            "interactiveHtmlBody" to Schema.string(
                description = "Temiz, beyaz temalı, inline CSS kullanan zengin HTML içerik bloğu (yalnızca div içeriği)"
            )
        )
    )

    private val htmlModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = htmlSchema
            }
        )
    }

    private var hasSeededInitialTab = false
    private var activeGeminiJob: Job? = null

    val tabsState: StateFlow<DataUiState<List<BrowserTab>>> = repository.observeTabs(currentUserId)
        .map<List<BrowserTab>, DataUiState<List<BrowserTab>>> { tabs ->
            if (tabs.isEmpty() && !hasSeededInitialTab) {
                hasSeededInitialTab = true
                viewModelScope.launch {
                    repository.createTab(
                        title = "Yeni Sekme",
                        url = "beyaz://index.html",
                        lastQuery = ""
                    )
                }
            }
            if (_selectedTabId.value.isBlank() && tabs.isNotEmpty()) {
                _selectedTabId.value = tabs.first().id
                val firstQuery = tabs.first().lastQuery
                if (firstQuery.isNotBlank() && _lastSearchedQuery.value.isBlank()) {
                    _lastSearchedQuery.value = firstQuery
                }
            } else if (tabs.isNotEmpty() && tabs.none { it.id == _selectedTabId.value }) {
                _selectedTabId.value = tabs.first().id
            }
            DataUiState.Success(tabs)
        }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val rootError = firestoreError ?: error
            Log.w(TAG, "Error observing tabs", rootError)
            emit(DataUiState.Error(rootError.message ?: "Sekmeler yüklenemedi."))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = DataUiState.Loading
        )

    val bookmarksState: StateFlow<DataUiState<List<Bookmark>>> = repository.observeBookmarks(currentUserId)
        .map<List<Bookmark>, DataUiState<List<Bookmark>>> { DataUiState.Success(it) }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val rootError = firestoreError ?: error
            Log.w(TAG, "Error observing bookmarks", rootError)
            emit(DataUiState.Error(rootError.message ?: "Güvenli Kasa yüklenemedi."))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = DataUiState.Loading
        )

    val historyState: StateFlow<DataUiState<List<SearchHistory>>> = repository.observeHistory(currentUserId)
        .map<List<SearchHistory>, DataUiState<List<SearchHistory>>> { DataUiState.Success(it) }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val rootError = firestoreError ?: error
            Log.w(TAG, "Error observing history", rootError)
            emit(DataUiState.Error(rootError.message ?: "Geçmiş yüklenemedi."))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = DataUiState.Loading
        )

    private val _selectedTabId = MutableStateFlow("")
    val selectedTabId: StateFlow<String> = _selectedTabId.asStateFlow()

    private val _isGeminiTabActive = MutableStateFlow(false)
    val isGeminiTabActive: StateFlow<Boolean> = _isGeminiTabActive.asStateFlow()

    private val _bottomDestination = MutableStateFlow(BrowserBottomDestination.BROWSER)
    val bottomDestination: StateFlow<BrowserBottomDestination> = _bottomDestination.asStateFlow()

    private val _lastSearchedQuery = MutableStateFlow("")
    val lastSearchedQuery: StateFlow<String> = _lastSearchedQuery.asStateFlow()

    private var lastAutoExecutedGeminiQuery: String = ""
    private var latestHistoryDocId: String = ""

    private val _geminiState = MutableStateFlow<GeminiUiState>(GeminiUiState.Idle)
    val geminiState: StateFlow<GeminiUiState> = _geminiState.asStateFlow()

    private val _statusBannerMessage = MutableStateFlow<String?>(null)
    val statusBannerMessage: StateFlow<String?> = _statusBannerMessage.asStateFlow()

    fun dismissBanner() {
        _statusBannerMessage.value = null
    }

    fun showBanner(message: String) {
        _statusBannerMessage.value = message
    }

    fun selectBottomDestination(destination: BrowserBottomDestination) {
        _bottomDestination.value = destination
        if (destination == BrowserBottomDestination.GEMINI) {
            activateGeminiTabAndAutoQuery()
        } else if (destination == BrowserBottomDestination.BROWSER) {
            _isGeminiTabActive.value = false
        }
    }

    fun selectBrowserTab(tab: BrowserTab) {
        _selectedTabId.value = tab.id
        _isGeminiTabActive.value = false
        _bottomDestination.value = BrowserBottomDestination.BROWSER
        if (tab.lastQuery.isNotBlank()) {
            _lastSearchedQuery.value = tab.lastQuery
        }
    }

    /**
     * Triggered when the user taps the "✦ Gemini" tab in the top tab bar (next to other browser tabs).
     * Automatically sends the user's current/latest search query to Gemini and streams the answer.
     */
    fun activateGeminiTabAndAutoQuery(explicitQuery: String? = null) {
        _isGeminiTabActive.value = true
        _bottomDestination.value = BrowserBottomDestination.GEMINI

        val activeTab = (tabsState.value as? DataUiState.Success)?.data
            ?.firstOrNull { it.id == _selectedTabId.value }

        val targetQuery = explicitQuery?.trim()?.takeIf { it.isNotEmpty() }
            ?: _lastSearchedQuery.value.trim().takeIf { it.isNotEmpty() }
            ?: activeTab?.lastQuery?.trim()?.takeIf { it.isNotEmpty() }
            ?: activeTab?.title?.takeIf { it.isNotBlank() && it != "Yeni Sekme" && !it.contains("index.html") }
            ?: ""

        if (targetQuery.isNotBlank()) {
            _lastSearchedQuery.value = targetQuery
            val currentGemini = _geminiState.value
            val alreadyLoaded = (currentGemini is GeminiUiState.Success && currentGemini.query == targetQuery) ||
                (currentGemini is GeminiUiState.Streaming && currentGemini.query == targetQuery) ||
                (currentGemini is GeminiUiState.Loading && currentGemini.query == targetQuery)

            if (!alreadyLoaded || lastAutoExecutedGeminiQuery != targetQuery) {
                askGeminiStream(targetQuery)
            }
        }
    }

    fun createNewTab(initialUrl: String = "beyaz://index.html", initialTitle: String = "Yeni Sekme") {
        viewModelScope.launch {
            val result = repository.createTab(
                title = initialTitle,
                url = initialUrl,
                lastQuery = ""
            )
            result.onSuccess { newId ->
                _selectedTabId.value = newId
                _isGeminiTabActive.value = false
                _bottomDestination.value = BrowserBottomDestination.BROWSER
            }.onFailure { err ->
                _statusBannerMessage.value = err.localizedMessage ?: "Yeni sekme açılamadı."
            }
        }
    }

    fun closeTab(tab: BrowserTab) {
        val currentTabs = (tabsState.value as? DataUiState.Success)?.data.orEmpty()
        viewModelScope.launch {
            if (currentTabs.size <= 1) {
                repository.updateTab(
                    tabId = tab.id,
                    title = "Yeni Sekme",
                    url = "beyaz://index.html",
                    lastQuery = "",
                    isPinned = false
                )
                _isGeminiTabActive.value = false
            } else {
                val nextTab = currentTabs.firstOrNull { it.id != tab.id }
                if (_selectedTabId.value == tab.id && nextTab != null) {
                    _selectedTabId.value = nextTab.id
                }
                repository.deleteTab(tab.id)
            }
        }
    }

    fun submitSearchOrUrl(rawInput: String, openGeminiImmediately: Boolean = false) {
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) return

        val lower = trimmed.lowercase()
        val isIndexHtmlAlias = lower == "index.html" ||
            lower == "index.htlm" ||
            lower == "inde.html" ||
            lower == "inde.htlm" ||
            lower == "beyaz://index.html"

        val isDirectUrl = !isIndexHtmlAlias && (
            trimmed.startsWith("http://", ignoreCase = true) ||
                trimmed.startsWith("https://", ignoreCase = true) ||
                trimmed.startsWith("beyaz://", ignoreCase = true) ||
                trimmed.startsWith("file://", ignoreCase = true) ||
                (!trimmed.contains(" ") && trimmed.contains(".") && trimmed.length > 3)
            )

        val resolvedUrl: String
        val resolvedTitle: String
        val searchQuery: String

        if (isIndexHtmlAlias) {
            resolvedUrl = "beyaz://index.html"
            resolvedTitle = "Yeni Sekme"
            searchQuery = ""
        } else if (isDirectUrl) {
            resolvedUrl = when {
                trimmed.startsWith("http://") || trimmed.startsWith("https://") ||
                    trimmed.startsWith("beyaz://") || trimmed.startsWith("file://") -> trimmed
                else -> "https://$trimmed"
            }
            resolvedTitle = trimmed.removePrefix("https://").removePrefix("http://").take(60)
            searchQuery = trimmed
        } else {
            val encoded = try {
                URLEncoder.encode(trimmed, "UTF-8")
            } catch (e: Exception) {
                trimmed.replace(" ", "+")
            }
            resolvedUrl = "https://www.google.com/search?q=$encoded"
            resolvedTitle = trimmed.take(80)
            searchQuery = trimmed
        }

        if (searchQuery.isNotBlank()) {
            _lastSearchedQuery.value = searchQuery
        }

        viewModelScope.launch {
            val activeTab = (tabsState.value as? DataUiState.Success)?.data
                ?.firstOrNull { it.id == _selectedTabId.value }

            if (activeTab != null) {
                repository.updateTab(
                    tabId = activeTab.id,
                    title = resolvedTitle,
                    url = resolvedUrl,
                    lastQuery = searchQuery,
                    isPinned = activeTab.isPinned
                )
            } else {
                val created = repository.createTab(
                    title = resolvedTitle,
                    url = resolvedUrl,
                    lastQuery = searchQuery
                )
                created.onSuccess { _selectedTabId.value = it }
            }

            val historyRes = repository.recordSearch(
                query = searchQuery,
                url = resolvedUrl
            )
            historyRes.onSuccess { docId ->
                latestHistoryDocId = docId
            }

            if (openGeminiImmediately) {
                activateGeminiTabAndAutoQuery(searchQuery)
            } else {
                _isGeminiTabActive.value = false
                _bottomDestination.value = BrowserBottomDestination.BROWSER
            }
        }
    }

    fun updateActiveTabPageMetadata(url: String, title: String?) {
        val activeTab = (tabsState.value as? DataUiState.Success)?.data
            ?.firstOrNull { it.id == _selectedTabId.value } ?: return

        val cleanUrl = if (url.startsWith("file:///android_asset/index.html")) {
            "beyaz://index.html"
        } else {
            url
        }
        val cleanTitle = title?.trim()?.takeIf { it.isNotEmpty() } ?: activeTab.title

        if (cleanUrl == activeTab.url && cleanTitle == activeTab.title) return

        viewModelScope.launch {
            repository.updateTab(
                tabId = activeTab.id,
                title = cleanTitle,
                url = cleanUrl,
                lastQuery = activeTab.lastQuery,
                isPinned = activeTab.isPinned
            )
        }
    }

    fun askGeminiStream(query: String) {
        val cleanQuery = query.trim()
        if (cleanQuery.isEmpty()) return

        _lastSearchedQuery.value = cleanQuery
        lastAutoExecutedGeminiQuery = cleanQuery
        activeGeminiJob?.cancel()

        activeGeminiJob = viewModelScope.launch {
            _geminiState.value = GeminiUiState.Loading(cleanQuery)
            val accumulated = StringBuilder()

            val prompt = """
                Sen Beyaz Browser'ın entegre araştırma asistanı Gemini'sin.
                Kullanıcı tarayıcıda şu konuyu araştırdı: "$cleanQuery"
                
                Lütfen Türkçe olarak:
                1. Konunun net, doğru ve anlaşılır bir özetini,
                2. En önemli 3-5 temel noktayı (maddeler halinde),
                3. Konuyla ilgili pratik bilgileri veya derinleştirici açıklamaları
                sade ve okunaklı bir biçimde yanıtla.
            """.trimIndent()

            try {
                withTimeout(60_000L) {
                    textModel.generateContentStream(prompt).collect { chunk ->
                        val textChunk = chunk.text.orEmpty()
                        accumulated.append(textChunk)
                        _geminiState.value = GeminiUiState.Streaming(
                            query = cleanQuery,
                            partialText = accumulated.toString()
                        )
                    }
                }
                val finalAnswer = accumulated.toString().trim()
                if (finalAnswer.isNotEmpty()) {
                    _geminiState.value = GeminiUiState.Success(
                        query = cleanQuery,
                        responseText = finalAnswer
                    )
                    if (latestHistoryDocId.isNotBlank()) {
                        repository.updateHistoryGeminiResponse(latestHistoryDocId, finalAnswer)
                    } else {
                        val res = repository.recordSearch(
                            query = cleanQuery,
                            url = "beyaz://index.html",
                            geminiResponse = finalAnswer
                        )
                        res.onSuccess { latestHistoryDocId = it }
                    }
                } else {
                    _geminiState.value = GeminiUiState.Error(
                        query = cleanQuery,
                        message = "Gemini boş bir yanıt döndürdü. Lütfen tekrar deneyin."
                    )
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Gemini streaming timed out", e)
                _geminiState.value = GeminiUiState.Error(
                    query = cleanQuery,
                    message = "Gemini yanıtı 60 saniye içinde tamamlanamadı. Lütfen tekrar deneyin."
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Gemini streaming failed", e)
                _geminiState.value = GeminiUiState.Error(
                    query = cleanQuery,
                    message = e.localizedMessage ?: "Gemini yanıtı alınırken bir hata oluştu."
                )
            }
        }
    }

    /**
     * Generates a rich, structured interactive HTML card via Gemini for `index.html` preview.
     */
    fun generateInteractiveIndexHtmlForQuery(query: String) {
        val cleanQuery = query.trim().ifEmpty { _lastSearchedQuery.value.trim() }
        if (cleanQuery.isEmpty()) return

        activeGeminiJob?.cancel()
        activeGeminiJob = viewModelScope.launch {
            val previousResponse = (_geminiState.value as? GeminiUiState.Success)?.responseText.orEmpty()
            _geminiState.value = GeminiUiState.Loading(cleanQuery)
            try {
                val prompt = """
                    Kullanıcının araştırdığı konu: "$cleanQuery"
                    Bu konu için Beyaz Browser'ın index.html sayfasında görüntülenecek sade, beyaz temalı, modern bir bilgi kartı üret.
                """.trimIndent()

                val response = withTimeout(60_000L) {
                    htmlModel.generateContent(prompt)
                }
                val jsonString = response.text ?: throw IllegalStateException("Boş JSON yanıtı döndü.")
                val json = JSONObject(jsonString)
                val headline = json.optString("headline", cleanQuery)
                val summary = json.optString("summary", "")
                val keyPointsArr = json.optJSONArray("keyPoints")
                val points = buildList {
                    if (keyPointsArr != null) {
                        for (i in 0 until keyPointsArr.length()) {
                            add(keyPointsArr.getString(i))
                        }
                    }
                }
                val formattedText = buildString {
                    appendLine(headline)
                    appendLine()
                    appendLine(summary)
                    if (points.isNotEmpty()) {
                        appendLine()
                        points.forEach { pt -> appendLine("• $pt") }
                    }
                }.trim()

                val htmlBody = json.optString("interactiveHtmlBody", "")
                _geminiState.value = GeminiUiState.Success(
                    query = cleanQuery,
                    responseText = formattedText.ifBlank { previousResponse },
                    generatedHtmlSnippet = htmlBody
                )
                _statusBannerMessage.value = "index.html görünümü Gemini ile güncellendi."
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "HTML generation timed out", e)
                _geminiState.value = GeminiUiState.Error(
                    query = cleanQuery,
                    message = "index.html oluşturma işlemi zaman aşımına uğradı."
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "HTML generation failed", e)
                _geminiState.value = GeminiUiState.Error(
                    query = cleanQuery,
                    message = e.localizedMessage ?: "index.html içeriği oluşturulamadı."
                )
            }
        }
    }

    fun saveBookmarkToVault(
        title: String,
        url: String,
        category: String = "Genel",
        note: String = ""
    ) {
        viewModelScope.launch {
            val result = repository.addBookmark(
                title = title,
                url = url,
                category = category,
                note = note
            )
            result.onSuccess {
                _statusBannerMessage.value = "\"$title\" Güvenli Kasaya kaydedildi."
            }.onFailure { err ->
                _statusBannerMessage.value = err.localizedMessage ?: "Kayıt başarısız oldu."
            }
        }
    }

    fun deleteBookmark(bookmarkId: String) {
        viewModelScope.launch {
            repository.deleteBookmark(bookmarkId)
        }
    }

    fun deleteHistoryItem(historyId: String) {
        viewModelScope.launch {
            repository.deleteHistoryItem(historyId)
        }
    }

    fun clearAllCloudData() {
        viewModelScope.launch {
            val result = repository.clearAllUserData()
            result.onSuccess {
                hasSeededInitialTab = false
                _lastSearchedQuery.value = ""
                _geminiState.value = GeminiUiState.Idle
                _statusBannerMessage.value = "Tüm tarayıcı ve kasa verileriniz buluttan güvenle silindi."
            }.onFailure { err ->
                _statusBannerMessage.value = err.localizedMessage ?: "Veriler temizlenemedi."
            }
        }
    }
}
