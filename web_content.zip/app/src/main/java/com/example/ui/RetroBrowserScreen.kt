package com.example.ui

import android.annotation.SuppressLint
import android.app.Activity
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.BrowserMode
import com.example.ui.chrome.ChromeBrowserHeader
import com.example.ui.components.AboutBrowserDialog
import com.example.ui.components.ArchiveTimeTravelDialog
import com.example.ui.components.CrtMonitorOverlay
import com.example.ui.components.EraSitesDialog
import com.example.ui.components.FlashPlayerSettingsDialog
import com.example.ui.components.SourceCodeDialog
import com.example.ui.components.UserAgentSwitcherDialog
import com.example.ui.components.XpAddressBar
import com.example.ui.components.XpLinksBar
import com.example.ui.components.XpMenuBar
import com.example.ui.components.XpStandardToolbar
import com.example.ui.components.XpStatusBar
import com.example.ui.components.XpTitleBar
import com.example.ui.xp.WindowsXpTheme

class WebAppInterface(private val onHtmlReceived: (String) -> Unit) {
    @JavascriptInterface
    fun processHTML(html: String) {
        onHtmlReceived(html)
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun RetroBrowserScreen(
    viewModel: RetroBrowserViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val activity = context as? Activity
    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    val activeTab = uiState.activeTab

    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    val rotateScreen: () -> Unit = {
        activity?.let { act ->
            val current = act.resources.configuration.orientation
            if (current == Configuration.ORIENTATION_LANDSCAPE) {
                act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            } else {
                act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            }
        }
    }

    // Intercept back button to navigate WebView back
    BackHandler(enabled = activeTab.canGoBack) {
        webViewRef?.let { wv ->
            if (wv.canGoBack()) {
                wv.goBack()
            }
        }
    }

    // React to user-agent change
    LaunchedEffect(uiState.userAgentType) {
        webViewRef?.settings?.userAgentString = uiState.userAgentType.userAgent
        webViewRef?.reload()
    }

    // React to active tab url change from external event
    LaunchedEffect(activeTab.url) {
        webViewRef?.let { wv ->
            if (wv.url != activeTab.url && activeTab.url.isNotEmpty()) {
                wv.loadUrl(activeTab.url)
            }
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        if (isLandscape || !uiState.isWidescreen16x9) {
            // Fullscreen Edge-to-Edge Browser View (native 16:9 when rotated in landscape)
            BrowserWindowContent(
                uiState = uiState,
                viewModel = viewModel,
                onRotateScreen = rotateScreen,
                onWebViewReady = { webViewRef = it },
                onEvaluateSource = {
                    webViewRef?.evaluateJavascript(
                        "javascript:window.Android.processHTML('<!DOCTYPE html>' + document.documentElement.outerHTML);",
                        null
                    )
                },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            // Authentic 16:9 Widescreen Desktop Monitor View (in Portrait)
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color(0xFF1A2A44), Color(0xFF0F172A), Color(0xFF1E293B))
                        )
                    )
                    .verticalScroll(rememberScrollState())
                    .padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Monitor Top Bezel
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(12.dp, RoundedCornerShape(10.dp))
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color(0xFF373A40), Color(0xFF232528))
                            )
                        )
                        .border(2.dp, Color(0xFF52565E), RoundedCornerShape(10.dp))
                        .padding(top = 8.dp, start = 8.dp, end = 8.dp)
                ) {
                    // 16:9 Widescreen Screen Area
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(16f / 9f)
                            .clip(RoundedCornerShape(4.dp))
                            .border(1.dp, Color(0xFF111215), RoundedCornerShape(4.dp))
                    ) {
                        BrowserWindowContent(
                            uiState = uiState,
                            viewModel = viewModel,
                            onRotateScreen = rotateScreen,
                            onWebViewReady = { webViewRef = it },
                            onEvaluateSource = {
                                webViewRef?.evaluateJavascript(
                                    "javascript:window.Android.processHTML('<!DOCTYPE html>' + document.documentElement.outerHTML);",
                                    null
                                )
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    // Monitor Chin with Controls & Power LED
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(28.dp)
                            .padding(horizontal = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Monitor Brand
                        Text(
                            text = "RetroVision 16:9 Widescreen LCD",
                            color = Color(0xFFAAAAAA),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.SansSerif
                        )

                        // OSD Buttons & Power LED
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "AUTO   MENU   -   +",
                                color = Color(0xFF666666),
                                fontSize = 7.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            // Power LED (Glowing green when active)
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF00E676))
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            // Power button toggle
                            Box(
                                modifier = Modifier
                                    .size(14.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF1E2124))
                                    .clickable { viewModel.toggleWidescreen16x9() }
                                    .border(1.dp, Color(0xFF555555), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("⏻", color = Color.White, fontSize = 8.sp)
                            }
                        }
                    }
                }

                // Monitor Stand Neck and Base
                Box(
                    modifier = Modifier
                        .width(48.dp)
                        .height(16.dp)
                        .background(Color(0xFF2C2E33))
                )
                Box(
                    modifier = Modifier
                        .width(140.dp)
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color(0xFF3A3D44))
                        .border(1.dp, Color(0xFF52565E), RoundedCornerShape(4.dp))
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Quick Action Controls under monitor
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    Button(
                        onClick = rotateScreen,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0058EE)),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.padding(horizontal = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ScreenRotation,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Rotate 16:9 Landscape", fontSize = 11.sp, color = Color.White)
                    }

                    Button(
                        onClick = { viewModel.toggleWidescreen16x9() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.padding(horizontal = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Fullscreen,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Fullscreen Fit", fontSize = 11.sp, color = Color.White)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    Button(
                        onClick = { viewModel.navigateTo("file:///android_asset/flash_player_hub.html") },
                        colors = ButtonDefaults.buttonColors(containerColor = WindowsXpTheme.FlashRed),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.padding(horizontal = 3.dp)
                    ) {
                        Text("⚡ Flash 10", fontSize = 10.sp, color = Color.White)
                    }

                    Button(
                        onClick = { viewModel.setShowWaybackDialog(true) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E8B57)),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.padding(horizontal = 3.dp)
                    ) {
                        Text("⏱ Wayback", fontSize = 10.sp, color = Color.White)
                    }

                    Button(
                        onClick = { viewModel.setShowEraSitesDialog(true) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF546E7A)),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.padding(horizontal = 3.dp)
                    ) {
                        Text("🌐 Era Sites", fontSize = 10.sp, color = Color.White)
                    }
                }
            }
        }

        // Dialogs
        if (uiState.showFlashSettings) {
            FlashPlayerSettingsDialog(
                onDismiss = { viewModel.setShowFlashSettings(false) },
                onLaunchFlashHub = {
                    viewModel.setShowFlashSettings(false)
                    viewModel.navigateTo("file:///android_asset/flash_player_hub.html")
                }
            )
        }

        if (uiState.showWaybackDialog) {
            ArchiveTimeTravelDialog(
                currentUrl = activeTab.url,
                onDismiss = { viewModel.setShowWaybackDialog(false) },
                onTravelToArchive = { archiveUrl ->
                    viewModel.navigateTo(archiveUrl)
                }
            )
        }

        if (uiState.showEraSitesDialog) {
            EraSitesDialog(
                onSelectSite = { site ->
                    viewModel.navigateTo(site.url)
                },
                onDismiss = { viewModel.setShowEraSitesDialog(false) }
            )
        }

        if (uiState.showUserAgentDialog) {
            UserAgentSwitcherDialog(
                currentAgent = uiState.userAgentType,
                onSelectAgent = { type ->
                    viewModel.setUserAgent(type)
                },
                onDismiss = { viewModel.setShowUserAgentDialog(false) }
            )
        }

        if (uiState.showSourceCodeDialog) {
            SourceCodeDialog(
                url = activeTab.url,
                sourceHtml = uiState.pageSourceCode,
                onDismiss = { viewModel.setShowSourceCodeDialog(false) }
            )
        }

        if (uiState.showAboutDialog) {
            AboutBrowserDialog(
                onDismiss = { viewModel.setShowAboutDialog(false) }
            )
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun BrowserWindowContent(
    uiState: RetroBrowserUiState,
    viewModel: RetroBrowserViewModel,
    onRotateScreen: () -> Unit,
    onWebViewReady: (WebView) -> Unit,
    onEvaluateSource: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeTab = uiState.activeTab

    Column(
        modifier = modifier
            .background(WindowsXpTheme.Background)
    ) {
        when (uiState.browserMode) {
            BrowserMode.WINDOWS_XP_IE6 -> {
                // Windows XP Luna Chrome Header
                XpTitleBar(
                    title = activeTab.title,
                    browserMode = uiState.browserMode,
                    isWidescreen16x9 = uiState.isWidescreen16x9,
                    onToggleWidescreen = { viewModel.toggleWidescreen16x9() },
                    onRotateScreen = onRotateScreen,
                    onToggleBrowserMode = { viewModel.toggleBrowserMode() },
                    onMinimize = { /* minimize */ },
                    onClose = { /* close */ }
                )

                XpMenuBar(
                    onNewTab = { viewModel.newTab() },
                    onOpenUrlDialog = { viewModel.setShowEraSitesDialog(true) },
                    onToggleCrt = { viewModel.toggleCrtFilter() },
                    crtActive = uiState.crtFilterActive,
                    isWidescreen16x9 = uiState.isWidescreen16x9,
                    onToggleWidescreen = { viewModel.toggleWidescreen16x9() },
                    onRotateScreen = onRotateScreen,
                    onOpenFlashSettings = { viewModel.setShowFlashSettings(true) },
                    onOpenUserAgentSwitcher = { viewModel.setShowUserAgentDialog(true) },
                    onOpenWaybackDialog = { viewModel.setShowWaybackDialog(true) },
                    onOpenEraSites = { viewModel.setShowEraSitesDialog(true) },
                    onViewSource = {
                        onEvaluateSource()
                        viewModel.setShowSourceCodeDialog(true)
                    },
                    onAbout = { viewModel.setShowAboutDialog(true) }
                )

                XpStandardToolbar(
                    canGoBack = activeTab.canGoBack,
                    canGoForward = activeTab.canGoForward,
                    isLoading = activeTab.isLoading,
                    onBack = { viewModel.updateActiveTabUrl(activeTab.url) },
                    onForward = { viewModel.updateActiveTabUrl(activeTab.url) },
                    onStop = { /* stop */ },
                    onRefresh = { viewModel.navigateTo(activeTab.url) },
                    onHome = { viewModel.navigateTo("file:///android_asset/msn_start_2001.html") },
                    onSearch = { viewModel.navigateTo("https://wiby.me") },
                    onFavorites = { viewModel.setShowEraSitesDialog(true) },
                    onHistory = { viewModel.setShowEraSitesDialog(true) },
                    onFlashHub = { viewModel.navigateTo("file:///android_asset/flash_player_hub.html") },
                    onWayback = { viewModel.setShowWaybackDialog(true) }
                )

                XpAddressBar(
                    currentUrl = activeTab.url,
                    onNavigate = { viewModel.navigateTo(it) },
                    onOpenWaybackPicker = { viewModel.setShowWaybackDialog(true) }
                )

                XpLinksBar(
                    onSelectSite = { site -> viewModel.navigateTo(site.url) }
                )
            }

            BrowserMode.GOOGLE_CHROME -> {
                // Google Chrome Mode Header
                ChromeBrowserHeader(
                    tabs = uiState.tabs,
                    activeTabId = uiState.activeTabId,
                    onSelectTab = { viewModel.selectTab(it) },
                    onCloseTab = { viewModel.closeTab(it) },
                    onNewTab = { viewModel.newTab() },
                    onToggleBrowserMode = { viewModel.toggleBrowserMode() },
                    isWidescreen16x9 = uiState.isWidescreen16x9,
                    onToggleWidescreen = { viewModel.toggleWidescreen16x9() },
                    onRotateScreen = onRotateScreen,
                    canGoBack = activeTab.canGoBack,
                    canGoForward = activeTab.canGoForward,
                    isLoading = activeTab.isLoading,
                    progress = activeTab.progress,
                    currentUrl = activeTab.url,
                    isSecure = activeTab.isSecure,
                    onBack = { /* back */ },
                    onForward = { /* forward */ },
                    onRefresh = { viewModel.navigateTo(activeTab.url) },
                    onStop = { /* stop */ },
                    onHome = { viewModel.navigateTo("file:///android_asset/msn_start_2001.html") },
                    onNavigate = { viewModel.navigateTo(it) },
                    onOpenFlashSettings = { viewModel.setShowFlashSettings(true) },
                    onOpenEraSites = { viewModel.setShowEraSitesDialog(true) },
                    onOpenWayback = { viewModel.setShowWaybackDialog(true) },
                    onToggleCrt = { viewModel.toggleCrtFilter() }
                )
            }
        }

        // Web View Container
        Box(
            modifier = Modifier
                .weight(1f)
                .background(Color.White)
        ) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    WebView(ctx).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )

                        settings.apply {
                            javaScriptEnabled = true
                            domStorageEnabled = true
                            allowFileAccess = true
                            allowContentAccess = true
                            loadWithOverviewMode = true
                            useWideViewPort = true
                            setSupportZoom(true)
                            builtInZoomControls = true
                            displayZoomControls = false
                            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                            userAgentString = uiState.userAgentType.userAgent
                        }

                        addJavascriptInterface(
                            WebAppInterface { html ->
                                viewModel.setPageSourceCode(html)
                            },
                            "Android"
                        )

                        webViewClient = object : WebViewClient() {
                            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                super.onPageStarted(view, url, favicon)
                                val currentTabId = viewModel.uiState.value.activeTabId
                                viewModel.updateTabState(
                                    tabId = currentTabId,
                                    url = url,
                                    isLoading = true,
                                    progress = 10,
                                    canGoBack = view?.canGoBack(),
                                    canGoForward = view?.canGoForward(),
                                    isSecure = url?.startsWith("https://") == true
                                )
                            }

                            override fun onPageFinished(view: WebView?, url: String?) {
                                super.onPageFinished(view, url)
                                val currentTabId = viewModel.uiState.value.activeTabId
                                viewModel.updateTabState(
                                    tabId = currentTabId,
                                    title = view?.title ?: url ?: "Document",
                                    url = url,
                                    isLoading = false,
                                    progress = 100,
                                    canGoBack = view?.canGoBack(),
                                    canGoForward = view?.canGoForward(),
                                    isSecure = url?.startsWith("https://") == true
                                )

                                // Inject Adobe Flash Player 10 / Ruffle compatibility polyfill
                                view?.evaluateJavascript(
                                    """
                                    (function() {
                                      if (!window._ruffleInjected) {
                                        window._ruffleInjected = true;
                                        var s = document.createElement('script');
                                        s.src = 'https://unpkg.com/@ruffle-rs/ruffle';
                                        document.head.appendChild(s);
                                      }
                                    })();
                                    """.trimIndent(),
                                    null
                                )
                            }

                            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                                return false
                            }
                        }

                        webChromeClient = object : WebChromeClient() {
                            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                super.onProgressChanged(view, newProgress)
                                val currentTabId = viewModel.uiState.value.activeTabId
                                viewModel.updateTabState(
                                    tabId = currentTabId,
                                    progress = newProgress,
                                    isLoading = newProgress < 100
                                )
                            }

                            override fun onReceivedTitle(view: WebView?, title: String?) {
                                super.onReceivedTitle(view, title)
                                val currentTabId = viewModel.uiState.value.activeTabId
                                if (!title.isNullOrBlank()) {
                                    viewModel.updateTabState(tabId = currentTabId, title = title)
                                }
                            }
                        }

                        loadUrl(activeTab.url)
                        onWebViewReady(this)
                    }
                },
                update = { view ->
                    onWebViewReady(view)
                }
            )

            // Optional CRT Scanline Overlay
            if (uiState.crtFilterActive) {
                CrtMonitorOverlay()
            }

            // Floating Adobe Flash Player 10 badge
            Row(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 12.dp, bottom = 12.dp)
                    .shadow(4.dp, RoundedCornerShape(16.dp))
                    .clip(RoundedCornerShape(16.dp))
                    .background(WindowsXpTheme.FlashRed)
                    .border(1.dp, Color.White, RoundedCornerShape(16.dp))
                    .clickable { viewModel.setShowFlashSettings(true) }
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "f",
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Flash 10",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            }
        }

        // Windows XP Status Bar at bottom (only in XP mode)
        if (uiState.browserMode == BrowserMode.WINDOWS_XP_IE6) {
            XpStatusBar(
                statusText = if (activeTab.isLoading) "Opening page..." else "Done",
                isLoading = activeTab.isLoading,
                progress = activeTab.progress,
                isSecure = activeTab.isSecure,
                hasFlash = activeTab.hasFlash
            )
        }
    }
}
