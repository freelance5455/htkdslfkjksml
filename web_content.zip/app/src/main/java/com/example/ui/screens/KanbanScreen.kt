package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ViewKanban
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.ProjectWithStats
import com.example.data.model.TaskEntity
import com.example.data.model.TaskPriority
import com.example.data.model.TaskStatus
import com.example.data.model.TaskWithMeta
import com.example.ui.components.TaskCard
import com.example.ui.components.color
import com.example.util.toPersianDigits

@Composable
fun KanbanScreen(
    projects: List<ProjectWithStats>,
    tasks: List<TaskWithMeta>,
    forceWideBoard: Boolean = false,
    onNewTaskClick: (projectId: Long?, status: TaskStatus) -> Unit,
    onTaskClick: (TaskWithMeta) -> Unit,
    onToggleTaskDone: (TaskEntity) -> Unit,
    onAdvanceTaskStatus: (TaskEntity) -> Unit,
    onToggleBookmarkTask: (TaskEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedProjectId by remember { mutableStateOf<Long?>(null) }
    var selectedPriority by remember { mutableStateOf<TaskPriority?>(null) }
    var selectedColumnTab by remember { mutableStateOf(TaskStatus.TODO) }

    val filteredTasks = remember(tasks, selectedProjectId, selectedPriority) {
        tasks.filter { meta ->
            val matchProject = selectedProjectId == null || meta.task.projectId == selectedProjectId
            val matchPriority = selectedPriority == null || meta.task.priority == selectedPriority?.name
            matchProject && matchPriority
        }.sortedWith(
            compareByDescending<TaskWithMeta> { it.task.bookmarked }
                .thenByDescending { TaskPriority.fromName(it.task.priority).weight }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "تابلو کانبان",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${filteredTasks.size.toPersianDigits()} تسک در تابلو",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (projects.isNotEmpty()) {
                Button(
                    onClick = { onNewTaskClick(selectedProjectId, selectedColumnTab) },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.testTag("kanban_new_task_button")
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("تسک جدید")
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (projects.isNotEmpty()) {
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedProjectId == null,
                    onClick = { selectedProjectId = null },
                    label = { Text(stringResource(R.string.kanban_all_projects)) }
                )
                projects.forEach { proj ->
                    FilterChip(
                        selected = selectedProjectId == proj.project.id,
                        onClick = {
                            selectedProjectId = if (selectedProjectId == proj.project.id) null else proj.project.id
                        },
                        label = { Text(proj.project.title) }
                    )
                }
            }
        }

        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = selectedPriority == null,
                onClick = { selectedPriority = null },
                label = { Text("همه اولویت‌ها") }
            )
            TaskPriority.entries.forEach { priority ->
                FilterChip(
                    selected = selectedPriority == priority,
                    onClick = { selectedPriority = if (selectedPriority == priority) null else priority },
                    label = { Text(priority.labelFa) }
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (projects.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.ViewKanban,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(56.dp)
                    )
                    Text(
                        text = "ابتدا یک پروژه بسازید تا تابلو کانبان فعال شود",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            BoxWithConstraints(modifier = Modifier.weight(1f)) {
                val isWide = forceWideBoard || maxWidth >= 720.dp
                val needsHorizontalScroll = forceWideBoard && maxWidth < 720.dp
                if (isWide) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .then(
                                if (needsHorizontalScroll) Modifier.horizontalScroll(rememberScrollState()) else Modifier
                            ),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        TaskStatus.entries.forEach { columnStatus ->
                            val columnTasks = filteredTasks.filter { it.task.status == columnStatus.name }
                            KanbanColumnSurface(
                                status = columnStatus,
                                tasks = columnTasks,
                                onAddInColumn = { onNewTaskClick(selectedProjectId, columnStatus) },
                                onTaskClick = onTaskClick,
                                onToggleTaskDone = onToggleTaskDone,
                                onAdvanceTaskStatus = onAdvanceTaskStatus,
                                onToggleBookmarkTask = onToggleBookmarkTask,
                                modifier = if (needsHorizontalScroll) {
                                    Modifier
                                        .width(300.dp)
                                        .fillMaxHeight()
                                } else {
                                    Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                }
                            )
                        }
                    }
                } else {
                    Column(modifier = Modifier.fillMaxSize()) {
                        val selectedIdx = TaskStatus.entries.indexOf(selectedColumnTab)
                        TabRow(
                            selectedTabIndex = selectedIdx,
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                        ) {
                            TaskStatus.entries.forEach { status ->
                                val count = filteredTasks.count { it.task.status == status.name }
                                Tab(
                                    selected = selectedColumnTab == status,
                                    onClick = { selectedColumnTab = status },
                                    modifier = Modifier.testTag("kanban_tab_${status.name.lowercase()}"),
                                    text = {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(8.dp)
                                                    .clip(CircleShape)
                                                    .background(status.color())
                                            )
                                            Text(
                                                text = "${status.labelFa} (${count.toPersianDigits()})",
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = FontWeight.SemiBold,
                                                maxLines = 1
                                            )
                                        }
                                    }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        val columnTasks = filteredTasks.filter { it.task.status == selectedColumnTab.name }
                        if (columnTasks.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "تسکی در ستون «${selectedColumnTab.labelFa}» وجود ندارد",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(bottom = 88.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(items = columnTasks, key = { it.task.id }) { meta ->
                                    TaskCard(
                                        item = meta,
                                        showProjectBadge = selectedProjectId == null,
                                        onClick = { onTaskClick(meta) },
                                        onToggleDone = { onToggleTaskDone(meta.task) },
                                        onAdvanceStatus = { onAdvanceTaskStatus(meta.task) },
                                        onToggleBookmark = { onToggleBookmarkTask(meta.task) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun KanbanColumnSurface(
    status: TaskStatus,
    tasks: List<TaskWithMeta>,
    onAddInColumn: () -> Unit,
    onTaskClick: (TaskWithMeta) -> Unit,
    onToggleTaskDone: (TaskEntity) -> Unit,
    onAdvanceTaskStatus: (TaskEntity) -> Unit,
    onToggleBookmarkTask: (TaskEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        shape = MaterialTheme.shapes.large,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(status.color())
                    )
                    Text(
                        text = status.labelFa,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Surface(
                        color = status.color().copy(alpha = 0.16f),
                        shape = RoundedCornerShape(50)
                    ) {
                        Text(
                            text = tasks.size.toPersianDigits(),
                            style = MaterialTheme.typography.labelSmall,
                            color = status.color(),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }
                IconButton(onClick = onAddInColumn) {
                    Icon(Icons.Rounded.Add, contentDescription = "افزودن به ${status.labelFa}")
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            LazyColumn(
                contentPadding = PaddingValues(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(items = tasks, key = { it.task.id }) { meta ->
                    TaskCard(
                        item = meta,
                        onClick = { onTaskClick(meta) },
                        onToggleDone = { onToggleTaskDone(meta.task) },
                        onAdvanceStatus = { onAdvanceTaskStatus(meta.task) },
                        onToggleBookmark = { onToggleBookmarkTask(meta.task) }
                    )
                }
            }
        }
    }
}
