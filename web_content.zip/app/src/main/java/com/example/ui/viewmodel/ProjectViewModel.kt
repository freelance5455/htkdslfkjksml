package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.FocusSessionEntity
import com.example.data.model.MilestoneEntity
import com.example.data.model.ProjectCategory
import com.example.data.model.ProjectEntity
import com.example.data.model.ProjectStatus
import com.example.data.model.ProjectTemplateType
import com.example.data.model.ProjectWithStats
import com.example.data.model.SubtaskEntity
import com.example.data.model.TaskEntity
import com.example.data.model.TaskPriority
import com.example.data.model.TaskStatus
import com.example.data.model.TaskWithMeta
import com.example.data.model.ThemeMode
import com.example.data.repository.ProjectRepository
import com.example.util.startOfDayMillis
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class DayActivity(
    val dayLabel: String,
    val completedCount: Int
)

data class WorkspaceUiState(
    val isLoading: Boolean = true,
    val projects: List<ProjectWithStats> = emptyList(),
    val tasks: List<TaskWithMeta> = emptyList(),
    val milestones: List<MilestoneEntity> = emptyList(),
    val focusSessions: List<FocusSessionEntity> = emptyList(),
    val weeklyActivity: List<DayActivity> = emptyList(),
    val totalFocusMinutes: Int = 0,
    val todayFocusMinutes: Int = 0,
    val overallCompletionRate: Float = 0f,
    val urgentTasksCount: Int = 0,
    val overdueTasksCount: Int = 0,
    val totalStoryPoints: Int = 0,
    val doneStoryPoints: Int = 0,
    val activeStreakDays: Int = 0
)

data class FocusTimerState(
    val durationMinutes: Int = 25,
    val remainingSeconds: Int = 25 * 60,
    val isRunning: Boolean = false,
    val selectedTaskId: Long? = null,
    val justCompletedMessage: String? = null
)

class ProjectViewModel(
    private val repository: ProjectRepository
) : ViewModel() {

    val themeMode: StateFlow<ThemeMode> = repository.themeMode
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ThemeMode.SYSTEM)

    val ownerName: StateFlow<String> = repository.ownerName
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "فضای کاری شخصی")

    val forceDesktopLayout: StateFlow<Boolean> = repository.forceDesktopLayout
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val workspaceState: StateFlow<WorkspaceUiState> = combine(
        repository.projects,
        repository.tasks,
        repository.subtasks,
        repository.milestones,
        repository.focusSessions
    ) { projects, tasks, subtasks, milestones, sessions ->
        val subtasksByTask = subtasks.groupBy { it.taskId }
        val tasksByProject = tasks.groupBy { it.projectId }
        val milestonesByProject = milestones.groupBy { it.projectId }
        val projectMap = projects.associateBy { it.id }

        val projectStats = projects.map { project ->
            val pTasks = tasksByProject[project.id].orEmpty()
            val pMilestones = milestonesByProject[project.id].orEmpty()
            val doneList = pTasks.filter { it.status == TaskStatus.DONE.name }
            ProjectWithStats(
                project = project,
                totalTasks = pTasks.size,
                doneTasks = doneList.size,
                inProgressTasks = pTasks.count { it.status == TaskStatus.IN_PROGRESS.name },
                todoTasks = pTasks.count { it.status == TaskStatus.TODO.name },
                totalMilestones = pMilestones.size,
                completedMilestones = pMilestones.count { it.isCompleted },
                totalEstimatedMinutes = pTasks.sumOf { it.estimatedMinutes },
                totalFocusMinutes = pTasks.sumOf { it.focusMinutesSpent },
                totalStoryPoints = pTasks.sumOf { it.storyPoints },
                doneStoryPoints = doneList.sumOf { it.storyPoints }
            )
        }

        val tasksWithMeta = tasks.map { task ->
            val proj = projectMap[task.projectId]
            TaskWithMeta(
                task = task,
                projectTitle = proj?.title ?: "پروژه",
                projectColorIndex = proj?.colorIndex ?: 0,
                subtasks = subtasksByTask[task.id].orEmpty()
            )
        }

        val now = System.currentTimeMillis()
        val todayStart = startOfDayMillis(now)
        val dayMs = 86_400_000L

        val dayLabels = listOf("ش", "ی", "د", "س", "چ", "پ", "ج")
        val weekly = (6 downTo 0).map { offset ->
            val dayStart = todayStart - offset * dayMs
            val dayEnd = dayStart + dayMs
            val cal = java.util.Calendar.getInstance().apply { timeInMillis = dayStart }
            val satFirstIndex = (cal.get(java.util.Calendar.DAY_OF_WEEK) % 7)
            val count = tasks.count { task ->
                val doneTime = task.completedAtMillis
                task.status == TaskStatus.DONE.name && doneTime != null && doneTime in dayStart until dayEnd
            }
            DayActivity(dayLabel = dayLabels[satFirstIndex], completedCount = count)
        }

        // Calculate consecutive active days streak ending today or yesterday
        val activeDayStarts = buildSet {
            tasks.forEach { t ->
                val done = t.completedAtMillis
                if (t.status == TaskStatus.DONE.name && done != null) add(startOfDayMillis(done))
            }
            sessions.forEach { s -> add(startOfDayMillis(s.completedAtMillis)) }
        }
        var streak = 0
        var checkDay = if (activeDayStarts.contains(todayStart)) todayStart else todayStart - dayMs
        while (activeDayStarts.contains(checkDay)) {
            streak++
            checkDay -= dayMs
        }

        val totalTasks = tasks.size
        val doneTasks = tasks.count { it.status == TaskStatus.DONE.name }
        val completionRate = if (totalTasks == 0) 0f else doneTasks.toFloat() / totalTasks.toFloat()

        val urgentCount = tasks.count {
            it.status != TaskStatus.DONE.name &&
                (it.priority == TaskPriority.URGENT.name || it.priority == TaskPriority.HIGH.name)
        }
        val overdueCount = tasks.count {
            val due = it.dueDateMillis
            it.status != TaskStatus.DONE.name && due != null && startOfDayMillis(due) < todayStart
        }

        val totalFocus = sessions.sumOf { it.durationMinutes }
        val todayFocus = sessions.filter { it.completedAtMillis >= todayStart }.sumOf { it.durationMinutes }

        WorkspaceUiState(
            isLoading = false,
            projects = projectStats,
            tasks = tasksWithMeta,
            milestones = milestones,
            focusSessions = sessions,
            weeklyActivity = weekly,
            totalFocusMinutes = totalFocus,
            todayFocusMinutes = todayFocus,
            overallCompletionRate = completionRate,
            urgentTasksCount = urgentCount,
            overdueTasksCount = overdueCount,
            totalStoryPoints = tasks.sumOf { it.storyPoints },
            doneStoryPoints = tasks.filter { it.status == TaskStatus.DONE.name }.sumOf { it.storyPoints },
            activeStreakDays = streak
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = WorkspaceUiState(isLoading = true)
    )

    private val _focusTimer = MutableStateFlow(FocusTimerState())
    val focusTimer: StateFlow<FocusTimerState> = _focusTimer.asStateFlow()
    private var timerJob: Job? = null

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { repository.setThemeMode(mode) }
    }

    fun setOwnerName(name: String) {
        viewModelScope.launch { repository.setOwnerName(name) }
    }

    fun setForceDesktopLayout(enabled: Boolean) {
        viewModelScope.launch { repository.setForceDesktopLayout(enabled) }
    }

    fun createProject(
        title: String,
        description: String,
        notes: String,
        budgetLabel: String,
        category: ProjectCategory,
        colorIndex: Int,
        targetDateMillis: Long?
    ) {
        if (title.isBlank()) return
        viewModelScope.launch {
            repository.insertProject(
                ProjectEntity(
                    title = title.trim(),
                    description = description.trim(),
                    notes = notes.trim(),
                    budgetLabel = budgetLabel.trim(),
                    category = category.name,
                    status = ProjectStatus.ACTIVE.name,
                    colorIndex = colorIndex,
                    targetDateMillis = targetDateMillis
                )
            )
        }
    }

    fun updateProject(project: ProjectEntity) {
        if (project.title.isBlank()) return
        viewModelScope.launch {
            repository.updateProject(
                project.copy(
                    title = project.title.trim(),
                    description = project.description.trim(),
                    notes = project.notes.trim(),
                    budgetLabel = project.budgetLabel.trim()
                )
            )
        }
    }

    fun updateProjectNotes(project: ProjectEntity, notes: String) {
        viewModelScope.launch {
            repository.updateProject(project.copy(notes = notes))
        }
    }

    fun togglePinProject(project: ProjectEntity) {
        viewModelScope.launch {
            repository.updateProject(project.copy(isPinned = !project.isPinned))
        }
    }

    fun updateProjectStatus(project: ProjectEntity, status: ProjectStatus) {
        viewModelScope.launch {
            repository.updateProject(project.copy(status = status.name))
        }
    }

    fun deleteProject(projectId: Long) {
        viewModelScope.launch { repository.deleteProject(projectId) }
    }

    fun createTask(
        projectId: Long,
        title: String,
        description: String,
        priority: TaskPriority,
        status: TaskStatus,
        dueDateMillis: Long?,
        estimatedMinutes: Int,
        storyPoints: Int,
        assigneeName: String,
        tag: String
    ) {
        if (title.isBlank()) return
        viewModelScope.launch {
            val completedAt = if (status == TaskStatus.DONE) System.currentTimeMillis() else null
            repository.insertTask(
                TaskEntity(
                    projectId = projectId,
                    title = title.trim(),
                    description = description.trim(),
                    priority = priority.name,
                    status = status.name,
                    dueDateMillis = dueDateMillis,
                    estimatedMinutes = estimatedMinutes.coerceIn(5, 600),
                    storyPoints = storyPoints.coerceIn(1, 21),
                    assigneeName = assigneeName.trim(),
                    tag = tag.trim(),
                    completedAtMillis = completedAt
                )
            )
        }
    }

    fun updateTask(task: TaskEntity) {
        if (task.title.isBlank()) return
        viewModelScope.launch {
            val completedAt = when {
                task.status == TaskStatus.DONE.name && task.completedAtMillis == null -> System.currentTimeMillis()
                task.status != TaskStatus.DONE.name -> null
                else -> task.completedAtMillis
            }
            repository.updateTask(
                task.copy(
                    title = task.title.trim(),
                    description = task.description.trim(),
                    assigneeName = task.assigneeName.trim(),
                    tag = task.tag.trim(),
                    completedAtMillis = completedAt
                )
            )
        }
    }

    fun duplicateTask(task: TaskEntity) {
        viewModelScope.launch { repository.duplicateTask(task) }
    }

    fun toggleBookmarkTask(task: TaskEntity) {
        viewModelScope.launch {
            repository.updateTask(task.copy(bookmarked = !task.bookmarked))
        }
    }

    fun moveTaskStatus(task: TaskEntity, newStatus: TaskStatus) {
        viewModelScope.launch {
            val completedAt = if (newStatus == TaskStatus.DONE) System.currentTimeMillis() else null
            repository.updateTask(
                task.copy(
                    status = newStatus.name,
                    completedAtMillis = completedAt
                )
            )
        }
    }

    fun toggleTaskDone(task: TaskEntity) {
        val current = TaskStatus.fromName(task.status)
        val next = if (current == TaskStatus.DONE) TaskStatus.TODO else TaskStatus.DONE
        moveTaskStatus(task, next)
    }

    fun deleteTask(taskId: Long) {
        viewModelScope.launch { repository.deleteTask(taskId) }
    }

    fun addSubtask(taskId: Long, title: String) {
        if (title.isBlank()) return
        viewModelScope.launch {
            repository.insertSubtask(SubtaskEntity(taskId = taskId, title = title.trim()))
        }
    }

    fun toggleSubtask(subtask: SubtaskEntity) {
        viewModelScope.launch {
            repository.updateSubtask(subtask.copy(isCompleted = !subtask.isCompleted))
        }
    }

    fun deleteSubtask(subtask: SubtaskEntity) {
        viewModelScope.launch { repository.deleteSubtask(subtask) }
    }

    fun addMilestone(projectId: Long, title: String, targetDateMillis: Long?) {
        if (title.isBlank()) return
        viewModelScope.launch {
            repository.insertMilestone(
                MilestoneEntity(
                    projectId = projectId,
                    title = title.trim(),
                    targetDateMillis = targetDateMillis
                )
            )
        }
    }

    fun toggleMilestone(milestone: MilestoneEntity) {
        viewModelScope.launch {
            repository.updateMilestone(milestone.copy(isCompleted = !milestone.isCompleted))
        }
    }

    fun deleteMilestone(milestone: MilestoneEntity) {
        viewModelScope.launch { repository.deleteMilestone(milestone) }
    }

    fun loadStarterTemplate() {
        viewModelScope.launch { repository.seedStarterWorkspace() }
    }

    fun createFromTemplate(template: ProjectTemplateType, onCreated: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val id = repository.createProjectFromTemplate(template)
            onCreated(id)
        }
    }

    suspend fun buildMarkdownReport(projectId: Long? = null): String =
        repository.buildMarkdownReport(projectId)

    suspend fun exportWorkspaceJson(): String =
        repository.exportWorkspaceJson()

    suspend fun importWorkspaceJson(rawJson: String): Result<Int> = try {
        Result.success(repository.importWorkspaceJson(rawJson))
    } catch (e: Exception) {
        Result.failure(e)
    }

    // Focus Timer Controls
    fun selectFocusTask(taskId: Long?) {
        _focusTimer.update { it.copy(selectedTaskId = taskId, justCompletedMessage = null) }
    }

    fun setFocusDuration(minutes: Int) {
        timerJob?.cancel()
        _focusTimer.update {
            it.copy(
                durationMinutes = minutes,
                remainingSeconds = minutes * 60,
                isRunning = false,
                justCompletedMessage = null
            )
        }
    }

    fun toggleFocusTimer() {
        val current = _focusTimer.value
        if (current.isRunning) pauseFocusTimer() else startFocusTimer()
    }

    private fun startFocusTimer() {
        if (_focusTimer.value.remainingSeconds <= 0) {
            _focusTimer.update { it.copy(remainingSeconds = it.durationMinutes * 60) }
        }
        _focusTimer.update { it.copy(isRunning = true, justCompletedMessage = null) }
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (_focusTimer.value.isRunning && _focusTimer.value.remainingSeconds > 0) {
                delay(1000L)
                _focusTimer.update { state ->
                    state.copy(remainingSeconds = (state.remainingSeconds - 1).coerceAtLeast(0))
                }
                if (_focusTimer.value.remainingSeconds == 0) {
                    finishFocusSessionInternal(completedFull = true)
                    break
                }
            }
        }
    }

    fun pauseFocusTimer() {
        timerJob?.cancel()
        _focusTimer.update { it.copy(isRunning = false) }
    }

    fun resetFocusTimer() {
        timerJob?.cancel()
        _focusTimer.update {
            it.copy(
                isRunning = false,
                remainingSeconds = it.durationMinutes * 60,
                justCompletedMessage = null
            )
        }
    }

    fun logElapsedFocusNow() {
        val state = _focusTimer.value
        val elapsedMinutes = ((state.durationMinutes * 60 - state.remainingSeconds) / 60).coerceAtLeast(1)
        timerJob?.cancel()
        viewModelScope.launch {
            val task = workspaceState.value.tasks.firstOrNull { it.task.id == state.selectedTaskId }?.task
            repository.logFocusSession(taskId = task?.id, projectId = task?.projectId, minutes = elapsedMinutes)
            _focusTimer.update {
                it.copy(
                    isRunning = false,
                    remainingSeconds = it.durationMinutes * 60,
                    justCompletedMessage = "جلسه تمرکز ثبت شد"
                )
            }
        }
    }

    private suspend fun finishFocusSessionInternal(completedFull: Boolean) {
        val state = _focusTimer.value
        val loggedMinutes = if (completedFull) state.durationMinutes else 1
        val task = workspaceState.value.tasks.firstOrNull { it.task.id == state.selectedTaskId }?.task
        repository.logFocusSession(taskId = task?.id, projectId = task?.projectId, minutes = loggedMinutes)
        _focusTimer.update {
            it.copy(
                isRunning = false,
                remainingSeconds = it.durationMinutes * 60,
                justCompletedMessage = "آفرین! جلسه تمرکز کامل و ثبت شد"
            )
        }
    }

    fun clearFocusMessage() {
        _focusTimer.update { it.copy(justCompletedMessage = null) }
    }

    class Factory(private val repository: ProjectRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(ProjectViewModel::class.java)) {
                return ProjectViewModel(repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
        }
    }
}
