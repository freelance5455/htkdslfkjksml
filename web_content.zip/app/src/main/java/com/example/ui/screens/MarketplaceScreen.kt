package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.Auction
import com.example.data.model.AuctionStatus
import com.example.data.model.BusinessAd
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.data.model.Wallet
import com.example.ui.components.BidderNumberChip
import com.example.ui.components.BusinessAdBanner
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.FeaturedBadge
import com.example.ui.components.LiveCountdownPill
import com.example.ui.components.LotImageDisplay
import com.example.ui.theme.MonoFontFamily
import com.example.util.AUCTION_CATEGORIES
import com.example.util.formatNaira

@Composable
fun MarketplaceScreen(
    auctionsState: UiState<List<Auction>>,
    adsState: UiState<List<BusinessAd>>,
    profile: UserProfile?,
    wallet: Wallet?,
    nowMillis: Long,
    isAdmin: Boolean,
    currentUserId: String,
    onOpenAuction: (String) -> Unit,
    onOpenWallet: () -> Unit,
    onSubmitAdInquiry: (businessName: String, budget: Long, message: String) -> Unit,
    onSeedShowcase: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }
    var showAdDialog by remember { mutableStateOf(false) }

    val allAuctions = (auctionsState as? UiState.Success)?.data ?: emptyList()
    val liveAuctions = remember(allAuctions, nowMillis, searchQuery, selectedCategory) {
        allAuctions.filter { lot ->
            val st = lot.effectiveStatus(nowMillis)
            val isFloorVisible = st == AuctionStatus.ACTIVE || st == AuctionStatus.PAUSED
            val matchesCat = selectedCategory == "All" || lot.category.equals(selectedCategory, ignoreCase = true)
            val matchesQuery = searchQuery.isBlank() ||
                lot.title.contains(searchQuery, ignoreCase = true) ||
                lot.description.contains(searchQuery, ignoreCase = true) ||
                lot.category.contains(searchQuery, ignoreCase = true)
            isFloorVisible && matchesCat && matchesQuery
        }
    }
    val featuredLots = remember(liveAuctions) { liveAuctions.filter { it.featured } }
    val ads = (adsState as? UiState.Success)?.data ?: emptyList()

    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Top Identity Bar: Bidder Number + Wallet Balance
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "True A Live Floor",
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "Your Bidder ID:",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            BidderNumberChip(
                                bidderNumber = profile?.bidderNumber?.ifBlank { "TA-…" } ?: "TA-…",
                                isLeadingMe = true
                            )
                        }
                    }

                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .clickable(onClick = onOpenWallet)
                            .testTag("marketplace_wallet_pill")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccountBalanceWallet,
                                contentDescription = "Wallet balance",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = formatNaira(wallet?.availableBalance ?: 0L),
                                style = MaterialTheme.typography.labelLarge.copy(fontFamily = MonoFontFamily),
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                }
            }

            // Search bar
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search watches, art, collectibles…") },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = "Search auctions")
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear search")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("marketplace_search_input")
                )
            }

            // Category chips
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(AUCTION_CATEGORIES) { category ->
                        FilterChip(
                            selected = selectedCategory == category,
                            onClick = { selectedCategory = category },
                            label = { Text(category) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            )
                        )
                    }
                }
            }

            // Featured Lots Carousel
            if (featuredLots.isNotEmpty()) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Featured Auctions",
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = "₦2,000 Spotlight",
                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            items(featuredLots, key = { "feat_${it.id}" }) { lot ->
                                FeaturedLotCard(
                                    lot = lot,
                                    nowMillis = nowMillis,
                                    currentUserId = currentUserId,
                                    onClick = { onOpenAuction(lot.id) }
                                )
                            }
                        }
                    }
                }
            }

            // Negotiated Business Ad Banner
            item {
                BusinessAdBanner(
                    ad = ads.firstOrNull(),
                    onNegotiateClick = { showAdDialog = true }
                )
            }

            // Live Auction Feed Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Live Auction Lots (${liveAuctions.size})",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "3% Fee",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            when (auctionsState) {
                is UiState.Loading -> {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(36.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator()
                        }
                    }
                }
                is UiState.Error -> {
                    item {
                        EmptyStateCard(
                            title = "Could not sync live floor",
                            subtitle = auctionsState.message
                        )
                    }
                }
                is UiState.Success -> {
                    if (liveAuctions.isEmpty()) {
                        item {
                            EmptyStateCard(
                                title = "No live lots match your filter",
                                subtitle = if (isAdmin) {
                                    "Seed curated showcase auctions with live timers and featured placement, or create a lot in the Sell tab."
                                } else {
                                    "Check back soon or tap the Sell tab to list an item for real-time bidding."
                                },
                                actionLabel = if (isAdmin) "Seed Showcase Auctions" else null,
                                onAction = if (isAdmin) onSeedShowcase else null
                            )
                        }
                    } else {
                        items(liveAuctions, key = { it.id }) { lot ->
                            LiveAuctionCard(
                                lot = lot,
                                nowMillis = nowMillis,
                                currentUserId = currentUserId,
                                onClick = { onOpenAuction(lot.id) }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showAdDialog) {
        NegotiateAdDialog(
            onDismiss = { showAdDialog = false },
            onSubmit = { name, budget, msg ->
                onSubmitAdInquiry(name, budget, msg)
                showAdDialog = false
            }
        )
    }
}

@Composable
private fun FeaturedLotCard(
    lot: Auction,
    nowMillis: Long,
    currentUserId: String,
    onClick: () -> Unit
) {
    val displayBid = if (lot.bidCount > 0L) lot.currentBid else lot.startingBid
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        modifier = Modifier
            .width(286.dp)
            .clickable(onClick = onClick)
            .testTag("featured_lot_${lot.id}")
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(162.dp)
            ) {
                LotImageDisplay(
                    imageSpec = lot.imageItems.firstOrNull(),
                    contentDescription = lot.title,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, Color.Black.copy(alpha = 0.65f))
                            )
                        )
                )
                FeaturedBadge(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(12.dp)
                )
                LiveCountdownPill(
                    endsAt = lot.endsAt,
                    nowMillis = nowMillis,
                    status = lot.status,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(12.dp)
                )
                Text(
                    text = lot.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(14.dp)
                )
            }
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (lot.bidCount > 0L) "CURRENT BID" else "STARTING BID",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = formatNaira(displayBid),
                            style = MaterialTheme.typography.titleLarge.copy(fontFamily = MonoFontFamily),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = "${lot.bidCount} bids",
                            style = MaterialTheme.typography.labelMedium,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Highest Bidder",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (lot.highestBidderNumber.isNotBlank()) {
                        BidderNumberChip(
                            bidderNumber = lot.highestBidderNumber,
                            isLeadingMe = lot.highestBidderId == currentUserId
                        )
                    } else {
                        Text(
                            text = "No bids yet",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LiveAuctionCard(
    lot: Auction,
    nowMillis: Long,
    currentUserId: String,
    onClick: () -> Unit
) {
    val displayBid = if (lot.bidCount > 0L) lot.currentBid else lot.startingBid
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("auction_card_${lot.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(106.dp)
                    .clip(RoundedCornerShape(16.dp))
            ) {
                LotImageDisplay(
                    imageSpec = lot.imageItems.firstOrNull(),
                    contentDescription = lot.title,
                    modifier = Modifier.fillMaxSize()
                )
                if (lot.featured) {
                    FeaturedBadge(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(6.dp)
                    )
                }
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = lot.category.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary,
                        fontWeight = FontWeight.Bold
                    )
                    LiveCountdownPill(
                        endsAt = lot.endsAt,
                        nowMillis = nowMillis,
                        status = lot.status
                    )
                }

                Text(
                    text = lot.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Column {
                        Text(
                            text = if (lot.bidCount > 0L) "Current (${lot.bidCount} bids)" else "Opening Bid",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = formatNaira(displayBid),
                            style = MaterialTheme.typography.titleMedium.copy(fontFamily = MonoFontFamily),
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    if (lot.highestBidderNumber.isNotBlank()) {
                        BidderNumberChip(
                            bidderNumber = lot.highestBidderNumber,
                            isLeadingMe = lot.highestBidderId == currentUserId
                        )
                    } else {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Gavel,
                                    contentDescription = "Place first bid",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = "Bid First",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NegotiateAdDialog(
    onDismiss: () -> Unit,
    onSubmit: (businessName: String, budget: Long, message: String) -> Unit
) {
    var businessName by remember { mutableStateOf("") }
    var budgetText by remember { mutableStateOf("50000") }
    var message by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Negotiate Business Advertising") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Business advertising rates on True A are custom negotiated with Admin based on campaign reach.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = businessName,
                    onValueChange = { businessName = it },
                    label = { Text("Business Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = budgetText,
                    onValueChange = { budgetText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Proposed Budget (₦)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = message,
                    onValueChange = { message = it },
                    label = { Text("Campaign Goals & Placement") },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSubmit(
                        businessName.trim(),
                        budgetText.toLongOrNull() ?: 0L,
                        message.trim()
                    )
                },
                enabled = businessName.trim().length >= 2 && message.trim().length >= 5
            ) {
                Text("Send Proposal")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
