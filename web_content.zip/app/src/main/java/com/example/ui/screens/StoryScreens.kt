package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.ArkFeedIds
import com.example.data.model.ArkGroup
import com.example.data.model.ArkStory
import com.example.data.model.StoryHighlight
import com.example.data.model.StoryReaction
import com.example.data.model.StoryViewer
import com.example.data.model.UserProfile
import com.example.ui.components.ArkAvatarBadge
import com.example.ui.components.ArkVideoPlayerView
import com.example.ui.components.formatPostTimestamp
import com.example.ui.theme.ArkThemeTokens
import com.example.util.ImageCompressionHelper
import com.example.util.PreparedArkVideo
import com.example.util.rememberDecodedImageBitmap
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun StoriesRail(
    profile: UserProfile,
    stories: List<ArkStory>,
    viewedStoryIds: Set<String>,
    onAddStoryClick: () -> Unit,
    onOpenStory: (ArkStory) -> Unit
) {
    val colors = ArkThemeTokens.colors
    val distinctByAuthor = remember(stories) {
        stories.groupBy { it.authorId }.map { (_, list) -> list.first() }
    }

    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(key = "add_story") {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .width(72.dp)
                    .clickable(onClick = onAddStoryClick)
                    .testTag("add_story_button")
            ) {
                Box(contentAlignment = Alignment.BottomEnd) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .border(2.dp, colors.accent.copy(alpha = 0.7f), CircleShape)
                            .padding(3.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        ArkAvatarBadge(
                            avatarPreset = profile.avatarPreset,
                            username = profile.username,
                            imageBase64 = profile.avatarImageBase64,
                            size = 56.dp
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(colors.accent)
                            .border(2.dp, colors.background, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add Story", tint = Color.White, modifier = Modifier.size(14.dp))
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text("Your Story", style = MaterialTheme.typography.labelSmall, color = colors.ink, maxLines = 1)
            }
        }

        items(distinctByAuthor, key = { it.id }) { story ->
            val seen = viewedStoryIds.contains(story.id)
            val ringBrush = if (seen) {
                Brush.linearGradient(listOf(colors.ink3.copy(alpha = 0.45f), colors.hairline))
            } else {
                Brush.linearGradient(listOf(colors.accent, colors.coral, colors.gold))
            }
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .width(72.dp)
                    .clickable { onOpenStory(story) }
                    .testTag("story_circle_${story.authorId}")
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .border(2.5.dp, ringBrush, CircleShape)
                        .padding(4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    ArkAvatarBadge(
                        avatarPreset = story.authorAvatar,
                        username = story.authorUsername,
                        size = 54.dp
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    text = if (story.authorId == profile.userId) "You" else story.authorUsername,
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.ink,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddStoryDialog(
    profile: UserProfile,
    groups: List<ArkGroup>,
    hideCandidates: List<Pair<String, String>> = emptyList(),
    onDismiss: () -> Unit,
    onCreateStory: (
        mediaType: String,
        imageBase64: String,
        caption: String,
        visibility: String,
        selectedGroups: List<ArkGroup>,
        hiddenFromUids: List<String>,
        videoDurationMs: Long,
        videoChunks: List<String>
    ) -> Unit
) {
    val colors = ArkThemeTokens.colors
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var imageBase64 by remember { mutableStateOf<String?>(null) }
    var preparedVideo by remember { mutableStateOf<PreparedArkVideo?>(null) }
    var caption by remember { mutableStateOf("") }
    val canPublic = profile.ageBracket != "under_13" && !profile.isPrivateAccount
    var visibility by remember { mutableStateOf("friends") }
    var selectedGroupId by remember { mutableStateOf(groups.firstOrNull()?.id) }
    val hiddenUids = remember {
        mutableStateListOf<String>().apply { addAll(profile.hiddenStoryFromUids) }
    }
    var showHidePicker by remember { mutableStateOf(false) }
    var isProcessingVideo by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                errorMsg = null
                preparedVideo = null
                imageBase64 = ImageCompressionHelper.compressUriToBase64(context, uri, maxDim = 480, maxBytes = 45_000)
            }
        }
    }

    val videoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                isProcessingVideo = true
                errorMsg = null
                ImageCompressionHelper.extractVideoForArk(context, uri)
                    .onSuccess {
                        preparedVideo = it
                        imageBase64 = it.thumbnailBase64
                    }
                    .onFailure { errorMsg = it.message ?: "Could not load video." }
                isProcessingVideo = false
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Share a 24h Story") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        enabled = !isProcessingVideo,
                        onClick = { imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = null)
                        Spacer(Modifier.width(4.dp))
                        Text("Photo")
                    }
                    OutlinedButton(
                        enabled = !isProcessingVideo,
                        onClick = { videoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Videocam, contentDescription = null)
                        Spacer(Modifier.width(4.dp))
                        Text(if (isProcessingVideo) "Loading..." else "Video")
                    }
                }
                if (isProcessingVideo) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = colors.accent)
                        Text("Preparing video...", style = MaterialTheme.typography.bodySmall, color = colors.ink2)
                    }
                }
                if (errorMsg != null) {
                    Text(errorMsg!!, color = colors.coral, style = MaterialTheme.typography.bodySmall)
                }
                if (!imageBase64.isNullOrBlank()) {
                    val bmp = rememberDecodedImageBitmap(imageBase64)
                    if (bmp != null) {
                        Image(
                            bitmap = bmp,
                            contentDescription = "Story preview",
                            modifier = Modifier.fillMaxWidth().height(130.dp).clip(RoundedCornerShape(14.dp)),
                            contentScale = ContentScale.Crop
                        )
                    }
                }
                OutlinedTextField(
                    value = caption,
                    onValueChange = { caption = it.take(140) },
                    label = { Text("Story caption (optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    FilterChip(selected = visibility == "friends", onClick = { visibility = "friends" }, label = { Text("Friends") })
                    FilterChip(selected = visibility == "followers", onClick = { visibility = "followers" }, label = { Text("Followers") })
                    FilterChip(selected = visibility == "group", onClick = { visibility = "group" }, label = { Text("Squad") })
                    FilterChip(selected = visibility == "public", enabled = canPublic, onClick = { if (canPublic) visibility = "public" }, label = { Text("Public") })
                }
                if (visibility == "group" && groups.isNotEmpty()) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(groups, key = { it.id }) { g ->
                            FilterChip(
                                selected = selectedGroupId == g.id,
                                onClick = { selectedGroupId = g.id },
                                label = { Text(g.name) }
                            )
                        }
                    }
                }
                if (hideCandidates.isNotEmpty()) {
                    TextButton(onClick = { showHidePicker = !showHidePicker }) {
                        Text(
                            if (showHidePicker) "Done hiding (${hiddenUids.size})"
                            else "Hide story from (${hiddenUids.size})"
                        )
                    }
                    if (showHidePicker) {
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            hideCandidates.take(12).forEach { (uid, uname) ->
                                val hidden = hiddenUids.contains(uid)
                                FilterChip(
                                    selected = hidden,
                                    onClick = { if (hidden) hiddenUids.remove(uid) else hiddenUids.add(uid) },
                                    label = { Text("@$uname") }
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = !isProcessingVideo && !imageBase64.isNullOrBlank() && (visibility != "group" || selectedGroupId != null),
                onClick = {
                    val mediaType = if (preparedVideo != null) "video" else "image"
                    val grpList = groups.filter { it.id == selectedGroupId }
                    onCreateStory(
                        mediaType,
                        imageBase64!!,
                        caption,
                        visibility,
                        grpList,
                        hiddenUids.toList(),
                        preparedVideo?.durationMs ?: 0L,
                        preparedVideo?.chunksBase64 ?: emptyList()
                    )
                    onDismiss()
                }
            ) { Text("Post Story") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun StoryViewerScreen(
    stories: List<ArkStory>,
    initialStoryId: String,
    currentUser: UserProfile,
    activeViewers: List<StoryViewer>,
    activeReactions: List<StoryReaction> = emptyList(),
    myHighlights: List<StoryHighlight> = emptyList(),
    onMarkViewed: (ArkStory) -> Unit,
    onDeleteStory: (String) -> Unit,
    onReactToStory: (ArkStory, String) -> Unit = { _, _ -> },
    onReplyViaDm: (ArkStory, String) -> Unit = { _, _ -> },
    onSaveToNewHighlight: (title: String, story: ArkStory) -> Unit = { _, _ -> },
    onAddToExistingHighlight: (highlight: StoryHighlight, story: ArkStory) -> Unit = { _, _ -> },
    onOpenUserProfile: (String) -> Unit = {},
    onLoadStoryVideo: suspend (String) -> File?,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val colors = ArkThemeTokens.colors
    var currentIndex by remember(initialStoryId, stories.size) {
        mutableIntStateOf(stories.indexOfFirst { it.id == initialStoryId }.coerceAtLeast(0))
    }
    val story = stories.getOrNull(currentIndex)
    if (story == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }

    val isOwner = story.authorId == currentUser.userId
    var progress by remember(story.id) { mutableFloatStateOf(0f) }
    var videoFile by remember(story.id) { mutableStateOf<File?>(null) }
    var loadingVideo by remember(story.id) { mutableStateOf(story.mediaType == "video") }
    var showViewersSheet by remember { mutableStateOf(false) }
    var showHighlightDialog by remember { mutableStateOf(false) }
    var replyText by remember(story.id) { mutableStateOf("") }
    var newHighlightTitle by remember { mutableStateOf("") }
    val paused = showViewersSheet || showHighlightDialog || replyText.isNotEmpty()

    LaunchedEffect(story.id) {
        onMarkViewed(story)
        if (story.mediaType == "video") {
            loadingVideo = true
            videoFile = onLoadStoryVideo(story.id)
            loadingVideo = false
        }
        val durationMs = if (story.mediaType == "video" && story.videoDurationMs > 0L) story.videoDurationMs else 5500L
        val steps = 55
        for (i in 1..steps) {
            while (paused) delay(150L)
            progress = i.toFloat() / steps
            delay(durationMs / steps)
        }
        if (!paused) {
            if (currentIndex < stories.lastIndex) currentIndex++ else onBack()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        if (story.mediaType == "video") {
            ArkVideoPlayerView(
                videoFile = videoFile,
                thumbnailBase64 = story.imageBase64,
                isLoading = loadingVideo,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            val bmp = rememberDecodedImageBitmap(story.imageBase64)
            if (bmp != null) {
                Image(
                    bitmap = bmp,
                    contentDescription = "Story by @${story.authorUsername}",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit
                )
            }
        }

        if (story.mediaType != "video") {
            Row(modifier = Modifier.fillMaxSize()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable { if (currentIndex > 0) currentIndex-- }
                )
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable { if (currentIndex < stories.lastIndex) currentIndex++ else onBack() }
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.65f), Color.Transparent)))
                .padding(14.dp)
        ) {
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(3.dp).clip(RoundedCornerShape(2.dp)),
                color = colors.accent,
                trackColor = Color.White.copy(alpha = 0.3f)
            )
            Spacer(Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable {
                        onBack()
                        onOpenUserProfile(story.authorId)
                    }
                ) {
                    ArkAvatarBadge(avatarPreset = story.authorAvatar, username = story.authorUsername, size = 38.dp)
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text("@${story.authorUsername}", style = MaterialTheme.typography.titleSmall, color = Color.White)
                        Text("${formatPostTimestamp(story.createdAt)} • ${story.visibility}", style = MaterialTheme.typography.labelSmall, color = colors.accent)
                    }
                }
                Row {
                    if (isOwner) {
                        IconButton(
                            onClick = { showHighlightDialog = true },
                            modifier = Modifier.testTag("save_story_highlight_button")
                        ) {
                            Icon(Icons.Default.BookmarkAdd, contentDescription = "Save to Highlight", tint = Color.White)
                        }
                        IconButton(
                            onClick = { onDeleteStory(story.id) },
                            modifier = Modifier.testTag("delete_story_button")
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete story", tint = colors.coral)
                        }
                    }
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.Close, contentDescription = "Close story", tint = Color.White)
                    }
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.78f))))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (story.caption.isNotBlank()) {
                Text(story.caption, style = MaterialTheme.typography.bodyLarge, color = Color.White)
            }
            if (isOwner) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = Color.White.copy(alpha = 0.16f),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.35f)),
                        modifier = Modifier
                            .clickable { showViewersSheet = true }
                            .testTag("story_viewers_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Visibility, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("${maxOf(story.viewerCount, activeViewers.size.toLong())} Viewers", style = MaterialTheme.typography.labelLarge, color = Color.White)
                        }
                    }
                    if (activeReactions.isNotEmpty()) {
                        Text(
                            text = "${activeReactions.size} reactions",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("love", "fire", "laugh", "clap").forEach { key ->
                        Surface(
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.16f),
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .clickable { onReactToStory(story, key) }
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(ArkFeedIds.reactionEmoji(key), fontSize = 18.sp)
                            }
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = replyText,
                        onValueChange = { replyText = it.take(300) },
                        placeholder = { Text("Reply to @${story.authorUsername}...", color = Color.White.copy(alpha = 0.7f)) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color.White,
                            unfocusedBorderColor = Color.White.copy(alpha = 0.45f)
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(8.dp))
                    IconButton(
                        enabled = replyText.trim().isNotBlank(),
                        onClick = {
                            onReplyViaDm(story, replyText)
                            replyText = ""
                        }
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send story reply", tint = Color.White)
                    }
                }
            }
        }
    }

    if (showViewersSheet && isOwner) {
        AlertDialog(
            onDismissRequest = { showViewersSheet = false },
            title = { Text("Story Viewers (Owner Only)") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (activeViewers.isEmpty()) {
                        Text("No viewers recorded yet.")
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxWidth().heightIn(max = 260.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(activeViewers, key = { it.viewerUid }) { v ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    ArkAvatarBadge(avatarPreset = v.viewerAvatar, username = v.viewerUsername, size = 32.dp)
                                    Spacer(Modifier.width(8.dp))
                                    Column {
                                        Text("@${v.viewerUsername}", style = MaterialTheme.typography.titleSmall)
                                        Text(formatPostTimestamp(v.viewedAt), style = MaterialTheme.typography.labelSmall, color = colors.ink2)
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showViewersSheet = false }) { Text("Done") }
            }
        )
    }

    if (showHighlightDialog && isOwner) {
        AlertDialog(
            onDismissRequest = { showHighlightDialog = false },
            title = { Text("Save to Profile Highlight") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newHighlightTitle,
                        onValueChange = { newHighlightTitle = it.take(30) },
                        label = { Text("New Highlight title") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedButton(
                        enabled = newHighlightTitle.trim().isNotBlank(),
                        onClick = {
                            onSaveToNewHighlight(newHighlightTitle.trim(), story)
                            newHighlightTitle = ""
                            showHighlightDialog = false
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Create Highlight")
                    }
                    if (myHighlights.isNotEmpty()) {
                        Text("Or add to existing:", style = MaterialTheme.typography.labelMedium, color = colors.ink2)
                        myHighlights.forEach { hl ->
                            OutlinedButton(
                                onClick = {
                                    onAddToExistingHighlight(hl, story)
                                    showHighlightDialog = false
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("${hl.title} (${hl.slides.size})")
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showHighlightDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun HighlightsRow(
    highlights: List<StoryHighlight>,
    isOwnProfile: Boolean,
    onOpenHighlight: (StoryHighlight) -> Unit,
    onCreateHint: () -> Unit = {}
) {
    val colors = ArkThemeTokens.colors
    if (highlights.isEmpty() && !isOwnProfile) return

    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(horizontal = 4.dp)
    ) {
        if (isOwnProfile) {
            item(key = "add_highlight_chip") {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .width(68.dp)
                        .clickable { onCreateHint() }
                ) {
                    Box(
                        modifier = Modifier
                            .size(58.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, colors.hairline, CircleShape)
                            .background(colors.surfaceSecondary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Create Highlight", tint = colors.ink)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text("New", style = MaterialTheme.typography.labelSmall, color = colors.ink2, maxLines = 1)
                }
            }
        }
        items(highlights, key = { it.id }) { hl ->
            val coverBmp = rememberDecodedImageBitmap(hl.coverImageBase64)
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .width(68.dp)
                    .clickable { onOpenHighlight(hl) }
            ) {
                Box(
                    modifier = Modifier
                        .size(58.dp)
                        .clip(CircleShape)
                        .border(2.dp, colors.accent.copy(alpha = 0.55f), CircleShape)
                        .padding(3.dp)
                        .clip(CircleShape)
                        .background(colors.surfaceSecondary),
                    contentAlignment = Alignment.Center
                ) {
                    if (coverBmp != null) {
                        Image(
                            bitmap = coverBmp,
                            contentDescription = hl.title,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text(hl.title, style = MaterialTheme.typography.labelSmall, color = colors.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
fun HighlightViewerDialog(
    highlight: StoryHighlight,
    isOwner: Boolean,
    onRename: (String) -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit
) {
    BackHandler(onBack = onDismiss)
    var slideIdx by remember(highlight.id) { mutableIntStateOf(0) }
    val slide = highlight.slides.getOrNull(slideIdx)
    var showRename by remember { mutableStateOf(false) }
    var renameText by remember(highlight.id) { mutableStateOf(highlight.title) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            if (slide != null) {
                val bmp = rememberDecodedImageBitmap(slide.imageBase64)
                if (bmp != null) {
                    Image(
                        bitmap = bmp,
                        contentDescription = slide.caption.ifBlank { highlight.title },
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                }
            }
            Row(modifier = Modifier.fillMaxSize()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable { if (slideIdx > 0) slideIdx-- }
                )
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable { if (slideIdx < highlight.slides.lastIndex) slideIdx++ else onDismiss() }
                )
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.65f), Color.Transparent)))
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(highlight.title, style = MaterialTheme.typography.titleMedium, color = Color.White)
                    Text("Slide ${slideIdx + 1}/${highlight.slides.size.coerceAtLeast(1)}", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.7f))
                }
                Row {
                    if (isOwner) {
                        TextButton(onClick = { showRename = true }) { Text("Rename", color = Color.White) }
                        IconButton(onClick = { onDelete(); onDismiss() }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete highlight", tint = Color(0xFFFF6B6B))
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close highlight", tint = Color.White)
                    }
                }
            }
            if (slide != null && slide.caption.isNotBlank()) {
                Text(
                    text = slide.caption,
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.5f))
                        .padding(16.dp)
                )
            }
        }
    }

    if (showRename) {
        AlertDialog(
            onDismissRequest = { showRename = false },
            title = { Text("Rename Highlight") },
            text = {
                OutlinedTextField(
                    value = renameText,
                    onValueChange = { renameText = it.take(30) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(
                    enabled = renameText.trim().isNotBlank(),
                    onClick = {
                        onRename(renameText.trim())
                        showRename = false
                    }
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showRename = false }) { Text("Cancel") }
            }
        )
    }
}
