package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.models.UserAccount
import com.example.ui.theme.HazimCyan
import com.example.ui.theme.HazimDarkBorder
import com.example.ui.theme.HazimDarkSurface
import com.example.ui.theme.HazimDarkSurfaceVariant
import com.example.ui.theme.HazimPurple
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark

enum class AuthDialogStep {
    MAIN_CHOICES,
    PROVIDER_ACCOUNT_PICKER,
    ADD_CUSTOM_ACCOUNT
}

@Composable
fun AuthDialog(
    isOpen: Boolean,
    onDismiss: () -> Unit,
    onGetAccountsForProvider: (String) -> List<UserAccount>,
    onLoginSuccess: (provider: String, email: String, name: String) -> Unit
) {
    if (!isOpen) return

    var currentStep by remember { mutableStateOf(AuthDialogStep.MAIN_CHOICES) }
    var selectedProvider by remember { mutableStateOf("Google") }
    var emailInput by remember { mutableStateOf("hazimqadir7@gmail.com") }
    var passwordInput by remember { mutableStateOf("••••••••") }

    var customAccountName by remember { mutableStateOf("") }
    var customAccountEmail by remember { mutableStateOf("") }

    Dialog(onDismissRequest = {
        currentStep = AuthDialogStep.MAIN_CHOICES
        onDismiss()
    }) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .border(1.dp, HazimDarkBorder, RoundedCornerShape(24.dp)),
            color = HazimDarkSurface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                when (currentStep) {
                    AuthDialogStep.MAIN_CHOICES -> {
                        // Top Header with close button
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(Brush.linearGradient(listOf(HazimCyan, HazimPurple))),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "H",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 20.sp
                                )
                            }

                            Text(
                                text = "Sign in to HAZIM AI",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryDark
                            )

                            IconButton(
                                onClick = onDismiss,
                                modifier = Modifier
                                    .size(32.dp)
                                    .testTag("auth_dialog_close_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Close",
                                    tint = TextSecondaryDark
                                )
                            }
                        }

                        Text(
                            text = "Choose an account to save your chat history, TTI images, ITV videos, and STV voices permanently.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondaryDark,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 8.dp, bottom = 18.dp)
                        )

                        // 1. Google Sign-in Button -> Opens Google Account Chooser
                        SocialLoginButton(
                            title = "Continue with Google",
                            subtitle = "Pick from your Google accounts",
                            badgeColor = Color(0xFF4285F4),
                            badgeLetter = "G",
                            testTag = "login_google_button",
                            onClick = {
                                selectedProvider = "Google"
                                currentStep = AuthDialogStep.PROVIDER_ACCOUNT_PICKER
                            }
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // 2. Facebook Sign-in Button -> Opens Facebook Account Chooser
                        SocialLoginButton(
                            title = "Continue with Facebook",
                            subtitle = "Pick from Facebook accounts",
                            badgeColor = Color(0xFF1877F2),
                            badgeLetter = "f",
                            testTag = "login_facebook_button",
                            onClick = {
                                selectedProvider = "Facebook"
                                currentStep = AuthDialogStep.PROVIDER_ACCOUNT_PICKER
                            }
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // 3. Microsoft Sign-in Button -> Opens Microsoft Account Chooser
                        SocialLoginButton(
                            title = "Continue with Microsoft",
                            subtitle = "Pick from Microsoft accounts",
                            badgeColor = Color(0xFF00A4EF),
                            badgeLetter = "M",
                            testTag = "login_microsoft_button",
                            onClick = {
                                selectedProvider = "Microsoft"
                                currentStep = AuthDialogStep.PROVIDER_ACCOUNT_PICKER
                            }
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            HorizontalDivider(modifier = Modifier.weight(1f), color = HazimDarkBorder)
                            Text(
                                text = "  OR DIRECT EMAIL  ",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondaryDark
                            )
                            HorizontalDivider(modifier = Modifier.weight(1f), color = HazimDarkBorder)
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Email field
                        OutlinedTextField(
                            value = emailInput,
                            onValueChange = { emailInput = it },
                            label = { Text("Email address") },
                            leadingIcon = {
                                Icon(Icons.Default.Email, contentDescription = null, tint = HazimCyan)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("auth_email_input"),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Password field
                        OutlinedTextField(
                            value = passwordInput,
                            onValueChange = { passwordInput = it },
                            label = { Text("Password") },
                            visualTransformation = PasswordVisualTransformation(),
                            leadingIcon = {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = HazimPurple)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("auth_password_input"),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = {
                                val name = emailInput.substringBefore("@").replace(".", " ")
                                    .split(" ").joinToString(" ") { it.replaceFirstChar(Char::uppercaseChar) }
                                onLoginSuccess("Email", emailInput, name)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("auth_submit_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = HazimCyan,
                                contentColor = Color.Black
                            )
                        ) {
                            Text(text = "Sign In with Email", fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        TextButton(
                            onClick = {
                                onLoginSuccess("Guest", "guest@hazimai.com", "Hazim Guest")
                            },
                            modifier = Modifier.testTag("auth_guest_button")
                        ) {
                            Text(
                                text = "Continue as Guest Member",
                                color = TextSecondaryDark,
                                fontSize = 12.sp
                            )
                        }
                    }

                    AuthDialogStep.PROVIDER_ACCOUNT_PICKER -> {
                        // Header with back button
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { currentStep = AuthDialogStep.MAIN_CHOICES }) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimaryDark)
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Choose an account",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = TextPrimaryDark
                                )
                                Text(
                                    text = "to continue to HAZIM AI ($selectedProvider)",
                                    fontSize = 12.sp,
                                    color = TextSecondaryDark
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        val accounts = onGetAccountsForProvider(selectedProvider)

                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(if (accounts.size > 2) 220.dp else 160.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(accounts) { account ->
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .border(1.dp, HazimDarkBorder, RoundedCornerShape(12.dp))
                                        .clickable {
                                            onLoginSuccess(selectedProvider, account.email, account.name)
                                        },
                                    color = HazimDarkSurfaceVariant
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    when (selectedProvider) {
                                                        "Google" -> Color(0xFF4285F4)
                                                        "Facebook" -> Color(0xFF1877F2)
                                                        else -> Color(0xFF00A4EF)
                                                    }
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = account.name.take(1).uppercase(),
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 16.sp
                                            )
                                        }

                                        Spacer(modifier = Modifier.width(12.dp))

                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = account.name,
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 14.sp,
                                                color = TextPrimaryDark
                                            )
                                            Text(
                                                text = account.email,
                                                fontSize = 12.sp,
                                                color = TextSecondaryDark
                                            )
                                        }

                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = HazimCyan,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Option to add / use another account
                        OutlinedButton(
                            onClick = {
                                customAccountName = ""
                                customAccountEmail = ""
                                currentStep = AuthDialogStep.ADD_CUSTOM_ACCOUNT
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = HazimCyan)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "Use another $selectedProvider account", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }

                    AuthDialogStep.ADD_CUSTOM_ACCOUNT -> {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { currentStep = AuthDialogStep.PROVIDER_ACCOUNT_PICKER }) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimaryDark)
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Add $selectedProvider Account",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = TextPrimaryDark
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        OutlinedTextField(
                            value = customAccountName,
                            onValueChange = { customAccountName = it },
                            label = { Text("Full Name") },
                            placeholder = { Text("e.g. Hazim Qadir") },
                            leadingIcon = {
                                Icon(Icons.Default.Person, contentDescription = null, tint = HazimCyan)
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = customAccountEmail,
                            onValueChange = { customAccountEmail = it },
                            label = { Text("$selectedProvider Email / User ID") },
                            placeholder = {
                                Text(
                                    when (selectedProvider) {
                                        "Google" -> "example@gmail.com"
                                        "Facebook" -> "username@facebook.com"
                                        else -> "user@outlook.com"
                                    }
                                )
                            },
                            leadingIcon = {
                                Icon(Icons.Default.Email, contentDescription = null, tint = HazimPurple)
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                if (customAccountEmail.isNotBlank()) {
                                    val name = if (customAccountName.isNotBlank()) customAccountName else customAccountEmail.substringBefore("@")
                                    onLoginSuccess(selectedProvider, customAccountEmail.trim(), name.trim())
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp),
                            shape = RoundedCornerShape(12.dp),
                            enabled = customAccountEmail.isNotBlank(),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = HazimCyan,
                                contentColor = Color.Black
                            )
                        ) {
                            Text(text = "Sign In & Save Activity", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SocialLoginButton(
    title: String,
    subtitle: String,
    badgeColor: Color,
    badgeLetter: String,
    testTag: String,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, HazimDarkBorder, RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .testTag(testTag),
        color = HazimDarkSurfaceVariant
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(badgeColor),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = badgeLetter,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryDark
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondaryDark,
                    fontSize = 11.sp
                )
            }
        }
    }
}
