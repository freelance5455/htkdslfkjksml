package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.example.ui.theme.CandleGlow
import com.example.ui.theme.CandleNightDark
import com.example.ui.theme.CandleOrange

/**
 * CandlelitSanctuaryOverlay:
 * Provides a deep nighttime meditation aura with gently flickering candlelight and rising embers.
 */
@Composable
fun CandlelitSanctuaryOverlay(
    isCandlelitMode: Boolean,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = isCandlelitMode,
        enter = fadeIn(tween(800)),
        exit = fadeOut(tween(800)),
        modifier = modifier
    ) {
        val infiniteTransition = rememberInfiniteTransition(label = "candle_sanctuary")

        val flameFlicker by infiniteTransition.animateFloat(
            initialValue = 0.65f,
            targetValue = 1.0f,
            animationSpec = infiniteRepeatable(
                animation = tween(1400, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "flameFlicker"
        )

        val emberRising by infiniteTransition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(4000, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "emberRising"
        )

        Box(modifier = Modifier.fillMaxSize()) {
            // Ambient deep vignette
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                CandleGlow.copy(alpha = 0.15f * flameFlicker),
                                CandleOrange.copy(alpha = 0.08f * flameFlicker),
                                CandleNightDark.copy(alpha = 0.65f)
                            ),
                            radius = 1000f
                        )
                    )
            )

            // Rising golden ember particles
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height

                val embers = listOf(
                    Triple(w * 0.25f, h * 0.85f, 2.0f),
                    Triple(w * 0.45f, h * 0.75f, 2.5f),
                    Triple(w * 0.65f, h * 0.80f, 1.8f),
                    Triple(w * 0.80f, h * 0.90f, 2.2f),
                    Triple(w * 0.35f, h * 0.95f, 1.5f)
                )

                for ((x, startY, radius) in embers) {
                    val y = (startY - (emberRising * h * 0.4f)) % h
                    val alpha = (1f - (startY - y) / (h * 0.4f)).coerceIn(0f, 1f)
                    drawCircle(
                        color = CandleGlow.copy(alpha = alpha * 0.75f * flameFlicker),
                        radius = radius,
                        center = Offset(x, y)
                    )
                }
            }
        }
    }
}
