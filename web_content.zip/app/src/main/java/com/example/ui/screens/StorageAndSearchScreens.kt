package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.RestoreFromTrash
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.ByteSizeFormatter
import com.example.data.local.TrashEntity
import com.example.data.model.FileCategory
import com.example.data.model.FileNode
import com.example.data.model.StorageAnalysisReport
import com.example.ui.components.FileTypeThumbnail
import com.example.ui.components.resolveCategoryVisual
import com.example.ui.theme.LocalAnimationSpecs
import com.example.ui.viewmodel.AiTaskState
import com.example.ui.viewmodel.SearchFilters
import com.example.ui.viewmodel.SmartSearchInterpretation

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalyzeStorageScreen(
    report: StorageAnalysisReport?,
    onCleanNodesToTrash: (List<String>) -> Unit,
    onOpenNode: (FileNode) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val animSpecs = LocalAnimationSpecs.current
    val sweepProgress by animateFloatAsState(
        targetValue = if (report != null) 1f else 0f,
        animationSpec = animSpecs.progressSpec(),
        label = "donut_sweep"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Analyze storage", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("analyze_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        if (report == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Donut Chart Card
            item {
                Card(
                    shape = RoundedCornerShape(26.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .widthIn(max = 640.dp)
                        .fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        val totalCatBytes = report.categoryBreakdown.values.sum().coerceAtLeast(1L)
                        val trackColor = MaterialTheme.colorScheme.surfaceVariant

                        Box(
                            modifier = Modifier.size(190.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val strokeWidth = 24.dp.toPx()
                                drawArc(
                                    color = trackColor,
                                    startAngle = 0f,
                                    sweepAngle = 360f,
                                    useCenter = false,
                                    style = Stroke(width = strokeWidth)
                                )
                                var startAngle = -90f
                                FileCategory.entries.forEach { cat ->
                                    val catBytes = report.categoryBreakdown[cat] ?: 0L
                                    if (catBytes > 0L) {
                                        val (_, color) = resolveCategoryVisual(cat)
                                        val sweep = (catBytes.toFloat() / totalCatBytes.toFloat()) * 360f * sweepProgress
                                        drawArc(
                                            color = color,
                                            startAngle = startAngle,
                                            sweepAngle = sweep,
                                            useCenter = false,
                                            style = Stroke(width = strokeWidth, cap = StrokeCap.Butt)
                                        )
                                        startAngle += sweep
                                    }
                                }
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                val pct = if (report.totalDeviceBytes > 0L) {
                                    ((report.usedDeviceBytes * 100) / report.totalDeviceBytes).toInt()
                                } else 0
                                Text(
                                    text = "$pct%",
                                    style = MaterialTheme.typography.headlineMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = ByteSizeFormatter.formatUsedOfTotal(
                                        report.usedDeviceBytes,
                                        report.totalDeviceBytes
                                    ),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(Modifier.height(18.dp))
                        HorizontalDivider()
                        Spacer(Modifier.height(12.dp))

                        // Legend Breakdown
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            FileCategory.entries.forEach { cat ->
                                val (_, color) = resolveCategoryVisual(cat)
                                val bytes = report.categoryBreakdown[cat] ?: 0L
                                val count = report.categoryCounts[cat] ?: 0
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(10.dp)
                                                .clip(CircleShape)
                                                .background(color)
                                        )
                                        Spacer(Modifier.width(10.dp))
                                        Text(cat.label, style = MaterialTheme.typography.bodyMedium)
                                    }
                                    Text(
                                        "$count • ${ByteSizeFormatter.format(bytes)}",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Duplicate Files Cleanup Card
            item {
                val duplicateDuplicatesOnly = report.duplicateGroups.flatMap { it.drop(1) }
                CleanupSectionCard(
                    title = "Duplicate files",
                    subtitle = if (duplicateDuplicatesOnly.isEmpty()) {
                        "No exact SHA-256 duplicates detected across accessible folders"
                    } else {
                        "${duplicateDuplicatesOnly.size} redundant copy/copies (${ByteSizeFormatter.format(duplicateDuplicatesOnly.sumOf { it.sizeBytes })})"
                    },
                    files = duplicateDuplicatesOnly,
                    cleanButtonLabel = "Clean redundant copies",
                    onClean = { onCleanNodesToTrash(duplicateDuplicatesOnly.map { it.path }) },
                    onOpenNode = onOpenNode
                )
            }

            // Large Files Card
            item {
                CleanupSectionCard(
                    title = "Large files (> 5 MB)",
                    subtitle = if (report.largeFiles.isEmpty()) {
                        "No large files found in mounted roots"
                    } else {
                        "${report.largeFiles.size} file(s) • ${ByteSizeFormatter.format(report.largeFiles.sumOf { it.sizeBytes })}"
                    },
                    files = report.largeFiles,
                    cleanButtonLabel = "Move all to Trash",
                    onClean = { onCleanNodesToTrash(report.largeFiles.map { it.path }) },
                    onOpenNode = onOpenNode
                )
            }

            // Unused / Old Files Card
            item {
                CleanupSectionCard(
                    title = "Unused / Old files (> 30 days)",
                    subtitle = if (report.unusedOldFiles.isEmpty()) {
                        "No stale files older than 30 days"
                    } else {
                        "${report.unusedOldFiles.size} file(s) • ${ByteSizeFormatter.format(report.unusedOldFiles.sumOf { it.sizeBytes })}"
                    },
                    files = report.unusedOldFiles,
                    cleanButtonLabel = "Clean old files",
                    onClean = { onCleanNodesToTrash(report.unusedOldFiles.map { it.path }) },
                    onOpenNode = onOpenNode
                )
            }
        }
    }
}

@Composable
private fun CleanupSectionCard(
    title: String,
    subtitle: String,
    files: List<FileNode>,
    cleanButtonLabel: String,
    onClean: () -> Unit,
    onOpenNode: (FileNode) -> Unit
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .widthIn(max = 640.dp)
            .fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleMedium)
                    Text(
                        subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (files.isNotEmpty()) {
                    FilledTonalButton(onClick = onClean) {
                        Icon(Icons.Filled.CleaningServices, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Clean")
                    }
                }
            }

            files.take(5).forEach { f ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onOpenNode(f) }
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FileTypeThumbnail(node = f, size = 38.dp)
                    Spacer(Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(f.name, style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            ByteSizeFormatter.format(f.sizeBytes),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            if (files.isNotEmpty()) {
                OutlinedButton(
                    onClick = onClean,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(cleanButtonLabel)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrashScreen(
    trashItems: List<TrashEntity>,
    autoEmptyEnabled: Boolean,
    onRestore: (TrashEntity) -> Unit,
    onEmptyAll: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Trash", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("trash_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (trashItems.isNotEmpty()) {
                        FilledTonalButton(
                            onClick = onEmptyAll,
                            modifier = Modifier
                                .padding(end = 12.dp)
                                .testTag("empty_trash_button")
                        ) {
                            Icon(Icons.Filled.DeleteForever, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Empty")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (autoEmptyEnabled) {
                Text(
                    text = "Items in Trash are permanently deleted after 30 days.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
                )
            }

            if (trashItems.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        "No files in Trash",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(trashItems, key = { it.id }) { item ->
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.originalName, style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        "${ByteSizeFormatter.format(item.sizeBytes)} • Deleted ${ByteSizeFormatter.formatTimestamp(item.deletedAtEpochMs)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                FilledTonalButton(
                                    onClick = { onRestore(item) },
                                    modifier = Modifier.testTag("restore_trash_${item.id}")
                                ) {
                                    Icon(Icons.Filled.RestoreFromTrash, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Restore")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmartSearchScreen(
    filters: SearchFilters,
    results: List<FileNode>,
    aiState: AiTaskState<SmartSearchInterpretation>,
    showExtensions: Boolean,
    onUpdateFilters: (SearchFilters) -> Unit,
    onRunAiSmartSearch: (String) -> Unit,
    onOpenNode: (FileNode) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    var queryText by remember(filters.query) { mutableStateOf(filters.query) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Search & Gemini Smart Filter", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("search_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            OutlinedTextField(
                value = queryText,
                onValueChange = {
                    queryText = it
                    onUpdateFilters(filters.copy(query = it))
                },
                placeholder = { Text("Name or natural prompt (e.g. PDFs from last week)") },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                trailingIcon = {
                    if (queryText.isNotEmpty()) {
                        IconButton(onClick = {
                            queryText = ""
                            onUpdateFilters(SearchFilters())
                        }) {
                            Icon(Icons.Filled.Close, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("smart_search_input")
            )

            Spacer(Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = { onRunAiSmartSearch(queryText) },
                    enabled = queryText.isNotBlank() && aiState !is AiTaskState.Loading,
                    modifier = Modifier.testTag("ask_gemini_search_button")
                ) {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Smart AI Search")
                }

                // Quick Date & Size Filters
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    val last7DaysMs = System.currentTimeMillis() - 7L * 24L * 3600L * 1000L
                    val isRecentActive = filters.modifiedAfterEpochMs != null
                    FilterChip(
                        selected = isRecentActive,
                        onClick = {
                            onUpdateFilters(
                                filters.copy(modifiedAfterEpochMs = if (isRecentActive) null else last7DaysMs)
                            )
                        },
                        label = { Text("Last 7d") }
                    )
                    val isLargeActive = filters.minSizeBytes != null
                    FilterChip(
                        selected = isLargeActive,
                        onClick = {
                            onUpdateFilters(
                                filters.copy(minSizeBytes = if (isLargeActive) null else 1_000_000L)
                            )
                        },
                        label = { Text("> 1 MB") }
                    )
                }
            }

            // Category Filter Row
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                items(FileCategory.entries) { cat ->
                    val selected = filters.category == cat
                    FilterChip(
                        selected = selected,
                        onClick = {
                            onUpdateFilters(filters.copy(category = if (selected) null else cat))
                        },
                        label = { Text(cat.label) }
                    )
                }
            }

            // AI Interpretation Status Banner
            when (aiState) {
                is AiTaskState.Loading -> {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(10.dp))
                            Text(aiState.label, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                is AiTaskState.Success -> {
                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Filled.AutoAwesome,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(aiState.data.explanation, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                is AiTaskState.Error -> {
                    Surface(
                        color = MaterialTheme.colorScheme.error.copy(alpha = 0.14f),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                    ) {
                        Text(
                            text = aiState.message,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
                AiTaskState.Idle -> {}
            }

            Spacer(Modifier.height(6.dp))
            Text(
                text = "${results.size} matching item(s)",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(6.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 24.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(results, key = { it.path }) { node ->
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(18.dp))
                            .clickable { onOpenNode(node) }
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            FileTypeThumbnail(node = node, size = 44.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(node.displayName(showExtensions), style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "${ByteSizeFormatter.format(node.sizeBytes)} • ${ByteSizeFormatter.formatShortDate(node.lastModified)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
