package com.example.ui.exam

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.SubjectWithStats
import com.example.ui.study.SubjectStylePresets

@Composable
fun ExamDialog(
    isEditing: Boolean,
    name: String,
    onNameChange: (String) -> Unit,
    date: String,
    onDateChange: (String) -> Unit,
    selectedSubjectId: Long?,
    onSubjectChange: (Long?) -> Unit,
    activeSubjects: List<SubjectWithStats>,
    remind30: Boolean,
    onRemind30Change: (Boolean) -> Unit,
    remind7: Boolean,
    onRemind7Change: (Boolean) -> Unit,
    remind1: Boolean,
    onRemind1Change: (Boolean) -> Unit,
    errorMessage: String?,
    onDismiss: () -> Unit,
    onSave: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isEditing) "Edit Exam" else "Add New Exam",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Exam Name
                OutlinedTextField(
                    value = name,
                    onValueChange = onNameChange,
                    label = { Text("Exam Name *") },
                    placeholder = { Text("e.g. Final Calculus Exam, CA Intermediate") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("exam_name_input")
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Exam Date
                OutlinedTextField(
                    value = date,
                    onValueChange = onDateChange,
                    label = { Text("Exam Date * (YYYY-MM-DD)") },
                    placeholder = { Text("e.g. 2026-12-15") },
                    singleLine = true,
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(16.dp))
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("exam_date_input")
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Optional Subject Selector
                Text(
                    text = "Link to Subject (Optional)",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // "None" option
                    val isNoneSelected = selectedSubjectId == null
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isNoneSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                            .border(1.dp, if (isNoneSelected) MaterialTheme.colorScheme.primary else Color.Transparent, RoundedCornerShape(10.dp))
                            .clickable { onSubjectChange(null) }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                            .testTag("exam_subject_none")
                    ) {
                        Text(
                            text = "None",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = if (isNoneSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isNoneSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                        )
                    }

                    activeSubjects.forEach { item ->
                        val sub = item.subject
                        val isSelected = sub.id == selectedSubjectId
                        val color = SubjectStylePresets.getColor(sub.colorHex)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) color.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                                .border(1.dp, if (isSelected) color else Color.Transparent, RoundedCornerShape(10.dp))
                                .clickable { onSubjectChange(sub.id) }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                                .testTag("exam_subject_${sub.id}")
                        ) {
                            Text(
                                text = sub.name,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) color else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Notification Reminders (PRD Section 5.5: "Optional reminders at 30, 7, and 1 days before")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Notifications,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Notification Reminders (Optional)",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                ReminderCheckboxRow(
                    label = "30 days before exam",
                    checked = remind30,
                    onCheckedChange = onRemind30Change,
                    testTag = "remind_30_checkbox"
                )

                ReminderCheckboxRow(
                    label = "7 days before exam",
                    checked = remind7,
                    onCheckedChange = onRemind7Change,
                    testTag = "remind_7_checkbox"
                )

                ReminderCheckboxRow(
                    label = "1 day before exam",
                    checked = remind1,
                    onCheckedChange = onRemind1Change,
                    testTag = "remind_1_checkbox"
                )

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = errorMessage,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onSave,
                modifier = Modifier.testTag("save_exam_button")
            ) {
                Text(if (isEditing) "Save Changes" else "Add Exam")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_exam_button")
            ) {
                Text("Cancel")
            }
        }
    )
}

@Composable
private fun ReminderCheckboxRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(testTag)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
