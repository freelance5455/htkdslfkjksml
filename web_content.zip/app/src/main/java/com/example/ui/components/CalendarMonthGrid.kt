package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.MuhuratCategory
import com.example.model.Paksha
import com.example.panchang.VedicPanchangCalculator
import com.example.ui.theme.BichhudaBadge
import com.example.ui.theme.EkadashiGreen
import com.example.ui.theme.PanchakBadge
import com.example.ui.theme.PurnimaGlow
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@Composable
fun CalendarMonthGrid(
    viewMonth: Calendar,
    selectedDate: Calendar,
    language: AppLanguage,
    onDateSelected: (Calendar) -> Unit,
    onPreviousMonth: () -> Unit,
    onNextMonth: () -> Unit,
    onTodayClick: () -> Unit,
    onMonthYearClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val year = viewMonth.get(Calendar.YEAR)
    val month = viewMonth.get(Calendar.MONTH) + 1 // 1..12

    val monthNamesHindi = listOf(
        "जनवरी", "फरवरी", "मार्च", "अप्रैल", "मई", "जून",
        "जुलाई", "अगस्त", "सितंबर", "अक्टूबर", "नवंबर", "दिसंबर"
    )
    val monthName = monthNamesHindi.getOrElse(month - 1) { "माह" }
    val hinduMonthPair = remember(month) { VedicPanchangCalculator.getMonthHinduPair(month) }
    val vikramSamvat = year + 57

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 4.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE0E0E0)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 10.dp)
        ) {
            // Header Row: Month / Year, Nav controls, Today button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onPreviousMonth,
                    modifier = Modifier.size(36.dp).testTag("prev_month_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Previous Month",
                        tint = Color.Black
                    )
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(onClick = onMonthYearClick)
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "$monthName $year",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "▾",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                    }
                    Text(
                        text = "$hinduMonthPair • संवत $vikramSamvat",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF333333),
                        fontWeight = FontWeight.Medium,
                        fontSize = 10.5.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onTodayClick,
                        modifier = Modifier.size(36.dp).testTag("today_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Today,
                            contentDescription = "Today",
                            tint = Color.Black
                        )
                    }

                    IconButton(
                        onClick = onNextMonth,
                        modifier = Modifier.size(36.dp).testTag("next_month_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "Next Month",
                            tint = Color.Black
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Monthly Rajasthan Panchang Highlights (अमास, पूनम, बिछूड़ा, पंचक in chronological order)
            val monthPanchak = remember(year, month) { VedicPanchangCalculator.getMonthPanchak(year, month) }
            val monthBichhuda = remember(year, month) { VedicPanchangCalculator.getMonthBichhuda(year, month) }
            val monthAmasDay = remember(year, month) {
                val testCal = viewMonth.clone() as Calendar
                val maxD = testCal.getActualMaximum(Calendar.DAY_OF_MONTH)
                var found: Int? = null
                for (d in 1..maxD) {
                    testCal.set(Calendar.DAY_OF_MONTH, d)
                    if (VedicPanchangCalculator.calculatePanchang(testCal).tithiNumber == 30) {
                        found = d
                        break
                    }
                }
                found
            }
            val monthPunamDay = remember(year, month) {
                val testCal = viewMonth.clone() as Calendar
                val maxD = testCal.getActualMaximum(Calendar.DAY_OF_MONTH)
                var found: Int? = null
                for (d in 1..maxD) {
                    testCal.set(Calendar.DAY_OF_MONTH, d)
                    if (VedicPanchangCalculator.calculatePanchang(testCal).tithiNumber == 15) {
                        found = d
                        break
                    }
                }
                found
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFDE7)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFFE082)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    // Row 1: Amas & Punam (Rajasthan monthly pillars)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (monthAmasDay != null) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color(0xFF263238))
                                        .padding(horizontal = 5.dp, vertical = 1.5.dp)
                                ) {
                                    Text(text = "अमास 🌑", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                }
                                Text(
                                    text = "$monthAmasDay $monthName",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black
                                )
                            }
                        }
                        if (monthPunamDay != null) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color(0xFFE65100))
                                        .padding(horizontal = 5.dp, vertical = 1.5.dp)
                                ) {
                                    Text(text = "पूनम 🌕", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                }
                                Text(
                                    text = "$monthPunamDay $monthName",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black
                                )
                            }
                        }
                    }

                    // Row 2: Bichhuda & Panchak in chronological order
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(BichhudaBadge)
                                    .padding(horizontal = 5.dp, vertical = 1.5.dp)
                            ) {
                                Text(text = "बिछूड़ा", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                            Text(
                                text = "${monthBichhuda.startDay} से ${monthBichhuda.endDay} $monthName",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Black
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(PanchakBadge)
                                    .padding(horizontal = 5.dp, vertical = 1.5.dp)
                            ) {
                                Text(text = "पंचक", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                            Text(
                                text = "${monthPanchak.startDay} से ${monthPanchak.endDay} $monthName",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Black
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Weekday Headers
            val weekdays = listOf("रवि", "सोम", "मंगल", "बुध", "गुरु", "शुक्र", "शनि")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                weekdays.forEachIndexed { index, day ->
                    Text(
                        text = day,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = if (index == 0) Color(0xFFD32F2F) else Color.Black,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Day Grid calculation
            val cal = viewMonth.clone() as Calendar
            cal.set(Calendar.DAY_OF_MONTH, 1)
            val firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK) // 1=Sun .. 7=Sat
            val maxDaysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)

            val totalCells = ((firstDayOfWeek - 1 + maxDaysInMonth + 6) / 7) * 7
            val rows = totalCells / 7

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                for (r in 0 until rows) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        for (c in 0 until 7) {
                            val cellIndex = r * 7 + c
                            val dayNumber = cellIndex - (firstDayOfWeek - 1) + 1

                            if (dayNumber in 1..maxDaysInMonth) {
                                val dayCal = viewMonth.clone() as Calendar
                                dayCal.set(Calendar.DAY_OF_MONTH, dayNumber)

                                val isSelected = dayCal.get(Calendar.YEAR) == selectedDate.get(Calendar.YEAR) &&
                                        dayCal.get(Calendar.MONTH) == selectedDate.get(Calendar.MONTH) &&
                                        dayCal.get(Calendar.DAY_OF_MONTH) == selectedDate.get(Calendar.DAY_OF_MONTH)

                                val panchang = VedicPanchangCalculator.calculatePanchang(dayCal)
                                val dayMuhurat = VedicPanchangCalculator.getAuspiciousMuhurats().find { it.dateString == panchang.dateString }
                                val muhuratTag = when (dayMuhurat?.category) {
                                    MuhuratCategory.GRIHA_PRAVESH -> "मकान"
                                    MuhuratCategory.OFFICE_UDGHATAN -> "ऑफिस"
                                    MuhuratCategory.VIVAH -> "विवाह"
                                    else -> null
                                }

                                DayGridCell(
                                    dayNumber = dayNumber,
                                    tithiNumber = panchang.tithiNumber,
                                    paksha = panchang.paksha,
                                    isPanchak = panchang.panchak.isActive,
                                    isPanchakStart = panchang.panchak.isStartDay,
                                    isPanchakEnd = panchang.panchak.isEndDay,
                                    isBichhuda = panchang.bichhuda.isActive,
                                    isBichhudaStart = panchang.bichhuda.isStartDay,
                                    isBichhudaEnd = panchang.bichhuda.isEndDay,
                                    hasFestival = panchang.festivals.isNotEmpty(),
                                    hasVrat = panchang.vrats.isNotEmpty(),
                                    muhuratTag = muhuratTag,
                                    isSelected = isSelected,
                                    isSunday = (c == 0),
                                    onClick = { onDateSelected(dayCal) },
                                    modifier = Modifier.weight(1f)
                                )
                            } else {
                                Box(modifier = Modifier.weight(1f).height(82.dp))
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Subtle Legend Indicator
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(BichhudaBadge)
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(text = "बिछूड़ा", fontSize = 8.5.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(text = "वृश्चिक चंद्र", style = MaterialTheme.typography.labelSmall, fontSize = 10.sp)
                }
                Spacer(modifier = Modifier.width(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(PanchakBadge)
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(text = "पंचक", fontSize = 8.5.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(text = "पंचक काल", style = MaterialTheme.typography.labelSmall, fontSize = 10.sp)
                }
                Spacer(modifier = Modifier.width(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(Color(0xFF263238))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(text = "अमास", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(text = "अमावस्या", style = MaterialTheme.typography.labelSmall, fontSize = 10.sp)
                }
                Spacer(modifier = Modifier.width(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(Color(0xFF2E7D32))
                            .padding(horizontal = 3.dp, vertical = 1.dp)
                    ) {
                        Text(text = "मकान", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(text = "गृह प्रवेश", style = MaterialTheme.typography.labelSmall, fontSize = 10.sp)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Dedicated Selected Date & Monthly Panchak & Bichhuda Precise Time Window
            val selectedPanchang = remember(selectedDate) { VedicPanchangCalculator.calculatePanchang(selectedDate) }
            val selectedDayNum = selectedDate.get(Calendar.DAY_OF_MONTH)

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFFFAFAFA))
                    .border(1.dp, Color(0xFFE2E2E2), RoundedCornerShape(12.dp))
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "तारीख: $selectedDayNum $monthName • तिथि: ${selectedPanchang.tithiName} (${selectedPanchang.paksha.name})",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                        Text(
                            text = "${selectedPanchang.dayOfWeek} • ${selectedPanchang.hinduMonth} मास • नक्षत्र: ${selectedPanchang.nakshatra}",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF555555)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(
                                if (selectedPanchang.panchak.isActive || selectedPanchang.bichhuda.isActive)
                                    PanchakBadge.copy(alpha = 0.15f)
                                else Color(0xFFE8F5E9)
                            )
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (selectedPanchang.panchak.isActive || selectedPanchang.bichhuda.isActive) "⚠️ सतर्कता काल" else "✓ शुभ दिन",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (selectedPanchang.panchak.isActive || selectedPanchang.bichhuda.isActive) PanchakBadge else Color(0xFF2E7D32)
                        )
                    }
                }

                // Chronological & Active Order: Bichhuda (13-15 Oct) and Panchak (21-25 Oct)
                val showBichhudaFirst = selectedPanchang.bichhuda.isActive ||
                        (!selectedPanchang.panchak.isActive && monthBichhuda.startDay <= monthPanchak.startDay)

                if (showBichhudaFirst) {
                    // Bichhuda Timing Box (Spacious, Zero Clipping)
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (selectedPanchang.bichhuda.isActive) BichhudaBadge.copy(alpha = 0.08f) else Color.White)
                            .border(
                                1.dp,
                                if (selectedPanchang.bichhuda.isActive) BichhudaBadge.copy(alpha = 0.4f) else Color(0xFFE8E8E8),
                                RoundedCornerShape(8.dp)
                            )
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "🦂 बिछुड़ा (${selectedPanchang.bichhuda.title})",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedPanchang.bichhuda.isActive) BichhudaBadge else Color.Black,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (selectedPanchang.bichhuda.isActive) BichhudaBadge.copy(alpha = 0.15f) else Color(0xFFE8F5E9))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (selectedPanchang.bichhuda.isActive) "सक्रिय" else "बिछुड़ा मुक्त",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (selectedPanchang.bichhuda.isActive) BichhudaBadge else Color(0xFF2E7D32)
                                )
                            }
                        }

                        Text(
                            text = selectedPanchang.bichhuda.todayStatusText,
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (selectedPanchang.bichhuda.isActive) BichhudaBadge else Color(0xFF444444)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFFF7F7F7))
                                    .padding(6.dp)
                            ) {
                                Text(text = "🕒 कब लगेगा:", fontSize = 10.sp, color = Color(0xFF666666))
                                Text(
                                    text = selectedPanchang.bichhuda.lagneKaTime,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black
                                )
                            }
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFFF7F7F7))
                                    .padding(6.dp)
                            ) {
                                Text(text = "⏳ कब उतरेगा:", fontSize = 10.sp, color = Color(0xFF666666))
                                Text(
                                    text = selectedPanchang.bichhuda.utarneKaTime,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black
                                )
                            }
                        }

                        Text(
                            text = "⏱️ कुल अवधि: ${selectedPanchang.bichhuda.durationText}",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF555555)
                        )
                    }

                    // Panchak Timing Box (Spacious, Zero Clipping)
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (selectedPanchang.panchak.isActive) PanchakBadge.copy(alpha = 0.08f) else Color.White)
                            .border(
                                1.dp,
                                if (selectedPanchang.panchak.isActive) PanchakBadge.copy(alpha = 0.4f) else Color(0xFFE8E8E8),
                                RoundedCornerShape(8.dp)
                            )
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "⚠️ पंचक (${selectedPanchang.panchak.title})",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedPanchang.panchak.isActive) PanchakBadge else Color.Black,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (selectedPanchang.panchak.isActive) PanchakBadge.copy(alpha = 0.15f) else Color(0xFFE8F5E9))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (selectedPanchang.panchak.isActive) "सक्रिय" else "पंचक मुक्त",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (selectedPanchang.panchak.isActive) PanchakBadge else Color(0xFF2E7D32)
                                )
                            }
                        }

                        Text(
                            text = selectedPanchang.panchak.todayStatusText,
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (selectedPanchang.panchak.isActive) PanchakBadge else Color(0xFF444444)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFFF7F7F7))
                                    .padding(6.dp)
                            ) {
                                Text(text = "🕒 कब लगेगा:", fontSize = 10.sp, color = Color(0xFF666666))
                                Text(
                                    text = selectedPanchang.panchak.lagneKaTime,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black
                                )
                            }
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFFF7F7F7))
                                    .padding(6.dp)
                            ) {
                                Text(text = "⏳ कब उतरेगा:", fontSize = 10.sp, color = Color(0xFF666666))
                                Text(
                                    text = selectedPanchang.panchak.utarneKaTime,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black
                                )
                            }
                        }

                        Text(
                            text = "⏱️ कुल अवधि: ${selectedPanchang.panchak.durationText}",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF555555)
                        )
                    }
                } else {
                    // Panchak Timing Box first if Panchak is active
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (selectedPanchang.panchak.isActive) PanchakBadge.copy(alpha = 0.08f) else Color.White)
                            .border(
                                1.dp,
                                if (selectedPanchang.panchak.isActive) PanchakBadge.copy(alpha = 0.4f) else Color(0xFFE8E8E8),
                                RoundedCornerShape(8.dp)
                            )
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "⚠️ पंचक (${selectedPanchang.panchak.title})",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedPanchang.panchak.isActive) PanchakBadge else Color.Black,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (selectedPanchang.panchak.isActive) PanchakBadge.copy(alpha = 0.15f) else Color(0xFFE8F5E9))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (selectedPanchang.panchak.isActive) "सक्रिय" else "पंचक मुक्त",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (selectedPanchang.panchak.isActive) PanchakBadge else Color(0xFF2E7D32)
                                )
                            }
                        }

                        Text(
                            text = selectedPanchang.panchak.todayStatusText,
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (selectedPanchang.panchak.isActive) PanchakBadge else Color(0xFF444444)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFFF7F7F7))
                                    .padding(6.dp)
                            ) {
                                Text(text = "🕒 कब लगेगा:", fontSize = 10.sp, color = Color(0xFF666666))
                                Text(
                                    text = selectedPanchang.panchak.lagneKaTime,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black
                                )
                            }
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFFF7F7F7))
                                    .padding(6.dp)
                            ) {
                                Text(text = "⏳ कब उतरेगा:", fontSize = 10.sp, color = Color(0xFF666666))
                                Text(
                                    text = selectedPanchang.panchak.utarneKaTime,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black
                                )
                            }
                        }

                        Text(
                            text = "⏱️ कुल अवधि: ${selectedPanchang.panchak.durationText}",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF555555)
                        )
                    }

                    // Bichhuda Timing Box
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (selectedPanchang.bichhuda.isActive) BichhudaBadge.copy(alpha = 0.08f) else Color.White)
                            .border(
                                1.dp,
                                if (selectedPanchang.bichhuda.isActive) BichhudaBadge.copy(alpha = 0.4f) else Color(0xFFE8E8E8),
                                RoundedCornerShape(8.dp)
                            )
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "🦂 बिछुड़ा (${selectedPanchang.bichhuda.title})",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedPanchang.bichhuda.isActive) BichhudaBadge else Color.Black,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (selectedPanchang.bichhuda.isActive) BichhudaBadge.copy(alpha = 0.15f) else Color(0xFFE8F5E9))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (selectedPanchang.bichhuda.isActive) "सक्रिय" else "बिछुड़ा मुक्त",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (selectedPanchang.bichhuda.isActive) BichhudaBadge else Color(0xFF2E7D32)
                                )
                            }
                        }

                        Text(
                            text = selectedPanchang.bichhuda.todayStatusText,
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (selectedPanchang.bichhuda.isActive) BichhudaBadge else Color(0xFF444444)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFFF7F7F7))
                                    .padding(6.dp)
                            ) {
                                Text(text = "🕒 कब लगेगा:", fontSize = 10.sp, color = Color(0xFF666666))
                                Text(
                                    text = selectedPanchang.bichhuda.lagneKaTime,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black
                                )
                            }
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFFF7F7F7))
                                    .padding(6.dp)
                            ) {
                                Text(text = "⏳ कब उतरेगा:", fontSize = 10.sp, color = Color(0xFF666666))
                                Text(
                                    text = selectedPanchang.bichhuda.utarneKaTime,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black
                                )
                            }
                        }

                        Text(
                            text = "⏱️ कुल अवधि: ${selectedPanchang.bichhuda.durationText}",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF555555)
                        )
                    }
                }

                // If selected date itself has a Makan Udghatan, Office Muhurat, or Vivah Muhurat
                val selectedDayMuhurat = remember(selectedPanchang.dateString) {
                    VedicPanchangCalculator.getAuspiciousMuhurats().find { it.dateString == selectedPanchang.dateString }
                }
                if (selectedDayMuhurat != null) {
                    val catName = when (selectedDayMuhurat.category) {
                        MuhuratCategory.GRIHA_PRAVESH -> "🏡 मकान उद्घाटन (गृह प्रवेश मुहूर्त)"
                        MuhuratCategory.OFFICE_UDGHATAN -> "🏢 ऑफिस व दुकान उद्घाटन मुहूर्त"
                        MuhuratCategory.VIVAH -> "💍 शुभ विवाह लग्न"
                        else -> "⭐ शुभ मांगलिक मुहूर्त"
                    }
                    val catColor = when (selectedDayMuhurat.category) {
                        MuhuratCategory.GRIHA_PRAVESH -> Color(0xFF2E7D32)
                        MuhuratCategory.OFFICE_UDGHATAN -> Color(0xFF1565C0)
                        MuhuratCategory.VIVAH -> Color(0xFFC2185B)
                        else -> Color(0xFFE65100)
                    }
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(catColor.copy(alpha = 0.08f))
                            .border(1.dp, catColor.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = catName,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = catColor
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(catColor)
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text(text = "शुभ दिन", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                        Text(
                            text = "लग्न: ${selectedDayMuhurat.auspiciousLagna} • समय: ${selectedDayMuhurat.timings}",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.Black
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DayGridCell(
    dayNumber: Int,
    tithiNumber: Int,
    paksha: Paksha,
    isPanchak: Boolean,
    isPanchakStart: Boolean = false,
    isPanchakEnd: Boolean = false,
    isBichhuda: Boolean,
    isBichhudaStart: Boolean = false,
    isBichhudaEnd: Boolean = false,
    hasFestival: Boolean,
    hasVrat: Boolean,
    muhuratTag: String? = null,
    isSelected: Boolean,
    isSunday: Boolean = false,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tithiAbbr = when (tithiNumber) {
        15 -> "पूनम 🌕"
        30 -> "अमास 🌑"
        11, 26 -> "ग्यारस"
        1 -> "शु एकम"
        2 -> "शु दूज"
        3 -> "शु तीज"
        4 -> "शु चौथ"
        5 -> "शु पंचम"
        6 -> "शु छठ"
        7 -> "शु सातम"
        8 -> "शु आठम"
        9 -> "शु नौमी"
        10 -> "शु दसम"
        12 -> "शु बारस"
        13 -> "शु तेरस"
        14 -> "शु चौदस"
        16 -> "कृ एकम"
        17 -> "कृ दूज"
        18 -> "कृ तीज"
        19 -> "कृ चौथ"
        20 -> "कृ पंचम"
        21 -> "कृ छठ"
        22 -> "कृ सातम"
        23 -> "कृ आठम"
        24 -> "कृ नौमी"
        25 -> "कृ दसम"
        27 -> "कृ बारस"
        28 -> "कृ तेरस"
        29 -> "कृ चौदस"
        else -> {
            val prefix = if (paksha == Paksha.SHUKLA) "शु" else "कृ"
            val num = if (tithiNumber <= 15) tithiNumber else tithiNumber - 15
            "$prefix $num"
        }
    }

    Box(
        modifier = modifier
            .height(82.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(
                when {
                    isSelected -> Color(0xFFF2F2F2)
                    isBichhuda -> Color(0xFFFFEBEE)
                    isPanchak -> Color(0xFFFFF8E1)
                    tithiNumber == 15 -> Color(0xFFFFFDE7)
                    tithiNumber == 30 -> Color(0xFFECEFF1)
                    else -> Color.White
                }
            )
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = when {
                    isSelected -> Color.Black
                    isBichhuda -> Color(0xFFEF9A9A)
                    isPanchak -> Color(0xFFFFE082)
                    tithiNumber == 15 -> Color(0xFFFFD54F)
                    tithiNumber == 30 -> Color(0xFFB0BEC5)
                    else -> Color(0xFFE0E0E0)
                },
                shape = RoundedCornerShape(8.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 2.dp, vertical = 2.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxSize()
        ) {
            // 1. TOP: Indicators / Badges Row (बिछूड़ा, पंचक, मुहूर्त, व्रत/त्यौहार, अमास, पूनम)
            Row(
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(18.dp)
            ) {
                if (isBichhuda) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(3.dp))
                            .background(if (isBichhudaStart || isBichhudaEnd) Color(0xFFC62828) else BichhudaBadge)
                            .padding(vertical = 1.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "बिछूड़ा",
                            fontSize = 7.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            maxLines = 1,
                            softWrap = false,
                            textAlign = TextAlign.Center
                        )
                    }
                } else if (isPanchak) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(3.dp))
                            .background(if (isPanchakStart || isPanchakEnd) Color(0xFFE65100) else Color(0xFFFF9800))
                            .padding(vertical = 1.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "पंचक",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            maxLines = 1,
                            softWrap = false,
                            textAlign = TextAlign.Center
                        )
                    }
                } else {
                    if (muhuratTag != null) {
                        val muhuratBg = when (muhuratTag) {
                            "मकान" -> Color(0xFF2E7D32)
                            "ऑफिस" -> Color(0xFF1565C0)
                            else -> Color(0xFFC2185B)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(3.dp))
                                .background(muhuratBg)
                                .padding(horizontal = 2.5.dp, vertical = 0.5.dp)
                        ) {
                            Text(
                                text = muhuratTag,
                                fontSize = 6.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                        Spacer(modifier = Modifier.width(1.5.dp))
                    }
                    if (hasFestival || hasVrat) {
                        Box(modifier = Modifier.size(5.dp).clip(CircleShape).background(EkadashiGreen))
                    } else if (tithiNumber == 30) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(3.dp))
                                .background(Color(0xFF263238))
                                .padding(horizontal = 2.5.dp, vertical = 0.5.dp)
                        ) {
                            Text(
                                text = "अमास",
                                fontSize = 6.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    } else if (tithiNumber == 15) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(3.dp))
                                .background(Color(0xFFE65100))
                                .padding(horizontal = 2.5.dp, vertical = 0.5.dp)
                        ) {
                            Text(
                                text = "पूनम",
                                fontSize = 6.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                }
            }

            // 2. CENTER: Gregorian Day Number (तारीख) + Tithi Badge (तारीख के ठीक पास तिथि)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.padding(horizontal = 1.dp)
            ) {
                Text(
                    text = "$dayNumber",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = when {
                        isSunday -> Color(0xFFD32F2F)
                        tithiNumber == 15 -> Color(0xFFE65100)
                        tithiNumber == 30 -> Color(0xFF212121)
                        else -> Color.Black
                    },
                    fontSize = 15.sp
                )

                Spacer(modifier = Modifier.width(3.dp))

                val tithiTag = when (tithiNumber) {
                    15 -> "पूनम"
                    30 -> "अमास"
                    11, 26 -> "ग्यारस"
                    else -> {
                        val pfx = if (paksha == Paksha.SHUKLA) "शु" else "कृ"
                        val n = if (tithiNumber <= 15) tithiNumber else tithiNumber - 15
                        "$pfx.$n"
                    }
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(
                            when {
                                tithiNumber == 15 -> Color(0xFFFFE082)
                                tithiNumber == 30 -> Color(0xFFCFD8DC)
                                tithiNumber == 11 || tithiNumber == 26 -> Color(0xFFC8E6C9)
                                paksha == Paksha.SHUKLA -> Color(0xFFFFF3E0)
                                else -> Color(0xFFECEFF1)
                            }
                        )
                        .padding(horizontal = 2.dp, vertical = 0.5.dp)
                ) {
                    Text(
                        text = tithiTag,
                        fontSize = 7.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = when {
                            tithiNumber == 15 -> Color(0xFFBF360C)
                            tithiNumber == 30 -> Color(0xFF263238)
                            tithiNumber == 11 || tithiNumber == 26 -> Color(0xFF1B5E20)
                            paksha == Paksha.SHUKLA -> Color(0xFFD84315)
                            else -> Color(0xFF37474F)
                        },
                        maxLines = 1,
                        softWrap = false
                    )
                }
            }

            // 3. BOTTOM: Vedic Tithi Label
            Text(
                text = tithiAbbr,
                style = MaterialTheme.typography.labelSmall,
                fontSize = 8.5.sp,
                fontWeight = when {
                    tithiNumber == 15 || tithiNumber == 30 -> FontWeight.Bold
                    tithiNumber == 11 || tithiNumber == 26 -> FontWeight.Bold
                    else -> FontWeight.Medium
                },
                color = when {
                    tithiNumber == 15 -> Color(0xFFE65100)
                    tithiNumber == 30 -> Color(0xFF263238)
                    tithiNumber == 11 || tithiNumber == 26 -> Color(0xFF1B5E20)
                    else -> Color(0xFF333333)
                },
                maxLines = 1,
                softWrap = false
            )
        }
    }
}
