package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

enum class ButtonRole {
    NUMBER,
    OPERATOR,
    EQUALS,
    FUNCTION,
    ACTION
}

@Composable
fun KeypadButton(
    text: String,
    role: ButtonRole,
    isUltimateMode: Boolean,
    onClick: (Offset) -> Unit,
    modifier: Modifier = Modifier,
    height: Dp = 56.dp
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    var centerOffsetInRoot by remember { mutableStateOf(Offset.Zero) }

    // Spring bouncy scale animation on press
    val scaleAnim by animateFloatAsState(
        targetValue = if (isPressed) 0.86f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "btnScale"
    )

    // Flash glow on press
    val flashAlpha by animateFloatAsState(
        targetValue = if (isPressed) 0.65f else 0f,
        animationSpec = tween(durationMillis = if (isPressed) 40 else 220),
        label = "btnFlash"
    )

    val neonColor = if (isUltimateMode) UltimateRedBright else OmnitrixGreenBright
    val neonDim = if (isUltimateMode) UltimateRedDim else OmnitrixGreenDim

    // Background Gradient based on role
    val backgroundBrush = when (role) {
        ButtonRole.EQUALS -> {
            Brush.verticalGradient(
                listOf(
                    if (isUltimateMode) UltimateRedBright else OmnitrixGreenBright,
                    if (isUltimateMode) UltimateRedDark else OmnitrixGreenDark
                )
            )
        }
        ButtonRole.OPERATOR -> {
            Brush.verticalGradient(
                listOf(GalvanSurfaceLight, GalvanDark)
            )
        }
        ButtonRole.FUNCTION -> {
            Brush.verticalGradient(
                listOf(GalvanSurface, GalvanBlack)
            )
        }
        ButtonRole.ACTION -> {
            Brush.verticalGradient(
                listOf(GalvanSurfaceLight, GalvanDark)
            )
        }
        ButtonRole.NUMBER -> {
            Brush.verticalGradient(
                listOf(GalvanSurface, GalvanBlack)
            )
        }
    }

    val textColor = when (role) {
        ButtonRole.EQUALS -> GalvanBlack
        ButtonRole.OPERATOR -> if (isUltimateMode) UltimateRedBright else AlienCyan
        ButtonRole.FUNCTION -> AlienGold
        ButtonRole.ACTION -> if (isUltimateMode) UltimateRedBright else OmnitrixGreenBright
        ButtonRole.NUMBER -> WhitePure
    }

    val borderColor by animateColorAsState(
        targetValue = if (isPressed) {
            neonColor
        } else when (role) {
            ButtonRole.EQUALS -> neonColor
            ButtonRole.OPERATOR -> if (isUltimateMode) UltimateRed.copy(alpha = 0.5f) else AlienCyan.copy(alpha = 0.4f)
            ButtonRole.FUNCTION -> AlienGold.copy(alpha = 0.35f)
            ButtonRole.ACTION -> neonDim.copy(alpha = 0.5f)
            ButtonRole.NUMBER -> GalvanBorder
        },
        label = "btnBorderColor"
    )

    val shape = RoundedCornerShape(16.dp)

    Box(
        modifier = modifier
            .height(height)
            .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
            .scale(scaleAnim)
            .onGloballyPositioned { coordinates ->
                val bounds = coordinates.boundsInRoot()
                centerOffsetInRoot = Offset(bounds.left + bounds.width / 2f, bounds.top + bounds.height / 2f)
            }
            .clip(shape)
            .background(backgroundBrush)
            .border(
                width = if (isPressed || role == ButtonRole.EQUALS) 2.dp else 1.2.dp,
                color = borderColor,
                shape = shape
            )
            .clickable(
                interactionSource = interactionSource,
                indication = null
            ) {
                onClick(centerOffsetInRoot)
            }
            .testTag("keypad_button_${text}"),
        contentAlignment = Alignment.Center
    ) {
        // Neon Press Glow Layer
        if (flashAlpha > 0f) {
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .background(neonColor.copy(alpha = flashAlpha))
            )
        }

        // Button Text
        Text(
            text = text,
            color = textColor,
            fontSize = when {
                role == ButtonRole.EQUALS -> 24.sp
                role == ButtonRole.FUNCTION -> 14.sp
                text.length > 2 -> 16.sp
                else -> 22.sp
            },
            fontWeight = when (role) {
                ButtonRole.EQUALS -> FontWeight.Black
                ButtonRole.NUMBER -> FontWeight.Bold
                else -> FontWeight.SemiBold
            },
            fontFamily = FontFamily.Monospace,
            letterSpacing = 0.5.sp
        )
    }
}
