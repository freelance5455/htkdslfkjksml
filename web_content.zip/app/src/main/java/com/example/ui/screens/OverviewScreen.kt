package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.LabTab
import com.example.ui.components.AnimatedCyberRadar
import com.example.ui.components.CyberCard
import com.example.ui.components.SafeLabDisclaimer
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun OverviewScreen(
    currentLanguage: AppLanguage,
    onNavigateTab: (LabTab) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBackground)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // Safe Lab Disclaimer Banner
        SafeLabDisclaimer(currentLanguage = currentLanguage)

        // Hero Security Radar & Threat Level Monitor
        CyberCard(
            borderColor = NeonCyan.copy(alpha = 0.5f)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(NeonGreen)
                        )
                        Text(
                            text = if (currentLanguage == AppLanguage.EN) "DEFENSE SYSTEM ACTIVE" else "প্রতিরক্ষা ব্যবস্থা সক্রিয়",
                            color = NeonGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (currentLanguage == AppLanguage.EN) "Threat Awareness Operations" else "হুমকি সচেতনতা অপারেশনস",
                        color = TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (currentLanguage == AppLanguage.EN)
                            "Interactive simulations exposing the 4 major cyber deception vectors targeting users."
                        else
                            "ব্যবহারকারীদের টার্গেট করা ৪টি প্রধান সাইবার প্রতারণা কৌশলের বাস্তবসম্মত সিমুলেশন।",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))
                AnimatedCyberRadar(size = 90.dp)
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Quick Stats Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatPill(
                    label = if (currentLanguage == AppLanguage.EN) "Threat Vectors" else "ঝুঁকি ক্যাটাগরি",
                    value = "4 Labs",
                    color = NeonCyan,
                    modifier = Modifier.weight(1f)
                )
                StatPill(
                    label = if (currentLanguage == AppLanguage.EN) "Harvesting Risk" else "তথ্য ফাঁসের ঝুঁকি",
                    value = "0.0% SAFE",
                    color = NeonGreen,
                    modifier = Modifier.weight(1f)
                )
                StatPill(
                    label = if (currentLanguage == AppLanguage.EN) "Mode" else "মোড",
                    value = "DEFENSIVE",
                    color = NeonPurple,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Section Title: Interactive Labs
        Text(
            text = if (currentLanguage == AppLanguage.EN) "CYBER DEFENSE LABORATORIES" else "সাইবার নিরাপত্তা ল্যাবসমূহ",
            color = NeonCyan,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        // 4 Lab Cards
        LabNavigationCard(
            title = if (currentLanguage == AppLanguage.EN) "1. Photo Upload Website Phishing" else "১. ফটো আপলোড ও মেটাডাটা ফাঁস ল্যাব",
            category = if (currentLanguage == AppLanguage.EN) "EXIF & Biometric Privacy Leak" else "ইএক্সআইএফ ও বায়োমেট্রিক তথ্য ঝুঁকি",
            description = if (currentLanguage == AppLanguage.EN)
                "Test voluntary photo uploads, inspect hidden GPS geotags, and discover how rogue sites exploit camera EXIF metadata."
            else
                "নিরাপদে ছবি প্রিভিউ করুন, গোপন জিপিএস মেটাডাটা বের হওয়া দেখুন এবং ক্ষতিকর সাইটের ট্র্যাকিং পদ্ধতি জানুন।",
            icon = Icons.Default.AddAPhoto,
            accentColor = NeonCyan,
            testTag = "nav_photo_lab",
            onClick = { onNavigateTab(LabTab.PHOTO_UPLOAD) }
        )

        LabNavigationCard(
            title = if (currentLanguage == AppLanguage.EN) "2. Fake Login Page Interceptor" else "২. নকল লগইন ও ফিশিং ইন্টারসেপ্টর",
            category = if (currentLanguage == AppLanguage.EN) "Credential Harvesting Simulation" else "পাসওয়ার্ড চুরি প্রতিরোধ সিমুলেশন",
            description = if (currentLanguage == AppLanguage.EN)
                "Interact with a deceptive single sign-on portal using dummy text to see real-time phishing interception in action."
            else
                "নকল কর্পোরেট লগইন পোর্টালে ডামি তথ্য দিন এবং আক্রমণকারী কীভাবে গোপনে কী-স্ট্রোক ধরে তা বিশ্লেষণ করুন।",
            icon = Icons.Default.Lock,
            accentColor = NeonMagenta,
            testTag = "nav_login_lab",
            onClick = { onNavigateTab(LabTab.FAKE_LOGIN) }
        )

        LabNavigationCard(
            title = if (currentLanguage == AppLanguage.EN) "3. Camera Permission Phishing" else "৩. ক্যামেরা পারমিশন ও প্রাইভেসি স্যান্ডবক্স",
            category = if (currentLanguage == AppLanguage.EN) "Social Engineering & Permissions" else "অনুমতি অপব্যবহার ও সোশ্যাল ইঞ্জিনিয়ারিং",
            description = if (currentLanguage == AppLanguage.EN)
                "Examine how deceptive prompt modals trick users into granting permanent camera and sensor privileges."
            else
                "প্রতারণামূলক অফারের মাধ্যমে ক্যামেরা অনুমতি নেওয়ার কৌশল ও অ্যান্ড্রয়েডের সবুজ প্রাইভেসি ডট সনাক্তকরণ।",
            icon = Icons.Default.CameraAlt,
            accentColor = NeonBlue,
            testTag = "nav_camera_lab",
            onClick = { onNavigateTab(LabTab.CAMERA_PERMISSION) }
        )

        LabNavigationCard(
            title = if (currentLanguage == AppLanguage.EN) "4. Malicious Android App Scanner" else "৪. ক্ষতিকর অ্যান্ড্রয়েড অ্যাপ স্ক্যানার",
            category = if (currentLanguage == AppLanguage.EN) "Malware & Overlay Trojans" else "ম্যালওয়্যার ও ওটিপি হ্যাকিং সচেতনতা",
            description = if (currentLanguage == AppLanguage.EN)
                "Run a simulated deep security scan against rogue mobile apps abusing Accessibility, SMS, and Screen Overlays."
            else
                "অ্যাক্সেসিবিলিটি সার্ভিস ও স্ক্রিন ওভারলে অপব্যবহারকারী সন্দেহজনক অ্যাপ স্ক্যান করে নিরাপত্তা রিপোর্ট দেখুন।",
            icon = Icons.Default.BugReport,
            accentColor = NeonRed,
            testTag = "nav_malware_lab",
            onClick = { onNavigateTab(LabTab.MALWARE_SCAN) }
        )

        // Web Version & Source Code Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = { onNavigateTab(LabTab.WEB_VIEW) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2842)),
                border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("nav_web_view")
            ) {
                Icon(
                    imageVector = Icons.Default.Public,
                    contentDescription = "Web Sandbox",
                    tint = NeonCyan,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (currentLanguage == AppLanguage.EN) "HTML Web Lab" else "HTML ওয়েব ল্যাব",
                    color = NeonCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Button(
                onClick = { onNavigateTab(LabTab.SOURCE_SETUP) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2842)),
                border = androidx.compose.foundation.BorderStroke(1.dp, NeonPurple.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("nav_source_setup")
            ) {
                Icon(
                    imageVector = Icons.Default.Code,
                    contentDescription = "Save or Copy HTML",
                    tint = NeonPurple,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (currentLanguage == AppLanguage.EN) "Save .html File" else "HTML সেভ/কোড",
                    color = NeonPurple,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Daily Security Best Practices Checklist
        CyberCard(borderColor = NeonGreen.copy(alpha = 0.3f)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = "Checklist",
                    tint = NeonGreen,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = if (currentLanguage == AppLanguage.EN) "Golden Defense Rules" else "গোল্ডেন সাইবার সুরক্ষা নীতি",
                    color = NeonGreen,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            DefenseCheckItem(
                text = if (currentLanguage == AppLanguage.EN)
                    "Never upload photos with active GPS location data to unknown public forums."
                else
                    "অপরিচিত ওয়েবসাইটে ছবি তোলার আগে ক্যামেরা সেটিংস থেকে লোকেশন ট্যাগিং বন্ধ রাখুন।"
            )
            DefenseCheckItem(
                text = if (currentLanguage == AppLanguage.EN)
                    "Check URL character substitution (e.g. '1' for 'l') before entering login credentials."
                else
                    "লগইন করার পূর্বে ব্রাউজারের অ্যাড্রেস বার ও ডোমেনের বানান সতর্কতার সাথে যাচাই করুন।"
            )
            DefenseCheckItem(
                text = if (currentLanguage == AppLanguage.EN)
                    "Select 'Only While Using App' instead of granting permanent camera/microphone permissions."
                else
                    "ক্যামেরা ও মাইক্রোফোনে সর্বদা 'Only this time' বা 'While using app' অনুমতি দিন।"
            )
            DefenseCheckItem(
                text = if (currentLanguage == AppLanguage.EN)
                    "Never grant Accessibility or Screen Overlay permissions to untrusted utilities like flashlights."
                else
                    "টর্চ বা ক্লিনারের মতো সাধারণ অ্যাপকে অ্যাক্সেসিবিলিটি বা ওভারলে অনুমতি দেবেন না।"
            )
        }
    }
}

@Composable
private fun StatPill(
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = Color(0xFF0C1220),
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.3f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                color = color,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 13.sp
            )
            Text(
                text = label,
                color = TextSecondary,
                fontSize = 9.sp,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun LabNavigationCard(
    title: String,
    category: String,
    description: String,
    icon: ImageVector,
    accentColor: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Surface(
        color = CyberSurfaceCard,
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(alpha = 0.35f)),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(accentColor.copy(alpha = 0.15f))
                    .border(1.dp, accentColor.copy(alpha = 0.6f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = accentColor,
                    modifier = Modifier.size(24.dp)
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = category,
                    color = accentColor,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = title,
                    color = TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = description,
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            }

            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = "Open Lab",
                tint = accentColor.copy(alpha = 0.7f),
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
private fun DefenseCheckItem(text: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            tint = NeonGreen,
            modifier = Modifier.size(14.dp)
        )
        Text(
            text = text,
            color = TextSecondary,
            fontSize = 11.sp,
            lineHeight = 15.sp
        )
    }
}
