package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.SecurityLabData
import com.example.model.AppLanguage
import com.example.model.SamplePhoto
import com.example.ui.components.CyberCard
import com.example.ui.components.SafeLabDisclaimer
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun PhotoUploadLabScreen(
    currentLanguage: AppLanguage,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    var selectedSample by remember { mutableStateOf<SamplePhoto?>(SecurityLabData.samplePhotos[0]) }
    var userCustomUri by remember { mutableStateOf<Uri?>(null) }
    var userCustomName by remember { mutableStateOf<String?>(null) }

    // Android Zero-Permission Photo Picker
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            userCustomUri = uri
            userCustomName = "selected_image.jpg"
            selectedSample = null
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBackground)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Disclaimer
        SafeLabDisclaimer(currentLanguage = currentLanguage)

        // Lab Header
        CyberCard(borderColor = NeonCyan.copy(alpha = 0.5f)) {
            Text(
                text = if (currentLanguage == AppLanguage.EN) "LAB 01: PHOTO UPLOAD & EXIF LEAK" else "ল্যাব ০১: ফটো আপলোড ও মেটাডাটা ফাঁস",
                color = NeonCyan,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 16.sp,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (currentLanguage == AppLanguage.EN)
                    "How deceptive image-sharing websites exploit user trust to extract hidden GPS geotags, camera hardware serials, and biometric markers."
                else
                    "ছবির পেছনের গোপন মেটাডাটা (জিপিএস অবস্থান, ক্যামেরা হার্ডওয়্যার আইডি) কীভাবে ক্ষতিকর সাইটগুলো ব্যবহারকারীর অজান্তে সংগ্রহ করে তার বিশ্লেষণ।",
                color = TextSecondary,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )
        }

        // Section: Select Photo (Voluntary Device Picker or Preset Demos)
        CyberCard(borderColor = NeonPurple.copy(alpha = 0.4f)) {
            Text(
                text = if (currentLanguage == AppLanguage.EN) "Select Photo for Voluntary Analysis" else "পরীক্ষার জন্য একটি ছবি নির্বাচন করুন",
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = if (currentLanguage == AppLanguage.EN)
                    "You can pick any image voluntarily from your device gallery (processed strictly on-device) or choose a preset scenario below:"
                else
                    "আপনার ডিভাইসের গ্যালারি থেকে যেকোনো ছবি নির্বাচন করুন অথবা নিচের প্রস্তুতকৃত ডেমো ছবিগুলো ব্যবহার করুন:",
                color = TextSecondary,
                fontSize = 11.sp
            )
            Spacer(modifier = Modifier.height(12.dp))

            // Button to open Device Photo Picker
            Button(
                onClick = {
                    photoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2640)),
                border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("pick_photo_button")
            ) {
                Icon(
                    imageVector = Icons.Default.AddPhotoAlternate,
                    contentDescription = "Pick Image",
                    tint = NeonCyan,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (currentLanguage == AppLanguage.EN) "Choose from Device Gallery" else "ডিভাইস গ্যালারি থেকে ছবি বাছাই করুন",
                    color = NeonCyan,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Preset Demo Buttons
            Text(
                text = if (currentLanguage == AppLanguage.EN) "Or Test with Simulated Samples:" else "অথবা ডেমো নমুনা দিয়ে পরীক্ষা করুন:",
                color = TextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(8.dp))

            SecurityLabData.samplePhotos.forEach { sample ->
                val isSelected = selectedSample?.id == sample.id && userCustomUri == null
                Surface(
                    color = if (isSelected) Color(0xFF1C2C4E) else CyberSurfaceElevated,
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isSelected) NeonCyan else Color.Transparent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            selectedSample = sample
                            userCustomUri = null
                        }
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (currentLanguage == AppLanguage.EN) sample.nameEn else sample.nameBn,
                                color = if (isSelected) NeonCyan else TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                            Text(
                                text = sample.category,
                                color = TextSecondary,
                                fontSize = 10.sp
                            )
                        }
                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Selected",
                                tint = NeonCyan,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        // Image Preview & Active Metadata Box
        CyberCard(borderColor = NeonAmber.copy(alpha = 0.4f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = if (currentLanguage == AppLanguage.EN) "Voluntary Image Preview" else "ছবি প্রিভিউ ও মেটাডাটা পর্যবেক্ষণ",
                    color = NeonAmber,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                if (userCustomUri != null || selectedSample != null) {
                    Surface(
                        color = Color(0xFF261820),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .clickable {
                                userCustomUri = null
                                selectedSample = SecurityLabData.samplePhotos[0]
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Clear",
                                tint = NeonRed,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (currentLanguage == AppLanguage.EN) "Reset" else "রিসেট",
                                color = NeonRed,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Visual Rendering
            if (userCustomUri != null) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .border(1.dp, NeonCyan, RoundedCornerShape(10.dp))
                ) {
                    AsyncImage(
                        model = userCustomUri,
                        contentDescription = "User uploaded image preview",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .background(Color.Black.copy(alpha = 0.7f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "LOCAL ONLY • NO TRANSMISSION",
                            color = NeonGreen,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            } else if (selectedSample != null) {
                // High-tech Cyber Preview Simulation
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            Brush.verticalGradient(listOf(Color(0xFF0F1A30), Color(0xFF070B16)))
                        )
                        .border(1.dp, NeonPurple.copy(alpha = 0.5f), RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PhotoCamera,
                            contentDescription = "Photo Camera",
                            tint = NeonCyan,
                            modifier = Modifier.size(42.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (currentLanguage == AppLanguage.EN) selectedSample!!.nameEn else selectedSample!!.nameBn,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = selectedSample!!.category,
                            color = NeonPurple,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Metadata Breakdown Panel
            val exif = selectedSample?.simulatedExif ?: SecurityLabData.samplePhotos[0].simulatedExif

            Text(
                text = if (currentLanguage == AppLanguage.EN) "EXTRACTED EXIF TELEMETRY:" else "নিষ্কাশিত মেটাডাটা ও টেলিমেট্রি:",
                color = NeonCyan,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(6.dp))

            Surface(
                color = Color(0xFF0A0F1D),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    ExifRow(
                        label = "GPS Geotag",
                        value = exif.gpsCoordinates,
                        valueColor = NeonRed,
                        isWarning = true
                    )
                    ExifRow(
                        label = "Approx. Location",
                        value = exif.locationName,
                        valueColor = NeonAmber
                    )
                    ExifRow(
                        label = "Timestamp",
                        value = exif.timestamp,
                        valueColor = TextPrimary
                    )
                    ExifRow(
                        label = "Device Hardware",
                        value = exif.deviceModel,
                        valueColor = NeonCyan
                    )
                    ExifRow(
                        label = "Optics / Lens",
                        value = exif.cameraLens,
                        valueColor = TextSecondary
                    )
                    ExifRow(
                        label = "Sensor Hardware ID",
                        value = exif.serialNumber,
                        valueColor = NeonPurple
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Risk Assessment Box
            Surface(
                color = Color(0xFF261014),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, NeonRed.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Risk",
                        tint = NeonRed,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = if (currentLanguage == AppLanguage.EN) exif.privacyRisk else exif.privacyRiskBn,
                        color = Color(0xFFFFB4AB),
                        fontSize = 11.sp,
                        lineHeight = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // Threat Explanation Section
        CyberCard(borderColor = NeonRed.copy(alpha = 0.35f)) {
            Text(
                text = if (currentLanguage == AppLanguage.EN) "How Malicious Sites Abuse Photo Uploads" else "ক্ষতিকর সাইটগুলো যেভাবে ছবির অপব্যবহার করে",
                color = NeonRed,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(10.dp))

            ThreatVectorItem(
                number = "1",
                title = if (currentLanguage == AppLanguage.EN) "Geotag Stalking & Residence Discovery" else "জিপিএস লোকেশন দিয়ে বাসস্থান শনাক্তকরণ",
                desc = if (currentLanguage == AppLanguage.EN)
                    "Smartphones automatically embed precise GPS coordinates into photo EXIF tags. Malicious websites scan these to map out user home addresses and daily routines."
                else
                    "স্মার্টফোন ক্যামেরায় অটোমেটিক জিপিএস কো-অর্ডিনেট যুক্ত থাকে। প্রতারক সাইটগুলো এই তথ্য দিয়ে ব্যবহারকারীর বাসা এবং চলাচলের রুট বের করে।"
            )

            ThreatVectorItem(
                number = "2",
                title = if (currentLanguage == AppLanguage.EN) "Biometric Facial Recognition Harvesting" else "অনুমতিহীন ফেসিয়াল বায়োমেট্রিক তথ্য সংগ্রহ",
                desc = if (currentLanguage == AppLanguage.EN)
                    "Sites promoting 'Free avatar filters' or 'Age predictors' often harvest thousands of high-res facial photos to feed unauthorized surveillance and facial databases."
                else
                    "ফ্রি ফিল্টার বা রূপচর্চার নামে হাজার হাজার সেলফি সংগ্রহ করে কৃত্রিম বুদ্ধিমত্তার ফেস রিকগনিশন ডাটাবেসে ব্যবহারকারীদের ছবি বিক্রি করা হয়।"
            )

            ThreatVectorItem(
                number = "3",
                title = if (currentLanguage == AppLanguage.EN) "Device Fingerprinting via Sensor Flaws" else "ক্যামেরা সেন্সর দিয়ে ডিভাইস ট্র্যাকিং",
                desc = if (currentLanguage == AppLanguage.EN)
                    "Every digital camera sensor has micro-imperfections (Photo-Response Non-Uniformity). Forensic algorithms link photos across multiple anonymous accounts to a single physical phone."
                else
                    "প্রতিটি ক্যামেরা সেন্সরের নির্দিষ্ট ক্ষুদ্র দাগ বা বৈশিষ্ট্য থাকে যা দিয়ে ছদ্মনামের একাধিক অ্যাকাউন্টের ছবি একই ব্যক্তির কিনা তা নিশ্চিত করা যায়।"
            )
        }

        // Prevention & Defense Checklist
        CyberCard(borderColor = NeonGreen.copy(alpha = 0.4f)) {
            Text(
                text = if (currentLanguage == AppLanguage.EN) "🛡️ Defensive Countermeasures" else "🛡️ প্রতিরোধ ও সতর্কতামূলক ব্যবস্থা",
                color = NeonGreen,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (currentLanguage == AppLanguage.EN)
                    "• Disable 'Location Tags' in your Android camera app settings.\n• Use an EXIF Metadata Eraser app or take a screenshot of the photo before sharing publicly.\n• Never upload government IDs, boarding passes, or office badges to online forums.\n• Use privacy-respecting platforms that automatically strip EXIF data before publishing."
                else
                    "• মোবাইল ক্যামেরা সেটিংস থেকে 'Location Tags' বা 'Save Location' বন্ধ রাখুন।\n• অনলাইনে ছবি আপলোড করার পূর্বে মেটাডাটা স্ক্রাবার ব্যবহার করুন অথবা ছবির স্ক্রিনশট পোস্ট করুন।\n• জাতীয় পরিচয়পত্র, পাসপোর্টের ছবি বা অফিসের আইডি ব্যাজ কখনোই অননুমোদিত সাইটে দেবেন না।\n• যেসব প্ল্যাটফর্ম আপলোডের পর মেটাডাটা মুছে ফেলে শুধুমাত্র সেগুলো ব্যবহার করুন।",
                color = TextSecondary,
                fontSize = 11.sp,
                lineHeight = 17.sp
            )
        }
    }
}

@Composable
private fun ExifRow(
    label: String,
    value: String,
    valueColor: Color,
    isWarning: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            color = TextSecondary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = value,
            color = valueColor,
            fontSize = 11.sp,
            fontWeight = if (isWarning) FontWeight.Bold else FontWeight.Normal,
            fontFamily = FontFamily.Monospace,
            maxLines = 1
        )
    }
}

@Composable
private fun ThreatVectorItem(
    number: String,
    title: String,
    desc: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            modifier = Modifier
                .size(22.dp)
                .clip(CircleShape)
                .background(NeonRed.copy(alpha = 0.2f))
                .border(1.dp, NeonRed, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = number,
                color = NeonRed,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp
            )
        }
        Column {
            Text(
                text = title,
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = desc,
                color = TextSecondary,
                fontSize = 11.sp,
                lineHeight = 15.sp
            )
        }
    }
}
