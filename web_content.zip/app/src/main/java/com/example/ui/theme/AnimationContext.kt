package com.example.ui.theme

import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.IntOffset

enum class AnimationMode(val label: String, val subtitle: String) {
    OFF(
        label = "Off",
        subtitle = "Instant state changes, zero transitions (honors reduced motion)"
    ),
    MEDIUM(
        label = "Medium (Default)",
        subtitle = "Crisp 180ms One UI fades, short slides, and tactile ripples"
    ),
    HIGH(
        label = "High",
        subtitle = "Expressive spring physics, staggered entries, and animated charts"
    )
}

data class AppAnimationSpecs(
    val mode: AnimationMode = AnimationMode.MEDIUM
) {
    val isAnimated: Boolean get() = mode != AnimationMode.OFF
    val isExpressive: Boolean get() = mode == AnimationMode.HIGH

    fun floatSpec(): AnimationSpec<Float> = when (mode) {
        AnimationMode.OFF -> snap()
        AnimationMode.MEDIUM -> tween(durationMillis = 190, easing = FastOutSlowInEasing)
        AnimationMode.HIGH -> spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessMediumLow
        )
    }

    fun progressSpec(): AnimationSpec<Float> = when (mode) {
        AnimationMode.OFF -> snap()
        AnimationMode.MEDIUM -> tween(durationMillis = 220, easing = FastOutSlowInEasing)
        AnimationMode.HIGH -> spring(
            dampingRatio = 0.72f,
            stiffness = Spring.StiffnessLow
        )
    }

    fun placementSpec(): FiniteAnimationSpec<IntOffset> = when (mode) {
        AnimationMode.OFF -> snap()
        AnimationMode.MEDIUM -> tween(durationMillis = 180, easing = FastOutSlowInEasing)
        AnimationMode.HIGH -> spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow
        )
    }

    fun screenEnter(): EnterTransition = when (mode) {
        AnimationMode.OFF -> EnterTransition.None
        AnimationMode.MEDIUM -> fadeIn(tween(180)) + slideInHorizontally(tween(180)) { it / 12 }
        AnimationMode.HIGH -> fadeIn(tween(240)) +
            slideInHorizontally(spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow)) { it / 5 } +
            scaleIn(initialScale = 0.96f, animationSpec = spring(dampingRatio = 0.8f))
    }

    fun screenExit(): ExitTransition = when (mode) {
        AnimationMode.OFF -> ExitTransition.None
        AnimationMode.MEDIUM -> fadeOut(tween(150)) + slideOutHorizontally(tween(150)) { -it / 14 }
        AnimationMode.HIGH -> fadeOut(tween(200)) + slideOutHorizontally(tween(220)) { -it / 6 }
    }

    fun bottomBarEnter(): EnterTransition = when (mode) {
        AnimationMode.OFF -> EnterTransition.None
        AnimationMode.MEDIUM -> fadeIn(tween(160)) + slideInVertically(tween(180)) { it }
        AnimationMode.HIGH -> fadeIn(tween(200)) +
            slideInVertically(spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessMedium)) { it }
    }

    fun bottomBarExit(): ExitTransition = when (mode) {
        AnimationMode.OFF -> ExitTransition.None
        AnimationMode.MEDIUM -> fadeOut(tween(140)) + slideOutVertically(tween(160)) { it }
        AnimationMode.HIGH -> fadeOut(tween(180)) + slideOutVertically(tween(200)) { it }
    }

    fun staggerDelayMillis(index: Int): Int = when (mode) {
        AnimationMode.OFF -> 0
        AnimationMode.MEDIUM -> (index.coerceAtMost(8)) * 12
        AnimationMode.HIGH -> (index.coerceAtMost(12)) * 28
    }
}

val LocalAnimationSpecs = staticCompositionLocalOf { AppAnimationSpecs(AnimationMode.MEDIUM) }
