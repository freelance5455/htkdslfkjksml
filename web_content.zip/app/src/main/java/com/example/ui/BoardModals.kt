package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SecondaryScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.chess.AVAILABLE_BOARD_THEMES
import com.example.chess.BoardTheme
import com.example.chess.ChessBoardState
import com.example.chess.ChessEngineCore
import com.example.chess.ChessPiece
import com.example.chess.MoveNode
import com.example.chess.PieceColor
import com.example.chess.PieceType
import com.example.data.CatalogDiagramEntity
import com.example.data.PmsPositionEntity
import com.example.scanner.DiagramScanResult
import com.example.scanner.PieceCodes
import com.example.scanner.ScannerFenAndVoting
import com.example.scanner.TemplateCoverage
import com.example.ui.theme.JetBrainsMonoFontFamily

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PmsStudyModal(
    currentFen: String,
    savedPositions: List<PmsPositionEntity>,
    onSaveCurrent: (title: String, note: String) -> Unit,
    onLoadFen: (fen: String, title: String) -> Unit,
    onDeletePosition: (String) -> Unit,
    onResetStart: () -> Unit,
    onDismiss: () -> Unit
) {
    var activeTab by remember { mutableIntStateOf(0) }
    var newTitle by remember { mutableStateOf("") }
    var newNote by remember { mutableStateOf("") }
    var customFen by remember { mutableStateOf(currentFen) }
    var fenError by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 560.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Study Positions & FEN Setup", style = MaterialTheme.typography.titleMedium)
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                SecondaryScrollableTabRow(selectedTabIndex = activeTab, edgePadding = 0.dp) {
                    Tab(selected = activeTab == 0, onClick = { activeTab = 0 }, text = { Text("Saved (${savedPositions.size})") })
                    Tab(selected = activeTab == 1, onClick = { activeTab = 1 }, text = { Text("Save Current") })
                    Tab(selected = activeTab == 2, onClick = { activeTab = 2 }, text = { Text("FEN Setup") })
                }

                Spacer(Modifier.height(12.dp))

                when (activeTab) {
                    0 -> {
                        if (savedPositions.isEmpty()) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(180.dp)
                            ) {
                                Text(
                                    "No saved study positions yet.\nSwitch to 'Save Current' to bookmark positions from your book.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        } else {
                            LazyColumn(
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.weight(1f, fill = false)
                            ) {
                                items(savedPositions, key = { it.id }) { pos ->
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                onLoadFen(pos.fen, pos.title)
                                                onDismiss()
                                            }
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.padding(10.dp)
                                        ) {
                                            MiniChessboardPreview(fen = pos.fen, modifier = Modifier.size(56.dp))
                                            Spacer(Modifier.width(10.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(pos.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                if (!pos.bookTitle.isNullOrBlank()) {
                                                    Text(
                                                        "${pos.bookTitle} • p.${pos.pageNumber ?: 1}",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.primary
                                                    )
                                                }
                                                if (pos.note.isNotBlank()) {
                                                    Text(pos.note, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                                }
                                            }
                                            IconButton(onClick = { onDeletePosition(pos.id) }) {
                                                Icon(Icons.Default.Delete, contentDescription = "Delete position")
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    1 -> {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                MiniChessboardPreview(fen = currentFen, modifier = Modifier.size(64.dp))
                                Spacer(Modifier.width(12.dp))
                                Text(
                                    currentFen,
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            OutlinedTextField(
                                value = newTitle,
                                onValueChange = { newTitle = it },
                                label = { Text("Position Title") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("pms_title_input")
                            )
                            OutlinedTextField(
                                value = newNote,
                                onValueChange = { newNote = it },
                                label = { Text("Study Note / Evaluation") },
                                minLines = 2,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Button(
                                onClick = {
                                    onSaveCurrent(newTitle, newNote)
                                    newTitle = ""
                                    newNote = ""
                                    activeTab = 0
                                },
                                modifier = Modifier.fillMaxWidth().testTag("pms_save_button")
                            ) {
                                Text("Save Position")
                            }
                        }
                    }

                    2 -> {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedTextField(
                                value = customFen,
                                onValueChange = {
                                    customFen = it
                                    fenError = null
                                },
                                label = { Text("FEN String") },
                                modifier = Modifier.fillMaxWidth().testTag("custom_fen_input")
                            )
                            if (fenError != null) {
                                Text(fenError!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = {
                                        onResetStart()
                                        onDismiss()
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("Start Pos")
                                }
                                Button(
                                    onClick = {
                                        if (ChessEngineCore.parseFen(customFen) == null) {
                                            fenError = "Invalid or illegal chess FEN position."
                                        } else {
                                            onLoadFen(customFen.trim(), "Custom FEN")
                                            onDismiss()
                                        }
                                    },
                                    modifier = Modifier.weight(1f).testTag("apply_custom_fen_button")
                                ) {
                                    Text("Load FEN")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun BoardToolsBottomSheet(
    boardState: ChessBoardState,
    currentTheme: BoardTheme,
    catalogDiagrams: List<CatalogDiagramEntity>,
    templateCoverage: TemplateCoverage,
    batchScanState: BatchScanState,
    onSelectNode: (String) -> Unit,
    onPromoteVariation: (String) -> Unit,
    onDeleteBranch: (String) -> Unit,
    onUpdateMoveComment: (String) -> Unit,
    onToggleNag: (String) -> Unit,
    onImportPgn: (String, Boolean) -> Unit,
    onExportPgn: () -> String,
    onSelectTheme: (BoardTheme) -> Unit,
    onLoadDiagramFromCatalog: (CatalogDiagramEntity) -> Unit,
    onJumpToPage: (Int) -> Unit,
    onStartBatchScan: () -> Unit,
    onPauseResumeBatchScan: () -> Unit,
    onCancelBatchScan: () -> Unit,
    onOpenExportZipDialog: () -> Unit = {},
    onDismiss: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val clipboard = LocalClipboardManager.current
    var pgnInput by remember { mutableStateOf("") }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 340.dp, max = 560.dp)
                .padding(horizontal = 16.dp)
                .padding(bottom = 24.dp)
        ) {
            SecondaryScrollableTabRow(selectedTabIndex = selectedTab, edgePadding = 0.dp) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Moves & Comments") })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("PGN Import/Export") })
                Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Diagram Catalog") })
                Tab(selected = selectedTab == 3, onClick = { selectedTab = 3 }, text = { Text("Board Themes") })
                Tab(
                    selected = selectedTab == 4,
                    onClick = {
                        onDismiss()
                        onOpenExportZipDialog()
                    },
                    text = { Text("Export App (.ZIP)") }
                )
            }

            Spacer(Modifier.height(12.dp))

            when (selectedTab) {
                0 -> {
                    val currentNode = boardState.currentNode
                    var commentDraft by remember(currentNode.id, currentNode.comment) {
                        mutableStateOf(currentNode.comment)
                    }
                    Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.verticalScroll(rememberScrollState())
                    ) {
                        // NAG Annotation Chips
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.horizontalScroll(rememberScrollState())
                        ) {
                            for (nag in listOf("!", "!!", "?", "??", "!?", "?!")) {
                                val selected = nag in currentNode.nags
                                FilterChip(
                                    selected = selected,
                                    onClick = { onToggleNag(nag) },
                                    label = { Text(nag, fontWeight = FontWeight.Bold) },
                                    enabled = currentNode.id != boardState.rootNodeId
                                )
                            }
                        }

                        // Move Comment Box
                        OutlinedTextField(
                            value = commentDraft,
                            onValueChange = {
                                commentDraft = it
                                onUpdateMoveComment(it)
                            },
                            label = {
                                Text(
                                    if (currentNode.id == boardState.rootNodeId) "Position / Game Intro Comment"
                                    else "Comment on ${currentNode.san}"
                                )
                            },
                            minLines = 2,
                            modifier = Modifier.fillMaxWidth().testTag("sheet_move_comment_input")
                        )

                        HorizontalDivider()
                        Text("Variation Tree", style = MaterialTheme.typography.titleMedium)

                        VariationTreeComposable(
                            boardState = boardState,
                            onSelectNode = onSelectNode,
                            onPromoteVariation = onPromoteVariation,
                            onDeleteBranch = onDeleteBranch
                        )
                    }
                }

                1 -> {
                    val exported = remember(boardState) { onExportPgn() }
                    Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.verticalScroll(rememberScrollState())
                    ) {
                        Text("Export Current Board PGN", fontWeight = FontWeight.SemiBold)
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                exported,
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 11.sp,
                                maxLines = 6,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { clipboard.setText(AnnotatedString(exported)) },
                                modifier = Modifier.weight(1f).testTag("copy_pgn_button")
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Copy PGN")
                            }
                            OutlinedButton(
                                onClick = { clipboard.setText(AnnotatedString(boardState.fen)) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Copy FEN")
                            }
                        }

                        HorizontalDivider()
                        Text("Import PGN Moves or Game", fontWeight = FontWeight.SemiBold)
                        OutlinedTextField(
                            value = pgnInput,
                            onValueChange = { pgnInput = it },
                            placeholder = { Text("Paste PGN with variations or comments...") },
                            minLines = 4,
                            modifier = Modifier.fillMaxWidth().testTag("import_pgn_textfield")
                        )
                        Button(
                            onClick = {
                                if (pgnInput.isNotBlank()) {
                                    onImportPgn(pgnInput, true)
                                    onDismiss()
                                }
                            },
                            modifier = Modifier.fillMaxWidth().testTag("load_pgn_submit_button")
                        ) {
                            Text("Import onto Analysis Board")
                        }
                    }
                }

                2 -> {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    "Offline NCC Template Library: ${templateCoverage.totalLearned}/${templateCoverage.totalRequired} (${templateCoverage.percentage}%)",
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    "Learned 32x32 piece templates scan diagrams in <10ms offline.",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Spacer(Modifier.height(8.dp))
                                if (batchScanState.isRunning) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text(
                                            "Scanning p.${batchScanState.currentPage}/${batchScanState.totalPages} (${batchScanState.diagramsFound} found)",
                                            style = MaterialTheme.typography.labelLarge,
                                            modifier = Modifier.weight(1f)
                                        )
                                        TextButton(onClick = onPauseResumeBatchScan) {
                                            Text(if (batchScanState.isPaused) "Resume" else "Pause")
                                        }
                                        TextButton(onClick = onCancelBatchScan) { Text("Stop") }
                                    }
                                } else {
                                    Button(onClick = onStartBatchScan, modifier = Modifier.testTag("batch_scan_book_button")) {
                                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("Batch Scan Book Diagrams Offline")
                                    }
                                }
                            }
                        }

                        if (catalogDiagrams.isEmpty()) {
                            Text(
                                "No cataloged diagrams for this book yet. Double-tap any diagram on a PDF page or run Batch Scan above.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(catalogDiagrams, key = { it.id }) { diag ->
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                onLoadDiagramFromCatalog(diag)
                                                onJumpToPage(diag.pageNumber)
                                                onDismiss()
                                            }
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.padding(8.dp)
                                        ) {
                                            MiniChessboardPreview(fen = diag.fen, modifier = Modifier.size(52.dp))
                                            Spacer(Modifier.width(10.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text("${diag.title} • Page ${diag.pageNumber}", fontWeight = FontWeight.SemiBold)
                                                Text(
                                                    "${(diag.confidence * 100).toInt()}% confidence • ${diag.sourceMethod}",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                3 -> {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(AVAILABLE_BOARD_THEMES, key = { it.id }) { theme ->
                            val isSelected = theme.id == currentTheme.id
                            Card(
                                border = if (isSelected) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onSelectTheme(theme) }
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(12.dp)
                                ) {
                                    Row(modifier = Modifier.clip(RoundedCornerShape(6.dp))) {
                                        Box(Modifier.size(24.dp).background(theme.lightSquare))
                                        Box(Modifier.size(24.dp).background(theme.darkSquare))
                                    }
                                    Spacer(Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(theme.name, fontWeight = FontWeight.SemiBold)
                                        Text(theme.description, style = MaterialTheme.typography.labelSmall)
                                    }
                                    if (isSelected) {
                                        Icon(Icons.Default.Check, contentDescription = "Selected", tint = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VariationTreeComposable(
    boardState: ChessBoardState,
    onSelectNode: (String) -> Unit,
    onPromoteVariation: (String) -> Unit,
    onDeleteBranch: (String) -> Unit
) {
    val root = boardState.nodes[boardState.rootNodeId] ?: return
    if (root.childrenIds.isEmpty()) {
        Text(
            "Play moves on the board or import a game to build variations and comments.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        return
    }

    val initialTurn = remember(boardState.initialFen) {
        ChessEngineCore.parseFen(boardState.initialFen)?.turn ?: PieceColor.WHITE
    }
    val initialMoveNum = remember(boardState.initialFen) {
        ChessEngineCore.parseFen(boardState.initialFen)?.fullMoveNumber ?: 1
    }

    fun formatMoveLabel(node: MoveNode): String {
        val idx = node.ply - 1
        val isWhite = if (initialTurn == PieceColor.WHITE) idx % 2 == 0 else idx % 2 == 1
        val moveNum = if (initialTurn == PieceColor.WHITE) initialMoveNum + idx / 2 else initialMoveNum + (idx + 1) / 2
        val prefix = if (isWhite) "$moveNum." else "$moveNum..."
        val nags = node.nags.joinToString("")
        return "$prefix${node.san}$nags"
    }

    // Flatten main line + sidelines cleanly
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            for (node in boardState.nodes.values.filter { it.id != boardState.rootNodeId }.sortedBy { it.ply }) {
                val isCurrent = node.id == boardState.currentNodeId
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.clickable { onSelectNode(node.id) }
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = formatMoveLabel(node) + if (node.comment.isNotBlank()) " 💬" else "",
                            fontSize = 12.sp,
                            fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                            color = if (isCurrent) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        if (boardState.currentNodeId != boardState.rootNodeId) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { onPromoteVariation(boardState.currentNodeId) }) {
                    Icon(Icons.Default.ArrowUpward, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Promote Line", fontSize = 12.sp)
                }
                OutlinedButton(
                    onClick = { onDeleteBranch(boardState.currentNodeId) },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Delete Move", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun DiagramReviewModal(
    sensorState: ActiveSensorState,
    onConfirmAndLearn: (Array<Array<String>>) -> Unit,
    onDismiss: () -> Unit
) {
    val scan = sensorState.lastResult ?: return
    var editableGrid by remember(scan) {
        mutableStateOf(ScannerFenAndVoting.copyGrid(scan.grid))
    }
    var selectedPaletteCode by remember { mutableStateOf("wP") }

    val validation = remember(editableGrid, sensorState.preferredTurn) {
        ScannerFenAndVoting.validateBoard(editableGrid, sensorState.preferredTurn, orientation = scan.orientation)
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier
                    .padding(14.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Verify Diagram & Learn Book", style = MaterialTheme.typography.titleMedium)
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "Close") }
                }

                // Side-by-side Original Crop vs Digital Editable Grid
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    sensorState.cleanCropBitmap?.let { bmp ->
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = "Cropped PDF diagram",
                            modifier = Modifier
                                .weight(1f)
                                .aspectRatio(1f)
                                .border(1.dp, Color.Gray)
                        )
                    }
                    // Editable 8x8 grid
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .aspectRatio(1f)
                            .border(1.dp, Color.DarkGray)
                    ) {
                        for (r in 0..7) {
                            Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
                                for (c in 0..7) {
                                    val sqName = ScannerFenAndVoting.gridToSquare(r, c, scan.orientation)
                                    val isUncertain = sqName in scan.uncertainSquares
                                    val isDark = (r + c) % 2 == 1
                                    val code = editableGrid[r][c]
                                    Box(
                                        contentAlignment = Alignment.Center,
                                        modifier = Modifier
                                            .weight(1f)
                                            .fillMaxHeight()
                                            .background(
                                                when {
                                                    isUncertain -> Color(0xFFFDE68A)
                                                    isDark -> Color(0xFFB58863)
                                                    else -> Color(0xFFF0D9B5)
                                                }
                                            )
                                            .clickable {
                                                val next = ScannerFenAndVoting.copyGrid(editableGrid)
                                                next[r][c] = if (next[r][c] == selectedPaletteCode) "empty" else selectedPaletteCode
                                                editableGrid = next
                                            }
                                    ) {
                                        if (code != "empty") {
                                            val pColor = if (code.startsWith("w")) PieceColor.WHITE else PieceColor.BLACK
                                            val pType = PieceType.fromChar(code[1]) ?: PieceType.PAWN
                                            PieceGlyphIcon(piece = ChessPiece(pColor, pType), modifier = Modifier.fillMaxWidth(0.88f))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Text(
                    "Tap a piece below, then tap any square above to adjust:",
                    style = MaterialTheme.typography.labelSmall
                )

                // Piece Palette
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.horizontalScroll(rememberScrollState())
                ) {
                    for (code in PieceCodes.ALL) {
                        val isSel = selectedPaletteCode == code
                        Surface(
                            shape = CircleShape,
                            color = if (isSel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                            border = if (isSel) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
                            modifier = Modifier
                                .size(38.dp)
                                .clickable { selectedPaletteCode = code }
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                if (code == "empty") {
                                    Text("∅", fontWeight = FontWeight.Bold)
                                } else {
                                    val pc = if (code.startsWith("w")) PieceColor.WHITE else PieceColor.BLACK
                                    val pt = PieceType.fromChar(code[1]) ?: PieceType.PAWN
                                    PieceGlyphIcon(ChessPiece(pc, pt), Modifier.size(28.dp))
                                }
                            }
                        }
                    }
                }

                if (!validation.isValid) {
                    Text(
                        validation.errors.joinToString("\n"),
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.labelSmall
                    )
                }

                Button(
                    onClick = { onConfirmAndLearn(editableGrid) },
                    modifier = Modifier.fillMaxWidth().testTag("confirm_learn_diagram_button")
                ) {
                    Text("Load on Board & Save Book Templates")
                }
            }
        }
    }
}
