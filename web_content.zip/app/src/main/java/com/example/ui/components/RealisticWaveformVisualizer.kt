package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.RecordingState
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.LedGreen
import com.example.ui.theme.LedOff
import com.example.ui.theme.LedRed
import com.example.ui.theme.LedYellow
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.StudioBlack
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioDivider
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.log10
import kotlin.math.roundToInt

@Composable
fun RealisticWaveformVisualizer(
    waveform: FloatArray,
    rmsLevel: Float,
    peakLevel: Float,
    recordingState: RecordingState,
    recordingDurationMs: Long,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "rec_blink")
    val recAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(600),
            repeatMode = RepeatMode.Reverse
        ),
        label = "rec_lamp_alpha"
    )

    val dbValue = if (peakLevel > 0.001f) {
        (20 * log10(peakLevel.coerceIn(0.001f, 1.0f))).coerceIn(-60f, 0f)
    } else {
        -60f
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(StudioBlack)
            .border(1.dp, StudioBorder, RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Header: Status indicator, Title & Timecode / Peak dB
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Recording / Live Status
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val statusColor = when (recordingState) {
                        RecordingState.RECORDING -> LedRed.copy(alpha = recAlpha)
                        RecordingState.PAUSED -> LedYellow
                        RecordingState.IDLE -> LedGreen
                    }
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(statusColor)
                    )
                    Text(
                        text = when (recordingState) {
                            RecordingState.RECORDING -> "REC ON AIR"
                            RecordingState.PAUSED -> "PAUSED"
                            RecordingState.IDLE -> "LIVE DSP ACTIVE"
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = when (recordingState) {
                            RecordingState.RECORDING -> LedRed
                            RecordingState.PAUSED -> LedYellow
                            RecordingState.IDLE -> EmeraldLight
                        }
                    )
                }

                // Timecode & dB
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Elapsed Time if recording
                    if (recordingState != RecordingState.IDLE) {
                        val totalSec = recordingDurationMs / 1000
                        val min = totalSec / 60
                        val sec = totalSec % 60
                        val ms = (recordingDurationMs % 1000) / 100
                        Text(
                            text = String.format("%02d:%02d.%d", min, sec, ms),
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = TextPrimary
                        )
                    }

                    // Peak Level dB Readout
                    Text(
                        text = if (dbValue <= -59f) "-INF dB" else "${dbValue.roundToInt()} dB",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = if (dbValue >= -2f) LedRed else if (dbValue >= -6f) LedYellow else TextSecondary
                    )
                }
            }

            // Display Screen: Oscilloscope Waveform + Segmented VU Meter
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(96.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(StudioSurface)
                    .border(1.dp, StudioDivider, RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left: Oscilloscope Canvas
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val width = size.width
                        val height = size.height
                        val midY = height / 2f

                        // 1. Oscilloscope Studio Graticule Grid
                        // Center baseline
                        drawLine(
                            color = StudioDivider.copy(alpha = 0.8f),
                            start = Offset(0f, midY),
                            end = Offset(width, midY),
                            strokeWidth = 1.dp.toPx()
                        )
                        // Top & Bottom limits
                        drawLine(
                            color = StudioDivider.copy(alpha = 0.4f),
                            start = Offset(0f, height * 0.2f),
                            end = Offset(width, height * 0.2f),
                            strokeWidth = 1.dp.toPx()
                        )
                        drawLine(
                            color = StudioDivider.copy(alpha = 0.4f),
                            start = Offset(0f, height * 0.8f),
                            end = Offset(width, height * 0.8f),
                            strokeWidth = 1.dp.toPx()
                        )

                        // 2. Real-time Audio Waveform Path
                        if (waveform.isNotEmpty()) {
                            val path = Path()
                            val points = waveform.size
                            val stepX = width / (points - 1).coerceAtLeast(1)

                            for (i in 0 until points) {
                                val sample = waveform[i].coerceIn(-1.0f, 1.0f)
                                val x = i * stepX
                                val y = midY - (sample * (height * 0.44f))

                                if (i == 0) {
                                    path.moveTo(x, y)
                                } else {
                                    path.lineTo(x, y)
                                }
                            }

                            // Glowing wide beam underlay
                            drawPath(
                                path = path,
                                color = EmeraldPrimary.copy(alpha = 0.25f),
                                style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                            )
                            // Sharp core beam
                            drawPath(
                                path = path,
                                color = EmeraldLight,
                                style = Stroke(width = 1.5.dp.toPx(), cap = StrokeCap.Round)
                            )
                        }
                    }
                }

                // Vertical Divider
                Spacer(
                    modifier = Modifier
                        .width(1.dp)
                        .fillMaxHeight()
                        .background(StudioDivider)
                )

                // Right: Studio Hardware VU Meter Bars
                VuMeterSegmentBar(
                    peakLevel = peakLevel,
                    rmsLevel = rmsLevel,
                    modifier = Modifier.width(36.dp).fillMaxHeight()
                )
            }
        }
    }
}

/**
 * 12-segment vertical LED VU Meter with Green, Amber, and Red overload zones.
 */
@Composable
fun VuMeterSegmentBar(
    peakLevel: Float,
    rmsLevel: Float,
    modifier: Modifier = Modifier
) {
    val totalSegments = 12
    val activePeakSegments = (peakLevel.coerceIn(0f, 1f) * totalSegments).roundToInt()
    val activeRmsSegments = (rmsLevel.coerceIn(0f, 1f) * totalSegments).roundToInt()

    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        for (i in (totalSegments - 1) downTo 0) {
            val isActive = i < activePeakSegments
            val isRmsActive = i < activeRmsSegments

            val segmentColor = when {
                i >= 10 -> if (isActive) LedRed else LedOff
                i >= 7 -> if (isActive) LedYellow else LedOff
                else -> if (isActive) LedGreen else LedOff
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.5.dp)
                    .clip(RoundedCornerShape(1.dp))
                    .background(
                        if (isRmsActive) segmentColor else segmentColor.copy(alpha = if (isActive) 0.6f else 0.2f)
                    )
            )
        }
    }
}
