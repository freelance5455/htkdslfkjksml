package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.BookingStatus
import com.example.data.model.ClientWithBookings
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.SdTopAppBar
import com.example.ui.components.StatusBadge
import com.example.ui.theme.BackgroundWhite
import com.example.ui.theme.BorderLight
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.GoldSecondary
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.StatusConfirmedFg
import com.example.ui.theme.StatusPendingFg
import com.example.ui.theme.SurfaceLightGray
import com.example.ui.theme.TextSecondary
import com.example.utils.CurrencyFormatters

@Composable
fun ClientsListScreen(
    clients: List<ClientWithBookings>,
    onBack: () -> Unit,
    onAddBooking: () -> Unit,
    onOpenClientDetail: (Long) -> Unit,
) {
    var quickQuery by remember { mutableStateOf("") }
    var selectedStatus by remember { mutableStateOf<BookingStatus?>(null) }
    var onlyUnpaid by remember { mutableStateOf(false) }

    val filtered = remember(clients, quickQuery, selectedStatus, onlyUnpaid) {
        clients.filter { item ->
            val q = quickQuery.trim()
            val matchesQuery = q.isEmpty() ||
                item.client.clientCode.contains(q, ignoreCase = true) ||
                item.client.fullName.contains(q, ignoreCase = true) ||
                item.client.phone.contains(q, ignoreCase = true) ||
                item.client.passportNumber.contains(q, ignoreCase = true)

            val matchesStatus = selectedStatus == null ||
                item.bookings.any { it.booking.status == selectedStatus }

            val matchesUnpaid = !onlyUnpaid || item.totalRemainingAcrossBookings > 0.01

            matchesQuery && matchesStatus && matchesUnpaid
        }
    }

    Scaffold(
        containerColor = SurfaceLightGray,
        topBar = {
            SdTopAppBar(
                title = "قائمة العملاء",
                subtitle = "${filtered.size} عميل من أصل ${clients.size}",
                onBack = onBack,
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onAddBooking,
                containerColor = NavyPrimary,
                contentColor = GoldSecondary,
                modifier = Modifier
                    .navigationBarsPadding()
                    .testTag("clients_fab_add"),
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة حجز جديد")
            }
        },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                OutlinedTextField(
                    value = quickQuery,
                    onValueChange = { quickQuery = it },
                    placeholder = { Text("بحث سريع بالكود أو الاسم أو الهاتف أو الجواز...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = NavyPrimary) },
                    trailingIcon = {
                        if (quickQuery.isNotEmpty()) {
                            IconButton(onClick = { quickQuery = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "مسح")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NavyPrimary,
                        unfocusedBorderColor = BorderLight,
                        focusedContainerColor = BackgroundWhite,
                        unfocusedContainerColor = BackgroundWhite,
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("clients_quick_search"),
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    FilterChip(
                        selected = selectedStatus == null && !onlyUnpaid,
                        onClick = {
                            selectedStatus = null
                            onlyUnpaid = false
                        },
                        label = { Text("الكل") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NavyPrimary,
                            selectedLabelColor = GoldSecondary,
                        ),
                    )
                    BookingStatus.entries.forEach { st ->
                        FilterChip(
                            selected = selectedStatus == st,
                            onClick = { selectedStatus = if (selectedStatus == st) null else st },
                            label = { Text(st.arabicLabel) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = NavyPrimary,
                                selectedLabelColor = GoldSecondary,
                            ),
                        )
                    }
                    FilterChip(
                        selected = onlyUnpaid,
                        onClick = { onlyUnpaid = !onlyUnpaid },
                        label = { Text("عليهم متبقي") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NavyPrimary,
                            selectedLabelColor = GoldSecondary,
                        ),
                    )
                }
            }

            if (filtered.isEmpty()) {
                BoxFallbackEmpty(
                    hasAnyClients = clients.isNotEmpty(),
                    onAddBooking = onAddBooking,
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 92.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(filtered, key = { it.client.id }) { item ->
                        ClientSummaryCard(
                            item = item,
                            onClick = { onOpenClientDetail(item.client.id) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BoxFallbackEmpty(hasAnyClients: Boolean, onAddBooking: () -> Unit) {
    Column(modifier = Modifier.padding(16.dp)) {
        EmptyStateCard(
            icon = Icons.Default.People,
            title = if (hasAnyClients) "لا توجد نتائج مطابقة" else "قائمة العملاء فارغة",
            subtitle = if (hasAnyClients) {
                "جرب تغيير كلمات البحث أو إزالة الفلاتر لعرض جميع العملاء."
            } else {
                "قم بإضافة أول عميل وحجز عمرة ليظهر هنا مع كامل تفاصيله."
            },
            actionLabel = if (!hasAnyClients) "إضافة حجز جديد" else null,
            onAction = if (!hasAnyClients) onAddBooking else null,
        )
    }
}

@Composable
fun ClientSummaryCard(
    item: ClientWithBookings,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val latestBooking = item.bookings.maxByOrNull { it.booking.createdAt }
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("client_card_${item.client.clientCode}"),
        colors = CardDefaults.cardColors(containerColor = BackgroundWhite),
        border = BorderStroke(1.dp, BorderLight),
        shape = RoundedCornerShape(16.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = GoldContainer,
                        border = BorderStroke(1.dp, GoldSecondary.copy(alpha = 0.6f)),
                    ) {
                        Text(
                            text = item.client.clientCode,
                            style = MaterialTheme.typography.labelLarge,
                            color = NavyPrimary,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = item.client.fullName,
                        style = MaterialTheme.typography.titleMedium,
                        color = NavyPrimary,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                if (latestBooking != null) {
                    StatusBadge(status = latestBooking.booking.status)
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Phone,
                        contentDescription = null,
                        tint = TextSecondary,
                        modifier = Modifier.height(16.dp),
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = item.client.phone.ifBlank { "بدون هاتف" },
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                    )
                }
                if (latestBooking != null) {
                    Text(
                        text = "الرحلة: ${latestBooking.booking.tripDate} • ${latestBooking.booking.companyName.ifBlank { latestBooking.booking.tripType.arabicLabel }}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    text = "المدفوع: ${CurrencyFormatters.formatMoney(item.totalPaidAcrossBookings)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = StatusConfirmedFg,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    text = "المتبقي: ${CurrencyFormatters.formatMoney(item.totalRemainingAcrossBookings)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = if (item.totalRemainingAcrossBookings > 0) StatusPendingFg else StatusConfirmedFg,
                    fontWeight = FontWeight.Bold,
                )
            }
        }
    }
}
