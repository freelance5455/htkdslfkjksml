package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.NavigateBefore
import androidx.compose.material.icons.filled.NavigateNext
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated

/**
 * Poweramp Pro Play / Pause Button with metallic bezel, concentric illumination, and tactile feel.
 */
@Composable
fun PowerampProPlayButton(
    isPlaying: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val infiniteTransition = rememberInfiniteTransition()
    val glowPulse by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        )
    )

    val scale = if (isPressed) 0.94f else 1.0f

    Box(
        modifier = modifier
            .size(76.dp)
            .scale(scale)
            .shadow(
                elevation = if (isPlaying) 16.dp else 8.dp,
                shape = CircleShape,
                ambientColor = if (isPlaying) NeonCyan else Color.Black,
                spotColor = if (isPlaying) NeonPurple else Color.Black
            )
            .clip(CircleShape)
            // Outer Bezel Rim
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        Color(0xFF384052),
                        Color(0xFF1E222C),
                        Color(0xFF0F1217)
                    )
                )
            )
            .border(
                width = 2.dp,
                brush = Brush.sweepGradient(
                    listOf(
                        if (isPlaying) NeonCyan.copy(alpha = glowPulse) else Color.White.copy(alpha = 0.2f),
                        if (isPlaying) NeonPurple.copy(alpha = glowPulse) else Color.White.copy(alpha = 0.05f),
                        if (isPlaying) NeonCyan.copy(alpha = glowPulse) else Color.White.copy(alpha = 0.2f)
                    )
                ),
                shape = CircleShape
            )
            .clickable(
                interactionSource = interactionSource,
                indication = ripple(bounded = true, color = NeonCyan),
                onClick = onClick
            )
            .testTag("poweramp_pro_play_btn"),
        contentAlignment = Alignment.Center
    ) {
        // Recessed Center Disc
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0xFF181C25),
                            Color(0xFF0E1015),
                            ObsidianBg
                        )
                    )
                )
                .border(1.dp, Color.White.copy(alpha = 0.1f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = if (isPlaying) "Pause" else "Play",
                tint = if (isPlaying) NeonCyan else Color.White,
                modifier = Modifier.size(34.dp)
            )
        }
    }
}

/**
 * Poweramp Pro Skip Track Button (Previous / Next) with tactile dark gunmetal disc.
 */
@Composable
fun PowerampProTrackButton(
    isNext: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale = if (isPressed) 0.92f else 1.0f

    Box(
        modifier = modifier
            .size(50.dp)
            .scale(scale)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    listOf(
                        Color(0xFF262C3A),
                        Color(0xFF171B24),
                        Color(0xFF10131A)
                    )
                )
            )
            .border(1.2.dp, Color.White.copy(alpha = 0.18f), CircleShape)
            .clickable(
                interactionSource = interactionSource,
                indication = ripple(bounded = true, color = Color.White),
                onClick = onClick
            )
            .testTag(if (isNext) "poweramp_next_btn" else "poweramp_prev_btn"),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = if (isNext) Icons.Default.SkipNext else Icons.Default.SkipPrevious,
            contentDescription = if (isNext) "Next Track" else "Previous Track",
            tint = Color.White,
            modifier = Modifier.size(28.dp)
        )
    }
}

/**
 * Poweramp Pro Multi-State Shuffle Button.
 */
@Composable
fun PowerampProShuffleButton(
    shuffleMode: Int, // 0: Off, 1: All, 2: Categories
    onToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isOff = shuffleMode == 0
    val isAll = shuffleMode == 1

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onToggle)
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .testTag("poweramp_shuffle_btn"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Default.Shuffle,
            contentDescription = "Shuffle",
            tint = if (isOff) Color.Gray else if (isAll) NeonCyan else NeonPurple,
            modifier = Modifier.size(22.dp)
        )
        Text(
            text = when (shuffleMode) {
                1 -> "ALL"
                2 -> "CAT"
                else -> "OFF"
            },
            fontSize = 8.5.sp,
            fontWeight = FontWeight.Bold,
            color = if (isOff) Color.Gray else if (isAll) NeonCyan else NeonPurple
        )
    }
}

/**
 * Poweramp Pro Multi-State Repeat Button.
 */
@Composable
fun PowerampProRepeatButton(
    repeatMode: Int, // 0: Off, 1: All, 2: Single Track
    onToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isOff = repeatMode == 0
    val isOne = repeatMode == 2

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onToggle)
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .testTag("poweramp_repeat_btn"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = if (isOne) Icons.Default.RepeatOne else Icons.Default.Repeat,
            contentDescription = "Repeat",
            tint = if (isOff) Color.Gray else if (isOne) NeonPink else NeonCyan,
            modifier = Modifier.size(22.dp)
        )
        Text(
            text = when (repeatMode) {
                1 -> "ALL"
                2 -> "ONE"
                else -> "OFF"
            },
            fontSize = 8.5.sp,
            fontWeight = FontWeight.Bold,
            color = if (isOff) Color.Gray else if (isOne) NeonPink else NeonCyan
        )
    }
}

/**
 * Poweramp Pro Complete Transport Controls Row.
 */
@Composable
fun PowerampProControlsRow(
    isPlaying: Boolean,
    shuffleMode: Int,
    repeatMode: Int,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onToggleShuffle: () -> Unit,
    onToggleRepeat: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Multi-state Shuffle
        PowerampProShuffleButton(
            shuffleMode = shuffleMode,
            onToggle = onToggleShuffle
        )

        // Previous Track
        PowerampProTrackButton(
            isNext = false,
            onClick = onPrevious
        )

        // Center Big Play/Pause
        PowerampProPlayButton(
            isPlaying = isPlaying,
            onClick = onPlayPause
        )

        // Next Track
        PowerampProTrackButton(
            isNext = true,
            onClick = onNext
        )

        // Multi-state Repeat
        PowerampProRepeatButton(
            repeatMode = repeatMode,
            onToggle = onToggleRepeat
        )
    }
}

/**
 * Poweramp Pro Visualizer Stage On-Screen Display (OSD) Header & Controls.
 */
@Composable
fun PowerampProVisualizerHUD(
    visualizerId: Int,
    visualizerName: String,
    isLocked: Boolean,
    onToggleLock: () -> Unit,
    onPrevVisualizer: () -> Unit,
    onNextVisualizer: () -> Unit,
    onPickerClick: () -> Unit,
    onFullscreenClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Visualizer Preset Title Pill with Lock
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .background(ObsidianBg.copy(alpha = 0.85f))
                .border(1.dp, NeonCyan.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                .clickable(onClick = onPickerClick)
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.GraphicEq,
                contentDescription = null,
                tint = NeonCyan,
                modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = "#$visualizerId $visualizerName",
                color = NeonCyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
        }

        // Quick Stage Controls: < PREV | LOCK | NEXT > | FULLSCREEN
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Previous Visualizer
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(ObsidianBg.copy(alpha = 0.75f))
                    .clickable(onClick = onPrevVisualizer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.NavigateBefore,
                    contentDescription = "Previous Visualizer",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Lock Preset
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(ObsidianBg.copy(alpha = 0.75f))
                    .clickable(onClick = onToggleLock),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                    contentDescription = if (isLocked) "Locked" else "Unlocked",
                    tint = if (isLocked) NeonPink else Color.Gray,
                    modifier = Modifier.size(15.dp)
                )
            }

            // Next Visualizer
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(ObsidianBg.copy(alpha = 0.75f))
                    .clickable(onClick = onNextVisualizer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.NavigateNext,
                    contentDescription = "Next Visualizer",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Fullscreen
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(ObsidianBg.copy(alpha = 0.75f))
                    .clickable(onClick = onFullscreenClick),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Fullscreen,
                    contentDescription = "Fullscreen Visualizer",
                    tint = NeonCyan,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
