package com.example.ui.chat

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.R
import com.example.data.model.ChatMessage
import com.example.data.model.MerkopMode
import com.example.data.repository.MerkopAiRepository
import com.example.util.HtmlTranscriptExporter
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject

private const val BRIDGE_TAG = "MerkopHtmlBridge"
private const val BUNDLED_HTML_URL = "file:///android_asset/index.html"

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun MerkopHtmlPreviewScreen(
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val aiRepository = remember { MerkopAiRepository() }
    val webViewHolder = remember { arrayOfNulls<WebView>(1) }
    val fileChooserCallbackHolder = remember {
        arrayOfNulls<android.webkit.ValueCallback<Array<Uri>>>(1)
    }

    val dispatchPickedModelUri: (Uri?) -> Unit = { uri ->
        if (uri != null) {
            scope.launch(Dispatchers.IO) {
                try {
                    val fileName = com.example.util.Model3dHelper.resolveDisplayName(context, uri)
                    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    if (bytes != null && bytes.isNotEmpty()) {
                        val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                        val script = "window.onMerkopNativeModelPicked && window.onMerkopNativeModelPicked(${JSONObject.quote(fileName)}, ${JSONObject.quote(b64)});"
                        withContext(Dispatchers.Main) {
                            webViewHolder[0]?.evaluateJavascript(script, null)
                        }
                    }
                } catch (e: Exception) {
                    Log.e(BRIDGE_TAG, "Failed to read native 3D model URI", e)
                }
            }
        }
    }

    val dispatchPickedImageUri: (Uri?) -> Unit = { uri ->
        if (uri != null) {
            scope.launch(Dispatchers.IO) {
                try {
                    val mime = context.contentResolver.getType(uri) ?: "image/jpeg"
                    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    if (bytes != null && bytes.isNotEmpty()) {
                        val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                        val dataUrl = "data:$mime;base64,$b64"
                        val script = "window.onMerkopNativeImagePicked && window.onMerkopNativeImagePicked(${JSONObject.quote(dataUrl)}, ${JSONObject.quote(mime)});"
                        withContext(Dispatchers.Main) {
                            webViewHolder[0]?.evaluateJavascript(script, null)
                        }
                    }
                } catch (e: Exception) {
                    Log.e(BRIDGE_TAG, "Failed to read native image URI", e)
                }
            }
        }
    }

    val nativeModelPickerLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.OpenDocument(),
        onResult = dispatchPickedModelUri
    )

    val nativeModelFallbackLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.GetContent(),
        onResult = dispatchPickedModelUri
    )

    val nativeImagePickerLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia(),
        onResult = dispatchPickedImageUri
    )

    val nativeImageFallbackLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.GetContent(),
        onResult = dispatchPickedImageUri
    )

    val filePickerLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        val cb = fileChooserCallbackHolder[0]
        fileChooserCallbackHolder[0] = null
        cb?.onReceiveValue(if (uris.isEmpty()) null else uris.toTypedArray())
    }

    val fallbackFilePickerLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri ->
        val cb = fileChooserCallbackHolder[0]
        fileChooserCallbackHolder[0] = null
        cb?.onReceiveValue(if (uri != null) arrayOf(uri) else null)
    }

    DisposableEffect(Unit) {
        onDispose {
            fileChooserCallbackHolder[0]?.onReceiveValue(null)
            fileChooserCallbackHolder[0] = null
            webViewHolder[0]?.apply {
                removeJavascriptInterface("MerkopNativeBridge")
                stopLoading()
                destroy()
            }
            webViewHolder[0] = null
        }
    }

    Surface(
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("html_preview_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = stringResource(R.string.cd_back_to_native),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.html_preview_title),
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "assets/index.html • Firebase AI Logic",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                IconButton(
                    onClick = { HtmlTranscriptExporter.shareStandaloneAppHtml(context) },
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("html_preview_share_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Share,
                        contentDescription = stringResource(R.string.action_share_full_html),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            AndroidView(
                factory = { ctx ->
                    WebView(ctx).apply {
                        webViewHolder[0] = this
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.allowFileAccess = false
                        settings.allowContentAccess = true
                        webChromeClient = object : android.webkit.WebChromeClient() {
                            override fun onShowFileChooser(
                                webView: WebView?,
                                filePathCallback: android.webkit.ValueCallback<Array<Uri>>?,
                                fileChooserParams: FileChooserParams?
                            ): Boolean {
                                fileChooserCallbackHolder[0]?.onReceiveValue(null)
                                fileChooserCallbackHolder[0] = filePathCallback
                                val accept = fileChooserParams?.acceptTypes
                                    ?.firstOrNull { it.isNotBlank() }
                                    ?: "*/*"
                                val launched = try {
                                    filePickerLauncher.launch(arrayOf("*/*"))
                                    true
                                } catch (_: Exception) {
                                    try {
                                        fallbackFilePickerLauncher.launch(accept)
                                        true
                                    } catch (_: Exception) {
                                        fileChooserCallbackHolder[0]?.onReceiveValue(null)
                                        fileChooserCallbackHolder[0] = null
                                        false
                                    }
                                }
                                return launched
                            }
                        }
                        webViewClient = object : WebViewClient() {
                            override fun shouldOverrideUrlLoading(
                                view: WebView?,
                                request: WebResourceRequest?
                            ): Boolean {
                                val target = request?.url?.toString().orEmpty()
                                return target != BUNDLED_HTML_URL
                            }
                        }
                        addJavascriptInterface(
                            MerkopWebBridge(
                                webView = this,
                                scope = scope,
                                aiRepository = aiRepository,
                                onLaunchModelPicker = {
                                    try {
                                        nativeModelPickerLauncher.launch(arrayOf("*/*"))
                                    } catch (_: Exception) {
                                        runCatching { nativeModelFallbackLauncher.launch("*/*") }
                                    }
                                },
                                onLaunchImagePicker = {
                                    try {
                                        nativeImagePickerLauncher.launch(
                                            androidx.activity.result.PickVisualMediaRequest(
                                                androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia.ImageOnly
                                            )
                                        )
                                    } catch (_: Exception) {
                                        runCatching { nativeImageFallbackLauncher.launch("image/*") }
                                    }
                                }
                            ),
                            "MerkopNativeBridge"
                        )
                        loadUrl(BUNDLED_HTML_URL)
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

private class MerkopWebBridge(
    private val webView: WebView,
    private val scope: CoroutineScope,
    private val aiRepository: MerkopAiRepository,
    private val onLaunchModelPicker: () -> Unit,
    private val onLaunchImagePicker: () -> Unit
) {
    @JavascriptInterface
    fun pickModel3dFromDevice() {
        scope.launch(Dispatchers.Main) {
            onLaunchModelPicker()
        }
    }

    @JavascriptInterface
    fun pickImageFromDevice() {
        scope.launch(Dispatchers.Main) {
            onLaunchImagePicker()
        }
    }

    @JavascriptInterface
    fun askGemini(
        reqId: String,
        modeId: String,
        historyJson: String,
        prompt: String,
        imageBase64: String
    ) {
        scope.launch(Dispatchers.IO) {
            val mode = MerkopMode.fromId(modeId)
            val history = parseHistory(historyJson)
            val bitmap = decodeBase64Bitmap(imageBase64)
            val accumulated = StringBuilder()

            try {
                withTimeout(60_000L) {
                    aiRepository.streamReply(
                        mode = mode,
                        history = history,
                        userPrompt = prompt,
                        attachedImage = bitmap
                    ).collect { chunk ->
                        accumulated.append(chunk)
                        val partial = accumulated.toString()
                        dispatchJs("window.onMerkopStreamChunk(${JSONObject.quote(reqId)}, ${JSONObject.quote(partial)})")
                    }
                    if (accumulated.isBlank()) {
                        val fallback = aiRepository.generateReplyUnary(
                            mode = mode,
                            history = history,
                            userPrompt = prompt,
                            attachedImage = bitmap
                        )
                        if (!fallback.isNullOrBlank()) {
                            accumulated.append(fallback)
                        }
                    }
                }
                val finalReply = accumulated.toString().trim()
                if (finalReply.isNotEmpty()) {
                    dispatchJs("window.onMerkopStreamComplete(${JSONObject.quote(reqId)}, ${JSONObject.quote(finalReply)})")
                } else {
                    dispatchJs("window.onMerkopStreamError(${JSONObject.quote(reqId)}, ${JSONObject.quote("Merkop boş yanıt döndürdü.")})")
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(BRIDGE_TAG, "HTML bridge inference timed out", e)
                dispatchJs("window.onMerkopStreamError(${JSONObject.quote(reqId)}, ${JSONObject.quote("Yanıt süresi 60 saniyeyi aştı.")})")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(BRIDGE_TAG, "HTML bridge inference failed", e)
                val msg = MerkopAiRepository.toUserFriendlyMessage(e)
                dispatchJs("window.onMerkopStreamError(${JSONObject.quote(reqId)}, ${JSONObject.quote(msg)})")
            }
        }
    }

    private suspend fun dispatchJs(script: String) {
        withContext(Dispatchers.Main) {
            webView.evaluateJavascript(script, null)
        }
    }

    private fun parseHistory(historyJson: String): List<ChatMessage> {
        return try {
            val arr = JSONArray(historyJson)
            (0 until arr.length()).mapNotNull { idx ->
                val obj = arr.optJSONObject(idx) ?: return@mapNotNull null
                val role = obj.optString("role", ChatMessage.ROLE_USER)
                val text = obj.optString("text", "")
                if (text.isBlank()) null else ChatMessage(role = role, text = text)
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun decodeBase64Bitmap(b64: String): Bitmap? {
        if (b64.isBlank()) return null
        return try {
            val bytes = Base64.decode(b64, Base64.DEFAULT)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (_: Exception) {
            null
        }
    }
}
