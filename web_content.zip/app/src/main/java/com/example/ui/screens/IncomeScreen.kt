package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.entity.TransactionEntity
import com.example.data.entity.TransactionTypes
import com.example.ui.components.ConfirmDialog
import com.example.ui.components.DatePickerHelper
import com.example.ui.components.Elevated3DCard
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.IncomeGreenLight
import com.example.ui.theme.IslamicEmerald
import com.example.ui.theme.IslamicGold
import com.example.ui.theme.IslamicGreenDark
import com.example.ui.theme.IslamicGreenPrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.util.BanglaHelper
import com.example.ui.viewmodel.FinanceViewModel

@Composable
fun IncomeScreen(
    viewModel: FinanceViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val transactions by viewModel.allTransactions.collectAsStateWithLifecycle()

    val incomeTransactions = remember(transactions) {
        transactions.filter {
            it.type == TransactionTypes.INCOME ||
                    it.type == TransactionTypes.POND_INCOME ||
                    it.type == TransactionTypes.MADRASAH_SALARY_INCOME ||
                    it.type == TransactionTypes.MOSQUE_SALARY_INCOME
        }
    }

    val totalIncome = remember(incomeTransactions) {
        incomeTransactions.sumOf { it.amount }
    }

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val tabs = listOf("নতুন আয় যোগ", "আয়ের তালিকা", "মাসভিত্তিক আয়")

    // Form states
    var amountInput by remember { mutableStateOf("") }
    var descriptionInput by remember { mutableStateOf("") }
    var selectedDate by remember { mutableStateOf(BanglaHelper.getTodayIso()) }
    var editingTransaction by remember { mutableStateOf<TransactionEntity?>(null) }
    var deleteCandidate by remember { mutableStateOf<TransactionEntity?>(null) }

    // Search and Filter states
    var searchQuery by remember { mutableStateOf("") }
    var filterMonth by remember { mutableStateOf("সব মাস") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .imePadding()
    ) {
        // Top Total Income Header Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Elevated3DCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = IncomeGreenLight,
                borderColor = IncomeGreen.copy(alpha = 0.3f),
                elevation = 2f
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "সর্বমোট আয়",
                            fontSize = 13.sp,
                            color = IncomeGreen,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = BanglaHelper.formatCurrency(totalIncome),
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = IncomeGreen
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(IncomeGreen),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.TrendingUp,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }

        // Sub-menu Tabs
        ScrollableTabRow(
            selectedTabIndex = selectedTabIndex,
            containerColor = Color.Transparent,
            contentColor = IslamicGreenPrimary,
            edgePadding = 16.dp,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                    color = IslamicGreenPrimary,
                    height = 3.dp
                )
            }
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTabIndex == index,
                    onClick = {
                        selectedTabIndex = index
                        if (index != 0) {
                            editingTransaction = null
                        }
                    },
                    text = {
                        Text(
                            text = title,
                            fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 14.sp
                        )
                    },
                    modifier = Modifier.testTag("income_tab_$index")
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Tab Contents
        when (selectedTabIndex) {
            0 -> {
                // নতুন আয় যোগ / সম্পাদনা Form
                IncomeAddForm(
                    selectedDate = selectedDate,
                    amountInput = amountInput,
                    descriptionInput = descriptionInput,
                    editingItem = editingTransaction,
                    onDateClick = {
                        DatePickerHelper.showDatePicker(context, selectedDate) { newDate ->
                            selectedDate = newDate
                        }
                    },
                    onAmountChange = { amountInput = it },
                    onDescriptionChange = { descriptionInput = it },
                    onSave = {
                        val parsed = BanglaHelper.parseAmount(amountInput)
                        if (parsed == null || parsed <= 0.0) {
                            Toast.makeText(context, "অনুগ্রহ করে সঠিক টাকার পরিমাণ লিখুন", Toast.LENGTH_SHORT).show()
                            return@IncomeAddForm
                        }
                        if (descriptionInput.trim().isBlank()) {
                            Toast.makeText(context, "অনুগ্রহ করে আয়ের বিবরণ লিখুন", Toast.LENGTH_SHORT).show()
                            return@IncomeAddForm
                        }

                        if (editingTransaction != null) {
                            viewModel.updateTransaction(
                                editingTransaction!!.copy(
                                    amount = parsed,
                                    date = selectedDate,
                                    description = descriptionInput.trim()
                                )
                            ) {
                                editingTransaction = null
                                amountInput = ""
                                descriptionInput = ""
                                selectedTabIndex = 1 // Switch to list
                            }
                        } else {
                            viewModel.addTransaction(
                                type = TransactionTypes.INCOME,
                                categoryLabel = "আয়",
                                amount = parsed,
                                date = selectedDate,
                                description = descriptionInput.trim()
                            ) {
                                amountInput = ""
                                descriptionInput = ""
                                selectedTabIndex = 1 // Switch to list
                            }
                        }
                    },
                    onCancelEdit = {
                        editingTransaction = null
                        amountInput = ""
                        descriptionInput = ""
                    }
                )
            }
            1 -> {
                // আয়ের তালিকা (Search, Filter, Edit, Delete)
                val filteredList = incomeTransactions.filter { item ->
                    val matchesSearch = item.description.contains(searchQuery, ignoreCase = true) ||
                            item.categoryLabel.contains(searchQuery, ignoreCase = true) ||
                            BanglaHelper.formatCurrency(item.amount).contains(searchQuery)
                    val matchesMonth = if (filterMonth == "সব মাস") true else {
                        val monthName = BanglaHelper.getMonthNameFromIso(item.date)
                        monthName == filterMonth
                    }
                    matchesSearch && matchesMonth
                }

                IncomeListView(
                    transactions = filteredList,
                    searchQuery = searchQuery,
                    filterMonth = filterMonth,
                    onSearchQueryChange = { searchQuery = it },
                    onFilterMonthChange = { filterMonth = it },
                    onEdit = { item ->
                        editingTransaction = item
                        amountInput = if (item.amount % 1.0 == 0.0) item.amount.toLong().toString() else item.amount.toString()
                        descriptionInput = item.description
                        selectedDate = item.date
                        selectedTabIndex = 0
                    },
                    onDelete = { item ->
                        deleteCandidate = item
                    }
                )
            }
            2 -> {
                // মাসভিত্তিক আয়
                MonthlyIncomeReportView(incomeTransactions)
            }
        }
    }

    // Delete Confirmation Dialog
    if (deleteCandidate != null) {
        ConfirmDialog(
            title = "আয় মুছে ফেলবেন?",
            message = "আপনি কি নিশ্চিতভাবে এই আয়ের হিসাব মুছে ফেলতে চান?\nবিবরণ: ${deleteCandidate!!.description}\nপরিমাণ: ${BanglaHelper.formatCurrency(deleteCandidate!!.amount)}",
            confirmText = "মুছে ফেলুন",
            dismissText = "বাতিল",
            isDanger = true,
            onConfirm = {
                viewModel.deleteTransaction(deleteCandidate!!.id)
                deleteCandidate = null
            },
            onDismiss = {
                deleteCandidate = null
            }
        )
    }
}

@Composable
fun IncomeAddForm(
    selectedDate: String,
    amountInput: String,
    descriptionInput: String,
    editingItem: TransactionEntity?,
    onDateClick: () -> Unit,
    onAmountChange: (String) -> Unit,
    onDescriptionChange: (String) -> Unit,
    onSave: () -> Unit,
    onCancelEdit: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Elevated3DCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("income_form_card"),
                elevation = 3f
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = if (editingItem != null) "আয় সম্পাদনা করুন" else "নতুন আয় যোগ করুন",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )

                    // Date Picker Row
                    Text(text = "তারিখ নির্বাচন", fontSize = 13.sp, color = Color(0xFF4B5563))
                    Elevated3DCard(
                        modifier = Modifier.fillMaxWidth(),
                        elevation = 1f,
                        onClick = onDateClick
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = BanglaHelper.formatBanglaDate(selectedDate),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                            Icon(
                                imageVector = Icons.Default.CalendarMonth,
                                contentDescription = "তারিখ বাছুন",
                                tint = IslamicGreenPrimary
                            )
                        }
                    }

                    // Amount Input
                    Text(text = "টাকার পরিমাণ", fontSize = 13.sp, color = Color(0xFF4B5563))
                    OutlinedTextField(
                        value = amountInput,
                        onValueChange = onAmountChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("income_amount_input"),
                        placeholder = { Text("যেমন: ৫০০০ বা 5000") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = IslamicGreenPrimary,
                            unfocusedBorderColor = BorderSubtle
                        )
                    )

                    // Description Input
                    Text(text = "আয়ের বিবরণ", fontSize = 13.sp, color = Color(0xFF4B5563))
                    OutlinedTextField(
                        value = descriptionInput,
                        onValueChange = onDescriptionChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("income_desc_input"),
                        placeholder = { Text("যেমন: ব্যবসা থেকে আয়, টিউশনি, ইত্যাদি") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = IslamicGreenPrimary,
                            unfocusedBorderColor = BorderSubtle
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (editingItem != null) {
                            Button(
                                onClick = onCancelEdit,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9E9E9E)),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("বাতিল", color = Color.White)
                            }
                        }

                        Button(
                            onClick = onSave,
                            colors = ButtonDefaults.buttonColors(containerColor = IslamicGreenPrimary),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("income_save_button")
                        ) {
                            Text(if (editingItem != null) "আপডেট করুন" else "সংরক্ষণ করুন", color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun IncomeListView(
    transactions: List<TransactionEntity>,
    searchQuery: String,
    filterMonth: String,
    onSearchQueryChange: (String) -> Unit,
    onFilterMonthChange: (String) -> Unit,
    onEdit: (TransactionEntity) -> Unit,
    onDelete: (TransactionEntity) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        // Search and Month Filter Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                modifier = Modifier
                    .weight(1f)
                    .testTag("income_search_input"),
                placeholder = { Text("খুঁজুন...", fontSize = 13.sp) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        modifier = Modifier.size(20.dp)
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotBlank()) {
                        IconButton(onClick = { onSearchQueryChange("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear", modifier = Modifier.size(18.dp))
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = IslamicGreenPrimary,
                    unfocusedBorderColor = BorderSubtle
                )
            )
        }

        // Horizontal Month Selector
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(top = 10.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "মোট ফলাফল: ${BanglaHelper.toBanglaDigits(transactions.size)} টি",
                        fontSize = 12.sp,
                        color = Color(0xFF6B7280)
                    )
                }
            }

            if (transactions.isEmpty()) {
                item {
                    Elevated3DCard(modifier = Modifier.fillMaxWidth()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "কোনো আয়ের হিসাব পাওয়া যায়নি", color = Color(0xFF6B7280), fontSize = 14.sp)
                        }
                    }
                }
            } else {
                items(transactions, key = { it.id }) { item ->
                    Elevated3DCard(
                        modifier = Modifier.fillMaxWidth(),
                        elevation = 2f
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.description.ifBlank { item.categoryLabel },
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "${BanglaHelper.formatBanglaDate(item.date)} • ${item.categoryLabel}",
                                    fontSize = 12.sp,
                                    color = Color(0xFF6B7280)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "+ " + BanglaHelper.formatCurrency(item.amount),
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = IncomeGreen
                                )
                            }

                            Row {
                                IconButton(
                                    onClick = { onEdit(item) },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "সম্পাদনা",
                                        tint = IslamicGreenPrimary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                IconButton(
                                    onClick = { onDelete(item) },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "মুছে ফেলুন",
                                        tint = ExpenseRed,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MonthlyIncomeReportView(transactions: List<TransactionEntity>) {
    // Group by month prefix "yyyy-MM"
    val monthlyGroups = remember(transactions) {
        transactions.groupBy {
            if (it.date.length >= 7) it.date.substring(0, 7) else "অন্যান্য"
        }.toList().sortedByDescending { it.first }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (monthlyGroups.isEmpty()) {
            item {
                Elevated3DCard(modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("এখনো কোনো মাসভিত্তিক আয়ের তথ্য নেই", color = Color(0xFF6B7280))
                    }
                }
            }
        } else {
            items(monthlyGroups) { (monthKey, items) ->
                val monthTotal = items.sumOf { it.amount }
                val monthName = BanglaHelper.getMonthNameFromIso("$monthKey-01")
                val year = if (monthKey.length >= 4) monthKey.substring(0, 4) else ""

                Elevated3DCard(
                    modifier = Modifier.fillMaxWidth(),
                    elevation = 3f
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "$monthName ${BanglaHelper.toBanglaDigits(year)}",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = BanglaHelper.formatCurrency(monthTotal),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = IncomeGreen
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "মোট লেনদেন: ${BanglaHelper.toBanglaDigits(items.size)} টি",
                            fontSize = 12.sp,
                            color = Color(0xFF6B7280)
                        )
                    }
                }
            }
        }
    }
}
