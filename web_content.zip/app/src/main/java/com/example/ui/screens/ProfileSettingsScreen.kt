package com.example.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Cake
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AppLanguage
import com.example.data.model.GenderOption
import com.example.data.model.HavenAward
import com.example.data.model.SexualityOption
import com.example.data.model.UserProfile
import com.example.ui.components.AwardsShowcaseCard
import com.example.ui.components.ProfileAvatarImage
import com.example.ui.components.detectFriendlyLocation
import com.example.ui.components.savePickedPhotoToInternalStorage

private val PROFILE_GRADES = listOf(
    "Grade 6", "Grade 7", "Grade 8", "Grade 9",
    "Grade 10", "Grade 11", "Grade 12", "College / Uni"
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileSettingsScreen(
    profile: UserProfile,
    awards: List<HavenAward>,
    biometricAvailable: Boolean,
    onSaveProfile: (UserProfile) -> Unit,
    onSetLanguage: (AppLanguage) -> Unit,
    onToggleDataFree: (Boolean) -> Unit,
    onToggleBiometric: (Boolean) -> Unit,
    onBackupToEmail: () -> Unit,
    onLockNow: () -> Unit,
    onLogout: () -> Unit
) {
    val context = LocalContext.current

    var name by remember(profile.name) { mutableStateOf(profile.name) }
    var email by remember(profile.backupEmail) { mutableStateOf(profile.backupEmail) }
    var idNumber by remember(profile.idNumber) { mutableStateOf(profile.idNumber) }
    var birthday by remember(profile.birthday) { mutableStateOf(profile.birthday) }
    var isStudent by remember(profile.isStudent) { mutableStateOf(profile.isStudent) }
    var gradeLevel by remember(profile.gradeLevel) { mutableStateOf(profile.gradeLevel.ifBlank { "Grade 10" }) }
    var locationText by remember(profile.locationText) { mutableStateOf(profile.locationText) }
    var photoPath by remember(profile.profilePhotoPath) { mutableStateOf(profile.profilePhotoPath) }
    var emergencyNum by remember(profile.emergencyAuthorityNumber) { mutableStateOf(profile.emergencyAuthorityNumber) }
    var bloodType by remember(profile.bloodType) { mutableStateOf(profile.bloodType) }
    var allergies by remember(profile.allergies) { mutableStateOf(profile.allergies) }
    var medicalNotes by remember(profile.medicalNotes) { mutableStateOf(profile.medicalNotes) }
    var gender by remember(profile.gender) { mutableStateOf(profile.gender) }
    var sexuality by remember(profile.sexuality) { mutableStateOf(profile.sexuality) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val saved = savePickedPhotoToInternalStorage(context, uri)
            if (saved != null) {
                photoPath = saved
                onSaveProfile(profile.copy(profilePhotoPath = saved))
            }
        }
    }

    val locationPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val granted = results[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            results[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            locationText = detectFriendlyLocation(context)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    ProfileAvatarImage(
                        photoPath = photoPath,
                        displayName = profile.name.ifBlank { "Friend" },
                        size = 64.dp
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${profile.name.ifBlank { "Teen User" }} • Age ${profile.age}",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        val verifiedBadge = if (profile.humanVerified && profile.emailOtpVerified) "Human & Email OTP Verified ✓" else "Verified Teen Profile"
                        Text(text = verifiedBadge, style = MaterialTheme.typography.bodySmall)
                        if (profile.isStudent) {
                            Text(text = "Student • $gradeLevel", style = MaterialTheme.typography.bodySmall)
                        }
                        if (locationText.isNotBlank()) {
                            Text(text = "📍 $locationText", style = MaterialTheme.typography.bodySmall)
                        }
                        Spacer(modifier = Modifier.padding(top = 4.dp))
                        OutlinedButton(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            modifier = Modifier.testTag("profile_change_photo_button")
                        ) {
                            Icon(Icons.Filled.CameraAlt, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (photoPath.isBlank()) "Add Picture" else "Change Picture")
                        }
                    }
                }
            }
        }

        // Awards Trophy Case
        item {
            AwardsShowcaseCard(awards = awards)
        }

        // Zero Ads / Zero Third-Party Pledge
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Shield, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        "Zero Ads & Zero Third-Party SDKs: Your diary, cycle, ID, photo, location, and awards stay privately on your device.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        // Global Language
        item {
            Card {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Public, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("South African & Global Languages", style = MaterialTheme.typography.titleMedium)
                    }
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        AppLanguage.entries.forEach { lang ->
                            FilterChip(
                                selected = profile.language == lang,
                                onClick = { onSetLanguage(lang) },
                                label = { Text(lang.nativeName) }
                            )
                        }
                    }
                }
            }
        }

        // Data-Free & Biometrics
        item {
            Card {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.CloudOff, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("Data-Free Offline Experience", style = MaterialTheme.typography.titleSmall)
                                Text("Zero mobile data usage mode", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        Switch(checked = profile.isDataFreeMode, onCheckedChange = onToggleDataFree)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Fingerprint, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("Biometric Privacy Lock", style = MaterialTheme.typography.titleSmall)
                                Text(
                                    if (biometricAvailable) "Require fingerprint, face, or device PIN" else "Set a screen lock in device Settings first",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                        Switch(
                            checked = profile.biometricLockEnabled,
                            onCheckedChange = onToggleBiometric,
                            enabled = biometricAvailable || profile.biometricLockEnabled
                        )
                    }

                    if (profile.biometricLockEnabled) {
                        OutlinedButton(onClick = onLockNow, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Filled.Lock, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Lock Haven Now")
                        }
                    }
                }
            }
        }

        // Email Backup
        item {
            Card {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Backup on Email", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Account & Backup Email") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            onSaveProfile(profile.copy(backupEmail = email.trim()))
                            onBackupToEmail()
                        },
                        modifier = Modifier.fillMaxWidth().testTag("profile_backup_email_button")
                    ) {
                        Icon(Icons.Filled.Backup, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Send Full Backup to Email")
                    }
                }
            }
        }

        // Identity, ID (even underage), Birthday, Student Grade, Location & Medical Details Editor
        item {
            Card {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Identity, Student, Location & Medical Info", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())

                    OutlinedTextField(
                        value = idNumber,
                        onValueChange = { idNumber = it },
                        label = { Text("ID Number (underage / school ID welcome)") },
                        leadingIcon = { Icon(Icons.Filled.Badge, contentDescription = null) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = birthday,
                        onValueChange = { birthday = it },
                        label = { Text("Birthday (YYYY-MM-DD)") },
                        leadingIcon = { Icon(Icons.Filled.Cake, contentDescription = null) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.School, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Student Status", style = MaterialTheme.typography.titleSmall)
                        }
                        Switch(checked = isStudent, onCheckedChange = { isStudent = it })
                    }

                    if (isStudent) {
                        Text("Grade / Level", style = MaterialTheme.typography.labelLarge)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            PROFILE_GRADES.forEach { g ->
                                FilterChip(selected = gradeLevel == g, onClick = { gradeLevel = g }, label = { Text(g) })
                            }
                        }
                    }

                    OutlinedTextField(
                        value = locationText,
                        onValueChange = { locationText = it },
                        label = { Text("Location (City / Town / Province)") },
                        leadingIcon = { Icon(Icons.Filled.LocationOn, contentDescription = null) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedButton(
                        onClick = {
                            locationPermLauncher.launch(
                                arrayOf(
                                    Manifest.permission.ACCESS_COARSE_LOCATION,
                                    Manifest.permission.ACCESS_FINE_LOCATION
                                )
                            )
                        }
                    ) {
                        Icon(Icons.Filled.MyLocation, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Detect Current Location")
                    }

                    Text("Gender", style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GenderOption.entries.forEach { g ->
                            FilterChip(selected = gender == g, onClick = { gender = g }, label = { Text(g.label) })
                        }
                    }

                    Text("Sexuality", style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        SexualityOption.entries.forEach { s ->
                            FilterChip(selected = sexuality == s, onClick = { sexuality = s }, label = { Text(s.label) })
                        }
                    }

                    OutlinedTextField(value = emergencyNum, onValueChange = { emergencyNum = it }, label = { Text("Local Authority Number") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = bloodType, onValueChange = { bloodType = it }, label = { Text("Blood Type") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = allergies, onValueChange = { allergies = it }, label = { Text("Allergies") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = medicalNotes, onValueChange = { medicalNotes = it }, label = { Text("Medical Notes") }, modifier = Modifier.fillMaxWidth())

                    Button(
                        onClick = {
                            onSaveProfile(
                                profile.copy(
                                    name = name.trim().ifBlank { "Friend" },
                                    backupEmail = email.trim(),
                                    idNumber = idNumber.trim(),
                                    birthday = birthday.trim(),
                                    isStudent = isStudent,
                                    gradeLevel = if (isStudent) gradeLevel else "Not in school",
                                    locationText = locationText.trim(),
                                    profilePhotoPath = photoPath,
                                    gender = gender,
                                    sexuality = sexuality,
                                    emergencyAuthorityNumber = emergencyNum.trim().ifBlank { "112" },
                                    bloodType = bloodType.trim(),
                                    allergies = allergies.trim(),
                                    medicalNotes = medicalNotes.trim()
                                )
                            )
                        },
                        modifier = Modifier.fillMaxWidth().testTag("save_profile_settings_button")
                    ) {
                        Text("Save Profile Changes")
                    }

                    OutlinedButton(
                        onClick = onLogout,
                        modifier = Modifier.fillMaxWidth().testTag("logout_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Log Out (Switch / Verify Email)")
                    }
                }
            }
        }
    }
}
