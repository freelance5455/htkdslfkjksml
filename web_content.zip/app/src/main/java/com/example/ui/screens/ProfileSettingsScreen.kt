package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AppLanguage
import com.example.data.model.GenderOption
import com.example.data.model.SexualityOption
import com.example.data.model.UserProfile

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileSettingsScreen(
    profile: UserProfile,
    biometricAvailable: Boolean,
    onSaveProfile: (UserProfile) -> Unit,
    onSetLanguage: (AppLanguage) -> Unit,
    onToggleDataFree: (Boolean) -> Unit,
    onToggleBiometric: (Boolean) -> Unit,
    onBackupToEmail: () -> Unit,
    onLockNow: () -> Unit
) {
    var name by remember(profile.name) { mutableStateOf(profile.name) }
    var email by remember(profile.backupEmail) { mutableStateOf(profile.backupEmail) }
    var emergencyNum by remember(profile.emergencyAuthorityNumber) { mutableStateOf(profile.emergencyAuthorityNumber) }
    var bloodType by remember(profile.bloodType) { mutableStateOf(profile.bloodType) }
    var allergies by remember(profile.allergies) { mutableStateOf(profile.allergies) }
    var medicalNotes by remember(profile.medicalNotes) { mutableStateOf(profile.medicalNotes) }
    var gender by remember(profile.gender) { mutableStateOf(profile.gender) }
    var sexuality by remember(profile.sexuality) { mutableStateOf(profile.sexuality) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.VerifiedUser, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "${profile.name.ifBlank { "Teen User" }} • Age ${profile.age} Verified",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${profile.gender.label} • ${profile.sexuality.label}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }

        // Zero Ads / Zero Third-Party Pledge
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Shield, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        "Zero Ads & Zero Third-Party SDKs: Your diary, cycle, vitality, and identity data remain strictly on your device unless you send an email backup.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        // Global Language
        item {
            Card {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Public, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Global Languages", style = MaterialTheme.typography.titleMedium)
                    }
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        AppLanguage.entries.forEach { lang ->
                            FilterChip(
                                selected = profile.language == lang,
                                onClick = { onSetLanguage(lang) },
                                label = { Text(lang.nativeName) }
                            )
                        }
                    }
                }
            }
        }

        // Data-Free & Biometrics
        item {
            Card {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.CloudOff, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("Data-Free Offline Experience", style = MaterialTheme.typography.titleSmall)
                                Text("Zero mobile data usage mode", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        Switch(checked = profile.isDataFreeMode, onCheckedChange = onToggleDataFree)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Fingerprint, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("Biometric Privacy Lock", style = MaterialTheme.typography.titleSmall)
                                Text(
                                    if (biometricAvailable) "Require fingerprint, face, or device PIN" else "Set a screen lock in device Settings first",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                        Switch(
                            checked = profile.biometricLockEnabled,
                            onCheckedChange = onToggleBiometric,
                            enabled = biometricAvailable || profile.biometricLockEnabled
                        )
                    }

                    if (profile.biometricLockEnabled) {
                        OutlinedButton(onClick = onLockNow, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Filled.Lock, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Lock Haven Now")
                        }
                    }
                }
            }
        }

        // Email Backup
        item {
            Card {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Backup on Email", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Backup Email Address") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            onSaveProfile(profile.copy(backupEmail = email.trim()))
                            onBackupToEmail()
                        },
                        modifier = Modifier.fillMaxWidth().testTag("profile_backup_email_button")
                    ) {
                        Icon(Icons.Filled.Backup, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Send Full Backup to Email")
                    }
                }
            }
        }

        // Identity & Medical Details Editor
        item {
            Card {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Identity & Emergency Medical Info", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())

                    Text("Gender", style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GenderOption.entries.forEach { g ->
                            FilterChip(selected = gender == g, onClick = { gender = g }, label = { Text(g.label) })
                        }
                    }

                    Text("Sexuality", style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        SexualityOption.entries.forEach { s ->
                            FilterChip(selected = sexuality == s, onClick = { sexuality = s }, label = { Text(s.label) })
                        }
                    }

                    OutlinedTextField(value = emergencyNum, onValueChange = { emergencyNum = it }, label = { Text("Local Authority Number") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = bloodType, onValueChange = { bloodType = it }, label = { Text("Blood Type") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = allergies, onValueChange = { allergies = it }, label = { Text("Allergies") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = medicalNotes, onValueChange = { medicalNotes = it }, label = { Text("Medical Notes") }, modifier = Modifier.fillMaxWidth())

                    Button(
                        onClick = {
                            onSaveProfile(
                                profile.copy(
                                    name = name.trim().ifBlank { "Friend" },
                                    backupEmail = email.trim(),
                                    gender = gender,
                                    sexuality = sexuality,
                                    emergencyAuthorityNumber = emergencyNum.trim().ifBlank { "112" },
                                    bloodType = bloodType.trim(),
                                    allergies = allergies.trim(),
                                    medicalNotes = medicalNotes.trim()
                                )
                            )
                        },
                        modifier = Modifier.fillMaxWidth().testTag("save_profile_settings_button")
                    ) {
                        Text("Save Profile Changes")
                    }
                }
            }
        }
    }
}
