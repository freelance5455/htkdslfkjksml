package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.QuizItem
import com.example.ui.theme.GameAmber
import com.example.ui.theme.GameAmberBright
import com.example.ui.theme.GameDarkBackground
import com.example.ui.theme.GameEmerald
import com.example.ui.theme.GameOrange
import com.example.ui.theme.GameRose
import com.example.ui.theme.GameSurfaceDark
import com.example.ui.theme.GameSurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

data class VictorySummary(
    val basePoints: Int,
    val streakBonus: Int,
    val difficultyLabel: String = "Normal",
    val difficultyMultiplier: Float = 1.0f,
    val difficultyBonus: Int = 0,
    val dailyStreakMultiplier: Float = 1.0f,
    val dailyStreakBonus: Int = 0,
    val dailyStreakLabel: String = "1.0x",
    val dailyStreakDays: Int = 0,
    val totalEarned: Int,
    val coinsEarned: Int,
    val stars: Int,
    val newlyUnlockedLevel: Int? = null
)

@Composable
fun VictoryDialog(
    item: QuizItem,
    summary: VictorySummary,
    onNextImage: () -> Unit,
    onGoToLevels: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .clip(RoundedCornerShape(28.dp))
                .border(2.dp, GameEmerald.copy(alpha = 0.7f), RoundedCornerShape(28.dp))
                .testTag("victory_dialog"),
            color = GameSurfaceDark,
            shadowElevation = 16.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Stars Row
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    for (i in 1..3) {
                        val isFilled = i <= summary.stars
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = if (isFilled) GameAmberBright else Color(0xFF334155),
                            modifier = Modifier.size(if (i == 2) 38.dp else 30.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = GameEmerald.copy(alpha = 0.2f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GameEmerald.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = "CORRECT GUESS!",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = GameEmerald,
                        letterSpacing = 2.sp,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = item.name,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )

                Text(
                    text = item.description,
                    fontSize = 11.sp,
                    color = TextSecondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Score Breakdown Card
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    color = Color(0xFF090E1A),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B))
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Zoom Score Base", fontSize = 12.sp, color = TextSecondary)
                            Text("+${summary.basePoints} pts", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }

                        if (summary.difficultyBonus > 0) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("⚡", fontSize = 12.sp)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Level Difficulty (${summary.difficultyLabel} • ${summary.difficultyMultiplier}x)", fontSize = 11.sp, color = Color(0xFF67E8F9), fontWeight = FontWeight.SemiBold)
                                }
                                Text("+${summary.difficultyBonus} pts", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF67E8F9))
                            }
                        }

                        if (summary.streakBonus > 0) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.LocalFireDepartment,
                                        contentDescription = null,
                                        tint = GameOrange,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Winning Streak Boost", fontSize = 12.sp, color = GameOrange, fontWeight = FontWeight.SemiBold)
                                }
                                Text("+${summary.streakBonus} pts", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GameOrange)
                            }
                        }

                        if (summary.dailyStreakBonus > 0) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Celebration,
                                        contentDescription = null,
                                        tint = GameAmberBright,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Daily Multiplier (${summary.dailyStreakDays}d • ${summary.dailyStreakLabel})", fontSize = 11.sp, color = GameAmberBright, fontWeight = FontWeight.SemiBold)
                                }
                                Text("+${summary.dailyStreakBonus} pts", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GameAmberBright)
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Coins Reward", fontSize = 12.sp, color = TextSecondary)
                            Text("+${summary.coinsEarned} 🪙", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GameAmberBright)
                        }

                        HorizontalDivider(color = Color(0xFF1E293B), thickness = 1.dp, modifier = Modifier.padding(vertical = 4.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Total Score Earned", fontSize = 13.sp, fontWeight = FontWeight.Black, color = Color.White)
                            Text(
                                text = "+${summary.totalEarned}",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                color = GameAmberBright
                            )
                        }
                    }
                }

                // Level Unlocked Notice
                summary.newlyUnlockedLevel?.let { lvl ->
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        color = Color(0xFF28133C),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFA855F7))
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("🎉", fontSize = 20.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "LEVEL $lvl UNLOCKED!",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFFE9D5FF)
                                )
                                Text(
                                    text = "New challenges are now accessible in Levels map.",
                                    fontSize = 10.sp,
                                    color = Color(0xFFD8B4FE)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Navigation Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onGoToLevels,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("victory_levels_button"),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("Levels", fontSize = 13.sp, color = TextSecondary, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = onNextImage,
                        modifier = Modifier
                            .weight(1.4f)
                            .height(48.dp)
                            .testTag("victory_next_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GameAmber,
                            contentColor = Color(0xFF0F172A)
                        )
                    ) {
                        Text("Next Image", fontSize = 13.sp, fontWeight = FontWeight.Black)
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}
