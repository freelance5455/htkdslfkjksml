package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.MetallicKnobBg
import com.example.ui.theme.MetallicKnobBorder
import com.example.ui.theme.MetallicSilver
import com.example.ui.theme.StudioBlack
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Authentic hardware studio rotary knob with brushed metallic surface,
 * glowing emerald LED travel arc, tactile drag interaction, and reset support.
 */
@Composable
fun MetallicKnob(
    label: String,
    value: Float, // Normalized 0.0 .. 1.0
    valueDisplay: String,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 82.dp,
    accentColor: Color = EmeraldPrimary,
    defaultValue: Float = 0.5f,
    tag: String = "metallic_knob"
) {
    var dragAccumulator by remember { mutableFloatStateOf(0f) }

    // Start angle at 135 deg (bottom-left) to 405 deg (bottom-right) -> 270 deg total sweep
    val startAngle = 135f
    val sweepAngle = 270f
    val currentAngle = startAngle + (value * sweepAngle)

    val animatedAngle by animateFloatAsState(
        targetValue = currentAngle,
        animationSpec = tween(durationMillis = 60),
        label = "knob_angle"
    )

    Column(
        modifier = modifier.testTag(tag),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // Parameter Title
        Text(
            text = label.uppercase(),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            color = TextSecondary
        )

        // Rotary Control Canvas
        Box(
            modifier = Modifier
                .size(size)
                .pointerInput(Unit) {
                    detectTapGestures(
                        onDoubleTap = {
                            onValueChange(defaultValue)
                        }
                    )
                }
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { dragAccumulator = 0f },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            // Drag up to increase, drag down to decrease (DAW standard)
                            val delta = -dragAmount.y / 280f
                            val newValue = (value + delta).coerceIn(0f, 1f)
                            onValueChange(newValue)
                        }
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(size)) {
                val center = Offset(this.size.width / 2f, this.size.height / 2f)
                val radius = (this.size.minDimension / 2f) - 6.dp.toPx()

                // 1. Inactive Background Arc (Dark Track)
                drawArc(
                    color = MetallicKnobBorder,
                    startAngle = startAngle,
                    sweepAngle = sweepAngle,
                    useCenter = false,
                    topLeft = Offset(center.x - radius, center.y - radius),
                    size = Size(radius * 2, radius * 2),
                    style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                )

                // 2. Active Glowing Value Arc
                if (value > 0.01f) {
                    drawArc(
                        brush = Brush.sweepGradient(
                            listOf(EmeraldDark, accentColor, EmeraldLight),
                            center = center
                        ),
                        startAngle = startAngle,
                        sweepAngle = (value * sweepAngle),
                        useCenter = false,
                        topLeft = Offset(center.x - radius, center.y - radius),
                        size = Size(radius * 2, radius * 2),
                        style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                    )
                }

                // 3. Metallic Outer Bezel
                val knobRadius = radius - 8.dp.toPx()
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            MetallicSilver.copy(alpha = 0.35f),
                            MetallicKnobBorder,
                            StudioBlack
                        ),
                        center = Offset(center.x - (knobRadius * 0.3f), center.y - (knobRadius * 0.3f)),
                        radius = knobRadius * 1.2f
                    ),
                    radius = knobRadius,
                    center = center
                )

                // 4. Brushed Metallic Inner Dial Face
                val innerFaceRadius = knobRadius - 3.dp.toPx()
                drawCircle(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            MetallicKnobBg,
                            Color(0xFF26332C),
                            MetallicKnobBg
                        ),
                        start = Offset(center.x - innerFaceRadius, center.y - innerFaceRadius),
                        end = Offset(center.x + innerFaceRadius, center.y + innerFaceRadius)
                    ),
                    radius = innerFaceRadius,
                    center = center
                )

                // Dial center cap ring
                drawCircle(
                    color = MetallicGold.copy(alpha = 0.5f),
                    radius = innerFaceRadius * 0.45f,
                    center = center,
                    style = Stroke(width = 1.dp.toPx())
                )

                // 5. Dial Indicator Marker (Radial Line / Notch)
                val angleRad = (animatedAngle * PI / 180f).toFloat()
                val markerInnerRadius = innerFaceRadius * 0.35f
                val markerOuterRadius = innerFaceRadius * 0.85f

                val startMarker = Offset(
                    x = center.x + markerInnerRadius * cos(angleRad),
                    y = center.y + markerInnerRadius * sin(angleRad)
                )
                val endMarker = Offset(
                    x = center.x + markerOuterRadius * cos(angleRad),
                    y = center.y + markerOuterRadius * sin(angleRad)
                )

                // Indicator line
                drawLine(
                    color = accentColor,
                    start = startMarker,
                    end = endMarker,
                    strokeWidth = 3.dp.toPx(),
                    cap = StrokeCap.Round
                )

                // Glowing tip indicator
                drawCircle(
                    color = accentColor,
                    radius = 2.5.dp.toPx(),
                    center = endMarker
                )
            }
        }

        // Formatted Value Display Badge
        Text(
            text = valueDisplay,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold,
            color = if (value > 0f) TextPrimary else TextMuted
        )
    }
}
private val EmeraldDark = Color(0xFF00875A)
