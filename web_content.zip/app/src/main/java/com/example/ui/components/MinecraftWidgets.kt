package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.ServerState
import com.example.ui.theme.MinecraftBackground
import com.example.ui.theme.MinecraftBorder
import com.example.ui.theme.MinecraftDiamond
import com.example.ui.theme.MinecraftDirt
import com.example.ui.theme.MinecraftEmerald
import com.example.ui.theme.MinecraftGold
import com.example.ui.theme.MinecraftGrass
import com.example.ui.theme.MinecraftRedstone
import com.example.ui.theme.MinecraftSurface
import com.example.ui.theme.MinecraftText
import com.example.ui.theme.MinecraftTextDim

@Composable
fun MinecraftBannerHeader(modifier: Modifier = Modifier) {
  val infiniteTransition = rememberInfiniteTransition(label = "torch")
  val torchGlow by infiniteTransition.animateFloat(
    initialValue = 0.85f,
    targetValue = 1.15f,
    animationSpec = infiniteRepeatable(
      animation = tween(1200, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "torchGlow"
  )

  Box(
    modifier = modifier
      .fillMaxWidth()
      .height(130.dp)
      .background(MinecraftDirt)
      .border(BorderStroke(3.dp, Color(0xFF1E140D)))
  ) {
    // Banner oficial de Chaufaland
    Image(
      painter = painterResource(id = R.drawable.chaufaland_banner_1791819044704),
      contentDescription = "CHAUFALAND Official Banner",
      contentScale = ContentScale.Crop,
      modifier = Modifier.fillMaxSize()
    )

    // Overlay sutil para legibilidad y antorchas
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(Color(0x33000000))
        .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
      Row(
        modifier = Modifier
          .align(Alignment.BottomCenter)
          .background(Color(0xAA1A120B), RoundedCornerShape(4.dp))
          .padding(horizontal = 10.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "🔥",
          fontSize = 14.sp,
          modifier = Modifier.scale(torchGlow)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = "MINECRAFT VOX & BEDROCK BRIDGE",
          color = MinecraftGold,
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          letterSpacing = 1.sp,
          fontFamily = FontFamily.Monospace
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = "🔥",
          fontSize = 14.sp,
          modifier = Modifier.scale(torchGlow)
        )
      }
    }
  }
}

@Composable
fun MinecraftCard(
  modifier: Modifier = Modifier,
  borderColor: Color = MinecraftBorder,
  content: @Composable BoxScope.() -> Unit
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .shadow(4.dp, RoundedCornerShape(4.dp))
      .border(BorderStroke(2.dp, borderColor), RoundedCornerShape(4.dp)),
    colors = CardDefaults.cardColors(containerColor = MinecraftSurface),
    shape = RoundedCornerShape(4.dp)
  ) {
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      content = content
    )
  }
}

@Composable
fun MinecraftButton(
  text: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  enabled: Boolean = true,
  containerColor: Color = MinecraftGrass,
  contentColor: Color = Color.White,
  testTag: String? = null
) {
  Button(
    onClick = onClick,
    enabled = enabled,
    shape = RoundedCornerShape(2.dp),
    colors = ButtonDefaults.buttonColors(
      containerColor = containerColor,
      contentColor = contentColor,
      disabledContainerColor = Color(0xFF3B332B),
      disabledContentColor = Color(0xFF6B5F52)
    ),
    border = BorderStroke(2.dp, Color(0xFF140F0B)),
    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
    modifier = modifier
      .then(if (testTag != null) Modifier.testTag(testTag) else Modifier)
  ) {
    Text(
      text = text,
      fontWeight = FontWeight.Bold,
      fontFamily = FontFamily.Monospace,
      fontSize = 13.sp
    )
  }
}

@Composable
fun PlayerAvatar(
  gamerTag: String,
  size: Dp = 40.dp,
  modifier: Modifier = Modifier
) {
  val avatarUrl = "https://mc-heads.net/avatar/${gamerTag.trim()}/64"

  Box(
    modifier = modifier
      .size(size)
      .background(Color(0xFF33271E), RoundedCornerShape(4.dp))
      .border(BorderStroke(1.5.dp, Color(0xFF16100B)), RoundedCornerShape(4.dp))
      .clip(RoundedCornerShape(4.dp)),
    contentAlignment = Alignment.Center
  ) {
    AsyncImage(
      model = avatarUrl,
      contentDescription = "Avatar de $gamerTag",
      modifier = Modifier.fillMaxSize(),
      contentScale = ContentScale.Crop
    )
  }
}

@Composable
fun ServerStateBadge(state: ServerState, modifier: Modifier = Modifier) {
  val (bgColor, txtColor) = when (state) {
    ServerState.ONLINE -> MinecraftEmerald to Color.White
    ServerState.OFFLINE -> MinecraftRedstone to Color.White
    ServerState.STARTING, ServerState.RESTARTING -> MinecraftGold to Color.Black
    ServerState.STOPPING -> MinecraftRedstone to Color.White
    ServerState.UNKNOWN -> Color.Gray to Color.White
  }

  Box(
    modifier = modifier
      .background(bgColor, RoundedCornerShape(2.dp))
      .border(BorderStroke(1.dp, Color(0xFF100C09)), RoundedCornerShape(2.dp))
      .padding(horizontal = 8.dp, vertical = 3.dp)
  ) {
    Text(
      text = state.displayName.uppercase(),
      color = txtColor,
      fontSize = 11.sp,
      fontWeight = FontWeight.ExtraBold,
      fontFamily = FontFamily.Monospace
    )
  }
}

@Composable
fun DimensionBadge(dimension: String, modifier: Modifier = Modifier) {
  val (color, label) = when (dimension.lowercase()) {
    "nether" -> MinecraftRedstone to "NETHER"
    "the_end", "end" -> Color(0xFF9B59B6) to "THE END"
    else -> MinecraftGrass to "OVERWORLD"
  }

  Box(
    modifier = modifier
      .background(color, RoundedCornerShape(2.dp))
      .border(BorderStroke(1.dp, Color(0xFF140F0B)), RoundedCornerShape(2.dp))
      .padding(horizontal = 6.dp, vertical = 2.dp)
  ) {
    Text(
      text = label,
      color = Color.White,
      fontSize = 10.sp,
      fontWeight = FontWeight.Bold,
      fontFamily = FontFamily.Monospace
    )
  }
}
