package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FolderCopy
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.RestoreSummary
import com.example.data.storage.LocalBackupFile
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.SdTopAppBar
import com.example.ui.components.SectionHeaderCard
import com.example.ui.theme.BackgroundWhite
import com.example.ui.theme.BorderLight
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.GoldSecondary
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.StatusCancelledFg
import com.example.ui.theme.StatusConfirmedFg
import com.example.ui.theme.SurfaceLightGray
import com.example.ui.theme.TextSecondary
import com.example.utils.DateFormatters
import java.io.File

@Composable
fun BackupScreen(
    lastBackupTimestamp: Long?,
    lastBackupName: String?,
    localBackups: List<LocalBackupFile>,
    isBusy: Boolean,
    restoreSummary: RestoreSummary?,
    onDismissRestoreSummary: () -> Unit,
    onCreateBackup: () -> Unit,
    onSaveBackupToPhoneUri: (File, android.net.Uri) -> Unit,
    onShareBackup: (File) -> Unit,
    onRestoreFromUri: (android.net.Uri) -> Unit,
    onRestoreFromFile: (File) -> Unit,
    onDeleteBackup: (File) -> Unit,
    onBack: () -> Unit,
) {
    var pendingSaveFile by remember { mutableStateOf<File?>(null) }

    val saveDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        val file = pendingSaveFile
        if (uri != null && file != null) {
            onSaveBackupToPhoneUri(file, uri)
        }
        pendingSaveFile = null
    }

    val openDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            onRestoreFromUri(uri)
        }
    }

    Scaffold(
        containerColor = SurfaceLightGray,
        topBar = {
            SdTopAppBar(
                title = "النسخ الاحتياطي والاستعادة",
                subtitle = "نسخ محلي كامل للبيانات والصور بدون إنترنت",
                onBack = onBack,
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (isBusy) {
                item {
                    LinearProgressIndicator(
                        color = GoldSecondary,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }

            // Status Card: Last Backup Date
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = NavyPrimary),
                    shape = RoundedCornerShape(18.dp),
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.History, contentDescription = null, tint = GoldSecondary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "تاريخ آخر نسخة احتياطية",
                                style = MaterialTheme.typography.titleMedium,
                                color = BackgroundWhite,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                        Text(
                            text = lastBackupTimestamp?.let {
                                DateFormatters.formatTimestampArabic(it)
                            } ?: "لم يتم إنشاء نسخة احتياطية بعد",
                            style = MaterialTheme.typography.titleLarge,
                            color = GoldSecondary,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.testTag("last_backup_date_text"),
                        )
                        if (!lastBackupName.isNullOrBlank()) {
                            Text(
                                text = "الملف: $lastBackupName",
                                style = MaterialTheme.typography.bodySmall,
                                color = BackgroundWhite.copy(alpha = 0.8f),
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = BackgroundWhite.copy(alpha = 0.1f),
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(Icons.Default.CloudOff, contentDescription = null, tint = GoldSecondary, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "تشمل النسخة جميع العملاء، الحجوزات، المدفوعات، وكل الصور المرفقة",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = BackgroundWhite,
                                )
                            }
                        }
                    }
                }
            }

            // Primary Actions: Create & Restore
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        enabled = !isBusy,
                        onClick = onCreateBackup,
                        colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .testTag("create_backup_button"),
                    ) {
                        Icon(Icons.Default.Backup, contentDescription = null, tint = GoldSecondary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "إنشاء نسخة احتياطية شاملة الآن",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                        )
                    }

                    OutlinedButton(
                        enabled = !isBusy,
                        onClick = {
                            openDocumentLauncher.launch(arrayOf("application/zip", "application/octet-stream", "*/*"))
                        },
                        border = BorderStroke(1.5.dp, NavyPrimary),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("restore_backup_picker_button"),
                    ) {
                        Icon(Icons.Default.Restore, contentDescription = null, tint = NavyPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "استعادة نسخة احتياطية من ملف بالهاتف",
                            style = MaterialTheme.typography.titleMedium,
                            color = NavyPrimary,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }
            }

            item {
                SectionHeaderCard(
                    title = "النسخ الاحتياطية المحفوظة (${localBackups.size})",
                    icon = Icons.Default.FolderCopy,
                )
            }

            if (localBackups.isEmpty()) {
                item {
                    EmptyStateCard(
                        icon = Icons.Default.Backup,
                        title = "لا توجد نسخ احتياطية محلية بعد",
                        subtitle = "اضغط على زر \"إنشاء نسخة احتياطية شاملة\" لحفظ نسخة كاملة يمكنك نقلها لأي هاتف جديد.",
                    )
                }
            } else {
                items(localBackups, key = { it.name }) { item ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = BackgroundWhite),
                        border = BorderStroke(1.dp, BorderLight),
                        shape = RoundedCornerShape(14.dp),
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Text(
                                text = item.name,
                                style = MaterialTheme.typography.titleSmall,
                                color = NavyPrimary,
                                fontWeight = FontWeight.Bold,
                            )
                            Text(
                                text = "${DateFormatters.formatTimestampArabic(item.modifiedAt)} • ${(item.sizeBytes / 1024).coerceAtLeast(1)} كيلوبايت",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        pendingSaveFile = item.file
                                        saveDocumentLauncher.launch(item.name)
                                    },
                                    modifier = Modifier.weight(1f),
                                ) {
                                    Icon(Icons.Default.SaveAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("حفظ بالهاتف")
                                }
                                OutlinedButton(
                                    onClick = { onShareBackup(item.file) },
                                    modifier = Modifier.weight(1f),
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("مشاركة")
                                }
                                IconButton(onClick = { onRestoreFromFile(item.file) }) {
                                    Icon(Icons.Default.Restore, contentDescription = "استعادة هذه النسخة", tint = StatusConfirmedFg)
                                }
                                IconButton(onClick = { onDeleteBackup(item.file) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "حذف النسخة", tint = StatusCancelledFg)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (restoreSummary != null) {
        AlertDialog(
            onDismissRequest = onDismissRestoreSummary,
            title = {
                Text(
                    text = "تمت استعادة النسخة الاحتياطية",
                    style = MaterialTheme.typography.titleLarge,
                    color = NavyPrimary,
                )
            },
            text = {
                Surface(
                    color = GoldContainer,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        Text("العملاء الجدد المضافون: ${restoreSummary.addedClients}", fontWeight = FontWeight.Bold)
                        Text("العملاء الموجودون مسبقًا (تم منع تكرارهم): ${restoreSummary.skippedDuplicateClients}")
                        Text("الحجوزات المستعادة: ${restoreSummary.addedBookings}")
                        Text("المدفوعات المستعادة: ${restoreSummary.addedPayments}")
                        Text("الصور والمستندات المستعادة: ${restoreSummary.restoredDocuments}")
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = onDismissRestoreSummary,
                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                ) {
                    Text("حسنًا")
                }
            },
        )
    }
}
