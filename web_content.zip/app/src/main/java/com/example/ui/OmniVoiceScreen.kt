package com.example.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.AudioPlayerBar
import com.example.ui.components.GenerationProgressDialog
import com.example.ui.components.PresetsDialog
import com.example.ui.components.ProjectLibrarySheet
import com.example.ui.components.StudioTopBar
import com.example.ui.components.TextEditorSection
import com.example.ui.components.VoiceControlsSection
import com.example.ui.components.VoiceSelectionDialog

@Composable
fun OmniVoiceScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val queueState by viewModel.queueState.collectAsStateWithLifecycle()
    val playbackState by viewModel.playbackState.collectAsStateWithLifecycle()
    val projects by viewModel.allProjects.collectAsStateWithLifecycle()

    var showVoiceDialog by remember { mutableStateOf(false) }
    var showPresetsDialog by remember { mutableStateOf(false) }
    var showProjectsDialog by remember { mutableStateOf(false) }
    var showGenerationDialog by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(queueState.isRunning, queueState.failedChunkIndex) {
        if (queueState.isRunning || queueState.failedChunkIndex != null) {
            showGenerationDialog = true
        }
    }

    LaunchedEffect(uiState.userNotice) {
        uiState.userNotice?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            viewModel.dismissNotice()
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing),
        topBar = {
            StudioTopBar(
                projectTitle = uiState.projectTitle,
                onTitleChange = { viewModel.updateTitle(it) },
                projectsCount = projects.size,
                onOpenProjects = { showProjectsDialog = true },
                onOpenPresets = { showPresetsDialog = true },
                onNewProject = { viewModel.createNewProject() },
                onSaveProject = {
                    viewModel.saveCurrentProject()
                    Toast.makeText(context, "Project saved", Toast.LENGTH_SHORT).show()
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            val isExpandedWidth = maxWidth >= 840.dp
            val scrollState = rememberScrollState()

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(scrollState),
                contentAlignment = Alignment.TopCenter
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = if (isExpandedWidth) 1100.dp else 680.dp)
                        .padding(16.dp)
                        .navigationBarsPadding(),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    if (isExpandedWidth) {
                        // Two Column Tablet/Desktop Layout
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Column(
                                modifier = Modifier.weight(1.2f),
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                TextEditorSection(
                                    text = uiState.scriptText,
                                    onTextChange = { viewModel.updateScriptText(it) },
                                    speechSpeed = uiState.speechSpeed,
                                    onOpenPresets = { showPresetsDialog = true }
                                )

                                if (uiState.currentAudioFile != null && playbackState.isLoaded) {
                                    AudioPlayerBar(
                                        playbackState = playbackState,
                                        onTogglePlayPause = { viewModel.togglePlayPause() },
                                        onSeekTo = { viewModel.seekTo(it) },
                                        onSeekBy = { viewModel.seekBy(it) },
                                        onDeleteAudio = { viewModel.deleteCurrentAudio() },
                                        projectTitle = uiState.projectTitle
                                    )
                                }
                            }

                            Column(
                                modifier = Modifier.weight(0.8f),
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                VoiceControlsSection(
                                    selectedVoice = uiState.selectedVoice,
                                    onOpenVoiceSelector = { showVoiceDialog = true },
                                    speechSpeed = uiState.speechSpeed,
                                    onSpeedChange = { viewModel.setSpeed(it) },
                                    pitch = uiState.pitch,
                                    onPitchChange = { viewModel.setPitch(it) },
                                    pauseBetweenSentencesMs = uiState.pauseBetweenSentencesMs,
                                    onPauseChange = { viewModel.setPause(it) },
                                    isVoicePreviewPlaying = uiState.isVoicePreviewPlaying,
                                    onToggleVoicePreview = { viewModel.previewSelectedVoice() },
                                    isGenerating = queueState.isRunning,
                                    onGenerateSpeech = { viewModel.generateSpeech() }
                                )
                            }
                        }
                    } else {
                        // Single Column Phone Layout
                        TextEditorSection(
                            text = uiState.scriptText,
                            onTextChange = { viewModel.updateScriptText(it) },
                            speechSpeed = uiState.speechSpeed,
                            onOpenPresets = { showPresetsDialog = true }
                        )

                        VoiceControlsSection(
                            selectedVoice = uiState.selectedVoice,
                            onOpenVoiceSelector = { showVoiceDialog = true },
                            speechSpeed = uiState.speechSpeed,
                            onSpeedChange = { viewModel.setSpeed(it) },
                            pitch = uiState.pitch,
                            onPitchChange = { viewModel.setPitch(it) },
                            pauseBetweenSentencesMs = uiState.pauseBetweenSentencesMs,
                            onPauseChange = { viewModel.setPause(it) },
                            isVoicePreviewPlaying = uiState.isVoicePreviewPlaying,
                            onToggleVoicePreview = { viewModel.previewSelectedVoice() },
                            isGenerating = queueState.isRunning,
                            onGenerateSpeech = { viewModel.generateSpeech() }
                        )

                        if (uiState.currentAudioFile != null && playbackState.isLoaded) {
                            AudioPlayerBar(
                                playbackState = playbackState,
                                onTogglePlayPause = { viewModel.togglePlayPause() },
                                onSeekTo = { viewModel.seekTo(it) },
                                onSeekBy = { viewModel.seekBy(it) },
                                onDeleteAudio = { viewModel.deleteCurrentAudio() },
                                projectTitle = uiState.projectTitle
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }

    // Voice Selection Dialog
    if (showVoiceDialog) {
        VoiceSelectionDialog(
            availableVoices = uiState.availableVoices,
            selectedVoice = uiState.selectedVoice,
            onSelectVoice = { viewModel.selectVoice(it) },
            onPreviewVoice = { voice ->
                viewModel.selectVoice(voice)
                viewModel.previewSelectedVoice()
            },
            onStopPreview = { viewModel.stopVoicePreview() },
            isVoicePreviewPlaying = uiState.isVoicePreviewPlaying,
            onDismiss = {
                viewModel.stopVoicePreview()
                showVoiceDialog = false
            }
        )
    }

    // Presets Dialog
    if (showPresetsDialog) {
        PresetsDialog(
            onSelectPreset = { preset ->
                viewModel.loadPreset(preset)
                Toast.makeText(context, "Loaded \"${preset.title}\"", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { showPresetsDialog = false }
        )
    }

    // Project Library Dialog
    if (showProjectsDialog) {
        ProjectLibrarySheet(
            projects = projects,
            currentProjectId = uiState.currentProjectId,
            onSelectProject = { viewModel.loadProject(it) },
            onDeleteProject = { viewModel.deleteProject(it) },
            onNewProject = { viewModel.createNewProject() },
            onDismiss = { showProjectsDialog = false }
        )
    }

    // Generation Progress Dialog
    if (showGenerationDialog) {
        GenerationProgressDialog(
            queueState = queueState,
            onRetryChunk = { viewModel.retryFailedChunk(it) },
            onCancel = {
                viewModel.cancelGeneration()
                showGenerationDialog = false
            },
            onDismiss = { showGenerationDialog = false }
        )
    }
}
