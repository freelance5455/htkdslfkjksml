package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.converter.ApkConverterEngine
import com.example.data.installer.ApkInstaller
import com.example.data.model.ApkInfo
import com.example.data.model.ConversionProgress
import com.example.data.model.ConversionStage
import com.example.data.model.SampleItem
import com.example.data.repository.ConvertedApkRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale

data class ConverterUiState(
    val currentTab: Int = 0,
    val progress: ConversionProgress = ConversionProgress(),
    val isConverting: Boolean = false,
    val lastConvertedApk: ApkInfo? = null,
    val historyApks: List<ApkInfo> = emptyList(),
    val isLoadingHistory: Boolean = false,
    val customAppName: String = "",
    val sampleList: List<SampleItem> = emptyList(),
    val snackbarMessage: String? = null,
    val apkToDelete: ApkInfo? = null,
    val showPermissionDialog: Boolean = false,
    val showHtmlPreviewDialog: Boolean = false,
    val isArabic: Boolean = false
)

class ConverterViewModel(application: Application) : AndroidViewModel(application) {

    private val engine = ApkConverterEngine(application)
    private val repository = ConvertedApkRepository(application)

    private val _uiState = MutableStateFlow(
        ConverterUiState(
            isArabic = Locale.getDefault().language.startsWith("ar"),
            sampleList = listOf(
                SampleItem(
                    id = "sample_app_index_html",
                    title = "ملف index.html للتطبيق",
                    description = "صفحة ويب متكاملة عن نفس التطبيق لتحويلها وتثبيتها كـ APK",
                    assetName = "apk_converter_web.zip",
                    type = "Web App HTML"
                ),
                SampleItem(
                    id = "sample_html5_game",
                    title = "لعبة فضاء HTML5",
                    description = "ملف ZIP يحتوي على كود لعبة HTML5 ورسوم متحركة ومؤثرات",
                    assetName = "sample_html5_game.zip",
                    type = "HTML5 ZIP"
                ),
                SampleItem(
                    id = "sample_app_archive",
                    title = "أرشيف حزمة تطبيق",
                    description = "ملف ZIP مضغوط يحتوي بداخله على حزمة APK كاملة",
                    assetName = "sample_app_archive.zip",
                    type = "ZIP with APK"
                ),
                SampleItem(
                    id = "sample_xapk_game",
                    title = "حزمة XAPK",
                    description = "حزمة ألعاب XAPK تحتوي على ملف APK وبيانات manifest",
                    assetName = "sample_xapk_game.xapk",
                    type = "XAPK Bundle"
                )
            )
        )
    )
    val uiState: StateFlow<ConverterUiState> = _uiState.asStateFlow()

    init {
        loadHistory()
    }

    fun selectTab(tab: Int) {
        _uiState.update { it.copy(currentTab = tab) }
        if (tab == 1) {
            loadHistory()
        }
    }

    fun setCustomAppName(name: String) {
        _uiState.update { it.copy(customAppName = name) }
    }

    fun toggleLanguage() {
        _uiState.update { it.copy(isArabic = !it.isArabic) }
    }

    fun openHtmlPreview() {
        _uiState.update { it.copy(showHtmlPreviewDialog = true) }
    }

    fun closeHtmlPreview() {
        _uiState.update { it.copy(showHtmlPreviewDialog = false) }
    }

    fun convertFromUri(uri: Uri) {
        viewModelScope.launch {
            _uiState.update { it.copy(isConverting = true, lastConvertedApk = null) }
            val customName = _uiState.value.customAppName.trim().ifEmpty { null }

            val result = engine.convertFile(
                sourceUri = uri,
                customAppName = customName
            ) { progress ->
                _uiState.update { it.copy(progress = progress) }
            }

            result.fold(
                onSuccess = { apkInfo ->
                    _uiState.update {
                        it.copy(
                            isConverting = false,
                            lastConvertedApk = apkInfo,
                            snackbarMessage = if (it.isArabic) "تم تحويل الحزمة وتوليد APK بنجاح!" else "APK converted successfully!"
                        )
                    }
                    loadHistory()
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            isConverting = false,
                            snackbarMessage = error.localizedMessage ?: "Conversion error"
                        )
                    }
                }
            )
        }
    }

    fun convertAppIndexHtml() {
        viewModelScope.launch {
            _uiState.update { it.copy(isConverting = true, lastConvertedApk = null) }
            val customName = _uiState.value.customAppName.trim().ifEmpty {
                if (_uiState.value.isArabic) "محول APK" else "APK Converter"
            }

            val result = engine.convertFile(
                sourceUri = null,
                assetName = "app_info/index.html",
                customAppName = customName
            ) { progress ->
                _uiState.update { it.copy(progress = progress) }
            }

            result.fold(
                onSuccess = { apkInfo ->
                    _uiState.update {
                        it.copy(
                            isConverting = false,
                            lastConvertedApk = apkInfo,
                            snackbarMessage = if (it.isArabic) "تم تحويل ملف index.html إلى APK بنجاح!" else "index.html converted to APK successfully!"
                        )
                    }
                    loadHistory()
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            isConverting = false,
                            snackbarMessage = error.localizedMessage ?: "Conversion error"
                        )
                    }
                }
            )
        }
    }

    fun convertSample(sample: SampleItem) {
        viewModelScope.launch {
            _uiState.update { it.copy(isConverting = true, lastConvertedApk = null) }
            val customName = _uiState.value.customAppName.trim().ifEmpty { sample.title }

            val result = engine.convertFile(
                sourceUri = null,
                assetName = sample.assetName,
                customAppName = customName
            ) { progress ->
                _uiState.update { it.copy(progress = progress) }
            }

            result.fold(
                onSuccess = { apkInfo ->
                    _uiState.update {
                        it.copy(
                            isConverting = false,
                            lastConvertedApk = apkInfo,
                            snackbarMessage = if (it.isArabic) "تم تحويل النموذج بنجاح!" else "Sample converted successfully!"
                        )
                    }
                    loadHistory()
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(
                            isConverting = false,
                            snackbarMessage = error.localizedMessage ?: "Conversion error"
                        )
                    }
                }
            )
        }
    }

    fun installApk(context: Context, apkInfo: ApkInfo) {
        if (!ApkInstaller.canRequestPackageInstalls(context)) {
            _uiState.update { it.copy(showPermissionDialog = true) }
            return
        }

        val apkFile = File(apkInfo.filePath)
        val result = ApkInstaller.installApk(context, apkFile)
        result.onFailure { error ->
            _uiState.update {
                it.copy(snackbarMessage = error.localizedMessage ?: "Could not open installer")
            }
        }
    }

    fun shareApk(context: Context, apkInfo: ApkInfo) {
        val apkFile = File(apkInfo.filePath)
        ApkInstaller.shareApk(context, apkFile).onFailure { error ->
            _uiState.update {
                it.copy(snackbarMessage = error.localizedMessage ?: "Could not share APK")
            }
        }
    }

    fun saveApkToStorage(context: Context, apkInfo: ApkInfo, destinationUri: Uri) {
        val apkFile = File(apkInfo.filePath)
        ApkInstaller.saveApkToStorage(context, apkFile, destinationUri).fold(
            onSuccess = {
                _uiState.update {
                    it.copy(
                        snackbarMessage = if (it.isArabic) "تم حفظ ملف APK في مجلد التنزيلات بنجاح!" else "APK saved to Downloads!"
                    )
                }
            },
            onFailure = { error ->
                _uiState.update {
                    it.copy(snackbarMessage = error.localizedMessage ?: "Save failed")
                }
            }
        )
    }

    fun saveIndexHtmlToStorage(context: Context, destinationUri: Uri) {
        try {
            context.assets.open("app_info/index.html").use { input ->
                context.contentResolver.openOutputStream(destinationUri)?.use { output ->
                    input.copyTo(output)
                }
            }
            _uiState.update {
                it.copy(
                    snackbarMessage = if (it.isArabic) "تم حفظ ملف index.html في الهاتف بنجاح!" else "index.html saved successfully!"
                )
            }
        } catch (e: Exception) {
            _uiState.update {
                it.copy(snackbarMessage = e.localizedMessage ?: "Save failed")
            }
        }
    }

    fun loadHistory() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingHistory = true) }
            val list = repository.getConvertedApks()
            _uiState.update { it.copy(historyApks = list, isLoadingHistory = false) }
        }
    }

    fun promptDeleteApk(apkInfo: ApkInfo) {
        _uiState.update { it.copy(apkToDelete = apkInfo) }
    }

    fun cancelDelete() {
        _uiState.update { it.copy(apkToDelete = null) }
    }

    fun confirmDelete() {
        val toDelete = _uiState.value.apkToDelete ?: return
        viewModelScope.launch {
            repository.deleteApk(toDelete.filePath)
            _uiState.update { it.copy(apkToDelete = null) }
            loadHistory()
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAllApks()
            loadHistory()
        }
    }

    fun dismissPermissionDialog() {
        _uiState.update { it.copy(showPermissionDialog = false) }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }
}
