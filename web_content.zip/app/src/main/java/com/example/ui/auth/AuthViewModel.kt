package com.example.ui.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.UserEntity
import com.example.data.repository.AuthRepository
import com.example.data.repository.AuthResult
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class ScreenDestination {
    LOADING,
    SIGN_UP,
    LOGIN,
    AUTHENTICATED
}

data class AuthUiState(
    val currentScreen: ScreenDestination = ScreenDestination.LOADING,
    val usernameInput: String = "",
    val isUsernameVisible: Boolean = true,
    val passwordInput: String = "",
    val isPasswordVisible: Boolean = false,
    val errorMessage: String? = null,
    val cooldownSecondsRemaining: Int = 0,
    val isCooldownActive: Boolean = false,
    val isLoading: Boolean = false,

    // One-time recovery code dialog
    val showRecoveryCodeDialog: Boolean = false,
    val recoveryCodeToDisplay: String? = null,

    // Forgot password modal
    val showForgotPasswordDialog: Boolean = false,
    val forgotUsernameInput: String = "",
    val isForgotUsernameVisible: Boolean = true,
    val forgotRecoveryCodeInput: String = "",
    val forgotNewPasswordInput: String = "",
    val isForgotNewPasswordVisible: Boolean = false,
    val forgotErrorMessage: String? = null,
    val isForgotLoading: Boolean = false,

    // Reset app dialog
    val showResetAppDialog: Boolean = false,

    // Active user info for session display
    val currentUser: UserEntity? = null
)

class AuthViewModel(
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    private var cooldownTickerJob: Job? = null

    init {
        viewModelScope.launch {
            authRepository.userFlow.collect { user ->
                val now = System.currentTimeMillis()
                val isSessionValid = authRepository.isSessionValid(user)
                val remainingCooldown = if (user != null && user.cooldownUntilTimestamp > now) {
                    (((user.cooldownUntilTimestamp - now) / 1000) + 1).toInt()
                } else {
                    0
                }

                _uiState.update { current ->
                    val destination = when {
                        user == null -> ScreenDestination.SIGN_UP
                        isSessionValid -> ScreenDestination.AUTHENTICATED
                        else -> ScreenDestination.LOGIN
                    }

                    current.copy(
                        currentScreen = destination,
                        currentUser = user,
                        usernameInput = if (current.usernameInput.isEmpty() && user != null) user.username else current.usernameInput,
                        cooldownSecondsRemaining = remainingCooldown,
                        isCooldownActive = remainingCooldown > 0
                    )
                }

                if (remainingCooldown > 0) {
                    startCooldownTimer(remainingCooldown)
                }
            }
        }
    }

    private fun startCooldownTimer(initialSeconds: Int) {
        cooldownTickerJob?.cancel()
        cooldownTickerJob = viewModelScope.launch {
            var seconds = initialSeconds
            while (seconds > 0) {
                _uiState.update { it.copy(cooldownSecondsRemaining = seconds, isCooldownActive = true) }
                delay(1000)
                seconds--
            }
            _uiState.update { it.copy(cooldownSecondsRemaining = 0, isCooldownActive = false, errorMessage = null) }
        }
    }

    fun onUsernameChange(value: String) {
        _uiState.update { it.copy(usernameInput = value, errorMessage = null) }
    }

    fun toggleUsernameVisibility() {
        _uiState.update { it.copy(isUsernameVisible = !it.isUsernameVisible) }
    }

    fun onPasswordChange(value: String) {
        _uiState.update { it.copy(passwordInput = value, errorMessage = null) }
    }

    fun togglePasswordVisibility() {
        _uiState.update { it.copy(isPasswordVisible = !it.isPasswordVisible) }
    }

    fun switchToLogin() {
        _uiState.update {
            it.copy(
                currentScreen = ScreenDestination.LOGIN,
                errorMessage = null,
                usernameInput = if (it.usernameInput.isEmpty() && it.currentUser != null) it.currentUser.username else it.usernameInput,
                passwordInput = ""
            )
        }
    }

    fun switchToSignUp() {
        _uiState.update {
            it.copy(
                currentScreen = ScreenDestination.SIGN_UP,
                errorMessage = null
            )
        }
    }

    fun onSignUp() {
        val state = _uiState.value
        val rawUsername = state.usernameInput.trim()
        val username = if (rawUsername.contains("@") && rawUsername.length > 20) {
            rawUsername.substringBefore("@")
        } else {
            rawUsername
        }
        val password = state.passwordInput

        if (username.length < 4 || username.length > 20) {
            val hint = if (rawUsername.contains("@")) " (use username without email domain)" else ""
            _uiState.update { it.copy(errorMessage = "Username must be 4–20 characters$hint") }
            return
        }
        if (password.length < 8) {
            _uiState.update { it.copy(errorMessage = "Password must be at least 8 characters") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null, usernameInput = username) }
            when (val result = authRepository.signUp(username, password)) {
                is AuthResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            recoveryCodeToDisplay = result.data,
                            showRecoveryCodeDialog = true,
                            passwordInput = ""
                        )
                    }
                }
                is AuthResult.Error -> {
                    _uiState.update { it.copy(isLoading = false, errorMessage = result.message) }
                }
                is AuthResult.Cooldown -> {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            cooldownSecondsRemaining = result.remainingSeconds,
                            isCooldownActive = true
                        )
                    }
                    startCooldownTimer(result.remainingSeconds)
                }
            }
        }
    }

    fun onLogin() {
        val state = _uiState.value
        if (state.isCooldownActive) return

        val username = state.usernameInput.trim()
        val password = state.passwordInput

        if (username.isEmpty() || password.isEmpty()) {
            _uiState.update { it.copy(errorMessage = "Incorrect username or password") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            when (val result = authRepository.login(username, password)) {
                is AuthResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            currentScreen = ScreenDestination.AUTHENTICATED,
                            passwordInput = "",
                            errorMessage = null
                        )
                    }
                }
                is AuthResult.Error -> {
                    _uiState.update { it.copy(isLoading = false, errorMessage = result.message) }
                }
                is AuthResult.Cooldown -> {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            errorMessage = "Too many failed attempts",
                            cooldownSecondsRemaining = result.remainingSeconds,
                            isCooldownActive = true
                        )
                    }
                    startCooldownTimer(result.remainingSeconds)
                }
            }
        }
    }

    fun onRecoveryCodeConfirmed() {
        _uiState.update {
            it.copy(
                showRecoveryCodeDialog = false,
                recoveryCodeToDisplay = null,
                currentScreen = ScreenDestination.AUTHENTICATED
            )
        }
    }

    // Forgot Password Flow
    fun openForgotPasswordDialog() {
        _uiState.update {
            it.copy(
                showForgotPasswordDialog = true,
                forgotUsernameInput = it.usernameInput,
                forgotRecoveryCodeInput = "",
                forgotNewPasswordInput = "",
                forgotErrorMessage = null
            )
        }
    }

    fun dismissForgotPasswordDialog() {
        _uiState.update { it.copy(showForgotPasswordDialog = false, forgotErrorMessage = null) }
    }

    fun onForgotUsernameChange(value: String) {
        _uiState.update { it.copy(forgotUsernameInput = value, forgotErrorMessage = null) }
    }

    fun toggleForgotUsernameVisibility() {
        _uiState.update { it.copy(isForgotUsernameVisible = !it.isForgotUsernameVisible) }
    }

    fun onForgotRecoveryCodeChange(value: String) {
        _uiState.update { it.copy(forgotRecoveryCodeInput = value, forgotErrorMessage = null) }
    }

    fun onForgotNewPasswordChange(value: String) {
        _uiState.update { it.copy(forgotNewPasswordInput = value, forgotErrorMessage = null) }
    }

    fun toggleForgotNewPasswordVisibility() {
        _uiState.update { it.copy(isForgotNewPasswordVisible = !it.isForgotNewPasswordVisible) }
    }

    fun submitForgotPassword() {
        val state = _uiState.value
        val username = state.forgotUsernameInput.trim()
        val recoveryCode = state.forgotRecoveryCodeInput.trim()
        val newPassword = state.forgotNewPasswordInput

        if (username.isEmpty() || recoveryCode.isEmpty()) {
            _uiState.update { it.copy(forgotErrorMessage = "Please enter username and recovery code") }
            return
        }
        if (newPassword.length < 8) {
            _uiState.update { it.copy(forgotErrorMessage = "Password must be at least 8 characters") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isForgotLoading = true, forgotErrorMessage = null) }
            when (val result = authRepository.resetPasswordWithRecoveryCode(username, recoveryCode, newPassword)) {
                is AuthResult.Success -> {
                    _uiState.update {
                        it.copy(
                            isForgotLoading = false,
                            showForgotPasswordDialog = false,
                            recoveryCodeToDisplay = result.data,
                            showRecoveryCodeDialog = true
                        )
                    }
                }
                is AuthResult.Error -> {
                    _uiState.update {
                        it.copy(isForgotLoading = false, forgotErrorMessage = result.message) }
                }
                is AuthResult.Cooldown -> {
                    _uiState.update {
                        it.copy(
                            isForgotLoading = false,
                            showForgotPasswordDialog = false,
                            errorMessage = "Too many failed attempts",
                            cooldownSecondsRemaining = result.remainingSeconds,
                            isCooldownActive = true
                        )
                    }
                    startCooldownTimer(result.remainingSeconds)
                }
            }
        }
    }

    // Reset App Flow
    fun openResetAppDialog() {
        _uiState.update { it.copy(showResetAppDialog = true) }
    }

    fun dismissResetAppDialog() {
        _uiState.update { it.copy(showResetAppDialog = false) }
    }

    fun confirmResetApp() {
        viewModelScope.launch {
            authRepository.resetApp()
            _uiState.update {
                AuthUiState(
                    currentScreen = ScreenDestination.SIGN_UP,
                    showResetAppDialog = false
                )
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            authRepository.logout()
            _uiState.update {
                it.copy(
                    currentScreen = ScreenDestination.LOGIN,
                    usernameInput = it.currentUser?.username ?: it.usernameInput,
                    passwordInput = "",
                    errorMessage = null
                )
            }
        }
    }
}

class AuthViewModelFactory(
    private val authRepository: AuthRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AuthViewModel::class.java)) {
            return AuthViewModel(authRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
