package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.DailyPanchang
import com.example.model.Paksha
import com.example.panchang.VedicPanchangCalculator
import java.util.Calendar

@Composable
fun TraditionalWallCalendar(
    viewMonth: Calendar,
    selectedDate: Calendar,
    language: AppLanguage,
    onDateSelected: (Calendar) -> Unit,
    onPreviousMonth: () -> Unit,
    onNextMonth: () -> Unit,
    onMonthYearSelected: (year: Int, month: Int) -> Unit,
    onAlarmClick: () -> Unit,
    onLanguageClick: () -> Unit,
    onThemeClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val year = viewMonth.get(Calendar.YEAR)
    val month = viewMonth.get(Calendar.MONTH) + 1 // 1..12

    val monthNamesHindi = listOf(
        "जनवरी", "फरवरी", "मार्च", "अप्रैल", "मई", "जून",
        "जुलाई", "अगस्त", "सितंबर", "अक्टूबर", "नवंबर", "दिसंबर"
    )
    val monthName = monthNamesHindi.getOrElse(month - 1) { "माह" }
    val hinduMonthPair = remember(month) { VedicPanchangCalculator.getMonthHinduPair(month) }
    val holidays = remember(year, month) { VedicPanchangCalculator.getMonthHolidays(year, month) }
    val bichhudaSpan = remember(year, month) { VedicPanchangCalculator.getMonthBichhuda(year, month) }
    val panchakSpan = remember(year, month) { VedicPanchangCalculator.getMonthPanchak(year, month) }
    val festivalsMarquee = remember(year, month) { VedicPanchangCalculator.getMonthFestivalsMarquee(year, month) }

    var showPickerModal by remember { mutableStateOf(false) }

    val verticalScrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF9F9F9))
            .verticalScroll(verticalScrollState)
    ) {
        // 1. Top Pink/Red Navigation Bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Color(0xFFE91E63),
            shadowElevation = 4.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onPreviousMonth,
                    modifier = Modifier.size(42.dp).testTag("wall_cal_prev")
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.25f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Previous",
                            tint = Color.White
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { showPickerModal = true },
                        modifier = Modifier.size(42.dp).testTag("wall_cal_datepicker")
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.25f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.DateRange,
                                contentDescription = "Date Picker",
                                tint = Color.White
                            )
                        }
                    }

                    IconButton(
                        onClick = onAlarmClick,
                        modifier = Modifier.size(42.dp).testTag("wall_cal_alarm")
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.25f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Alarm,
                                contentDescription = "Alarm",
                                tint = Color.White
                            )
                        }
                    }

                    IconButton(
                        onClick = onLanguageClick,
                        modifier = Modifier.size(42.dp).testTag("wall_cal_lang")
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.25f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Translate,
                                contentDescription = "Language",
                                tint = Color.White
                            )
                        }
                    }

                    IconButton(
                        onClick = onThemeClick,
                        modifier = Modifier.size(42.dp).testTag("wall_cal_theme")
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.25f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.ColorLens,
                                contentDescription = "Theme",
                                tint = Color.White
                            )
                        }
                    }
                }

                IconButton(
                    onClick = onNextMonth,
                    modifier = Modifier.size(42.dp).testTag("wall_cal_next")
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.25f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "Next",
                            tint = Color.White
                        )
                    }
                }
            }
        }

        // 2. Grand Traditional Temple Arch Banner (Mandir & Deity Header)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(86.dp)
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF8B0000), Color(0xFFB71C1C), Color(0xFFD32F2F))
                    )
                )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Sacred Shiva-Parvati / Ganesha Deity Art Badge
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(62.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFFFFD54F))
                            .border(2.dp, Color(0xFFFFECB3), RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "🕉️", fontSize = 24.sp)
                            Text(
                                text = "शिव-पार्वती",
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF8B0000)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    // Big Bold Title
                    Column {
                        Text(
                            text = "वैदिक पंचांग $year",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White,
                            fontSize = 22.sp
                        )
                        Text(
                            text = "सनातन धर्म प्रामाणिक काल गणना",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFFD54F),
                            fontSize = 11.sp
                        )
                    }
                }

                // 2026 Calendar Emblem Badge
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.White)
                        .border(1.5.dp, Color(0xFFB71C1C), RoundedCornerShape(8.dp))
                        .clickable { showPickerModal = true },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "$year",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFFD32F2F)
                        )
                        Text(
                            text = "पंचांग",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF333333)
                        )
                    }
                }
            }
        }

        // 3. Triple Ribbon Strip (Month-Year, Vikram Samvat, Hindu Months)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(34.dp)
                .clickable { showPickerModal = true }
        ) {
            // Left Red Banner
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .background(Color(0xFFD32F2F)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "$monthName - $year ▾",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }

            // Center Maroon/Purple Banner
            Box(
                modifier = Modifier
                    .weight(1.2f)
                    .fillMaxHeight()
                    .background(Color(0xFF4A148C)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "विक्रम संवत 2083",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }

            // Right Orange Banner
            Box(
                modifier = Modifier
                    .weight(1.1f)
                    .fillMaxHeight()
                    .background(Color(0xFFE65100)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = hinduMonthPair,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }

        // 4. Main Calendar Body (Weekday Avatars + 5 Weeks Grid + Right Side Panel)
        val horizontalScrollState = rememberScrollState()

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(horizontalScrollState)
                .padding(top = 2.dp)
        ) {
            // Main Calendar Table: 7 Rows (Sun to Sat)
            Column(
                modifier = Modifier.width(360.dp)
            ) {
                val weekdaysData = listOf(
                    Triple(Calendar.SUNDAY, "रवि\nSUN", Color(0xFFD32F2F) to "☀️"),
                    Triple(Calendar.MONDAY, "सोम\nMON", Color(0xFF1976D2) to "🔱"),
                    Triple(Calendar.TUESDAY, "मंगल\nTUE", Color(0xFF388E3C) to "🚩"),
                    Triple(Calendar.WEDNESDAY, "बुध\nWED", Color(0xFF00897B) to "🐘"),
                    Triple(Calendar.THURSDAY, "गुरु\nTHU", Color(0xFF8E24AA) to "🌸"),
                    Triple(Calendar.FRIDAY, "शुक्र\nFRI", Color(0xFF3949AB) to "🪷"),
                    Triple(Calendar.SATURDAY, "शनि\nSAT", Color(0xFF4E342E) to "🪐")
                )

                weekdaysData.forEach { (dayOfWeek, label, styleInfo) ->
                    val (badgeColor, deityIcon) = styleInfo
                    WeekdayCalendarRow(
                        viewMonth = viewMonth,
                        dayOfWeek = dayOfWeek,
                        weekdayLabel = label,
                        badgeColor = badgeColor,
                        deityIcon = deityIcon,
                        selectedDate = selectedDate,
                        onDateSelected = onDateSelected
                    )
                }
            }

            // Right Side Panel (Vrat Days, Holidays, Bichhuda Box, Panchak Box)
            TraditionalRightPanel(
                holidays = holidays,
                bichhuda = bichhudaSpan,
                panchak = panchakSpan,
                modifier = Modifier.width(145.dp)
            )
        }

        // 5. Bottom Marquee / Ribbon (इस महीने के त्यौहार)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0D1B2A))
                .padding(horizontal = 10.dp, vertical = 8.dp)
        ) {
            Text(
                text = "इस महीने के त्यौहार (Festivals of this Month)",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFFFFD54F),
                fontSize = 12.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = festivalsMarquee,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Medium,
                color = Color.White,
                fontSize = 10.5.sp,
                lineHeight = 15.sp
            )
        }

        Spacer(modifier = Modifier.height(10.dp))
    }

    if (showPickerModal) {
        MonthYearPickerDialog(
            currentCalendar = viewMonth,
            onDismiss = { showPickerModal = false },
            onConfirm = { y, m ->
                onMonthYearSelected(y, m)
                showPickerModal = false
            }
        )
    }
}

@Composable
private fun WeekdayCalendarRow(
    viewMonth: Calendar,
    dayOfWeek: Int,
    weekdayLabel: String,
    badgeColor: Color,
    deityIcon: String,
    selectedDate: Calendar,
    onDateSelected: (Calendar) -> Unit
) {
    val daysInThisRow = remember(viewMonth, dayOfWeek) {
        val cal = viewMonth.clone() as Calendar
        cal.set(Calendar.DAY_OF_MONTH, 1)
        val maxDays = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        val list = mutableListOf<Int>()
        for (d in 1..maxDays) {
            cal.set(Calendar.DAY_OF_MONTH, d)
            if (cal.get(Calendar.DAY_OF_WEEK) == dayOfWeek) {
                list.add(d)
            }
        }
        list
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(IntrinsicSize.Min)
            .border(0.5.dp, Color(0xFFDDDDDD))
    ) {
        // Left Deity Avatar Weekday Badge
        Box(
            modifier = Modifier
                .width(44.dp)
                .fillMaxHeight()
                .background(badgeColor.copy(alpha = 0.08f))
                .border(0.5.dp, Color(0xFFE0E0E0))
                .padding(vertical = 4.dp, horizontal = 2.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(text = deityIcon, fontSize = 14.sp)
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(badgeColor),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = weekdayLabel,
                        color = Color.White,
                        fontSize = 8.5.sp,
                        fontWeight = FontWeight.ExtraBold,
                        textAlign = TextAlign.Center,
                        lineHeight = 10.sp
                    )
                }
            }
        }

        val cal = viewMonth.clone() as Calendar
        cal.set(Calendar.DAY_OF_MONTH, 1)
        val firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
        val hasLeadingBlank = dayOfWeek < firstDayOfWeek

        for (col in 0 until 5) {
            val dayNumber = if (hasLeadingBlank) {
                daysInThisRow.getOrNull(col - 1)
            } else {
                daysInThisRow.getOrNull(col)
            }

            if (dayNumber != null) {
                val dayCal = viewMonth.clone() as Calendar
                dayCal.set(Calendar.DAY_OF_MONTH, dayNumber)

                val isSelected = dayCal.get(Calendar.YEAR) == selectedDate.get(Calendar.YEAR) &&
                        dayCal.get(Calendar.MONTH) == selectedDate.get(Calendar.MONTH) &&
                        dayCal.get(Calendar.DAY_OF_MONTH) == selectedDate.get(Calendar.DAY_OF_MONTH)

                val panchang = VedicPanchangCalculator.calculatePanchang(dayCal)

                TraditionalDateCell(
                    dayNumber = dayNumber,
                    panchang = panchang,
                    isSunday = dayOfWeek == Calendar.SUNDAY,
                    isSelected = isSelected,
                    onClick = { onDateSelected(dayCal) },
                    modifier = Modifier.width(63.2.dp)
                )
            } else {
                Box(
                    modifier = Modifier
                        .width(63.2.dp)
                        .fillMaxHeight()
                        .background(Color(0xFFFBFBFB))
                        .border(0.5.dp, Color(0xFFE8E8E8))
                )
            }
        }
    }
}

@Composable
private fun TraditionalDateCell(
    dayNumber: Int,
    panchang: DailyPanchang,
    isSunday: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cellBgColor = when {
        isSelected -> Color(0xFFFFECB3)
        panchang.paksha == Paksha.KRISHNA -> Color(0xFFFFF8E7)
        else -> Color.White
    }

    val tithiHindiNum = remember(panchang.tithiNumber) {
        val num = if (panchang.tithiNumber <= 15) panchang.tithiNumber else panchang.tithiNumber - 15
        VedicPanchangCalculator.HINDI_NUMERALS.getOrElse(num) { "$num" }
    }

    val iconSymbol = when {
        panchang.tithiNumber == 15 -> "🌕"
        panchang.tithiNumber == 30 -> "🌑"
        panchang.tithiNumber == 11 || panchang.tithiNumber == 26 -> "🌾"
        panchang.tithiNumber == 13 || panchang.tithiNumber == 28 -> "🪔"
        panchang.tithiNumber == 4 || panchang.tithiNumber == 19 -> "🐘"
        panchang.festivals.isNotEmpty() -> "🚩"
        else -> ""
    }

    Box(
        modifier = modifier
            .fillMaxHeight()
            .background(cellBgColor)
            .border(
                width = if (isSelected) 1.5.dp else 0.5.dp,
                color = if (isSelected) Color(0xFFD32F2F) else Color(0xFFE0E0E0)
            )
            .clickable(onClick = onClick)
            .padding(2.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Text(
                    text = "$dayNumber",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 18.sp,
                    color = if (isSunday) Color(0xFFD32F2F) else Color(0xFF111111),
                    modifier = Modifier.padding(start = 2.dp)
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(1.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(14.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(Color(0xFFE91E63)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "$dayNumber",
                            color = Color.White,
                            fontSize = 7.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(13.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFFFD54F))
                            .border(0.5.dp, Color(0xFFFFA000), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = tithiHindiNum,
                            color = Color(0xFF3E2723),
                            fontSize = 7.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${panchang.hinduMonth} ${if (panchang.paksha == Paksha.SHUKLA) "शुक्ल" else "कृष्ण"} ${if (panchang.tithiNumber <= 15) panchang.tithiNumber else panchang.tithiNumber - 15}",
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF333333),
                        maxLines = 1
                    )
                    Text(
                        text = "तिथि : ${panchang.tithiName}",
                        fontSize = 7.5.sp,
                        color = Color(0xFF444444),
                        maxLines = 1
                    )
                    Text(
                        text = "नक्षत्र : ${panchang.nakshatra}",
                        fontSize = 7.5.sp,
                        color = Color(0xFF555555),
                        maxLines = 1
                    )
                }

                if (iconSymbol.isNotBlank()) {
                    Text(text = iconSymbol, fontSize = 11.sp, modifier = Modifier.padding(end = 1.dp))
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "🌅${panchang.sunrise}",
                    fontSize = 6.8.sp,
                    color = Color(0xFF444444),
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = "🌄${panchang.sunset}",
                    fontSize = 6.8.sp,
                    color = Color(0xFF444444),
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
private fun TraditionalRightPanel(
    holidays: List<Pair<String, String>>,
    bichhuda: com.example.panchang.MonthBichhudaSpan,
    panchak: com.example.panchang.MonthPanchakSpan,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .background(Color(0xFFFFFBF0))
            .border(0.5.dp, Color(0xFFD0D0D0))
            .padding(3.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(0.5.dp, Color(0xFFCCCCCC)),
            shape = RoundedCornerShape(4.dp)
        ) {
            Column(modifier = Modifier.padding(4.dp)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF5D4037))
                        .padding(vertical = 2.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "व्रत दिन",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))

                val vrats = listOf(
                    "🌑" to "अमावस्या",
                    "🌕" to "पूर्णिमा",
                    "🌾" to "एकादशी",
                    "🌙" to "षष्ठी",
                    "🌿" to "चतुर्दशी",
                    "🔱" to "शिवरात्रि",
                    "🪔" to "प्रदोष व्रत",
                    "🐘" to "संकष्टी चतुर्थी व्रत",
                    "🌸" to "द्वादशी",
                    "☀️" to "संक्रांति"
                )

                vrats.forEach { (icon, name) ->
                    Row(
                        modifier = Modifier.padding(vertical = 1.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = icon, fontSize = 7.5.sp)
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(text = name, fontSize = 7.5.sp, color = Color(0xFF333333), maxLines = 1)
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp), color = Color(0xFFEEEEEE))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(Color(0xFFE91E63)))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(text = "राष्ट्रीय तिथि", fontSize = 7.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(6.dp).background(Color.White).border(0.5.dp, Color.Gray))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(text = "शुक्ल पक्ष", fontSize = 7.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(6.dp).background(Color(0xFFFFF8E7)))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(text = "कृष्ण पक्ष", fontSize = 7.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(6.dp).background(Color(0xFFFFCDD2)))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(text = "छुट्टियां", fontSize = 7.sp)
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(0.5.dp, Color(0xFFE57373)),
            shape = RoundedCornerShape(4.dp)
        ) {
            Column {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFD32F2F))
                        .padding(vertical = 2.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "छुट्टियां",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp
                    )
                }
                Column(modifier = Modifier.padding(3.dp)) {
                    holidays.forEach { (dateText, holidayName) ->
                        Text(
                            text = dateText,
                            fontSize = 7.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFD32F2F)
                        )
                        Text(
                            text = holidayName,
                            fontSize = 7.sp,
                            color = Color(0xFF333333),
                            modifier = Modifier.padding(bottom = 2.dp),
                            maxLines = 1
                        )
                    }
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(0.5.dp, Color(0xFFFFB74D)),
            shape = RoundedCornerShape(4.dp)
        ) {
            Column {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFE65100))
                        .padding(vertical = 2.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "बिछुड़ा",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp
                    )
                }
                Column(modifier = Modifier.padding(3.dp)) {
                    Text(
                        text = "आरम्भ ${bichhuda.startDate}",
                        fontSize = 7.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF111111)
                    )
                    Text(
                        text = bichhuda.startTime,
                        fontSize = 7.5.sp,
                        color = Color(0xFF444444)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "अंत ${bichhuda.endDate}",
                        fontSize = 7.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF111111)
                    )
                    Text(
                        text = bichhuda.endTime,
                        fontSize = 7.5.sp,
                        color = Color(0xFF444444)
                    )
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(0.5.dp, Color(0xFF64B5F6)),
            shape = RoundedCornerShape(4.dp)
        ) {
            Column {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0D47A1))
                        .padding(vertical = 2.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "पंचक",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp
                    )
                }
                Column(modifier = Modifier.padding(3.dp)) {
                    Text(
                        text = "आरम्भ ${panchak.startDate}",
                        fontSize = 7.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF111111)
                    )
                    Text(
                        text = panchak.startTime,
                        fontSize = 7.5.sp,
                        color = Color(0xFF444444)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "अंत ${panchak.endDate}",
                        fontSize = 7.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF111111)
                    )
                    Text(
                        text = panchak.endTime,
                        fontSize = 7.5.sp,
                        color = Color(0xFF444444)
                    )
                }
            }
        }
    }
}
