package com.example.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.local.ConversationEntity
import com.example.ui.PermissionRequestTarget
import com.example.ui.theme.SuesaAccentWhite
import com.example.ui.theme.SuesaBubbleModel
import com.example.ui.theme.SuesaCard
import com.example.ui.theme.SuesaPurple
import com.example.ui.theme.SuesaPurpleBorder
import com.example.ui.theme.SuesaSuccess
import com.example.ui.theme.SuesaTextPrimary
import com.example.ui.theme.SuesaTextSecondary
import com.example.util.AttachmentHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AttachmentBottomSheet(
    photoPermissionGranted: Boolean,
    cameraPermissionGranted: Boolean,
    filesPermissionGranted: Boolean,
    isFloatingPanelOpen: Boolean,
    onDismiss: () -> Unit,
    onPhotoPickClick: () -> Unit,
    onCameraPickClick: () -> Unit,
    onFilePickClick: () -> Unit,
    onOpenPanelClick: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SuesaCard,
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(top = 12.dp, bottom = 14.dp)
                    .width(42.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF777777))
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp)
                .padding(bottom = 24.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // 1. Fotoğraf
                FileMenuCardItem(
                    emoji = "🖼️",
                    title = "Fotoğraf",
                    subtitle = if (photoPermissionGranted) "Galeriden Seç" else "İzin İste & Seç",
                    isGrantedBadge = photoPermissionGranted,
                    onClick = onPhotoPickClick,
                    modifier = Modifier.testTag("photo_pick_button")
                )

                // 2. Kamera
                FileMenuCardItem(
                    emoji = "📷",
                    title = "Kamera",
                    subtitle = if (cameraPermissionGranted) "Kamerayı Aç" else "İzin İste & Aç",
                    isGrantedBadge = cameraPermissionGranted,
                    onClick = onCameraPickClick,
                    modifier = Modifier.testTag("camera_pick_button")
                )

                // 3. Dosyalar
                FileMenuCardItem(
                    emoji = "📎",
                    title = "Dosyalar",
                    subtitle = if (filesPermissionGranted) "Tüm Dosyalar" else "İzin İste & Aç",
                    isGrantedBadge = filesPermissionGranted,
                    onClick = onFilePickClick,
                    modifier = Modifier.testTag("file_pick_button")
                )

                // 4. Paneli Aç (Replaces NotDefteri as requested!)
                FileMenuCardItem(
                    emoji = "🖥️",
                    title = "Paneli Aç",
                    subtitle = if (isFloatingPanelOpen) "Yüzen Ekran Aktif" else "Küçük Yüzen Ekran",
                    isPurpleHighlight = true,
                    onClick = onOpenPanelClick,
                    modifier = Modifier.testTag("open_panel_button")
                )
            }

            HorizontalDivider(color = Color(0xFF303030), thickness = 1.dp)
            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "💡 İpucu: 'Paneli Aç' seçeneği ile Suesa'yı ekran üzerinde yüzen küçük bir pencereye dönüştürebilir ve ekranda gördüğü şeyleri anlatmasını sağlayabilirsin.",
                color = SuesaTextSecondary,
                fontSize = 12.sp,
                lineHeight = 17.sp
            )
        }
    }
}

@Composable
private fun FileMenuCardItem(
    emoji: String,
    title: String,
    subtitle: String,
    isGrantedBadge: Boolean = false,
    isPurpleHighlight: Boolean = false,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bgColor = if (isPurpleHighlight) Color(0xFF241C2E) else SuesaBubbleModel
    val borderColor = when {
        isPurpleHighlight -> SuesaPurpleBorder
        isGrantedBadge -> Color(0xFF3A3A3A)
        else -> Color(0xFF333333)
    }

    Column(
        modifier = modifier
            .width(114.dp)
            .height(126.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(22.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(50.dp)
                .clip(CircleShape)
                .background(if (isPurpleHighlight) Color(0xFF1A102B) else Color(0xFF151515)),
            contentAlignment = Alignment.Center
        ) {
            Text(text = emoji, fontSize = 24.sp)
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = title,
            color = if (isPurpleHighlight) Color(0xFFE9D5FF) else Color(0xFFF2F2F2),
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1
        )

        Spacer(modifier = Modifier.height(2.dp))

        Text(
            text = subtitle,
            color = if (isPurpleHighlight) Color(0xFFC084FC) else SuesaTextSecondary,
            fontSize = 10.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun FirstTimePermissionDialog(
    target: PermissionRequestTarget,
    onAllowAlways: () -> Unit,
    onAllowOnce: () -> Unit,
    onDeny: () -> Unit
) {
    val (icon, title, message, primaryActionText) = when (target) {
        PermissionRequestTarget.PHOTO -> Quadruple(
            Icons.Default.PhotoLibrary,
            "Suesa AI cihazınızdaki fotoğraflara erişsin mi?",
            "İlk kullanımda fotoğraf izni gereklidir. İzin verdiğinizde telefonunuzdaki fotoğraflardan ve galeriden istediğiniz görselleri seçebilirsiniz.",
            "İzin Ver ve Fotoğrafları Aç"
        )
        PermissionRequestTarget.CAMERA -> Quadruple(
            Icons.Default.CameraAlt,
            "Suesa AI kameranızı kullansın mı?",
            "Fotoğraf çekmek ve yüzen panelde canlı görüntü analizi yapabilmek için kamera erişim izni gereklidir.",
            "İzin Ver ve Kamerayı Aç"
        )
        PermissionRequestTarget.FILES -> Quadruple(
            Icons.Default.FolderOpen,
            "Suesa AI tüm dosyalara erişsin mi?",
            "Telefonunuzdaki tüm dosya türlerini (PDF, metin, kod, ses, video, belge vb.) seçip Suesa'ya gönderebilmek için dosya erişim izni verin.",
            "İzin Ver ve Tüm Dosyaları Aç"
        )
    }

    Dialog(onDismissRequest = onDeny) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(Color(0xFF1E1E1E))
                .border(1.dp, Color(0xFF444444), RoundedCornerShape(22.dp))
                .padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF2A1F3D))
                    .border(1.dp, SuesaPurpleBorder, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = Color(0xFFD8B4FE),
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = title,
                color = SuesaAccentWhite,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = message,
                color = Color(0xFFBBBBBB),
                fontSize = 13.sp,
                lineHeight = 19.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = onAllowAlways,
                colors = ButtonDefaults.buttonColors(
                    containerColor = SuesaAccentWhite,
                    contentColor = Color(0xFF111111)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("permission_allow_always_button")
            ) {
                Text(
                    text = primaryActionText,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedButton(
                onClick = onAllowOnce,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = SuesaTextPrimary),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("permission_allow_once_button")
            ) {
                Text(text = "Yalnızca Bu Sefer İzin Ver", fontSize = 13.sp)
            }

            Spacer(modifier = Modifier.height(6.dp))

            OutlinedButton(
                onClick = onDeny,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = SuesaTextSecondary),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .testTag("permission_deny_button")
            ) {
                Text(text = "İzin Verme", fontSize = 13.sp)
            }
        }
    }
}

private data class Quadruple<A, B, C, D>(
    val first: A,
    val second: B,
    val third: C,
    val fourth: D
)

@Composable
fun LiveCameraCaptureModal(
    onDismiss: () -> Unit,
    onPhotoCaptured: (Bitmap) -> Unit,
    onLaunchSystemCamera: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var lensFacing by remember { mutableIntStateOf(CameraSelector.LENS_FACING_BACK) }
    val imageCapture = remember { ImageCapture.Builder().build() }
    val previewView = remember { PreviewView(context) }
    var cameraError by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(lensFacing) {
        cameraError = null
        try {
            val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
            cameraProviderFuture.addListener({
                try {
                    val cameraProvider = cameraProviderFuture.get()
                    val preview = Preview.Builder().build().also {
                        it.setSurfaceProvider(previewView.surfaceProvider)
                    }
                    val selector = CameraSelector.Builder()
                        .requireLensFacing(lensFacing)
                        .build()
                    cameraProvider.unbindAll()
                    cameraProvider.bindToLifecycle(
                        lifecycleOwner,
                        selector,
                        preview,
                        imageCapture
                    )
                } catch (e: Exception) {
                    cameraError = "Kamera önizlemesi başlatılamadı (${e.localizedMessage ?: "Emülatör kamerası"})."
                }
            }, ContextCompat.getMainExecutor(context))
        } catch (e: Exception) {
            cameraError = e.localizedMessage
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            runCatching {
                ProcessCameraProvider.getInstance(context).get().unbindAll()
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0B0B0B))
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top Camera Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CameraAlt,
                            contentDescription = null,
                            tint = SuesaAccentWhite
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Suesa Kamera",
                            color = SuesaAccentWhite,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconButton(
                            onClick = {
                                lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) {
                                    CameraSelector.LENS_FACING_FRONT
                                } else {
                                    CameraSelector.LENS_FACING_BACK
                                }
                            },
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(Color(0xFF242424))
                        ) {
                            Icon(
                                imageVector = Icons.Default.Cameraswitch,
                                contentDescription = "Kamerayı çevir",
                                tint = SuesaAccentWhite
                            )
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(Color(0xFF242424))
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Kapat",
                                tint = SuesaAccentWhite
                            )
                        }
                    }
                }

                // Live CameraX Preview Area
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(vertical = 12.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(Color(0xFF161616))
                        .border(1.dp, Color(0xFF383838), RoundedCornerShape(22.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    AndroidView(
                        factory = { previewView },
                        modifier = Modifier.fillMaxSize()
                    )

                    if (cameraError != null) {
                        Column(
                            modifier = Modifier
                                .padding(20.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color(0xCC111111))
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = cameraError ?: "",
                                color = Color(0xFFDDDDDD),
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                // Bottom Camera Actions
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = onLaunchSystemCamera,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = SuesaTextPrimary)
                        ) {
                            Text("Sistem Kamerası", fontSize = 12.sp)
                        }

                        // Main Shutter Button
                        Box(
                            modifier = Modifier
                                .size(74.dp)
                                .clip(CircleShape)
                                .background(SuesaAccentWhite)
                                .border(4.dp, SuesaPurple, CircleShape)
                                .clickable {
                                    captureFromCameraOrPreview(
                                        context = context,
                                        imageCapture = imageCapture,
                                        previewView = previewView,
                                        onCaptured = onPhotoCaptured
                                    )
                                }
                                .testTag("camera_shutter_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = "Fotoğraf Çek",
                                tint = Color(0xFF111111),
                                modifier = Modifier.size(32.dp)
                            )
                        }

                        OutlinedButton(
                            onClick = {
                                val sample = AttachmentHelper.generateInteractiveSceneBitmap(0)
                                onPhotoCaptured(sample)
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFD8B4FE))
                        ) {
                            Text("Deneme karesi çek", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

private fun captureFromCameraOrPreview(
    context: Context,
    imageCapture: ImageCapture,
    previewView: PreviewView,
    onCaptured: (Bitmap) -> Unit
) {
    // First check if previewView already has a valid frame bitmap
    val previewBmp = runCatching { previewView.bitmap }.getOrNull()
    if (previewBmp != null) {
        onCaptured(previewBmp)
        return
    }

    imageCapture.takePicture(
        ContextCompat.getMainExecutor(context),
        object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                val bitmap = runCatching { imageProxyToBitmap(image) }.getOrNull()
                image.close()
                if (bitmap != null) {
                    onCaptured(bitmap)
                } else {
                    onCaptured(AttachmentHelper.generateInteractiveSceneBitmap(0))
                }
            }

            override fun onError(exception: ImageCaptureException) {
                onCaptured(AttachmentHelper.generateInteractiveSceneBitmap(0))
            }
        }
    )
}

private fun imageProxyToBitmap(image: ImageProxy): Bitmap? {
    val bmp = image.toBitmap()
    val rotation = image.imageInfo.rotationDegrees
    if (rotation == 0) return bmp
    val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
    return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, matrix, true)
}

@Composable
fun SettingsModal(
    currentApiKey: String,
    photoPermissionGranted: Boolean,
    cameraPermissionGranted: Boolean,
    filesPermissionGranted: Boolean,
    onSaveApiKey: (String) -> Unit,
    onResetPermissions: () -> Unit,
    onDismiss: () -> Unit
) {
    var apiKeyText by remember(currentApiKey) { mutableStateOf(currentApiKey) }

    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(SuesaCard)
                .border(1.dp, Color(0xFF444444), RoundedCornerShape(18.dp))
                .padding(18.dp)
        ) {
            Text(
                text = "🔑 Gemini API & İzin Ayarları",
                color = SuesaAccentWhite,
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Özel Gemini API anahtarını buraya yazabilir veya boş bırakarak AI Studio Secrets yapılandırmasını kullanabilirsin.",
                color = Color(0xFFAAAAAA),
                fontSize = 13.sp,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = apiKeyText,
                onValueChange = { apiKeyText = it },
                placeholder = {
                    Text("Gemini API anahtarı (İsteğe bağlı)", color = SuesaTextSecondary)
                },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true,
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = SuesaBubbleModel,
                    unfocusedContainerColor = SuesaBubbleModel,
                    focusedBorderColor = Color(0xFF666666),
                    unfocusedBorderColor = Color(0xFF444444),
                    focusedTextColor = SuesaAccentWhite,
                    unfocusedTextColor = SuesaAccentWhite
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("api_key_input")
            )

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = Color(0xFF303030), thickness = 1.dp)
            Spacer(modifier = Modifier.height(10.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = SuesaPurple,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Cihaz Erişim İzinleri Durumu",
                    color = SuesaTextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            PermissionStatusRow("🖼️ Fotoğraflar ve Galeri", photoPermissionGranted)
            PermissionStatusRow("📷 Kamera ve Canlı Görüş", cameraPermissionGranted)
            PermissionStatusRow("📎 Tüm Dosyalar (*/*)", filesPermissionGranted)

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedButton(
                onClick = onResetPermissions,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFD8B4FE)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("İzinleri Sıfırla (İlk Tıklamada Tekrar İste)", fontSize = 12.sp)
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF333333),
                        contentColor = SuesaAccentWhite
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                ) {
                    Text("Kapat", fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = { onSaveApiKey(apiKeyText) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = SuesaAccentWhite,
                        contentColor = Color(0xFF111111)
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .testTag("save_settings_button")
                ) {
                    Text("Kaydet", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun PermissionStatusRow(label: String, granted: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = Color(0xFFCCCCCC), fontSize = 12.sp)
        Text(
            text = if (granted) "İzin Verildi ✓" else "İlk Açılışta Sorulacak",
            color = if (granted) SuesaSuccess else Color(0xFFFBBF24),
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun ChatSummariesModal(
    conversations: List<ConversationEntity>,
    onSelectConversation: (String) -> Unit,
    onDeleteConversation: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("tr", "TR")) }

    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 520.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Color(0xFF1B1B1B))
                .border(1.dp, Color(0xFF3A3A3A), RoundedCornerShape(18.dp))
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Sohbet Özetleri",
                        color = SuesaAccentWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Suesa ile yaptığın konuşmaların kısa özeti",
                        color = SuesaTextSecondary,
                        fontSize = 12.sp
                    )
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF292929))
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Kapat",
                        tint = SuesaAccentWhite,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (conversations.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 36.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Henüz kayıtlı sohbet yok.",
                        color = SuesaTextSecondary,
                        fontSize = 14.sp
                    )
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(conversations, key = { it.id }) { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF161616))
                                .border(1.dp, Color(0xFF303030), RoundedCornerShape(12.dp))
                                .clickable { onSelectConversation(item.id) }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = dateFormat.format(Date(item.updatedAt)),
                                    color = Color(0xFF888888),
                                    fontSize = 11.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = item.title.ifBlank { "Yeni sohbet" },
                                    color = SuesaAccentWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(3.dp))
                                Text(
                                    text = item.preview.ifBlank { "Henüz mesaj yok." },
                                    color = Color(0xFFBBBBBB),
                                    fontSize = 13.sp,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            IconButton(
                                onClick = { onDeleteConversation(item.id) }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteOutline,
                                    contentDescription = "Sohbeti sil",
                                    tint = Color(0xFF999999)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
