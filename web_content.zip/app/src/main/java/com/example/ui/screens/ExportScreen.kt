package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.viewmodel.MotionForgeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExportScreen(
  viewModel: MotionForgeViewModel,
  onBack: () -> Unit
) {
  val recipe by viewModel.recipe.collectAsState()
  val isExporting by viewModel.isExporting.collectAsState()
  val exportProgress by viewModel.exportProgress.collectAsState()
  val exportComplete by viewModel.exportComplete.collectAsState()

  var selectedResolution by remember { mutableStateOf("1080p (1080x1920)") }
  var selectedFps by remember { mutableStateOf("30 FPS") }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Render & Video Export") },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = null)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
      )
    }
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .background(MaterialTheme.colorScheme.background)
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
      ) {
        Column(modifier = Modifier.padding(20.dp)) {
          Text("Project Export Settings", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.height(8.dp))
          Text("Project: ${recipe?.projectName ?: "Untitled"}", style = MaterialTheme.typography.bodyMedium)
          Text("Duration: ${recipe?.settings?.durationSeconds ?: 10f}s", style = MaterialTheme.typography.bodyMedium)
          Text("Encoding: H.264 / MP4 + AAC Audio", style = MaterialTheme.typography.bodyMedium)
        }
      }

      Text("Resolution Preset", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)

      Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        listOf("720p (720x1280)", "1080p (1080x1920)", "4K UHD").forEach { res ->
          FilterChip(
            selected = selectedResolution == res,
            onClick = { selectedResolution = res },
            label = { Text(res.substringBefore(" ")) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = MaterialTheme.colorScheme.primary,
              selectedLabelColor = Color.White
            )
          )
        }
      }

      Text("Frame Rate", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)

      Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        listOf("30 FPS", "60 FPS").forEach { fps ->
          FilterChip(
            selected = selectedFps == fps,
            onClick = { selectedFps = fps },
            label = { Text(fps) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = MaterialTheme.colorScheme.primary,
              selectedLabelColor = Color.White
            )
          )
        }
      }

      Spacer(modifier = Modifier.weight(1f))

      if (isExporting) {
        Column(
          modifier = Modifier.fillMaxWidth(),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          LinearProgressIndicator(
            progress = { exportProgress },
            modifier = Modifier.fillMaxWidth().height(8.dp),
            color = MaterialTheme.colorScheme.primary,
          )
          Text(
            text = "Rendering MP4 Video... ${(exportProgress * 100).toInt()}%",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold
          )
        }
      } else if (exportComplete) {
        Card(
          modifier = Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = Color(0xFF1B3B2B))
        ) {
          Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF4CAF50), modifier = Modifier.size(48.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text("Video Rendered Successfully!", fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(modifier = Modifier.height(4.dp))
            Text("Saved to device gallery / MotionForge exports", style = MaterialTheme.typography.bodySmall, color = Color.LightGray)
          }
        }
        Spacer(modifier = Modifier.height(16.dp))
        Button(
          onClick = { viewModel.resetExportState() },
          modifier = Modifier.fillMaxWidth(),
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
        ) {
          Text("Render Another Copy")
        }
      } else {
        Button(
          onClick = {
            viewModel.startExport(selectedResolution, "mp4")
          },
          modifier = Modifier.fillMaxWidth(),
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
          Icon(Icons.Default.Download, contentDescription = null)
          Spacer(modifier = Modifier.width(8.dp))
          Text("Start Render & Export MP4")
        }
      }
    }
  }
}
