package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.MetallicSilver
import com.example.ui.theme.MetallicSilverDark
import com.example.ui.theme.StudioBlack
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioDivider
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.roundToInt

@Composable
fun StudioFader(
    label: String,
    value: Float, // 0.0 .. 1.0
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    height: Int = 140,
    accentColor: Color = EmeraldPrimary,
    tag: String = "studio_fader"
) {
    Column(
        modifier = modifier.testTag(tag),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            text = label.uppercase(),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            color = TextSecondary
        )

        BoxWithConstraints(
            modifier = Modifier
                .width(44.dp)
                .height(height.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(StudioBlack)
                .border(1.dp, StudioBorder, RoundedCornerShape(6.dp))
                .pointerInput(height) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        val delta = -dragAmount.y / (height * density)
                        val newValue = (value + delta).coerceIn(0f, 1f)
                        onValueChange(newValue)
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            val density = androidx.compose.ui.platform.LocalDensity.current
            val totalHeightPx = with(density) { maxHeight.toPx() }
            val capHeightDp = 28.dp
            val capHeightPx = with(density) { capHeightDp.toPx() }
            val travelRangePx = totalHeightPx - capHeightPx

            // Fader groove / center slot
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .fillMaxHeight()
                    .padding(vertical = 10.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color(0xFF070B09))
                    .border(0.5.dp, StudioDivider, RoundedCornerShape(2.dp))
            )

            // Fader active fill track (from bottom up)
            val fillHeight = (travelRangePx * value).coerceAtLeast(0f)
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height(with(androidx.compose.ui.platform.LocalDensity.current) { fillHeight.toDp() })
                    .align(Alignment.BottomCenter)
                    .padding(bottom = (capHeightDp / 2))
                    .clip(RoundedCornerShape(1.dp))
                    .background(accentColor.copy(alpha = 0.7f))
            )

            // Tactile Metallic Fader Knob Cap
            val capYOffset = ((1f - value) * travelRangePx).roundToInt()

            Box(
                modifier = Modifier
                    .offset { IntOffset(0, capYOffset) }
                    .align(Alignment.TopCenter)
                    .width(38.dp)
                    .height(capHeightDp)
                    .shadow(4.dp, RoundedCornerShape(4.dp))
                    .clip(RoundedCornerShape(4.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                MetallicSilver,
                                Color(0xFF37474F),
                                Color(0xFF263238),
                                MetallicSilverDark
                            )
                        )
                    )
                    .border(1.dp, Color(0xFF546E7A), RoundedCornerShape(4.dp)),
                contentAlignment = Alignment.Center
            ) {
                // Illuminated center line on fader cap
                Box(
                    modifier = Modifier
                        .fillMaxWidth(0.7f)
                        .height(2.5.dp)
                        .clip(RoundedCornerShape(1.dp))
                        .background(accentColor)
                )
            }
        }

        // Percentage Readout
        Text(
            text = "${(value * 100).roundToInt()}%",
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold,
            color = if (value > 0f) TextPrimary else TextMuted
        )
    }
}
