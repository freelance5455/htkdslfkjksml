package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.PayoutEntity
import com.example.data.local.UserEntity
import com.example.ui.theme.ZingBlack
import com.example.ui.theme.ZingBorder
import com.example.ui.theme.ZingCardSurface
import com.example.ui.theme.ZingCyan
import com.example.ui.theme.ZingDarkSurface
import com.example.ui.theme.ZingEmerald
import com.example.ui.theme.ZingGold
import com.example.ui.theme.ZingNeonPink
import com.example.ui.theme.ZingTextMuted
import com.example.ui.theme.ZingTextPrimary
import com.example.ui.theme.ZingTextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun CreatorDashboardScreen(
    user: UserEntity?,
    payouts: List<PayoutEntity>,
    onBack: () -> Unit,
    onRequestPayout: (Double, String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showWithdrawDialog by remember { mutableStateOf(false) }

    val walletBalance = user?.walletBalance ?: 48250.0
    val totalEarnings = walletBalance + 35750.0

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ZingBlack)
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 32.dp)
    ) {
        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = ZingTextPrimary
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "Creator Monetization Studio",
                    color = ZingTextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Sinji Shorts Creator Rewards & Earnings Dashboard",
                    color = ZingTextSecondary,
                    fontSize = 12.sp
                )
            }
        }

        // --- Earnings Hero Card ---
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Transparent),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .border(
                    width = 1.dp,
                    brush = Brush.linearGradient(listOf(ZingGold.copy(alpha = 0.6f), ZingNeonPink.copy(alpha = 0.3f))),
                    shape = RoundedCornerShape(20.dp)
                )
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                Color(0xFF261D09),
                                Color(0xFF1E132D),
                                ZingDarkSurface
                            )
                        )
                    )
                    .padding(20.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.MonetizationOn,
                                contentDescription = null,
                                tint = ZingGold,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Available Balance",
                                color = ZingGold,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = ZingEmerald.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "Eligible for Payout",
                                color = ZingEmerald,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "₹${String.format("%,.2f", walletBalance)}",
                        color = Color.White,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.ExtraBold
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Lifetime Earnings: ₹${String.format("%,.2f", totalEarnings)} ($${String.format("%,.1f", totalEarnings / 83.5)})",
                        color = ZingTextSecondary,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = { showWithdrawDialog = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ZingGold,
                                contentColor = ZingBlack
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("request_payout_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Payments,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Withdraw / Payout", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // --- Quick Performance Analytics ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            AnalyticsStatCard(
                icon = Icons.Default.Visibility,
                label = "30-Day Views",
                value = "2.84M",
                subtext = "+34% vs last month",
                accentColor = ZingCyan,
                modifier = Modifier.weight(1f)
            )
            AnalyticsStatCard(
                icon = Icons.Default.TrendingUp,
                label = "Avg. RPM",
                value = "₹48.60",
                subtext = "Per 1,000 views",
                accentColor = ZingEmerald,
                modifier = Modifier.weight(1f)
            )
            AnalyticsStatCard(
                icon = Icons.Default.Star,
                label = "Engagement",
                value = "8.4%",
                subtext = "High viral rank",
                accentColor = ZingGold,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // --- Monetization Breakdown Section (शुरू से दिखे) ---
        Text(
            text = "Active & Future Monetization Streams",
            color = ZingTextPrimary,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 1. Ads Revenue Sharing
            MonetizationStreamCard(
                icon = Icons.Default.Tv,
                title = "1. Ads Revenue Sharing",
                tag = "ACTIVE NOW",
                tagColor = ZingEmerald,
                description = "Earn up to 55% share on in-feed video ads shown between your reels.",
                stats = "Earned: ₹21,450.00 | RPM: ₹45.20",
                isExpanded = true
            )

            // 2. Creator Rewards Program
            MonetizationStreamCard(
                icon = Icons.Default.AutoAwesome,
                title = "2. Creator Rewards Program",
                tag = "TIER 2 SILVER",
                tagColor = ZingGold,
                description = "Monthly incentive pool for top original short videos that spark community trends.",
                stats = "Current Bonus Pool: ₹18,500.00 | Next Tier: Gold at 5M views",
                isExpanded = true
            )

            // 3. Virtual Gifts & Coin Tipping
            MonetizationStreamCard(
                icon = Icons.Default.CardGiftcard,
                title = "3. Video Gifts & Coins",
                tag = "ACTIVE NOW",
                tagColor = ZingNeonPink,
                description = "Viewers send virtual gifts (Roses, Rockets, Crowns) on your videos that convert to real cash.",
                stats = "Total Gifts: 8,420 Coins (₹12,630.00)",
                isExpanded = true
            )

            // 4. Subscriptions & VIP Club (Future Monetization Option)
            MonetizationStreamCard(
                icon = Icons.Default.Star,
                title = "4. Fan Subscriptions & VIP Badges",
                tag = "BETA PREVIEW",
                tagColor = ZingCyan,
                description = "Offer paid monthly subscriptions for exclusive creator reels, custom badges & private chats.",
                stats = "Rollout: Coming Next Quarter | Estimated ₹299/mo per sub",
                isExpanded = false
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // --- Payout History & Banking Section ---
        Text(
            text = "Earnings & Payout History",
            color = ZingTextPrimary,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
        )

        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = ZingCardSurface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                if (payouts.isEmpty()) {
                    Text(
                        text = "No payout requests yet. Click Withdraw to request your first transfer.",
                        color = ZingTextSecondary,
                        fontSize = 13.sp
                    )
                } else {
                    payouts.forEach { payout ->
                        PayoutRowItem(payout = payout)
                        Spacer(modifier = Modifier.height(12.dp))
                    }
                }
            }
        }
    }

    // Payout Request Dialog
    if (showWithdrawDialog) {
        WithdrawPayoutDialog(
            availableBalance = walletBalance,
            onDismiss = { showWithdrawDialog = false },
            onSubmit = { amount, method, details ->
                onRequestPayout(amount, method, details)
                showWithdrawDialog = false
                Toast.makeText(context, "Payout request submitted successfully!", Toast.LENGTH_SHORT).show()
            }
        )
    }
}

@Composable
private fun AnalyticsStatCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    subtext: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = ZingCardSurface),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Icon(imageVector = icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = value, color = ZingTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(text = label, color = ZingTextSecondary, fontSize = 11.sp)
            Text(text = subtext, color = accentColor, fontSize = 9.sp)
        }
    }
}

@Composable
private fun MonetizationStreamCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    tag: String,
    tagColor: Color,
    description: String,
    stats: String,
    isExpanded: Boolean
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = ZingCardSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, ZingBorder, RoundedCornerShape(14.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(tagColor.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = icon, contentDescription = null, tint = tagColor, modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = title,
                        color = ZingTextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = tagColor.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = tag,
                        color = tagColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(text = description, color = ZingTextSecondary, fontSize = 12.sp, lineHeight = 16.sp)

            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = ZingDarkSurface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = stats,
                    color = ZingGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
            }
        }
    }
}

@Composable
private fun PayoutRowItem(payout: PayoutEntity) {
    val dateStr = SimpleDateFormat("dd MMM, yyyy", Locale.getDefault()).format(Date(payout.requestDate))
    val statusColor = when (payout.status) {
        "COMPLETED" -> ZingEmerald
        "PROCESSING" -> ZingGold
        else -> ZingCyan
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(ZingDarkSurface),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.AccountBalance,
                    contentDescription = null,
                    tint = statusColor,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = "${payout.payoutMethod} (${payout.accountDetails})",
                    color = ZingTextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(text = dateStr, color = ZingTextMuted, fontSize = 11.sp)
            }
        }

        Column(horizontalAlignment = Alignment.End) {
            Text(
                text = "₹${String.format("%,.2f", payout.amount)}",
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = payout.status,
                color = statusColor,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun WithdrawPayoutDialog(
    availableBalance: Double,
    onDismiss: () -> Unit,
    onSubmit: (Double, String, String) -> Unit
) {
    var amountText by remember { mutableStateOf("10000") }
    var selectedMethod by remember { mutableStateOf("UPI") }
    var accountDetails by remember { mutableStateOf("creator@oksbi") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ZingDarkSurface,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Payments, contentDescription = null, tint = ZingGold)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Request Payout", color = ZingTextPrimary, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Available to withdraw: ₹${String.format("%,.2f", availableBalance)}",
                    color = ZingGold,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Amount input
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("Amount (₹)", color = ZingTextSecondary) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ZingTextPrimary,
                        unfocusedTextColor = ZingTextPrimary,
                        focusedBorderColor = ZingGold,
                        unfocusedBorderColor = ZingBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Payout Method Selector
                Text("Payout Method:", color = ZingTextSecondary, fontSize = 12.sp)
                listOf("UPI", "Bank Transfer", "PayPal").forEach { method ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedMethod = method }
                    ) {
                        RadioButton(
                            selected = (selectedMethod == method),
                            onClick = { selectedMethod = method },
                            colors = RadioButtonDefaults.colors(selectedColor = ZingGold)
                        )
                        Text(method, color = ZingTextPrimary, fontSize = 13.sp)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Account details input
                OutlinedTextField(
                    value = accountDetails,
                    onValueChange = { accountDetails = it },
                    label = {
                        Text(
                            if (selectedMethod == "UPI") "UPI ID (e.g. name@upi)" else "Account / Email Details",
                            color = ZingTextSecondary
                        )
                    },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ZingTextPrimary,
                        unfocusedTextColor = ZingTextPrimary,
                        focusedBorderColor = ZingGold,
                        unfocusedBorderColor = ZingBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountText.toDoubleOrNull() ?: 5000.0
                    onSubmit(amount, selectedMethod, accountDetails)
                },
                colors = ButtonDefaults.buttonColors(containerColor = ZingGold, contentColor = ZingBlack)
            ) {
                Text("Confirm Payout", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = ZingTextSecondary)
            }
        }
    )
}
