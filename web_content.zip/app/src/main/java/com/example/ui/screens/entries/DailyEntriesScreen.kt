package com.example.ui.screens.entries

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.DeliveryDining
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.DeliveryEntry
import com.example.ui.DeliveryViewModel
import com.example.ui.theme.Cycle1Color
import com.example.ui.theme.Cycle2Color
import com.example.ui.theme.Cycle3Color
import com.example.ui.theme.DexterCyanPrimary
import com.example.ui.theme.DexterEmeraldSecondary
import com.example.ui.theme.DexterSurface
import com.example.ui.theme.DexterSurfaceVariant
import com.example.ui.theme.KamaiGreenGlow

@Composable
fun DailyEntriesScreen(
    viewModel: DeliveryViewModel,
    onAddEntry: () -> Unit,
    onEditEntry: (DeliveryEntry) -> Unit,
    modifier: Modifier = Modifier
) {
    val entries by viewModel.currentMonthEntries.collectAsStateWithLifecycle()
    var selectedCycleFilter by remember { mutableStateOf(0) } // 0 = All, 1 = C1, 2 = C2, 3 = C3

    val filteredEntries = remember(entries, selectedCycleFilter) {
        if (selectedCycleFilter == 0) entries
        else entries.filter { it.cycleNumber == selectedCycleFilter }
    }

    val totalDeliveries = remember(filteredEntries) { filteredEntries.sumOf { it.deliveriesCount } }
    val totalEarnings = remember(filteredEntries) { filteredEntries.sumOf { it.totalEarnings } }

    Box(modifier = modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Filter Chips Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    0 to "All (${entries.size})",
                    1 to "Cycle 1 (1-10)",
                    2 to "Cycle 2 (11-20)",
                    3 to "Cycle 3 (21-31)"
                ).forEach { (filterId, label) ->
                    val isSelected = selectedCycleFilter == filterId
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedCycleFilter = filterId },
                        label = { Text(label, fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = DexterCyanPrimary,
                            selectedLabelColor = Color(0xFF001E2E),
                            containerColor = DexterSurface,
                            labelColor = Color(0xFF94A3B8)
                        ),
                        border = BorderStroke(1.dp, if (isSelected) DexterCyanPrimary else Color(0xFF1E293B))
                    )
                }
            }

            // Subtotal Bar
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                shape = RoundedCornerShape(14.dp),
                color = DexterSurface,
                border = BorderStroke(1.dp, Color(0xFF1E293B))
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Column {
                        Text(
                            text = if (selectedCycleFilter == 0) "All Cycles Subtotal" else "Cycle $selectedCycleFilter Subtotal",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF64748B),
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "$totalDeliveries Deliveries (${filteredEntries.size} Days)",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "TOTAL KAMAI",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF64748B),
                            letterSpacing = 0.5.sp
                        )
                        Text(
                            text = "₹${totalEarnings.toInt()}",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = KamaiGreenGlow
                        )
                    }
                }
            }

            // Entries List
            if (filteredEntries.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.ReceiptLong,
                            contentDescription = null,
                            modifier = Modifier.size(56.dp),
                            tint = Color(0xFF334155)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No deliveries recorded yet",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = Color(0xFF94A3B8)
                        )
                        Text(
                            text = "Tap the + button below to log deliveries",
                            fontSize = 13.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 88.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredEntries, key = { it.id }) { entry ->
                        DeliveryEntryItemCard(
                            entry = entry,
                            onEdit = { onEditEntry(entry) },
                            onDelete = { viewModel.deleteEntry(entry) }
                        )
                    }
                }
            }
        }

        // Floating Action Button
        FloatingActionButton(
            onClick = onAddEntry,
            containerColor = DexterEmeraldSecondary,
            contentColor = Color(0xFF003822),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .testTag("add_entry_fab")
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add Delivery Entry", modifier = Modifier.size(26.dp))
        }
    }
}

@Composable
fun DeliveryEntryItemCard(
    entry: DeliveryEntry,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val cycleColor = when (entry.cycleNumber) {
        1 -> Cycle1Color
        2 -> Cycle2Color
        else -> Cycle3Color
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DexterSurface),
        border = BorderStroke(1.dp, Color(0xFF1E293B)),
        elevation = CardDefaults.cardElevation(2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Leading Date & Cycle Badge
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(cycleColor.copy(alpha = 0.12f))
                    .border(BorderStroke(1.dp, cycleColor.copy(alpha = 0.3f)), RoundedCornerShape(12.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Text(
                    text = "${entry.dayOfMonth}",
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Black,
                    color = cycleColor
                )
                Text(
                    text = "C${entry.cycleNumber}",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = cycleColor
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            // Main Info: Deliveries & Rate
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${entry.deliveriesCount} Deliveries",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color.White
                    )
                    Text(
                        text = "  •  ₹${entry.ratePerDelivery.toInt()}/drop",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF94A3B8)
                    )
                }

                Text(
                    text = entry.dateString,
                    fontSize = 12.sp,
                    color = Color(0xFF64748B)
                )

                if (entry.notes.isNotBlank()) {
                    Text(
                        text = entry.notes,
                        fontSize = 11.sp,
                        color = Color(0xFF94A3B8),
                        maxLines = 1,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }

            // Daily Kamai Amount & Action Buttons
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "₹${entry.totalEarnings.toInt()}",
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Black,
                    color = KamaiGreenGlow
                )

                Row {
                    IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                        Icon(
                            Icons.Default.Edit,
                            contentDescription = "Edit",
                            tint = Color(0xFF94A3B8),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                        Icon(
                            Icons.Default.DeleteOutline,
                            contentDescription = "Delete",
                            tint = Color(0xFFF43F5E),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}
