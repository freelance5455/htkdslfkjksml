package com.example.ui.components.tools

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

// 1. STOP WATCH DIALOG
@Composable
fun StopWatchDialog(onDismiss: () -> Unit) {
    var isRunning by remember { mutableStateOf(false) }
    var timeMillis by remember { mutableLongStateOf(0L) }
    val laps = remember { mutableStateListOf<Long>() }

    LaunchedEffect(isRunning) {
        while (isRunning) {
            delay(10)
            timeMillis += 10
        }
    }

    val minutes = (timeMillis / 60000) % 60
    val seconds = (timeMillis / 1000) % 60
    val centis = (timeMillis % 1000) / 10

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.fillMaxWidth(0.92f).clip(RoundedCornerShape(20.dp)),
            color = Color.White,
            shadowElevation = 8.dp
        ) {
            Column(modifier = Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "⏱️ स्टॉप वॉच (Stop Watch)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Box(
                    modifier = Modifier.size(190.dp).clip(CircleShape).background(Color(0xFFF7F7F7)).border(2.dp, Color.Black, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = String.format(Locale.US, "%02d:%02d.%02d", minutes, seconds, centis),
                        fontSize = 32.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.Black
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { isRunning = !isRunning },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = if (isRunning) Color(0xFFD32F2F) else Color(0xFF2E7D32))
                    ) {
                        Icon(imageVector = if (isRunning) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isRunning) "रोकें (Stop)" else "प्रारंभ (Start)")
                    }

                    OutlinedButton(
                        onClick = {
                            if (isRunning) laps.add(0, timeMillis)
                            else { timeMillis = 0L; laps.clear() }
                        },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(if (isRunning) "लैप (Lap)" else "रीसेट (Reset)", color = Color.Black)
                    }
                }

                if (laps.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    LazyColumn(modifier = Modifier.fillMaxWidth().height(100.dp)) {
                        items(laps.size) { idx ->
                            val lapTime = laps[idx]
                            val lMin = (lapTime / 60000) % 60
                            val lSec = (lapTime / 1000) % 60
                            val lCen = (lapTime % 1000) / 10
                            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(text = "लैप #${laps.size - idx}", fontSize = 11.5.sp, color = Color.Gray)
                                Text(text = String.format(Locale.US, "%02d:%02d.%02d", lMin, lSec, lCen), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                            }
                        }
                    }
                }
            }
        }
    }
}

// 2. COIN TOSS DIALOG (सिक्का उछालें)
@Composable
fun CoinTossDialog(onDismiss: () -> Unit) {
    val coroutineScope = rememberCoroutineScope()
    var resultText by remember { mutableStateOf("सिक्का उछालें") }
    var headsCount by remember { mutableIntStateOf(0) }
    var tailsCount by remember { mutableIntStateOf(0) }
    val rotation = remember { Animatable(0f) }

    fun tossCoin() {
        coroutineScope.launch {
            rotation.animateTo(rotation.value + 720f, animationSpec = tween(600))
            val isHeads = (0..1).random() == 0
            if (isHeads) {
                resultText = "HEADS (चित) 👑"
                headsCount++
            } else {
                resultText = "TAILS (पट) 🪙"
                tailsCount++
            }
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.fillMaxWidth(0.92f).clip(RoundedCornerShape(20.dp)),
            color = Color.White,
            shadowElevation = 8.dp
        ) {
            Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "🪙 सिक्का टॉस (Coin Toss)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Box(
                    modifier = Modifier
                        .size(130.dp)
                        .rotate(rotation.value)
                        .clip(CircleShape)
                        .background(Color(0xFFFFD54F))
                        .border(4.dp, Color(0xFFFFA000), CircleShape)
                        .clickable { tossCoin() },
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = if (resultText.contains("HEADS")) "चित\nHEADS" else if (resultText.contains("TAILS")) "पट\nTAILS" else "टॉस\nTOSS", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, textAlign = TextAlign.Center, color = Color(0xFF5D4037))
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(text = resultText, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.Black)

                Spacer(modifier = Modifier.height(10.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    Text(text = "Heads: $headsCount | Tails: $tailsCount", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color.Gray)
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { tossCoin() },
                    modifier = Modifier.fillMaxWidth().height(44.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Black, contentColor = Color.White)
                ) {
                    Text(text = "सिक्का उछालें (Flip Coin)", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// 3. NUMBER TO WORD DIALOG (संख्या से शब्द)
@Composable
fun NumberToWordDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    var numberStr by remember { mutableStateOf("125000") }

    val num = numberStr.toLongOrNull() ?: 0L
    val wordHindi = convertToIndianWordsHindi(num)
    val wordEnglish = convertToIndianWordsEnglish(num)

    Dialog(onDismissRequest = onDismiss) {
        Surface(modifier = Modifier.fillMaxWidth(0.94f).clip(RoundedCornerShape(20.dp)), color = Color.White, shadowElevation = 8.dp) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "1 ➔ ONE संख्या से शब्द", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = numberStr,
                    onValueChange = { numberStr = it.filter { ch -> ch.isDigit() } },
                    label = { Text("अंक दर्ज करें (Enter Amount / Number)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(14.dp))

                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFFF7F7F7)), shape = RoundedCornerShape(12.dp)) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(text = "🇮🇳 हिंदी (Hindi):", fontSize = 12.sp, color = Color(0xFF666666))
                        Text(text = wordHindi, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.Black)

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(text = "🇬🇧 अंग्रेजी (English):", fontSize = 12.sp, color = Color(0xFF666666))
                        Text(text = wordEnglish, fontWeight = FontWeight.Bold, fontSize = 13.5.sp, color = Color(0xFF1565C0))
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("Number to Words", "$wordHindi\n$wordEnglish"))
                        Toast.makeText(context, "शब्द कॉपी हो गए!", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxWidth().height(42.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Black, contentColor = Color.White)
                ) {
                    Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "कॉपी करें (Copy Words)")
                }
            }
        }
    }
}

fun convertToIndianWordsEnglish(n: Long): String {
    if (n == 0L) return "Zero Rupees Only"
    val units = arrayOf("", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen")
    val tens = arrayOf("", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety")

    fun convertChunk(v: Long): String {
        return if (v < 20) units[v.toInt()]
        else if (v < 100) tens[(v / 10).toInt()] + " " + units[(v % 10).toInt()]
        else units[(v / 100).toInt()] + " Hundred " + convertChunk(v % 100)
    }

    var temp = n
    var result = ""

    val crore = temp / 10000000
    temp %= 10000000
    if (crore > 0) result += convertChunk(crore) + " Crore "

    val lakh = temp / 100000
    temp %= 100000
    if (lakh > 0) result += convertChunk(lakh) + " Lakh "

    val thousand = temp / 1000
    temp %= 1000
    if (thousand > 0) result += convertChunk(thousand) + " Thousand "

    if (temp > 0) result += convertChunk(temp)

    return result.trim() + " Rupees Only"
}

fun convertToIndianWordsHindi(n: Long): String {
    if (n == 0L) return "शून्य रुपये मात्र"
    var temp = n
    var result = ""

    val crore = temp / 10000000
    temp %= 10000000
    if (crore > 0) result += "$crore करोड़ "

    val lakh = temp / 100000
    temp %= 100000
    if (lakh > 0) result += "$lakh लाख "

    val thousand = temp / 1000
    temp %= 1000
    if (thousand > 0) result += "$thousand हज़ार "

    val hundred = temp / 100
    temp %= 100
    if (hundred > 0) result += "$hundred सौ "

    if (temp > 0) result += "$temp "

    return result.trim() + " रुपये मात्र"
}

// 4. BMI CALCULATOR DIALOG
@Composable
fun BmiCalculatorDialog(onDismiss: () -> Unit) {
    var heightCmStr by remember { mutableStateOf("170") }
    var weightKgStr by remember { mutableStateOf("68") }

    val h = (heightCmStr.toDoubleOrNull() ?: 0.0) / 100.0
    val w = weightKgStr.toDoubleOrNull() ?: 0.0
    val bmi = if (h > 0) w / (h * h) else 0.0

    val (bmiStatus, statusColor) = when {
        bmi < 18.5 -> "कम वजन (Underweight)" to Color(0xFF1976D2)
        bmi in 18.5..24.9 -> "सामान्य व स्वस्थ (Normal Weight)" to Color(0xFF2E7D32)
        bmi in 25.0..29.9 -> "अधिक वजन (Overweight)" to Color(0xFFF57F17)
        else -> "मोटापा (Obese)" to Color(0xFFD32F2F)
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(modifier = Modifier.fillMaxWidth(0.92f).clip(RoundedCornerShape(20.dp)), color = Color.White, shadowElevation = 8.dp) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "⚖️ BMI कैलकुलेटर", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = heightCmStr,
                        onValueChange = { heightCmStr = it.filter { ch -> ch.isDigit() } },
                        label = { Text("ऊंचाई (cm)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = weightKgStr,
                        onValueChange = { weightKgStr = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        label = { Text("वजन (kg)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = statusColor.copy(alpha = 0.1f)),
                    border = BorderStroke(1.dp, statusColor),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "आपका BMI स्कोर:", fontSize = 12.sp, color = Color(0xFF555555))
                        Text(text = String.format(Locale.US, "%.1f", bmi), fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = statusColor)
                        Text(text = bmiStatus, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = statusColor)
                    }
                }
            }
        }
    }
}

// 5. PRICE TO WEIGHT & WEIGHT TO PRICE (भाव से वजन व वजन से भाव)
@Composable
fun PriceWeightCalculatorDialog(isPriceToWeight: Boolean, onDismiss: () -> Unit) {
    var ratePerKgStr by remember { mutableStateOf("120") }
    var inputStr by remember { mutableStateOf(if (isPriceToWeight) "50" else "450") }

    val rate = ratePerKgStr.toDoubleOrNull() ?: 0.0
    val input = inputStr.toDoubleOrNull() ?: 0.0

    val result = if (isPriceToWeight) {
        // ₹ input -> grams
        if (rate > 0) (input / rate) * 1000.0 else 0.0
    } else {
        // grams input -> ₹ price
        (input / 1000.0) * rate
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(modifier = Modifier.fillMaxWidth(0.92f).clip(RoundedCornerShape(20.dp)), color = Color.White, shadowElevation = 8.dp) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (isPriceToWeight) "₹ ➔ ⚖️ भाव से वजन (Price to Weight)" else "⚖️ ➔ ₹ वजन से भाव (Weight to Price)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = ratePerKgStr,
                    onValueChange = { ratePerKgStr = it.filter { ch -> ch.isDigit() || ch == '.' } },
                    label = { Text("भाव प्रति किलो (Rate per kg ₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = inputStr,
                    onValueChange = { inputStr = it.filter { ch -> ch.isDigit() || ch == '.' } },
                    label = { Text(if (isPriceToWeight) "रुपये में खरीदें (Enter ₹ Amount)" else "वजन खरीदें (Enter Grams)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(14.dp))

                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)), shape = RoundedCornerShape(12.dp)) {
                    Column(modifier = Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = if (isPriceToWeight) "आपको वजन मिलेगा:" else "कुल देय मूल्य:", fontSize = 12.sp, color = Color(0xFF2E7D32))
                        Text(
                            text = if (isPriceToWeight) String.format(Locale.US, "%.1f ग्राम (%.3f kg)", result, result / 1000.0) else formatInr(result),
                            fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF1B5E20)
                        )
                    }
                }
            }
        }
    }
}

// 6. SIMPLE TALLY COUNTER DIALOG
@Composable
fun TallyCounterDialog(onDismiss: () -> Unit) {
    var count by remember { mutableIntStateOf(0) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(modifier = Modifier.fillMaxWidth(0.92f).clip(RoundedCornerShape(20.dp)), color = Color.White, shadowElevation = 8.dp) {
            Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "🔢 डिजिटल काउंटर (Counter)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Box(
                    modifier = Modifier.size(170.dp).clip(CircleShape).background(Color(0xFFF5F5F5)).border(2.dp, Color.Black, CircleShape).clickable { count++ },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "$count", fontSize = 48.sp, fontWeight = FontWeight.ExtraBold, color = Color.Black)
                        Text(text = "स्पर्श करें (+1)", fontSize = 11.sp, color = Color.Gray)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { if (count > 0) count-- }, shape = RoundedCornerShape(8.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEEEEEE), contentColor = Color.Black)) {
                        Icon(imageVector = Icons.Default.Remove, contentDescription = "Minus")
                    }
                    Button(onClick = { count = 0 }, shape = RoundedCornerShape(8.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEEEEEE), contentColor = Color.Black)) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = "Reset")
                    }
                    Button(onClick = { count++ }, shape = RoundedCornerShape(8.dp), colors = ButtonDefaults.buttonColors(containerColor = Color.Black, contentColor = Color.White)) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Add")
                    }
                }
            }
        }
    }
}
