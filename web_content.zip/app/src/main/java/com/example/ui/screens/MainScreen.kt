package com.example.ui.screens

import android.Manifest
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AmberGlow
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.viewmodel.AppTab
import com.example.ui.viewmodel.PrayerViewModel
import kotlinx.coroutines.launch

@Composable
fun MainScreen(
    viewModel: PrayerViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val currentTab by viewModel.currentTab.collectAsState()
    val themeMode by viewModel.themeMode.collectAsState()
    val selectedCity by viewModel.selectedCity.collectAsState()
    val isUsingGps by viewModel.isUsingGps.collectAsState()
    val selectedMethodId by viewModel.selectedMethodId.collectAsState()

    // Clock and Adhan State
    val currentTimeFormatted by viewModel.currentTimeFormatted.collectAsState()
    val selectedAdhanAlert by viewModel.selectedAdhanAlert.collectAsState()
    val selectedReminderTime by viewModel.selectedReminderTime.collectAsState()
    val isAdhanNotificationEnabled by viewModel.isAdhanNotificationEnabled.collectAsState()
    val isAdhanAudioPlaying by viewModel.isAdhanAudioPlaying.collectAsState()

    // Adhkar State
    val selectedAdhkarCat by viewModel.selectedAdhkarCategory.collectAsState()
    val adhkarMap by viewModel.adhkarMap.collectAsState()
    val currentAdhkarList = adhkarMap[selectedAdhkarCat] ?: emptyList()

    // Tasbeeh State
    val tasbeehCount by viewModel.tasbeehCount.collectAsState()
    val tasbeehTotal by viewModel.tasbeehTotal.collectAsState()
    val tasbeehTarget by viewModel.tasbeehTarget.collectAsState()
    val selectedPhraseIndex by viewModel.selectedPhraseIndex.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    // Back handling: press Back returns to Prayers home tab if on another screen
    BackHandler(enabled = currentTab != AppTab.PRAYERS) {
        viewModel.selectTab(AppTab.PRAYERS)
    }

    // Permission launcher for Location (GPS)
    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true
        val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (fineGranted || coarseGranted) {
            viewModel.requestGpsLocation()
            scope.launch {
                snackbarHostState.showSnackbar("تم تحديد موقعك بدقة عبر الأقمار الصناعية")
            }
        } else {
            scope.launch {
                snackbarHostState.showSnackbar("تعذر الحصول على إذن الموقع، تم الاحتفاظ بالمدينة المحددة")
            }
        }
    }

    // Set RTL layout for Arabic prayer times app
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            modifier = modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding(),
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopNavTabs(
                    currentTab = currentTab,
                    onSelectTab = { viewModel.selectTab(it) },
                    onOpenSettings = { viewModel.selectTab(AppTab.SETTINGS) }
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                Crossfade(targetState = currentTab, label = "tabTransition") { tab ->
                    when (tab) {
                        AppTab.PRAYERS -> {
                            PrayerTimesScreen(
                                uiState = uiState,
                                isUsingGps = isUsingGps,
                                currentTimeFormatted = currentTimeFormatted,
                                onAdjustOffset = { prayerType, delta ->
                                    viewModel.adjustOffset(prayerType, delta)
                                },
                                onRefresh = { viewModel.refreshData() },
                                onGoToSettings = { viewModel.selectTab(AppTab.SETTINGS) },
                                onRequestGps = {
                                    locationPermissionLauncher.launch(
                                        arrayOf(
                                            Manifest.permission.ACCESS_FINE_LOCATION,
                                            Manifest.permission.ACCESS_COARSE_LOCATION
                                        )
                                    )
                                },
                                onNavigateToRamadan = { viewModel.selectTab(AppTab.RAMADAN) }
                            )
                        }

                        AppTab.RAMADAN -> {
                            RamadanCountdownScreen(
                                countdownState = uiState.ramadanCountdown,
                                events = uiState.islamicEvents
                            )
                        }

                        AppTab.ADHKAR -> {
                            AdhkarScreen(
                                selectedCategory = selectedAdhkarCat,
                                adhkarItems = currentAdhkarList,
                                onSelectCategory = { viewModel.selectAdhkarCategory(it) },
                                onDecrementDhikr = { viewModel.decrementDhikr(it) },
                                onResetCategory = { viewModel.resetAdhkarCategory(it) }
                            )
                        }

                        AppTab.TASBEEH -> {
                            TasbeehScreen(
                                currentDhikr = viewModel.currentTasbeehPhrase,
                                count = tasbeehCount,
                                totalCount = tasbeehTotal,
                                target = tasbeehTarget,
                                phrases = viewModel.tasbeehPhrases,
                                selectedPhraseIndex = selectedPhraseIndex,
                                onSelectPhrase = { viewModel.selectTasbeehPhrase(it) },
                                onIncrement = { viewModel.incrementTasbeeh() },
                                onReset = { viewModel.resetTasbeeh() }
                            )
                        }

                        AppTab.QIBLA -> {
                            QiblaScreen(
                                locationName = uiState.locationName,
                                qiblaAngle = uiState.qiblaAngle
                            )
                        }

                        AppTab.SETTINGS -> {
                            SettingsScreen(
                                selectedCity = selectedCity,
                                isUsingGps = isUsingGps,
                                selectedMethodId = selectedMethodId,
                                themeMode = themeMode,
                                supportedCities = viewModel.supportedCities,
                                availableMethods = viewModel.availableMethods,
                                selectedAdhanAlert = selectedAdhanAlert,
                                selectedReminderTime = selectedReminderTime,
                                isAdhanNotificationEnabled = isAdhanNotificationEnabled,
                                isAdhanAudioPlaying = isAdhanAudioPlaying,
                                onSelectCity = { viewModel.selectCity(it) },
                                onRequestGps = {
                                    locationPermissionLauncher.launch(
                                        arrayOf(
                                            Manifest.permission.ACCESS_FINE_LOCATION,
                                            Manifest.permission.ACCESS_COARSE_LOCATION
                                        )
                                    )
                                },
                                onSelectMethod = { viewModel.selectCalculationMethod(it) },
                                onSelectTheme = { viewModel.setTheme(it) },
                                onSelectAdhanAlert = { viewModel.setAdhanAlertType(it) },
                                onSelectReminderTime = { viewModel.setReminderTime(it) },
                                onToggleAdhanNotification = { viewModel.setAdhanNotificationEnabled(it) },
                                onPlayAdhanPreview = { viewModel.playAdhanPreview(it) },
                                onStopAdhanPreview = { viewModel.stopAdhanPreview() },
                                onSaveAdhanSettings = {
                                    viewModel.saveAdhanSettings()
                                    scope.launch {
                                        snackbarHostState.showSnackbar("تم حفظ إعدادات الأذان والتنبيهات بنجاح!")
                                    }
                                },
                                onResetOffsets = {
                                    com.example.data.model.PrayerType.entries.forEach {
                                        viewModel.adjustOffset(it, -viewModel.offsets.value.getOffset(it))
                                    }
                                    scope.launch {
                                        snackbarHostState.showSnackbar("تم تصفير جميع التعديلات")
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TopNavTabs(
    currentTab: AppTab,
    onSelectTab: (AppTab) -> Unit,
    onOpenSettings: () -> Unit
) {
    val scrollState = rememberScrollState()

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.22f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Main 5 tabs matching HTML prototype
            Row(
                modifier = Modifier
                    .weight(1f)
                    .horizontalScroll(scrollState),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf(
                    Triple(AppTab.PRAYERS, "المواقيت", Icons.Default.AccessTime),
                    Triple(AppTab.RAMADAN, "عداد رمضان", Icons.Default.NightsStay),
                    Triple(AppTab.ADHKAR, "الأذكار", Icons.Default.MenuBook),
                    Triple(AppTab.TASBEEH, "المسبحة", Icons.Default.RadioButtonChecked),
                    Triple(AppTab.QIBLA, "القبلة", Icons.Default.Navigation)
                ).forEach { (tab, label, icon) ->
                    val isSelected = currentTab == tab
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (isSelected) {
                                    Brush.linearGradient(
                                        colors = listOf(GoldDark, AmberGlow)
                                    )
                                } else {
                                    Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))
                                }
                            )
                            .clickable { onSelectTab(tab) }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                            .testTag("tab_${tab.name.lowercase()}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                tint = if (isSelected) Color.Black else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = label,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) Color.Black else MaterialTheme.colorScheme.onSurface,
                                maxLines = 1
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.width(4.dp))

            // Settings button
            val isSettingsSelected = currentTab == AppTab.SETTINGS
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(
                        if (isSettingsSelected) AmberGlow else MaterialTheme.colorScheme.background
                    )
                    .clickable { onOpenSettings() }
                    .padding(8.dp)
                    .testTag("btn_settings_tab"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "الإعدادات",
                    tint = if (isSettingsSelected) Color.Black else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(17.dp)
                )
            }
        }
    }
}
