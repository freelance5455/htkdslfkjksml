package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AssignmentInd
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.PasswordProtectionDialog
import com.example.ui.components.SlantedShape
import com.example.ui.components.YmHeader
import com.example.ui.navigation.VaultDestination
import com.example.ui.theme.BlackPure
import com.example.ui.theme.SilverDark
import com.example.ui.theme.SilverLight
import com.example.ui.theme.SilverSurface
import com.example.ui.theme.SilverSurfaceVariant
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@Composable
fun MainScreen(
    onNavigateToSection: (VaultDestination) -> Unit
) {
    // Password Dialog state
    var pendingDestination by remember { mutableStateOf<VaultDestination?>(null) }

    // Smooth upward entrance animations for elements
    val headerAnim = remember { Animatable(200f) }
    val headerAlpha = remember { Animatable(0f) }

    val b1Anim = remember { Animatable(300f) }
    val b1Alpha = remember { Animatable(0f) }

    val b2Anim = remember { Animatable(300f) }
    val b2Alpha = remember { Animatable(0f) }

    val b3Anim = remember { Animatable(350f) }
    val b3Alpha = remember { Animatable(0f) }

    val b4Anim = remember { Animatable(350f) }
    val b4Alpha = remember { Animatable(0f) }

    val b5Anim = remember { Animatable(400f) }
    val b5Alpha = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        val animSpec = tween<Float>(durationMillis = 650, easing = FastOutSlowInEasing)

        launch {
            headerAnim.animateTo(0f, animSpec)
        }
        launch {
            headerAlpha.animateTo(1f, animSpec)
        }

        launch {
            delay(100L)
            b1Anim.animateTo(0f, animSpec)
        }
        launch {
            delay(100L)
            b1Alpha.animateTo(1f, animSpec)
        }

        launch {
            delay(160L)
            b2Anim.animateTo(0f, animSpec)
        }
        launch {
            delay(160L)
            b2Alpha.animateTo(1f, animSpec)
        }

        launch {
            delay(220L)
            b3Anim.animateTo(0f, animSpec)
        }
        launch {
            delay(220L)
            b3Alpha.animateTo(1f, animSpec)
        }

        launch {
            delay(280L)
            b4Anim.animateTo(0f, animSpec)
        }
        launch {
            delay(280L)
            b4Alpha.animateTo(1f, animSpec)
        }

        launch {
            delay(340L)
            b5Anim.animateTo(0f, animSpec)
        }
        launch {
            delay(340L)
            b5Alpha.animateTo(1f, animSpec)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(SilverLight)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // Top / Center Brand Header
            Box(
                modifier = Modifier
                    .offset { IntOffset(0, headerAnim.value.roundToInt()) }
                    .alpha(headerAlpha.value)
            ) {
                YmHeader(largeSize = true)
            }

            Spacer(modifier = Modifier.height(36.dp))

            // 2x2 Grid of Elegant Square Buttons
            // Row 1: Button 1 & Button 2
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                MainSquareButton(
                    title = "File recording",
                    icon = Icons.Default.FolderOpen,
                    testTag = "btn_file_recording",
                    modifier = Modifier
                        .weight(1f)
                        .offset { IntOffset(0, b1Anim.value.roundToInt()) }
                        .alpha(b1Alpha.value),
                    onClick = {
                        pendingDestination = VaultDestination.FileRecording
                    }
                )

                MainSquareButton(
                    title = "Information",
                    icon = Icons.Default.AssignmentInd,
                    testTag = "btn_information",
                    modifier = Modifier
                        .weight(1f)
                        .offset { IntOffset(0, b2Anim.value.roundToInt()) }
                        .alpha(b2Alpha.value),
                    onClick = {
                        pendingDestination = VaultDestination.Information
                    }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Row 2: Button 3 & Button 4
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                MainSquareButton(
                    title = "Create a PDF file",
                    icon = Icons.Default.PictureAsPdf,
                    testTag = "btn_create_pdf",
                    modifier = Modifier
                        .weight(1f)
                        .offset { IntOffset(0, b3Anim.value.roundToInt()) }
                        .alpha(b3Alpha.value),
                    onClick = {
                        pendingDestination = VaultDestination.CreatePdf
                    }
                )

                MainSquareButton(
                    title = "View PDF files",
                    icon = Icons.Default.AutoStories,
                    testTag = "btn_view_pdfs",
                    modifier = Modifier
                        .weight(1f)
                        .offset { IntOffset(0, b4Anim.value.roundToInt()) }
                        .alpha(b4Alpha.value),
                    onClick = {
                        pendingDestination = VaultDestination.ViewPdfs
                    }
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Button 5: Information Storage (wide horizontal rectangle spanning most of the screen width)
            MainWideButton(
                title = "Information Storage",
                icon = Icons.Default.Storage,
                testTag = "btn_information_storage",
                modifier = Modifier
                    .fillMaxWidth()
                    .offset { IntOffset(0, b5Anim.value.roundToInt()) }
                    .alpha(b5Alpha.value),
                onClick = {
                    pendingDestination = VaultDestination.InformationStorage
                }
            )

            Spacer(modifier = Modifier.height(24.dp))
        }

        // Password Dialog when attempting to enter any of the 5 sections
        pendingDestination?.let { targetDest ->
            val sectionName = when (targetDest) {
                VaultDestination.FileRecording -> "File recording"
                VaultDestination.Information -> "Information"
                VaultDestination.CreatePdf -> "Create a PDF file"
                VaultDestination.ViewPdfs -> "View PDF files"
                VaultDestination.InformationStorage -> "Information Storage"
                else -> ""
            }
            PasswordProtectionDialog(
                targetSectionName = sectionName,
                onSuccess = {
                    val dest = targetDest
                    pendingDestination = null
                    onNavigateToSection(dest)
                },
                onDismiss = {
                    pendingDestination = null
                }
            )
        }
    }
}

@Composable
fun MainSquareButton(
    title: String,
    icon: ImageVector,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bgBrush = Brush.verticalGradient(
        colors = listOf(
            SilverSurface,
            SilverSurfaceVariant
        )
    )

    Box(
        modifier = modifier
            .testTag(testTag)
            .aspectRatio(1f)
            .clip(SlantedShape)
            .shadow(elevation = 3.dp, shape = SlantedShape)
            .background(bgBrush)
            .border(BorderStroke(1.5.dp, BlackPure), SlantedShape)
            .clickable { onClick() }
            .padding(14.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Large black icon in the center
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = BlackPure,
                modifier = Modifier.size(44.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Button name in smaller black text underneath the icon
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = BlackPure,
                textAlign = TextAlign.Center,
                lineHeight = 18.sp
            )
        }
    }
}

@Composable
fun MainWideButton(
    title: String,
    icon: ImageVector,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bgBrush = Brush.verticalGradient(
        colors = listOf(
            SilverSurface,
            SilverSurfaceVariant
        )
    )

    Box(
        modifier = modifier
            .testTag(testTag)
            .clip(SlantedShape)
            .shadow(elevation = 3.dp, shape = SlantedShape)
            .background(bgBrush)
            .border(BorderStroke(1.5.dp, BlackPure), SlantedShape)
            .clickable { onClick() }
            .padding(horizontal = 20.dp, vertical = 20.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = BlackPure,
                modifier = Modifier.size(36.dp)
            )

            Spacer(modifier = Modifier.width(14.dp))

            Text(
                text = title,
                style = MaterialTheme.typography.headlineMedium.copy(fontSize = 18.sp),
                fontWeight = FontWeight.Bold,
                color = BlackPure,
                textAlign = TextAlign.Center
            )
        }
    }
}
