package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PersonPin
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.ArkPost
import com.example.data.model.BlockedUser
import com.example.data.model.FollowEdge
import com.example.data.model.FollowRequest
import com.example.data.model.FriendEdge
import com.example.data.model.RestrictedUser
import com.example.data.model.StoryHighlight
import com.example.data.model.UserProfile
import com.example.ui.components.ArkAvatarBadge
import com.example.ui.components.EmptyStateGlassCard
import com.example.ui.components.FeedPostCard
import com.example.ui.components.GlowingPillButton
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.UserBadgeChip
import com.example.ui.theme.ArkThemeTokens

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun UserProfileScreen(
    targetProfile: UserProfile?,
    currentUser: UserProfile,
    posts: List<ArkPost>,
    taggedPosts: List<ArkPost>,
    highlights: List<StoryHighlight>,
    targetFollowers: List<FollowEdge>,
    targetFollowing: List<FollowEdge>,
    myFollowers: List<FollowEdge>,
    myFollowing: List<FollowEdge>,
    myFriends: List<FriendEdge>,
    outgoingFollowRequests: List<FollowRequest>,
    blockedUsers: List<BlockedUser>,
    restrictedUsers: List<RestrictedUser>,
    myReactions: Map<String, String>,
    myPollVotes: Map<String, Int>,
    bookmarkedIds: Set<String>,
    onBack: () -> Unit,
    onFollowOrRequest: (UserProfile) -> Unit,
    onUnfollow: (String, String) -> Unit,
    onCancelFollowRequest: (String) -> Unit,
    onMessageUser: (UserProfile) -> Unit,
    onBlockUser: (String, String) -> Unit,
    onUnblockUser: (String) -> Unit,
    onRestrictUser: (String, String) -> Unit,
    onUnrestrictUser: (String) -> Unit,
    onReportUser: (String, String, String) -> Unit,
    onOpenUserProfile: (String) -> Unit,
    onReaction: (ArkPost, String) -> Unit,
    onOpenComments: (ArkPost) -> Unit,
    onSharePost: (ArkPost) -> Unit,
    onToggleBookmark: (String) -> Unit,
    onVotePoll: (String, Int) -> Unit,
    onOpenMedia: (ArkPost, Int) -> Unit,
    onHashtagClick: (String) -> Unit,
    onOpenLikers: (ArkPost) -> Unit
) {
    BackHandler(onBack = onBack)
    val colors = ArkThemeTokens.colors

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Grid, 1: Posts, 2: Tagged
    var showOverflowMenu by remember { mutableStateOf(false) }
    var activeHighlight by remember { mutableStateOf<StoryHighlight?>(null) }
    var connectionsDialogTab by remember { mutableStateOf<Int?>(null) } // 0: Followers, 1: Following
    var showReportDialog by remember { mutableStateOf(false) }
    var reportReason by remember { mutableStateOf("Harassment or inappropriate content") }

    if (targetProfile == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                CircularProgressIndicator(color = colors.accent)
                TextButton(onClick = onBack) { Text("Back") }
            }
        }
        return
    }

    val isSelf = targetProfile.userId == currentUser.userId
    val isFollowing = remember(myFollowing, targetProfile.userId) {
        myFollowing.any { it.peerUid == targetProfile.userId }
    }
    val followsMe = remember(myFollowers, targetProfile.userId) {
        myFollowers.any { it.peerUid == targetProfile.userId }
    }
    val isFriend = remember(myFriends, targetProfile.userId) {
        myFriends.any { it.friendUid == targetProfile.userId }
    }
    val outgoingReq = remember(outgoingFollowRequests, targetProfile.userId) {
        outgoingFollowRequests.firstOrNull { it.toUid == targetProfile.userId }
    }
    val isBlocked = remember(blockedUsers, targetProfile.userId) {
        blockedUsers.any { it.blockedUid == targetProfile.userId }
    }
    val isRestricted = remember(restrictedUsers, targetProfile.userId) {
        restrictedUsers.any { it.restrictedUid == targetProfile.userId }
    }
    val canViewContent = isSelf || !targetProfile.isPrivateAccount || isFollowing || isFriend

    Column(modifier = Modifier.fillMaxSize()) {
        Surface(color = colors.surface) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("user_profile_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = colors.ink)
                    }
                    Text(
                        text = "@${targetProfile.username}",
                        style = MaterialTheme.typography.titleLarge,
                        color = colors.ink,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (targetProfile.isPrivateAccount) {
                        Spacer(Modifier.width(6.dp))
                        Icon(Icons.Default.Lock, contentDescription = "Private account", tint = colors.ink2, modifier = Modifier.size(16.dp))
                    }
                }

                if (!isSelf) {
                    Box {
                        IconButton(onClick = { showOverflowMenu = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "Account actions", tint = colors.ink)
                        }
                        DropdownMenu(expanded = showOverflowMenu, onDismissRequest = { showOverflowMenu = false }) {
                            DropdownMenuItem(
                                text = { Text(if (isRestricted) "Unrestrict Account" else "Restrict Account") },
                                onClick = {
                                    showOverflowMenu = false
                                    if (isRestricted) onUnrestrictUser(targetProfile.userId)
                                    else onRestrictUser(targetProfile.userId, targetProfile.username)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(if (isBlocked) "Unblock Account" else "Block Account", color = colors.coral) },
                                onClick = {
                                    showOverflowMenu = false
                                    if (isBlocked) onUnblockUser(targetProfile.userId)
                                    else onBlockUser(targetProfile.userId, targetProfile.username)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Report Account", color = colors.coral) },
                                onClick = {
                                    showOverflowMenu = false
                                    showReportDialog = true
                                }
                            )
                        }
                    }
                }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item(key = "up_header") {
                LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ArkAvatarBadge(
                            avatarPreset = targetProfile.avatarPreset,
                            username = targetProfile.username,
                            imageBase64 = targetProfile.avatarImageBase64,
                            size = 76.dp,
                            isOnline = targetProfile.isOnline,
                            showOnlineDot = targetProfile.showOnlineStatus
                        )
                        Spacer(Modifier.width(16.dp))
                        Row(
                            modifier = Modifier.weight(1f),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            ProfileMetricItem(
                                value = maxOf(targetProfile.postsCount, posts.size.toLong()).toString(),
                                label = "Posts",
                                onClick = null
                            )
                            ProfileMetricItem(
                                value = maxOf(targetProfile.followersCount, targetFollowers.size.toLong()).toString(),
                                label = "Followers",
                                onClick = if (canViewContent) {
                                    { connectionsDialogTab = 0 }
                                } else null
                            )
                            ProfileMetricItem(
                                value = maxOf(targetProfile.followingCount, targetFollowing.size.toLong()).toString(),
                                label = "Following",
                                onClick = if (canViewContent) {
                                    { connectionsDialogTab = 1 }
                                } else null
                            )
                        }
                    }

                    Spacer(Modifier.height(12.dp))
                    Text(
                        text = targetProfile.fullName.ifBlank { targetProfile.displayTag },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.ink
                    )
                    Text(
                        text = "LVL ${targetProfile.level} • ${targetProfile.points} PTS",
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.accent
                    )
                    if (targetProfile.bio.isNotBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Text(targetProfile.bio, style = MaterialTheme.typography.bodyMedium, color = colors.ink)
                    }
                    if (targetProfile.website.isNotBlank()) {
                        Spacer(Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Link, contentDescription = null, tint = colors.accent, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(targetProfile.website, style = MaterialTheme.typography.labelMedium, color = colors.accent)
                        }
                    }

                    if (!isSelf && !isBlocked) {
                        Spacer(Modifier.height(14.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            when {
                                isFollowing -> OutlinedButton(
                                    onClick = { onUnfollow(targetProfile.userId, targetProfile.username) },
                                    modifier = Modifier.weight(1f).height(44.dp).testTag("up_following_btn")
                                ) {
                                    Text("Following")
                                }
                                outgoingReq != null -> OutlinedButton(
                                    onClick = { onCancelFollowRequest(outgoingReq.id) },
                                    modifier = Modifier.weight(1f).height(44.dp).testTag("up_requested_btn")
                                ) {
                                    Text("Requested")
                                }
                                else -> GlowingPillButton(
                                    text = when {
                                        targetProfile.isPrivateAccount -> "Request Follow"
                                        followsMe -> "Follow Back"
                                        else -> "Follow"
                                    },
                                    onClick = { onFollowOrRequest(targetProfile) },
                                    modifier = Modifier.weight(1f).height(44.dp).testTag("up_follow_btn")
                                )
                            }

                            OutlinedButton(
                                onClick = { onMessageUser(targetProfile) },
                                modifier = Modifier.weight(1f).height(44.dp).testTag("up_message_btn")
                            ) {
                                Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Message")
                            }
                        }
                    } else if (isBlocked) {
                        Spacer(Modifier.height(12.dp))
                        OutlinedButton(
                            onClick = { onUnblockUser(targetProfile.userId) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Unblock @${targetProfile.username}")
                        }
                    }
                }
            }

            if (isBlocked) {
                item {
                    EmptyStateGlassCard(
                        icon = Icons.Default.Lock,
                        title = "Account Blocked",
                        subtitle = "You have blocked @${targetProfile.username}. Unblock to view or interact."
                    )
                }
            } else if (!canViewContent) {
                item {
                    EmptyStateGlassCard(
                        icon = Icons.Default.Lock,
                        title = "This Account is Private",
                        subtitle = "Follow @${targetProfile.username} to see their posts, highlights, and tagged moments."
                    )
                }
            } else {
                if (highlights.isNotEmpty()) {
                    item(key = "up_highlights") {
                        HighlightsRow(
                            highlights = highlights,
                            isOwnProfile = false,
                            onOpenHighlight = { activeHighlight = it }
                        )
                    }
                }

                if (targetProfile.badges.isNotEmpty()) {
                    item(key = "up_badges") {
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            targetProfile.badges.take(6).forEach { badge ->
                                UserBadgeChip(label = "★ $badge", accent = colors.gold)
                            }
                        }
                    }
                }

                item(key = "up_tabs") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            leadingIcon = { Icon(Icons.Default.GridOn, contentDescription = null, modifier = Modifier.size(16.dp)) },
                            label = { Text("Grid (${posts.size})") }
                        )
                        FilterChip(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            label = { Text("Posts") }
                        )
                        FilterChip(
                            selected = selectedTab == 2,
                            onClick = { selectedTab = 2 },
                            leadingIcon = { Icon(Icons.Default.PersonPin, contentDescription = null, modifier = Modifier.size(16.dp)) },
                            label = { Text("Tagged (${taggedPosts.size})") }
                        )
                    }
                }

                when (selectedTab) {
                    0 -> profileMediaGridItems(
                        posts = posts,
                        colors = colors,
                        onOpenMedia = onOpenMedia,
                        onOpenPostComments = onOpenComments
                    )

                    1 -> if (posts.isEmpty()) {
                        item {
                            EmptyStateGlassCard(
                                icon = Icons.Default.GridOn,
                                title = "No Visible Posts Yet",
                                subtitle = "@${targetProfile.username} hasn't shared visible posts yet."
                            )
                        }
                    } else {
                        items(posts, key = { "up_post_${it.id}" }) { post ->
                            FeedPostCard(
                                post = post,
                                currentUserId = currentUser.userId,
                                myReaction = myReactions[post.id],
                                myPollVote = myPollVotes[post.id],
                                isBookmarked = bookmarkedIds.contains(post.id),
                                onReaction = { react -> onReaction(post, react) },
                                onOpenComments = { onOpenComments(post) },
                                onShare = { onSharePost(post) },
                                onToggleBookmark = { onToggleBookmark(post.id) },
                                onVotePoll = { idx -> onVotePoll(post.id, idx) },
                                onEditCaption = {},
                                onToggleCommentsDisabled = {},
                                onDeletePost = {},
                                onHidePost = {},
                                onMuteAuthor = {},
                                onReportPost = { onReportUser(post.id, "Reported post", "Reported from profile") },
                                onOpenMedia = { page -> onOpenMedia(post, page) },
                                onOpenUserProfile = onOpenUserProfile,
                                onHashtagClick = onHashtagClick,
                                onOpenLikers = { onOpenLikers(post) }
                            )
                        }
                    }

                    else -> profileTaggedItems(
                        taggedPosts = taggedPosts,
                        pendingTags = emptyList(),
                        isOwnProfile = false,
                        colors = colors,
                        onApproveTag = {},
                        onDeclineTag = {},
                        onOpenMedia = onOpenMedia,
                        onOpenComments = onOpenComments
                    )
                }
            }

            item { Spacer(Modifier.height(24.dp)) }
        }
    }

    if (activeHighlight != null) {
        HighlightViewerDialog(
            highlight = activeHighlight!!,
            isOwner = false,
            onRename = {},
            onDelete = {},
            onDismiss = { activeHighlight = null }
        )
    }

    if (connectionsDialogTab != null) {
        FollowConnectionsDialog(
            title = "@${targetProfile.username}",
            initialTab = connectionsDialogTab!!,
            followers = targetFollowers,
            following = targetFollowing,
            currentUser = currentUser,
            myFollowing = myFollowing,
            outgoingFollowRequests = outgoingFollowRequests,
            isOwnProfile = isSelf,
            onOpenUserProfile = { uid ->
                connectionsDialogTab = null
                onOpenUserProfile(uid)
            },
            onFollowEdge = { edge ->
                onFollowOrRequest(
                    UserProfile(
                        userId = edge.peerUid,
                        username = edge.peerUsername,
                        fullName = edge.peerFullName,
                        avatarPreset = edge.peerAvatar,
                        isPrivateAccount = false
                    )
                )
            },
            onUnfollowUser = onUnfollow,
            onCancelFollowRequest = onCancelFollowRequest,
            onRemoveFollower = { _, _ -> },
            onDismiss = { connectionsDialogTab = null }
        )
    }

    if (showReportDialog) {
        AlertDialog(
            onDismissRequest = { showReportDialog = false },
            title = { Text("Report @${targetProfile.username}") },
            text = {
                OutlinedTextField(
                    value = reportReason,
                    onValueChange = { reportReason = it.take(120) },
                    label = { Text("Reason") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    onReportUser(targetProfile.userId, reportReason, "Reported from UserProfileScreen")
                    showReportDialog = false
                }) { Text("Submit Report", color = colors.coral) }
            },
            dismissButton = {
                TextButton(onClick = { showReportDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun ProfileMetricItem(
    value: String,
    label: String,
    onClick: (() -> Unit)?
) {
    val colors = ArkThemeTokens.colors
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = if (onClick != null) {
            Modifier.clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 4.dp)
        } else {
            Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        }
    ) {
        Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = colors.ink)
        Text(label, style = MaterialTheme.typography.labelSmall, color = colors.ink2)
    }
}

@Composable
fun FollowConnectionsDialog(
    title: String,
    initialTab: Int,
    followers: List<FollowEdge>,
    following: List<FollowEdge>,
    currentUser: UserProfile,
    myFollowing: List<FollowEdge>,
    outgoingFollowRequests: List<FollowRequest>,
    isOwnProfile: Boolean,
    onOpenUserProfile: (String) -> Unit,
    onFollowEdge: (FollowEdge) -> Unit,
    onUnfollowUser: (String, String) -> Unit,
    onCancelFollowRequest: (String) -> Unit,
    onRemoveFollower: (String, String) -> Unit,
    onDismiss: () -> Unit
) {
    val colors = ArkThemeTokens.colors
    var selectedTab by remember(initialTab) { mutableIntStateOf(initialTab) }
    var search by remember { mutableStateOf("") }

    val mutuals = remember(followers, myFollowing) {
        val followingSet = myFollowing.map { it.peerUid }.toSet()
        followers.filter { followingSet.contains(it.peerUid) }
    }
    val myFollowingSet = remember(myFollowing) { myFollowing.map { it.peerUid }.toSet() }
    val outgoingByUid = remember(outgoingFollowRequests) { outgoingFollowRequests.associateBy { it.toUid } }

    val activeList = when (selectedTab) {
        0 -> followers
        1 -> following
        else -> mutuals
    }.filter { edge ->
        val q = search.trim().lowercase()
        q.isBlank() || edge.peerUsername.lowercase().contains(q) || edge.peerFullName.lowercase().contains(q)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                TabRow(selectedTabIndex = selectedTab, containerColor = colors.surface) {
                    Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Followers (${followers.size})") })
                    Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Following (${following.size})") })
                    Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Mutual (${mutuals.size})") })
                }
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it.take(30) },
                    placeholder = { Text("Filter username...") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                if (activeList.isEmpty()) {
                    Text("No connections match.", style = MaterialTheme.typography.bodySmall, color = colors.ink2)
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth().heightIn(max = 300.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(activeList, key = { "${selectedTab}_${it.peerUid}" }) { edge ->
                            val isMe = edge.peerUid == currentUser.userId
                            val amFollowing = myFollowingSet.contains(edge.peerUid)
                            val pendingReq = outgoingByUid[edge.peerUid]
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onOpenUserProfile(edge.peerUid) }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    ArkAvatarBadge(avatarPreset = edge.peerAvatar, username = edge.peerUsername, size = 36.dp)
                                    Spacer(Modifier.width(8.dp))
                                    Column {
                                        Text("@${edge.peerUsername}", style = MaterialTheme.typography.titleSmall, color = colors.ink, maxLines = 1)
                                        if (edge.peerFullName.isNotBlank()) {
                                            Text(edge.peerFullName, style = MaterialTheme.typography.labelSmall, color = colors.ink2, maxLines = 1)
                                        }
                                    }
                                }
                                if (!isMe) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        if (isOwnProfile && selectedTab == 0) {
                                            OutlinedButton(
                                                onClick = { onRemoveFollower(edge.peerUid, edge.peerUsername) },
                                                contentPadding = PaddingValues(horizontal = 8.dp)
                                            ) {
                                                Text("Remove", style = MaterialTheme.typography.labelSmall)
                                            }
                                        } else {
                                            when {
                                                amFollowing -> OutlinedButton(
                                                    onClick = { onUnfollowUser(edge.peerUid, edge.peerUsername) },
                                                    contentPadding = PaddingValues(horizontal = 8.dp)
                                                ) { Text("Following", style = MaterialTheme.typography.labelSmall) }
                                                pendingReq != null -> OutlinedButton(
                                                    onClick = { onCancelFollowRequest(pendingReq.id) },
                                                    contentPadding = PaddingValues(horizontal = 8.dp)
                                                ) { Text("Requested", style = MaterialTheme.typography.labelSmall) }
                                                else -> Surface(
                                                    shape = RoundedCornerShape(50),
                                                    color = colors.accent,
                                                    modifier = Modifier.clickable { onFollowEdge(edge) }
                                                ) {
                                                    Text(
                                                        "Follow",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = androidx.compose.ui.graphics.Color.White,
                                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Done") }
        }
    )
}
