package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.SandboxSpec
import com.example.data.model.SandboxWidget
import com.example.util.CodeAuditReport
import com.example.util.SandboxScenarioSnapshot

@Composable
fun IterativeAiRefinementCard(
    isRefining: Boolean,
    onRefineSubmit: (String) -> Unit
) {
    var instruction by remember { mutableStateOf("") }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("iterative_refinement_card"),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.AutoFixHigh,
                    contentDescription = "Iterative AI Refinement",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Iterative AI Project Refinement",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Evolve this app's sandbox widgets, formula, and Kotlin code in-place.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            OutlinedTextField(
                value = instruction,
                onValueChange = { instruction = it },
                enabled = !isRefining,
                placeholder = {
                    Text(
                        text = "e.g., Add a tax percentage slider and a dark/light contrast toggle...",
                        style = MaterialTheme.typography.bodySmall
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("refinement_instruction_input"),
                shape = RoundedCornerShape(10.dp)
            )

            Button(
                onClick = {
                    if (instruction.isNotBlank()) {
                        val submitted = instruction
                        instruction = ""
                        onRefineSubmit(submitted)
                    }
                },
                enabled = !isRefining && instruction.isNotBlank(),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("submit_refinement_button"),
                shape = RoundedCornerShape(10.dp)
            ) {
                if (isRefining) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        color = MaterialTheme.colorScheme.onPrimary,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Refining Sandbox & Kotlin Source...")
                } else {
                    Icon(
                        imageVector = Icons.Default.AutoFixHigh,
                        contentDescription = "Apply AI Refinement",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Apply AI Refinement")
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CustomSandboxWidgetBuilderCard(
    currentSpec: SandboxSpec,
    onAddWidgetAndFormula: (SandboxWidget, String, String, String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    var selectedType by remember { mutableStateOf("SLIDER") }
    var widgetLabel by remember { mutableStateOf("") }
    var widgetSubtitle by remember { mutableStateOf("") }
    var defaultVal by remember { mutableStateOf("25") }
    var minVal by remember { mutableStateOf("0") }
    var maxVal by remember { mutableStateOf("100") }
    var unitVal by remember { mutableStateOf("%") }
    var formulaMode by remember(currentSpec.formulaMode) { mutableStateOf(currentSpec.formulaMode) }
    var formulaLabel by remember(currentSpec.primaryFormulaLabel) { mutableStateOf(currentSpec.primaryFormulaLabel) }
    var formulaUnit by remember(currentSpec.primaryFormulaUnit) { mutableStateOf(currentSpec.primaryFormulaUnit) }

    val widgetTypes = listOf("SLIDER", "NUMBER_INPUT", "TOGGLE", "SEGMENTED", "CHECKLIST", "METRIC_CARD")
    val formulaModes = listOf("MULTIPLY", "ADD", "RATIO", "COMPOUND", "CUSTOM_SCORE")

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("custom_widget_builder_card"),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(
                        imageVector = Icons.Default.AddCircleOutline,
                        contentDescription = "Custom Widget Builder",
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Sandbox Widget & Formula Composer",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Add custom interactive controls or change live formula evaluation.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                Text(
                    text = if (expanded) "Hide" else "Customize",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.testTag("toggle_widget_builder_button")
                )
            }

            if (expanded) {
                Text(
                    text = "Widget Type:",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    widgetTypes.forEach { type ->
                        FilterChip(
                            selected = selectedType == type,
                            onClick = { selectedType = type },
                            label = { Text(type, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                OutlinedTextField(
                    value = widgetLabel,
                    onValueChange = { widgetLabel = it },
                    label = { Text("Control Label") },
                    placeholder = { Text("e.g.,Concurrency Multiplier") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("custom_widget_label_input"),
                    shape = RoundedCornerShape(10.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = defaultVal,
                        onValueChange = { defaultVal = it },
                        label = { Text("Default") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    )
                    OutlinedTextField(
                        value = unitVal,
                        onValueChange = { unitVal = it },
                        label = { Text("Unit") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    )
                }

                if (selectedType == "SLIDER") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = minVal,
                            onValueChange = { minVal = it },
                            label = { Text("Min") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                        OutlinedTextField(
                            value = maxVal,
                            onValueChange = { maxVal = it },
                            label = { Text("Max") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }

                Text(
                    text = "Live Formula Evaluation Mode:",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    formulaModes.forEach { mode ->
                        FilterChip(
                            selected = formulaMode == mode,
                            onClick = { formulaMode = mode },
                            label = { Text(mode, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = formulaLabel,
                        onValueChange = { formulaLabel = it },
                        label = { Text("Output Label") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    )
                    OutlinedTextField(
                        value = formulaUnit,
                        onValueChange = { formulaUnit = it },
                        label = { Text("Output Unit") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    )
                }

                Button(
                    onClick = {
                        val cleanLabel = widgetLabel.trim().ifBlank { "Custom Parameter" }
                        val newWidget = SandboxWidget(
                            id = "custom_${System.currentTimeMillis() % 100000}",
                            type = selectedType,
                            label = cleanLabel,
                            subtitle = widgetSubtitle.trim(),
                            defaultValue = defaultVal.trim().ifBlank { "10" },
                            minValue = minVal.toFloatOrNull() ?: 0f,
                            maxValue = (maxVal.toFloatOrNull() ?: 100f).coerceAtLeast(1f),
                            unit = unitVal.trim(),
                            options = if (selectedType == "SEGMENTED" || selectedType == "CHECKLIST") {
                                listOf("Standard", "High Priority", "Verified")
                            } else {
                                emptyList()
                            }
                        )
                        onAddWidgetAndFormula(newWidget, formulaMode, formulaLabel, formulaUnit)
                        widgetLabel = ""
                        expanded = false
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("add_custom_widget_submit_button"),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Add Control & Update Sandbox Formula")
                }
            }
        }
    }
}

@Composable
fun ScenarioSnapshotsCard(
    snapshots: List<SandboxScenarioSnapshot>,
    currentResult: String,
    currentUnit: String,
    onCaptureSnapshot: (String) -> Unit,
    onRestoreSnapshot: (SandboxScenarioSnapshot) -> Unit,
    onDeleteSnapshot: (String) -> Unit
) {
    var scenarioName by remember { mutableStateOf("") }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("scenario_snapshots_card"),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.BookmarkAdd,
                    contentDescription = "Scenario Snapshots",
                    tint = MaterialTheme.colorScheme.tertiary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Sandbox Scenario Snapshots & Comparison",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Save current slider/toggle states ($currentResult $currentUnit) to compare or restore.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = scenarioName,
                    onValueChange = { scenarioName = it },
                    placeholder = { Text("Scenario label (e.g., Peak Load)", style = MaterialTheme.typography.bodySmall) },
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("snapshot_name_input"),
                    shape = RoundedCornerShape(10.dp)
                )
                Button(
                    onClick = {
                        onCaptureSnapshot(scenarioName.trim())
                        scenarioName = ""
                    },
                    modifier = Modifier.testTag("capture_snapshot_button"),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Capture")
                }
            }

            if (snapshots.isEmpty()) {
                Text(
                    text = "No scenario snapshots captured yet. Adjust controls above and tap Capture to compare configurations.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                snapshots.forEach { snap ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = snap.label,
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Output: ${snap.computedResult} ${snap.unit}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = { onRestoreSnapshot(snap) },
                                modifier = Modifier.testTag("restore_snapshot_${snap.id}")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Restore,
                                    contentDescription = "Restore scenario",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            IconButton(
                                onClick = { onDeleteSnapshot(snap.id) },
                                modifier = Modifier.testTag("delete_snapshot_${snap.id}")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteOutline,
                                    contentDescription = "Delete scenario",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CodeComplianceAuditCard(
    auditReport: CodeAuditReport,
    isRefining: Boolean,
    onAutoHardenClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("code_compliance_audit_card"),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(
                        imageVector = Icons.Default.VerifiedUser,
                        contentDescription = "Architecture Auditor",
                        tint = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Automated Architecture & Layout Audit",
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Surface(
                    color = MaterialTheme.colorScheme.tertiaryContainer,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "${auditReport.readinessScore}% Ready",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            // Metrics summary row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricMiniPill(
                    label = "Lines",
                    value = "${auditReport.lineCount}",
                    modifier = Modifier.weight(1f)
                )
                MetricMiniPill(
                    label = "@Composable",
                    value = "${auditReport.composableCount}",
                    modifier = Modifier.weight(1f)
                )
                MetricMiniPill(
                    label = "State Keys",
                    value = "${auditReport.stateCount}",
                    modifier = Modifier.weight(1f)
                )
            }

            auditReport.checks.forEach { check ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = if (check.passed) Icons.Default.CheckCircle else Icons.Default.WarningAmber,
                        contentDescription = check.title,
                        tint = if (check.passed) {
                            MaterialTheme.colorScheme.tertiary
                        } else {
                            MaterialTheme.colorScheme.error
                        },
                        modifier = Modifier
                            .padding(top = 2.dp)
                            .size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = check.title,
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = check.detail,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            OutlinedButton(
                onClick = onAutoHardenClick,
                enabled = !isRefining,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("ai_harden_code_button"),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.AutoFixHigh,
                    contentDescription = "AI Auto-Harden Code",
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("AI Auto-Harden & Optimize Compose Source")
            }
        }
    }
}

@Composable
private fun MetricMiniPill(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f),
                shape = RoundedCornerShape(10.dp)
            )
            .padding(vertical = 8.dp, horizontal = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
