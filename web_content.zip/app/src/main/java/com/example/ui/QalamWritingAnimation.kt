package com.example.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SufiLanguage
import com.example.ui.theme.CandleGlow
import com.example.ui.theme.ParchmentBase
import com.example.ui.theme.ParchmentBorder
import com.example.ui.theme.ParchmentSurface
import com.example.ui.theme.SufiCharcoal
import com.example.ui.theme.SufiGold
import com.example.ui.theme.SufiGoldBright
import com.example.ui.theme.SufiMaroon
import com.example.ui.theme.SufiMaroonDark
import com.example.ui.theme.SufiMutedText
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Pure 2D Calligraphic Qalam & Parchment Scribbling Animation:
 * Renders an authentic wooden reed pen gliding from left to right across
 * aged parchment lines, scribbling illuminated golden & sepia calligraphy in real-time.
 */
@Composable
fun QalamWritingAnimation(
    language: SufiLanguage,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "qalam_scribble_flow")

    // Continuous progress of the writing animation across lines (0f to 1f)
    val scribbleProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "scribbleProgress"
    )

    // Breathing candlelight glow on parchment
    val candleBreathing by infiniteTransition.animateFloat(
        initialValue = 0.7f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "candleBreathing"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .shadow(12.dp, RoundedCornerShape(24.dp))
            .testTag("qalam_writing_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = ParchmentSurface.copy(alpha = 0.97f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.5.dp, SufiGold.copy(alpha = 0.6f), RoundedCornerShape(24.dp))
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header: Writing title
            Text(
                text = if (language == SufiLanguage.MALAYALAM)
                    "ഖലമുകൊണ്ട് വരികൾ കുറിക്കുന്നു..."
                else
                    "Inscribing wisdom upon parchment...",
                style = MaterialTheme.typography.labelMedium,
                fontFamily = FontFamily.Serif,
                fontStyle = FontStyle.Italic,
                color = SufiMaroon,
                fontSize = 14.sp,
                letterSpacing = 1.2.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Pure 2D Canvas: Parchment + Scribble Lines + Moving Qalam Reed Pen
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(ParchmentBase)
                    .border(1.dp, ParchmentBorder, RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp)
                ) {
                    val w = size.width
                    val h = size.height

                    // 1. Draw aged parchment paper background styling & subtle horizontal guide lines
                    drawParchmentBackground(w, h, candleBreathing)

                    // 2. Define 3 lines of calligraphy paths across the paper from left to right
                    val line1Y = h * 0.28f
                    val line2Y = h * 0.54f
                    val line3Y = h * 0.78f

                    val startX = w * 0.08f
                    val endX = w * 0.88f
                    val lineSpan = endX - startX

                    // Map scribbleProgress (0..1) across the 3 consecutive lines
                    // Line 1: 0.00 -> 0.33
                    // Line 2: 0.33 -> 0.66
                    // Line 3: 0.66 -> 1.00
                    val p = scribbleProgress.coerceIn(0f, 1f)

                    val activeLineIndex: Int
                    val lineProgress: Float

                    when {
                        p < 0.333f -> {
                            activeLineIndex = 0
                            lineProgress = (p / 0.333f).coerceIn(0f, 1f)
                        }
                        p < 0.666f -> {
                            activeLineIndex = 1
                            lineProgress = ((p - 0.333f) / 0.333f).coerceIn(0f, 1f)
                        }
                        else -> {
                            activeLineIndex = 2
                            lineProgress = ((p - 0.666f) / 0.334f).coerceIn(0f, 1f)
                        }
                    }

                    // Draw completed and currently written ink strokes
                    for (lineIdx in 0..2) {
                        val currentY = when (lineIdx) {
                            0 -> line1Y
                            1 -> line2Y
                            else -> line3Y
                        }

                        val progressForThisLine = when {
                            lineIdx < activeLineIndex -> 1.0f
                            lineIdx == activeLineIndex -> lineProgress
                            else -> 0.0f
                        }

                        if (progressForThisLine > 0f) {
                            drawCalligraphyScribble(
                                startX = startX,
                                endX = endX,
                                baselineY = currentY,
                                progress = progressForThisLine,
                                lineSeed = lineIdx
                            )
                        }
                    }

                    // 3. Compute active Nib (Pen Tip) coordinate
                    val currentBaseY = when (activeLineIndex) {
                        0 -> line1Y
                        1 -> line2Y
                        else -> line3Y
                    }
                    val currentNibX = startX + lineSpan * lineProgress
                    val nibYOffset = sin(lineProgress * 18 * PI.toFloat()) * 8f
                    val nibTipPos = Offset(currentNibX, currentBaseY + nibYOffset)

                    // 4. Golden ink shimmer & fairy dust particle halo around nib
                    drawNibGlow(nibTipPos, candleBreathing)

                    // 5. Draw the 2D Qalam (Reed Pen) angled gracefully on the paper
                    draw2DQalamPen(nibTipPos, lineProgress)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Subtitle indicating the contemplative writing
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = if (language == SufiLanguage.MALAYALAM)
                        "റൂമിയുടെ കാലത്തെഴുതിയ തൂലികയാൽ..."
                    else
                        "Written with the ancient reed pen of Rumi's era...",
                    style = MaterialTheme.typography.bodySmall,
                    color = SufiMutedText,
                    fontSize = 12.sp,
                    fontStyle = FontStyle.Italic
                )
            }
        }
    }
}

/**
 * Draws vintage parchment background guidelines and subtle corner ornaments
 */
private fun DrawScope.drawParchmentBackground(w: Float, h: Float, candleFactor: Float) {
    // Warm radial candlelight vignette
    drawRect(
        brush = Brush.radialGradient(
            colors = listOf(
                CandleGlow.copy(alpha = 0.18f * candleFactor),
                Color.Transparent
            ),
            center = Offset(w * 0.5f, h * 0.45f),
            radius = w * 0.65f
        )
    )

    // Faint vintage calligraphy guidelines
    val lineYs = listOf(h * 0.28f, h * 0.54f, h * 0.78f)
    for (ly in lineYs) {
        drawLine(
            color = SufiGold.copy(alpha = 0.16f),
            start = Offset(w * 0.06f, ly + 6f),
            end = Offset(w * 0.94f, ly + 6f),
            strokeWidth = 1.dp.toPx(),
            cap = StrokeCap.Round
        )
    }

    // Vintage decorative corner borders
    val borderInset = 8.dp.toPx()
    val cornerLen = 14.dp.toPx()
    val cornerColor = SufiGold.copy(alpha = 0.35f)
    val cornerWidth = 1.2.dp.toPx()

    // Top-Left
    drawLine(cornerColor, Offset(borderInset, borderInset), Offset(borderInset + cornerLen, borderInset), cornerWidth)
    drawLine(cornerColor, Offset(borderInset, borderInset), Offset(borderInset, borderInset + cornerLen), cornerWidth)

    // Top-Right
    drawLine(cornerColor, Offset(w - borderInset, borderInset), Offset(w - borderInset - cornerLen, borderInset), cornerWidth)
    drawLine(cornerColor, Offset(w - borderInset, borderInset), Offset(w - borderInset, borderInset + cornerLen), cornerWidth)

    // Bottom-Left
    drawLine(cornerColor, Offset(borderInset, h - borderInset), Offset(borderInset + cornerLen, h - borderInset), cornerWidth)
    drawLine(cornerColor, Offset(borderInset, h - borderInset), Offset(borderInset, h - borderInset - cornerLen), cornerWidth)

    // Bottom-Right
    drawLine(cornerColor, Offset(w - borderInset, h - borderInset), Offset(w - borderInset - cornerLen, h - borderInset), cornerWidth)
    drawLine(cornerColor, Offset(w - borderInset, h - borderInset), Offset(w - borderInset, h - borderInset - cornerLen), cornerWidth)
}

/**
 * Draws flowing cursive calligraphic ink loops and strokes across a line
 */
private fun DrawScope.drawCalligraphyScribble(
    startX: Float,
    endX: Float,
    baselineY: Float,
    progress: Float,
    lineSeed: Int
) {
    val totalWidth = (endX - startX) * progress
    if (totalWidth <= 0f) return

    val numSegments = 12
    val segmentWidth = (endX - startX) / numSegments

    val inkPath = Path()
    inkPath.moveTo(startX, baselineY)

    var currentX = startX
    var i = 0

    while (currentX < startX + totalWidth && i < numSegments) {
        val segProg = ((startX + totalWidth - currentX) / segmentWidth).coerceIn(0f, 1f)
        val x1 = currentX + segmentWidth * 0.3f * segProg
        val x2 = currentX + segmentWidth * 0.7f * segProg
        val x3 = currentX + segmentWidth * segProg

        // Distinct rhythmic loops per line index
        val amp1 = if ((i + lineSeed) % 2 == 0) -14f else 8f
        val amp2 = if ((i + lineSeed) % 3 == 0) 12f else -10f

        val y1 = baselineY + amp1
        val y2 = baselineY + amp2
        val y3 = baselineY + sin(i * 1.5f + lineSeed) * 4f

        inkPath.cubicTo(x1, y1, x2, y2, x3, y3)
        currentX += segmentWidth
        i++
    }

    // Outer rich golden glowing ink stroke
    drawPath(
        path = inkPath,
        color = SufiGoldBright,
        style = Stroke(
            width = 3.5.dp.toPx(),
            cap = StrokeCap.Round,
            join = StrokeJoin.Round
        )
    )

    // Inner deep Persian sepia ink core
    drawPath(
        path = inkPath,
        color = SufiMaroonDark,
        style = Stroke(
            width = 2.0.dp.toPx(),
            cap = StrokeCap.Round,
            join = StrokeJoin.Round
        )
    )
}

/**
 * Draws the glistening halo and ink sparkles around the active Qalam nib
 */
private fun DrawScope.drawNibGlow(nibTip: Offset, candleFactor: Float) {
    // Radiant halo
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                CandleGlow.copy(alpha = 0.75f * candleFactor),
                SufiGoldBright.copy(alpha = 0.45f * candleFactor),
                Color.Transparent
            ),
            center = nibTip,
            radius = 16.dp.toPx()
        ),
        radius = 16.dp.toPx(),
        center = nibTip
    )

    // Glint core
    drawCircle(
        color = SufiGoldBright,
        radius = 3.dp.toPx(),
        center = nibTip
    )

    // Trailing golden fairy dust sparkles
    drawCircle(
        color = SufiGold.copy(alpha = 0.7f),
        radius = 1.5.dp.toPx(),
        center = Offset(nibTip.x - 8.dp.toPx(), nibTip.y + 4.dp.toPx())
    )
    drawCircle(
        color = SufiGold.copy(alpha = 0.5f),
        radius = 1.2.dp.toPx(),
        center = Offset(nibTip.x - 14.dp.toPx(), nibTip.y - 6.dp.toPx())
    )
}

/**
 * Draws an authentic 2D Bamboo/Wood Qalam (Reed Pen) angled at 40 degrees
 */
private fun DrawScope.draw2DQalamPen(nibTip: Offset, lineProgress: Float) {
    // Subtle calligraphic wrist tilt oscillation
    val tiltAngle = 38f + sin(lineProgress * 24 * PI.toFloat()) * 4f

    rotate(degrees = tiltAngle, pivot = nibTip) {
        val penLength = 55.dp.toPx()
        val shaftWidth = 7.dp.toPx()
        val nibLength = 16.dp.toPx()

        // 1. Nib: Tapered metal/reed cut tip
        val nibPath = Path().apply {
            moveTo(nibTip.x, nibTip.y)
            lineTo(nibTip.x - shaftWidth * 0.45f, nibTip.y - nibLength)
            lineTo(nibTip.x + shaftWidth * 0.45f, nibTip.y - nibLength)
            close()
        }
        drawPath(
            path = nibPath,
            brush = Brush.verticalGradient(
                colors = listOf(SufiGoldBright, SufiMaroonDark),
                startY = nibTip.y - nibLength,
                endY = nibTip.y
            )
        )

        // Nib ink slit line
        drawLine(
            color = SufiCharcoal,
            start = Offset(nibTip.x, nibTip.y),
            end = Offset(nibTip.x, nibTip.y - nibLength * 0.65f),
            strokeWidth = 1.dp.toPx(),
            cap = StrokeCap.Round
        )

        // 2. Brass Ferrule Collar Ring
        val collarTopY = nibTip.y - nibLength - 4.dp.toPx()
        drawRect(
            color = SufiGold,
            topLeft = Offset(nibTip.x - shaftWidth * 0.55f, collarTopY),
            size = androidx.compose.ui.geometry.Size(shaftWidth * 1.1f, 4.dp.toPx())
        )

        // 3. Wooden Reed Pen Shaft (Aged bamboo/rosewood gradient)
        val shaftTopY = collarTopY - penLength
        val shaftRect = androidx.compose.ui.geometry.Rect(
            left = nibTip.x - shaftWidth * 0.5f,
            top = shaftTopY,
            right = nibTip.x + shaftWidth * 0.5f,
            bottom = collarTopY
        )

        drawRoundRect(
            brush = Brush.horizontalGradient(
                colors = listOf(
                    Color(0xFF8D5B28), // Bamboo wood shadow
                    Color(0xFFC68B59), // Bamboo wood highlight
                    Color(0xFF6E411B)  // Bamboo deep wood tone
                ),
                startX = shaftRect.left,
                endX = shaftRect.right
            ),
            topLeft = Offset(shaftRect.left, shaftRect.top),
            size = androidx.compose.ui.geometry.Size(shaftRect.width, shaftRect.height),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(4.dp.toPx(), 4.dp.toPx())
        )

        // Reed bamboo segment nodes
        val node1Y = collarTopY - penLength * 0.45f
        val node2Y = collarTopY - penLength * 0.85f
        drawLine(
            color = Color(0xFF4A2A0C),
            start = Offset(shaftRect.left, node1Y),
            end = Offset(shaftRect.right, node1Y),
            strokeWidth = 1.5.dp.toPx()
        )
        drawLine(
            color = Color(0xFF4A2A0C),
            start = Offset(shaftRect.left, node2Y),
            end = Offset(shaftRect.right, node2Y),
            strokeWidth = 1.5.dp.toPx()
        )
    }
}
