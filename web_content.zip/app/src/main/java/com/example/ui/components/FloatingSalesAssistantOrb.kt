package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Face3
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.example.data.model.SalesAssistantPersona
import com.example.util.LoginPersonaPrefs
import kotlin.math.PI
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Floating Circular AI Salesperson on the side of the screen:
 * 1. Before "OK" is clicked (or when user opens settings): shows the rectangular selection bar to pick Male or Female + Local Language, followed by an "OK" button.
 * 2. After "OK" is clicked: the rectangular bar is completely CLOSED, and ONLY the small circle on the side remains visible, speaking with animated wave lines inside the circle!
 */
@Composable
fun FloatingSalesAssistantOrb(
    userGender: String,
    preferredLanguage: String,
    persona: SalesAssistantPersona,
    currentPitchText: String,
    currentActionLabel: String,
    isSpeaking: Boolean,
    isVoiceMuted: Boolean,
    isRectangleSelectorOpen: Boolean,
    onConfirmOkAndCloseRectangle: (String, String) -> Unit,
    onOpenSelectorRectangle: () -> Unit,
    onExecuteSalesmanDirection: () -> Unit,
    onReplayPitch: () -> Unit,
    onToggleMute: () -> Unit,
    onChangeGenderAndLanguage: (String, String) -> Unit,
    onAskSalesmanQuestion: (String) -> Unit,
    onQuickDirectToDeals: () -> Unit,
    onQuickDirectToTryOn: () -> Unit,
    onQuickDirectToCompare: () -> Unit,
    onQuickDirectToWedding: () -> Unit
) {
    var verticalDragOffsetPx by remember { mutableFloatStateOf(0f) }
    var tempGender by rememberSaveable(userGender) { mutableStateOf(userGender) }
    var tempLanguage by rememberSaveable(preferredLanguage) { mutableStateOf(preferredLanguage) }

    val isFemaleAssistant = persona.assistantGender == "FEMALE"
    val primaryWaveColor = if (isFemaleAssistant) Color(0xFF38BDF8) else Color(0xFFF59E0B)
    val secondaryWaveColor = if (isFemaleAssistant) Color(0xFFF43F5E) else Color(0xFF10B981)

    val infiniteTransition = rememberInfiniteTransition(label = "circle_wave_transition")
    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isSpeaking) 550 else 1800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_phase"
    )
    val waveAmplitude by infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = if (isSpeaking) 1.0f else 0.32f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isSpeaking) 320 else 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "wave_amplitude"
    )
    val outerGlowScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (isSpeaking) 1.24f else 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isSpeaking) 450 else 1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "outer_glow_scale"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(end = 12.dp, bottom = 88.dp),
        contentAlignment = Alignment.CenterEnd
    ) {
        Row(
            modifier = Modifier
                .offset { IntOffset(0, verticalDragOffsetPx.roundToInt().coerceIn(-360, 320)) },
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.End
        ) {
            // RECTANGLE BAR: Only visible BEFORE clicking OK (closes completely after clicking OK!)
            AnimatedVisibility(
                visible = isRectangleSelectorOpen,
                enter = fadeIn() + scaleIn(),
                exit = fadeOut() + scaleOut()
            ) {
                Card(
                    modifier = Modifier
                        .widthIn(max = 290.dp)
                        .padding(end = 10.dp)
                        .testTag("gender_rectangle_bar"),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.98f)
                    ),
                    border = BorderStroke(1.5.dp, primaryWaveColor),
                    elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Choose Gender & Local Language",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                selected = tempGender == "MALE",
                                onClick = { tempGender = "MALE" },
                                label = {
                                    Text(
                                        text = "Male (Ananya AI)",
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Face3,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFF38BDF8).copy(alpha = 0.22f),
                                    selectedLabelColor = Color(0xFF38BDF8)
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("rect_select_male")
                            )

                            FilterChip(
                                selected = tempGender == "FEMALE",
                                onClick = { tempGender = "FEMALE" },
                                label = {
                                    Text(
                                        text = "Female (Kabir AI)",
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Face,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFFF59E0B).copy(alpha = 0.22f),
                                    selectedLabelColor = Color(0xFFF59E0B)
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("rect_select_female")
                            )
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            LoginPersonaPrefs.supportedLanguages.forEach { lang ->
                                FilterChip(
                                    selected = tempLanguage == lang,
                                    onClick = { tempLanguage = lang },
                                    label = {
                                        Text(
                                            text = lang,
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    }
                                )
                            }
                        }

                        // OK BUTTON: Closes the rectangle bar and makes ONLY the circle speak in the wave line!
                        Button(
                            onClick = {
                                onConfirmOkAndCloseRectangle(tempGender, tempLanguage)
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (tempGender == "MALE") Color(0xFF38BDF8) else Color(0xFFF59E0B),
                                contentColor = Color(0xFF090A0F)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(42.dp)
                                .testTag("gender_ok_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "OK",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }
            }

            // ONLY THE SMALL CIRCLE ON THE SIDE WITH WAVE LINE INSIDE THE CIRCLE
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .pointerInput(Unit) {
                        detectVerticalDragGestures { change, dragAmount ->
                            change.consume()
                            verticalDragOffsetPx = (verticalDragOffsetPx + dragAmount).coerceIn(-360f, 320f)
                        }
                    }
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(72.dp)
                        .testTag("floating_ai_sales_assistant_orb")
                        .clickable {
                            // Tapping the circle makes it speak & direct the user with the wave line inside the circle
                            onReplayPitch()
                            onExecuteSalesmanDirection()
                        }
                ) {
                    // Outer subtle aura ring
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val centerOffset = Offset(size.width / 2f, size.height / 2f)
                        val baseRadius = size.minDimension / 2f - 4.dp.toPx()
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    primaryWaveColor.copy(alpha = if (isSpeaking) 0.55f else 0.22f),
                                    secondaryWaveColor.copy(alpha = 0.0f)
                                ),
                                center = centerOffset,
                                radius = baseRadius * outerGlowScale
                            ),
                            radius = baseRadius * outerGlowScale,
                            center = centerOffset
                        )
                    }

                    // The Circle itself with Animated Voice Wave Lines Inside the Circle
                    Surface(
                        modifier = Modifier.size(62.dp),
                        shape = CircleShape,
                        color = Color(0xFF0B0E17),
                        border = BorderStroke(
                            width = if (isSpeaking) 2.6.dp else 2.dp,
                            brush = Brush.sweepGradient(
                                listOf(primaryWaveColor, secondaryWaveColor, primaryWaveColor)
                            )
                        ),
                        shadowElevation = 12.dp
                    ) {
                        CircleWaveLineCanvas(
                            isFemaleAssistant = isFemaleAssistant,
                            isSpeaking = isSpeaking,
                            wavePhase = wavePhase,
                            waveAmplitude = waveAmplitude,
                            primaryColor = primaryWaveColor,
                            secondaryColor = secondaryWaveColor
                        )
                    }

                    // Tiny button on corner of circle to re-open the gender/language selector if needed
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E293B))
                            .clickable { onOpenSelectorRectangle() }
                            .testTag("reopen_gender_selector_btn"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "Change Gender or Language",
                            tint = primaryWaveColor,
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Renders the animated AI Voice Wave Line inside the circle:
 * - Draws flowing sinusoidal voice wave lines + equalizer wave bars inside the circular orb.
 * - Distinct color signature: Cyan-Rose AI wave for Female AI Saleswoman (Ananya) and Gold-Emerald AI wave for Male AI Salesman (Kabir).
 */
@Composable
fun CircleWaveLineCanvas(
    isFemaleAssistant: Boolean,
    isSpeaking: Boolean,
    wavePhase: Float,
    waveAmplitude: Float,
    primaryColor: Color,
    secondaryColor: Color,
    modifier: Modifier = Modifier.fillMaxSize()
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val cy = h / 2f

        // Deep radial core inside the circle
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(
                    primaryColor.copy(alpha = if (isSpeaking) 0.30f else 0.14f),
                    Color(0xFF090B12)
                ),
                center = Offset(cx, cy),
                radius = w * 0.6f
            )
        )

        // Subtle gender-coded AI core glow dot at top of circle (Crimson/Cyan bindi glow for Ananya, Gold crest for Kabir)
        drawCircle(
            color = if (isFemaleAssistant) Color(0xFFF43F5E) else Color(0xFFF59E0B),
            radius = w * 0.045f,
            center = Offset(cx, h * 0.22f)
        )

        // 1. Secondary background harmonic wave line inside the circle
        val secondaryWavePath = Path()
        val steps = 40
        val startX = w * 0.10f
        val endX = w * 0.90f
        val spanWidth = endX - startX
        val maxAmpSecondary = if (isSpeaking) (h * 0.22f * waveAmplitude) else (h * 0.05f)

        for (i in 0..steps) {
            val fraction = i.toFloat() / steps.toFloat()
            val x = startX + fraction * spanWidth
            // Envelope tapers at circle left/right edges so wave stays cleanly inside the circle
            val envelope = sin(fraction * PI).toFloat()
            val y = cy + sin(fraction * 3f * PI - wavePhase * 1.3f).toFloat() * maxAmpSecondary * envelope
            if (i == 0) {
                secondaryWavePath.moveTo(x, y)
            } else {
                secondaryWavePath.lineTo(x, y)
            }
        }
        drawPath(
            path = secondaryWavePath,
            color = secondaryColor.copy(alpha = if (isSpeaking) 0.75f else 0.40f),
            style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
        )

        // 2. Primary glowing AI voice wave line across the center of the circle
        val primaryWavePath = Path()
        val maxAmpPrimary = if (isSpeaking) (h * 0.30f * waveAmplitude) else (h * 0.08f)

        for (i in 0..steps) {
            val fraction = i.toFloat() / steps.toFloat()
            val x = startX + fraction * spanWidth
            val envelope = sin(fraction * PI).toFloat()
            val y = cy + sin(fraction * 2.5f * PI + wavePhase).toFloat() * maxAmpPrimary * envelope
            if (i == 0) {
                primaryWavePath.moveTo(x, y)
            } else {
                primaryWavePath.lineTo(x, y)
            }
        }
        drawPath(
            path = primaryWavePath,
            brush = Brush.horizontalGradient(
                colors = listOf(primaryColor, secondaryColor, primaryColor)
            ),
            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
        )

        // 3. Vertical reactive voice wave bars along the center axis inside the circle
        val barCount = 7
        val totalBarsWidth = w * 0.56f
        val barStartX = (w - totalBarsWidth) / 2f
        val barSpacing = totalBarsWidth / (barCount - 1)

        for (idx in 0 until barCount) {
            val distFromCenter = 1f - (kotlin.math.abs(idx - (barCount / 2)).toFloat() / (barCount / 2 + 1))
            val dynamicFactor = kotlin.math.abs(sin(wavePhase + idx * 0.75f)).toFloat()
            val barHeight = if (isSpeaking) {
                (h * 0.10f + h * 0.42f * dynamicFactor * distFromCenter * waveAmplitude)
            } else {
                h * 0.08f * distFromCenter
            }
            val bx = barStartX + idx * barSpacing
            drawRoundRect(
                color = primaryColor.copy(alpha = if (isSpeaking) 0.9f else 0.5f),
                topLeft = Offset(bx - 1.5.dp.toPx(), cy - barHeight / 2f),
                size = Size(3.dp.toPx(), barHeight),
                cornerRadius = CornerRadius(4f, 4f)
            )
        }
    }
}
