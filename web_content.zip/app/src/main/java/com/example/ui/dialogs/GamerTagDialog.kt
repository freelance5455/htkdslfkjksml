package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

@Composable
fun GamerTagDialog(
    initialGamerTag: String,
    onConfirm: (String) -> Unit
) {
    var text by remember { mutableStateOf(initialGamerTag) }
    var showError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = { /* Obligatorio en primer uso */ },
        containerColor = Color(0xFF1C2028),
        shape = RoundedCornerShape(16.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = "🎮 ", fontSize = 20.sp)
                Text(
                    text = "GamerTag de Minecraft",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = Color(0xFFFFB703)
                )
            }
        },
        text = {
            Column {
                Text(
                    text = "Ingresa tu GamerTag real de Minecraft para reconocerte en el chat de voz y cargar tu skin:",
                    fontSize = 13.sp,
                    color = Color(0xFFA0AEC0)
                )

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val previewTag = if (text.isNotBlank()) text.trim() else "Steve"
                    AsyncImage(
                        model = "https://minotar.net/avatar/$previewTag/64.png",
                        contentDescription = "Skin preview",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .border(1.dp, Color(0xFFFFB703), RoundedCornerShape(6.dp))
                    )

                    Spacer(modifier = Modifier.width(12.dp))

                    OutlinedTextField(
                        value = text,
                        onValueChange = {
                            text = it
                            showError = false
                        },
                        placeholder = { Text("ej: Juansito, Alex...", fontSize = 13.sp) },
                        singleLine = true,
                        isError = showError,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFFFB703),
                            unfocusedBorderColor = Color(0xFF333A47),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("gamertag_input_field")
                    )
                }

                if (showError) {
                    Text(
                        text = "El GamerTag no puede estar vacío.",
                        color = Color(0xFFE74C3C),
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (text.isNotBlank()) {
                        onConfirm(text.trim())
                    } else {
                        showError = true
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB703)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("btn_confirm_gamertag")
            ) {
                Text("Entrar al Servidor", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    )
}
