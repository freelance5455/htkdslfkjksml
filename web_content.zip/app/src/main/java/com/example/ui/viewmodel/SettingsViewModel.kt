package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.MediaSource
import com.example.data.model.SyncDocuments
import com.example.data.preferences.UserPreferences
import com.example.data.preferences.UserPreferencesRepository
import com.example.data.repository.GoogleDriveSyncRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SettingsUiState(
    val isSyncing: Boolean = false,
    val syncSuccess: Boolean = false,
    val lastSyncDocs: SyncDocuments? = null,
    val selectedDocPreview: String = "History.txt",
    val activeDocContent: String = "",
    val isDocViewerOpen: Boolean = false,
    val isCaptchaWebViewOpen: Boolean = false,
    val captchaTargetUrl: String = "https://e621.net",
    val statusBanner: String? = null
)

class SettingsViewModel(
    private val preferencesRepository: UserPreferencesRepository,
    private val googleDriveSyncRepository: GoogleDriveSyncRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    val userPreferences: StateFlow<UserPreferences> = preferencesRepository.userPreferencesFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = UserPreferences()
        )

    fun syncGoogleDrive(email: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isSyncing = true, statusBanner = "Connecting to Google Drive...")
            val result = googleDriveSyncRepository.performGoogleAccountSync(email)
            result.onSuccess { docs ->
                _uiState.value = _uiState.value.copy(
                    isSyncing = false,
                    syncSuccess = true,
                    lastSyncDocs = docs,
                    statusBanner = "Successfully synced 4 text files to Google Drive!"
                )
            }.onFailure { err ->
                _uiState.value = _uiState.value.copy(
                    isSyncing = false,
                    syncSuccess = false,
                    statusBanner = "Sync failed: ${err.localizedMessage}"
                )
            }
        }
    }

    fun viewDocument(docName: String) {
        viewModelScope.launch {
            val content = googleDriveSyncRepository.readDocumentContent(docName)
            _uiState.value = _uiState.value.copy(
                selectedDocPreview = docName,
                activeDocContent = content,
                isDocViewerOpen = true
            )
        }
    }

    fun closeDocViewer() {
        _uiState.value = _uiState.value.copy(isDocViewerOpen = false)
    }

    fun openCaptchaWebView(url: String) {
        _uiState.value = _uiState.value.copy(
            isCaptchaWebViewOpen = true,
            captchaTargetUrl = url
        )
    }

    fun closeCaptchaWebView() {
        _uiState.value = _uiState.value.copy(isCaptchaWebViewOpen = false)
    }

    fun saveApiKeys(
        e621Login: String,
        e621ApiKey: String,
        rule34ApiKey: String,
        redditClientId: String,
        redditClientSecret: String,
        blueskyHandle: String,
        blueskyAppPassword: String,
        twitterBearerToken: String
    ) {
        viewModelScope.launch {
            preferencesRepository.saveApiKeys(
                e621Login = e621Login,
                e621ApiKey = e621ApiKey,
                rule34ApiKey = rule34ApiKey,
                redditClientId = redditClientId,
                redditClientSecret = redditClientSecret,
                blueskyHandle = blueskyHandle,
                blueskyAppPassword = blueskyAppPassword,
                twitterBearerToken = twitterBearerToken
            )
            _uiState.value = _uiState.value.copy(statusBanner = "API credentials saved securely!")
        }
    }

    fun updateUiScale(scale: Float) {
        viewModelScope.launch {
            preferencesRepository.setUiScale(scale)
        }
    }

    fun updateDownloadFolder(path: String) {
        viewModelScope.launch {
            preferencesRepository.setDownloadFolder(path)
            _uiState.value = _uiState.value.copy(statusBanner = "Download location updated to $path")
        }
    }

    fun setGenderFilter(filter: com.example.data.model.GenderFilter) {
        viewModelScope.launch {
            preferencesRepository.setGenderFilter(filter)
            _uiState.value = _uiState.value.copy(statusBanner = "Gender filter set to ${filter.label}")
        }
    }

    fun toggleMalesOnly(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setMalesOnly(enabled)
        }
    }

    fun saveSourceQueryConfigs(redditSubs: String, e621Tags: String, r34Tags: String, phQuery: String) {
        viewModelScope.launch {
            preferencesRepository.saveSourceQueryConfigs(redditSubs, e621Tags, r34Tags, phQuery)
            _uiState.value = _uiState.value.copy(statusBanner = "Source search configurations updated!")
        }
    }

    fun clearBanner() {
        _uiState.value = _uiState.value.copy(statusBanner = null)
    }
}
