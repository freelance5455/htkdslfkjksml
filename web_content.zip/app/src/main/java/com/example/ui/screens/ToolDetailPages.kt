package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AssistantPersona
import com.example.data.model.GeminiModelOption
import com.example.data.model.PendingAttachment
import com.example.ui.MainViewModel
import com.example.ui.theme.NexusBackground
import com.example.ui.theme.NexusBorder
import com.example.ui.theme.NexusCodeBackground
import com.example.ui.theme.NexusCyan
import com.example.ui.theme.NexusCyanDark
import com.example.ui.theme.NexusCyanDim
import com.example.ui.theme.NexusRose
import com.example.ui.theme.NexusSurface
import com.example.ui.theme.NexusSurfaceElevated
import com.example.ui.theme.NexusSurfaceVariant
import com.example.ui.theme.NexusTextPrimary
import com.example.ui.theme.NexusTextSecondary
import com.example.ui.theme.NexusTextTertiary
import com.example.ui.theme.NexusVioletLight
import com.example.util.AttachmentReader
import androidx.compose.material3.HorizontalDivider

@Composable
private fun ToolPageHeader(
    title: String,
    subtitle: String,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(NexusBackground)
            .statusBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(40.dp)
                    .testTag("tool_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Назад к инструментам",
                    tint = NexusVioletLight
                )
            }
            Spacer(modifier = Modifier.width(6.dp))
            Column {
                Text(
                    text = title,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = NexusTextPrimary
                )
                Text(
                    text = subtitle,
                    fontSize = 11.5.sp,
                    color = NexusTextSecondary
                )
            }
        }
        HorizontalDivider(thickness = 0.8.dp, color = NexusBorder)
    }
}

@Composable
private fun ToolAttachmentsPreview(
    attachments: List<PendingAttachment>,
    onRemove: (String) -> Unit
) {
    if (attachments.isEmpty()) return
    LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        items(attachments, key = { it.uriString }) { att ->
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(NexusSurfaceElevated)
                    .border(1.dp, NexusCyan.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
                    .padding(start = 10.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = att.displayName,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = NexusTextPrimary
                    )
                    Text(
                        text = "${att.kind.label} • ${AttachmentReader.formatFileSize(att.sizeBytes)}",
                        fontSize = 10.sp,
                        color = NexusTextSecondary
                    )
                }
                IconButton(
                    onClick = { onRemove(att.uriString) },
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Удалить",
                        tint = NexusTextSecondary,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ToolResultCard(
    output: String,
    isGenerating: Boolean,
    error: String?,
    onSpeak: (String) -> Unit,
    onMoveToChat: (String) -> Unit
) {
    val context = LocalContext.current
    if (error != null) {
        Surface(
            color = NexusRose.copy(alpha = 0.14f),
            border = BorderStroke(1.dp, NexusRose.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = error,
                color = NexusTextPrimary,
                fontSize = 13.sp,
                modifier = Modifier.padding(14.dp)
            )
        }
        return
    }

    if (isGenerating && output.isBlank()) {
        Surface(
            color = NexusSurfaceElevated,
            border = BorderStroke(1.dp, NexusCyan.copy(alpha = 0.4f)),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    color = NexusVioletLight,
                    strokeWidth = 2.dp
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text("Выполняется обработка...", fontSize = 13.sp, color = NexusVioletLight)
            }
        }
        return
    }

    if (output.isBlank()) return

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = NexusSurface),
        border = BorderStroke(1.dp, NexusBorder),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("tool_result_card")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Результат",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = NexusVioletLight
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = output,
                fontSize = 14.sp,
                lineHeight = 20.sp,
                color = NexusTextPrimary
            )
            if (!isGenerating) {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("NEXUS Result", output))
                            Toast.makeText(context, "Скопировано", Toast.LENGTH_SHORT).show()
                        },
                        border = BorderStroke(1.dp, NexusBorder),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = null,
                            tint = NexusTextSecondary,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Копия", fontSize = 12.sp, color = NexusTextPrimary)
                    }
                    OutlinedButton(
                        onClick = { onSpeak(output) },
                        border = BorderStroke(1.dp, NexusBorder),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = null,
                            tint = NexusVioletLight,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Голос", fontSize = 12.sp, color = NexusTextPrimary)
                    }
                    Button(
                        onClick = { onMoveToChat(output) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NexusCyanDim,
                            contentColor = NexusTextPrimary
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("В чат", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun ImageAnalysisToolPage(
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onMovedToChat: () -> Unit,
    modifier: Modifier = Modifier
) {
    val attachments by viewModel.toolAttachments.collectAsStateWithLifecycle()
    val output by viewModel.toolOutput.collectAsStateWithLifecycle()
    val isGenerating by viewModel.isToolGenerating.collectAsStateWithLifecycle()
    val error by viewModel.toolError.collectAsStateWithLifecycle()

    var prompt by remember { mutableStateOf("") }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(5)
    ) { uris ->
        if (uris.isNotEmpty()) viewModel.addToolAttachmentUris(uris)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NexusBackground)
            .navigationBarsPadding()
            .imePadding()
    ) {
        ToolPageHeader(
            title = "Анализ фото и видео",
            subtitle = "Распознавание объектов, видео, текста и схем",
            onBack = {
                viewModel.stopToolGeneration()
                onBack()
            }
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = {
                    imagePicker.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                    )
                },
                border = BorderStroke(1.dp, NexusCyan.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("tool_pick_image_button")
            ) {
                Icon(
                    imageVector = Icons.Default.AddPhotoAlternate,
                    contentDescription = null,
                    tint = NexusVioletLight
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Выбрать фото или видео", color = NexusTextPrimary)
            }

            ToolAttachmentsPreview(
                attachments = attachments,
                onRemove = { viewModel.removeToolAttachment(it) }
            )

            OutlinedTextField(
                value = prompt,
                onValueChange = { prompt = it },
                label = { Text("Задача для анализа", color = NexusTextSecondary) },
                placeholder = { Text("Опишите фото, извлеките текст или найдите детали...", color = NexusTextTertiary) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("tool_image_prompt"),
                minLines = 3,
                maxLines = 6,
                shape = RoundedCornerShape(14.dp),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Text,
                    capitalization = KeyboardCapitalization.Sentences,
                    autoCorrectEnabled = true,
                    imeAction = ImeAction.Default
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = NexusCodeBackground,
                    unfocusedContainerColor = NexusCodeBackground,
                    focusedBorderColor = NexusCyan,
                    unfocusedBorderColor = NexusBorder,
                    focusedTextColor = NexusTextPrimary,
                    unfocusedTextColor = NexusTextPrimary
                )
            )

            Button(
                onClick = {
                    if (isGenerating) {
                        viewModel.stopToolGeneration()
                    } else {
                        val effective = prompt.ifBlank { "Подробно опиши изображение и выдели ключевые детали на русском языке." }
                        viewModel.runToolQuery(effective, useToolAttachments = true)
                    }
                },
                enabled = isGenerating || attachments.isNotEmpty() || prompt.isNotBlank(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isGenerating) NexusRose else NexusCyanDim,
                    contentColor = NexusTextPrimary
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Icon(
                    imageVector = if (isGenerating) Icons.Default.Stop else Icons.AutoMirrored.Filled.Send,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (isGenerating) "Остановить" else "Проанализировать изображение", fontWeight = FontWeight.SemiBold)
            }

            ToolResultCard(
                output = output,
                isGenerating = isGenerating,
                error = error,
                onSpeak = { viewModel.speakText(it) },
                onMoveToChat = { res ->
                    viewModel.moveToolResultToChat(
                        userPrompt = prompt.ifBlank { "Анализ изображения" },
                        assistantReply = res
                    )
                    onMovedToChat()
                }
            )
        }
    }
}

@Composable
fun DocumentWorkToolPage(
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onMovedToChat: () -> Unit,
    modifier: Modifier = Modifier
) {
    val attachments by viewModel.toolAttachments.collectAsStateWithLifecycle()
    val output by viewModel.toolOutput.collectAsStateWithLifecycle()
    val isGenerating by viewModel.isToolGenerating.collectAsStateWithLifecycle()
    val error by viewModel.toolError.collectAsStateWithLifecycle()

    var selectedAction by remember { mutableStateOf("Краткое резюме и выводы") }
    var prompt by remember { mutableStateOf("") }

    val docPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) viewModel.addToolAttachmentUris(uris)
    }

    val mediaPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(5)
    ) { uris ->
        if (uris.isNotEmpty()) viewModel.addToolAttachmentUris(uris)
    }

    val presets = listOf(
        "Краткое резюме и выводы",
        "Ключевые факты и цифры",
        "Поиск ошибок в коде",
        "Перевод на русский"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NexusBackground)
            .navigationBarsPadding()
            .imePadding()
    ) {
        ToolPageHeader(
            title = "Работа с документами",
            subtitle = "PDF, DOCX, XLSX, текст, код, видео и аудио",
            onBack = {
                viewModel.stopToolGeneration()
                onBack()
            }
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        docPicker.launch(arrayOf("*/*"))
                    },
                    border = BorderStroke(1.dp, NexusCyan.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("tool_pick_doc_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.UploadFile,
                        contentDescription = null,
                        tint = NexusVioletLight,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Файл / Док", color = NexusTextPrimary, fontSize = 13.sp)
                }

                OutlinedButton(
                    onClick = {
                        mediaPicker.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                        )
                    },
                    border = BorderStroke(1.dp, NexusCyan.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("tool_pick_media_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.AddPhotoAlternate,
                        contentDescription = null,
                        tint = NexusVioletLight,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Фото / Видео", color = NexusTextPrimary, fontSize = 13.sp)
                }
            }

            ToolAttachmentsPreview(
                attachments = attachments,
                onRemove = { viewModel.removeToolAttachment(it) }
            )

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(presets) { mode ->
                    val active = selectedAction == mode
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (active) NexusCyanDark else NexusSurfaceVariant)
                            .border(1.dp, if (active) NexusCyan else NexusBorder, RoundedCornerShape(10.dp))
                            .clickable { selectedAction = mode }
                            .padding(horizontal = 12.dp, vertical = 7.dp)
                    ) {
                        Text(
                            text = mode,
                            fontSize = 12.sp,
                            color = if (active) NexusVioletLight else NexusTextSecondary
                        )
                    }
                }
            }

            OutlinedTextField(
                value = prompt,
                onValueChange = { prompt = it },
                label = { Text("Инструкция или текст документа", color = NexusTextSecondary) },
                placeholder = { Text("Задайте вопрос по файлу или вставьте текст...", color = NexusTextTertiary) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("tool_doc_prompt"),
                minLines = 3,
                maxLines = 6,
                shape = RoundedCornerShape(14.dp),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Text,
                    capitalization = KeyboardCapitalization.Sentences,
                    autoCorrectEnabled = true,
                    imeAction = ImeAction.Default
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = NexusCodeBackground,
                    unfocusedContainerColor = NexusCodeBackground,
                    focusedBorderColor = NexusCyan,
                    unfocusedBorderColor = NexusBorder,
                    focusedTextColor = NexusTextPrimary,
                    unfocusedTextColor = NexusTextPrimary
                )
            )

            Button(
                onClick = {
                    if (isGenerating) {
                        viewModel.stopToolGeneration()
                    } else {
                        val effective = "Действие: $selectedAction.\n${prompt.trim()}".trim()
                        viewModel.runToolQuery(effective, useToolAttachments = true)
                    }
                },
                enabled = isGenerating || attachments.isNotEmpty() || prompt.isNotBlank(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isGenerating) NexusRose else NexusCyanDim,
                    contentColor = NexusTextPrimary
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Icon(
                    imageVector = if (isGenerating) Icons.Default.Stop else Icons.Default.Description,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (isGenerating) "Остановить" else "Обработать документ", fontWeight = FontWeight.SemiBold)
            }

            ToolResultCard(
                output = output,
                isGenerating = isGenerating,
                error = error,
                onSpeak = { viewModel.speakText(it) },
                onMoveToChat = { res ->
                    viewModel.moveToolResultToChat(
                        userPrompt = "$selectedAction: ${prompt.ifBlank { "прикреплённый документ" }}",
                        assistantReply = res
                    )
                    onMovedToChat()
                }
            )
        }
    }
}

@Composable
fun VoiceToolPage(
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onNavigateToChat: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NexusBackground)
            .navigationBarsPadding()
            .imePadding()
    ) {
        ToolPageHeader(
            title = "Голосовые функции",
            subtitle = "Распознавание речи, нейросфера и чтец текста",
            onBack = onBack
        )
        VoiceScreen(
            viewModel = viewModel,
            onNavigateToChat = onNavigateToChat,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun TextGenerationToolPage(
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onMovedToChat: () -> Unit,
    modifier: Modifier = Modifier
) {
    val output by viewModel.toolOutput.collectAsStateWithLifecycle()
    val isGenerating by viewModel.isToolGenerating.collectAsStateWithLifecycle()
    val error by viewModel.toolError.collectAsStateWithLifecycle()

    val formats = listOf("Статья", "Письмо", "Код", "План", "Редактура")
    val tones = listOf("Профессиональный", "Научный", "Дружелюбный", "Краткий")

    var selectedFormat by remember { mutableStateOf(formats.first()) }
    var selectedTone by remember { mutableStateOf(tones.first()) }
    var topic by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NexusBackground)
            .navigationBarsPadding()
            .imePadding()
    ) {
        ToolPageHeader(
            title = "Генерация текста",
            subtitle = "Создание материалов, писем, кода и планов",
            onBack = {
                viewModel.stopToolGeneration()
                onBack()
            }
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Формат", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = NexusTextSecondary)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(formats) { item ->
                    val active = selectedFormat == item
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (active) NexusCyanDark else NexusSurfaceVariant)
                            .border(1.dp, if (active) NexusCyan else NexusBorder, RoundedCornerShape(10.dp))
                            .clickable { selectedFormat = item }
                            .padding(horizontal = 12.dp, vertical = 7.dp)
                    ) {
                        Text(item, fontSize = 12.sp, color = if (active) NexusVioletLight else NexusTextSecondary)
                    }
                }
            }

            Text("Стиль", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = NexusTextSecondary)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(tones) { item ->
                    val active = selectedTone == item
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (active) NexusCyanDark else NexusSurfaceVariant)
                            .border(1.dp, if (active) NexusCyan else NexusBorder, RoundedCornerShape(10.dp))
                            .clickable { selectedTone = item }
                            .padding(horizontal = 12.dp, vertical = 7.dp)
                    ) {
                        Text(item, fontSize = 12.sp, color = if (active) NexusVioletLight else NexusTextSecondary)
                    }
                }
            }

            OutlinedTextField(
                value = topic,
                onValueChange = { topic = it },
                label = { Text("Тема или черновик", color = NexusTextSecondary) },
                placeholder = { Text("Опишите задачу: тема, структура, язык, детали...", color = NexusTextTertiary) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("tool_textgen_prompt"),
                minLines = 4,
                maxLines = 8,
                shape = RoundedCornerShape(14.dp),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Text,
                    capitalization = KeyboardCapitalization.Sentences,
                    autoCorrectEnabled = true,
                    imeAction = ImeAction.Default
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = NexusCodeBackground,
                    unfocusedContainerColor = NexusCodeBackground,
                    focusedBorderColor = NexusCyan,
                    unfocusedBorderColor = NexusBorder,
                    focusedTextColor = NexusTextPrimary,
                    unfocusedTextColor = NexusTextPrimary
                )
            )

            Button(
                onClick = {
                    if (isGenerating) {
                        viewModel.stopToolGeneration()
                    } else {
                        val fullPrompt = "Создай текст.\nФормат: $selectedFormat.\nСтиль: $selectedTone.\nЗадание:\n${topic.trim()}"
                        viewModel.runToolQuery(fullPrompt, useToolAttachments = false)
                    }
                },
                enabled = isGenerating || topic.isNotBlank(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isGenerating) NexusRose else NexusCyanDim,
                    contentColor = NexusTextPrimary
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Text(if (isGenerating) "Остановить генерацию" else "Сгенерировать текст", fontWeight = FontWeight.SemiBold)
            }

            ToolResultCard(
                output = output,
                isGenerating = isGenerating,
                error = error,
                onSpeak = { viewModel.speakText(it) },
                onMoveToChat = { res ->
                    viewModel.moveToolResultToChat(
                        userPrompt = "$selectedFormat ($selectedTone): $topic",
                        assistantReply = res
                    )
                    onMovedToChat()
                }
            )
        }
    }
}

@Composable
fun OtherAiToolPage(
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NexusBackground)
            .navigationBarsPadding()
            .imePadding()
    ) {
        ToolPageHeader(
            title = "Другие функции ИИ",
            subtitle = "Выбор модели Gemini и режимов синтеза",
            onBack = onBack
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Активная версия Gemini", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = NexusTextPrimary)
            GeminiModelOption.values().forEach { model ->
                val selected = settings.geminiModel == model
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (selected) NexusSurfaceElevated else NexusSurface)
                        .border(1.dp, if (selected) NexusCyan else NexusBorder, RoundedCornerShape(12.dp))
                        .clickable { viewModel.updateGeminiModel(model) }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(model.title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = NexusTextPrimary)
                        Text(model.description, fontSize = 11.sp, color = NexusTextSecondary)
                    }
                    if (selected) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = NexusVioletLight,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text("Роль и характер интеллекта", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = NexusTextPrimary)
            AssistantPersona.values().forEach { persona ->
                val selected = settings.persona == persona
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (selected) NexusSurfaceElevated else NexusSurface)
                        .border(1.dp, if (selected) NexusCyan else NexusBorder, RoundedCornerShape(12.dp))
                        .clickable { viewModel.updatePersona(persona) }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(persona.title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = NexusTextPrimary)
                        Text(persona.description, fontSize = 11.sp, color = NexusTextSecondary)
                    }
                    if (selected) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = NexusVioletLight,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Button(
                onClick = onOpenSettings,
                colors = ButtonDefaults.buttonColors(
                    containerColor = NexusCyanDim,
                    contentColor = NexusTextPrimary
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Text("Открыть полные настройки", fontWeight = FontWeight.SemiBold)
            }
        }
    }
}
