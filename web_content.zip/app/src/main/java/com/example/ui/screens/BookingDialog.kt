package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Plumbing
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.BookingRepository
import com.example.model.Booking
import com.example.model.NepalLocations
import com.example.model.Provider
import com.example.model.ServiceCategory
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.NavyLight
import com.example.ui.theme.NavyPrimary
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BookingDialog(
    initialProvider: Provider? = null,
    availableProviders: List<Provider> = emptyList(),
    bookingRepository: BookingRepository,
    onDismiss: () -> Unit,
    onSuccess: (Booking) -> Unit
) {
    val currentUser = Firebase.auth.currentUser
    val coroutineScope = rememberCoroutineScope()

    var customerName by remember { mutableStateOf(currentUser?.displayName ?: "") }
    var customerPhone by remember { mutableStateOf("") }
    var selectedCategory by remember {
        mutableStateOf(initialProvider?.category ?: "electrician")
    }
    var selectedCity by remember {
        mutableStateOf(initialProvider?.city ?: "Tulsipur")
    }
    var selectedProvider by remember {
        mutableStateOf(initialProvider)
    }
    var address by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var preferredDate by remember { mutableStateOf("आजै (Today)") }
    var preferredTime by remember { mutableStateOf("बिहान ९:०० - १२:००") }

    var isSubmitting by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val quickDescriptionSuggestions = remember(selectedCategory) {
        when (selectedCategory.lowercase()) {
            "electrician" -> listOf(
                "स्विचबोर्ड मर्मत",
                "घरको वायरिङ समस्या",
                "मेन मिटर / MCB ट्रिप",
                "पङ्खा र बत्ती जडान",
                "इन्भर्टर ब्याट्री चेक"
            )
            "plumber" -> listOf(
                "धाराबाट पानी चुहावट",
                "पाइप लाइन फिटिङ",
                "पानी ट्याङ्की जडान",
                "कमोड / फ्लस मर्मत",
                "मोटर पम्प जडान"
            )
            else -> listOf(
                "रेफ्रिजरेटर कुलिंग समस्या",
                "वासिङ मेसिन मर्मत",
                "ग्यास चुल्हो मर्मत",
                "पानी तान्ने मोटर",
                "माइक्रोवेभ मर्मत"
            )
        }
    }

    AlertDialog(
        onDismissRequest = { if (!isSubmitting) onDismiss() },
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(NavyPrimary.copy(alpha = 0.1f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = null,
                        tint = EmeraldGreen,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "नयाँ सेवा अनुरोध फारम",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = NavyPrimary
                    )
                    Text(
                        text = "Mero Sewa Service Booking",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                if (errorMessage != null) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.errorContainer
                    ) {
                        Text(
                            text = errorMessage!!,
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                // 1. Service Category
                Text(
                    text = "१. सेवा कोटि (Service Category) *",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(
                        Triple(ServiceCategory.ELECTRICIAN.id, ServiceCategory.ELECTRICIAN.labelNepali, Icons.Filled.Bolt),
                        Triple(ServiceCategory.PLUMBER.id, ServiceCategory.PLUMBER.labelNepali, Icons.Filled.Plumbing),
                        Triple(ServiceCategory.OTHER_REPAIRS.id, ServiceCategory.OTHER_REPAIRS.labelNepali, Icons.Filled.Build)
                    ).forEach { (catId, label, icon) ->
                        val isSelected = selectedCategory == catId
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                selectedCategory = catId
                                // Reset selected provider if it doesn't match new category
                                if (selectedProvider != null && selectedProvider!!.category != catId) {
                                    selectedProvider = null
                                }
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp),
                                    tint = if (isSelected) EmeraldGreen else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            },
                            label = { Text(label, fontSize = 11.sp) },
                            modifier = Modifier.testTag("booking_cat_$catId")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // 2. City / Geographic Location
                Text(
                    text = "२. सहर / क्षेत्र (Service Location) *",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    NepalLocations.CITIES.forEach { city ->
                        val isSelected = selectedCity == city
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedCity = city },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Filled.LocationOn,
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp)
                                )
                            },
                            label = { Text(NepalLocations.getNepaliName(city).split(" ")[0], fontSize = 11.sp) },
                            modifier = Modifier.testTag("booking_city_$city")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // 3. Specific Address & Landmark
                Text(
                    text = "३. विस्तृत ठेगाना र टोल (Detailed Address) *",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    placeholder = { Text("उदा: तुलसीपुर वडा ५, वीरेन्द्र चोक, पञ्चेबाजा नजिक") },
                    leadingIcon = { Icon(Icons.Filled.Home, contentDescription = null, tint = NavyLight) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("customer_address_input")
                )

                Spacer(modifier = Modifier.height(14.dp))

                // 4. Work Description
                Text(
                    text = "४. मर्मत गर्नुपर्ने कामको विवरण (Work Details) *",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    placeholder = { Text("के समस्या भएको हो, स्पष्ट खुलाउनुहोस्...") },
                    leadingIcon = { Icon(Icons.Filled.Description, contentDescription = null, tint = NavyLight) },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("customer_description_input")
                )

                // Quick suggestions chips
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "द्रुत सुझावहरू (Quick Suggestions):",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
                Spacer(modifier = Modifier.height(2.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    quickDescriptionSuggestions.forEach { suggestion ->
                        Surface(
                            onClick = {
                                description = if (description.isBlank()) suggestion else "$description, $suggestion"
                            },
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                        ) {
                            Text(
                                text = "+ $suggestion",
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                color = NavyPrimary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // 5. Preferred Date
                Text(
                    text = "५. उपयुक्त मिति (Preferred Date)",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("आजै (Today)", "भोलि (Tomorrow)", "२-३ दिनमा").forEach { dateOpt ->
                        FilterChip(
                            selected = preferredDate == dateOpt,
                            onClick = { preferredDate = dateOpt },
                            label = { Text(dateOpt, fontSize = 11.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // 6. Preferred Time Window
                Text(
                    text = "६. उपयुक्त समय (Preferred Time) *",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf(
                        "बिहान ९:०० - १२:००",
                        "दिउँसो १२:०० - ३:००",
                        "साँझ ३:०० - ६:००",
                        "तत्काल आवश्यक (Urgent)"
                    ).forEach { timeOpt ->
                        FilterChip(
                            selected = preferredTime == timeOpt,
                            onClick = { preferredTime = timeOpt },
                            leadingIcon = {
                                Icon(Icons.Filled.Schedule, contentDescription = null, modifier = Modifier.size(14.dp))
                            },
                            label = { Text(timeOpt, fontSize = 11.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // 7. Customer Contact Info
                Text(
                    text = "७. तपाईंको सम्पर्क विवरण (Contact Details) *",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = NavyPrimary
                )
                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = customerName,
                    onValueChange = { customerName = it },
                    label = { Text("तपाईंको पूरा नाम *") },
                    leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("customer_name_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = customerPhone,
                    onValueChange = { customerPhone = it },
                    label = { Text("सम्पर्क मोबाइल नम्बर *") },
                    placeholder = { Text("उदा: 9847123456") },
                    leadingIcon = { Icon(Icons.Filled.Phone, contentDescription = null) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("customer_phone_input")
                )

                // Provider confirmation notice
                Spacer(modifier = Modifier.height(12.dp))
                Card(
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = EmeraldGreen.copy(alpha = 0.08f))
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CheckCircle,
                            contentDescription = null,
                            tint = EmeraldGreen,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (selectedProvider != null) {
                                "प्राविधिक: ${selectedProvider!!.name}"
                            } else {
                                "प्राविधिक: उपलब्ध प्रमाणित स्थानीय प्राविधिक"
                            },
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = EmeraldGreen
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (customerName.trim().length < 2) {
                        errorMessage = "कृपया आफ्नो पूरा नाम लेख्नुहोस्।"
                        return@Button
                    }
                    if (customerPhone.trim().length < 7) {
                        errorMessage = "कृपया मान्य फोन नम्बर प्रविष्ट गर्नुहोस् (कम्तिमा ७ अङ्क)।"
                        return@Button
                    }
                    if (address.trim().length < 3) {
                        errorMessage = "कृपया आफ्नो घर, टोल वा चोकको ठेगाना प्रविष्ट गर्नुहोस्।"
                        return@Button
                    }
                    if (description.trim().length < 4) {
                        errorMessage = "कृपया मर्मत गर्नुपर्ने समस्याको विवरण खुलाउनुहोस्।"
                        return@Button
                    }

                    val uid = currentUser?.uid ?: return@Button
                    isSubmitting = true
                    errorMessage = null

                    // Determine provider ID and name
                    val chosenProvider = selectedProvider ?: availableProviders.firstOrNull {
                        it.category.equals(selectedCategory, ignoreCase = true) &&
                                (selectedCity == "All" || it.city.equals(selectedCity, ignoreCase = true))
                    }

                    val pId = chosenProvider?.id ?: "any_verified_provider"
                    val pName = chosenProvider?.name ?: "प्रमाणित स्थानीय प्राविधिक"

                    coroutineScope.launch {
                        val booking = Booking(
                            customerUid = uid,
                            customerName = customerName.trim(),
                            customerPhone = customerPhone.trim(),
                            providerId = pId,
                            providerName = pName,
                            category = selectedCategory,
                            city = selectedCity,
                            address = address.trim(),
                            description = description.trim(),
                            preferredDate = preferredDate.trim(),
                            preferredTime = preferredTime.trim(),
                            status = "pending"
                        )
                        val result = bookingRepository.createBooking(booking)
                        isSubmitting = false
                        if (result.isSuccess) {
                            val savedId = result.getOrThrow()
                            onSuccess(booking.copy(id = savedId))
                        } else {
                            errorMessage = result.exceptionOrNull()?.localizedMessage
                                ?: "सेवा अनुरोध पठाउन असफल भयो। कृपया पुन: प्रयास गर्नुहोस्।"
                        }
                    }
                },
                shape = RoundedCornerShape(20.dp),
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                enabled = !isSubmitting,
                modifier = Modifier.testTag("submit_booking_button")
            ) {
                if (isSubmitting) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        color = Color.White,
                        strokeWidth = 2.dp
                    )
                } else {
                    Text("अनुरोध पेश गर्नुहोस्")
                }
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                enabled = !isSubmitting
            ) {
                Text("रद्द गर्नुहोस्")
            }
        }
    )
}
