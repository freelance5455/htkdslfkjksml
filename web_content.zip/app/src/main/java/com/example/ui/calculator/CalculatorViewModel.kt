package com.example.ui.calculator

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.CalculationHistoryEntity
import com.example.data.preferences.PreferencesDataSource
import com.example.data.preferences.UserPreferences
import com.example.data.repository.HistoryDataSource
import com.example.engine.AngleMode
import com.example.engine.CalcError
import com.example.engine.CalculationEngine
import com.example.engine.EvalResult
import com.example.engine.NumberFormatter
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.math.BigDecimal

data class CalculatorUiState(
  val expression: String = "",
  val formattedExpression: String = "",
  val resultText: String = "",
  val isLivePreview: Boolean = false,
  val isEvaluated: Boolean = false,
  val errorMessage: String? = null,
  val isScientificMode: Boolean = false,
  val isSecondPage: Boolean = false,
  val isHyperbolic: Boolean = false,
  val angleMode: AngleMode = AngleMode.DEG,
  val hasMemory: Boolean = false,
  val memoryFormatted: String = "",
  val lastResultRaw: String? = null,
)

private data class InternalCalcState(
  val expression: String = "",
  val evaluatedResult: String? = null,
  val evaluatedRaw: String? = null,
  val errorMessage: String? = null,
  val isEvaluated: Boolean = false,
  val isScientificMode: Boolean = false,
  val isSecondPage: Boolean = false,
  val isHyperbolic: Boolean = false,
  val repeatOp: Char? = null,
  val repeatOperand: String? = null,
)

class CalculatorViewModel(
  private val historyRepository: HistoryDataSource,
  private val preferencesRepository: PreferencesDataSource,
) : ViewModel() {

  private val internalState = MutableStateFlow(InternalCalcState())
  private val memoryMutex = Mutex()
  private var memoryMirror: BigDecimal? = null
  private var memoryInitialized = false

  val preferences: StateFlow<UserPreferences> =
    preferencesRepository.preferences.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = UserPreferences(),
    )

  init {
    viewModelScope.launch {
      preferencesRepository.preferences.collect { prefs ->
        memoryMutex.withLock {
          if (!memoryInitialized) {
            memoryMirror = prefs.memoryValue
            memoryInitialized = true
          }
        }
      }
    }
  }

  val history: StateFlow<List<CalculationHistoryEntity>> =
    historyRepository.history.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = emptyList(),
    )

  val uiState: StateFlow<CalculatorUiState> =
    combine(internalState, preferences) { calc, prefs ->
        val formattedExpr =
          NumberFormatter.formatExpressionForDisplay(calc.expression, prefs.groupingStyle)
        val hasMem = prefs.memoryValue != null
        val memFmt =
          prefs.memoryValue?.let { NumberFormatter.formatResult(it, prefs.formattingOptions) } ?: ""

        if (calc.errorMessage != null) {
          CalculatorUiState(
            expression = calc.expression,
            formattedExpression = formattedExpr,
            resultText = calc.errorMessage,
            isLivePreview = false,
            isEvaluated = calc.isEvaluated,
            errorMessage = calc.errorMessage,
            isScientificMode = calc.isScientificMode,
            isSecondPage = calc.isSecondPage,
            isHyperbolic = calc.isHyperbolic,
            angleMode = prefs.angleMode,
            hasMemory = hasMem,
            memoryFormatted = memFmt,
            lastResultRaw = null,
          )
        } else if (calc.isEvaluated && calc.evaluatedResult != null) {
          CalculatorUiState(
            expression = calc.expression,
            formattedExpression = formattedExpr,
            resultText = calc.evaluatedResult,
            isLivePreview = false,
            isEvaluated = true,
            errorMessage = null,
            isScientificMode = calc.isScientificMode,
            isSecondPage = calc.isSecondPage,
            isHyperbolic = calc.isHyperbolic,
            angleMode = prefs.angleMode,
            hasMemory = hasMem,
            memoryFormatted = memFmt,
            lastResultRaw = calc.evaluatedRaw,
          )
        } else {
          val live =
            CalculationEngine.evaluateLivePreview(
              calc.expression,
              prefs.angleMode,
              prefs.formattingOptions,
            )
          val previewText =
            when (live) {
              is EvalResult.Success -> {
                // Avoid showing identical redundant preview if user just typed a plain single number
                val cleanExpr = calc.expression.replace("−", "-")
                val isSinglePlainNumber =
                  cleanExpr.toBigDecimalOrNull() != null && !cleanExpr.contains('%')
                if (isSinglePlainNumber) "" else live.formatted
              }
              is EvalResult.Error -> ""
              null -> ""
            }
          val previewRaw = (live as? EvalResult.Success)?.rawNumericString
          CalculatorUiState(
            expression = calc.expression,
            formattedExpression = formattedExpr,
            resultText = previewText,
            isLivePreview = previewText.isNotEmpty(),
            isEvaluated = false,
            errorMessage = null,
            isScientificMode = calc.isScientificMode,
            isSecondPage = calc.isSecondPage,
            isHyperbolic = calc.isHyperbolic,
            angleMode = prefs.angleMode,
            hasMemory = hasMem,
            memoryFormatted = memFmt,
            lastResultRaw = previewRaw,
          )
        }
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = CalculatorUiState(),
      )

  fun onDigit(digit: String) {
    internalState.update { state ->
      val base =
        if (state.isEvaluated) {
          ""
        } else {
          state.expression
        }
      // Prevent multiple leading zeros on a fresh number segment
      val updated = replaceTrailingZeroIfNeeded(base, digit)
      state.copy(
        expression = updated,
        evaluatedResult = null,
        evaluatedRaw = null,
        errorMessage = null,
        isEvaluated = false,
        repeatOp = null,
        repeatOperand = null,
      )
    }
  }

  fun onDecimal() {
    internalState.update { state ->
      val base = if (state.isEvaluated) "" else state.expression
      val currentSegment = extractTrailingNumberSegment(base)
      if (currentSegment.contains('.') || base.matches(Regex(""".*[0-9.]E[+\-−]?\d*$""", RegexOption.IGNORE_CASE))) {
        return@update state
      }
      val toAppend =
        when {
          base.isEmpty() -> "0."
          base.last().isDigit() -> "."
          base.last() in charArrayOf(')', '%', '!', 'π', 'e') -> "×0."
          else -> "0."
        }
      state.copy(
        expression = base + toAppend,
        evaluatedResult = null,
        evaluatedRaw = null,
        errorMessage = null,
        isEvaluated = false,
        repeatOp = null,
        repeatOperand = null,
      )
    }
  }

  fun onOperator(op: Char) {
    internalState.update { state ->
      val base =
        if (state.isEvaluated && state.evaluatedRaw != null && state.errorMessage == null) {
          state.evaluatedRaw
        } else if (state.errorMessage != null) {
          ""
        } else {
          state.expression
        }

      if (base.isEmpty()) {
        if (op == '−') {
          return@update state.copy(
            expression = "−",
            evaluatedResult = null,
            evaluatedRaw = null,
            errorMessage = null,
            isEvaluated = false,
          )
        }
        return@update state
      }

      val last = base.last()
      val updated =
        when {
          last == '(' || last == ',' -> {
            if (op == '−') "$base−" else base
          }
          isBinaryOp(last) -> {
            if (base.length == 1 && last == '−' && op != '−') {
              ""
            } else if (base.length >= 2 && base[base.length - 2] in charArrayOf('(', ',', '×', '÷', '^') && last == '−') {
              base
            } else {
              base.dropLast(1) + op
            }
          }
          else -> base + op
        }

      state.copy(
        expression = updated,
        evaluatedResult = null,
        evaluatedRaw = null,
        errorMessage = null,
        isEvaluated = false,
        repeatOp = null,
        repeatOperand = null,
      )
    }
  }

  fun onPercent() {
    internalState.update { state ->
      val base =
        if (state.isEvaluated && state.evaluatedRaw != null && state.errorMessage == null) {
          state.evaluatedRaw
        } else {
          state.expression
        }
      if (base.isEmpty()) return@update state
      val last = base.last()
      if (!last.isDigit() && last != ')' && last != 'π' && last != 'e' && last != '!') {
        return@update state
      }
      state.copy(
        expression = "$base%",
        evaluatedResult = null,
        evaluatedRaw = null,
        errorMessage = null,
        isEvaluated = false,
        repeatOp = null,
        repeatOperand = null,
      )
    }
  }

  fun onToggleSign() {
    internalState.update { state ->
      val base =
        if (state.isEvaluated && state.evaluatedRaw != null && state.errorMessage == null) {
          state.evaluatedRaw
        } else {
          state.expression
        }

      if (base.isEmpty()) {
        return@update state.copy(
          expression = "−",
          isEvaluated = false,
          errorMessage = null,
        )
      }
      if (base == "−") {
        return@update state.copy(expression = "", isEvaluated = false, errorMessage = null)
      }

      // Check if trailing token is "(−<digits>)"
      val wrappedNegRegex = Regex("""\(−(\d*\.?\d*(?:[Ee][+\-]?\d+)?)\)$""")
      val wrappedMatch = wrappedNegRegex.find(base)
      val updated =
        if (wrappedMatch != null) {
          base.removeRange(wrappedMatch.range) + wrappedMatch.groupValues[1]
        } else if (base.startsWith("−") && base.drop(1).matches(Regex("""\d*\.?\d*(?:[Ee][+\-]?\d+)?"""))) {
          base.drop(1)
        } else {
          // Find trailing unsigned number (including scientific E notation)
          val numRegex = Regex("""(\d+\.?\d*(?:[Ee][+\-]?\d+)?|\.\d+(?:[Ee][+\-]?\d+)?)$""")
          val numMatch = numRegex.find(base)
          if (numMatch != null) {
            val prefix = base.substring(0, numMatch.range.first)
            if (prefix.isEmpty()) {
              "−${numMatch.value}"
            } else if (prefix.endsWith("−") && (prefix.length == 1 || prefix[prefix.length - 2] in charArrayOf('(', ',', '×', '÷', '^', '+', '−'))) {
              prefix.dropLast(1) + numMatch.value
            } else {
              "$prefix(−${numMatch.value})"
            }
          } else {
            val last = base.last()
            if (last in charArrayOf('+', '−', '×', '÷', '^', '(', ',')) {
              "$base(−"
            } else {
              base
            }
          }
        }

      state.copy(
        expression = updated,
        evaluatedResult = null,
        evaluatedRaw = null,
        errorMessage = null,
        isEvaluated = false,
      )
    }
  }

  fun onClearAll() {
    internalState.value =
      internalState.value.copy(
        expression = "",
        evaluatedResult = null,
        evaluatedRaw = null,
        errorMessage = null,
        isEvaluated = false,
        repeatOp = null,
        repeatOperand = null,
      )
  }

  fun onBackspace() {
    internalState.update { state ->
      if (state.isEvaluated || state.errorMessage != null) {
        return@update state.copy(
          expression = "",
          evaluatedResult = null,
          evaluatedRaw = null,
          errorMessage = null,
          isEvaluated = false,
          repeatOp = null,
          repeatOperand = null,
        )
      }
      val expr = state.expression
      if (expr.isEmpty()) return@update state

      // Delete multi-char function prefix cleanly (e.g. "sin(", "logBase(", "nroot(")
      val funcPrefixes =
        listOf(
          "logBase(",
          "nroot(",
          "sinh(",
          "cosh(",
          "tanh(",
          "asin(",
          "acos(",
          "atan(",
          "sin(",
          "cos(",
          "tan(",
          "log(",
          "abs(",
          "ln(",
          "√(",
          "∛(",
        )
      val matchedPrefix = funcPrefixes.firstOrNull { expr.endsWith(it) }
      val updated =
        if (matchedPrefix != null) {
          expr.dropLast(matchedPrefix.length)
        } else {
          expr.dropLast(1)
        }
      state.copy(expression = updated, errorMessage = null)
    }
  }

  fun onEquals() {
    val state = internalState.value
    val prefs = preferences.value

    // Repeated equals behavior
    if (state.isEvaluated && state.evaluatedRaw != null && state.repeatOp != null && state.repeatOperand != null) {
      val repeatedExpr = "${state.evaluatedRaw}${state.repeatOp}${state.repeatOperand}"
      evaluateAndPersist(repeatedExpr, state.repeatOp, state.repeatOperand, prefs)
      return
    }

    val expr = state.expression.trim()
    if (expr.isEmpty()) return

    val (lastOp, lastOperand) = extractLastBinaryStep(expr)
    evaluateAndPersist(expr, lastOp, lastOperand, prefs)
  }

  private fun evaluateAndPersist(
    expr: String,
    repeatOp: Char?,
    repeatOperand: String?,
    prefs: UserPreferences,
  ) {
    when (val res = CalculationEngine.evaluate(expr, prefs.angleMode, prefs.formattingOptions)) {
      is EvalResult.Success -> {
        internalState.update {
          it.copy(
            expression = expr,
            evaluatedResult = res.formatted,
            evaluatedRaw = res.rawNumericString,
            errorMessage = null,
            isEvaluated = true,
            repeatOp = repeatOp,
            repeatOperand = repeatOperand,
          )
        }
        val cleanInput = expr.replace("−", "-")
        val isTrivialSameNumber = cleanInput == res.rawNumericString.replace("−", "-")
        if (!isTrivialSameNumber) {
          viewModelScope.launch {
            historyRepository.saveCalculation(
              expression = expr,
              resultFormatted = res.formatted,
              resultRaw = res.rawNumericString,
              angleMode = prefs.angleMode.name,
              isScientific = internalState.value.isScientificMode,
            )
          }
        }
      }
      is EvalResult.Error -> {
        internalState.update {
          it.copy(
            evaluatedResult = null,
            evaluatedRaw = null,
            errorMessage = res.error.message,
            isEvaluated = true,
            repeatOp = null,
            repeatOperand = null,
          )
        }
      }
    }
  }

  // Scientific input helpers
  fun onScientificFunction(prefixWithParen: String) {
    internalState.update { state ->
      val base =
        if (state.isEvaluated && state.evaluatedRaw != null && state.errorMessage == null) {
          // Apply function directly to evaluated result if user taps sin/sqrt etc after '='
          return@update state.copy(
            expression = "$prefixWithParen${state.evaluatedRaw})",
            evaluatedResult = null,
            evaluatedRaw = null,
            errorMessage = null,
            isEvaluated = false,
          )
        } else if (state.isEvaluated) {
          ""
        } else {
          state.expression
        }
      state.copy(
        expression = base + prefixWithParen,
        evaluatedResult = null,
        evaluatedRaw = null,
        errorMessage = null,
        isEvaluated = false,
        repeatOp = null,
        repeatOperand = null,
      )
    }
  }

  fun onScientificConstant(symbol: String) {
    internalState.update { state ->
      val base = if (state.isEvaluated) "" else state.expression
      state.copy(
        expression = base + symbol,
        evaluatedResult = null,
        evaluatedRaw = null,
        errorMessage = null,
        isEvaluated = false,
        repeatOp = null,
        repeatOperand = null,
      )
    }
  }

  fun onScientificPostfix(suffix: String) {
    internalState.update { state ->
      val base =
        if (state.isEvaluated && state.evaluatedRaw != null && state.errorMessage == null) {
          state.evaluatedRaw
        } else {
          state.expression
        }
      if (base.isEmpty()) return@update state
      val last = base.last()
      if (!last.isDigit() && last != ')' && last != 'π' && last != 'e' && last != '!') {
        return@update state
      }
      state.copy(
        expression = base + suffix,
        evaluatedResult = null,
        evaluatedRaw = null,
        errorMessage = null,
        isEvaluated = false,
      )
    }
  }

  fun onReciprocal() {
    internalState.update { state ->
      val base =
        if (state.isEvaluated && state.evaluatedRaw != null && state.errorMessage == null) {
          return@update state.copy(
            expression = "1÷(${state.evaluatedRaw})",
            evaluatedResult = null,
            evaluatedRaw = null,
            errorMessage = null,
            isEvaluated = false,
          )
        } else if (state.isEvaluated) {
          ""
        } else {
          state.expression
        }
      state.copy(
        expression = "${base}1÷(",
        evaluatedResult = null,
        evaluatedRaw = null,
        errorMessage = null,
        isEvaluated = false,
      )
    }
  }

  fun onParen(paren: String) {
    internalState.update { state ->
      val base = if (state.isEvaluated) "" else state.expression
      if (paren == ")") {
        val openCount = base.count { it == '(' } - base.count { it == ')' }
        if (openCount <= 0) return@update state
        if (base.isNotEmpty() && base.last() in charArrayOf('(', ',', '+', '−', '×', '÷', '^')) {
          return@update state
        }
      }
      state.copy(
        expression = base + paren,
        evaluatedResult = null,
        evaluatedRaw = null,
        errorMessage = null,
        isEvaluated = false,
      )
    }
  }

  fun onComma() {
    internalState.update { state ->
      val base = state.expression
      if (base.isEmpty() || base.last() in charArrayOf('(', ',', '+', '−', '×', '÷', '^')) {
        return@update state
      }
      state.copy(
        expression = "$base,",
        evaluatedResult = null,
        evaluatedRaw = null,
        errorMessage = null,
        isEvaluated = false,
      )
    }
  }

  fun toggleScientificMode() {
    internalState.update { it.copy(isScientificMode = !it.isScientificMode) }
  }

  fun setScientificMode(enabled: Boolean) {
    internalState.update { it.copy(isScientificMode = enabled) }
  }

  fun toggleSecondPage() {
    internalState.update { it.copy(isSecondPage = !it.isSecondPage) }
  }

  fun toggleHyperbolic() {
    internalState.update { it.copy(isHyperbolic = !it.isHyperbolic) }
  }

  fun toggleAngleMode() {
    val next = if (preferences.value.angleMode == AngleMode.DEG) AngleMode.RAD else AngleMode.DEG
    viewModelScope.launch { preferencesRepository.setAngleMode(next) }
  }

  // Memory operations
  fun onMemoryClear() {
    viewModelScope.launch {
      memoryMutex.withLock {
        memoryInitialized = true
        memoryMirror = null
        preferencesRepository.setMemoryValue(null)
      }
    }
  }

  fun onMemoryRecall() {
    val mem = (if (memoryInitialized) memoryMirror else preferences.value.memoryValue) ?: return
    val raw = NumberFormatter.formatRawForExpression(mem)
    val insertText = if (raw.startsWith("−") && internalState.value.expression.isNotEmpty() && !internalState.value.isEvaluated) {
      "($raw)"
    } else {
      raw
    }
    internalState.update { state ->
      val base = if (state.isEvaluated) "" else state.expression
      state.copy(
        expression = base + insertText,
        evaluatedResult = null,
        evaluatedRaw = null,
        errorMessage = null,
        isEvaluated = false,
        repeatOp = null,
        repeatOperand = null,
      )
    }
  }

  fun onMemoryAdd() {
    val currentVal = resolveCurrentNumericValue() ?: return
    viewModelScope.launch {
      memoryMutex.withLock {
        if (!memoryInitialized) {
          memoryMirror = preferencesRepository.preferences.first().memoryValue
          memoryInitialized = true
        }
        val baseMem = memoryMirror ?: BigDecimal.ZERO
        val updated = baseMem.add(currentVal)
        memoryMirror = updated
        preferencesRepository.setMemoryValue(updated)
      }
    }
  }

  fun onMemorySubtract() {
    val currentVal = resolveCurrentNumericValue() ?: return
    viewModelScope.launch {
      memoryMutex.withLock {
        if (!memoryInitialized) {
          memoryMirror = preferencesRepository.preferences.first().memoryValue
          memoryInitialized = true
        }
        val baseMem = memoryMirror ?: BigDecimal.ZERO
        val updated = baseMem.subtract(currentVal)
        memoryMirror = updated
        preferencesRepository.setMemoryValue(updated)
      }
    }
  }

  private fun resolveCurrentNumericValue(): BigDecimal? {
    val state = internalState.value
    val prefs = preferences.value
    if (state.expression.isBlank()) return null
    val res = CalculationEngine.evaluate(state.expression, prefs.angleMode, prefs.formattingOptions)
    return (res as? EvalResult.Success)?.value
  }

  // History actions
  fun reuseHistoryItem(item: CalculationHistoryEntity) {
    internalState.update {
      it.copy(
        expression = item.expression,
        evaluatedResult = item.resultFormatted,
        evaluatedRaw = item.resultRaw,
        errorMessage = null,
        isEvaluated = false,
        repeatOp = null,
        repeatOperand = null,
      )
    }
  }

  fun reuseHistoryResult(item: CalculationHistoryEntity) {
    internalState.update { state ->
      val base = if (state.isEvaluated) "" else state.expression
      val raw = item.resultRaw
      val toAppend =
        if (raw.startsWith("−") && base.isNotEmpty()) "($raw)" else raw
      state.copy(
        expression = base + toAppend,
        evaluatedResult = null,
        evaluatedRaw = null,
        errorMessage = null,
        isEvaluated = false,
      )
    }
  }

  fun deleteHistoryItem(id: Long) {
    viewModelScope.launch { historyRepository.deleteById(id) }
  }

  fun clearAllHistory() {
    viewModelScope.launch { historyRepository.clearAll() }
  }

  private fun isBinaryOp(c: Char): Boolean = c in charArrayOf('+', '−', '×', '÷', '^')

  private fun extractTrailingNumberSegment(expr: String): String {
    var i = expr.length - 1
    while (i >= 0 && (expr[i].isDigit() || expr[i] == '.')) {
      i--
    }
    return expr.substring(i + 1)
  }

  private fun replaceTrailingZeroIfNeeded(expr: String, digit: String): String {
    if (expr == "0") return digit
    if (expr.endsWith("−0") && (expr.length == 2 || expr[expr.length - 3] in charArrayOf('(', ',', '+', '−', '×', '÷', '^'))) {
      return expr.dropLast(1) + digit
    }
    if (expr.length >= 2 && expr.last() == '0' && expr[expr.length - 2] in charArrayOf('(', ',', '+', '−', '×', '÷', '^')) {
      return expr.dropLast(1) + digit
    }
    return expr + digit
  }

  private fun extractLastBinaryStep(expr: String): Pair<Char?, String?> {
    // Only extract simple trailing binary step when there are no unmatched parens
    var depth = 0
    for (i in expr.length - 1 downTo 1) {
      val ch = expr[i]
      when (ch) {
        ')' -> depth++
        '(' -> depth--
        '+', '−', '-', '×', '÷' -> {
          if (depth == 0) {
            val prev = expr[i - 1]
            // Skip +/- inside scientific notation exponent like 1E+3 or 1E-5
            if ((ch == '+' || ch == '-' || ch == '−') &&
              (prev == 'E' || prev == 'e') &&
              i >= 2 &&
              (expr[i - 2].isDigit() || expr[i - 2] == '.')
            ) {
              continue
            }
            if (prev.isDigit() || prev == ')' || prev == 'π' || prev == 'e' || prev == '%' || prev == '!') {
              val rhs = expr.substring(i + 1)
              if (rhs.isNotEmpty() && !hasBinaryOpIgnoringSciExp(rhs)) {
                return ch to rhs
              }
            }
            return null to null
          }
        }
      }
    }
    return null to null
  }

  private fun hasBinaryOpIgnoringSciExp(rhs: String): Boolean {
    for (idx in rhs.indices) {
      val c = rhs[idx]
      if (c == '×' || c == '÷') return true
      if (c == '+' || c == '−' || c == '-') {
        val isSciExp =
          idx >= 2 &&
            (rhs[idx - 1] == 'E' || rhs[idx - 1] == 'e') &&
            (rhs[idx - 2].isDigit() || rhs[idx - 2] == '.')
        if (!isSciExp) return true
      }
    }
    return false
  }

  class Factory(
    private val historyRepository: HistoryDataSource,
    private val preferencesRepository: PreferencesDataSource,
  ) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
      return CalculatorViewModel(historyRepository, preferencesRepository) as T
    }
  }
}
