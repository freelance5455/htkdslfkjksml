package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Slideshow
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.decode.VideoFrameDecoder
import coil.request.ImageRequest
import com.example.data.model.FileCategory
import com.example.data.model.FileKind
import com.example.data.model.FileNode

data class FileKindVisual(
    val icon: ImageVector,
    val tint: Color,
    val containerColor: Color
)

fun resolveFileKindVisual(kind: FileKind): FileKindVisual = when (kind) {
    FileKind.FOLDER -> FileKindVisual(Icons.Filled.Folder, Color(0xFFF59E0B), Color(0x28F59E0B))
    FileKind.APK, FileKind.APKS, FileKind.XAPK -> FileKindVisual(Icons.Filled.Android, Color(0xFF16A34A), Color(0x2616A34A))
    FileKind.EXE, FileKind.MSI -> FileKindVisual(Icons.Filled.Terminal, Color(0xFFDC2626), Color(0x26DC2626))
    FileKind.ZIP, FileKind.ARCHIVE -> FileKindVisual(Icons.Filled.FolderZip, Color(0xFFD97706), Color(0x26D97706))
    FileKind.PDF -> FileKindVisual(Icons.Filled.PictureAsPdf, Color(0xFFE11D48), Color(0x24E11D48))
    FileKind.WORD -> FileKindVisual(Icons.Filled.Description, Color(0xFF2563EB), Color(0x242563EB))
    FileKind.EXCEL -> FileKindVisual(Icons.Filled.TableChart, Color(0xFF059669), Color(0x24059669))
    FileKind.POWERPOINT -> FileKindVisual(Icons.Filled.Slideshow, Color(0xFFEA580C), Color(0x24EA580C))
    FileKind.TEXT -> FileKindVisual(Icons.Filled.Description, Color(0xFF4F46E5), Color(0x244F46E5))
    FileKind.IMAGE -> FileKindVisual(Icons.Filled.Image, Color(0xFF9333EA), Color(0x249333EA))
    FileKind.AUDIO -> FileKindVisual(Icons.Filled.AudioFile, Color(0xFFDB2777), Color(0x24DB2777))
    FileKind.VIDEO -> FileKindVisual(Icons.Filled.VideoFile, Color(0xFF0891B2), Color(0x240891B2))
    FileKind.GENERIC -> FileKindVisual(Icons.Filled.InsertDriveFile, Color(0xFF64748B), Color(0x2464748B))
}

fun resolveCategoryVisual(category: FileCategory): Pair<ImageVector, Color> = when (category) {
    FileCategory.IMAGES -> Icons.Filled.Image to Color(0xFF8B5CF6)
    FileCategory.AUDIO -> Icons.Filled.AudioFile to Color(0xFFEC4899)
    FileCategory.VIDEOS -> Icons.Filled.VideoFile to Color(0xFF06B6D4)
    FileCategory.DOCUMENTS -> Icons.Filled.Description to Color(0xFF3B82F6)
    FileCategory.DOWNLOADS -> Icons.Filled.Folder to Color(0xFF10B981)
    FileCategory.INSTALLATION -> Icons.Filled.Android to Color(0xFF22C55E)
    FileCategory.COMPRESSED -> Icons.Filled.FolderZip to Color(0xFFF59E0B)
    FileCategory.APPS -> Icons.Filled.Android to Color(0xFF0EA5E9)
}

@Composable
fun FileTypeThumbnail(
    node: FileNode,
    size: Dp = 46.dp,
    modifier: Modifier = Modifier
) {
    val visual = resolveFileKindVisual(node.kind)
    val context = LocalContext.current
    val shape = RoundedCornerShape(14.dp)

    Box(
        modifier = modifier
            .size(size)
            .clip(shape)
            .background(visual.containerColor),
        contentAlignment = Alignment.Center
    ) {
        if ((node.kind == FileKind.IMAGE || node.kind == FileKind.VIDEO) && node.contentUriString != null) {
            val reqBuilder = ImageRequest.Builder(context)
                .data(node.contentUriString)
                .crossfade(true)
            if (node.kind == FileKind.VIDEO) {
                reqBuilder.decoderFactory(VideoFrameDecoder.Factory())
            }
            AsyncImage(
                model = reqBuilder.build(),
                contentDescription = node.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.matchParentSize()
            )
        } else {
            Icon(
                imageVector = visual.icon,
                contentDescription = node.kind.displayLabel,
                tint = visual.tint,
                modifier = Modifier.size(size * 0.56f)
            )
        }

        if (node.hasSuspiciousDoubleExtension) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(2.dp)
                    .size(16.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.error),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Warning,
                    contentDescription = "Suspicious double extension",
                    tint = Color.White,
                    modifier = Modifier.size(11.dp)
                )
            }
        }
    }
}

@Composable
fun FileBadgePill(
    text: String,
    isWarning: Boolean = false,
    modifier: Modifier = Modifier
) {
    val bg = if (isWarning) {
        MaterialTheme.colorScheme.error.copy(alpha = 0.14f)
    } else {
        MaterialTheme.colorScheme.primaryContainer
    }
    val fg = if (isWarning) {
        MaterialTheme.colorScheme.error
    } else {
        MaterialTheme.colorScheme.onPrimaryContainer
    }

    Surface(
        color = bg,
        shape = RoundedCornerShape(8.dp),
        modifier = modifier
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
            color = fg,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}
