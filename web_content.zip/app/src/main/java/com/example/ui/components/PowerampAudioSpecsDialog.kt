package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.EqualizerPreset
import com.example.model.Song
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated

/**
 * Poweramp Audiophile Output & DSP Pipeline Inspector.
 * Shows bit-perfect DVC, decoder specs, sample rate, floating-point DSP, and dynamic headroom.
 */
@Composable
fun PowerampAudioSpecsDialog(
    song: Song,
    currentEqualizer: EqualizerPreset,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = ObsidianBg),
                modifier = Modifier.testTag("audio_specs_close_btn")
            ) {
                Text("Done", fontWeight = FontWeight.Bold)
            }
        },
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(NeonCyan.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("Audio Processing Info", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text("Poweramp Hi-Res Pipeline", color = NeonCyan, fontSize = 11.sp)
                    }
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("audio_specs_content")
            ) {
                // Hi-Res Badge Summary Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceElevated)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(song.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("${song.artist} • ${song.album}", color = Color.LightGray, fontSize = 12.sp)
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(NeonCyan.copy(alpha = 0.15f))
                                .border(1.dp, NeonCyan, RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "HI-RES",
                                color = NeonCyan,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Detail Items
                SpecItem(
                    icon = Icons.Default.GraphicEq,
                    label = "Decoder Format",
                    value = "${song.codec} (${song.bitDepth}-bit / ${song.sampleRateHz / 1000} kHz)"
                )
                SpecItem(
                    icon = Icons.Default.Speed,
                    label = "Bitrate & Stream",
                    value = "${song.bitrateKbps} kbps • ${song.channels}"
                )
                SpecItem(
                    icon = Icons.Default.Bolt,
                    label = "Direct Volume Control (DVC)",
                    value = if (currentEqualizer.dvcEnabled) "Active (Hi-Res Bit-Perfect Headroom)" else "Disabled",
                    valueColor = if (currentEqualizer.dvcEnabled) NeonCyan else Color.Gray
                )
                SpecItem(
                    icon = Icons.Default.Memory,
                    label = "Audio DSP Engine",
                    value = "Prism 32-bit Floating Point DSP"
                )
                SpecItem(
                    icon = Icons.Default.Equalizer,
                    label = "Active Equalizer",
                    value = "${currentEqualizer.name} (${if (currentEqualizer.limiterEnabled) "Limiter ON" else "Direct"})"
                )
                SpecItem(
                    icon = Icons.Default.Info,
                    label = "Preamp & Dynamic Range",
                    value = "${if (currentEqualizer.preampDb >= 0) "+" else ""}${String.format("%.1f", currentEqualizer.preampDb)} dB (+6.0 dB Headroom)"
                )
            }
        },
        containerColor = SurfaceDark,
        shape = RoundedCornerShape(20.dp)
    )
}

@Composable
private fun SpecItem(
    icon: ImageVector,
    label: String,
    value: String,
    valueColor: Color = Color.White
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = NeonCyan,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(label, color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        }
        Text(
            text = value,
            color = valueColor,
            fontSize = 12.5.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(start = 24.dp, top = 2.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Divider(color = Color.White.copy(alpha = 0.05f))
    }
}
