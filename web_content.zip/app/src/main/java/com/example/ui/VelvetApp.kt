package com.example.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.EmojiEmotions
import androidx.compose.material.icons.outlined.Keyboard
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.keyboard.resolveIsDark
import com.example.ui.screens.EmojiStudioScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.StudioPlaygroundScreen
import com.example.ui.screens.ThemeLibraryScreen
import com.example.ui.theme.VelvetKeyTheme

const val ROUTE_STUDIO = "studio"
const val ROUTE_THEMES = "themes"
const val ROUTE_EMOJIS = "emojis"
const val ROUTE_SETTINGS = "settings"

private data class NavDestination(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

private val destinations = listOf(
    NavDestination(ROUTE_STUDIO, "Studio", Icons.Filled.Keyboard, Icons.Outlined.Keyboard),
    NavDestination(ROUTE_THEMES, "Themes", Icons.Filled.Palette, Icons.Outlined.Palette),
    NavDestination(ROUTE_EMOJIS, "Emojis", Icons.Filled.EmojiEmotions, Icons.Outlined.EmojiEmotions),
    NavDestination(ROUTE_SETTINGS, "Settings", Icons.Filled.Settings, Icons.Outlined.Settings)
)

@Composable
fun VelvetApp(
    viewModel: VelvetMainViewModel,
    initialTab: String? = null,
    onRequestMicPermission: () -> Unit
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val imeStatus by viewModel.imeStatus.collectAsStateWithLifecycle()
    val hasMicPermission by viewModel.hasMicPermission.collectAsStateWithLifecycle()
    val playgroundText by viewModel.playgroundText.collectAsStateWithLifecycle()
    val aiPolishState by viewModel.aiPolishState.collectAsStateWithLifecycle()

    val isDark = resolveIsDark(settings.darkModeOption, isSystemInDarkTheme())
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: ROUTE_STUDIO

    fun navigateTo(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    LaunchedEffect(Unit) {
        viewModel.navigateToTabCallback = { route -> navigateTo(route) }
        if (initialTab == ROUTE_SETTINGS) {
            navigateTo(ROUTE_SETTINGS)
        }
    }

    VelvetKeyTheme(darkTheme = isDark) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useRail = maxWidth >= 680.dp

            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                bottomBar = {
                    if (!useRail) {
                        NavigationBar(
                            windowInsets = WindowInsets.navigationBars
                        ) {
                            destinations.forEach { dest ->
                                val selected = currentRoute == dest.route
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { navigateTo(dest.route) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                            contentDescription = dest.label
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = dest.label,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            softWrap = false
                                        )
                                    },
                                    modifier = Modifier.testTag("nav_${dest.route}")
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .consumeWindowInsets(innerPadding)
                        .windowInsetsPadding(WindowInsets.statusBars)
                        .imePadding()
                ) {
                    if (useRail) {
                        NavigationRail {
                            destinations.forEach { dest ->
                                val selected = currentRoute == dest.route
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { navigateTo(dest.route) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                            contentDescription = dest.label
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = dest.label,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            softWrap = false
                                        )
                                    },
                                    modifier = Modifier.testTag("nav_${dest.route}")
                                )
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxSize(),
                        contentAlignment = Alignment.TopCenter
                    ) {
                        NavHost(
                            navController = navController,
                            startDestination = ROUTE_STUDIO,
                            modifier = Modifier
                                .fillMaxSize()
                                .widthIn(max = 640.dp)
                        ) {
                            composable(ROUTE_STUDIO) {
                                StudioPlaygroundScreen(
                                    viewModel = viewModel,
                                    settings = settings,
                                    imeStatus = imeStatus,
                                    hasMicPermission = hasMicPermission,
                                    playgroundText = playgroundText,
                                    aiPolishState = aiPolishState,
                                    onRequestMicPermission = onRequestMicPermission
                                )
                            }
                            composable(ROUTE_THEMES) {
                                ThemeLibraryScreen(
                                    viewModel = viewModel,
                                    settings = settings
                                )
                            }
                            composable(ROUTE_EMOJIS) {
                                EmojiStudioScreen(
                                    viewModel = viewModel,
                                    settings = settings
                                )
                            }
                            composable(ROUTE_SETTINGS) {
                                SettingsScreen(
                                    viewModel = viewModel,
                                    settings = settings,
                                    hasMicPermission = hasMicPermission,
                                    onRequestMicPermission = onRequestMicPermission
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
