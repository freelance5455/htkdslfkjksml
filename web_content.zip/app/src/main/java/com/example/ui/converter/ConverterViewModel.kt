package com.example.ui.converter

import androidx.lifecycle.ViewModel
import com.example.converter.ConversionUnit
import com.example.converter.ConverterCategory
import com.example.converter.UnitConverter
import com.example.engine.FormattingOptions
import com.example.engine.NumberFormatter
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class ConverterUiState(
  val category: ConverterCategory = ConverterCategory.LENGTH,
  val units: List<ConversionUnit> = UnitConverter.unitsFor(ConverterCategory.LENGTH),
  val fromUnit: ConversionUnit = UnitConverter.unitsFor(ConverterCategory.LENGTH)[2], // m
  val toUnit: ConversionUnit = UnitConverter.unitsFor(ConverterCategory.LENGTH)[5], // ft
  val inputText: String = "1",
  val customRateText: String = "",
) {
  fun computeOutput(formatting: FormattingOptions): String {
    val inputVal = inputText.replace("−", "-").toDoubleOrNull() ?: return "—"
    val customRate =
      if (category.isCurrency && customRateText.isNotBlank()) {
        customRateText.toDoubleOrNull()
      } else {
        null
      }
    val converted =
      UnitConverter.convert(
        value = inputVal,
        from = fromUnit,
        to = toUnit,
        category = category,
        customCurrencyRate = customRate,
      ) ?: return "—"
    return NumberFormatter.formatDouble(converted, formatting)
  }

  fun effectiveRateLabel(): String {
    if (fromUnit.id == toUnit.id) {
      return "1 ${fromUnit.symbol} = 1 ${toUnit.symbol}"
    }
    if (category == ConverterCategory.TEMPERATURE) {
      val conv = UnitConverter.convert(1.0, fromUnit, toUnit, category) ?: 1.0
      return "1 ${fromUnit.symbol} → ${NumberFormatter.formatDouble(conv)} ${toUnit.symbol}"
    }
    if (category == ConverterCategory.FUEL_ECONOMY) {
      val conv = UnitConverter.convert(1.0, fromUnit, toUnit, category)
      return if (conv != null) {
        "1 ${fromUnit.symbol} = ${NumberFormatter.formatDouble(conv)} ${toUnit.symbol}"
      } else {
        "${fromUnit.symbol} ↔ ${toUnit.symbol}"
      }
    }
    val custom = if (category.isCurrency) customRateText.toDoubleOrNull() else null
    val rate =
      if (custom != null && custom.isFinite() && custom > 0.0) {
        custom
      } else {
        UnitConverter.defaultRateBetween(fromUnit, toUnit)
      }
    return "1 ${fromUnit.symbol} = ${NumberFormatter.formatDouble(rate)} ${toUnit.symbol}"
  }
}

class ConverterViewModel : ViewModel() {

  private val _state = MutableStateFlow(ConverterUiState())
  val state: StateFlow<ConverterUiState> = _state.asStateFlow()

  fun selectCategory(category: ConverterCategory) {
    val units = UnitConverter.unitsFor(category)
    val defaultFrom = units.first()
    val defaultTo = if (units.size > 1) units[1] else units.first()
    val (from, to) =
      when (category) {
        ConverterCategory.LENGTH -> units[2] to units[5]
        ConverterCategory.WEIGHT -> units[2] to units[5]
        ConverterCategory.TEMPERATURE -> units[0] to units[1]
        ConverterCategory.CURRENCY -> units[0] to units[1]
        else -> defaultFrom to defaultTo
      }
    _state.update { current ->
      val sanitizedInput =
        if (category != ConverterCategory.TEMPERATURE && current.inputText.startsWith("−")) {
          current.inputText.drop(1).ifEmpty { "0" }
        } else {
          current.inputText
        }
      current.copy(
        category = category,
        units = units,
        fromUnit = from,
        toUnit = to,
        inputText = sanitizedInput,
        customRateText = "",
      )
    }
  }

  fun selectFromUnit(unit: ConversionUnit) {
    _state.update { it.copy(fromUnit = unit, customRateText = "") }
  }

  fun selectToUnit(unit: ConversionUnit) {
    _state.update { it.copy(toUnit = unit, customRateText = "") }
  }

  fun swapUnits() {
    _state.update {
      it.copy(
        fromUnit = it.toUnit,
        toUnit = it.fromUnit,
        customRateText = "",
      )
    }
  }

  fun onDigit(digit: String) {
    _state.update { current ->
      val next =
        when {
          current.inputText == "0" -> digit
          current.inputText == "−0" -> "−$digit"
          current.inputText.length >= 16 -> current.inputText
          else -> current.inputText + digit
        }
      current.copy(inputText = next)
    }
  }

  fun onDecimal() {
    _state.update { current ->
      if (current.inputText.contains('.')) return@update current
      val next =
        when {
          current.inputText.isEmpty() || current.inputText == "−" -> "${current.inputText}0."
          else -> "${current.inputText}."
        }
      current.copy(inputText = next)
    }
  }

  fun onToggleSign() {
    _state.update { current ->
      if (!current.category.let { it == ConverterCategory.TEMPERATURE }) return@update current
      val next =
        if (current.inputText.startsWith("−")) {
          current.inputText.drop(1)
        } else {
          "−${current.inputText}"
        }
      current.copy(inputText = next)
    }
  }

  fun onBackspace() {
    _state.update { current ->
      val trimmed = current.inputText.dropLast(1)
      current.copy(inputText = if (trimmed.isEmpty() || trimmed == "−") "0" else trimmed)
    }
  }

  fun onClear() {
    _state.update { it.copy(inputText = "0") }
  }

  fun onCustomRateChanged(rate: String) {
    _state.update { it.copy(customRateText = rate.filter { ch -> ch.isDigit() || ch == '.' }) }
  }
}
