package com.example.ui.screens.seller

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.OrderStatusBadge
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SellerDashboardScreen(
    user: User?,
    products: List<Product>,
    orders: List<Order>,
    deliveryPartners: List<DeliveryPartner>,
    onAddProductClick: () -> Unit,
    onPostInnovationClick: () -> Unit,
    onConfirmOrder: (String) -> Unit,
    onRequestDeliveryPartner: (orderId: String, partner: DeliveryPartner) -> Unit,
    onToggleProductActive: (String) -> Unit,
    onDeleteProduct: (String) -> Unit,
    onViewEarnings: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedOrderForDelivery by remember { mutableStateOf<Order?>(null) }
    var selectedTab by remember { mutableStateOf(0) } // 0 = Overview & Orders, 1 = Products Inventory

    val sellerOrders = orders.filter { it.sellerId == user?.id || it.sellerName.contains("Apex") || it.sellerName.contains(user?.name ?: "") }
    val pendingOrders = sellerOrders.filter { it.status == OrderStatus.ORDER_PLACED || it.status == OrderStatus.SELLER_CONFIRMED || it.status == OrderStatus.DELIVERY_REQUESTED }
    val completedOrders = sellerOrders.filter { it.status == OrderStatus.COMPLETED }
    val totalEarnings = sellerOrders.filter { it.status == OrderStatus.COMPLETED }.sumOf { it.subtotal * 0.85 }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Innovator Command Center",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "${user?.name ?: "Seller"} • Innovation Workspace",
                            style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }
                },
                actions = {
                    IconButton(onClick = onViewEarnings) {
                        Icon(
                            imageVector = Icons.Filled.AccountBalanceWallet,
                            contentDescription = "Earnings",
                            tint = IgnisTechBlue
                        )
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = IgnisTechBlue
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Orders & Activity (${pendingOrders.size} Pending)", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Inventory (${products.size})") }
                )
            }

            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                if (selectedTab == 0) {
                    // Metric Cards Row
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFE0F2FE)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text(
                                        text = "Pending Orders",
                                        style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFF0369A1))
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "${pendingOrders.size}",
                                        style = MaterialTheme.typography.headlineMedium.copy(
                                            fontWeight = FontWeight.Black,
                                            color = Color(0xFF0284C7)
                                        )
                                    )
                                }
                            }

                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFDCFCE7)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text(
                                        text = "Net Earnings",
                                        style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFF166534))
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "$${"%.2f".format(totalEarnings)}",
                                        style = MaterialTheme.typography.headlineMedium.copy(
                                            fontWeight = FontWeight.Black,
                                            color = Color(0xFF15803D)
                                        )
                                    )
                                }
                            }
                        }
                    }

                    // Quick Action Buttons
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = onAddProductClick,
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = IgnisOrangePrimary),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("seller_add_product_button")
                            ) {
                                Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Add Product", fontSize = 13.sp)
                            }

                            Button(
                                onClick = onPostInnovationClick,
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = IgnisTechBlue),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("seller_post_innovation_button")
                            ) {
                                Icon(Icons.Filled.Bolt, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Post Update", fontSize = 13.sp)
                            }
                        }
                    }

                    // Incoming Orders Section
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Incoming Customer Orders",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "${sellerOrders.size} total",
                                style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                        }
                    }

                    if (sellerOrders.isEmpty()) {
                        item {
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(24.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("No orders received yet. Innovator listings are active in the local marketplace.")
                                }
                            }
                        }
                    } else {
                        items(sellerOrders) { order ->
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(
                                                text = order.orderNumber,
                                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                            )
                                            Text(
                                                text = "Customer: ${order.consumerName}",
                                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            )
                                        }
                                        OrderStatusBadge(status = order.status)
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    Text(
                                        text = "${order.items.size} item(s) • Total: $${"%.2f".format(order.total)}",
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                                    )

                                    Text(
                                        text = "Destination: ${order.deliveryAddress.street}, ${order.deliveryAddress.city}",
                                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    )

                                    Spacer(modifier = Modifier.height(12.dp))

                                    // Action Buttons based on status
                                    when (order.status) {
                                        OrderStatus.ORDER_PLACED -> {
                                            Button(
                                                onClick = { onConfirmOrder(order.id) },
                                                colors = ButtonDefaults.buttonColors(containerColor = IgnisTechBlue),
                                                shape = RoundedCornerShape(12.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text("Confirm & Prepare Order")
                                            }
                                        }
                                        OrderStatus.SELLER_CONFIRMED, OrderStatus.DELIVERY_REQUESTED -> {
                                            Button(
                                                onClick = { selectedOrderForDelivery = order },
                                                colors = ButtonDefaults.buttonColors(containerColor = IgnisOrangePrimary),
                                                shape = RoundedCornerShape(12.dp),
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Icon(Icons.Filled.TwoWheeler, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text("Assign Nearby Delivery Partner")
                                            }
                                        }
                                        OrderStatus.DELIVERY_ASSIGNED, OrderStatus.PICKED_UP, OrderStatus.ON_THE_WAY -> {
                                            Surface(
                                                color = Color(0xFFDCFCE7),
                                                shape = RoundedCornerShape(10.dp)
                                            ) {
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(10.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    Icon(Icons.Filled.TwoWheeler, contentDescription = null, tint = Color(0xFF166534))
                                                    Text(
                                                        text = "Fulfillment in progress via ${order.deliveryPartnerName ?: "Local Partner"}",
                                                        style = MaterialTheme.typography.bodySmall.copy(
                                                            color = Color(0xFF166534),
                                                            fontWeight = FontWeight.SemiBold
                                                        )
                                                    )
                                                }
                                            }
                                        }
                                        else -> {}
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // Products Management Tab
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Your Innovation Catalog",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            FilledTonalButton(
                                onClick = onAddProductClick,
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("New Product")
                            }
                        }
                    }

                    items(products) { product ->
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(60.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Color(0xFF0F172A))
                                ) {
                                    // Product icon / tag
                                    Icon(
                                        imageVector = Icons.Filled.Bolt,
                                        contentDescription = null,
                                        tint = IgnisOrangePrimary,
                                        modifier = Modifier.align(Alignment.Center)
                                    )
                                }

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = product.name,
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "$${"%.2f".format(product.price)} • Stock: ${product.stock} • Radius: ${product.deliveryAreaKm}km",
                                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Surface(
                                        color = if (product.active) Color(0xFFDCFCE7) else Color(0xFFFFE4E6),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = if (product.active) "Active in Marketplace" else "Paused",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = if (product.active) Color(0xFF166534) else Color(0xFF9F1239),
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 10.sp
                                            ),
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    IconButton(onClick = { onToggleProductActive(product.id) }) {
                                        Icon(
                                            imageVector = if (product.active) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                                            contentDescription = "Toggle Active",
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    IconButton(onClick = { onDeleteProduct(product.id) }) {
                                        Icon(
                                            imageVector = Icons.Filled.DeleteOutline,
                                            contentDescription = "Delete",
                                            tint = Color(0xFFEF4444)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Delivery Partner Selection Bottom Sheet
    if (selectedOrderForDelivery != null) {
        ModalBottomSheet(
            onDismissRequest = { selectedOrderForDelivery = null }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "Assign Delivery Partner for ${selectedOrderForDelivery?.orderNumber}",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "Nearby active couriers within your local dispatch network.",
                    style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )

                deliveryPartners.forEach { partner ->
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        border = CardDefaults.outlinedCardBorder(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .clickable {
                                selectedOrderForDelivery?.let { order ->
                                    onRequestDeliveryPartner(order.id, partner)
                                    selectedOrderForDelivery = null
                                }
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(IgnisEmerald),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = when (partner.vehicle) {
                                        VehicleType.BICYCLE -> Icons.Filled.DirectionsBike
                                        VehicleType.MOTORCYCLE -> Icons.Filled.TwoWheeler
                                        VehicleType.SCOOTER -> Icons.Filled.ElectricScooter
                                        VehicleType.CAR -> Icons.Filled.DirectionsCar
                                        VehicleType.OTHER -> Icons.Filled.LocalShipping
                                    },
                                    contentDescription = null,
                                    tint = Color.White
                                )
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = partner.name,
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "★ ${partner.rating}",
                                        style = MaterialTheme.typography.labelSmall.copy(color = IgnisAmber, fontWeight = FontWeight.Bold)
                                    )
                                }
                                Text(
                                    text = "${partner.vehicle.label} • ${partner.distanceKm} km away • ${partner.completedDeliveries} trips",
                                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }

                            Button(
                                onClick = {
                                    selectedOrderForDelivery?.let { order ->
                                        onRequestDeliveryPartner(order.id, partner)
                                        selectedOrderForDelivery = null
                                    }
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = IgnisEmerald)
                            ) {
                                Text("Assign")
                            }
                        }
                    }
                }
            }
        }
    }
}
