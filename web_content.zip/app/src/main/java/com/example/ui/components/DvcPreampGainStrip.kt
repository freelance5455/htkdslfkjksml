package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated

/**
 * Direct Volume Control (DVC) Preamp Gain Vertical Strip & Fine-Tuning Stage.
 * Regulates pre-DSP signal amplitude before it enters the digital signal processing chain.
 */
@Composable
fun DvcPreampVerticalStrip(
    preampDb: Float,
    onPreampChange: (Float) -> Unit,
    dvcEnabled: Boolean,
    modifier: Modifier = Modifier
) {
    val range = -12f..12f
    val fraction = ((preampDb - range.start) / (range.endInclusive - range.start)).coerceIn(0f, 1f)

    Card(
        modifier = modifier
            .width(82.dp)
            .height(260.dp)
            .testTag("dvc_preamp_vertical_strip"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF141824)),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, if (dvcEnabled) NeonPurple.copy(alpha = 0.7f) else Color.Gray.copy(alpha = 0.3f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(vertical = 10.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header Pill
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = null,
                        tint = if (dvcEnabled) NeonPurple else Color.Gray,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(
                        text = "DVC",
                        color = if (dvcEnabled) NeonPurple else Color.Gray,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
                Text(
                    text = "PREAMP",
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.8.sp
                )
            }

            // Readout Badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(ObsidianBg)
                    .border(1.dp, NeonPurple.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "${if (preampDb > 0) "+" else ""}${String.format("%.1f", preampDb)}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = if (preampDb > 0) NeonPurple else if (preampDb < 0) NeonCyan else Color.White
                )
            }

            // Vertical Interactive Fader Canvas
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .pointerInput(range, preampDb) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            // Drag up to increase dB, down to decrease dB
                            val deltaFraction = -dragAmount.y / (size.height.toFloat())
                            val newDb = (preampDb + deltaFraction * 24f).coerceIn(-12f, 12f)
                            onPreampChange((Math.round(newDb * 10f) / 10f))
                        }
                    }
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onDoubleTap = {
                                onPreampChange(0.0f) // Unity gain reset
                            },
                            onTap = { offset ->
                                val touchedFraction = 1f - (offset.y / size.height).coerceIn(0f, 1f)
                                val newDb = range.start + touchedFraction * 24f
                                onPreampChange((Math.round(newDb * 10f) / 10f))
                            }
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val centerX = w / 2f

                    // Fader slot track
                    val trackW = 6.dp.toPx()
                    drawRoundRect(
                        color = Color(0xFF0A0D14),
                        topLeft = Offset(centerX - trackW / 2f, 0f),
                        size = Size(trackW, h),
                        cornerRadius = CornerRadius(trackW / 2f, trackW / 2f)
                    )

                    // Draw tick marks (+12, +6, 0, -6, -12)
                    val ticks = listOf(12f, 6f, 0f, -6f, -12f)
                    for (t in ticks) {
                        val tickFrac = 1f - ((t - range.start) / 24f)
                        val tickY = tickFrac * h
                        val isCenter = t == 0f
                        drawLine(
                            color = if (isCenter) NeonCyan.copy(alpha = 0.8f) else Color.White.copy(alpha = 0.25f),
                            start = Offset(centerX - (if (isCenter) 14.dp.toPx() else 9.dp.toPx()), tickY),
                            end = Offset(centerX - trackW / 2f - 2.dp.toPx(), tickY),
                            strokeWidth = if (isCenter) 2.dp.toPx() else 1.dp.toPx()
                        )
                    }

                    // Active Fill from center 0dB
                    val centerZeroY = h * 0.5f
                    val knobY = (1f - fraction) * h

                    val fillTop = minOf(centerZeroY, knobY)
                    val fillHeight = kotlin.math.abs(centerZeroY - knobY)
                    if (fillHeight > 1f) {
                        drawRoundRect(
                            brush = Brush.verticalGradient(
                                listOf(NeonPurple, NeonCyan),
                                startY = fillTop,
                                endY = fillTop + fillHeight
                            ),
                            topLeft = Offset(centerX - trackW / 2f, fillTop),
                            size = Size(trackW, fillHeight),
                            cornerRadius = CornerRadius(trackW / 2f, trackW / 2f)
                        )
                    }

                    // Tactile Brushed Metallic Fader Thumb Cap
                    val thumbW = 28.dp.toPx()
                    val thumbH = 14.dp.toPx()
                    val thumbTop = (knobY - thumbH / 2f).coerceIn(0f, h - thumbH)

                    // Glow behind thumb
                    drawRoundRect(
                        color = NeonPurple.copy(alpha = 0.35f),
                        topLeft = Offset(centerX - thumbW / 2f - 2.dp.toPx(), thumbTop - 2.dp.toPx()),
                        size = Size(thumbW + 4.dp.toPx(), thumbH + 4.dp.toPx()),
                        cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                    )

                    // Thumb Body
                    drawRoundRect(
                        brush = Brush.verticalGradient(
                            listOf(Color(0xFF3B4052), Color(0xFF1E222D), Color(0xFF13161F)),
                            startY = thumbTop,
                            endY = thumbTop + thumbH
                        ),
                        topLeft = Offset(centerX - thumbW / 2f, thumbTop),
                        size = Size(thumbW, thumbH),
                        cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx())
                    )

                    // Thumb center indicator line
                    drawLine(
                        color = NeonPurple,
                        start = Offset(centerX - thumbW * 0.35f, thumbTop + thumbH / 2f),
                        end = Offset(centerX + thumbW * 0.35f, thumbTop + thumbH / 2f),
                        strokeWidth = 2.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }
            }

            // Quick Reset / Unity Button
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(SurfaceElevated)
                    .clickable { onPreampChange(0.0f) }
                    .padding(horizontal = 8.dp, vertical = 3.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("0 dB", color = Color.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/**
 * Detailed DVC Preamp Gain Stage Card with Micro Fine-Tuning.
 * Gives exact 0.1 dB step resolution and headroom visualization before signal enters DSP filters.
 */
@Composable
fun DvcPreampGainDetailCard(
    preampDb: Float,
    onPreampChange: (Float) -> Unit,
    dvcEnabled: Boolean,
    onToggleDvc: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("dvc_preamp_detail_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (dvcEnabled) NeonPurple.copy(alpha = 0.5f) else Color.White.copy(alpha = 0.1f)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(NeonPurple.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = null,
                            tint = NeonPurple,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Direct Volume Control (DVC) Preamp",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.5.sp
                        )
                        Text(
                            text = "Pre-DSP Signal Amplitude Calibration",
                            color = NeonPurple,
                            fontSize = 11.sp
                        )
                    }
                }

                // Unity Reset Button
                IconButton(
                    onClick = { onPreampChange(0.0f) },
                    modifier = Modifier.size(30.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.RestartAlt,
                        contentDescription = "Reset Unity Gain",
                        tint = Color.LightGray,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Main Gain readout + status indicator
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Gain Level", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
                    Text(
                        text = "${if (preampDb > 0) "+" else ""}${String.format("%.1f", preampDb)} dB",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (preampDb > 0) NeonPurple else if (preampDb < 0) NeonCyan else Color.White
                    )
                }

                // Headroom Badge
                Column(horizontalAlignment = Alignment.End) {
                    val headroom = (6.0f - preampDb).coerceAtLeast(0f)
                    Text("Dynamic Headroom", fontSize = 11.sp, color = Color.Gray)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFF131722))
                            .border(1.dp, NeonCyan.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "+${String.format("%.1f", headroom)} dB Headroom",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = NeonCyan
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Continuous Slider
            Slider(
                value = preampDb,
                onValueChange = { onPreampChange((Math.round(it * 10f) / 10f)) },
                valueRange = -12f..12f,
                colors = SliderDefaults.colors(
                    thumbColor = NeonPurple,
                    activeTrackColor = NeonPurple,
                    inactiveTrackColor = SurfaceElevated
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dvc_preamp_fine_slider")
            )

            // Micro Fine-Tuning Step Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // -1.0 dB
                FineTuneButton(label = "-1.0 dB") {
                    onPreampChange((preampDb - 1.0f).coerceIn(-12f, 12f))
                }
                // -0.1 dB (Micro-step)
                FineTuneButton(label = "-0.1 dB") {
                    onPreampChange(((Math.round((preampDb - 0.1f) * 10f)) / 10f).coerceIn(-12f, 12f))
                }
                // 0.0 dB Unity
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (preampDb == 0f) NeonPurple else SurfaceElevated)
                        .clickable { onPreampChange(0.0f) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "UNITY 0dB",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (preampDb == 0f) ObsidianBg else Color.White
                    )
                }
                // +0.1 dB (Micro-step)
                FineTuneButton(label = "+0.1 dB") {
                    onPreampChange(((Math.round((preampDb + 0.1f) * 10f)) / 10f).coerceIn(-12f, 12f))
                }
                // +1.0 dB
                FineTuneButton(label = "+1.0 dB") {
                    onPreampChange((preampDb + 1.0f).coerceIn(-12f, 12f))
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Pre-DSP Chain Architecture Diagram
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0F121B))
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ChainStep("32-bit Float Input", isHighlighted = false)
                    Text("➜", color = Color.Gray, fontSize = 11.sp)
                    ChainStep("DVC Preamp Gain", isHighlighted = true, accent = NeonPurple)
                    Text("➜", color = Color.Gray, fontSize = 11.sp)
                    ChainStep("10-Band EQ", isHighlighted = false)
                    Text("➜", color = Color.Gray, fontSize = 11.sp)
                    ChainStep("DAC Out", isHighlighted = false)
                }
            }
        }
    }
}

@Composable
private fun FineTuneButton(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(SurfaceElevated)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            fontSize = 10.5.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color.LightGray
        )
    }
}

@Composable
private fun ChainStep(
    title: String,
    isHighlighted: Boolean,
    accent: Color = NeonCyan
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (isHighlighted) accent.copy(alpha = 0.2f) else Color.Transparent)
            .border(if (isHighlighted) 1.dp else 0.dp, if (isHighlighted) accent else Color.Transparent, RoundedCornerShape(6.dp))
            .padding(horizontal = 6.dp, vertical = 3.dp)
    ) {
        Text(
            text = title,
            fontSize = 9.sp,
            fontWeight = if (isHighlighted) FontWeight.Bold else FontWeight.Normal,
            color = if (isHighlighted) accent else Color.Gray,
            textAlign = TextAlign.Center
        )
    }
}

/**
 * Vertical Fader Strip for a single Equalizer Frequency Band.
 */
@Composable
fun EqualizerVerticalBandFader(
    label: String,
    freq: String,
    value: Float,
    modifier: Modifier = Modifier,
    onValueChange: (Float) -> Unit
) {
    val range = -12f..12f
    val fraction = ((value - range.start) / 24f).coerceIn(0f, 1f)

    Column(
        modifier = modifier
            .width(52.dp)
            .height(260.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(SurfaceDark)
            .padding(vertical = 8.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Frequency Label
        Text(
            text = freq,
            color = NeonCyan,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1
        )

        // Readout
        Text(
            text = "${if (value > 0) "+" else ""}${String.format("%.1f", value)}",
            fontSize = 9.5.sp,
            fontWeight = FontWeight.SemiBold,
            color = if (value > 0) NeonCyan else if (value < 0) NeonPink else Color.LightGray
        )

        // Vertical Slider Canvas
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(vertical = 6.dp)
                .pointerInput(range, value) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        val deltaFraction = -dragAmount.y / (size.height.toFloat())
                        val newVal = (value + deltaFraction * 24f).coerceIn(-12f, 12f)
                        onValueChange((Math.round(newVal * 10f) / 10f))
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures(
                        onDoubleTap = { onValueChange(0f) },
                        onTap = { offset ->
                            val touchedFraction = 1f - (offset.y / size.height).coerceIn(0f, 1f)
                            val newVal = range.start + touchedFraction * 24f
                            onValueChange((Math.round(newVal * 10f) / 10f))
                        }
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val centerX = w / 2f
                val trackW = 4.dp.toPx()

                // Slot
                drawRoundRect(
                    color = Color(0xFF0F131D),
                    topLeft = Offset(centerX - trackW / 2f, 0f),
                    size = Size(trackW, h),
                    cornerRadius = CornerRadius(trackW / 2f, trackW / 2f)
                )

                // 0dB Center tick line
                val centerZeroY = h * 0.5f
                drawLine(
                    color = Color.White.copy(alpha = 0.2f),
                    start = Offset(centerX - 8.dp.toPx(), centerZeroY),
                    end = Offset(centerX + 8.dp.toPx(), centerZeroY),
                    strokeWidth = 1.dp.toPx()
                )

                val knobY = (1f - fraction) * h

                // Active bar from center
                val fillTop = minOf(centerZeroY, knobY)
                val fillHeight = kotlin.math.abs(centerZeroY - knobY)
                if (fillHeight > 1f) {
                    drawRoundRect(
                        color = if (value > 0) NeonCyan else NeonPink,
                        topLeft = Offset(centerX - trackW / 2f, fillTop),
                        size = Size(trackW, fillHeight),
                        cornerRadius = CornerRadius(trackW / 2f, trackW / 2f)
                    )
                }

                // Fader Thumb Cap
                val thumbW = 20.dp.toPx()
                val thumbH = 10.dp.toPx()
                val thumbTop = (knobY - thumbH / 2f).coerceIn(0f, h - thumbH)

                drawRoundRect(
                    color = Color(0xFF2C3242),
                    topLeft = Offset(centerX - thumbW / 2f, thumbTop),
                    size = Size(thumbW, thumbH),
                    cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
                )

                drawLine(
                    color = NeonCyan,
                    start = Offset(centerX - thumbW * 0.3f, thumbTop + thumbH / 2f),
                    end = Offset(centerX + thumbW * 0.3f, thumbTop + thumbH / 2f),
                    strokeWidth = 1.5.dp.toPx()
                )
            }
        }

        // Band Name
        Text(
            text = label.take(4),
            color = Color.Gray,
            fontSize = 8.sp,
            maxLines = 1
        )
    }
}
