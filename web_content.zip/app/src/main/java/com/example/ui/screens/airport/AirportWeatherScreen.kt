package com.example.ui.screens.airport

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.*
import com.example.ui.navigation.Screen
import com.example.ui.theme.*
import com.example.ui.viewmodel.UiState
import com.example.ui.viewmodel.WeatherViewModel

@Composable
fun AirportWeatherScreen(
  viewModel: WeatherViewModel,
  onNavigateTo: (Screen) -> Unit,
  modifier: Modifier = Modifier
) {
  val selectedAirport by viewModel.selectedAirport.collectAsState()
  val metarState by viewModel.metarState.collectAsState()
  val tafState by viewModel.tafState.collectAsState()
  val windState by viewModel.windAloftState.collectAsState()
  val isOffline by viewModel.isOffline.collectAsState()
  val isFav by viewModel.isSelectedFavorite.collectAsState()

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp)
      .testTag("airport_weather_screen"),
    verticalArrangement = Arrangement.spacedBy(14.dp),
    contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
  ) {
    if (isOffline) {
      item { OfflineNoticeBanner() }
    }

    // Airport Header Info Card
    item {
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "${selectedAirport.icao} / ${selectedAirport.iata}",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
              )
              Text(
                text = selectedAirport.nameFa,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
              )
              Text(
                text = selectedAirport.nameEn,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }

            IconButton(onClick = { viewModel.toggleFavorite(selectedAirport.icao) }) {
              Icon(
                imageVector = if (isFav) Icons.Default.Star else Icons.Default.StarBorder,
                contentDescription = "علاقه‌مندی",
                tint = if (isFav) StatusYellow else MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))
          Divider()
          Spacer(modifier = Modifier.height(10.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            AirportSpecItem("موقعیت", "${selectedAirport.cityFa}، ${selectedAirport.countryFa}")
            AirportSpecItem("ارتفاع فرودگاه", "${selectedAirport.elevationFt} FT")
            AirportSpecItem("مختصات", "${selectedAirport.latitude}, ${selectedAirport.longitude}")
            AirportSpecItem("منطقه FIR", selectedAirport.fir)
          }
        }
      }
    }

    // Decoded METAR Overview
    item {
      when (val ms = metarState) {
        is UiState.Success -> {
          val metar = ms.data
          Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            border = CardDefaults.outlinedCardBorder(),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = "وضعیت جوی حاضر (METAR)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                  )
                  if (metar.isSpeci) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(shape = RoundedCornerShape(4.dp), color = StatusRed) {
                      Text("SPECI", color = androidx.compose.ui.graphics.Color.White, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), style = MaterialTheme.typography.labelSmall)
                    }
                  }
                }
                FlightCategoryBadge(category = metar.flightCategory)
              }

              Spacer(modifier = Modifier.height(12.dp))

              // Decoded weather parameters grid
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                DecodedMetricItem("سمت و سرعت باد", "${metar.windDirDeg?.let { "$it°" } ?: "VRB"}/${metar.windSpeedKt ?: 0} KT${metar.windGustKt?.let { " G$it" } ?: ""}")
                DecodedMetricItem("دید افقی", if (metar.isCavok) "CAVOK (>10km)" else "${metar.visibilityMeters?.let { "${it}m" } ?: metar.visibilitySm ?: "--"}")
                DecodedMetricItem("دما / نقطه شبنم", "${metar.tempC ?: "--"}°C / ${metar.dewPointC ?: "--"}°C")
                DecodedMetricItem("فشار فرودگاه QNH", "${metar.altimeterHpa?.toInt()?.let { "Q$it hPa" } ?: "--"}")
              }

              Spacer(modifier = Modifier.height(10.dp))

              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                DecodedMetricItem("ابرها و سقف پرواز", metar.cloudsSummary)
                DecodedMetricItem("پدیده حاضر", metar.presentWeather ?: "بدون پدیده جوی مهم")
                DecodedMetricItem("روند (Trend)", metar.trend ?: "NOSIG")
              }

              Spacer(modifier = Modifier.height(12.dp))
              TextButton(
                onClick = { onNavigateTo(Screen.METAR) },
                modifier = Modifier.align(Alignment.End)
              ) {
                Text("مشاهده جزئیات کامل متار و پیام خام ←")
              }
            }
          }
        }
        is UiState.Loading -> {
          Card(modifier = Modifier.fillMaxWidth()) {
            Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
              CircularProgressIndicator()
            }
          }
        }
        is UiState.Error -> {
          Card(modifier = Modifier.fillMaxWidth()) {
            Text(
              text = "داده‌های متار: ${ms.message}",
              modifier = Modifier.padding(16.dp),
              color = StatusRed
            )
          }
        }
      }
    }

    // Raw METAR snippet
    item {
      when (val ms = metarState) {
        is UiState.Success -> {
          RawMessageCard(
            titleFa = "پیام خام متار (Original Raw METAR)",
            rawText = ms.data.rawMetar,
            source = ms.data.source,
            issueTimeUtc = ms.data.obsTimeUtc,
            isSpeci = ms.data.isSpeci,
            isParsingFailed = ms.data.parsingFailed
          )
        }
        else -> Unit
      }
    }

    // TAF preview card
    item {
      when (val ts = tafState) {
        is UiState.Success -> {
          Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            border = CardDefaults.outlinedCardBorder(),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = "پیش‌بینی فرودگاهی TAF",
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold
                )
                Text(
                  text = "اعتبار: ${ts.data.validFromUtc} تا ${ts.data.validToUtc}",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.primary
                )
              }

              Spacer(modifier = Modifier.height(8.dp))

              Text(
                text = ts.data.rawTaf,
                style = MaterialTheme.typography.bodySmall.copy(
                  fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                ),
                color = MaterialTheme.colorScheme.onSurface
              )

              Spacer(modifier = Modifier.height(10.dp))
              TextButton(
                onClick = { onNavigateTo(Screen.TAF) },
                modifier = Modifier.align(Alignment.End)
              ) {
                Text("مشاهده خط زمانی پیش‌بینی TAF ←")
              }
            }
          }
        }
        is UiState.Loading -> {
          LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        }
        is UiState.Error -> {
          Text(text = "پیش‌بینی تف: ${ts.message}", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
      }
    }

    item { OperationalDisclaimerCard() }
  }
}

@Composable
private fun AirportSpecItem(label: String, value: String) {
  Column {
    Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Text(text = value, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
  }
}

@Composable
private fun DecodedMetricItem(label: String, value: String) {
  Column {
    Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Text(text = value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
  }
}
