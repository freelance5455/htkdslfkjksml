package com.example.ui.screens.airport

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.*
import com.example.ui.navigation.Screen
import com.example.ui.theme.*
import com.example.ui.viewmodel.UiState
import com.example.ui.viewmodel.WeatherViewModel

@Composable
fun AirportWeatherScreen(
  viewModel: WeatherViewModel,
  onNavigateTo: (Screen) -> Unit,
  modifier: Modifier = Modifier
) {
  val selectedAirport by viewModel.selectedAirport.collectAsState()
  val metarState by viewModel.metarState.collectAsState()
  val tafState by viewModel.tafState.collectAsState()
  val isOffline by viewModel.isOffline.collectAsState()
  val isFav by viewModel.isSelectedFavorite.collectAsState()
  val clipboard = LocalClipboardManager.current
  val context = LocalContext.current

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp)
      .testTag("airport_weather_screen"),
    verticalArrangement = Arrangement.spacedBy(14.dp),
    contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
  ) {
    if (isOffline) {
      item { OfflineNoticeBanner() }
    }

    // 1. Station Specification Card (English)
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFCBD5E1)),
        modifier = Modifier.fillMaxWidth().testTag("airport_spec_card")
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = "${selectedAirport.icao} / ${selectedAirport.iata.ifBlank { "ICAO" }}",
                  style = MaterialTheme.typography.headlineMedium,
                  fontWeight = FontWeight.Bold,
                  color = OceanBlue
                )
                Spacer(modifier = Modifier.width(8.dp))
                val isDom = selectedAirport.icao.startsWith("OI") || selectedAirport.countryEn.equals("Iran", ignoreCase = true)
                Surface(
                  shape = RoundedCornerShape(4.dp),
                  color = if (isDom) Color(0xFFF0FDF4) else Color(0xFFFFF7ED)
                ) {
                  Text(
                    text = if (isDom) "DOMESTIC" else "INTERNATIONAL",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDom) Color(0xFF15803D) else Color(0xFFC2410C),
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                  )
                }
              }
              Text(
                text = "${selectedAirport.nameEn} (${selectedAirport.nameFa})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = AtcTextMain
              )
              Text(
                text = "${selectedAirport.cityEn}, ${selectedAirport.countryEn}",
                style = MaterialTheme.typography.bodySmall,
                color = AtcTextMuted
              )
            }

            IconButton(onClick = { viewModel.toggleFavorite(selectedAirport.icao) }) {
              Icon(
                imageVector = if (isFav) Icons.Default.Star else Icons.Default.StarBorder,
                contentDescription = "Favorite",
                tint = if (isFav) StatusYellow else AtcTextMuted
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))
          Divider(color = Color(0xFFE2E8F0))
          Spacer(modifier = Modifier.height(10.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            AirportSpecItem("Location", "${selectedAirport.cityEn}, ${selectedAirport.countryEn}")
            AirportSpecItem("Elevation", "${selectedAirport.elevationFt} FT")
            AirportSpecItem("Coordinates", "${selectedAirport.latitude}, ${selectedAirport.longitude}")
            AirportSpecItem("FIR Area", selectedAirport.fir)
          }
        }
      }
    }

    // 2. PURE RAW METAR CARD - SOFT PURPLE (بنفش ملایم)
    // Controllers already know the codes - only raw format, no explanations
    item {
      when (val ms = metarState) {
        is UiState.Success -> {
          val metar = ms.data
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MetarCardBg),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, MetarCardBorder),
            modifier = Modifier.fillMaxWidth().testTag("airport_raw_metar_card")
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.Terminal, contentDescription = null, tint = MetarCardText, modifier = Modifier.size(20.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = if (metar.isSpeci) "RAW SPECI REPORT" else "RAW METAR REPORT",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MetarCardText
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  FlightCategoryBadge(category = metar.flightCategory)
                }

                IconButton(
                  onClick = {
                    clipboard.setText(AnnotatedString(metar.rawMetar))
                    Toast.makeText(context, "METAR copied", Toast.LENGTH_SHORT).show()
                  },
                  modifier = Modifier.size(32.dp).testTag("btn_copy_airport_metar")
                ) {
                  Icon(Icons.Default.ContentCopy, contentDescription = "Copy raw text", tint = MetarCardText, modifier = Modifier.size(18.dp))
                }
              }

              Spacer(modifier = Modifier.height(10.dp))

              Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color.White.copy(alpha = 0.25f),
                border = androidx.compose.foundation.BorderStroke(1.dp, MetarCardBorder),
                modifier = Modifier.fillMaxWidth()
              ) {
                Text(
                  text = metar.rawMetar.ifBlank { "NO RAW METAR AVAILABLE" },
                  style = MaterialTheme.typography.bodyMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 0.5.sp,
                    lineHeight = 22.sp
                  ),
                  color = MetarCardText,
                  modifier = Modifier.padding(12.dp)
                )
              }

              Spacer(modifier = Modifier.height(10.dp))

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(text = "Obs Time: ${metar.obsTimeUtc}", style = MaterialTheme.typography.labelSmall, color = MetarCardText.copy(alpha = 0.8f))
                Text(text = "Source: ${metar.source}", style = MaterialTheme.typography.labelSmall, color = MetarCardText.copy(alpha = 0.8f))
                TextButton(
                  onClick = { onNavigateTo(Screen.METAR) },
                  contentPadding = PaddingValues(0.dp)
                ) {
                  Text("Open METAR Page →", color = OceanBlue, style = MaterialTheme.typography.labelSmall)
                }
              }
            }
          }
        }
        is UiState.Loading -> {
          Card(modifier = Modifier.fillMaxWidth()) {
            Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
              CircularProgressIndicator(color = OceanBlue)
            }
          }
        }
        is UiState.Error -> {
          Card(modifier = Modifier.fillMaxWidth()) {
            Text(text = "METAR Error: ${ms.message}", modifier = Modifier.padding(16.dp), color = StatusRed)
          }
        }
      }
    }

    // 3. PURE RAW TAF CARD - SOFT GREEN (سبز ملایم)
    item {
      when (val ts = tafState) {
        is UiState.Success -> {
          val taf = ts.data
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = TafCardBg),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, TafCardBorder),
            modifier = Modifier.fillMaxWidth().testTag("airport_raw_taf_card")
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.Schedule, contentDescription = null, tint = TafCardText, modifier = Modifier.size(20.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = "RAW TAF FORECAST",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = TafCardText
                  )
                }

                IconButton(
                  onClick = {
                    clipboard.setText(AnnotatedString(taf.rawTaf))
                    Toast.makeText(context, "TAF copied", Toast.LENGTH_SHORT).show()
                  },
                  modifier = Modifier.size(32.dp).testTag("btn_copy_airport_taf")
                ) {
                  Icon(Icons.Default.ContentCopy, contentDescription = "Copy raw text", tint = TafCardText, modifier = Modifier.size(18.dp))
                }
              }

              Spacer(modifier = Modifier.height(10.dp))

              Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color.White.copy(alpha = 0.25f),
                border = androidx.compose.foundation.BorderStroke(1.dp, TafCardBorder),
                modifier = Modifier.fillMaxWidth()
              ) {
                Text(
                  text = taf.rawTaf.ifBlank { "NO RAW TAF AVAILABLE" },
                  style = MaterialTheme.typography.bodyMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 0.5.sp,
                    lineHeight = 22.sp
                  ),
                  color = TafCardText,
                  modifier = Modifier.padding(12.dp)
                )
              }

              Spacer(modifier = Modifier.height(10.dp))

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(text = "Valid: ${taf.validFromUtc} - ${taf.validToUtc}", style = MaterialTheme.typography.labelSmall, color = TafCardText.copy(alpha = 0.8f))
                Text(text = "Source: ${taf.source}", style = MaterialTheme.typography.labelSmall, color = TafCardText.copy(alpha = 0.8f))
                TextButton(
                  onClick = { onNavigateTo(Screen.TAF) },
                  contentPadding = PaddingValues(0.dp)
                ) {
                  Text("Open TAF Page →", color = OceanBlue, style = MaterialTheme.typography.labelSmall)
                }
              }
            }
          }
        }
        is UiState.Loading -> {
          Card(modifier = Modifier.fillMaxWidth()) {
            Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
              CircularProgressIndicator(color = OceanBlue)
            }
          }
        }
        is UiState.Error -> {
          Card(modifier = Modifier.fillMaxWidth()) {
            Text(text = "TAF Error: ${ts.message}", modifier = Modifier.padding(16.dp), color = AtcTextMuted)
          }
        }
      }
    }

    item { OperationalDisclaimerCard() }
  }
}

@Composable
private fun AirportSpecItem(label: String, value: String) {
  Column {
    Text(text = label, style = MaterialTheme.typography.labelSmall, color = AtcTextMuted)
    Text(text = value, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, color = AtcTextMain)
  }
}
