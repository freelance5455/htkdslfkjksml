package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Gesture
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.example.data.model.AiResultType
import com.example.ui.theme.LavenderContainer
import com.example.ui.theme.LavenderTertiary
import com.example.ui.theme.WaterBlueSoft
import kotlin.math.abs
import kotlin.math.roundToInt

enum class AiGestureAction(val label: String, val directionHint: String) {
    OPEN_AI_SPACE("Open AI Space + Smart Plan", "Swipe ↑ Up or Double-Tap Orb"),
    EMOTIONAL_CALM("AI Calm & Emotional Support", "Swipe ← Left"),
    WAKE_UP_AND_MOTIVATE("Wake Up ☀️ & Motivation Verse", "Swipe → Right"),
    SLEEP_QUIET_TOGGLE("Sleep Quiet Mode", "Swipe ↓ Down"),
    VOICE_OR_PHONE_CONTROL("AI Phone Control", "Draw Circle / Long-Press")
}

@Composable
fun FloatingAiGestureOrb(
    isSubscribed: Boolean,
    onGestureAction: (AiGestureAction) -> Unit,
    modifier: Modifier = Modifier
) {
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    var isPressed by remember { mutableStateOf(false) }
    var showGesturePadDialog by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(targetValue = if (isPressed) 1.12f else 1f, label = "orb_scale")

    Box(
        modifier = modifier
            .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
            .scale(scale)
            .size(58.dp)
            .shadow(10.dp, CircleShape)
            .clip(CircleShape)
            .background(
                Brush.linearGradient(
                    listOf(MaterialTheme.colorScheme.primary, LavenderTertiary)
                )
            )
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        isPressed = true
                        tryAwaitRelease()
                        isPressed = false
                    },
                    onTap = { showGesturePadDialog = true },
                    onDoubleTap = { onGestureAction(AiGestureAction.OPEN_AI_SPACE) },
                    onLongPress = { showGesturePadDialog = true }
                )
            }
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    offsetX += dragAmount.x
                    offsetY += dragAmount.y
                }
            }
            .testTag("floating_ai_gesture_orb"),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Filled.AutoAwesome,
            contentDescription = "AI Gesture Orb: Tap or Long-press for AI Gestures, Double-tap for AI Space, Drag to move",
            tint = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.size(28.dp)
        )
    }

    if (showGesturePadDialog) {
        AlertDialog(
            onDismissRequest = { showGesturePadDialog = false },
            title = { Text("Haven AI Gesture Pad ✨") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Swipe in any direction below, double-tap the floating orb anytime for AI Space, or drag the orb anywhere on screen.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    AiGestureSwipeCanvas(
                        isSubscribed = isSubscribed,
                        onActionTriggered = { action ->
                            showGesturePadDialog = false
                            onGestureAction(action)
                        }
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showGesturePadDialog = false }) { Text("Close") }
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AiGesturePadCard(
    isSubscribed: Boolean,
    onActionTriggered: (AiGestureAction) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth().testTag("ai_gesture_pad_card"),
        colors = CardDefaults.cardColors(containerColor = WaterBlueSoft)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Gesture, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text("AI Gesture Space", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        text = "Draw/swipe a gesture in the pad (or double-tap the floating ✨ AI Orb)",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
            AiGestureSwipeCanvas(
                isSubscribed = isSubscribed,
                onActionTriggered = onActionTriggered
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                AiGestureAction.entries.forEach { act ->
                    AssistChip(
                        onClick = { onActionTriggered(act) },
                        label = {
                            val lockSuffix = if (act == AiGestureAction.VOICE_OR_PHONE_CONTROL && !isSubscribed) " 🔒" else ""
                            Text("${act.directionHint}: ${act.label}$lockSuffix", style = MaterialTheme.typography.labelSmall)
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun AiGestureSwipeCanvas(
    isSubscribed: Boolean,
    onActionTriggered: (AiGestureAction) -> Unit
) {
    val trailPoints = remember { mutableStateListOf<Offset>() }
    var lastGestureLabel by remember { mutableStateOf("Swipe ↑ ↓ ← → or Double-Tap here") }
    val strokeColor = MaterialTheme.colorScheme.primary

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(LavenderContainer)
            .pointerInput(isSubscribed) {
                detectTapGestures(
                    onDoubleTap = {
                        lastGestureLabel = "Double-Tap → AI Space ✨"
                        onActionTriggered(AiGestureAction.OPEN_AI_SPACE)
                    },
                    onLongPress = {
                        lastGestureLabel = "Long-Press → AI Phone Control 📱"
                        onActionTriggered(AiGestureAction.VOICE_OR_PHONE_CONTROL)
                    }
                )
            }
            .pointerInput(isSubscribed) {
                var totalDx = 0f
                var totalDy = 0f
                detectDragGestures(
                    onDragStart = { start ->
                        trailPoints.clear()
                        trailPoints.add(start)
                        totalDx = 0f
                        totalDy = 0f
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        totalDx += dragAmount.x
                        totalDy += dragAmount.y
                        trailPoints.add(change.position)
                    },
                    onDragEnd = {
                        val threshold = 48f
                        val action = when {
                            abs(totalDy) >= abs(totalDx) && totalDy < -threshold -> {
                                lastGestureLabel = "Swipe ↑ Up → Smart AI Plan"
                                AiGestureAction.OPEN_AI_SPACE
                            }
                            abs(totalDy) >= abs(totalDx) && totalDy > threshold -> {
                                lastGestureLabel = "Swipe ↓ Down → Sleep Quiet Mode"
                                AiGestureAction.SLEEP_QUIET_TOGGLE
                            }
                            abs(totalDx) > abs(totalDy) && totalDx > threshold -> {
                                lastGestureLabel = "Swipe → Right → Wake Up & Verse ☀️"
                                AiGestureAction.WAKE_UP_AND_MOTIVATE
                            }
                            abs(totalDx) > abs(totalDy) && totalDx < -threshold -> {
                                lastGestureLabel = "Swipe ← Left → Emotional Support 💙"
                                AiGestureAction.EMOTIONAL_CALM
                            }
                            else -> null
                        }
                        if (action != null) {
                            onActionTriggered(action)
                        }
                        trailPoints.clear()
                    }
                )
            }
            .testTag("ai_gesture_canvas"),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxWidth().height(130.dp)) {
            if (trailPoints.size > 1) {
                val path = Path().apply {
                    moveTo(trailPoints.first().x, trailPoints.first().y)
                    for (i in 1 until trailPoints.size) {
                        lineTo(trailPoints[i].x, trailPoints[i].y)
                    }
                }
                drawPath(
                    path = path,
                    color = strokeColor,
                    style = Stroke(width = 10f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(10.dp)) {
            Text(
                text = lastGestureLabel,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "↑ Smart Plan • ↓ Sleep Quiet • → Wake & Verse • ← Calm • Double-Tap",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

fun AiGestureAction.toAiResultType(): AiResultType = when (this) {
    AiGestureAction.OPEN_AI_SPACE -> AiResultType.ACTION_PLAN
    AiGestureAction.EMOTIONAL_CALM -> AiResultType.EMOTIONAL_SUPPORT
    AiGestureAction.WAKE_UP_AND_MOTIVATE -> AiResultType.MOTIVATION_VERSE
    AiGestureAction.SLEEP_QUIET_TOGGLE -> AiResultType.EMOTIONAL_SUPPORT
    AiGestureAction.VOICE_OR_PHONE_CONTROL -> AiResultType.PHONE_COMMAND
}
