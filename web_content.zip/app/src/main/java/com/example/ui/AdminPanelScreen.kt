package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.CreditTransaction
import com.example.data.UserAccount
import java.text.SimpleDateFormat
import java.util.Locale

@Composable
fun AdminPanelScreen(
    viewModel: AdminViewModel,
    onBackToEditor: () -> Unit,
    modifier: Modifier = Modifier,
) {
  val accountState by viewModel.currentAccountState.collectAsStateWithLifecycle()
  val usersState by viewModel.allUsersState.collectAsStateWithLifecycle()
  val transactionsState by viewModel.transactionsState.collectAsStateWithLifecycle()
  val actionState by viewModel.actionState.collectAsStateWithLifecycle()
  val initError by viewModel.profileInitError.collectAsStateWithLifecycle()

  var selectedTab by remember { mutableIntStateOf(0) }
  var searchQuery by remember { mutableStateOf("") }
  var selfAmountInput by remember { mutableStateOf("50") }
  var selfReasonInput by remember { mutableStateOf("Admin self top-up") }
  var selectedTargetUser by remember { mutableStateOf<UserAccount?>(null) }

  val currentAccount = (accountState as? UiState.Success)?.data
  val isAdmin = currentAccount?.isAdmin == true
  val isProcessing = actionState is AdminActionState.Processing

  Box(
      modifier =
          modifier
              .fillMaxSize()
              .background(Color(0xFF080A0F)),
      contentAlignment = Alignment.TopCenter,
  ) {
    Column(
        modifier = Modifier.widthIn(max = 920.dp).fillMaxSize(),
    ) {
      // Header Bar
      Row(
          modifier =
              Modifier.fillMaxWidth()
                  .background(Color(0xFF101521))
                  .border(1.dp, Color.White.copy(alpha = 0.08f))
                  .padding(horizontal = 12.dp, vertical = 10.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        IconButton(
            onClick = onBackToEditor,
            modifier = Modifier.minimumInteractiveComponentSize().testTag("back_to_editor_btn"),
        ) {
          Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Back to Photo Editor",
              tint = Color(0xFFF1F5F9),
          )
        }

        Column(modifier = Modifier.weight(1f)) {
          Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            Text(
                text = if (isAdmin) "Admin Credit Panel" else "Credit Wallet",
                color = Color(0xFFF1F5F9),
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
            )
            if (isAdmin) {
              Box(
                  modifier =
                      Modifier.clip(RoundedCornerShape(99.dp))
                          .background(Color(0xFF00D2FF).copy(alpha = 0.16f))
                          .border(1.dp, Color(0xFF00D2FF).copy(alpha = 0.45f), RoundedCornerShape(99.dp))
                          .padding(horizontal = 8.dp, vertical = 2.dp),
              ) {
                Text(
                    text = "ADMIN",
                    color = Color(0xFF00D2FF),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                )
              }
            }
          }
          Text(
              text = currentAccount?.email ?: "Loading account...",
              color = Color(0xFF94A3B8),
              fontSize = 12.sp,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
          )
        }

        Surface(
            shape = RoundedCornerShape(99.dp),
            color = Color(0xFF182235),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00D2FF).copy(alpha = 0.35f)),
        ) {
          Row(
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(5.dp),
          ) {
            Icon(
                imageVector = Icons.Filled.Bolt,
                contentDescription = "Credit balance",
                tint = Color(0xFF00D2FF),
                modifier = Modifier.size(16.dp),
            )
            Text(
                text = "${currentAccount?.credits ?: 0} Credits",
                color = Color(0xFFF1F5F9),
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
            )
          }
        }
      }

      // Action Feedback Banner
      if (initError != null) {
        StatusBanner(
            text = initError ?: "",
            isError = true,
            onDismiss = { viewModel.ensureProfile() },
            actionLabel = "Retry",
        )
      }
      when (val st = actionState) {
        is AdminActionState.Success ->
            StatusBanner(
                text = st.message,
                isError = false,
                onDismiss = { viewModel.clearActionState() },
                actionLabel = "Dismiss",
            )
        is AdminActionState.Error ->
            StatusBanner(
                text = st.message,
                isError = true,
                onDismiss = { viewModel.clearActionState() },
                actionLabel = "Dismiss",
            )
        else -> Unit
      }

      if (accountState is UiState.Loading) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
          CircularProgressIndicator(color = Color(0xFF00D2FF))
        }
      } else if (accountState is UiState.Error) {
        val msg = (accountState as UiState.Error).message
        Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
          Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(text = msg, color = Color(0xFFFCA5A5))
            Button(onClick = { viewModel.ensureProfile() }) { Text("Retry") }
          }
        }
      } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
          // Admin Quick Self-Top-Up Card
          if (currentAccount != null && currentAccount.isAdmin) {
            item {
              SelfCreditTopUpCard(
                  account = currentAccount,
                  amountText = selfAmountInput,
                  onAmountChange = { selfAmountInput = it.filter { ch -> ch.isDigit() } },
                  reasonText = selfReasonInput,
                  onReasonChange = { selfReasonInput = it },
                  isProcessing = isProcessing,
                  onQuickAdd = { preset ->
                    viewModel.adjustCredits(
                        targetUid = currentAccount.uid,
                        targetLabel = "your account",
                        delta = preset,
                        reason = selfReasonInput.ifBlank { "Admin quick top-up (+$preset)" },
                    )
                  },
                  onCustomAdd = {
                    val amt = selfAmountInput.toLongOrNull() ?: 0L
                    viewModel.adjustCredits(
                        targetUid = currentAccount.uid,
                        targetLabel = "your account",
                        delta = amt,
                        reason = selfReasonInput,
                    )
                  },
              )
            }
          }

          // Tabs: Accounts & Ledger (or Wallet History for non-admin)
          item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              if (isAdmin) {
                FilterChip(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    label = { Text("User Accounts") },
                    leadingIcon = {
                      Icon(Icons.Filled.People, contentDescription = null, modifier = Modifier.size(16.dp))
                    },
                    colors =
                        FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF00D2FF).copy(alpha = 0.18f),
                            selectedLabelColor = Color(0xFF00D2FF),
                            selectedLeadingIconColor = Color(0xFF00D2FF),
                        ),
                )
              }
              FilterChip(
                  selected = !isAdmin || selectedTab == 1,
                  onClick = { selectedTab = 1 },
                  label = { Text(if (isAdmin) "Transaction Ledger" else "My Credit History") },
                  leadingIcon = {
                    Icon(Icons.Filled.History, contentDescription = null, modifier = Modifier.size(16.dp))
                  },
                  colors =
                      FilterChipDefaults.filterChipColors(
                          selectedContainerColor = Color(0xFF00D2FF).copy(alpha = 0.18f),
                          selectedLabelColor = Color(0xFF00D2FF),
                          selectedLeadingIconColor = Color(0xFF00D2FF),
                      ),
              )
            }
          }

          if (isAdmin && selectedTab == 0) {
            val allUsers = (usersState as? UiState.Success)?.data ?: emptyList()
            val totalCredits = allUsers.sumOf { it.credits }

            item {
              Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(10.dp),
              ) {
                MetricTile(
                    label = "Total Accounts",
                    value = "${allUsers.size}",
                    modifier = Modifier.weight(1f),
                )
                MetricTile(
                    label = "Total Credits Issued",
                    value = "$totalCredits",
                    modifier = Modifier.weight(1f),
                )
              }
            }

            item {
              OutlinedTextField(
                  value = searchQuery,
                  onValueChange = { searchQuery = it },
                  modifier = Modifier.fillMaxWidth().testTag("admin_user_search"),
                  placeholder = { Text("Search users by name, email, or UID...") },
                  leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                  singleLine = true,
                  shape = RoundedCornerShape(12.dp),
                  colors = darkFieldColors(),
              )
            }

            when (val uState = usersState) {
              is UiState.Loading -> {
                item {
                  Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Color(0xFF00D2FF))
                  }
                }
              }
              is UiState.Error -> {
                item {
                  Text(text = uState.message, color = Color(0xFFFCA5A5))
                }
              }
              is UiState.Success -> {
                val filtered =
                    uState.data.filter { user ->
                      val q = searchQuery.trim()
                      q.isEmpty() ||
                          user.email.contains(q, ignoreCase = true) ||
                          user.displayName.contains(q, ignoreCase = true) ||
                          user.uid.contains(q, ignoreCase = true)
                    }
                if (filtered.isEmpty()) {
                  item {
                    EmptyCard("No matching user accounts found. Users appear automatically once they sign in with Google.")
                  }
                } else {
                  items(filtered, key = { it.uid }) { user ->
                    UserAccountRow(
                        account = user,
                        isSelf = user.uid == currentAccount?.uid,
                        onManageClick = { selectedTargetUser = user },
                    )
                  }
                }
              }
            }
          } else {
            // Transactions Tab (Admin Ledger or User History)
            if (!isAdmin) {
              item {
                EmptyCard(
                    "Standard user account active. Only authorized admins (${UserAccount.BOOTSTRAPPED_ADMIN_EMAIL} or promoted admins) can grant credits to accounts."
                )
              }
            }
            when (val tState = transactionsState) {
              is UiState.Loading -> {
                item {
                  Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Color(0xFF00D2FF))
                  }
                }
              }
              is UiState.Error -> {
                item { Text(text = tState.message, color = Color(0xFFFCA5A5)) }
              }
              is UiState.Success -> {
                if (tState.data.isEmpty()) {
                  item { EmptyCard("No credit transactions recorded yet.") }
                } else {
                  items(tState.data, key = { it.id }) { tx ->
                    TransactionRow(tx)
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  // Manage Target User Credits Dialog
  val targetUser = selectedTargetUser
  if (targetUser != null) {
    ManageUserCreditsDialog(
        target = targetUser,
        isProcessing = isProcessing,
        onDismiss = { selectedTargetUser = null },
        onApplyCredits = { delta, reason ->
          viewModel.adjustCredits(
              targetUid = targetUser.uid,
              targetLabel = targetUser.email,
              delta = delta,
              reason = reason,
          )
          selectedTargetUser = null
        },
        onToggleAdmin = { makeAdmin ->
          viewModel.toggleAdminRole(targetUser, makeAdmin)
          selectedTargetUser = null
        },
    )
  }
}

@Composable
private fun SelfCreditTopUpCard(
    account: UserAccount,
    amountText: String,
    onAmountChange: (String) -> Unit,
    reasonText: String,
    onReasonChange: (String) -> Unit,
    isProcessing: Boolean,
    onQuickAdd: (Long) -> Unit,
    onCustomAdd: () -> Unit,
) {
  Column(
      modifier =
          Modifier.fillMaxWidth()
              .clip(RoundedCornerShape(16.dp))
              .background(
                  Brush.linearGradient(
                      colors = listOf(Color(0xFF11192B), Color(0xFF151C32))
                  )
              )
              .border(1.dp, Color(0xFF00D2FF).copy(alpha = 0.28f), RoundedCornerShape(16.dp))
              .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Icon(
          imageVector = Icons.Filled.AdminPanelSettings,
          contentDescription = null,
          tint = Color(0xFF00D2FF),
      )
      Text(
          text = "Add Credits to My Account (${account.displayName})",
          color = Color(0xFFF1F5F9),
          fontWeight = FontWeight.Bold,
          fontSize = 15.sp,
      )
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      listOf(10L, 50L, 100L, 500L).forEach { preset ->
        OutlinedButton(
            onClick = { onQuickAdd(preset) },
            enabled = !isProcessing,
            modifier = Modifier.weight(1f).minimumInteractiveComponentSize(),
            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp),
            shape = RoundedCornerShape(10.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00D2FF).copy(alpha = 0.4f)),
        ) {
          Text(
              text = "+$preset",
              color = Color(0xFF00D2FF),
              fontWeight = FontWeight.Bold,
              fontSize = 13.sp,
          )
        }
      }
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
      OutlinedTextField(
          value = amountText,
          onValueChange = onAmountChange,
          label = { Text("Custom Credits") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          singleLine = true,
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(10.dp),
          colors = darkFieldColors(),
      )
      OutlinedTextField(
          value = reasonText,
          onValueChange = onReasonChange,
          label = { Text("Reason / Note") },
          singleLine = true,
          modifier = Modifier.weight(1.4f),
          shape = RoundedCornerShape(10.dp),
          colors = darkFieldColors(),
      )
    }

    Button(
        onClick = onCustomAdd,
        enabled = !isProcessing && (amountText.toLongOrNull() ?: 0L) > 0L,
        modifier =
            Modifier.fillMaxWidth()
                .height(48.dp)
                .minimumInteractiveComponentSize()
                .testTag("add_self_credit_button"),
        shape = RoundedCornerShape(10.dp),
        colors =
            ButtonDefaults.buttonColors(
                containerColor = Color(0xFF00D2FF),
                contentColor = Color(0xFF050811),
            ),
    ) {
      Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
      Spacer(modifier = Modifier.width(6.dp))
      Text(
          text = "Add ${amountText.ifBlank { "0" }} Credits to My Account",
          fontWeight = FontWeight.Bold,
      )
    }
  }
}

@Composable
private fun UserAccountRow(
    account: UserAccount,
    isSelf: Boolean,
    onManageClick: () -> Unit,
) {
  Row(
      modifier =
          Modifier.fillMaxWidth()
              .clip(RoundedCornerShape(14.dp))
              .background(Color(0xFF111622))
              .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(14.dp))
              .clickable(onClick = onManageClick)
              .padding(14.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    Box(
        modifier =
            Modifier.size(42.dp)
                .clip(CircleShape)
                .background(
                    if (account.isAdmin) Color(0xFF00D2FF).copy(alpha = 0.2f)
                    else Color(0xFF6366F1).copy(alpha = 0.22f)
                ),
        contentAlignment = Alignment.Center,
    ) {
      Text(
          text = account.displayName.firstOrNull()?.uppercase() ?: "U",
          color = if (account.isAdmin) Color(0xFF00D2FF) else Color(0xFFA5B4FC),
          fontWeight = FontWeight.Bold,
          fontSize = 16.sp,
      )
    }

    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
      Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        Text(
            text = account.displayName + if (isSelf) " (You)" else "",
            color = Color(0xFFF1F5F9),
            fontWeight = FontWeight.SemiBold,
            fontSize = 14.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        if (account.isAdmin) {
          Icon(
              imageVector = Icons.Filled.Shield,
              contentDescription = "Admin",
              tint = Color(0xFF00D2FF),
              modifier = Modifier.size(14.dp),
          )
        }
      }
      Text(
          text = account.email,
          color = Color(0xFF94A3B8),
          fontSize = 12.sp,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
      )
    }

    Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
      Text(
          text = "${account.credits} cr",
          color = Color(0xFF00D2FF),
          fontWeight = FontWeight.Bold,
          fontSize = 14.sp,
      )
      Button(
          onClick = onManageClick,
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
          modifier = Modifier.height(34.dp).minimumInteractiveComponentSize(),
          shape = RoundedCornerShape(8.dp),
          colors =
              ButtonDefaults.buttonColors(
                  containerColor = Color(0xFF1E293B),
                  contentColor = Color(0xFFF1F5F9),
              ),
      ) {
        Text("Manage", fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
      }
    }
  }
}

@Composable
private fun ManageUserCreditsDialog(
    target: UserAccount,
    isProcessing: Boolean,
    onDismiss: () -> Unit,
    onApplyCredits: (Long, String) -> Unit,
    onToggleAdmin: (Boolean) -> Unit,
) {
  var isAddMode by remember { mutableStateOf(true) }
  var amountText by remember { mutableStateOf("50") }
  var reasonText by remember { mutableStateOf("Admin credit adjustment") }
  val isPrimaryOwner = target.email.equals(UserAccount.BOOTSTRAPPED_ADMIN_EMAIL, ignoreCase = true)

  AlertDialog(
      onDismissRequest = onDismiss,
      containerColor = Color(0xFF101521),
      titleContentColor = Color(0xFFF1F5F9),
      textContentColor = Color(0xFFCBD5E1),
      title = {
        Column {
          Text(target.displayName, fontWeight = FontWeight.Bold, fontSize = 17.sp)
          Text(target.email, color = Color(0xFF94A3B8), fontSize = 12.sp)
          Text(
              "Current Balance: ${target.credits} credits",
              color = Color(0xFF00D2FF),
              fontWeight = FontWeight.SemiBold,
              fontSize = 13.sp,
          )
        }
      },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = isAddMode,
                onClick = { isAddMode = true },
                label = { Text("Add Credits") },
                leadingIcon = { Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp)) },
                modifier = Modifier.weight(1f),
            )
            FilterChip(
                selected = !isAddMode,
                onClick = { isAddMode = false },
                label = { Text("Deduct") },
                leadingIcon = { Icon(Icons.Filled.Remove, contentDescription = null, modifier = Modifier.size(16.dp)) },
                modifier = Modifier.weight(1f),
            )
          }

          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("10", "25", "100", "250").forEach { preset ->
              OutlinedButton(
                  onClick = { amountText = preset },
                  modifier = Modifier.weight(1f),
                  contentPadding = PaddingValues(0.dp),
              ) {
                Text(preset, fontSize = 12.sp, color = Color(0xFF00D2FF))
              }
            }
          }

          OutlinedTextField(
              value = amountText,
              onValueChange = { amountText = it.filter { ch -> ch.isDigit() } },
              label = { Text("Amount") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              singleLine = true,
              modifier = Modifier.fillMaxWidth(),
              colors = darkFieldColors(),
          )

          OutlinedTextField(
              value = reasonText,
              onValueChange = { reasonText = it },
              label = { Text("Reason / Note") },
              singleLine = true,
              modifier = Modifier.fillMaxWidth(),
              colors = darkFieldColors(),
          )

          if (!isPrimaryOwner) {
            Row(
                modifier =
                    Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.White.copy(alpha = 0.04f))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text("Admin Role", color = Color(0xFFF1F5F9), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text("Allow granting credits to accounts", color = Color(0xFF94A3B8), fontSize = 11.sp)
              }
              Switch(
                  checked = target.isAdmin,
                  onCheckedChange = { onToggleAdmin(it) },
              )
            }
          }
        }
      },
      confirmButton = {
        val raw = amountText.toLongOrNull() ?: 0L
        val delta = if (isAddMode) raw else -raw
        Button(
            onClick = { onApplyCredits(delta, reasonText) },
            enabled = !isProcessing && raw > 0L,
            colors =
                ButtonDefaults.buttonColors(
                    containerColor = if (isAddMode) Color(0xFF00D2FF) else Color(0xFFEF4444),
                    contentColor = if (isAddMode) Color(0xFF050811) else Color.White,
                ),
        ) {
          Text(if (isAddMode) "Add +$raw" else "Deduct -$raw", fontWeight = FontWeight.Bold)
        }
      },
      dismissButton = {
        TextButton(onClick = onDismiss) { Text("Cancel", color = Color(0xFF94A3B8)) }
      },
  )
}

@Composable
private fun TransactionRow(tx: CreditTransaction) {
  val isPositive = tx.amount >= 0
  val formatter = remember { SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()) }
  val dateStr = tx.createdAt?.toDate()?.let { formatter.format(it) } ?: "Just now"

  Row(
      modifier =
          Modifier.fillMaxWidth()
              .clip(RoundedCornerShape(12.dp))
              .background(Color(0xFF111622))
              .border(1.dp, Color.White.copy(alpha = 0.07f), RoundedCornerShape(12.dp))
              .padding(12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    Box(
        modifier =
            Modifier.clip(RoundedCornerShape(8.dp))
                .background(
                    if (isPositive) Color(0xFF10B981).copy(alpha = 0.16f)
                    else Color(0xFFF59E0B).copy(alpha = 0.16f)
                )
                .padding(horizontal = 10.dp, vertical = 6.dp),
    ) {
      Text(
          text = if (isPositive) "+${tx.amount}" else "${tx.amount}",
          color = if (isPositive) Color(0xFF6EE7B7) else Color(0xFFFCD34D),
          fontWeight = FontWeight.Bold,
          fontSize = 13.sp,
      )
    }

    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
      Text(
          text = tx.reason,
          color = Color(0xFFF1F5F9),
          fontWeight = FontWeight.Medium,
          fontSize = 13.sp,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
      )
      Text(
          text = "To: ${tx.targetEmail} • By: ${tx.adminEmail}",
          color = Color(0xFF94A3B8),
          fontSize = 11.sp,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
      )
    }

    Column(horizontalAlignment = Alignment.End) {
      Text("Bal: ${tx.balanceAfter}", color = Color(0xFFCBD5E1), fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
      Text(dateStr, color = Color(0xFF64748B), fontSize = 10.5.sp)
    }
  }
}

@Composable
private fun MetricTile(label: String, value: String, modifier: Modifier = Modifier) {
  Column(
      modifier =
          modifier
              .clip(RoundedCornerShape(14.dp))
              .background(Color(0xFF111622))
              .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(14.dp))
              .padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(4.dp),
  ) {
    Text(label, color = Color(0xFF94A3B8), fontSize = 11.5.sp)
    Text(value, color = Color(0xFFF1F5F9), fontWeight = FontWeight.Bold, fontSize = 22.sp)
  }
}

@Composable
private fun EmptyCard(text: String) {
  Box(
      modifier =
          Modifier.fillMaxWidth()
              .clip(RoundedCornerShape(12.dp))
              .background(Color(0xFF111622))
              .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
              .padding(16.dp),
  ) {
    Text(text = text, color = Color(0xFF94A3B8), fontSize = 12.5.sp)
  }
}

@Composable
private fun StatusBanner(
    text: String,
    isError: Boolean,
    onDismiss: () -> Unit,
    actionLabel: String,
) {
  Row(
      modifier =
          Modifier.fillMaxWidth()
              .background(
                  if (isError) Color(0xFFEF4444).copy(alpha = 0.16f)
                  else Color(0xFF10B981).copy(alpha = 0.16f)
              )
              .padding(horizontal = 14.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Row(
        modifier = Modifier.weight(1f),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Icon(
          imageVector = Icons.Filled.CheckCircle,
          contentDescription = null,
          tint = if (isError) Color(0xFFFCA5A5) else Color(0xFF6EE7B7),
          modifier = Modifier.size(16.dp),
      )
      Text(
          text = text,
          color = if (isError) Color(0xFFFCA5A5) else Color(0xFFA7F3D0),
          fontSize = 12.sp,
      )
    }
    TextButton(onClick = onDismiss) {
      Text(actionLabel, color = Color(0xFF00D2FF), fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
  }
}

@Composable
private fun darkFieldColors() =
    OutlinedTextFieldDefaults.colors(
        focusedTextColor = Color(0xFFF1F5F9),
        unfocusedTextColor = Color(0xFFF1F5F9),
        focusedBorderColor = Color(0xFF00D2FF),
        unfocusedBorderColor = Color.White.copy(alpha = 0.16f),
        focusedLabelColor = Color(0xFF00D2FF),
        unfocusedLabelColor = Color(0xFF94A3B8),
        focusedPlaceholderColor = Color(0xFF64748B),
        unfocusedPlaceholderColor = Color(0xFF64748B),
        cursorColor = Color(0xFF00D2FF),
    )
