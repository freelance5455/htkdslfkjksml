package com.example.ui

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.CreditRepository
import com.example.data.CreditTransaction
import com.example.data.UserAccount
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface UiState<out T> {
  data object Loading : UiState<Nothing>

  data class Success<T>(val data: T) : UiState<T>

  data class Error(val message: String) : UiState<Nothing>
}

sealed interface AdminActionState {
  data object Idle : AdminActionState

  data object Processing : AdminActionState

  data class Success(val message: String) : AdminActionState

  data class Error(val message: String) : AdminActionState
}

@OptIn(ExperimentalCoroutinesApi::class)
class AdminViewModel(
    private val repository: CreditRepository,
    private val currentUserId: String,
    private val currentUserEmail: String,
) : ViewModel() {

  private val _actionState = MutableStateFlow<AdminActionState>(AdminActionState.Idle)
  val actionState: StateFlow<AdminActionState> = _actionState.asStateFlow()

  private val _profileInitError = MutableStateFlow<String?>(null)
  val profileInitError: StateFlow<String?> = _profileInitError.asStateFlow()

  val currentAccountState: StateFlow<UiState<UserAccount?>> =
      repository
          .observeCurrentUser(currentUserId)
          .map<UserAccount?, UiState<UserAccount?>> { UiState.Success(it) }
          .catch { error ->
            val firestoreError =
                generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val rootError = firestoreError ?: error
            Log.w(TAG, "Error observing current account", rootError)
            emit(UiState.Error(rootError.localizedMessage ?: "Failed to load account"))
          }
          .stateIn(
              scope = viewModelScope,
              started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
              initialValue = UiState.Loading,
          )

  val allUsersState: StateFlow<UiState<List<UserAccount>>> =
      currentAccountState
          .flatMapLatest { accountState ->
            when (accountState) {
              is UiState.Loading -> flowOf(UiState.Loading)
              is UiState.Error -> flowOf(UiState.Error(accountState.message))
              is UiState.Success -> {
                val acct = accountState.data
                val isAdmin =
                    acct?.isAdmin == true ||
                        currentUserEmail.equals(
                            UserAccount.BOOTSTRAPPED_ADMIN_EMAIL,
                            ignoreCase = true,
                        )
                if (acct != null && isAdmin) {
                  repository
                      .observeAllUsers()
                      .map<List<UserAccount>, UiState<List<UserAccount>>> { UiState.Success(it) }
                      .catch { error ->
                        val firestoreError =
                            generateSequence(error) { it.cause }
                                .filterIsInstance<FirebaseFirestoreException>()
                                .firstOrNull()
                        if (firestoreError == null && error is CancellationException) throw error
                        val rootError = firestoreError ?: error
                        Log.w(TAG, "Error observing all users", rootError)
                        emit(
                            UiState.Error(
                                rootError.localizedMessage ?: "Failed to load user accounts"
                            )
                        )
                      }
                } else {
                  flowOf(UiState.Success(emptyList()))
                }
              }
            }
          }
          .stateIn(
              scope = viewModelScope,
              started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
              initialValue = UiState.Loading,
          )

  val transactionsState: StateFlow<UiState<List<CreditTransaction>>> =
      currentAccountState
          .flatMapLatest { accountState ->
            when (accountState) {
              is UiState.Loading -> flowOf(UiState.Loading)
              is UiState.Error -> flowOf(UiState.Error(accountState.message))
              is UiState.Success -> {
                val acct = accountState.data
                if (acct == null) {
                  flowOf(UiState.Success(emptyList()))
                } else {
                  val isAdmin =
                      acct.isAdmin ||
                          currentUserEmail.equals(
                              UserAccount.BOOTSTRAPPED_ADMIN_EMAIL,
                              ignoreCase = true,
                          )
                  repository
                      .observeTransactions(currentUserId, isAdmin)
                      .map<List<CreditTransaction>, UiState<List<CreditTransaction>>> {
                        UiState.Success(it)
                      }
                      .catch { error ->
                        val firestoreError =
                            generateSequence(error) { it.cause }
                                .filterIsInstance<FirebaseFirestoreException>()
                                .firstOrNull()
                        if (firestoreError == null && error is CancellationException) throw error
                        val rootError = firestoreError ?: error
                        Log.w(TAG, "Error observing credit transactions", rootError)
                        emit(
                            UiState.Error(
                                rootError.localizedMessage ?: "Failed to load credit history"
                            )
                        )
                      }
                }
              }
            }
          }
          .stateIn(
              scope = viewModelScope,
              started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
              initialValue = UiState.Loading,
          )

  init {
    ensureProfile()
  }

  fun ensureProfile() {
    viewModelScope.launch {
      _profileInitError.value = null
      val result = repository.ensureUserProfile()
      result.onFailure { err ->
        _profileInitError.value = err.localizedMessage ?: "Could not initialize user profile"
      }
    }
  }

  fun adjustCredits(targetUid: String, targetLabel: String, delta: Long, reason: String) {
    if (delta == 0L) {
      _actionState.value = AdminActionState.Error("Credit amount must be greater than zero.")
      return
    }
    viewModelScope.launch {
      _actionState.value = AdminActionState.Processing
      val result = repository.adjustUserCredits(targetUid, delta, reason)
      result.fold(
          onSuccess = { newBalance ->
            val verb = if (delta > 0) "Added +$delta" else "Deducted ${-delta}"
            _actionState.value =
                AdminActionState.Success("$verb credits for $targetLabel (New balance: $newBalance)")
          },
          onFailure = { err ->
            _actionState.value =
                AdminActionState.Error(err.localizedMessage ?: "Credit update failed.")
          },
      )
    }
  }

  fun toggleAdminRole(account: UserAccount, makeAdmin: Boolean) {
    viewModelScope.launch {
      _actionState.value = AdminActionState.Processing
      val result = repository.setAdminRole(account, makeAdmin)
      result.fold(
          onSuccess = {
            val status = if (makeAdmin) "promoted to Admin" else "set to Standard User"
            _actionState.value = AdminActionState.Success("${account.email} $status.")
          },
          onFailure = { err ->
            _actionState.value =
                AdminActionState.Error(err.localizedMessage ?: "Failed to update user role.")
          },
      )
    }
  }

  fun clearActionState() {
    _actionState.value = AdminActionState.Idle
  }

  private companion object {
    const val TAG = "AdminVM"
    const val STOP_TIMEOUT_MILLIS = 5000L
  }
}
