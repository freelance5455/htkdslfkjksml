package com.example.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.data.models.MediaItem
import com.example.data.models.MediaType
import com.example.data.models.ScreenDestination
import com.example.ui.theme.HazimCyan
import com.example.ui.theme.HazimDarkBackground
import com.example.ui.theme.HazimDarkBorder
import com.example.ui.theme.HazimDarkSurface
import com.example.ui.theme.HazimDarkSurfaceVariant
import com.example.ui.theme.HazimEmerald
import com.example.ui.theme.HazimPurple
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import com.example.ui.theme.TextTertiaryDark
import com.example.viewmodel.HazimAiViewModel

@Composable
fun GalleryScreen(
    viewModel: HazimAiViewModel,
    onOpenDrawer: () -> Unit
) {
    val context = LocalContext.current
    val galleryFilter by viewModel.galleryFilter.collectAsState()
    val galleryItems by viewModel.galleryItems.collectAsState()
    val selectedItem by viewModel.selectedGalleryItem.collectAsState()

    val isPlayingVoice by viewModel.ttsEngine.isPlaying.collectAsState()
    val isVideoPlaying by viewModel.isVideoPlaying.collectAsState()
    val videoProgress by viewModel.videoProgress.collectAsState()

    val filters = listOf(
        Pair("ALL", "All Creations"),
        Pair("IMAGE", "Images (TTI)"),
        Pair("VIDEO", "Videos (ITV)"),
        Pair("AUDIO", "Voices (STV)")
    )

    val filteredItems = when (galleryFilter) {
        "IMAGE" -> galleryItems.filter { it.type == MediaType.IMAGE }
        "VIDEO" -> galleryItems.filter { it.type == MediaType.VIDEO }
        "AUDIO" -> galleryItems.filter { it.type == MediaType.AUDIO }
        else -> galleryItems
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(HazimDarkBackground)
            .navigationBarsPadding()
    ) {
        // Top Bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = HazimDarkBackground
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onOpenDrawer,
                    modifier = Modifier.testTag("gallery_open_drawer_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Menu,
                        contentDescription = "Menu",
                        tint = TextPrimaryDark
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                Column {
                    Text(
                        text = "My Gallery",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryDark
                    )
                    Text(
                        text = "${galleryItems.size} generated creations",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondaryDark,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Filter Chips Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            filters.forEach { (code, label) ->
                val isSelected = galleryFilter == code
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .border(
                            1.dp,
                            if (isSelected) HazimCyan else HazimDarkBorder,
                            RoundedCornerShape(10.dp)
                        )
                        .clickable { viewModel.setGalleryFilter(code) },
                    color = if (isSelected) HazimCyan.copy(alpha = 0.2f) else HazimDarkSurface
                ) {
                    Box(
                        modifier = Modifier.padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = when (code) {
                                "ALL" -> "All"
                                "IMAGE" -> "TTI"
                                "VIDEO" -> "ITV"
                                "AUDIO" -> "STV"
                                else -> code
                            },
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) HazimCyan else TextSecondaryDark
                        )
                    }
                }
            }
        }

        // Gallery Grid
        if (filteredItems.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "No creations found in this category",
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryDark,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Generate some artwork with TTI, videos with ITV, or voice notes with STV!",
                        fontSize = 12.sp,
                        color = TextSecondaryDark,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredItems) { item ->
                    GalleryGridCard(
                        item = item,
                        onClick = { viewModel.selectGalleryItem(item) }
                    )
                }
            }
        }
    }

    // Detail / Fullscreen Modal Viewer
    if (selectedItem != null) {
        val item = selectedItem!!
        Dialog(onDismissRequest = { viewModel.selectGalleryItem(null) }) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.dp, HazimDarkBorder, RoundedCornerShape(20.dp)),
                color = HazimDarkSurface
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(
                                        when (item.type) {
                                            MediaType.IMAGE -> HazimCyan.copy(alpha = 0.2f)
                                            MediaType.VIDEO -> HazimPurple.copy(alpha = 0.2f)
                                            MediaType.AUDIO -> HazimEmerald.copy(alpha = 0.2f)
                                        }
                                    )
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = when (item.type) {
                                        MediaType.IMAGE -> "TTI IMAGE"
                                        MediaType.VIDEO -> "ITV VIDEO"
                                        MediaType.AUDIO -> "STV VOICE"
                                    },
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when (item.type) {
                                        MediaType.IMAGE -> HazimCyan
                                        MediaType.VIDEO -> HazimPurple
                                        MediaType.AUDIO -> HazimEmerald
                                    }
                                )
                            }
                        }

                        IconButton(
                            onClick = { viewModel.selectGalleryItem(null) },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondaryDark)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Media Render
                    when (item.type) {
                        MediaType.IMAGE -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(HazimDarkSurfaceVariant)
                            ) {
                                AsyncImage(
                                    model = item.mediaUrl,
                                    contentDescription = item.title,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            }
                        }
                        MediaType.VIDEO -> {
                            val animatedScale by animateFloatAsState(
                                targetValue = if (isVideoPlaying) 1.0f + (videoProgress * 0.2f) else 1.0f,
                                label = "scale"
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(16f / 9f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.Black),
                                contentAlignment = Alignment.Center
                            ) {
                                AsyncImage(
                                    model = item.mediaUrl,
                                    contentDescription = item.title,
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .graphicsLayer {
                                            scaleX = animatedScale
                                            scaleY = animatedScale
                                        },
                                    contentScale = ContentScale.Crop
                                )
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(CircleShape)
                                        .background(Color.Black.copy(alpha = 0.6f))
                                        .clickable { viewModel.toggleVideoPlayback() },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isVideoPlaying) Icons.Default.Stop else Icons.Default.PlayArrow,
                                        contentDescription = "Play/Stop",
                                        tint = Color.White
                                    )
                                }
                            }
                        }
                        MediaType.AUDIO -> {
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp)),
                                color = HazimDarkSurfaceVariant
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.GraphicEq,
                                        contentDescription = null,
                                        tint = HazimEmerald,
                                        modifier = Modifier.size(48.dp)
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(
                                        text = item.voiceName ?: "Neural Voice",
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimaryDark,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = "Language: ${item.language ?: "Hindi/English"}",
                                        fontSize = 11.sp,
                                        color = TextSecondaryDark
                                    )
                                    Spacer(modifier = Modifier.height(14.dp))
                                    Button(
                                        onClick = {
                                            if (isPlayingVoice) {
                                                viewModel.stopStvVoice()
                                            } else {
                                                viewModel.ttsEngine.speak(item.prompt)
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (isPlayingVoice) Color(0xFFEF4444) else HazimEmerald,
                                            contentColor = Color.Black
                                        )
                                    ) {
                                        Icon(
                                            imageVector = if (isPlayingVoice) Icons.Default.Stop else Icons.Default.PlayArrow,
                                            contentDescription = null
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(if (isPlayingVoice) "Stop" else "Listen Voice")
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = item.title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryDark
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = item.prompt,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondaryDark,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Action buttons: ITV bridge / Share / Delete
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (item.type == MediaType.IMAGE) {
                            Button(
                                onClick = {
                                    viewModel.setItvSourceImage(item)
                                    viewModel.selectGalleryItem(null)
                                    viewModel.navigateTo(ScreenDestination.IMAGE_TO_VIDEO)
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = HazimPurple,
                                    contentColor = Color.White
                                )
                            ) {
                                Icon(Icons.Default.Movie, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "Animate in ITV", fontSize = 12.sp)
                            }
                        }

                        OutlinedButton(
                            onClick = {
                                val shareIntent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_TEXT, "HAZIM AI Creation: ${item.title}\n${item.prompt}\n${item.mediaUrl}")
                                    type = "text/plain"
                                }
                                context.startActivity(Intent.createChooser(shareIntent, "Share"))
                            },
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = "Share", tint = TextSecondaryDark, modifier = Modifier.size(16.dp))
                        }

                        OutlinedButton(
                            onClick = {
                                viewModel.deleteGalleryItem(item.id)
                                Toast.makeText(context, "Removed from gallery", Toast.LENGTH_SHORT).show()
                            },
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFEF4444), modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GalleryGridCard(
    item: MediaItem,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, HazimDarkBorder, RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .testTag("gallery_item_${item.id}"),
        color = HazimDarkSurface
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .background(HazimDarkSurfaceVariant)
            ) {
                if (item.type == MediaType.AUDIO) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.GraphicEq,
                            contentDescription = null,
                            tint = HazimEmerald,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                } else {
                    AsyncImage(
                        model = item.thumbnailUrl,
                        contentDescription = item.title,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }

                // Type Badge overlay
                Box(
                    modifier = Modifier
                        .padding(8.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            when (item.type) {
                                MediaType.IMAGE -> HazimCyan.copy(alpha = 0.85f)
                                MediaType.VIDEO -> HazimPurple.copy(alpha = 0.85f)
                                MediaType.AUDIO -> HazimEmerald.copy(alpha = 0.85f)
                            }
                        )
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                        .align(Alignment.TopStart)
                ) {
                    Text(
                        text = when (item.type) {
                            MediaType.IMAGE -> "TTI"
                            MediaType.VIDEO -> "ITV"
                            MediaType.AUDIO -> "STV"
                        },
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                }

                // Video indicator overlay
                if (item.type == MediaType.VIDEO) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.6f))
                            .align(Alignment.Center),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = item.title,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.sp,
                    color = TextPrimaryDark,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = item.prompt,
                    fontSize = 10.sp,
                    color = TextSecondaryDark,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
