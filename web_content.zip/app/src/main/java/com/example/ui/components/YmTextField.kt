package com.example.ui.components

import android.view.KeyEvent
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.testTag
import com.example.ui.theme.BlackPure
import com.example.ui.theme.SilverDark
import com.example.ui.theme.SilverSurface
import com.example.util.TextInputSanitizer

@Composable
fun YmTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    label: String? = null,
    placeholder: String? = null,
    leadingIcon: @Composable (() -> Unit)? = null,
    trailingIcon: @Composable (() -> Unit)? = null,
    suffix: @Composable (() -> Unit)? = null,
    singleLine: Boolean = true,
    minLines: Int = 1,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    shape: Shape = SlantedShape,
    testTag: String? = null
) {
    var lastKeyPressSeq by remember { mutableLongStateOf(0L) }
    var lastConsumedSeq by remember { mutableLongStateOf(0L) }
    var lastInputTime by remember { mutableLongStateOf(0L) }
    var lastInputChar by remember { mutableStateOf<Char?>(null) }

    val fieldModifier = (if (testTag != null) modifier.testTag(testTag) else modifier)
        .onPreviewKeyEvent { keyEvent ->
            if (keyEvent.type == KeyEventType.KeyDown) {
                val nativeCode = keyEvent.nativeKeyEvent.keyCode
                if ((nativeCode in KeyEvent.KEYCODE_A..KeyEvent.KEYCODE_Z) ||
                    (nativeCode in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9) ||
                    nativeCode == KeyEvent.KEYCODE_SPACE ||
                    nativeCode == KeyEvent.KEYCODE_AT ||
                    nativeCode == KeyEvent.KEYCODE_PERIOD ||
                    nativeCode == KeyEvent.KEYCODE_COMMA ||
                    nativeCode == KeyEvent.KEYCODE_MINUS ||
                    nativeCode == KeyEvent.KEYCODE_SLASH ||
                    keyEvent.nativeKeyEvent.unicodeChar != 0
                ) {
                    lastKeyPressSeq++
                }
            }
            false
        }

    OutlinedTextField(
        value = value,
        onValueChange = { incoming ->
            val result = TextInputSanitizer.sanitize(
                oldText = value,
                newText = incoming,
                keyPressSeq = lastKeyPressSeq,
                lastConsumedSeq = lastConsumedSeq,
                lastTime = lastInputTime,
                lastChar = lastInputChar
            )
            lastConsumedSeq = result.consumedSeq
            lastInputTime = result.time
            lastInputChar = result.character
            onValueChange(result.text)
        },
        label = label?.let { { Text(it, color = SilverDark) } },
        placeholder = placeholder?.let { { Text(it, color = SilverDark) } },
        leadingIcon = leadingIcon,
        trailingIcon = trailingIcon,
        suffix = suffix,
        singleLine = singleLine,
        minLines = minLines,
        keyboardOptions = keyboardOptions,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = BlackPure,
            unfocusedBorderColor = SilverDark,
            focusedLabelColor = BlackPure,
            unfocusedLabelColor = SilverDark,
            focusedTextColor = BlackPure,
            unfocusedTextColor = BlackPure,
            focusedContainerColor = SilverSurface.copy(alpha = 0.5f),
            unfocusedContainerColor = SilverSurface.copy(alpha = 0.3f)
        ),
        shape = shape,
        modifier = fieldModifier
    )
}
