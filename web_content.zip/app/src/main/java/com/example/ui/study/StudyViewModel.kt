package com.example.ui.study

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.ExamEntity
import com.example.data.model.StudySessionEntity
import com.example.data.model.SubjectEntity
import com.example.data.model.SubjectWithStats
import com.example.data.repository.ExamRepository
import com.example.data.repository.StudySessionRepository
import com.example.data.repository.SubjectRepository
import com.example.data.streak.StreakCalculator
import com.example.data.streak.StreakResult
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters

enum class TimerState {
    IDLE,
    RUNNING,
    PAUSED
}

data class StudyUiState(
    val activeSubjects: List<SubjectWithStats> = emptyList(),
    val archivedSubjects: List<SubjectWithStats> = emptyList(),
    val subjectsMap: Map<Long, SubjectEntity> = emptyMap(),
    val sessions: List<StudySessionEntity> = emptyList(),
    val streakResult: StreakResult = StreakResult(
        currentStreak = 0,
        longestStreak = 0,
        studiedDates = emptySet(),
        partialDates = emptySet(),
        frozenDates = emptySet(),
        freezesUsedThisMonth = 0,
        freezesRemainingThisMonth = 2,
        isStudiedToday = false
    ),
    val todayStudyMinutes: Int = 0,

    // Exam Countdown State (PRD section 5.5)
    val activeExams: List<ExamEntity> = emptyList(),
    val archivedExams: List<ExamEntity> = emptyList(),
    val nearestExam: ExamEntity? = null,

    // Live Timer State
    val timerState: TimerState = TimerState.IDLE,
    val timerElapsedSeconds: Long = 0L,
    val timerSubjectId: Long? = null,
    val timerStartDate: String = "",
    val timerStartTimeFormatted: String = "",

    // Subject Add/Edit Dialog
    val showSubjectDialog: Boolean = false,
    val subjectBeingEdited: SubjectEntity? = null,
    val subjectNameInput: String = "",
    val subjectColorInput: String = SubjectStylePresets.COLORS[0].hex,
    val subjectIconInput: String = SubjectStylePresets.ICONS[0].name,
    val subjectTargetHoursInput: String = "",
    val subjectError: String? = null,

    // Subject Archive Dialog
    val showArchiveConfirmDialog: Boolean = false,
    val subjectToArchive: SubjectEntity? = null,

    // Archived Subjects Section BottomSheet
    val showArchivedSection: Boolean = false,

    // Session Add/Edit Dialog
    val showSessionDialog: Boolean = false,
    val sessionBeingEdited: StudySessionEntity? = null,
    val sessionSubjectId: Long? = null,
    val sessionDateInput: String = "",
    val sessionStartTimeInput: String = "",
    val sessionHoursInput: String = "0",
    val sessionMinutesInput: String = "30",
    val sessionTopicInput: String = "",
    val sessionRemarkInput: String = "",
    val sessionError: String? = null,

    // Delete Session Confirm Dialog
    val showDeleteSessionDialog: Boolean = false,
    val sessionToDelete: StudySessionEntity? = null
)

class StudyViewModel(
    private val subjectRepository: SubjectRepository,
    private val sessionRepository: StudySessionRepository,
    private val examRepository: ExamRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(StudyUiState())
    val uiState: StateFlow<StudyUiState> = _uiState.asStateFlow()

    private var timerJob: Job? = null

    init {
        viewModelScope.launch {
            combine(
                subjectRepository.allSubjectsFlow,
                sessionRepository.allSessionsFlow,
                examRepository.activeExamsFlow,
                examRepository.archivedExamsFlow
            ) { allSubjects, allSessions, activeExams, archivedExams ->
                val today = LocalDate.now()
                val todayStr = today.toString()
                val monday = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
                val sunday = today.with(TemporalAdjusters.nextOrSame(DayOfWeek.SUNDAY))

                val subjectsById = allSubjects.associateBy { it.id }

                // Group minutes by date for streak calculation
                val minutesByDate = mutableMapOf<LocalDate, Int>()
                for (s in allSessions) {
                    try {
                        val d = LocalDate.parse(s.date)
                        minutesByDate[d] = (minutesByDate[d] ?: 0) + s.durationMinutes
                    } catch (_: Exception) {}
                }

                val streak = StreakCalculator.calculateStreak(minutesByDate, today)
                val todayMinutes = minutesByDate[today] ?: 0

                // Map subjects with statistics
                val activeWithStats = allSubjects.filter { !it.isArchived }.map { subject ->
                    val subjectSessions = allSessions.filter { it.subjectId == subject.id }
                    val totalMinutes = subjectSessions.sumOf { it.durationMinutes }
                    val lastDate = subjectSessions.maxByOrNull { it.date }?.date

                    val thisWeekMinutes = subjectSessions.filter { session ->
                        try {
                            val parsedDate = LocalDate.parse(session.date)
                            !parsedDate.isBefore(monday) && !parsedDate.isAfter(sunday)
                        } catch (e: Exception) {
                            false
                        }
                    }.sumOf { it.durationMinutes }

                    SubjectWithStats(
                        subject = subject,
                        totalMinutesStudied = totalMinutes,
                        lastStudiedDate = lastDate,
                        thisWeekMinutesStudied = thisWeekMinutes
                    )
                }

                val archivedWithStats = allSubjects.filter { it.isArchived }.map { subject ->
                    val subjectSessions = allSessions.filter { it.subjectId == subject.id }
                    val totalMinutes = subjectSessions.sumOf { it.durationMinutes }
                    val lastDate = subjectSessions.maxByOrNull { it.date }?.date
                    SubjectWithStats(
                        subject = subject,
                        totalMinutesStudied = totalMinutes,
                        lastStudiedDate = lastDate,
                        thisWeekMinutesStudied = 0
                    )
                }

                val nearestExam = activeExams.firstOrNull()

                _uiState.update { current ->
                    current.copy(
                        activeSubjects = activeWithStats,
                        archivedSubjects = archivedWithStats,
                        subjectsMap = subjectsById,
                        sessions = allSessions,
                        streakResult = streak,
                        todayStudyMinutes = todayMinutes,
                        activeExams = activeExams,
                        archivedExams = archivedExams,
                        nearestExam = nearestExam
                    )
                }
            }.collect {}
        }
    }

    // ==========================================
    // LIVE TIMER IMPLEMENTATION (PRD section 5.2)
    // ==========================================

    fun startTimer(subjectId: Long? = null) {
        val now = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))
        val todayStr = LocalDate.now().toString()
        val chosenSubject = subjectId ?: _uiState.value.timerSubjectId ?: _uiState.value.activeSubjects.firstOrNull()?.subject?.id

        _uiState.update {
            it.copy(
                timerState = TimerState.RUNNING,
                timerSubjectId = chosenSubject,
                timerStartDate = todayStr,
                timerStartTimeFormatted = if (it.timerStartTimeFormatted.isEmpty()) now else it.timerStartTimeFormatted
            )
        }

        startTimerTicker()
    }

    fun pauseTimer() {
        timerJob?.cancel()
        _uiState.update { it.copy(timerState = TimerState.PAUSED) }
    }

    fun resumeTimer() {
        _uiState.update { it.copy(timerState = TimerState.RUNNING) }
        startTimerTicker()
    }

    fun selectTimerSubject(subjectId: Long) {
        _uiState.update { it.copy(timerSubjectId = subjectId) }
    }

    private fun startTimerTicker() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                _uiState.update { it.copy(timerElapsedSeconds = it.timerElapsedSeconds + 1) }
            }
        }
    }

    fun stopTimerAndOpenLog() {
        timerJob?.cancel()
        val elapsed = _uiState.value.timerElapsedSeconds
        val durationMins = (elapsed / 60).toInt().coerceAtLeast(1)
        val hours = durationMins / 60
        val mins = durationMins % 60

        val subjectId = _uiState.value.timerSubjectId ?: _uiState.value.activeSubjects.firstOrNull()?.subject?.id
        val startTime = _uiState.value.timerStartTimeFormatted.ifEmpty {
            LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))
        }
        val date = _uiState.value.timerStartDate.ifEmpty {
            LocalDate.now().toString()
        }

        _uiState.update {
            it.copy(
                timerState = TimerState.IDLE,
                timerElapsedSeconds = 0L,
                timerStartTimeFormatted = "",
                // Pre-fill manual session dialog
                showSessionDialog = true,
                sessionBeingEdited = null,
                sessionSubjectId = subjectId,
                sessionDateInput = date,
                sessionStartTimeInput = startTime,
                sessionHoursInput = hours.toString(),
                sessionMinutesInput = mins.toString(),
                sessionTopicInput = "",
                sessionRemarkInput = "",
                sessionError = null
            )
        }
    }

    fun resetTimer() {
        timerJob?.cancel()
        _uiState.update {
            it.copy(
                timerState = TimerState.IDLE,
                timerElapsedSeconds = 0L,
                timerStartTimeFormatted = "",
                timerStartDate = ""
            )
        }
    }

    // ==========================================
    // SUBJECT MANAGEMENT (PRD section 5.1)
    // ==========================================

    fun openAddSubjectDialog() {
        _uiState.update {
            it.copy(
                showSubjectDialog = true,
                subjectBeingEdited = null,
                subjectNameInput = "",
                subjectColorInput = SubjectStylePresets.COLORS.random().hex,
                subjectIconInput = SubjectStylePresets.ICONS[0].name,
                subjectTargetHoursInput = "",
                subjectError = null
            )
        }
    }

    fun openEditSubjectDialog(subject: SubjectEntity) {
        _uiState.update {
            it.copy(
                showSubjectDialog = true,
                subjectBeingEdited = subject,
                subjectNameInput = subject.name,
                subjectColorInput = subject.colorHex,
                subjectIconInput = subject.iconName,
                subjectTargetHoursInput = subject.weeklyTargetHours?.toString() ?: "",
                subjectError = null
            )
        }
    }

    fun closeSubjectDialog() {
        _uiState.update { it.copy(showSubjectDialog = false, subjectError = null) }
    }

    fun onSubjectNameChange(value: String) {
        _uiState.update { it.copy(subjectNameInput = value, subjectError = null) }
    }

    fun onSubjectColorChange(hex: String) {
        _uiState.update { it.copy(subjectColorInput = hex) }
    }

    fun onSubjectIconChange(name: String) {
        _uiState.update { it.copy(subjectIconInput = name) }
    }

    fun onSubjectTargetHoursChange(value: String) {
        _uiState.update { it.copy(subjectTargetHoursInput = value) }
    }

    fun saveSubject() {
        val state = _uiState.value
        val name = state.subjectNameInput.trim()
        if (name.isEmpty()) {
            _uiState.update { it.copy(subjectError = "Subject name cannot be empty") }
            return
        }

        val targetHours = state.subjectTargetHoursInput.trim().toFloatOrNull()

        viewModelScope.launch {
            val editing = state.subjectBeingEdited
            if (editing != null) {
                subjectRepository.updateSubject(
                    id = editing.id,
                    name = name,
                    colorHex = state.subjectColorInput,
                    iconName = state.subjectIconInput,
                    weeklyTargetHours = targetHours
                )
            } else {
                subjectRepository.addSubject(
                    name = name,
                    colorHex = state.subjectColorInput,
                    iconName = state.subjectIconInput,
                    weeklyTargetHours = targetHours
                )
            }
            _uiState.update { it.copy(showSubjectDialog = false) }
        }
    }

    fun openArchiveConfirmDialog(subject: SubjectEntity) {
        _uiState.update {
            it.copy(
                showArchiveConfirmDialog = true,
                subjectToArchive = subject
            )
        }
    }

    fun closeArchiveConfirmDialog() {
        _uiState.update {
            it.copy(
                showArchiveConfirmDialog = false,
                subjectToArchive = null
            )
        }
    }

    fun confirmArchiveSubject() {
        val subject = _uiState.value.subjectToArchive ?: return
        viewModelScope.launch {
            subjectRepository.archiveSubject(subject.id)
            closeArchiveConfirmDialog()
        }
    }

    fun restoreSubject(id: Long) {
        viewModelScope.launch {
            subjectRepository.restoreSubject(id)
        }
    }

    fun toggleArchivedSection(show: Boolean) {
        _uiState.update { it.copy(showArchivedSection = show) }
    }

    // ==========================================
    // STUDY SESSION MANAGEMENT (PRD section 5.2)
    // ==========================================

    fun openAddManualSessionDialog() {
        val todayStr = LocalDate.now().toString()
        val nowTimeStr = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))
        val defaultSubjectId = _uiState.value.activeSubjects.firstOrNull()?.subject?.id

        _uiState.update {
            it.copy(
                showSessionDialog = true,
                sessionBeingEdited = null,
                sessionSubjectId = defaultSubjectId,
                sessionDateInput = todayStr,
                sessionStartTimeInput = nowTimeStr,
                sessionHoursInput = "0",
                sessionMinutesInput = "45",
                sessionTopicInput = "",
                sessionRemarkInput = "",
                sessionError = null
            )
        }
    }

    fun openEditSessionDialog(session: StudySessionEntity) {
        val hours = session.durationMinutes / 60
        val mins = session.durationMinutes % 60

        _uiState.update {
            it.copy(
                showSessionDialog = true,
                sessionBeingEdited = session,
                sessionSubjectId = session.subjectId,
                sessionDateInput = session.date,
                sessionStartTimeInput = session.startTime,
                sessionHoursInput = hours.toString(),
                sessionMinutesInput = mins.toString(),
                sessionTopicInput = session.topic ?: "",
                sessionRemarkInput = session.remark ?: "",
                sessionError = null
            )
        }
    }

    fun closeSessionDialog() {
        _uiState.update { it.copy(showSessionDialog = false, sessionError = null) }
    }

    fun onSessionSubjectChange(subjectId: Long) {
        _uiState.update { it.copy(sessionSubjectId = subjectId) }
    }

    fun onSessionDateChange(value: String) {
        _uiState.update { it.copy(sessionDateInput = value, sessionError = null) }
    }

    fun onSessionStartTimeChange(value: String) {
        _uiState.update { it.copy(sessionStartTimeInput = value) }
    }

    fun onSessionHoursChange(value: String) {
        _uiState.update { it.copy(sessionHoursInput = value, sessionError = null) }
    }

    fun onSessionMinutesChange(value: String) {
        _uiState.update { it.copy(sessionMinutesInput = value, sessionError = null) }
    }

    fun onSessionTopicChange(value: String) {
        _uiState.update { it.copy(sessionTopicInput = value) }
    }

    fun onSessionRemarkChange(value: String) {
        _uiState.update { it.copy(sessionRemarkInput = value) }
    }

    fun saveSession() {
        val state = _uiState.value
        val subjectId = state.sessionSubjectId
        if (subjectId == null) {
            _uiState.update { it.copy(sessionError = "Please select a subject") }
            return
        }

        val hours = state.sessionHoursInput.trim().toIntOrNull() ?: 0
        val mins = state.sessionMinutesInput.trim().toIntOrNull() ?: 0
        val totalMinutes = (hours * 60) + mins

        if (totalMinutes <= 0) {
            _uiState.update { it.copy(sessionError = "Duration must be at least 1 minute") }
            return
        }

        val date = state.sessionDateInput.trim().ifEmpty { LocalDate.now().toString() }
        val startTime = state.sessionStartTimeInput.trim().ifEmpty {
            LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"))
        }

        viewModelScope.launch {
            val editing = state.sessionBeingEdited
            if (editing != null) {
                val updated = editing.copy(
                    subjectId = subjectId,
                    date = date,
                    startTime = startTime,
                    durationMinutes = totalMinutes,
                    topic = state.sessionTopicInput.trim().ifBlank { null },
                    remark = state.sessionRemarkInput.trim().ifBlank { null }
                )
                sessionRepository.updateSession(updated)
            } else {
                sessionRepository.addSession(
                    subjectId = subjectId,
                    date = date,
                    startTime = startTime,
                    durationMinutes = totalMinutes,
                    topic = state.sessionTopicInput,
                    remark = state.sessionRemarkInput
                )
            }
            _uiState.update { it.copy(showSessionDialog = false) }
        }
    }

    fun openDeleteSessionConfirm(session: StudySessionEntity) {
        _uiState.update {
            it.copy(
                showDeleteSessionDialog = true,
                sessionToDelete = session
            )
        }
    }

    fun closeDeleteSessionConfirm() {
        _uiState.update {
            it.copy(
                showDeleteSessionDialog = false,
                sessionToDelete = null
            )
        }
    }

    fun confirmDeleteSession() {
        val session = _uiState.value.sessionToDelete ?: return
        viewModelScope.launch {
            sessionRepository.deleteSession(session.id)
            closeDeleteSessionConfirm()
        }
    }

    // ==========================================
    // EXAM MANAGEMENT (PRD section 5.5)
    // ==========================================

    fun addExam(
        name: String,
        date: String,
        subjectId: Long?,
        remind30: Boolean,
        remind7: Boolean,
        remind1: Boolean
    ) {
        viewModelScope.launch {
            examRepository.addExam(
                name = name,
                date = date,
                subjectId = subjectId,
                remind30 = remind30,
                remind7 = remind7,
                remind1 = remind1
            )
        }
    }

    fun updateExam(exam: ExamEntity) {
        viewModelScope.launch {
            examRepository.updateExam(exam)
        }
    }

    fun deleteExam(id: Long) {
        viewModelScope.launch {
            examRepository.deleteExam(id)
        }
    }
}

class StudyViewModelFactory(
    private val subjectRepository: SubjectRepository,
    private val sessionRepository: StudySessionRepository,
    private val examRepository: ExamRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(StudyViewModel::class.java)) {
            return StudyViewModel(subjectRepository, sessionRepository, examRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
