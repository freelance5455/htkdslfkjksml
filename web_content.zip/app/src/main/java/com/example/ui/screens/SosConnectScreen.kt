package com.example.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.EmergencyContactEntity
import com.example.data.local.SosMessageEntity
import com.example.data.model.UserProfile
import com.example.localization.LocalizedStrings
import com.example.system.SosTriggerAction
import com.example.ui.theme.SagePrimary
import com.example.ui.theme.SosCrimson
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SosConnectScreen(
    profile: UserProfile,
    strings: LocalizedStrings,
    contacts: List<EmergencyContactEntity>,
    sosMessages: List<SosMessageEntity>,
    currentLocationText: String,
    onRefreshLocation: () -> Unit,
    onCallNumber: (String) -> Unit,
    onActivateSosTrigger: (SosTriggerAction, String) -> Unit,
    onSendSmsDirect: (phone: String, message: String) -> Unit,
    onSendWhatsAppDirect: (phone: String, message: String) -> Unit,
    onDispatchSos: (contact: EmergencyContactEntity?, message: String, channel: String) -> Unit,
    onAddContact: (name: String, phone: String, relationship: String) -> Unit,
    onDeleteContact: (Int) -> Unit
) {
    var sosInput by remember { mutableStateOf("I need urgent help. My emergency call didn't go through—please check my location!") }
    var selectedContact by remember(contacts) { mutableStateOf(contacts.firstOrNull()) }
    var showAddContactDialog by remember { mutableStateOf(false) }

    val locationPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        onRefreshLocation()
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Emergency Authority Call & Medical Info
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Warning, contentDescription = null, tint = SosCrimson)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(strings.sosHeaderTitle, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.MedicalServices, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Medical ID: ${profile.name.ifBlank { "Teen User" }}, Age ${profile.age} • Blood: ${profile.bloodType} • Allergies: ${profile.allergies}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    if (profile.medicalNotes.isNotBlank()) {
                        Text("Notes: ${profile.medicalNotes}", style = MaterialTheme.typography.bodySmall)
                    }

                    Button(
                        onClick = { onActivateSosTrigger(SosTriggerAction.CALL_AUTHORITY, sosInput) },
                        colors = ButtonDefaults.buttonColors(containerColor = SosCrimson, contentColor = Color.White),
                        modifier = Modifier.fillMaxWidth().height(54.dp).testTag("call_authority_button")
                    ) {
                        Icon(Icons.Filled.Call, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("${strings.callAuthority} (${profile.emergencyAuthorityNumber})")
                    }

                    OutlinedButton(
                        onClick = { onActivateSosTrigger(SosTriggerAction.SEND_PRECONFIGURED_SMS, sosInput) },
                        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("sos_trigger_sms_all_button")
                    ) {
                        Icon(Icons.Filled.Sms, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("SOS Trigger: Send Pre-Configured SMS to All Contacts")
                    }
                }
            }
        }

        // Special WhatsApp-Style SOS Messenger (fallback when authority call fails)
        item {
            Card(shape = RoundedCornerShape(20.dp)) {
                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(SagePrimary)
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Chat, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(strings.sosMessengerTitle, style = MaterialTheme.typography.titleSmall, color = Color.White)
                                Text("Call didn't go through? Send instant SOS + GPS", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.85f))
                            }
                        }
                    }

                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.LocationOn, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(currentLocationText, style = MaterialTheme.typography.bodySmall)
                            }
                            TextButton(
                                onClick = {
                                    locationPermLauncher.launch(
                                        arrayOf(
                                            Manifest.permission.ACCESS_FINE_LOCATION,
                                            Manifest.permission.ACCESS_COARSE_LOCATION
                                        )
                                    )
                                },
                                modifier = Modifier.testTag("refresh_gps_button")
                            ) {
                                Text("Attach GPS")
                            }
                        }

                        if (contacts.isNotEmpty()) {
                            Text("Send SOS To:", style = MaterialTheme.typography.labelLarge)
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                contacts.forEach { contact ->
                                    FilterChip(
                                        selected = selectedContact?.id == contact.id,
                                        onClick = { selectedContact = contact },
                                        label = { Text("${contact.name} (${contact.relationship})") }
                                    )
                                }
                            }
                        } else {
                            Text(
                                "Add a trusted parent, guardian, or friend below so you can alert them in 1 tap.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(
                                "Authority call didn't connect—please check on me!",
                                "I feel unsafe. Please come get me at my GPS.",
                                "Medical emergency—please call me back right away."
                            ).forEach { template ->
                                AssistChip(onClick = { sosInput = template }, label = { Text(template, style = MaterialTheme.typography.labelSmall) })
                            }
                        }

                        OutlinedTextField(
                            value = sosInput,
                            onValueChange = { sosInput = it },
                            label = { Text("Emergency Message") },
                            minLines = 2,
                            modifier = Modifier.fillMaxWidth().testTag("sos_message_input")
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            Button(
                                onClick = { onDispatchSos(selectedContact, sosInput, "WhatsApp") },
                                modifier = Modifier.weight(1f).testTag("send_sos_whatsapp_button")
                            ) {
                                Icon(Icons.Filled.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("WhatsApp / App")
                            }
                            OutlinedButton(
                                onClick = { onDispatchSos(selectedContact, sosInput, "SMS") },
                                modifier = Modifier.weight(1f).testTag("send_sos_sms_button")
                            ) {
                                Icon(Icons.Filled.Sms, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Offline SMS")
                            }
                        }
                    }
                }
            }
        }

        // SOS Messenger Thread History
        if (sosMessages.isNotEmpty()) {
            item {
                Text("SOS Thread Log", style = MaterialTheme.typography.titleMedium)
            }
            items(sosMessages.take(5), key = { it.id }) { msg ->
                val timeStr = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(msg.timestamp))
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("To ${msg.recipientName} • ${msg.status} • $timeStr", style = MaterialTheme.typography.labelSmall)
                        Text(msg.messageText, style = MaterialTheme.typography.bodyMedium)
                        Text(msg.locationSummary, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        // Call & Message People / Trusted Contacts
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Trusted Contacts (Call & Message)", style = MaterialTheme.typography.titleLarge)
                Button(
                    onClick = { showAddContactDialog = true },
                    modifier = Modifier.testTag("add_contact_button")
                ) {
                    Icon(Icons.Filled.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add")
                }
            }
        }

        items(contacts, key = { it.id }) { contact ->
            Card {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(contact.name, style = MaterialTheme.typography.titleMedium)
                            Text("${contact.relationship} • ${contact.phone}", style = MaterialTheme.typography.bodySmall)
                        }
                        IconButton(onClick = { onDeleteContact(contact.id) }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Delete contact")
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { onCallNumber(contact.phone) }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Filled.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Call")
                        }
                        OutlinedButton(onClick = { onSendSmsDirect(contact.phone, "Hey ${contact.name}, checking in from Haven.") }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Filled.Sms, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("SMS")
                        }
                        OutlinedButton(onClick = { onSendWhatsAppDirect(contact.phone, "Hey ${contact.name}, checking in from Haven.") }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Filled.Chat, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("WhatsApp")
                        }
                    }
                }
            }
        }
    }

    if (showAddContactDialog) {
        var cName by remember { mutableStateOf("") }
        var cPhone by remember { mutableStateOf("") }
        var cRelation by remember { mutableStateOf("Parent / Guardian") }

        AlertDialog(
            onDismissRequest = { showAddContactDialog = false },
            title = { Text("Add Trusted Contact") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = cName, onValueChange = { cName = it }, label = { Text("Name") }, singleLine = true)
                    OutlinedTextField(value = cPhone, onValueChange = { cPhone = it }, label = { Text("Phone Number") }, singleLine = true)
                    OutlinedTextField(value = cRelation, onValueChange = { cRelation = it }, label = { Text("Relationship (Mom, Best Friend, Counselor)") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onAddContact(cName, cPhone, cRelation)
                        showAddContactDialog = false
                    }
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showAddContactDialog = false }) { Text("Cancel") }
            }
        )
    }
}
