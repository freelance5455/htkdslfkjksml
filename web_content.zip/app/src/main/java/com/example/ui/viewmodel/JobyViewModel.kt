package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.JobyRepository
import com.example.model.AppNotification
import com.example.model.ChatMessage
import com.example.model.Conversation
import com.example.model.JobApplication
import com.example.model.JobListing
import com.example.model.JobyConstants
import com.example.model.ModerationReport
import com.example.model.PaymentTransaction
import com.example.model.SideQuest
import com.example.model.SubscriptionPlan
import com.example.model.UserProfile
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface UiState<out T> {
  data object Loading : UiState<Nothing>
  data class Success<T>(val data: T) : UiState<T>
  data class Error(val message: String) : UiState<Nothing>
}

data class JobFilterState(
  val query: String = "",
  val selectedState: String = "All India",
  val selectedCategory: String = "All",
  val selectedJobType: String = "ALL",
  val remoteOnly: Boolean = false
)

@OptIn(ExperimentalCoroutinesApi::class)
class JobyViewModel(
  private val repository: JobyRepository,
  val currentUserId: String,
  val userEmail: String,
  val userDisplayName: String
) : ViewModel() {

  val isAdminUser: Boolean = userEmail.equals(JobyConstants.ADMIN_BOOTSTRAP_EMAIL, ignoreCase = true)

  private val _filterState = MutableStateFlow(JobFilterState())
  val filterState: StateFlow<JobFilterState> = _filterState.asStateFlow()

  private val _activeConversationId = MutableStateFlow<String?>(null)
  val activeConversationId: StateFlow<String?> = _activeConversationId.asStateFlow()

  private val _snackbarMessage = MutableStateFlow<String?>(null)
  val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

  private val _isBusy = MutableStateFlow(false)
  val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

  private fun <T> Flow<T>.toUiStateFlow(tagLabel: String): StateFlow<UiState<T>> =
    map<T, UiState<T>> { UiState.Success(it) }
      .catch { error ->
        val firestoreError = generateSequence(error) { it.cause }
          .filterIsInstance<FirebaseFirestoreException>()
          .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val rootError = firestoreError ?: error
        Log.w(TAG, "Error observing $tagLabel", rootError)
        emit(UiState.Error(rootError.localizedMessage ?: "Failed to load $tagLabel"))
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS),
        initialValue = UiState.Loading
      )

  val userProfileState: StateFlow<UiState<UserProfile?>> =
    repository.observeUserProfile(currentUserId).toUiStateFlow("userProfile")

  val approvedJobsState: StateFlow<UiState<List<JobListing>>> =
    repository.observeApprovedJobs(currentUserId).toUiStateFlow("approvedJobs")

  val employerJobsState: StateFlow<UiState<List<JobListing>>> =
    repository.observeEmployerJobs(currentUserId).toUiStateFlow("employerJobs")

  val approvedSideQuestsState: StateFlow<UiState<List<SideQuest>>> =
    repository.observeApprovedSideQuests(currentUserId).toUiStateFlow("approvedSideQuests")

  val employerSideQuestsState: StateFlow<UiState<List<SideQuest>>> =
    repository.observeEmployerSideQuests(currentUserId).toUiStateFlow("employerSideQuests")

  val seekerApplicationsState: StateFlow<UiState<List<JobApplication>>> =
    repository.observeSeekerApplications(currentUserId).toUiStateFlow("seekerApplications")

  val employerApplicationsState: StateFlow<UiState<List<JobApplication>>> =
    repository.observeEmployerApplications(currentUserId).toUiStateFlow("employerApplications")

  val conversationsState: StateFlow<UiState<List<Conversation>>> =
    repository.observeConversations(currentUserId).toUiStateFlow("conversations")

  val activeMessagesState: StateFlow<UiState<List<ChatMessage>>> =
    _activeConversationId
      .flatMapLatest { convId ->
        if (convId == null) flowOf(emptyList())
        else repository.observeMessages(convId, currentUserId)
      }
      .toUiStateFlow("messages")

  val notificationsState: StateFlow<UiState<List<AppNotification>>> =
    repository.observeNotifications(currentUserId).toUiStateFlow("notifications")

  val subscriptionPlansState: StateFlow<UiState<List<SubscriptionPlan>>> =
    repository.observeSubscriptionPlans(currentUserId).toUiStateFlow("subscriptionPlans")

  val userTransactionsState: StateFlow<UiState<List<PaymentTransaction>>> =
    repository.observeUserTransactions(currentUserId).toUiStateFlow("userTransactions")

  // Admin-scoped flows (only subscribed when isAdminUser == true)
  val allJobsAdminState: StateFlow<UiState<List<JobListing>>> =
    if (isAdminUser) repository.observeAllJobsAdmin(currentUserId).toUiStateFlow("allJobsAdmin")
    else MutableStateFlow(UiState.Success(emptyList()))

  val allSideQuestsAdminState: StateFlow<UiState<List<SideQuest>>> =
    if (isAdminUser) repository.observeAllSideQuestsAdmin(currentUserId).toUiStateFlow("allSideQuestsAdmin")
    else MutableStateFlow(UiState.Success(emptyList()))

  val allUsersAdminState: StateFlow<UiState<List<UserProfile>>> =
    if (isAdminUser) repository.observeAllUsersAdmin(currentUserId).toUiStateFlow("allUsersAdmin")
    else MutableStateFlow(UiState.Success(emptyList()))

  val allReportsAdminState: StateFlow<UiState<List<ModerationReport>>> =
    if (isAdminUser) repository.observeAllReportsAdmin(currentUserId).toUiStateFlow("allReportsAdmin")
    else MutableStateFlow(UiState.Success(emptyList()))

  val allTransactionsAdminState: StateFlow<UiState<List<PaymentTransaction>>> =
    if (isAdminUser) repository.observeAllTransactionsAdmin(currentUserId).toUiStateFlow("allTransactionsAdmin")
    else MutableStateFlow(UiState.Success(emptyList()))

  fun clearSnackbar() {
    _snackbarMessage.value = null
  }

  fun showMessage(msg: String) {
    _snackbarMessage.value = msg
  }

  fun updateFilter(transform: (JobFilterState) -> JobFilterState) {
    _filterState.value = transform(_filterState.value)
  }

  fun openConversation(conversationId: String?) {
    _activeConversationId.value = conversationId
  }

  fun saveUserProfile(profile: UserProfile, onSuccess: () -> Unit = {}) {
    viewModelScope.launch {
      _isBusy.value = true
      val res = repository.upsertUserProfile(profile)
      _isBusy.value = false
      res.onSuccess {
        _snackbarMessage.value = "Profile saved"
        onSuccess()
      }.onFailure {
        _snackbarMessage.value = it.localizedMessage ?: "Failed to save profile"
      }
    }
  }

  fun switchLanguage(code: String) {
    viewModelScope.launch {
      repository.updatePreferredLanguage(code).onFailure {
        _snackbarMessage.value = "Failed to switch language"
      }
    }
  }

  fun toggleSavedJob(savedIds: List<String>, jobId: String) {
    viewModelScope.launch {
      repository.toggleSavedJob(savedIds, jobId).onSuccess {
        val msg = if (jobId in savedIds) "Removed from saved jobs" else "Saved to bookmarks"
        _snackbarMessage.value = msg
      }
    }
  }

  fun createJob(job: JobListing, onSuccess: () -> Unit = {}) {
    viewModelScope.launch {
      _isBusy.value = true
      val res = repository.createJob(job, isAdminUser = isAdminUser)
      _isBusy.value = false
      res.onSuccess {
        _snackbarMessage.value = if (isAdminUser) "Job published & approved" else "Job submitted for Admin moderation"
        onSuccess()
      }.onFailure {
        _snackbarMessage.value = it.localizedMessage ?: "Failed to create job"
      }
    }
  }

  fun toggleJobActive(jobId: String, active: Boolean) {
    viewModelScope.launch {
      repository.toggleJobActive(jobId, active)
    }
  }

  fun applyToJob(job: JobListing, seeker: UserProfile, coverNote: String, onSuccess: () -> Unit = {}) {
    viewModelScope.launch {
      _isBusy.value = true
      val res = repository.applyToJob(job, seeker, coverNote)
      _isBusy.value = false
      res.onSuccess {
        _snackbarMessage.value = "Application submitted (₹0 fee)"
        onSuccess()
      }.onFailure {
        _snackbarMessage.value = it.localizedMessage ?: "Failed to apply"
      }
    }
  }

  fun updateApplicationStatus(app: JobApplication, status: String, note: String = "") {
    viewModelScope.launch {
      repository.updateApplicationStatus(app, status, note).onSuccess {
        _snackbarMessage.value = "Updated status to $status"
      }.onFailure {
        _snackbarMessage.value = it.localizedMessage ?: "Could not update status"
      }
    }
  }

  fun createSideQuest(quest: SideQuest, onSuccess: () -> Unit = {}) {
    viewModelScope.launch {
      _isBusy.value = true
      val res = repository.createSideQuest(quest, isAdminUser = isAdminUser)
      _isBusy.value = false
      res.onSuccess {
        _snackbarMessage.value = if (isAdminUser) "Side Quest published" else "Side Quest submitted for Admin review"
        onSuccess()
      }.onFailure {
        _snackbarMessage.value = it.localizedMessage ?: "Failed to create Side Quest"
      }
    }
  }

  fun claimSideQuest(quest: SideQuest, seeker: UserProfile) {
    viewModelScope.launch {
      repository.claimSideQuest(quest, seeker).onSuccess {
        _snackbarMessage.value = "Side Quest accepted! Complete deliverables & submit proof."
      }.onFailure {
        _snackbarMessage.value = it.localizedMessage ?: "Could not accept Side Quest"
      }
    }
  }

  fun submitSideQuestProof(quest: SideQuest, proofNote: String, onSuccess: () -> Unit = {}) {
    viewModelScope.launch {
      repository.submitSideQuestProof(quest, proofNote).onSuccess {
        _snackbarMessage.value = "Proof sent to ${quest.posterName} for payout verification."
        onSuccess()
      }.onFailure {
        _snackbarMessage.value = it.localizedMessage ?: "Failed to submit proof"
      }
    }
  }

  fun releaseSideQuestPayout(quest: SideQuest) {
    viewModelScope.launch {
      repository.releaseSideQuestPayout(quest).onSuccess { ref ->
        _snackbarMessage.value = "Marked Paid ($ref). Invoice recorded."
      }.onFailure {
        _snackbarMessage.value = it.localizedMessage ?: "Failed to release payout"
      }
    }
  }

  fun startConversation(
    seekerId: String,
    employerId: String,
    seekerName: String,
    employerName: String,
    jobTitle: String,
    onReady: (String) -> Unit
  ) {
    viewModelScope.launch {
      repository.startOrGetConversation(seekerId, employerId, seekerName, employerName, jobTitle)
        .onSuccess { convId ->
          _activeConversationId.value = convId
          onReady(convId)
        }
        .onFailure {
          _snackbarMessage.value = it.localizedMessage ?: "Could not open conversation"
        }
    }
  }

  fun sendMessage(conversation: Conversation, senderName: String, text: String, attachmentLabel: String = "") {
    if (text.isBlank()) return
    viewModelScope.launch {
      repository.sendMessage(conversation, senderName, text, attachmentLabel).onFailure {
        _snackbarMessage.value = it.localizedMessage ?: "Failed to send message"
      }
    }
  }

  fun markNotificationRead(notificationId: String) {
    viewModelScope.launch {
      repository.markNotificationRead(notificationId)
    }
  }

  fun upgradeSubscription(user: UserProfile, plan: SubscriptionPlan, paymentMethod: String, onSuccess: () -> Unit = {}) {
    viewModelScope.launch {
      _isBusy.value = true
      val res = repository.upgradeSubscriptionPlan(user, plan, paymentMethod)
      _isBusy.value = false
      res.onSuccess { invoice ->
        _snackbarMessage.value = "Upgraded to ${plan.name}! Invoice $invoice generated."
        onSuccess()
      }.onFailure {
        _snackbarMessage.value = it.localizedMessage ?: "Upgrade failed"
      }
    }
  }

  fun submitReport(targetType: String, targetId: String, targetTitle: String, reason: String, details: String, onSuccess: () -> Unit = {}) {
    viewModelScope.launch {
      repository.submitReport(targetType, targetId, targetTitle, reason, details).onSuccess {
        _snackbarMessage.value = "Report submitted to JOBY Trust & Safety."
        onSuccess()
      }.onFailure {
        _snackbarMessage.value = it.localizedMessage ?: "Failed to submit report"
      }
    }
  }

  // Admin actions
  fun moderateJob(jobId: String, status: String) {
    viewModelScope.launch {
      repository.moderateJob(jobId, status).onSuccess {
        _snackbarMessage.value = "Job marked $status"
      }
    }
  }

  fun moderateSideQuest(questId: String, status: String) {
    viewModelScope.launch {
      repository.moderateSideQuest(questId, status).onSuccess {
        _snackbarMessage.value = "Side Quest marked $status"
      }
    }
  }

  fun saveSubscriptionPlanAdmin(plan: SubscriptionPlan) {
    viewModelScope.launch {
      repository.saveSubscriptionPlanAdmin(plan).onSuccess {
        _snackbarMessage.value = "Updated ${plan.name} pricing (₹${plan.priceInr})"
      }.onFailure {
        _snackbarMessage.value = it.localizedMessage ?: "Failed to update plan"
      }
    }
  }

  fun resolveReportAdmin(reportId: String, status: String, note: String) {
    viewModelScope.launch {
      repository.resolveReportAdmin(reportId, status, note).onSuccess {
        _snackbarMessage.value = "Report $status"
      }
    }
  }

  fun setCompanyVerifiedAdmin(userId: String, verified: Boolean) {
    viewModelScope.launch {
      repository.setCompanyVerifiedAdmin(userId, verified).onSuccess {
        _snackbarMessage.value = if (verified) "Company verified" else "Verification removed"
      }
    }
  }

  fun setUserStatusAdmin(userId: String, status: String) {
    viewModelScope.launch {
      repository.setUserAccountStatusAdmin(userId, status).onSuccess {
        _snackbarMessage.value = "Account status set to $status"
      }
    }
  }

  fun seedMarketplaceSampleData() {
    viewModelScope.launch {
      _isBusy.value = true
      val res = repository.seedIndiaMarketplaceDataAdmin()
      _isBusy.value = false
      res.onSuccess {
        _snackbarMessage.value = "Seeded pan-India Jobs, Side Quests & Subscription Plans!"
      }.onFailure {
        _snackbarMessage.value = it.localizedMessage ?: "Seeding failed"
      }
    }
  }

  private companion object {
    const val TAG = "JobyVM"
    const val STOP_TIMEOUT_MS = 5000L
  }
}
