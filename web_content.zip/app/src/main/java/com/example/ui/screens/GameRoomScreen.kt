package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.ArkGameType
import com.example.data.model.GameRoom
import com.example.ui.components.GlowingPillButton
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.UserBadgeChip
import com.example.ui.theme.ArkThemeTokens
import kotlinx.coroutines.delay
import kotlin.random.Random

@Composable
fun GameRoomScreen(
    room: GameRoom,
    currentUserId: String,
    onBack: () -> Unit,
    onToggleReady: () -> Unit,
    onStartOrNextRound: () -> Unit,
    onSubmitMove: (choice: String, pointsEarned: Long, nextWordChain: String?) -> Unit,
    onRematch: () -> Unit,
    onShareGameResult: (gameTitle: String, scoreSummary: String, winnerName: String) -> Unit = { _, _, _ -> }
) {
    BackHandler(onBack = onBack)

    val colors = ArkThemeTokens.colors
    val game = ArkGameType.fromId(room.gameType)
    val isHost = room.hostId == currentUserId
    val isReady = room.readyUids.contains(currentUserId)
    val myVote = room.votes[currentUserId]

    Column(modifier = Modifier.fillMaxSize()) {
        Surface(color = colors.glassSurfaceElevated) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Leave room view", tint = colors.textPrimary)
                    }
                    Column {
                        Text(game.title, style = MaterialTheme.typography.titleLarge, color = colors.textPrimary)
                        Text("Room Code: ${room.roomCode} • Round ${room.roundNumber}/${room.maxRounds}", style = MaterialTheme.typography.labelSmall, color = colors.cyan)
                    }
                }
                UserBadgeChip(label = room.status.uppercase(), accent = colors.emerald)
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Player Roster & Live Scoreboard
            item {
                LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Players (${room.playerUids.size})", style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                    Spacer(Modifier.height(8.dp))
                    room.playerUids.forEach { pid ->
                        val name = room.playerNames[pid] ?: "Player"
                        val score = room.scores[pid] ?: 0L
                        val ready = room.readyUids.contains(pid)
                        val isTurn = room.status == "playing" && room.currentTurnUid == pid
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = if (pid == currentUserId) "@$name (You)" else "@$name",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (isTurn) colors.cyan else colors.textPrimary,
                                    fontWeight = if (isTurn) FontWeight.Bold else FontWeight.Normal
                                )
                                if (room.status == "waiting" && ready) {
                                    Spacer(Modifier.width(6.dp))
                                    Icon(Icons.Default.CheckCircle, contentDescription = "Ready", tint = colors.emerald, modifier = Modifier.size(16.dp))
                                }
                            }
                            Text("$score PTS", style = MaterialTheme.typography.labelLarge, color = colors.gold)
                        }
                    }
                }
            }

            when (room.status) {
                "waiting" -> {
                    item {
                        LiquidGlassCard(modifier = Modifier.fillMaxWidth(), accentColor = colors.violet) {
                            Text("Game Rules", style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                            Spacer(Modifier.height(4.dp))
                            Text(game.rules, style = MaterialTheme.typography.bodyMedium, color = colors.textSecondary)
                            Spacer(Modifier.height(12.dp))
                            Text(
                                "Share Room Code ${room.roomCode} with friends so they can join in real time!",
                                style = MaterialTheme.typography.labelMedium,
                                color = colors.cyan
                            )
                        }
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(
                                onClick = onToggleReady,
                                modifier = Modifier.weight(1f).height(50.dp),
                                shape = RoundedCornerShape(25.dp)
                            ) {
                                Text(if (isReady) "Ready ✓" else "Mark Ready")
                            }
                            if (isHost) {
                                GlowingPillButton(
                                    text = "Start Game",
                                    icon = Icons.Default.PlayArrow,
                                    onClick = onStartOrNextRound,
                                    modifier = Modifier.weight(1f).testTag("start_game_button")
                                )
                            }
                        }
                    }
                }

                "playing" -> {
                    item {
                        ActiveGameplayCard(
                            room = room,
                            game = game,
                            currentUserId = currentUserId,
                            myVote = myVote,
                            onSubmitMove = onSubmitMove
                        )
                    }

                    if (isHost) {
                        item {
                            GlowingPillButton(
                                text = if (room.roundNumber >= room.maxRounds) "Finish & Crown Winner" else "Next Round →",
                                onClick = onStartOrNextRound,
                                modifier = Modifier.fillMaxWidth().testTag("next_round_button")
                            )
                        }
                    } else {
                        item {
                            Text(
                                "Waiting for host @${room.hostUsername} to advance the round (${room.votes.size}/${room.playerUids.size} submitted)...",
                                style = MaterialTheme.typography.bodySmall,
                                color = colors.textSecondary
                            )
                        }
                    }
                }

                "finished" -> {
                    item {
                        LiquidGlassCard(modifier = Modifier.fillMaxWidth(), accentColor = colors.gold) {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = colors.gold, modifier = Modifier.size(48.dp))
                                Spacer(Modifier.height(8.dp))
                                Text("Game Complete!", style = MaterialTheme.typography.headlineSmall, color = colors.textPrimary)
                                Text(
                                    "Winner: @${room.winnerUsername ?: room.hostUsername}",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = colors.gold
                                )
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    "Fair match points & XP have been added to your ARK profile!",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = colors.emerald
                                )
                                val winnerName = room.winnerUsername ?: room.hostUsername
                                val myScore = room.scores[currentUserId] ?: 0L
                                Spacer(Modifier.height(12.dp))
                                OutlinedButton(
                                    onClick = {
                                        onShareGameResult(
                                            game.title,
                                            "Scored $myScore PTS across ${room.maxRounds} rounds",
                                            "@$winnerName"
                                        )
                                    },
                                    modifier = Modifier.fillMaxWidth().testTag("share_game_to_feed_button")
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null)
                                    Spacer(Modifier.width(8.dp))
                                    Text("Share Match to Feed")
                                }
                                if (isHost) {
                                    Spacer(Modifier.height(10.dp))
                                    GlowingPillButton(
                                        text = "Rematch",
                                        icon = Icons.Default.Refresh,
                                        onClick = onRematch,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ActiveGameplayCard(
    room: GameRoom,
    game: ArkGameType,
    currentUserId: String,
    myVote: String?,
    onSubmitMove: (choice: String, pointsEarned: Long, nextWordChain: String?) -> Unit
) {
    val colors = ArkThemeTokens.colors

    LiquidGlassCard(modifier = Modifier.fillMaxWidth(), accentColor = colors.cyan) {
        Text("Round ${room.roundNumber} of ${room.maxRounds}", style = MaterialTheme.typography.labelSmall, color = colors.cyan)
        Spacer(Modifier.height(6.dp))

        when (game) {
            ArkGameType.TRUTH_OR_DARE -> {
                val turnName = room.playerNames[room.currentTurnUid] ?: "Player"
                Text("Turn: @$turnName", style = MaterialTheme.typography.labelLarge, color = colors.gold)
                Spacer(Modifier.height(6.dp))
                Text(room.promptText, style = MaterialTheme.typography.titleMedium, color = colors.textPrimary)
                Spacer(Modifier.height(12.dp))
                if (myVote == null) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        GlowingPillButton(
                            text = "Completed (+30)",
                            onClick = { onSubmitMove("completed", 30L, null) },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedButton(
                            onClick = { onSubmitMove("skipped", 5L, null) },
                            modifier = Modifier.weight(1f).height(50.dp),
                            shape = RoundedCornerShape(25.dp)
                        ) {
                            Text("Skip")
                        }
                    }
                } else {
                    Text("Turn logged: $myVote ✓", color = colors.emerald, style = MaterialTheme.typography.labelLarge)
                }
            }

            ArkGameType.NEVER_HAVE_I_EVER -> {
                Text(room.promptText, style = MaterialTheme.typography.titleMedium, color = colors.textPrimary)
                Spacer(Modifier.height(12.dp))
                if (myVote == null) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        GlowingPillButton(
                            text = "I Have",
                            accent = colors.coral,
                            onClick = { onSubmitMove("I Have", 20L, null) },
                            modifier = Modifier.weight(1f)
                        )
                        GlowingPillButton(
                            text = "Never",
                            accent = colors.emerald,
                            onClick = { onSubmitMove("Never", 20L, null) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                } else {
                    Text("You voted: $myVote", color = colors.cyan, style = MaterialTheme.typography.labelLarge)
                }
            }

            ArkGameType.WOULD_YOU_RATHER -> {
                val optA = room.optionA ?: "Option A"
                val optB = room.optionB ?: "Option B"
                val totalVotes = room.votes.size.coerceAtLeast(1)
                val aCount = room.votes.values.count { it == "A" }
                val bCount = room.votes.values.count { it == "B" }

                Text(room.promptText, style = MaterialTheme.typography.titleMedium, color = colors.textPrimary)
                Spacer(Modifier.height(10.dp))
                PollOptionButton(
                    label = "A: $optA",
                    percentage = if (myVote != null) (aCount * 100) / totalVotes else null,
                    selected = myVote == "A",
                    accent = colors.cyan,
                    onClick = { if (myVote == null) onSubmitMove("A", 25L, null) }
                )
                Spacer(Modifier.height(8.dp))
                PollOptionButton(
                    label = "B: $optB",
                    percentage = if (myVote != null) (bCount * 100) / totalVotes else null,
                    selected = myVote == "B",
                    accent = colors.violet,
                    onClick = { if (myVote == null) onSubmitMove("B", 25L, null) }
                )
            }

            ArkGameType.MAFIA -> {
                val myRole = room.secretRoles?.get(currentUserId) ?: "Villager"
                UserBadgeChip(label = "Secret Role: $myRole", accent = colors.coral)
                Spacer(Modifier.height(8.dp))
                Text(room.promptText, style = MaterialTheme.typography.titleMedium, color = colors.textPrimary)
                Spacer(Modifier.height(10.dp))
                if (myVote == null) {
                    Text("Cast your vote / action:", style = MaterialTheme.typography.labelMedium, color = colors.textSecondary)
                    Spacer(Modifier.height(6.dp))
                    room.playerUids.forEach { pid ->
                        val pName = room.playerNames[pid] ?: "Player"
                        OutlinedButton(
                            onClick = { onSubmitMove(pid, 25L, null) },
                            modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                        ) {
                            Text("Vote @$pName")
                        }
                    }
                } else {
                    Text("Vote locked! Waiting for round resolution.", color = colors.emerald)
                }
            }

            ArkGameType.GUESS_THE_PERSON,
            ArkGameType.QUIZ_BATTLE,
            ArkGameType.EMOJI_CHALLENGE -> {
                Text(room.promptText, style = MaterialTheme.typography.titleMedium, color = colors.textPrimary)
                Spacer(Modifier.height(12.dp))
                val opts = room.options ?: emptyList()
                val correct = room.correctIndex?.toInt() ?: 0
                opts.forEachIndexed { idx, opt ->
                    val isSelected = myVote == idx.toString()
                    val isCorrect = idx == correct
                    val tint = when {
                        myVote == null -> colors.cyan
                        isCorrect -> colors.emerald
                        isSelected -> colors.coral
                        else -> colors.textSecondary
                    }
                    OutlinedButton(
                        onClick = {
                            if (myVote == null) {
                                val pts = if (idx == correct) 40L else 10L
                                onSubmitMove(idx.toString(), pts, null)
                            }
                        },
                        border = BorderStroke(1.dp, tint),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
                    ) {
                        Text(opt, color = tint)
                    }
                }
            }

            ArkGameType.WORD_CHAIN -> {
                val currentWord = room.promptText.ifBlank { "SPARK" }
                val requiredLetter = currentWord.lastOrNull()?.uppercaseChar() ?: 'K'
                var nextWord by remember(room.roundNumber) { mutableStateOf("") }
                var wordError by remember { mutableStateOf<String?>(null) }

                Text("Current Word:", style = MaterialTheme.typography.labelMedium, color = colors.textSecondary)
                Text(currentWord, style = MaterialTheme.typography.headlineMedium, color = colors.cyan)
                Spacer(Modifier.height(6.dp))
                Text("Submit a word starting with '$requiredLetter'", style = MaterialTheme.typography.bodyMedium, color = colors.gold)
                Spacer(Modifier.height(10.dp))
                if (myVote == null) {
                    OutlinedTextField(
                        value = nextWord,
                        onValueChange = { nextWord = it.trim().filter { c -> c.isLetter() }.take(24) },
                        label = { Text("Your word ($requiredLetter...)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (wordError != null) {
                        Text(wordError!!, color = colors.coral, style = MaterialTheme.typography.bodySmall)
                    }
                    Spacer(Modifier.height(8.dp))
                    GlowingPillButton(
                        text = "Submit Word (+25)",
                        onClick = {
                            val clean = nextWord.trim().uppercase()
                            if (clean.length < 3 || clean.firstOrNull() != requiredLetter) {
                                wordError = "Word must be >= 3 letters and start with '$requiredLetter'."
                            } else {
                                wordError = null
                                onSubmitMove(clean, 25L, clean)
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    Text("Submitted: $myVote ✓", color = colors.emerald, style = MaterialTheme.typography.labelLarge)
                }
            }

            ArkGameType.QUICK_REACTION -> {
                var phase by remember(room.roundNumber) { mutableStateOf("arming") }
                var goTimestamp by remember(room.roundNumber) { mutableLongStateOf(0L) }
                var reactionMs by remember(room.roundNumber) { mutableLongStateOf(0L) }

                LaunchedEffect(room.roundNumber, myVote) {
                    if (myVote == null) {
                        phase = "waiting"
                        delay(Random.nextLong(1200L, 3200L))
                        goTimestamp = System.currentTimeMillis()
                        phase = "go"
                    }
                }

                val padColor by animateColorAsState(
                    targetValue = when (phase) {
                        "go" -> colors.emerald
                        "done" -> colors.cyan
                        else -> colors.coral
                    },
                    label = "reactor"
                )

                Text(room.promptText, style = MaterialTheme.typography.titleMedium, color = colors.textPrimary)
                Spacer(Modifier.height(12.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(padColor.copy(alpha = 0.25f))
                        .clickable(enabled = myVote == null) {
                            if (phase == "go") {
                                val ms = (System.currentTimeMillis() - goTimestamp).coerceAtLeast(1L)
                                reactionMs = ms
                                phase = "done"
                                val pts = (60L - (ms / 25L)).coerceIn(15L, 60L)
                                onSubmitMove("${ms}ms", pts, null)
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Bolt, contentDescription = null, tint = padColor, modifier = Modifier.size(36.dp))
                        Text(
                            text = when {
                                myVote != null -> "Reflex: $myVote ✓"
                                phase == "go" -> "TAP NOW!"
                                else -> "WAIT FOR EMERALD..."
                            },
                            style = MaterialTheme.typography.titleMedium,
                            color = padColor
                        )
                    }
                }
            }

            ArkGameType.MEMORY_CHALLENGE -> {
                val targetSeq = remember(room.promptText) {
                    room.promptText.split("-").mapNotNull { it.toIntOrNull() }.ifEmpty { listOf(1, 2, 3, 4) }
                }
                var highlightedPad by remember(room.roundNumber) { mutableIntStateOf(-1) }
                var showingSequence by remember(room.roundNumber) { mutableStateOf(true) }
                var userSequence by remember(room.roundNumber) { mutableStateOf<List<Int>>(emptyList()) }

                LaunchedEffect(room.roundNumber, myVote) {
                    if (myVote == null) {
                        showingSequence = true
                        delay(450L)
                        for (pad in targetSeq) {
                            highlightedPad = pad
                            delay(500L)
                            highlightedPad = -1
                            delay(200L)
                        }
                        showingSequence = false
                    }
                }

                Text(
                    if (showingSequence) "Memorize the Neon Sequence..." else "Repeat ${targetSeq.size} Pads (${userSequence.size}/${targetSeq.size})",
                    style = MaterialTheme.typography.titleMedium,
                    color = colors.textPrimary
                )
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    (1..4).forEach { pad ->
                        val padColors = listOf(colors.cyan, colors.violet, colors.emerald, colors.gold)
                        val baseColor = padColors[pad - 1]
                        val lit = highlightedPad == pad
                        Button(
                            onClick = {
                                if (!showingSequence && myVote == null) {
                                    val next = userSequence + pad
                                    userSequence = next
                                    if (next.size == targetSeq.size) {
                                        val exact = next == targetSeq
                                        onSubmitMove(if (exact) "perfect" else "attempt", if (exact) 50L else 15L, null)
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (lit) baseColor else baseColor.copy(alpha = 0.28f)
                            ),
                            modifier = Modifier.weight(1f).height(64.dp),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Text("$pad", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                if (myVote != null) {
                    Spacer(Modifier.height(8.dp))
                    Text("Sequence submitted: $myVote ✓", color = colors.emerald, style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}

@Composable
private fun PollOptionButton(
    label: String,
    percentage: Int?,
    selected: Boolean,
    accent: Color,
    onClick: () -> Unit
) {
    val colors = ArkThemeTokens.colors
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = if (selected) accent.copy(alpha = 0.22f) else colors.glassSurfaceElevated,
        border = BorderStroke(1.dp, if (selected) accent else colors.glassBorder)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(label, style = MaterialTheme.typography.bodyMedium, color = colors.textPrimary, modifier = Modifier.weight(1f))
                if (percentage != null) {
                    Text("$percentage%", style = MaterialTheme.typography.labelLarge, color = accent)
                }
            }
            if (percentage != null) {
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { percentage / 100f },
                    modifier = Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)),
                    color = accent
                )
            }
        }
    }
}
