package com.example.ui.screens.snowtam

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SnowtamData
import com.example.ui.components.*
import com.example.ui.navigation.Screen
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusRed
import com.example.ui.theme.StatusYellow
import com.example.ui.viewmodel.WeatherViewModel

@Composable
fun SnowtamScreen(
  viewModel: WeatherViewModel,
  onNavigateTo: (Screen) -> Unit,
  modifier: Modifier = Modifier
) {
  val selectedAirport by viewModel.selectedAirport.collectAsState()
  val snowtams by viewModel.snowtams.collectAsState()
  val isOffline by viewModel.isOffline.collectAsState()

  var showIngestDialog by remember { mutableStateOf(false) }
  var ingestInputText by remember { mutableStateOf("") }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp)
      .testTag("snowtam_screen"),
    verticalArrangement = Arrangement.spacedBy(14.dp),
    contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
  ) {
    if (isOffline) {
      item { OfflineNoticeBanner() }
    }

    // Header & Actions
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "اسنوتام و وضعیت باند (SNOWTAM / RCR)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "بر اساس فرمت گزارش‌دهی جهانی ایکائو (ICAO GRF & Doc 10066)",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        Row {
          IconButton(
            onClick = { showIngestDialog = true },
            modifier = Modifier.testTag("btn_ingest_snowtam")
          ) {
            Icon(Icons.Default.Add, contentDescription = "ثبت / بارگذاری اسنوتام", tint = MaterialTheme.colorScheme.primary)
          }
          IconButton(
            onClick = { viewModel.seedOfficialSampleSnowtam() },
            modifier = Modifier.testTag("btn_load_sample_snowtam")
          ) {
            Icon(Icons.Default.Download, contentDescription = "نمونه رسمی ایکائو", tint = MaterialTheme.colorScheme.primary)
          }
        }
      }
    }

    // Status / Source Connection Notice
    item {
      if (snowtams.isEmpty()) {
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
          border = CardDefaults.outlinedCardBorder(),
          modifier = Modifier.fillMaxWidth().testTag("snowtam_not_configured_card")
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Info, contentDescription = null, tint = StatusYellow)
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "SNOWTAM SOURCE NOT CONFIGURED",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = StatusYellow
              )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = "اتصال خودکار به فید مستقیم اسنوتام OPMET برای فرودگاه ${selectedAirport.icao} پیکربندی نشده است. پورتال‌های رسمی اسنوتام نیازمند لاگین شبکه هوانوردی AIS/AMHS هستند.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Button(
                onClick = { viewModel.seedOfficialSampleSnowtam() },
                modifier = Modifier.weight(1f).testTag("btn_test_icao_sample")
              ) {
                Text("بارگذاری بولتن نمونه رسمی Doc 10066")
              }
              OutlinedButton(
                onClick = { showIngestDialog = true },
                modifier = Modifier.weight(1f)
              ) {
                Text("ورود دستی متن اسنوتام")
              }
            }
          }
        }
      }
    }

    // 15. SNOWTAM QUICK VIEW (If available)
    if (snowtams.isNotEmpty()) {
      val latest = snowtams.first()

      item {
        RunwayThirdsVisualizer(
          runwayDesignator = latest.runwayDesignator,
          rwycc1 = latest.rwyccPart1,
          rwycc2 = latest.rwyccPart2,
          rwycc3 = latest.rwyccPart3,
          lowestRwycc = latest.lowestRwycc,
          contaminantType = latest.contaminantType,
          depthMm1 = latest.depthMmPart1,
          depthMm2 = latest.depthMmPart2,
          depthMm3 = latest.depthMmPart3,
          coveragePercent1 = latest.coveragePercentPart1,
          coveragePercent2 = latest.coveragePercentPart2,
          coveragePercent3 = latest.coveragePercentPart3
        )
      }

      // Latest SNOWTAM Raw Message
      item {
        RawMessageCard(
          titleFa = "پیام خام اسنوتام (Original SNOWTAM)",
          rawText = latest.rawSnowtam,
          source = latest.source,
          issueTimeUtc = latest.issueTimeUtc,
          receiptTimeUtc = latest.receivedTimeUtc
        )
      }
    }

    // ICAO GRF & SNOWTAM Educational Guide Shortcut
    item {
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onNavigateTo(Screen.ICAO_GUIDE) }
          .testTag("btn_icao_guide_shortcut")
      ) {
        Row(
          modifier = Modifier.padding(14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.MenuBook, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "راهنمای استانداردهای ICAO GRF و اسنوتام",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = "تعریف کدهای RWYCC، بخش‌های سه‌گانه باند و جداول ارزیابی آلاینده‌ها",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
          Icon(Icons.Default.ChevronLeft, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        }
      }
    }

    // 17. SNOWTAM HISTORY
    item {
      Column {
        Text(
          text = "تاریخچه گزارش‌های وضعیت باند ذخیره شده (SNOWTAM History)",
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = "فقط پیام‌هایی که واقعاً دریافت و در پایگاه داده محلی ذخیره شده‌اند نمایش داده می‌شوند.",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }

    if (snowtams.isEmpty()) {
      item {
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = MaterialTheme.colorScheme.surfaceVariant,
          border = CardDefaults.outlinedCardBorder(),
          modifier = Modifier.fillMaxWidth()
        ) {
          Box(modifier = Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
            Text(
              text = "NO STORED HISTORY (هیچ سابقه اسنوتامی ذخیره نشده است)",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    } else {
      items(snowtams) { item ->
        Card(
          shape = RoundedCornerShape(10.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = CardDefaults.outlinedCardBorder(),
          modifier = Modifier.fillMaxWidth().testTag("snowtam_history_item_${item.id}")
        ) {
          Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column {
              Text(
                text = "باند ${item.runwayDesignator} • سریال: ${item.serialNumber.ifBlank { "0001" }}",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = "زمان گزارش: ${item.issueTimeUtc} • دریافت: ${item.receivedTimeUtc}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
              if (item.contaminantType.isNotBlank()) {
                Text(
                  text = "آلاینده: ${item.contaminantType}",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.primary
                )
              }
            }

            if (item.lowestRwycc != null) {
              Surface(
                shape = RoundedCornerShape(6.dp),
                color = MaterialTheme.colorScheme.primaryContainer
              ) {
                Text(
                  text = "RWYCC: ${item.rwyccPart1}/${item.rwyccPart2}/${item.rwyccPart3}",
                  style = MaterialTheme.typography.labelMedium,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.onPrimaryContainer,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
              }
            }
          }
        }
      }
    }

    item { OperationalDisclaimerCard() }
  }

  // Ingest Dialog
  if (showIngestDialog) {
    AlertDialog(
      onDismissRequest = { showIngestDialog = false },
      title = { Text("ورود یا الصاق پیام SNOWTAM") },
      text = {
        Column {
          Text(
            text = "متن بولتن خام اسنوتام دریافتی از شبکه هوانوردی را وارد نمایید:",
            style = MaterialTheme.typography.bodySmall
          )
          Spacer(modifier = Modifier.height(8.dp))
          OutlinedTextField(
            value = ingestInputText,
            onValueChange = { ingestInputText = it },
            modifier = Modifier.fillMaxWidth().height(140.dp).testTag("input_snowtam_text"),
            placeholder = { Text("SWIR0001 OIIE 12050020\n(SNOWTAM 0001 OIIE 29R 5/5/5 ...)") }
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (ingestInputText.isNotBlank()) {
              viewModel.ingestCustomOrSampleSnowtam(ingestInputText)
            }
            showIngestDialog = false
            ingestInputText = ""
          },
          modifier = Modifier.testTag("btn_confirm_ingest_snowtam")
        ) {
          Text("پردازش و ذخیره")
        }
      },
      dismissButton = {
        TextButton(onClick = { showIngestDialog = false }) {
          Text("انصراف")
        }
      }
    )
  }
}
