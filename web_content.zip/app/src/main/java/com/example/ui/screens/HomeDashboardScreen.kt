package com.example.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Eject
import androidx.compose.material.icons.filled.FolderSpecial
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.SdStorage
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LargeTopAppBar
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.ByteSizeFormatter
import com.example.data.local.ShortcutEntity
import com.example.data.model.FileCategory
import com.example.data.model.FileNode
import com.example.data.model.StorageRootType
import com.example.data.model.StorageVolumeInfo
import com.example.ui.components.FileBadgePill
import com.example.ui.components.FileTypeThumbnail
import com.example.ui.components.resolveCategoryVisual
import com.example.ui.theme.LocalAnimationSpecs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeDashboardScreen(
    volumes: List<StorageVolumeInfo>,
    recentFiles: List<FileNode>,
    shortcuts: List<ShortcutEntity>,
    categoryCounts: Map<FileCategory, Int>,
    categorySizes: Map<FileCategory, Long>,
    trashCount: Int,
    showExtensions: Boolean,
    onOpenSearch: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenCamera: () -> Unit,
    onOpenCategory: (FileCategory) -> Unit,
    onOpenFavorites: () -> Unit,
    onOpenVolume: (StorageVolumeInfo) -> Unit,
    onMountDeviceFolder: () -> Unit,
    onMountCloudProvider: () -> Unit,
    onEjectVolume: (StorageVolumeInfo) -> Unit,
    onOpenRecentFile: (FileNode) -> Unit,
    onOpenShortcutPath: (String) -> Unit,
    onOpenTrash: () -> Unit,
    onOpenAnalyzeStorage: () -> Unit
) {
    val scrollBehavior = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()
    var showOverflowMenu by remember { mutableStateOf(false) }
    val animSpecs = LocalAnimationSpecs.current

    val hasSafMounted = volumes.any { it.type == StorageRootType.SAF_FOLDER }
    val hasUsbConnected = volumes.any { it.type == StorageRootType.USB_OTG }

    Scaffold(
        modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = {
            LargeTopAppBar(
                title = {
                    Text(
                        text = "My Files",
                        fontWeight = FontWeight.Bold
                    )
                },
                actions = {
                    IconButton(
                        onClick = onOpenCamera,
                        modifier = Modifier.testTag("home_camera_button")
                    ) {
                        Icon(Icons.Filled.CameraAlt, contentDescription = "Capture photo or video")
                    }
                    IconButton(
                        onClick = onOpenSearch,
                        modifier = Modifier.testTag("home_search_button")
                    ) {
                        Icon(Icons.Filled.Search, contentDescription = "Search files")
                    }
                    Box {
                        IconButton(
                            onClick = { showOverflowMenu = true },
                            modifier = Modifier.testTag("home_more_menu_button")
                        ) {
                            Icon(Icons.Filled.MoreVert, contentDescription = "More options")
                        }
                        DropdownMenu(
                            expanded = showOverflowMenu,
                            onDismissRequest = { showOverflowMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Mount device folder (SAF)") },
                                onClick = {
                                    showOverflowMenu = false
                                    onMountDeviceFolder()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Analyze storage") },
                                onClick = {
                                    showOverflowMenu = false
                                    onOpenAnalyzeStorage()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Trash") },
                                onClick = {
                                    showOverflowMenu = false
                                    onOpenTrash()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Settings") },
                                leadingIcon = { Icon(Icons.Filled.Settings, contentDescription = null) },
                                onClick = {
                                    showOverflowMenu = false
                                    onOpenSettings()
                                }
                            )
                        }
                    }
                },
                scrollBehavior = scrollBehavior,
                colors = TopAppBarDefaults.largeTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    scrolledContainerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Capability Banner when external device folders haven't been granted via SAF yet
            if (!hasSafMounted) {
                item {
                    Card(
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.65f)
                        ),
                        modifier = Modifier
                            .widthIn(max = 680.dp)
                            .fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Filled.FolderSpecial,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    "Scoped Storage Active",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    "Internal workspace is ready. Grant SAF folder access to browse shared Downloads, DCIM, or Documents.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(Modifier.width(8.dp))
                            FilledTonalButton(
                                onClick = onMountDeviceFolder,
                                modifier = Modifier.testTag("banner_mount_saf_button")
                            ) {
                                Text("Mount")
                            }
                        }
                    }
                }
            }

            // Recent Files Horizontal List
            item {
                Column(
                    modifier = Modifier
                        .widthIn(max = 680.dp)
                        .fillMaxWidth()
                ) {
                    SectionHeader("Recent files")
                    Card(
                        shape = RoundedCornerShape(26.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (recentFiles.isEmpty()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(18.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("No recent files yet", style = MaterialTheme.typography.titleSmall)
                                    Text(
                                        "Capture a photo/video or mount a folder to see recent items here.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                FilledTonalButton(onClick = onOpenCamera) {
                                    Icon(Icons.Filled.CameraAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Camera")
                                }
                            }
                        } else {
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                items(recentFiles, key = { it.path }) { node ->
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier
                                            .width(86.dp)
                                            .clip(RoundedCornerShape(16.dp))
                                            .clickable { onOpenRecentFile(node) }
                                            .padding(6.dp)
                                    ) {
                                        FileTypeThumbnail(node = node, size = 60.dp)
                                        Spacer(Modifier.height(6.dp))
                                        Text(
                                            text = node.displayName(showExtensions),
                                            style = MaterialTheme.typography.labelMedium,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = ByteSizeFormatter.format(node.sizeBytes),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Pinned Home Shortcuts (if user added any)
            if (shortcuts.isNotEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .widthIn(max = 680.dp)
                            .fillMaxWidth()
                    ) {
                        SectionHeader("Shortcuts")
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(shortcuts, key = { it.path }) { sc ->
                                Surface(
                                    color = MaterialTheme.colorScheme.surface,
                                    shape = RoundedCornerShape(18.dp),
                                    modifier = Modifier.clickable { onOpenShortcutPath(sc.path) }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            Icons.Filled.FolderSpecial,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(Modifier.width(8.dp))
                                        Text(sc.label, style = MaterialTheme.typography.labelLarge)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Categories Grid (Samsung One UI 4x2 / 2-column rounded grid with counts & sizes)
            item {
                Column(
                    modifier = Modifier
                        .widthIn(max = 680.dp)
                        .fillMaxWidth()
                ) {
                    SectionHeader("Categories")
                    Card(
                        shape = RoundedCornerShape(26.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        val categories = FileCategory.entries
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            categories.chunked(2).forEach { pair ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    for (cat in pair) {
                                        val (icon, tint) = resolveCategoryVisual(cat)
                                        val count = categoryCounts[cat] ?: 0
                                        val bytes = categorySizes[cat] ?: 0L
                                        Surface(
                                            color = MaterialTheme.colorScheme.background.copy(alpha = 0.55f),
                                            shape = RoundedCornerShape(18.dp),
                                            modifier = Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(18.dp))
                                                .clickable { onOpenCategory(cat) }
                                                .testTag("category_${cat.name.lowercase()}")
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(12.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Surface(
                                                    color = tint.copy(alpha = 0.14f),
                                                    shape = RoundedCornerShape(13.dp),
                                                    modifier = Modifier.size(40.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = icon,
                                                        contentDescription = cat.label,
                                                        tint = tint,
                                                        modifier = Modifier.padding(9.dp)
                                                    )
                                                }
                                                Spacer(Modifier.width(10.dp))
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = cat.label,
                                                        style = MaterialTheme.typography.titleSmall,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                    Text(
                                                        text = "$count • ${ByteSizeFormatter.format(bytes)}",
                                                        style = MaterialTheme.typography.labelSmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        maxLines = 1
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .clickable { onOpenFavorites() }
                                    .padding(horizontal = 12.dp, vertical = 10.dp)
                                    .testTag("favorites_row"),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Filled.Star,
                                    contentDescription = "Favorites",
                                    tint = androidx.compose.ui.graphics.Color(0xFFF59E0B)
                                )
                                Spacer(Modifier.width(12.dp))
                                Text("Favorites", style = MaterialTheme.typography.titleSmall)
                            }
                        }
                    }
                }
            }

            // Storage Section (Internal Storage, Mounted SAF Folders, and USB OTG)
            item {
                Column(
                    modifier = Modifier
                        .widthIn(max = 680.dp)
                        .fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        SectionHeader("Storage")
                        FilledTonalButton(
                            onClick = onMountDeviceFolder,
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("add_saf_folder_button")
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Add Folder", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Card(
                        shape = RoundedCornerShape(26.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(vertical = 8.dp)) {
                            volumes.filter { it.type != StorageRootType.SAF_CLOUD }.forEachIndexed { idx, vol ->
                                if (idx > 0) {
                                    HorizontalDivider(modifier = Modifier.padding(horizontal = 20.dp))
                                }
                                StorageVolumeRow(
                                    volume = vol,
                                    animProgressSpec = animSpecs.progressSpec(),
                                    onClick = { onOpenVolume(vol) },
                                    onEject = { onEjectVolume(vol) }
                                )
                            }

                            if (!hasUsbConnected) {
                                HorizontalDivider(modifier = Modifier.padding(horizontal = 20.dp))
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 20.dp, vertical = 14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Filled.Usb,
                                        contentDescription = "USB Storage",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(26.dp)
                                    )
                                    Spacer(Modifier.width(14.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("USB / SD storage", style = MaterialTheme.typography.titleMedium)
                                        Text(
                                            "Not connected • Plug in USB OTG drive (FAT32, exFAT, NTFS, ext4)",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Cloud, Trash, & Analyze Storage Section
            item {
                Column(
                    modifier = Modifier
                        .widthIn(max = 680.dp)
                        .fillMaxWidth()
                        .padding(bottom = 24.dp)
                ) {
                    SectionHeader("Cloud & Storage Tools")
                    Card(
                        shape = RoundedCornerShape(26.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(vertical = 6.dp)) {
                            val cloudVolumes = volumes.filter { it.type == StorageRootType.SAF_CLOUD }
                            if (cloudVolumes.isEmpty()) {
                                UtilityRow(
                                    icon = Icons.Filled.CloudQueue,
                                    title = "Google Drive / Cloud Drive",
                                    subtitle = "Connect cloud document provider via Android SAF",
                                    testTag = "cloud_drive_row",
                                    onClick = onMountCloudProvider
                                )
                            } else {
                                cloudVolumes.forEach { cv ->
                                    UtilityRow(
                                        icon = Icons.Filled.CloudQueue,
                                        title = cv.title,
                                        subtitle = cv.subtitle,
                                        testTag = "cloud_drive_mounted_${cv.id}",
                                        onClick = { onOpenVolume(cv) }
                                    )
                                }
                            }

                            HorizontalDivider(modifier = Modifier.padding(horizontal = 20.dp))
                            UtilityRow(
                                icon = Icons.Filled.DeleteOutline,
                                title = "Trash",
                                subtitle = if (trashCount == 0) "Empty • Auto-deletes items after 30 days" else "$trashCount item(s) in Recycle bin",
                                testTag = "trash_row",
                                onClick = onOpenTrash
                            )

                            HorizontalDivider(modifier = Modifier.padding(horizontal = 20.dp))
                            UtilityRow(
                                icon = Icons.Filled.PieChart,
                                title = "Analyze storage",
                                subtitle = "Category breakdown, large files, duplicates & cleanup",
                                testTag = "analyze_storage_row",
                                onClick = onOpenAnalyzeStorage
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 8.dp, bottom = 8.dp)
    )
}

@Composable
private fun StorageVolumeRow(
    volume: StorageVolumeInfo,
    animProgressSpec: androidx.compose.animation.core.AnimationSpec<Float>,
    onClick: () -> Unit,
    onEject: () -> Unit
) {
    val rawRatio = if (volume.totalBytes > 0L) {
        (volume.usedBytes.toFloat() / volume.totalBytes.toFloat()).coerceIn(0f, 1f)
    } else 0f
    val animatedRatio by animateFloatAsState(
        targetValue = rawRatio,
        animationSpec = animProgressSpec,
        label = "storage_bar"
    )

    val icon = when (volume.type) {
        StorageRootType.INTERNAL_WORKSPACE -> Icons.Filled.Smartphone
        StorageRootType.USB_OTG -> Icons.Filled.Usb
        StorageRootType.SAF_CLOUD -> Icons.Filled.CloudQueue
        StorageRootType.SAF_FOLDER -> Icons.Filled.SdStorage
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp)
            .testTag("volume_row_${volume.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            color = MaterialTheme.colorScheme.primaryContainer,
            shape = RoundedCornerShape(15.dp),
            modifier = Modifier.size(44.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = volume.title,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(10.dp)
            )
        }
        Spacer(Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = volume.title,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                FileBadgePill(text = volume.fileSystemType.label)
                if (volume.isReadOnly) {
                    FileBadgePill(text = "Read-only", isWarning = true)
                }
            }
            Text(
                text = if (volume.totalBytes > 0L) {
                    ByteSizeFormatter.formatUsedOfTotal(volume.usedBytes, volume.totalBytes)
                } else {
                    volume.subtitle
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (volume.totalBytes > 0L) {
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { animatedRatio },
                    strokeCap = StrokeCap.Round,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(7.dp)
                )
            }
            if (volume.isUnsupportedFormat && volume.unsupportedExplanation != null) {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = volume.unsupportedExplanation,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.error
                )
            }
        }
        if (volume.isEjectable) {
            IconButton(
                onClick = onEject,
                modifier = Modifier.testTag("eject_volume_${volume.id}")
            ) {
                Icon(Icons.Filled.Eject, contentDescription = "Safe eject ${volume.title}")
            }
        }
    }
}

@Composable
private fun UtilityRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    testTag: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            color = MaterialTheme.colorScheme.secondaryContainer,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.size(42.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(10.dp)
            )
        }
        Spacer(Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
