package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.NavigateBefore
import androidx.compose.material.icons.filled.NavigateNext
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.AudioSpectrumData
import com.example.model.EqualizerPreset
import com.example.model.Song
import com.example.model.VisualizerRegistry
import com.example.ui.components.PowerampAudioSpecsDialog
import com.example.ui.components.PowerampProControlsRow
import com.example.ui.components.PowerampProVisualizerHUD
import com.example.ui.components.PowerampWaveformSeekbar
import com.example.ui.components.VisualizerCanvas
import com.example.ui.components.VisualizerPickerSheet
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun NowPlayingScreen(
    song: Song,
    isPlaying: Boolean,
    currentPositionSec: Float,
    selectedVisualizerId: Int,
    spectrumData: AudioSpectrumData,
    currentEqualizer: EqualizerPreset,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeek: (Float) -> Unit,
    onToggleFavorite: () -> Unit,
    onSelectVisualizer: (Int) -> Unit,
    onRandomVisualizer: () -> Unit,
    onNavigateToEqualizer: () -> Unit,
    onCollapse: () -> Unit
) {
    var isFullscreenVisualizer by remember { mutableStateOf(false) }
    var showVisualizerPicker by remember { mutableStateOf(false) }
    var showAudioSpecsDialog by remember { mutableStateOf(false) }
    var isVisualizerLocked by remember { mutableStateOf(false) }

    var shuffleMode by remember { mutableIntStateOf(0) } // 0: off, 1: all, 2: categories
    var repeatMode by remember { mutableIntStateOf(0) }  // 0: off, 1: all, 2: one

    var dragDistance by remember { mutableFloatStateOf(0f) }

    val visualizerItem = remember(selectedVisualizerId) {
        VisualizerRegistry.ALL_150_VISUALIZERS.getOrNull(selectedVisualizerId - 1)
            ?: VisualizerRegistry.ALL_150_VISUALIZERS.first()
    }

    fun stepVisualizer(next: Boolean) {
        val total = VisualizerRegistry.ALL_150_VISUALIZERS.size
        val newId = if (next) {
            if (selectedVisualizerId < total) selectedVisualizerId + 1 else 1
        } else {
            if (selectedVisualizerId > 1) selectedVisualizerId - 1 else total
        }
        onSelectVisualizer(newId)
    }

    if (isFullscreenVisualizer) {
        // Fullscreen Poweramp Pro Milkdrop Visualizer Mode
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(ObsidianBg)
                .testTag("fullscreen_visualizer_mode")
        ) {
            VisualizerCanvas(
                visualizerId = selectedVisualizerId,
                spectrumData = spectrumData,
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onDoubleTap = {
                                if (!isVisualizerLocked) stepVisualizer(true)
                            }
                        )
                    }
            )

            // Top Poweramp Pro OSD HUD
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Preset name OSD
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(ObsidianBg.copy(alpha = 0.85f))
                        .border(1.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .clickable { showVisualizerPicker = true }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.GraphicEq,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "#${visualizerItem.id} ${visualizerItem.name}",
                            color = NeonCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // OSD Buttons: Prev, Lock, Next, Exit
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(ObsidianBg.copy(alpha = 0.8f))
                            .clickable { stepVisualizer(false) },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.NavigateBefore, contentDescription = "Prev", tint = Color.White, modifier = Modifier.size(20.dp))
                    }

                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(ObsidianBg.copy(alpha = 0.8f))
                            .clickable { isVisualizerLocked = !isVisualizerLocked },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isVisualizerLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                            contentDescription = "Lock",
                            tint = if (isVisualizerLocked) NeonPink else Color.Gray,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(ObsidianBg.copy(alpha = 0.8f))
                            .clickable { stepVisualizer(true) },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.NavigateNext, contentDescription = "Next", tint = Color.White, modifier = Modifier.size(20.dp))
                    }

                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(ObsidianBg.copy(alpha = 0.8f))
                            .clickable { isFullscreenVisualizer = false },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.FullscreenExit, contentDescription = "Exit", tint = Color.White, modifier = Modifier.size(20.dp))
                    }
                }
            }

            // Bottom Floating Controls Overlay with Real-Time Waveform
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Transparent, ObsidianBg.copy(alpha = 0.96f))
                        )
                    )
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = song.title,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${song.artist} • ${song.hiResBadgeText}",
                            color = NeonCyan,
                            fontSize = 12.sp,
                            maxLines = 1
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Poweramp Waveform Seekbar moving in exact sync with audio
                PowerampWaveformSeekbar(
                    waveformPeaks = song.waveformPoints,
                    currentPositionSec = currentPositionSec,
                    durationSec = song.durationSec,
                    isPlaying = isPlaying,
                    onSeek = onSeek,
                    rmsPulse = spectrumData.rmsLevel
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Poweramp Pro Transport Buttons
                PowerampProControlsRow(
                    isPlaying = isPlaying,
                    shuffleMode = shuffleMode,
                    repeatMode = repeatMode,
                    onPlayPause = onPlayPause,
                    onNext = onNext,
                    onPrevious = onPrevious,
                    onToggleShuffle = { shuffleMode = (shuffleMode + 1) % 3 },
                    onToggleRepeat = { repeatMode = (repeatMode + 1) % 3 }
                )
            }
        }
    } else {
        // Standard Poweramp Pro Now Playing Screen
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(ObsidianBg)
                .padding(horizontal = 18.dp)
                .testTag("now_playing_screen")
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            // Poweramp Pro Header Row with Codec & DVC Badges
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onCollapse,
                    modifier = Modifier.testTag("now_playing_collapse_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowDown,
                        contentDescription = "Collapse",
                        tint = Color.White,
                        modifier = Modifier.size(30.dp)
                    )
                }

                // Poweramp Hi-Res & DVC clickable badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(SurfaceDark)
                        .border(1.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                        .clickable { showAudioSpecsDialog = true }
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                        .testTag("audiophile_badge_chip")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = null,
                            tint = NeonCyan,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${song.codec} • ${song.sampleRateHz / 1000}kHz / ${song.bitDepth}-bit",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = "DVC",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = NeonCyan
                        )
                    }
                }

                IconButton(
                    onClick = onNavigateToEqualizer,
                    modifier = Modifier.testTag("now_playing_eq_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Equalizer,
                        contentDescription = "Equalizer",
                        tint = NeonCyan
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Visualizer Stage Card with Poweramp Pro HUD & Gestures
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(255.dp)
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onDoubleTap = {
                                if (!isVisualizerLocked) stepVisualizer(true)
                            }
                        )
                    }
                    .pointerInput(Unit) {
                        detectHorizontalDragGestures(
                            onDragStart = { dragDistance = 0f },
                            onHorizontalDrag = { change, dragAmount ->
                                change.consume()
                                dragDistance += dragAmount
                            },
                            onDragEnd = {
                                if (dragDistance > 75f) {
                                    onPrevious()
                                } else if (dragDistance < -75f) {
                                    onNext()
                                }
                                dragDistance = 0f
                            }
                        )
                    },
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = androidx.compose.foundation.BorderStroke(1.2.dp, Color.White.copy(alpha = 0.08f))
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    // Visualizer Canvas
                    VisualizerCanvas(
                        visualizerId = selectedVisualizerId,
                        spectrumData = spectrumData,
                        modifier = Modifier.fillMaxSize()
                    )

                    // Poweramp Pro Visualizer HUD
                    PowerampProVisualizerHUD(
                        visualizerId = selectedVisualizerId,
                        visualizerName = visualizerItem.name,
                        isLocked = isVisualizerLocked,
                        onToggleLock = { isVisualizerLocked = !isVisualizerLocked },
                        onPrevVisualizer = { stepVisualizer(false) },
                        onNextVisualizer = { stepVisualizer(true) },
                        onPickerClick = { showVisualizerPicker = true },
                        onFullscreenClick = { isFullscreenVisualizer = true },
                        modifier = Modifier.align(Alignment.TopCenter)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Song Info & Favorite
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = song.title,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 20.sp,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${song.artist} • ${song.album}",
                        fontSize = 13.sp,
                        color = Color.LightGray,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = song.fullCodecDetail,
                        fontSize = 11.sp,
                        color = NeonCyan,
                        maxLines = 1
                    )
                }

                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier.testTag("now_playing_fav_btn")
                ) {
                    Icon(
                        imageVector = if (song.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (song.isFavorite) NeonPink else Color.Gray,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            // Custom Tags Flow
            if (song.customTags.isNotEmpty()) {
                Spacer(modifier = Modifier.height(4.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    song.customTags.forEach { tag ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(NeonPurple.copy(alpha = 0.2f))
                                .border(1.dp, NeonPurple.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 7.dp, vertical = 2.dp)
                        ) {
                            Text("#$tag", color = NeonPurple, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Poweramp Waveform Seekbar (moves smoothly in exact sync with audio)
            PowerampWaveformSeekbar(
                waveformPeaks = song.waveformPoints,
                currentPositionSec = currentPositionSec,
                durationSec = song.durationSec,
                isPlaying = isPlaying,
                onSeek = onSeek,
                rmsPulse = spectrumData.rmsLevel
            )

            // Time Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val curSecInt = currentPositionSec.toInt()
                val curMin = curSecInt / 60
                val curS = curSecInt % 60
                Text(
                    text = "%d:%02d".format(curMin, curS),
                    fontSize = 12.sp,
                    color = NeonCyan,
                    fontWeight = FontWeight.SemiBold
                )

                val remainingSec = (song.durationSec - curSecInt).coerceAtLeast(0)
                val remMin = remainingSec / 60
                val remS = remainingSec % 60
                Text(
                    text = "-%d:%02d".format(remMin, remS),
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Poweramp Pro Audiophile Quick Bar: [EQ] [VIS] [DVC] [INFO]
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Quick EQ button
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(SurfaceDark)
                        .clickable { onNavigateToEqualizer() }
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                        .testTag("quick_bar_eq"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Tune, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(currentEqualizer.name.take(12), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    }
                }

                // Quick DVC preamp gain pill
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(SurfaceDark)
                        .clickable { onNavigateToEqualizer() }
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                        .testTag("quick_bar_dvc"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Bolt, contentDescription = null, tint = NeonPurple, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "DVC ${if (currentEqualizer.preampDb > 0) "+" else ""}${String.format("%.1f", currentEqualizer.preampDb)}dB",
                            color = NeonPurple,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                    }
                }

                // Quick Audio Specs Info
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(SurfaceDark)
                        .clickable { showAudioSpecsDialog = true }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("quick_bar_info"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("SPECS", color = Color.LightGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Poweramp Pro Transport Buttons Row (Shuffle, Prev, Big Dual-Ring Play/Pause, Next, Repeat)
            PowerampProControlsRow(
                isPlaying = isPlaying,
                shuffleMode = shuffleMode,
                repeatMode = repeatMode,
                onPlayPause = onPlayPause,
                onNext = onNext,
                onPrevious = onPrevious,
                onToggleShuffle = { shuffleMode = (shuffleMode + 1) % 3 },
                onToggleRepeat = { repeatMode = (repeatMode + 1) % 3 }
            )

            Spacer(modifier = Modifier.height(10.dp))
        }
    }

    if (showVisualizerPicker) {
        VisualizerPickerSheet(
            selectedId = selectedVisualizerId,
            onSelectVisualizer = { onSelectVisualizer(it) },
            onRandomVisualizer = onRandomVisualizer,
            onDismiss = { showVisualizerPicker = false }
        )
    }

    if (showAudioSpecsDialog) {
        PowerampAudioSpecsDialog(
            song = song,
            currentEqualizer = currentEqualizer,
            onDismiss = { showAudioSpecsDialog = false }
        )
    }
}
