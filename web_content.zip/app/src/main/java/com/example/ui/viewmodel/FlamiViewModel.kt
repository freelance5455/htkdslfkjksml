package com.example.ui.viewmodel

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.AppearanceSettings
import com.example.core.ClassicThemeMode
import com.example.core.DesignSystem
import com.example.core.DocumentExportManager
import com.example.core.ExportFormat
import com.example.core.FlamiL10n
import com.example.core.ThemePreferencesStore
import com.example.core.TtsManager
import com.example.core.VoiceAssistantManager
import com.example.data.ai.FlamiAiService
import com.example.data.model.ChatMessage
import com.example.data.model.ChatSession
import com.example.data.model.ContextualMemory
import com.example.data.model.SearchHit
import com.example.data.model.UserProfile
import com.example.data.repository.FlamiWorkspaceRepository
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class GenerationState(
    val isGenerating: Boolean = false,
    val activeChatId: String? = null,
    val streamingMessageId: String? = null,
    val streamingText: String = "",
    val errorMessage: String? = null
)

data class SearchUiState(
    val query: String = "",
    val isSearching: Boolean = false,
    val results: List<SearchHit> = emptyList(),
    val error: String? = null
)

data class AttachedVideo(
    val bytes: ByteArray,
    val mimeType: String,
    val label: String
)

class FlamiViewModel(
    private val repository: FlamiWorkspaceRepository,
    private val aiService: FlamiAiService,
    private val themeStore: ThemePreferencesStore,
    val ttsManager: TtsManager,
    val voiceAssistantManager: VoiceAssistantManager,
    private val currentUserId: String,
    private val initialDisplayName: String
) : ViewModel() {

    private val _activeChatId = MutableStateFlow<String?>(null)
    val activeChatId: StateFlow<String?> = _activeChatId.asStateFlow()

    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    private val _attachedBitmap = MutableStateFlow<Bitmap?>(null)
    val attachedBitmap: StateFlow<Bitmap?> = _attachedBitmap.asStateFlow()

    private val _attachedVideo = MutableStateFlow<AttachedVideo?>(null)
    val attachedVideo: StateFlow<AttachedVideo?> = _attachedVideo.asStateFlow()

    private val _generationState = MutableStateFlow(GenerationState())
    val generationState: StateFlow<GenerationState> = _generationState.asStateFlow()

    private val _searchState = MutableStateFlow(SearchUiState())
    val searchState: StateFlow<SearchUiState> = _searchState.asStateFlow()

    private val _toastEvent = MutableStateFlow<String?>(null)
    val toastEvent: StateFlow<String?> = _toastEvent.asStateFlow()

    private val _voiceAutoSpeak = MutableStateFlow(true)
    val voiceAutoSpeak: StateFlow<Boolean> = _voiceAutoSpeak.asStateFlow()

    private val _localLanguageOverride = MutableStateFlow<String?>(null)

    private var activeGenerationJob: Job? = null
    private var searchJob: Job? = null

    val appearanceSettings: StateFlow<AppearanceSettings> = themeStore.appearanceFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = themeStore.appearanceFlow.value
        )

    val userProfile: StateFlow<UserProfile> = repository.observeUserProfile()
        .map { it ?: UserProfile(userId = currentUserId, displayName = initialDisplayName) }
        .catch { error ->
            val ffe = unwrapFirestoreError(error)
            if (ffe == null && error is CancellationException) throw error
            Log.w(TAG, "Profile stream error", ffe ?: error)
            emit(UserProfile(userId = currentUserId, displayName = initialDisplayName))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = UserProfile(userId = currentUserId, displayName = initialDisplayName)
        )

    val effectiveLanguageCode: StateFlow<String> = kotlinx.coroutines.flow.combine(
        userProfile,
        _localLanguageOverride
    ) { profile, override ->
        override ?: profile.preferredLanguage
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = "auto"
    )

    val chats: StateFlow<List<ChatSession>> = repository.observeChats()
        .catch { error ->
            val ffe = unwrapFirestoreError(error)
            if (ffe == null && error is CancellationException) throw error
            Log.w(TAG, "Chats stream error", ffe ?: error)
            emit(emptyList())
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = emptyList()
        )

    val memories: StateFlow<List<ContextualMemory>> = repository.observeMemories()
        .catch { error ->
            val ffe = unwrapFirestoreError(error)
            if (ffe == null && error is CancellationException) throw error
            Log.w(TAG, "Memories stream error", ffe ?: error)
            emit(emptyList())
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = emptyList()
        )

    @Suppress("OPT_IN_USAGE")
    val messages: StateFlow<List<ChatMessage>> = _activeChatId
        .flatMapLatest { chatId ->
            if (chatId.isNullOrBlank()) {
                flowOf(emptyList())
            } else {
                repository.observeMessages(chatId)
                    .catch { error ->
                        val ffe = unwrapFirestoreError(error)
                        if (ffe == null && error is CancellationException) throw error
                        Log.w(TAG, "Messages stream error", ffe ?: error)
                        emit(emptyList())
                    }
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = emptyList()
        )

    init {
        viewModelScope.launch {
            repository.ensureUserProfile(initialDisplayName, "auto")
        }
    }

    fun setDesignSystem(designSystem: DesignSystem) {
        viewModelScope.launch {
            themeStore.setDesignSystem(designSystem)
        }
    }

    fun setAnimeBackgroundIndex(index: Int) {
        viewModelScope.launch {
            themeStore.setAnimeBackgroundIndex(index)
        }
    }

    fun setCustomAnimeBackground(uri: Uri) {
        viewModelScope.launch {
            themeStore.saveCustomAnimeBackground(uri).onFailure { err ->
                _toastEvent.value = err.localizedMessage ?: "Failed to set background"
            }
        }
    }

    fun setClassicThemeMode(mode: ClassicThemeMode) {
        viewModelScope.launch {
            themeStore.setClassicThemeMode(mode)
        }
    }

    fun setVoiceAutoSpeak(enabled: Boolean) {
        _voiceAutoSpeak.value = enabled
        if (!enabled) ttsManager.stop()
    }

    fun updateInputText(newText: String) {
        _inputText.value = newText
    }

    fun attachBitmap(bitmap: Bitmap?) {
        _attachedBitmap.value = bitmap
        if (bitmap != null) {
            _attachedVideo.value = null
        }
    }

    fun attachVideo(video: AttachedVideo?) {
        _attachedVideo.value = video
        if (video != null) {
            _attachedBitmap.value = null
        }
    }

    fun clearToast() {
        _toastEvent.value = null
    }

    fun showToast(msg: String) {
        _toastEvent.value = msg
    }

    fun selectChat(chatId: String?) {
        _activeChatId.value = chatId
    }

    fun startNewChat() {
        _activeChatId.value = null
        _generationState.update { it.copy(errorMessage = null) }
    }

    fun sendMessage(
        overridePrompt: String? = null,
        speakResponseAloud: Boolean = false
    ) {
        val rawPrompt = (overridePrompt ?: _inputText.value).trim()
        val bitmapToSend = if (overridePrompt == null) _attachedBitmap.value else null
        val videoToSend = if (overridePrompt == null) _attachedVideo.value else null

        if (rawPrompt.isBlank() && bitmapToSend == null && videoToSend == null) return

        if (overridePrompt == null) {
            _inputText.value = ""
            _attachedBitmap.value = null
            _attachedVideo.value = null
        }

        val previousJob = activeGenerationJob
        if (previousJob != null && previousJob.isActive) {
            previousJob.cancel()
        }

        activeGenerationJob = viewModelScope.launch {
            var targetChatId = _activeChatId.value
            val profile = userProfile.value
            val langCode = effectiveLanguageCode.value

            try {
                val isFirstTurnInChat = targetChatId == null
                if (targetChatId == null) {
                    val tempTitle = rawPrompt.replace('\n', ' ').take(48)
                        .ifBlank { if (videoToSend != null) "Video Analysis" else "Image Analysis" }
                    val createResult = repository.createChat(tempTitle)
                    targetChatId = createResult.getOrElse { err ->
                        _generationState.value = GenerationState(
                            isGenerating = false,
                            errorMessage = err.localizedMessage ?: "Failed to create chat"
                        )
                        return@launch
                    }
                    _activeChatId.value = targetChatId
                }

                val currentChatId = targetChatId
                val existingMessages = repository.getMessagesOnce(currentChatId).getOrElse { emptyList() }

                val attachmentNote = when {
                    bitmapToSend != null -> "Photo (${bitmapToSend.width}x${bitmapToSend.height})"
                    videoToSend != null -> "Video (${videoToSend.label})"
                    else -> null
                }

                val userMsgResult = repository.addMessage(
                    chatId = currentChatId,
                    role = "user",
                    text = rawPrompt.ifBlank { if (videoToSend != null) "[Video]" else "[Image]" },
                    hasImage = bitmapToSend != null || videoToSend != null,
                    imageNote = attachmentNote,
                    languageCode = FlamiL10n.resolveEffectiveCode(langCode),
                    isError = false
                )
                if (userMsgResult.isFailure) {
                    _generationState.value = GenerationState(
                        isGenerating = false,
                        activeChatId = currentChatId,
                        errorMessage = userMsgResult.exceptionOrNull()?.localizedMessage ?: "Failed to save message"
                    )
                    return@launch
                }

                val placeholderRes = repository.addMessage(
                    chatId = currentChatId,
                    role = "model",
                    text = "",
                    hasImage = false,
                    languageCode = FlamiL10n.resolveEffectiveCode(langCode),
                    isError = false,
                    updateChatPreview = false
                )
                val assistantMsgId = placeholderRes.getOrNull()

                _generationState.value = GenerationState(
                    isGenerating = true,
                    activeChatId = currentChatId,
                    streamingMessageId = assistantMsgId,
                    streamingText = "",
                    errorMessage = null
                )

                if (profile.memoryEnabled && rawPrompt.isNotBlank()) {
                    launch {
                        val candidate = aiService.extractMemoryIfUseful(rawPrompt, memories.value)
                        if (candidate != null && candidate.shouldSave) {
                            repository.addMemory(
                                fact = candidate.fact,
                                category = candidate.category,
                                sourceChatId = currentChatId
                            )
                        }
                    }
                }
                if (isFirstTurnInChat && rawPrompt.isNotBlank()) {
                    launch {
                        val smartTitle = aiService.generateChatTitle(
                            rawPrompt,
                            FlamiL10n.resolveEffectiveCode(langCode)
                        )
                        repository.renameChat(currentChatId, smartTitle)
                    }
                }

                var latestText = ""
                var lastPersistTime = 0L
                aiService.streamReply(
                    history = existingMessages,
                    userPrompt = rawPrompt,
                    attachedBitmap = bitmapToSend,
                    attachedVideoBytes = videoToSend?.bytes,
                    attachedVideoMimeType = videoToSend?.mimeType,
                    memories = if (profile.memoryEnabled) memories.value else emptyList(),
                    preferredLanguage = langCode,
                    modelMode = profile.modelMode
                ).collect { accumulated ->
                    latestText = accumulated
                    _generationState.update {
                        it.copy(
                            isGenerating = true,
                            activeChatId = currentChatId,
                            streamingMessageId = assistantMsgId,
                            streamingText = accumulated
                        )
                    }
                    val now = System.currentTimeMillis()
                    if (assistantMsgId != null && now - lastPersistTime >= 650L) {
                        lastPersistTime = now
                        repository.updateMessage(
                            chatId = currentChatId,
                            messageId = assistantMsgId,
                            newText = accumulated,
                            isError = false,
                            updateChatPreview = false
                        )
                    }
                }

                if (assistantMsgId != null && latestText.isNotBlank()) {
                    repository.updateMessage(
                        chatId = currentChatId,
                        messageId = assistantMsgId,
                        newText = latestText,
                        isError = false,
                        updateChatPreview = true
                    )
                    if (speakResponseAloud && profile.ttsEnabled) {
                        ttsManager.speak(
                            messageId = assistantMsgId,
                            rawText = latestText,
                            languageCode = langCode,
                            speechRate = profile.ttsRate.toFloat()
                        )
                    }
                }

                _generationState.value = GenerationState(isGenerating = false)
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "AI generation timed out", e)
                persistErrorOnActiveMessage(
                    chatId = targetChatId,
                    messageId = _generationState.value.streamingMessageId,
                    partialText = _generationState.value.streamingText,
                    errorMsg = "Request timed out after 60s. Please retry."
                )
            } catch (e: CancellationException) {
                val partial = _generationState.value.streamingText
                val msgId = _generationState.value.streamingMessageId
                if (!targetChatId.isNullOrBlank() && !msgId.isNullOrBlank() && partial.isNotBlank()) {
                    viewModelScope.launch {
                        repository.updateMessage(
                            chatId = targetChatId,
                            messageId = msgId,
                            newText = partial,
                            isError = false,
                            updateChatPreview = true
                        )
                    }
                }
                _generationState.update {
                    it.copy(isGenerating = false, streamingMessageId = null, streamingText = "")
                }
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "AI generation failed", e)
                persistErrorOnActiveMessage(
                    chatId = targetChatId,
                    messageId = _generationState.value.streamingMessageId,
                    partialText = _generationState.value.streamingText,
                    errorMsg = e.localizedMessage ?: "AI request failed."
                )
            }
        }
    }

    private suspend fun persistErrorOnActiveMessage(
        chatId: String?,
        messageId: String?,
        partialText: String,
        errorMsg: String
    ) {
        if (!chatId.isNullOrBlank() && !messageId.isNullOrBlank()) {
            val content = if (partialText.isNotBlank()) {
                "$partialText\n\n[Error: $errorMsg]"
            } else {
                errorMsg
            }
            repository.updateMessage(
                chatId = chatId,
                messageId = messageId,
                newText = content,
                isError = true,
                updateChatPreview = true
            )
        }
        _generationState.value = GenerationState(
            isGenerating = false,
            activeChatId = chatId,
            errorMessage = errorMsg
        )
    }

    fun cancelGeneration() {
        activeGenerationJob?.cancel()
        activeGenerationJob = null
        _generationState.update {
            it.copy(isGenerating = false, streamingMessageId = null)
        }
    }

    fun retryLastUserMessage() {
        val lastUserMsg = messages.value.lastOrNull { it.role == "user" } ?: return
        sendMessage(overridePrompt = lastUserMsg.text)
    }

    fun renameChat(chatId: String, newTitle: String) {
        viewModelScope.launch {
            repository.renameChat(chatId, newTitle)
        }
    }

    fun togglePinChat(chat: ChatSession) {
        viewModelScope.launch {
            repository.togglePinChat(chat.id, !chat.isPinned)
        }
    }

    fun deleteChat(chatId: String) {
        viewModelScope.launch {
            if (_activeChatId.value == chatId) {
                _activeChatId.value = null
            }
            repository.deleteChat(chatId)
        }
    }

    fun searchHistory(query: String) {
        _searchState.update { it.copy(query = query) }
        searchJob?.cancel()
        if (query.isBlank()) {
            _searchState.value = SearchUiState(query = "")
            return
        }
        searchJob = viewModelScope.launch {
            _searchState.update { it.copy(isSearching = true, error = null) }
            val result = repository.searchMessages(query, chats.value)
            result.onSuccess { hits ->
                _searchState.update { it.copy(isSearching = false, results = hits) }
            }.onFailure { err ->
                _searchState.update { it.copy(isSearching = false, error = err.localizedMessage) }
            }
        }
    }

    fun addMemory(fact: String, category: String) {
        viewModelScope.launch {
            repository.addMemory(fact, category, _activeChatId.value)
        }
    }

    fun toggleMemoryActive(memory: ContextualMemory) {
        viewModelScope.launch {
            repository.updateMemory(memory.copy(isActive = !memory.isActive))
        }
    }

    fun deleteMemory(memoryId: String) {
        viewModelScope.launch {
            repository.deleteMemory(memoryId)
        }
    }

    fun updateLanguage(langCode: String) {
        _localLanguageOverride.value = langCode
        viewModelScope.launch {
            repository.updateUserPreferences(preferredLanguage = langCode)
        }
    }

    fun updateModelMode(mode: String) {
        viewModelScope.launch {
            repository.updateUserPreferences(modelMode = mode)
        }
    }

    fun updateTtsEnabled(enabled: Boolean) {
        if (!enabled) ttsManager.stop()
        viewModelScope.launch {
            repository.updateUserPreferences(ttsEnabled = enabled)
        }
    }

    fun updateTtsRate(rate: Float) {
        viewModelScope.launch {
            repository.updateUserPreferences(ttsRate = rate.toDouble())
        }
    }

    fun updateMemoryEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.updateUserPreferences(memoryEnabled = enabled)
        }
    }

    fun exportCurrentChat(
        context: Context,
        uri: Uri,
        format: ExportFormat,
        singleMessage: ChatMessage? = null,
        successMessage: String
    ) {
        viewModelScope.launch {
            val activeChat = chats.value.firstOrNull { it.id == _activeChatId.value }
            val title = activeChat?.title ?: "FLAMI AI Export"
            val targetMessages = if (singleMessage != null) {
                listOf(singleMessage)
            } else {
                messages.value
            }
            val result = DocumentExportManager.writeExportToUri(
                context = context,
                uri = uri,
                format = format,
                title = title,
                messages = targetMessages
            )
            result.onSuccess {
                _toastEvent.value = successMessage
            }.onFailure { err ->
                _toastEvent.value = err.localizedMessage ?: "Export failed"
            }
        }
    }

    private fun unwrapFirestoreError(error: Throwable): FirebaseFirestoreException? {
        return generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
    }

    override fun onCleared() {
        super.onCleared()
        activeGenerationJob?.cancel()
        ttsManager.shutdown()
        voiceAssistantManager.destroy()
    }

    companion object {
        private const val TAG = "FlamiViewModel"
    }
}
