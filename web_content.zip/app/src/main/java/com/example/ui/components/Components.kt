package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Airport
import com.example.ui.navigation.Screen
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.cos
import kotlin.math.sin

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AtcTopBar(
  currentScreen: Screen,
  selectedAirport: Airport?,
  onOpenDrawer: () -> Unit,
  onOpenSearch: () -> Unit,
  onRefresh: () -> Unit,
  modifier: Modifier = Modifier
) {
  var utcClock by remember { mutableStateOf("") }

  LaunchedEffect(Unit) {
    while (true) {
      val sdf = SimpleDateFormat("HH:mm:ss 'UTC'", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
      }
      utcClock = sdf.format(Date())
      kotlinx.coroutines.delay(1000)
    }
  }

  TopAppBar(
    modifier = modifier.testTag("atc_top_bar"),
    colors = TopAppBarDefaults.topAppBarColors(
      containerColor = MaterialTheme.colorScheme.surface,
      titleContentColor = MaterialTheme.colorScheme.onSurface
    ),
    navigationIcon = {
      IconButton(
        onClick = onOpenDrawer,
        modifier = Modifier.testTag("btn_drawer_menu")
      ) {
        Icon(
          imageVector = Icons.Default.Menu,
          contentDescription = "منوی ناوبری",
          tint = MaterialTheme.colorScheme.primary
        )
      }
    },
    title = {
      Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = "ATC Aviation Weather",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
          )
          Spacer(modifier = Modifier.width(8.dp))
          if (selectedAirport != null) {
            Surface(
              shape = RoundedCornerShape(4.dp),
              color = MaterialTheme.colorScheme.primaryContainer,
              modifier = Modifier.clickable { onOpenSearch() }
            ) {
              Text(
                text = "${selectedAirport.icao} (${selectedAirport.iata.ifBlank { "ICAO" }})",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
          }
        }
        Text(
          text = "$utcClock • ${currentScreen.titleFa}",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    },
    actions = {
      IconButton(
        onClick = onOpenSearch,
        modifier = Modifier.testTag("btn_search_airports")
      ) {
        Icon(
          imageVector = Icons.Default.Search,
          contentDescription = "جستجوی فرودگاه",
          tint = MaterialTheme.colorScheme.onSurface
        )
      }
      IconButton(
        onClick = onRefresh,
        modifier = Modifier.testTag("btn_refresh_weather")
      ) {
        Icon(
          imageVector = Icons.Default.Refresh,
          contentDescription = "به‌روزرسانی داده‌ها",
          tint = MaterialTheme.colorScheme.primary
        )
      }
    }
  )
}

@Composable
fun FlightCategoryBadge(
  category: String,
  modifier: Modifier = Modifier
) {
  val (bgColor, textColor) = when (category.uppercase()) {
    "VFR" -> Pair(CategoryVfr, Color.White)
    "MVFR" -> Pair(CategoryMvfr, Color.White)
    "IFR" -> Pair(CategoryIfr, Color.Black)
    "LIFR" -> Pair(CategoryLifr, Color.White)
    else -> Pair(StatusGray, Color.White)
  }

  Surface(
    shape = RoundedCornerShape(6.dp),
    color = bgColor,
    modifier = modifier.testTag("flight_category_badge")
  ) {
    Text(
      text = category.uppercase(),
      style = MaterialTheme.typography.labelLarge,
      fontWeight = FontWeight.Bold,
      color = textColor,
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
    )
  }
}

@Composable
fun RawMessageCard(
  titleFa: String,
  rawText: String,
  source: String,
  issueTimeUtc: String = "",
  receiptTimeUtc: String = "",
  isSpeci: Boolean = false,
  isParsingFailed: Boolean = false,
  modifier: Modifier = Modifier
) {
  val clipboard = LocalClipboardManager.current
  val context = LocalContext.current

  Card(
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    border = CardDefaults.outlinedCardBorder(),
    modifier = modifier.fillMaxWidth().testTag("raw_message_card")
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.Terminal,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = titleFa,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold
          )
          if (isSpeci) {
            Spacer(modifier = Modifier.width(8.dp))
            Surface(
              shape = RoundedCornerShape(4.dp),
              color = StatusRed
            ) {
              Text(
                text = "SPECI (گزارش ویژه)",
                color = Color.White,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
          }
        }

        IconButton(
          onClick = {
            clipboard.setText(AnnotatedString(rawText))
            Toast.makeText(context, "پیام خام کپی شد", Toast.LENGTH_SHORT).show()
          },
          modifier = Modifier.size(32.dp).testTag("btn_copy_raw_message")
        ) {
          Icon(
            imageVector = Icons.Default.ContentCopy,
            contentDescription = "کپی پیام",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(18.dp)
          )
        }
      }

      if (isParsingFailed) {
        Surface(
          shape = RoundedCornerShape(6.dp),
          color = StatusYellow.copy(alpha = 0.2f),
          modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
        ) {
          Row(
            modifier = Modifier.padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Default.Warning, contentDescription = null, tint = StatusYellow)
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "PARSING FAILED — RAW MESSAGE AVAILABLE (تحلیل خودکار ناموفق بود؛ پیام اصلی دست‌نخورده نمایش داده شده است)",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurface
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Monospace Raw Aviation Message Display
      Surface(
        shape = RoundedCornerShape(8.dp),
        color = MaterialTheme.colorScheme.surface,
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier.fillMaxWidth()
      ) {
        Text(
          text = rawText.ifBlank { "NO RAW MESSAGE AVAILABLE" },
          style = MaterialTheme.typography.bodyMedium.copy(
            fontFamily = FontFamily.Monospace,
            letterSpacing = 0.5.sp,
            lineHeight = 22.sp
          ),
          color = MaterialTheme.colorScheme.onSurface,
          modifier = Modifier.padding(12.dp)
        )
      }

      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text(
          text = "منبع داده: $source",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (issueTimeUtc.isNotBlank()) {
          Text(
            text = "زمان گزارش: $issueTimeUtc",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.primary
          )
        }
      }
    }
  }
}

@Composable
fun RunwayThirdsVisualizer(
  runwayDesignator: String,
  rwycc1: Int?,
  rwycc2: Int?,
  rwycc3: Int?,
  lowestRwycc: Int?,
  contaminantType: String,
  depthMm1: Int? = null,
  depthMm2: Int? = null,
  depthMm3: Int? = null,
  coveragePercent1: Int? = null,
  coveragePercent2: Int? = null,
  coveragePercent3: Int? = null,
  modifier: Modifier = Modifier
) {
  fun rwyccColor(code: Int?): Color = when (code) {
    6 -> Rwycc6Color
    5 -> Rwycc5Color
    4 -> Rwycc4Color
    3 -> Rwycc3Color
    2 -> Rwycc2Color
    1 -> Rwycc1Color
    0 -> Rwycc0Color
    else -> StatusGray
  }

  fun rwyccDescription(code: Int?): String = when (code) {
    6 -> "خشک (Good)"
    5 -> "مرطوب / برف خشک تا 3mm (Good)"
    4 -> "پوشش فشرده -15C (Medium to Good)"
    3 -> "برف تر / فشرده -15C (Medium)"
    2 -> "برف آبکی Slush / آب راکد (Medium to Poor)"
    1 -> "یخ (Poor)"
    0 -> "یخ مرطوب / آب روی یخ (Less than Poor)"
    else -> "نامشخص (NR)"
  }

  Card(
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    border = CardDefaults.outlinedCardBorder(),
    modifier = modifier.fillMaxWidth().testTag("runway_thirds_visualizer")
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "وضعیت بخش‌های سه‌گانه باند $runwayDesignator",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "استاندارد ICAO GRF (Global Reporting Format)",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        if (lowestRwycc != null) {
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = rwyccColor(lowestRwycc),
            modifier = Modifier.padding(4.dp)
          ) {
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Text(
                text = "کمترین RWYCC",
                style = MaterialTheme.typography.labelSmall,
                color = Color.White
              )
              Text(
                text = "$lowestRwycc",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Runway Graphic with 3 Thirds
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .height(84.dp)
          .clip(RoundedCornerShape(8.dp))
          .border(2.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
          .background(Color(0xFF1E293B)),
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Third 1
        RunwayThirdBox(
          label = "THIRD 1 (ابتدای باند)",
          rwycc = rwycc1,
          color = rwyccColor(rwycc1),
          depth = depthMm1,
          coverage = coveragePercent1,
          modifier = Modifier.weight(1f)
        )
        Box(modifier = Modifier.width(2.dp).fillMaxHeight().background(Color.White.copy(alpha = 0.4f)))
        // Third 2
        RunwayThirdBox(
          label = "THIRD 2 (میانه باند)",
          rwycc = rwycc2,
          color = rwyccColor(rwycc2),
          depth = depthMm2,
          coverage = coveragePercent2,
          modifier = Modifier.weight(1f)
        )
        Box(modifier = Modifier.width(2.dp).fillMaxHeight().background(Color.White.copy(alpha = 0.4f)))
        // Third 3
        RunwayThirdBox(
          label = "THIRD 3 (انتهای باند)",
          rwycc = rwycc3,
          color = rwyccColor(rwycc3),
          depth = depthMm3,
          coverage = coveragePercent3,
          modifier = Modifier.weight(1f)
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text(
          text = "نوع آلاینده (Contaminant): ${contaminantType.ifBlank { "Dry / Not Reported" }}",
          style = MaterialTheme.typography.bodySmall,
          fontWeight = FontWeight.Medium,
          color = MaterialTheme.colorScheme.onSurface
        )
        if (lowestRwycc != null) {
          Text(
            text = rwyccDescription(lowestRwycc),
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = rwyccColor(lowestRwycc)
          )
        }
      }
    }
  }
}

@Composable
private fun RunwayThirdBox(
  label: String,
  rwycc: Int?,
  color: Color,
  depth: Int?,
  coverage: Int?,
  modifier: Modifier = Modifier
) {
  Box(
    modifier = modifier
      .fillMaxHeight()
      .background(color.copy(alpha = 0.25f))
      .padding(6.dp),
    contentAlignment = Alignment.Center
  ) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall,
        fontSize = 9.sp,
        color = Color.White.copy(alpha = 0.9f)
      )
      Text(
        text = if (rwycc != null) "RWYCC $rwycc" else "NR",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = color
      )
      if (coverage != null || depth != null) {
        Text(
          text = "${coverage?.let { "$it%" } ?: ""}${if (depth != null) " • ${depth}mm" else ""}",
          style = MaterialTheme.typography.labelSmall,
          fontSize = 9.sp,
          color = Color.White.copy(alpha = 0.8f)
        )
      }
    }
  }
}

@Composable
fun WindVectorVisualizer(
  windDirDeg: Int,
  windSpeedKt: Int,
  modifier: Modifier = Modifier
) {
  Box(
    modifier = modifier
      .size(72.dp)
      .clip(CircleShape)
      .background(MaterialTheme.colorScheme.surface)
      .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape),
    contentAlignment = Alignment.Center
  ) {
    Canvas(modifier = Modifier.fillMaxSize().padding(8.dp)) {
      val center = Offset(size.width / 2, size.height / 2)
      val radius = size.width / 2 - 4.dp.toPx()

      // Direction line: aviation wind is direction it blows FROM, so vector points to (dir + 180)
      val rad = Math.toRadians((windDirDeg - 90).toDouble())
      val arrowX = center.x + radius * cos(rad).toFloat()
      val arrowY = center.y + radius * sin(rad).toFloat()

      // Outer compass marks
      drawLine(
        color = Color.Gray.copy(alpha = 0.4f),
        start = Offset(center.x, center.y - radius),
        end = Offset(center.x, center.y + radius),
        strokeWidth = 1.dp.toPx()
      )
      drawLine(
        color = Color.Gray.copy(alpha = 0.4f),
        start = Offset(center.x - radius, center.y),
        end = Offset(center.x + radius, center.y),
        strokeWidth = 1.dp.toPx()
      )

      // Wind pointer arrow
      drawLine(
        color = AtcAeroBlueLight,
        start = center,
        end = Offset(arrowX, arrowY),
        strokeWidth = 3.dp.toPx()
      )

      drawCircle(
        color = Color(0xFFEF4444),
        radius = 3.dp.toPx(),
        center = Offset(arrowX, arrowY)
      )
    }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Text(
        text = "${windDirDeg}°",
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        fontSize = 10.sp
      )
      Text(
        text = "$windSpeedKt kt",
        style = MaterialTheme.typography.labelSmall,
        fontSize = 9.sp,
        color = MaterialTheme.colorScheme.primary
      )
    }
  }
}

@Composable
fun OfflineNoticeBanner(
  modifier: Modifier = Modifier
) {
  Surface(
    shape = RoundedCornerShape(8.dp),
    color = StatusYellow.copy(alpha = 0.2f),
    border = CardDefaults.outlinedCardBorder(),
    modifier = modifier.fillMaxWidth().testTag("offline_notice_banner")
  ) {
    Row(
      modifier = Modifier.padding(10.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(Icons.Default.CloudOff, contentDescription = null, tint = StatusYellow)
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = "OFFLINE — SHOWING CACHED DATA (عدم اتصال به اینترنت — نمایش داده‌های ذخیره شده محلی)",
        style = MaterialTheme.typography.bodySmall,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
      )
    }
  }
}

@Composable
fun OperationalDisclaimerCard(
  modifier: Modifier = Modifier
) {
  Surface(
    shape = RoundedCornerShape(8.dp),
    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
    border = CardDefaults.outlinedCardBorder(),
    modifier = modifier.fillMaxWidth().testTag("operational_disclaimer")
  ) {
    Row(
      modifier = Modifier.padding(10.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
        Icons.Default.Shield,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.secondary,
        modifier = Modifier.size(18.dp)
      )
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = "تصمیمات عملیاتی مراقبت پرواز باید بر اساس منابع رسمی معتبر هوانوردی و دستورالعمل‌های محلی مصوب اتخاذ گردد.\nOperational decisions must be based on current authorized aviation information sources and applicable local procedures.",
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 16.sp
      )
    }
  }
}
