package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Airport
import com.example.ui.navigation.Screen
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.cos
import kotlin.math.sin

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AtcTopBar(
  currentScreen: Screen,
  selectedAirport: Airport?,
  onOpenDrawer: () -> Unit,
  onOpenSearch: () -> Unit,
  onRefresh: () -> Unit,
  modifier: Modifier = Modifier
) {
  var utcClock by remember { mutableStateOf("") }

  LaunchedEffect(Unit) {
    while (true) {
      val sdf = SimpleDateFormat("HH:mm:ss 'UTC'", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
      }
      utcClock = sdf.format(Date())
      kotlinx.coroutines.delay(1000)
    }
  }

  TopAppBar(
    modifier = modifier.testTag("atc_top_bar"),
    colors = TopAppBarDefaults.topAppBarColors(
      containerColor = OceanBlue,
      titleContentColor = Color.White,
      navigationIconContentColor = Color.White,
      actionIconContentColor = Color.White
    ),
    navigationIcon = {
      IconButton(
        onClick = onOpenDrawer,
        modifier = Modifier.testTag("btn_drawer_menu")
      ) {
        Icon(
          imageVector = Icons.Default.Menu,
          contentDescription = "Navigation Menu",
          tint = Color.White
        )
      }
    },
    title = {
      Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = "ATC Aviation Weather",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = Color.White
          )
          Spacer(modifier = Modifier.width(8.dp))
          if (selectedAirport != null) {
            Surface(
              shape = RoundedCornerShape(4.dp),
              color = Color.White.copy(alpha = 0.22f),
              modifier = Modifier.clickable { onOpenSearch() }
            ) {
              Text(
                text = "${selectedAirport.icao} (${selectedAirport.iata.ifBlank { "ICAO" }})",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
          }
        }
        Text(
          text = "$utcClock • ${currentScreen.titleEn}",
          style = MaterialTheme.typography.labelSmall,
          color = Color(0xFFE0F2FE)
        )
      }
    },
    actions = {
      IconButton(
        onClick = onOpenSearch,
        modifier = Modifier.testTag("btn_search_airports")
      ) {
        Icon(
          imageVector = Icons.Default.Search,
          contentDescription = "Search Airports",
          tint = Color.White
        )
      }
      IconButton(
        onClick = onRefresh,
        modifier = Modifier.testTag("btn_refresh_weather")
      ) {
        Icon(
          imageVector = Icons.Default.Refresh,
          contentDescription = "Refresh Data",
          tint = Color.White
        )
      }
    }
  )
}

@Composable
fun FlightCategoryBadge(
  category: String,
  modifier: Modifier = Modifier
) {
  val (bgColor, textColor) = when (category.uppercase()) {
    "VFR" -> Pair(CategoryVfr, Color.White)
    "MVFR" -> Pair(CategoryMvfr, Color.White)
    "IFR" -> Pair(CategoryIfr, Color.Black)
    "LIFR" -> Pair(CategoryLifr, Color.White)
    else -> Pair(StatusGray, Color.White)
  }

  Surface(
    shape = RoundedCornerShape(6.dp),
    color = bgColor,
    modifier = modifier.testTag("flight_category_badge")
  ) {
    Text(
      text = category.uppercase(),
      style = MaterialTheme.typography.labelLarge,
      fontWeight = FontWeight.Bold,
      color = textColor,
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
    )
  }
}

@Composable
fun RawMessageCard(
  title: String,
  rawText: String,
  source: String,
  issueTimeUtc: String = "",
  receiptTimeUtc: String = "",
  isSpeci: Boolean = false,
  isParsingFailed: Boolean = false,
  containerColor: Color = RawTerminalBg,
  borderColor: Color = RawTerminalBorder,
  textColor: Color = RawTerminalText,
  modifier: Modifier = Modifier
) {
  val clipboard = LocalClipboardManager.current
  val context = LocalContext.current

  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = containerColor),
    border = androidx.compose.foundation.BorderStroke(1.5.dp, borderColor),
    modifier = modifier.fillMaxWidth().testTag("raw_message_card")
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.Terminal,
            contentDescription = null,
            tint = OceanBlue,
            modifier = Modifier.size(20.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = title,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = textColor
          )
          if (isSpeci) {
            Spacer(modifier = Modifier.width(8.dp))
            Surface(
              shape = RoundedCornerShape(4.dp),
              color = StatusRed
            ) {
              Text(
                text = "SPECI",
                color = Color.White,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
          }
        }

        IconButton(
          onClick = {
            clipboard.setText(AnnotatedString(rawText))
            Toast.makeText(context, "Raw message copied", Toast.LENGTH_SHORT).show()
          },
          modifier = Modifier.size(32.dp).testTag("btn_copy_raw_message")
        ) {
          Icon(
            imageVector = Icons.Default.ContentCopy,
            contentDescription = "Copy raw text",
            tint = textColor.copy(alpha = 0.7f),
            modifier = Modifier.size(18.dp)
          )
        }
      }

      if (isParsingFailed) {
        Surface(
          shape = RoundedCornerShape(6.dp),
          color = StatusYellow.copy(alpha = 0.2f),
          modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
        ) {
          Row(
            modifier = Modifier.padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(Icons.Default.Warning, contentDescription = null, tint = StatusYellow)
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "RAW MESSAGE UNTOUCHED (ICAO FORMAT)",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurface
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Monospace Raw Aviation Message Display (Blends seamlessly with colored card background)
      Surface(
        shape = RoundedCornerShape(8.dp),
        color = Color.White.copy(alpha = 0.25f),
        border = androidx.compose.foundation.BorderStroke(1.dp, borderColor.copy(alpha = 0.7f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Text(
          text = rawText.ifBlank { "NO RAW MESSAGE AVAILABLE" },
          style = MaterialTheme.typography.bodyMedium.copy(
            fontFamily = FontFamily.Monospace,
            letterSpacing = 0.5.sp,
            lineHeight = 22.sp
          ),
          color = textColor,
          modifier = Modifier.padding(12.dp)
        )
      }

      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text(
          text = "Source: $source",
          style = MaterialTheme.typography.labelSmall,
          color = textColor.copy(alpha = 0.75f)
        )
        if (issueTimeUtc.isNotBlank()) {
          Text(
            text = "Time: $issueTimeUtc",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Medium,
            color = OceanBlue
          )
        }
      }
    }
  }
}

@Composable
fun RunwayThirdsVisualizer(
  runwayDesignator: String,
  rwycc1: Int?,
  rwycc2: Int?,
  rwycc3: Int?,
  lowestRwycc: Int?,
  contaminantType: String,
  depthMm1: Int? = null,
  depthMm2: Int? = null,
  depthMm3: Int? = null,
  coveragePercent1: Int? = null,
  coveragePercent2: Int? = null,
  coveragePercent3: Int? = null,
  modifier: Modifier = Modifier
) {
  fun rwyccColor(code: Int?): Color = when (code) {
    6 -> Rwycc6Color
    5 -> Rwycc5Color
    4 -> Rwycc4Color
    3 -> Rwycc3Color
    2 -> Rwycc2Color
    1 -> Rwycc1Color
    0 -> Rwycc0Color
    else -> StatusGray
  }

  fun rwyccDescription(code: Int?): String = when (code) {
    6 -> "خشک (Good)"
    5 -> "مرطوب / برف خشک تا 3mm (Good)"
    4 -> "پوشش فشرده -15C (Medium to Good)"
    3 -> "برف تر / فشرده -15C (Medium)"
    2 -> "برف آبکی Slush / آب راکد (Medium to Poor)"
    1 -> "یخ (Poor)"
    0 -> "یخ مرطوب / آب روی یخ (Less than Poor)"
    else -> "نامشخص (NR)"
  }

  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = SnowtamCardBg),
    border = androidx.compose.foundation.BorderStroke(1.5.dp, SnowtamCardBorder),
    modifier = modifier.fillMaxWidth().testTag("runway_thirds_visualizer")
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "وضعیت بخش‌های سه‌گانه باند $runwayDesignator",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "استاندارد ICAO GRF (Global Reporting Format)",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        if (lowestRwycc != null) {
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = rwyccColor(lowestRwycc),
            modifier = Modifier.padding(4.dp)
          ) {
            Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Text(
                text = "کمترین RWYCC",
                style = MaterialTheme.typography.labelSmall,
                color = Color.White
              )
              Text(
                text = "$lowestRwycc",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Runway Graphic with 3 Thirds
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .height(84.dp)
          .clip(RoundedCornerShape(8.dp))
          .border(2.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
          .background(Color(0xFF1E293B)),
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Third 1
        RunwayThirdBox(
          label = "THIRD 1 (ابتدای باند)",
          rwycc = rwycc1,
          color = rwyccColor(rwycc1),
          depth = depthMm1,
          coverage = coveragePercent1,
          modifier = Modifier.weight(1f)
        )
        Box(modifier = Modifier.width(2.dp).fillMaxHeight().background(Color.White.copy(alpha = 0.4f)))
        // Third 2
        RunwayThirdBox(
          label = "THIRD 2 (میانه باند)",
          rwycc = rwycc2,
          color = rwyccColor(rwycc2),
          depth = depthMm2,
          coverage = coveragePercent2,
          modifier = Modifier.weight(1f)
        )
        Box(modifier = Modifier.width(2.dp).fillMaxHeight().background(Color.White.copy(alpha = 0.4f)))
        // Third 3
        RunwayThirdBox(
          label = "THIRD 3 (انتهای باند)",
          rwycc = rwycc3,
          color = rwyccColor(rwycc3),
          depth = depthMm3,
          coverage = coveragePercent3,
          modifier = Modifier.weight(1f)
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text(
          text = "نوع آلاینده (Contaminant): ${contaminantType.ifBlank { "Dry / Not Reported" }}",
          style = MaterialTheme.typography.bodySmall,
          fontWeight = FontWeight.Medium,
          color = MaterialTheme.colorScheme.onSurface
        )
        if (lowestRwycc != null) {
          Text(
            text = rwyccDescription(lowestRwycc),
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = rwyccColor(lowestRwycc)
          )
        }
      }
    }
  }
}

@Composable
private fun RunwayThirdBox(
  label: String,
  rwycc: Int?,
  color: Color,
  depth: Int?,
  coverage: Int?,
  modifier: Modifier = Modifier
) {
  Box(
    modifier = modifier
      .fillMaxHeight()
      .background(color.copy(alpha = 0.25f))
      .padding(6.dp),
    contentAlignment = Alignment.Center
  ) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall,
        fontSize = 9.sp,
        color = Color.White.copy(alpha = 0.9f)
      )
      Text(
        text = if (rwycc != null) "RWYCC $rwycc" else "NR",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        color = color
      )
      if (coverage != null || depth != null) {
        Text(
          text = "${coverage?.let { "$it%" } ?: ""}${if (depth != null) " • ${depth}mm" else ""}",
          style = MaterialTheme.typography.labelSmall,
          fontSize = 9.sp,
          color = Color.White.copy(alpha = 0.8f)
        )
      }
    }
  }
}

@Composable
fun WindVectorVisualizer(
  windDirDeg: Int,
  windSpeedKt: Int,
  modifier: Modifier = Modifier
) {
  Box(
    modifier = modifier
      .size(72.dp)
      .clip(CircleShape)
      .background(MaterialTheme.colorScheme.surface)
      .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape),
    contentAlignment = Alignment.Center
  ) {
    Canvas(modifier = Modifier.fillMaxSize().padding(8.dp)) {
      val center = Offset(size.width / 2, size.height / 2)
      val radius = size.width / 2 - 4.dp.toPx()

      // Direction line: aviation wind is direction it blows FROM, so vector points to (dir + 180)
      val rad = Math.toRadians((windDirDeg - 90).toDouble())
      val arrowX = center.x + radius * cos(rad).toFloat()
      val arrowY = center.y + radius * sin(rad).toFloat()

      // Outer compass marks
      drawLine(
        color = Color.Gray.copy(alpha = 0.4f),
        start = Offset(center.x, center.y - radius),
        end = Offset(center.x, center.y + radius),
        strokeWidth = 1.dp.toPx()
      )
      drawLine(
        color = Color.Gray.copy(alpha = 0.4f),
        start = Offset(center.x - radius, center.y),
        end = Offset(center.x + radius, center.y),
        strokeWidth = 1.dp.toPx()
      )

      // Wind pointer arrow
      drawLine(
        color = AtcAeroBlueLight,
        start = center,
        end = Offset(arrowX, arrowY),
        strokeWidth = 3.dp.toPx()
      )

      drawCircle(
        color = Color(0xFFEF4444),
        radius = 3.dp.toPx(),
        center = Offset(arrowX, arrowY)
      )
    }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Text(
        text = "${windDirDeg}°",
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        fontSize = 10.sp
      )
      Text(
        text = "$windSpeedKt kt",
        style = MaterialTheme.typography.labelSmall,
        fontSize = 9.sp,
        color = MaterialTheme.colorScheme.primary
      )
    }
  }
}

@Composable
fun OfflineNoticeBanner(
  modifier: Modifier = Modifier
) {
  Surface(
    shape = RoundedCornerShape(8.dp),
    color = StatusYellow.copy(alpha = 0.2f),
    border = CardDefaults.outlinedCardBorder(),
    modifier = modifier.fillMaxWidth().testTag("offline_notice_banner")
  ) {
    Row(
      modifier = Modifier.padding(10.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(Icons.Default.CloudOff, contentDescription = null, tint = StatusYellow)
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = "OFFLINE — SHOWING CACHED DATA (عدم اتصال به اینترنت — نمایش داده‌های ذخیره شده محلی)",
        style = MaterialTheme.typography.bodySmall,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurface
      )
    }
  }
}

@Composable
fun OperationalDisclaimerCard(
  modifier: Modifier = Modifier
) {
  Surface(
    shape = RoundedCornerShape(8.dp),
    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
    border = CardDefaults.outlinedCardBorder(),
    modifier = modifier.fillMaxWidth().testTag("operational_disclaimer")
  ) {
    Row(
      modifier = Modifier.padding(10.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
        Icons.Default.Shield,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.secondary,
        modifier = Modifier.size(18.dp)
      )
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = "تصمیمات عملیاتی مراقبت پرواز باید بر اساس منابع رسمی معتبر هوانوردی و دستورالعمل‌های محلی مصوب اتخاذ گردد.\nOperational decisions must be based on current authorized aviation information sources and applicable local procedures.",
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        lineHeight = 16.sp
      )
    }
  }
}

/**
 * 1. Specialized Wind & Gust Card (Aero Cyan/Sky Blue)
 * Tailored for instant wind assessment without visual fatigue.
 */
@Composable
fun WindAeroCard(
  isCalm: Boolean,
  windDirDeg: Int?,
  windSpeedKt: Int?,
  windGustKt: Int?,
  isVariable: Boolean,
  varFromDeg: Int?,
  varToDeg: Int?,
  modifier: Modifier = Modifier
) {
  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = WindCardBg),
    border = androidx.compose.foundation.BorderStroke(1.5.dp, WindCardBorder),
    modifier = modifier.fillMaxWidth().testTag("wind_aero_card")
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = WindAccent.copy(alpha = 0.15f),
            modifier = Modifier.size(36.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(Icons.Default.Air, contentDescription = null, tint = WindAccent, modifier = Modifier.size(20.dp))
            }
          }
          Spacer(modifier = Modifier.width(8.dp))
          Column {
            Text(
              text = "باد سطحی و جهت (Surface Wind)",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold,
              color = AtcTextMain
            )
            Text(
              text = "تله‌متری جهت و سرعت باد برج و تقرب",
              style = MaterialTheme.typography.labelSmall,
              color = AtcTextMuted
            )
          }
        }

        if (windGustKt != null) {
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = WindGustBadgeBg,
            border = androidx.compose.foundation.BorderStroke(1.dp, WindGustBadgeBorder)
          ) {
            Text(
              text = "تندباد (GUST): $windGustKt KT",
              color = WindGustBadgeText,
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          val mainText = when {
            isCalm -> "آرام (CALM 00000KT)"
            isVariable && windSpeedKt != null -> "جهت متغیر (VRB) / $windSpeedKt گره"
            windDirDeg != null && windSpeedKt != null -> "${windDirDeg}° / $windSpeedKt گره (KT)"
            else -> "نامشخص / گزارش نشده"
          }

          Text(
            text = mainText,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.ExtraBold,
            color = WindAccent
          )

          if (varFromDeg != null && varToDeg != null) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "تغییر زاویه نوسانی: بین ${varFromDeg}° و ${varToDeg}°",
              style = MaterialTheme.typography.labelSmall,
              color = AtcTextMuted
            )
          }

          if (windSpeedKt != null && !isCalm) {
            val mps = (windSpeedKt * 0.514444).toInt()
            val kmh = (windSpeedKt * 1.852).toInt()
            Text(
              text = "معادل: $mps متر بر ثانیه (m/s) • $kmh کیلومتر بر ساعت",
              style = MaterialTheme.typography.labelSmall,
              color = AtcTextSubtle
            )
          }
        }

        if (windDirDeg != null && windSpeedKt != null && !isCalm) {
          WindVectorVisualizer(
            windDirDeg = windDirDeg,
            windSpeedKt = windSpeedKt
          )
        }
      }
    }
  }
}

/**
 * 2. Specialized Visibility & Flight Category Card (Dynamic Green / Blue / Amber / Magenta)
 * Conveys ceiling and landing minimums ergonomically.
 */
@Composable
fun VisibilityRvrCard(
  flightCategory: String,
  isCavok: Boolean,
  visibilityMeters: Int?,
  visibilitySm: String?,
  rvrText: String?,
  modifier: Modifier = Modifier
) {
  val (bgColor, borderColor, accentColor, categoryTitleFa) = when (flightCategory.uppercase()) {
    "VFR" -> listOf(CategoryVfrBg, CategoryVfrBorder, CategoryVfr, "دید پرواز بصری (VFR)")
    "MVFR" -> listOf(CategoryMvfrBg, CategoryMvfrBorder, CategoryMvfr, "دید پرواز بینابینی (MVFR)")
    "IFR" -> listOf(CategoryIfrBg, CategoryIfrBorder, CategoryIfr, "دید پرواز دستگاهی (IFR)")
    "LIFR" -> listOf(CategoryLifrBg, CategoryLifrBorder, CategoryLifr, "حداقل‌های دید شدید (LIFR)")
    else -> listOf(CategoryMvfrBg, CategoryMvfrBorder, CategoryMvfr, "دید استاندارد هوانوردی")
  }

  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = bgColor as Color),
    border = androidx.compose.foundation.BorderStroke(1.5.dp, borderColor as Color),
    modifier = modifier.fillMaxWidth().testTag("visibility_rvr_card")
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = (accentColor as Color).copy(alpha = 0.15f),
            modifier = Modifier.size(36.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(Icons.Default.Visibility, contentDescription = null, tint = accentColor, modifier = Modifier.size(20.dp))
            }
          }
          Spacer(modifier = Modifier.width(8.dp))
          Column {
            Text(
              text = "دید افقی و دید امتداد باند (Visibility & RVR)",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold,
              color = AtcTextMain
            )
            Text(
              text = categoryTitleFa as String,
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.SemiBold,
              color = accentColor
            )
          }
        }

        FlightCategoryBadge(category = flightCategory)
      }

      Spacer(modifier = Modifier.height(12.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(text = "دید افقی غالب (Prevailing Vis)", style = MaterialTheme.typography.labelSmall, color = AtcTextMuted)
          val visDisplay = when {
            isCavok -> "CAVOK (دید بیش از ۱۰ کیلومتر)"
            visibilityMeters != null -> "${visibilityMeters} متر (${String.format(java.util.Locale.US, "%.1f", visibilityMeters / 1000.0)} کیلومتر)"
            visibilitySm != null -> "$visibilitySm مایل قانونی (SM)"
            else -> "نامشخص"
          }
          Text(
            text = visDisplay,
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.Bold,
            color = accentColor as Color
          )
        }

        Column(modifier = Modifier.weight(1f)) {
          Text(text = "دید امتداد باند (RVR)", style = MaterialTheme.typography.labelSmall, color = AtcTextMuted)
          Text(
            text = rvrText ?: "فاقد گزارش RVR",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            color = AtcTextMain
          )
        }
      }
    }
  }
}

/**
 * 3. Specialized Clouds & Ceiling Card (Soft Indigo/Periwinkle)
 */
@Composable
fun CloudsCeilingCard(
  cloudsSummary: String,
  ceilingFt: Int?,
  isCavok: Boolean,
  modifier: Modifier = Modifier
) {
  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = CloudsCardBg),
    border = androidx.compose.foundation.BorderStroke(1.5.dp, CloudsCardBorder),
    modifier = modifier.fillMaxWidth().testTag("clouds_ceiling_card")
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = CloudsAccent.copy(alpha = 0.15f),
            modifier = Modifier.size(36.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(Icons.Default.Cloud, contentDescription = null, tint = CloudsAccent, modifier = Modifier.size(20.dp))
            }
          }
          Spacer(modifier = Modifier.width(8.dp))
          Column {
            Text(
              text = "پوشش ابرها و کف ابر (Clouds & Ceiling)",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold,
              color = AtcTextMain
            )
            Text(
              text = "لایه‌های ارتفاعی ابر بالای تراز فرودگاه (AGL)",
              style = MaterialTheme.typography.labelSmall,
              color = AtcTextMuted
            )
          }
        }

        if (ceilingFt != null) {
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = CloudsAccent,
            modifier = Modifier.padding(2.dp)
          ) {
            Text(
              text = "CEILING: $ceilingFt FT",
              color = Color.White,
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      Text(
        text = if (isCavok) "CAVOK — بدون ابر زیر ۵۰۰۰ پا و بدون ابرهای جوشان همرفتی (CB/TCU)" else cloudsSummary,
        style = MaterialTheme.typography.bodyMedium,
        fontWeight = FontWeight.SemiBold,
        color = AtcTextMain,
        lineHeight = 22.sp
      )

      if (ceilingFt != null) {
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = "سقف پرواز عملیاتی (کف ضخیم‌ترین لایه ابر بیش از ۴ اکتا): $ceilingFt پا AGL",
          style = MaterialTheme.typography.labelSmall,
          color = CloudsAccent,
          fontWeight = FontWeight.Medium
        )
      }
    }
  }
}

/**
 * 4. Specialized Temperature & Dew Point Card (Warm Apricot/Coral)
 */
@Composable
fun TempDewPointCard(
  tempC: Int?,
  dewpointC: Int?,
  modifier: Modifier = Modifier
) {
  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = TempCardBg),
    border = androidx.compose.foundation.BorderStroke(1.5.dp, TempCardBorder),
    modifier = modifier.fillMaxWidth().testTag("temp_dew_point_card")
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = TempAccent.copy(alpha = 0.15f),
            modifier = Modifier.size(36.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(Icons.Default.Thermostat, contentDescription = null, tint = TempAccent, modifier = Modifier.size(20.dp))
            }
          }
          Spacer(modifier = Modifier.width(8.dp))
          Column {
            Text(
              text = "دما و نقطه شبنم (Temperature & Dew Point)",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold,
              color = AtcTextMain
            )
            Text(
              text = "بررسی رطوبت نسبی و پتانسیل تشکیل مه و یخ‌زدگی",
              style = MaterialTheme.typography.labelSmall,
              color = AtcTextMuted
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(text = "دمای محیط (Air Temp)", style = MaterialTheme.typography.labelSmall, color = AtcTextMuted)
          Text(
            text = tempC?.let { "$it°C (${(it * 9/5) + 32}°F)" } ?: "گزارش نشده",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = TempAccent
          )
        }

        Column(modifier = Modifier.weight(1f)) {
          Text(text = "نقطه شبنم (Dew Point)", style = MaterialTheme.typography.labelSmall, color = AtcTextMuted)
          Text(
            text = dewpointC?.let { "$it°C" } ?: "گزارش نشده",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = AtcTextMain
          )
        }

        if (tempC != null && dewpointC != null) {
          val spread = tempC - dewpointC
          Column(modifier = Modifier.weight(1f)) {
            Text(text = "فاصله دما/شبنم (Spread)", style = MaterialTheme.typography.labelSmall, color = AtcTextMuted)
            Text(
              text = "$spread°C",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = if (spread <= 2) StatusRed else AtcTextMain
            )
            if (spread <= 2) {
              Text(
                text = "هشدار: احتمال مه یا دید کم",
                style = MaterialTheme.typography.labelSmall,
                color = StatusRed,
                fontSize = 9.sp
              )
            }
          }
        }
      }
    }
  }
}

/**
 * 5. Specialized Altimeter & QNH Pressure Card (Crisp Teal)
 */
@Composable
fun AltimeterQnhCard(
  altimHpa: Int?,
  altimInHg: Double?,
  modifier: Modifier = Modifier
) {
  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = QnhCardBg),
    border = androidx.compose.foundation.BorderStroke(1.5.dp, QnhCardBorder),
    modifier = modifier.fillMaxWidth().testTag("altimeter_qnh_card")
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = QnhAccent.copy(alpha = 0.15f),
            modifier = Modifier.size(36.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(Icons.Default.Speed, contentDescription = null, tint = QnhAccent, modifier = Modifier.size(20.dp))
            }
          }
          Spacer(modifier = Modifier.width(8.dp))
          Column {
            Text(
              text = "فشار جوی و تنظیم ارتفاع‌سنج (Altimeter / QNH)",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold,
              color = AtcTextMain
            )
            Text(
              text = "تنظیم زیرمقیاس ارتفاع‌سنج کابین خلبان و زیردست رادار",
              style = MaterialTheme.typography.labelSmall,
              color = AtcTextMuted
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(text = "QNH استاندارد هوانوردی", style = MaterialTheme.typography.labelSmall, color = AtcTextMuted)
          Text(
            text = altimHpa?.let { "Q$it hPa" } ?: "نامشخص",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.ExtraBold,
            color = QnhAccent
          )
        }

        Column(modifier = Modifier.weight(1f)) {
          Text(text = "واحد اینچ جیوه (inHg)", style = MaterialTheme.typography.labelSmall, color = AtcTextMuted)
          Text(
            text = altimInHg?.let { "A${String.format(java.util.Locale.US, "%.2f", it)}" }
              ?: altimHpa?.let { "A${String.format(java.util.Locale.US, "%.2f", it * 0.02953)}" }
              ?: "نامشخص",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = AtcTextMain
          )
        }

        Column(modifier = Modifier.weight(1f)) {
          Text(text = "فشار تراز استاندارد", style = MaterialTheme.typography.labelSmall, color = AtcTextMuted)
          Text(
            text = "1013.25 hPa",
            style = MaterialTheme.typography.bodyMedium,
            color = AtcTextMuted
          )
        }
      }
    }
  }
}

