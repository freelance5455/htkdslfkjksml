package com.example.ui.chat

import android.graphics.Bitmap
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.example.data.model.MerkopMode
import com.example.data.repository.ConversationRepository
import com.example.data.repository.MerkopAiRepository
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

@OptIn(ExperimentalCoroutinesApi::class)
class MerkopChatViewModel(
    private val conversationRepository: ConversationRepository,
    private val aiRepository: MerkopAiRepository,
    private val currentUserId: String
) : ViewModel() {

    private val _selectedConversationId = MutableStateFlow<String?>(null)
    val selectedConversationId: StateFlow<String?> = _selectedConversationId.asStateFlow()

    private val _selectedMode = MutableStateFlow(MerkopMode.GENERAL)
    val selectedMode: StateFlow<MerkopMode> = _selectedMode.asStateFlow()

    private val _streamingText = MutableStateFlow<String?>(null)
    val streamingText: StateFlow<String?> = _streamingText.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _aiError = MutableStateFlow<String?>(null)
    val aiError: StateFlow<String?> = _aiError.asStateFlow()

    private val _attachedImage = MutableStateFlow<Bitmap?>(null)
    val attachedImage: StateFlow<Bitmap?> = _attachedImage.asStateFlow()

    val conversationsState: StateFlow<UiState<List<Conversation>>> =
        conversationRepository.observeConversations(currentUserId)
            .map<List<Conversation>, UiState<List<Conversation>>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing conversations", rootError)
                emit(UiState.Error(rootError.localizedMessage ?: "Sohbetler yüklenemedi."))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Loading
            )

    val messagesState: StateFlow<UiState<List<ChatMessage>>> =
        _selectedConversationId
            .flatMapLatest { convId ->
                if (convId == null) {
                    flowOf(UiState.Success(emptyList()))
                } else {
                    conversationRepository.observeMessages(currentUserId, convId)
                        .map<List<ChatMessage>, UiState<List<ChatMessage>>> { UiState.Success(it) }
                        .catch { error ->
                            val firestoreError = generateSequence(error) { it.cause }
                                .filterIsInstance<FirebaseFirestoreException>()
                                .firstOrNull()
                            if (firestoreError == null && error is CancellationException) throw error
                            val rootError = firestoreError ?: error
                            Log.w(TAG, "Error observing messages", rootError)
                            emit(UiState.Error(rootError.localizedMessage ?: "Mesajlar yüklenemedi."))
                        }
                }
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Success(emptyList())
            )

    fun selectConversation(conversation: Conversation) {
        _selectedConversationId.value = conversation.id
        _selectedMode.value = MerkopMode.fromId(conversation.mode)
        _aiError.value = null
    }

    fun startNewConversation() {
        _selectedConversationId.value = null
        _aiError.value = null
        _streamingText.value = null
        _attachedImage.value = null
    }

    fun setMode(mode: MerkopMode) {
        _selectedMode.value = mode
        val convId = _selectedConversationId.value ?: return
        viewModelScope.launch {
            conversationRepository.updateConversationMode(convId, mode)
        }
    }

    fun setAttachedImage(bitmap: Bitmap?) {
        _attachedImage.value = bitmap?.let { scaleBitmapIfNeeded(it, MAX_IMAGE_DIMENSION_PX) }
    }

    fun dismissAiError() {
        _aiError.value = null
    }

    fun renameConversation(conversationId: String, newTitle: String) {
        viewModelScope.launch {
            conversationRepository.renameConversation(conversationId, newTitle)
                .onFailure { e ->
                    _aiError.value = e.localizedMessage ?: "Sohbet adı değiştirilemedi."
                }
        }
    }

    fun deleteConversation(conversationId: String) {
        viewModelScope.launch {
            if (_selectedConversationId.value == conversationId) {
                _selectedConversationId.value = null
            }
            conversationRepository.deleteConversation(conversationId)
                .onFailure { e ->
                    _aiError.value = e.localizedMessage ?: "Sohbet silinemedi."
                }
        }
    }

    fun sendMessage(rawPrompt: String) {
        if (_isGenerating.value) return
        val imageToSend = _attachedImage.value
        val prompt = rawPrompt.trim().ifEmpty {
            if (imageToSend != null) "Bu görseli analiz et ve Türkçe açıkla." else return
        }

        val mode = _selectedMode.value
        val existingHistory = (messagesState.value as? UiState.Success)?.data.orEmpty()

        viewModelScope.launch {
            _isGenerating.value = true
            _aiError.value = null
            _attachedImage.value = null

            try {
                _streamingText.value = ""

                val convId = _selectedConversationId.value ?: run {
                    val created = withTimeout(FIRESTORE_WRITE_TIMEOUT_MS) {
                        conversationRepository.createConversation(
                            title = prompt.take(48),
                            mode = mode
                        )
                    }.getOrElse { err ->
                        _aiError.value = err.localizedMessage ?: "Yeni sohbet oluşturulamadı."
                        return@launch
                    }
                    _selectedConversationId.value = created
                    created
                }

                val isFirstMessage = existingHistory.isEmpty()
                val userCount = existingHistory.size + 1L
                withTimeout(FIRESTORE_WRITE_TIMEOUT_MS) {
                    conversationRepository.addMessageAndUpdateConversation(
                        conversationId = convId,
                        role = ChatMessage.ROLE_USER,
                        text = prompt,
                        hasImage = imageToSend != null,
                        newTitleIfFirst = if (isFirstMessage) prompt.take(48) else null,
                        newMessageCount = userCount
                    )
                }.getOrElse { err ->
                    _aiError.value = err.localizedMessage ?: "Mesaj kaydedilemedi."
                    return@launch
                }

                val accumulated = StringBuilder()

                withTimeout(INFERENCE_TIMEOUT_MS) {
                    aiRepository.streamReply(
                        mode = mode,
                        history = existingHistory,
                        userPrompt = prompt,
                        attachedImage = imageToSend
                    ).collect { chunk ->
                        accumulated.append(chunk)
                        _streamingText.value = accumulated.toString()
                    }
                    if (accumulated.isBlank()) {
                        val fallback = aiRepository.generateReplyUnary(
                            mode = mode,
                            history = existingHistory,
                            userPrompt = prompt,
                            attachedImage = imageToSend
                        )
                        if (!fallback.isNullOrBlank()) {
                            accumulated.append(fallback)
                            _streamingText.value = fallback
                        }
                    }
                }

                val replyText = accumulated.toString().trim()
                if (replyText.isNotEmpty()) {
                    withTimeout(FIRESTORE_WRITE_TIMEOUT_MS) {
                        conversationRepository.addMessageAndUpdateConversation(
                            conversationId = convId,
                            role = ChatMessage.ROLE_MODEL,
                            text = replyText,
                            hasImage = false,
                            newTitleIfFirst = null,
                            newMessageCount = userCount + 1L
                        )
                    }.onFailure { err ->
                        _aiError.value = err.localizedMessage ?: "Merkop yanıtı kaydedilemedi."
                    }
                } else {
                    _aiError.value = "Merkop boş yanıt döndürdü. Lütfen tekrar deneyin."
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Merkop operation timed out", e)
                _aiError.value = "Bağlantı veya yanıt süresi zaman aşımına uğradı. Lütfen tekrar deneyin."
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Merkop AI inference failed", e)
                _aiError.value = MerkopAiRepository.toUserFriendlyMessage(e)
            } finally {
                _isGenerating.value = false
                _streamingText.value = null
            }
        }
    }

    private fun scaleBitmapIfNeeded(bitmap: Bitmap, maxDim: Int): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        if (width <= maxDim && height <= maxDim) return bitmap
        val ratio = minOf(maxDim.toFloat() / width, maxDim.toFloat() / height)
        val newW = (width * ratio).toInt().coerceAtLeast(1)
        val newH = (height * ratio).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bitmap, newW, newH, true)
    }

    private companion object {
        const val TAG = "MerkopChatVM"
        const val STOP_TIMEOUT_MILLIS = 5000L
        const val FIRESTORE_WRITE_TIMEOUT_MS = 15_000L
        const val INFERENCE_TIMEOUT_MS = 60_000L
        const val MAX_IMAGE_DIMENSION_PX = 1280
    }
}
