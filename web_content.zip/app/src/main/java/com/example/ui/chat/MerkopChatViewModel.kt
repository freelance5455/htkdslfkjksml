package com.example.ui.chat

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.example.data.model.MerkopMode
import com.example.data.repository.ConversationRepository
import com.example.data.repository.MerkopAiRepository
import com.example.util.Model3dAsset
import com.example.util.Model3dHelper
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

@OptIn(ExperimentalCoroutinesApi::class)
class MerkopChatViewModel(
    private val conversationRepository: ConversationRepository,
    private val aiRepository: MerkopAiRepository,
    private val currentUserId: String
) : ViewModel() {

    private val _selectedConversationId = MutableStateFlow<String?>(null)
    val selectedConversationId: StateFlow<String?> = _selectedConversationId.asStateFlow()

    private val _selectedMode = MutableStateFlow(MerkopMode.GENERAL)
    val selectedMode: StateFlow<MerkopMode> = _selectedMode.asStateFlow()

    private val _streamingText = MutableStateFlow<String?>(null)
    val streamingText: StateFlow<String?> = _streamingText.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _aiError = MutableStateFlow<String?>(null)
    val aiError: StateFlow<String?> = _aiError.asStateFlow()

    private val _attachedImage = MutableStateFlow<Bitmap?>(null)
    val attachedImage: StateFlow<Bitmap?> = _attachedImage.asStateFlow()

    private val _deepCodingEnabled = MutableStateFlow(false)
    val deepCodingEnabled: StateFlow<Boolean> = _deepCodingEnabled.asStateFlow()

    private val _autoReviewEnabled = MutableStateFlow(false)
    val autoReviewEnabled: StateFlow<Boolean> = _autoReviewEnabled.asStateFlow()

    private val _pendingModels3d = MutableStateFlow<List<Model3dAsset>>(emptyList())
    val pendingModels3d: StateFlow<List<Model3dAsset>> = _pendingModels3d.asStateFlow()

    private val _conversationModels3d = MutableStateFlow<List<Model3dAsset>>(emptyList())
    val conversationModels3d: StateFlow<List<Model3dAsset>> = _conversationModels3d.asStateFlow()

    val conversationsState: StateFlow<UiState<List<Conversation>>> =
        conversationRepository.observeConversations(currentUserId)
            .map<List<Conversation>, UiState<List<Conversation>>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing conversations", rootError)
                emit(UiState.Error(rootError.localizedMessage ?: "Sohbetler yüklenemedi."))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Loading
            )

    val messagesState: StateFlow<UiState<List<ChatMessage>>> =
        _selectedConversationId
            .flatMapLatest { convId ->
                if (convId == null) {
                    flowOf(UiState.Success(emptyList()))
                } else {
                    conversationRepository.observeMessages(currentUserId, convId)
                        .map<List<ChatMessage>, UiState<List<ChatMessage>>> { UiState.Success(it) }
                        .catch { error ->
                            val firestoreError = generateSequence(error) { it.cause }
                                .filterIsInstance<FirebaseFirestoreException>()
                                .firstOrNull()
                            if (firestoreError == null && error is CancellationException) throw error
                            val rootError = firestoreError ?: error
                            Log.w(TAG, "Error observing messages", rootError)
                            emit(UiState.Error(rootError.localizedMessage ?: "Mesajlar yüklenemedi."))
                        }
                }
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Success(emptyList())
            )

    fun selectConversation(conversation: Conversation, context: Context? = null) {
        _selectedConversationId.value = conversation.id
        _selectedMode.value = MerkopMode.fromId(conversation.mode)
        _aiError.value = null
        if (context != null) {
            loadConversationModels(context, conversation.id)
        } else {
            _conversationModels3d.value = emptyList()
        }
    }

    fun loadConversationModels(context: Context, conversationId: String?) {
        val convId = conversationId ?: run {
            _conversationModels3d.value = emptyList()
            return
        }
        viewModelScope.launch {
            val loaded = withContext(Dispatchers.IO) {
                Model3dHelper.loadModelsForConversation(context.applicationContext, convId)
            }
            _conversationModels3d.value = loaded
        }
    }

    fun startNewConversation() {
        _selectedConversationId.value = null
        _aiError.value = null
        _streamingText.value = null
        _attachedImage.value = null
        _pendingModels3d.value = emptyList()
        _conversationModels3d.value = emptyList()
    }

    fun setMode(mode: MerkopMode) {
        _selectedMode.value = mode
        val convId = _selectedConversationId.value ?: return
        viewModelScope.launch {
            conversationRepository.updateConversationMode(convId, mode)
        }
    }

    fun setAttachedImage(bitmap: Bitmap?) {
        _attachedImage.value = bitmap?.let { scaleBitmapIfNeeded(it, MAX_IMAGE_DIMENSION_PX) }
    }

    fun attachModel3d(context: Context, uri: Uri) {
        val convKey = _selectedConversationId.value ?: "_draft"
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                Model3dHelper.importFromUri(context.applicationContext, uri, convKey)
            }
            result.onSuccess { asset ->
                _pendingModels3d.value = _pendingModels3d.value
                    .filterNot { it.fileName == asset.fileName } + asset
            }.onFailure { err ->
                _aiError.value = err.localizedMessage ?: "3D model yüklenemedi."
            }
        }
    }

    fun attachModel3dFromUrl(context: Context, url: String, sketchfabToken: String = "") {
        val convKey = _selectedConversationId.value ?: "_draft"
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                Model3dHelper.importFromUrl(context.applicationContext, url, convKey, sketchfabToken)
            }
            result.onSuccess { asset ->
                _pendingModels3d.value = _pendingModels3d.value
                    .filterNot { it.fileName == asset.fileName } + asset
            }.onFailure { err ->
                _aiError.value = err.localizedMessage ?: "Linkten 3D model alınamadı."
            }
        }
    }

    fun attachPresetModel3d(context: Context, kind: String) {
        val convKey = _selectedConversationId.value ?: "_draft"
        viewModelScope.launch {
            val result = withContext(Dispatchers.IO) {
                Model3dHelper.createPresetModel(context.applicationContext, kind, convKey)
            }
            result.onSuccess { asset ->
                _pendingModels3d.value = _pendingModels3d.value
                    .filterNot { it.fileName == asset.fileName } + asset
            }.onFailure { err ->
                _aiError.value = err.localizedMessage ?: "Hazır 3D model eklenemedi."
            }
        }
    }

    fun removePendingModel3d(assetId: String) {
        _pendingModels3d.value = _pendingModels3d.value.filterNot { it.id == assetId }
    }

    fun removeConversationModel3d(context: Context, assetId: String) {
        val convId = _selectedConversationId.value ?: return
        viewModelScope.launch {
            val updated = withContext(Dispatchers.IO) {
                Model3dHelper.deleteAsset(context.applicationContext, convId, assetId)
            }
            _conversationModels3d.value = updated
        }
    }

    fun dismissAiError() {
        _aiError.value = null
    }

    fun toggleDeepCoding() {
        _deepCodingEnabled.value = !_deepCodingEnabled.value
    }

    fun toggleAutoReview() {
        _autoReviewEnabled.value = !_autoReviewEnabled.value
    }

    fun renameConversation(conversationId: String, newTitle: String) {
        viewModelScope.launch {
            conversationRepository.renameConversation(conversationId, newTitle)
                .onFailure { e ->
                    _aiError.value = e.localizedMessage ?: "Sohbet adı değiştirilemedi."
                }
        }
    }

    fun deleteConversation(conversationId: String) {
        viewModelScope.launch {
            if (_selectedConversationId.value == conversationId) {
                _selectedConversationId.value = null
            }
            conversationRepository.deleteConversation(conversationId)
                .onFailure { e ->
                    _aiError.value = e.localizedMessage ?: "Sohbet silinemedi."
                }
        }
    }

    fun sendMessage(rawPrompt: String, appContext: Context? = null) {
        if (_isGenerating.value) return
        val imageToSend = _attachedImage.value
        val pendingModels = _pendingModels3d.value
        val basePrompt = rawPrompt.trim().ifEmpty {
            when {
                pendingModels.isNotEmpty() ->
                    "Yüklediğim ${pendingModels.joinToString(", ") { it.fileName }} 3D modelini incele ve etkileşimli bir 3D sahneye/oyuna koy."
                imageToSend != null ->
                    "Bu görseli analiz et ve Türkçe açıkla."
                else -> return
            }
        }
        val prompt = if (pendingModels.isNotEmpty()) {
            val tag = pendingModels.joinToString(", ") { "🧊 ${it.fileName}" }
            "[$tag]\n$basePrompt"
        } else {
            basePrompt
        }

        val mode = _selectedMode.value
        val existingHistory = (messagesState.value as? UiState.Success)?.data.orEmpty()

        viewModelScope.launch {
            _isGenerating.value = true
            _aiError.value = null
            _attachedImage.value = null

            try {
                _streamingText.value = ""

                val convId = _selectedConversationId.value ?: run {
                    val created = withTimeout(FIRESTORE_WRITE_TIMEOUT_MS) {
                        conversationRepository.createConversation(
                            title = basePrompt.take(48),
                            mode = mode
                        )
                    }.getOrElse { err ->
                        _aiError.value = err.localizedMessage ?: "Yeni sohbet oluşturulamadı."
                        return@launch
                    }
                    _selectedConversationId.value = created
                    created
                }

                val activeModels3d: List<Model3dAsset> = if (pendingModels.isNotEmpty() && appContext != null) {
                    val persisted = withContext(Dispatchers.IO) {
                        Model3dHelper.attachAssetsToConversation(appContext.applicationContext, pendingModels, convId)
                    }
                    _pendingModels3d.value = emptyList()
                    _conversationModels3d.value = persisted
                    persisted
                } else {
                    val combined = (_conversationModels3d.value + pendingModels)
                        .associateBy { it.fileName }
                        .values
                        .toList()
                    if (pendingModels.isNotEmpty()) {
                        _pendingModels3d.value = emptyList()
                        _conversationModels3d.value = combined
                    }
                    combined
                }

                val isFirstMessage = existingHistory.isEmpty()
                val userCount = existingHistory.size + 1L
                withTimeout(FIRESTORE_WRITE_TIMEOUT_MS) {
                    conversationRepository.addMessageAndUpdateConversation(
                        conversationId = convId,
                        role = ChatMessage.ROLE_USER,
                        text = prompt,
                        hasImage = imageToSend != null,
                        newTitleIfFirst = if (isFirstMessage) basePrompt.take(48) else null,
                        newMessageCount = userCount
                    )
                }.getOrElse { err ->
                    _aiError.value = err.localizedMessage ?: "Mesaj kaydedilemedi."
                    return@launch
                }

                val accumulated = StringBuilder()

                val isDeepCoding = mode == MerkopMode.CODER && _deepCodingEnabled.value
                val isAutoReview = mode == MerkopMode.CODER && _autoReviewEnabled.value

                withTimeout(INFERENCE_TIMEOUT_MS) {
                    aiRepository.streamReply(
                        mode = mode,
                        history = existingHistory,
                        userPrompt = basePrompt,
                        attachedImage = imageToSend,
                        deepCoding = isDeepCoding,
                        attachedModels3d = activeModels3d
                    ).collect { chunk ->
                        accumulated.append(chunk)
                        _streamingText.value = accumulated.toString()
                    }
                    if (accumulated.isBlank()) {
                        val fallback = aiRepository.generateReplyUnary(
                            mode = mode,
                            history = existingHistory,
                            userPrompt = basePrompt,
                            attachedImage = imageToSend,
                            attachedModels3d = activeModels3d
                        )
                        if (!fallback.isNullOrBlank()) {
                            accumulated.append(fallback)
                            _streamingText.value = fallback
                        }
                    }
                    if (isAutoReview && accumulated.isNotBlank()) {
                        _streamingText.value = accumulated.toString() + "\n\n⚡ Kod otomatik denetleniyor…"
                        val audited = aiRepository.reviewAndPolishCode(
                            userPrompt = basePrompt,
                            draftReply = accumulated.toString()
                        )
                        if (!audited.isNullOrBlank()) {
                            accumulated.clear()
                            accumulated.append(audited)
                            _streamingText.value = audited
                        }
                    }
                }

                val replyText = accumulated.toString().trim()
                if (replyText.isNotEmpty()) {
                    withTimeout(FIRESTORE_WRITE_TIMEOUT_MS) {
                        conversationRepository.addMessageAndUpdateConversation(
                            conversationId = convId,
                            role = ChatMessage.ROLE_MODEL,
                            text = replyText,
                            hasImage = false,
                            newTitleIfFirst = null,
                            newMessageCount = userCount + 1L
                        )
                    }.onFailure { err ->
                        _aiError.value = err.localizedMessage ?: "Merkop yanıtı kaydedilemedi."
                    }
                } else {
                    _aiError.value = "Merkop boş yanıt döndürdü. Lütfen tekrar deneyin."
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Merkop operation timed out", e)
                _aiError.value = "Bağlantı veya yanıt süresi zaman aşımına uğradı. Lütfen tekrar deneyin."
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Merkop AI inference failed", e)
                _aiError.value = MerkopAiRepository.toUserFriendlyMessage(e)
            } finally {
                _isGenerating.value = false
                _streamingText.value = null
            }
        }
    }

    private fun scaleBitmapIfNeeded(bitmap: Bitmap, maxDim: Int): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        if (width <= maxDim && height <= maxDim) return bitmap
        val ratio = minOf(maxDim.toFloat() / width, maxDim.toFloat() / height)
        val newW = (width * ratio).toInt().coerceAtLeast(1)
        val newH = (height * ratio).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bitmap, newW, newH, true)
    }

    private companion object {
        const val TAG = "MerkopChatVM"
        const val STOP_TIMEOUT_MILLIS = 5000L
        const val FIRESTORE_WRITE_TIMEOUT_MS = 15_000L
        const val INFERENCE_TIMEOUT_MS = 60_000L
        const val MAX_IMAGE_DIMENSION_PX = 1280
    }
}
