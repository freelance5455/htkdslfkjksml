package com.example.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.example.R
import com.example.data.preferences.UserPreferences
import com.example.engine.NumberGroupingStyle
import com.example.ui.components.AetherCard
import com.example.ui.components.AetherFilterChip
import com.example.ui.theme.AetherTheme
import com.example.ui.theme.AppThemeMode

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingsBottomSheet(
  preferences: UserPreferences,
  onDismiss: () -> Unit,
  onSelectTheme: (AppThemeMode) -> Unit,
  onToggleHaptics: (Boolean) -> Unit,
  onSelectGrouping: (NumberGroupingStyle) -> Unit,
  onSelectPrecision: (Int) -> Unit,
) {
  val colors = AetherTheme.colors
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = colors.surface,
    contentColor = colors.textPrimary,
    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
  ) {
    Column(
      modifier =
        Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 16.dp)
          .padding(bottom = 28.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      Text(
        text = stringResource(R.string.settings_title),
        style = MaterialTheme.typography.headlineSmall,
        color = colors.textPrimary,
      )

      // Appearance
      AetherCard(backgroundColor = colors.surfaceElevated) {
        Text(
          text = stringResource(R.string.settings_appearance),
          style = MaterialTheme.typography.labelLarge,
          color = colors.lavender,
        )
        Spacer(modifier = Modifier.height(12.dp))
        FlowRow(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          AppThemeMode.entries.forEach { mode ->
            AetherFilterChip(
              label = mode.label,
              selected = preferences.themeMode == mode,
              onClick = { onSelectTheme(mode) },
              hapticsEnabled = preferences.hapticEnabled,
              modifier = Modifier.testTag("theme_option_${mode.name}"),
            )
          }
        }
      }

      // Haptics
      AetherCard(backgroundColor = colors.surfaceElevated) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(
              text = stringResource(R.string.settings_haptics),
              style = MaterialTheme.typography.titleMedium,
              color = colors.textPrimary,
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = stringResource(R.string.settings_haptics_desc),
              style = MaterialTheme.typography.bodySmall,
              color = colors.textSecondary,
            )
          }
          Switch(
            checked = preferences.hapticEnabled,
            onCheckedChange = onToggleHaptics,
            colors =
              SwitchDefaults.colors(
                checkedThumbColor = Color(0xFFF1F0F5),
                checkedTrackColor = colors.accent,
                uncheckedThumbColor = colors.textSecondary,
                uncheckedTrackColor = colors.surface,
              ),
            modifier = Modifier.testTag("haptics_switch"),
          )
        }
      }

      // Number formatting
      AetherCard(backgroundColor = colors.surfaceElevated) {
        Text(
          text = stringResource(R.string.settings_formatting),
          style = MaterialTheme.typography.labelLarge,
          color = colors.lavender,
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
          text = stringResource(R.string.settings_grouping),
          style = MaterialTheme.typography.bodyMedium,
          color = colors.textPrimary,
        )
        Spacer(modifier = Modifier.height(8.dp))
        FlowRow(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          NumberGroupingStyle.entries.forEach { style ->
            AetherFilterChip(
              label = "${style.label} (${style.example})",
              selected = preferences.groupingStyle == style,
              onClick = { onSelectGrouping(style) },
              hapticsEnabled = preferences.hapticEnabled,
            )
          }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text(
          text = stringResource(R.string.settings_precision),
          style = MaterialTheme.typography.bodyMedium,
          color = colors.textPrimary,
        )
        Spacer(modifier = Modifier.height(8.dp))
        val precisionOptions = listOf(-1 to "Auto", 0 to "0", 2 to "2", 4 to "4", 6 to "6", 8 to "8")
        FlowRow(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          precisionOptions.forEach { (value, label) ->
            AetherFilterChip(
              label = label,
              selected = preferences.decimalPrecision == value,
              onClick = { onSelectPrecision(value) },
              hapticsEnabled = preferences.hapticEnabled,
            )
          }
        }
      }

      // About
      AetherCard(backgroundColor = colors.surfaceElevated) {
        Text(
          text = stringResource(R.string.settings_about),
          style = MaterialTheme.typography.labelLarge,
          color = colors.lavender,
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Text(
            text = stringResource(R.string.app_name),
            style = MaterialTheme.typography.titleMedium,
            color = colors.textPrimary,
          )
          Text(
            text = "v${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})",
            style = MaterialTheme.typography.bodyMedium,
            color = colors.textSecondary,
          )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = stringResource(R.string.settings_privacy_note),
          style = MaterialTheme.typography.bodySmall,
          color = colors.textSecondary,
        )
      }
    }
  }
}
