package com.example.ui.components

import android.graphics.Bitmap
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DragIndicator
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Minimize
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.ui.theme.SuesaAccentWhite
import com.example.ui.theme.SuesaOverlayBg
import com.example.ui.theme.SuesaPurple
import com.example.ui.theme.SuesaPurpleBorder
import com.example.ui.theme.SuesaSuccess
import com.example.ui.theme.SuesaTextPrimary
import com.example.ui.theme.SuesaTextSecondary
import com.example.util.AttachmentHelper
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

@Composable
fun InteractiveScreenWorkspaceBanner(
    activeSceneIndex: Int,
    onSelectScene: (Int) -> Unit,
    onScanCurrentScreen: () -> Unit,
    modifier: Modifier = Modifier
) {
    val sceneBitmap = remember(activeSceneIndex) {
        if (activeSceneIndex > 0) {
            AttachmentHelper.generateInteractiveSceneBitmap(activeSceneIndex - 1)
        } else null
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF1A1426))
            .border(1.dp, SuesaPurpleBorder, RoundedCornerShape(16.dp))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "🖥️ Küçük Yüzen Ekran & Ekran Okuma Modu",
                    color = Color(0xFFE9D5FF),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Text(
                text = "Sürüklenebilir",
                color = Color(0xFFC084FC),
                fontSize = 11.sp
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "Yüzen Suesa panelini parmağınla istediğin yere sürükleyebilirsin. Test için aşağıdaki örnek ekranlardan birini açıp panelden 'Ekranı Gör ve Anlat'a basabilirsin:",
            color = Color(0xFFCCCCCC),
            fontSize = 11.sp,
            lineHeight = 16.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val scenes = listOf(
                0 to "💬 Sohbet Ekranı",
                1 to "⛏️ Minecraft @Suesa_S",
                2 to "💻 Kod / Hata Ekranı",
                3 to "📝 Notlar & Ödev"
            )
            scenes.forEach { (idx, label) ->
                val selected = activeSceneIndex == idx
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (selected) SuesaPurple else Color(0xFF282036))
                        .border(
                            1.dp,
                            if (selected) SuesaAccentWhite else Color(0xFF4C376B),
                            RoundedCornerShape(10.dp)
                        )
                        .clickable { onSelectScene(idx) }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = label,
                        color = SuesaAccentWhite,
                        fontSize = 11.sp,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }

        if (sceneBitmap != null) {
            Spacer(modifier = Modifier.height(10.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, Color(0xFF444444), RoundedCornerShape(12.dp))
            ) {
                Image(
                    bitmap = sceneBitmap.asImageBitmap(),
                    contentDescription = "Aktif Ekran Sahnesi",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(165.dp)
                )
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xDD140A23))
                        .border(1.dp, SuesaPurpleBorder, RoundedCornerShape(8.dp))
                        .clickable(onClick = onScanCurrentScreen)
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = "👁️ Bu Ekranı Suesa'ya Okut",
                        color = Color(0xFFE9D5FF),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun FloatingSuesaOverlayPanel(
    isMinimizedBubble: Boolean,
    isLiveCameraEnabled: Boolean,
    isAutoWatchEnabled: Boolean,
    isAnalyzing: Boolean,
    visionCommentary: String,
    lastCapturedPreview: Bitmap?,
    mcBotStatus: String,
    onSetMinimized: (Boolean) -> Unit,
    onCloseOverlay: () -> Unit,
    onRequestScanScreen: (customQuestion: String?, liveCameraFrame: Bitmap?) -> Unit,
    onToggleLiveCamera: (Boolean) -> Unit,
    onToggleAutoWatch: (Boolean) -> Unit,
    onMinecraftCommand: (String) -> Unit,
    onEnterSystemPiP: () -> Unit,
    modifier: Modifier = Modifier
) {
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    var quickQuestion by remember { mutableStateOf("") }
    var showMcCommands by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val miniCameraPreviewView = remember { PreviewView(context) }

    // Bind CameraX if Live Camera Eye is toggled on inside the floating panel
    LaunchedEffect(isLiveCameraEnabled) {
        if (isLiveCameraEnabled) {
            try {
                val providerFuture = ProcessCameraProvider.getInstance(context)
                providerFuture.addListener({
                    runCatching {
                        val provider = providerFuture.get()
                        val preview = Preview.Builder().build().also {
                            it.setSurfaceProvider(miniCameraPreviewView.surfaceProvider)
                        }
                        provider.unbindAll()
                        provider.bindToLifecycle(
                            lifecycleOwner,
                            CameraSelector.DEFAULT_BACK_CAMERA,
                            preview
                        )
                    }
                }, ContextCompat.getMainExecutor(context))
            } catch (_: Exception) {
            }
        } else {
            runCatching {
                ProcessCameraProvider.getInstance(context).get().unbindAll()
            }
        }
    }

    // Periodic Auto Screen Watch when enabled
    LaunchedEffect(isAutoWatchEnabled, isLiveCameraEnabled) {
        while (isAutoWatchEnabled) {
            delay(12_000)
            if (!isAnalyzing) {
                val camBmp = if (isLiveCameraEnabled) {
                    runCatching { miniCameraPreviewView.bitmap }.getOrNull()
                } else null
                onRequestScanScreen(null, camBmp)
            }
        }
    }

    Box(
        modifier = modifier
            .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    offsetX += dragAmount.x
                    offsetY += dragAmount.y
                }
            }
    ) {
        if (isMinimizedBubble) {
            // Minimized Floating Bubble ("Küçük Yüzen Suesa Balonu")
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .shadow(16.dp, CircleShape)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            colors = listOf(Color(0xFF7B3FF2), Color(0xFF3B0764))
                        )
                    )
                    .border(2.dp, SuesaAccentWhite, CircleShape)
                    .clickable { onSetMinimized(false) }
                    .testTag("floating_bubble_expand_button"),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "S",
                        color = SuesaAccentWhite,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 20.sp
                    )
                    Text(
                        text = "👁️",
                        fontSize = 11.sp
                    )
                }
            }
        } else {
            // Expanded Small Floating Overlay Window ("Küçük Yüzen Ekran Paneli")
            Column(
                modifier = Modifier
                    .width(292.dp)
                    .heightIn(max = 460.dp)
                    .shadow(24.dp, RoundedCornerShape(18.dp))
                    .clip(RoundedCornerShape(18.dp))
                    .background(SuesaOverlayBg)
                    .border(1.5.dp, SuesaPurpleBorder, RoundedCornerShape(18.dp))
                    .padding(12.dp)
                    .testTag("overlay_panel_card")
            ) {
                // Drag & Action Title Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.DragIndicator,
                            contentDescription = "Taşı",
                            tint = Color(0xFFC084FC),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (isAnalyzing) Color(0xFFFBBF24) else SuesaSuccess)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Suesa Yüzen Panel",
                            color = SuesaAccentWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // System PiP (Floating Window outside app)
                        Box(
                            modifier = Modifier
                                .size(26.dp)
                                .clip(RoundedCornerShape(7.dp))
                                .background(Color(0xFF2B1F3D))
                                .clickable(onClick = onEnterSystemPiP),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PictureInPictureAlt,
                                contentDescription = "Küçük Pencere (PiP)",
                                tint = Color(0xFFE9D5FF),
                                modifier = Modifier.size(14.dp)
                            )
                        }

                        // Minimize to Floating Bubble
                        Box(
                            modifier = Modifier
                                .size(26.dp)
                                .clip(RoundedCornerShape(7.dp))
                                .background(Color(0xFF2B1F3D))
                                .clickable { onSetMinimized(true) }
                                .testTag("minimize_overlay_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Minimize,
                                contentDescription = "Balona Küçült",
                                tint = SuesaAccentWhite,
                                modifier = Modifier.size(14.dp)
                            )
                        }

                        // Close Panel
                        Box(
                            modifier = Modifier
                                .size(26.dp)
                                .clip(RoundedCornerShape(7.dp))
                                .background(Color(0xFF3A2030))
                                .clickable(onClick = onCloseOverlay)
                                .testTag("close_overlay_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Paneli Kapat",
                                tint = Color(0xFFFCA5A5),
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = Color(0xFF3D295E), thickness = 1.dp)
                Spacer(modifier = Modifier.height(8.dp))

                // Scrollable inner content of the floating window
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Primary Action: Scan Screen / Tell what Suesa sees!
                    Button(
                        onClick = {
                            val camFrame = if (isLiveCameraEnabled) {
                                runCatching { miniCameraPreviewView.bitmap }.getOrNull()
                            } else null
                            onRequestScanScreen(
                                quickQuestion.trim().takeIf { it.isNotEmpty() },
                                camFrame
                            )
                        },
                        enabled = !isAnalyzing,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SuesaPurple,
                            contentColor = SuesaAccentWhite
                        ),
                        shape = RoundedCornerShape(11.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(42.dp)
                            .testTag("scan_screen_button")
                    ) {
                        if (isAnalyzing) {
                            CircularProgressIndicator(
                                color = SuesaAccentWhite,
                                strokeWidth = 2.dp,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Ekran İnceleniyor…", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        } else {
                            Icon(
                                imageVector = Icons.Default.Visibility,
                                contentDescription = null,
                                modifier = Modifier.size(17.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isLiveCameraEnabled) "👁️ Kamerada Ne Var Söyle" else "👁️ Ekranı Gör ve Anlat",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Live Camera Eye inside Floating Panel (if enabled)
                    AnimatedVisibility(visible = isLiveCameraEnabled) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(110.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color.Black)
                                .border(1.dp, SuesaPurpleBorder, RoundedCornerShape(10.dp))
                        ) {
                            AndroidView(
                                factory = { miniCameraPreviewView },
                                modifier = Modifier.fillMaxSize()
                            )
                            Text(
                                text = "📷 Canlı Görüş Aktif",
                                color = SuesaAccentWhite,
                                fontSize = 10.sp,
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .padding(6.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xAA000000))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    // Suesa's Live Vision Commentary Box (with mini screenshot preview)
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF1F1630))
                            .border(1.dp, Color(0xFF4B3275), RoundedCornerShape(12.dp))
                            .padding(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "💬 Suesa'nın Ekran Yorumu:",
                                color = Color(0xFFD8B4FE),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            if (lastCapturedPreview != null) {
                                Image(
                                    bitmap = lastCapturedPreview.asImageBitmap(),
                                    contentDescription = "İncelenen Ekran",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(width = 38.dp, height = 24.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .border(1.dp, SuesaPurpleBorder, RoundedCornerShape(4.dp))
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(5.dp))

                        Text(
                            text = visionCommentary,
                            color = SuesaTextPrimary,
                            fontSize = 12.sp,
                            lineHeight = 17.sp
                        )
                    }

                    // Quick Question about the screen inside the Floating Panel
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OutlinedTextField(
                            value = quickQuestion,
                            onValueChange = { quickQuestion = it },
                            placeholder = {
                                Text("Ekran hakkında sor...", fontSize = 11.sp, color = SuesaTextSecondary)
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = Color(0xFF241C2E),
                                unfocusedContainerColor = Color(0xFF241C2E),
                                focusedBorderColor = SuesaPurple,
                                unfocusedBorderColor = Color(0xFF3D3150),
                                focusedTextColor = SuesaAccentWhite,
                                unfocusedTextColor = SuesaAccentWhite
                            ),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(
                                onSend = {
                                    val q = quickQuestion.trim()
                                    if (q.isNotEmpty() && !isAnalyzing) {
                                        val camFrame = if (isLiveCameraEnabled) {
                                            runCatching { miniCameraPreviewView.bitmap }.getOrNull()
                                        } else null
                                        onRequestScanScreen(q, camFrame)
                                        quickQuestion = ""
                                    }
                                }
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                        )

                        IconButton(
                            onClick = {
                                val q = quickQuestion.trim()
                                val camFrame = if (isLiveCameraEnabled) {
                                    runCatching { miniCameraPreviewView.bitmap }.getOrNull()
                                } else null
                                onRequestScanScreen(q.ifEmpty { null }, camFrame)
                                quickQuestion = ""
                            },
                            enabled = !isAnalyzing,
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(SuesaAccentWhite)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Sor",
                                tint = Color(0xFF111111),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    // Toggles: Canlı Kamera Gözü & Otomatik Ekran İzleme
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "📷 Kamera Gözü",
                            color = Color(0xFFDDDDDD),
                            fontSize = 11.sp
                        )
                        Switch(
                            checked = isLiveCameraEnabled,
                            onCheckedChange = onToggleLiveCamera,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = SuesaAccentWhite,
                                checkedTrackColor = SuesaPurple
                            ),
                            modifier = Modifier.height(24.dp)
                        )

                        Text(
                            text = "🔄 Oto İzle",
                            color = Color(0xFFDDDDDD),
                            fontSize = 11.sp
                        )
                        Switch(
                            checked = isAutoWatchEnabled,
                            onCheckedChange = onToggleAutoWatch,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = SuesaAccentWhite,
                                checkedTrackColor = SuesaPurple
                            ),
                            modifier = Modifier.height(24.dp)
                        )
                    }

                    // Collapsible Minecraft @Suesa_S Bot Control Grid (from user's prototype)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(9.dp))
                            .background(Color(0xFF241C2E))
                            .border(1.dp, Color(0xFF3D3150), RoundedCornerShape(9.dp))
                            .clickable { showMcCommands = !showMcCommands }
                            .padding(horizontal = 10.dp, vertical = 7.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "⛏️ @Suesa_Sㅤム Bot Kontrolü",
                                color = Color(0xFFE9D5FF),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = if (showMcCommands) "Gizle ▲" else "Aç ▼",
                                color = Color(0xFFAAAAAA),
                                fontSize = 10.sp
                            )
                        }
                    }

                    AnimatedVisibility(visible = showMcCommands) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                OverlayMcCmdButton("🏃 Takip Et", Modifier.weight(1f)) {
                                    onMinecraftCommand("follow")
                                }
                                OverlayMcCmdButton("🛑 Dur", Modifier.weight(1f)) {
                                    onMinecraftCommand("stop")
                                }
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                OverlayMcCmdButton("📍 Yanıma Gel", Modifier.weight(1f)) {
                                    onMinecraftCommand("come")
                                }
                                OverlayMcCmdButton("🪓 Odun Kır", Modifier.weight(1f)) {
                                    onMinecraftCommand("wood")
                                }
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                OverlayMcCmdButton("⛏️ Taş Kaz", Modifier.weight(1f)) {
                                    onMinecraftCommand("stone")
                                }
                                OverlayMcCmdButton("📊 Durum", Modifier.weight(1f)) {
                                    onMinecraftCommand("status")
                                }
                            }
                            Text(
                                text = mcBotStatus,
                                color = Color(0xFFAAAAAA),
                                fontSize = 10.sp,
                                lineHeight = 13.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun OverlayMcCmdButton(
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(9.dp))
            .background(Color(0xFF241C2E))
            .border(1.dp, Color(0xFF3D3150), RoundedCornerShape(9.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp, horizontal = 5.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = SuesaAccentWhite,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
