package com.example.ui.chat

import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Html
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.R
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.example.data.model.MerkopMode
import com.example.data.repository.ConversationRepository
import com.example.data.repository.MerkopAiRepository
import com.example.util.HtmlTranscriptExporter
import com.example.util.signOut
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch

@Composable
fun MerkopChatRoute(
    currentUserId: String
) {
    val context = LocalContext.current
    val viewModel: MerkopChatViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val databaseId = context.applicationContext.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                MerkopChatViewModel(
                    conversationRepository = ConversationRepository(db),
                    aiRepository = MerkopAiRepository(),
                    currentUserId = currentUserId
                )
            }
        }
    )

    val conversationsState by viewModel.conversationsState.collectAsStateWithLifecycle()
    val messagesState by viewModel.messagesState.collectAsStateWithLifecycle()
    val selectedConversationId by viewModel.selectedConversationId.collectAsStateWithLifecycle()
    val selectedMode by viewModel.selectedMode.collectAsStateWithLifecycle()
    val streamingText by viewModel.streamingText.collectAsStateWithLifecycle()
    val isGenerating by viewModel.isGenerating.collectAsStateWithLifecycle()
    val aiError by viewModel.aiError.collectAsStateWithLifecycle()
    val attachedImage by viewModel.attachedImage.collectAsStateWithLifecycle()

    MerkopChatScreen(
        conversationsState = conversationsState,
        messagesState = messagesState,
        selectedConversationId = selectedConversationId,
        selectedMode = selectedMode,
        streamingText = streamingText,
        isGenerating = isGenerating,
        aiError = aiError,
        attachedImage = attachedImage,
        onSelectConversation = viewModel::selectConversation,
        onStartNewConversation = viewModel::startNewConversation,
        onSelectMode = viewModel::setMode,
        onAttachImage = viewModel::setAttachedImage,
        onSendMessage = viewModel::sendMessage,
        onRenameConversation = viewModel::renameConversation,
        onDeleteConversation = viewModel::deleteConversation,
        onDismissError = viewModel::dismissAiError
    )
}

@Composable
fun MerkopChatScreen(
    conversationsState: UiState<List<Conversation>>,
    messagesState: UiState<List<ChatMessage>>,
    selectedConversationId: String?,
    selectedMode: MerkopMode,
    streamingText: String?,
    isGenerating: Boolean,
    aiError: String?,
    attachedImage: Bitmap?,
    onSelectConversation: (Conversation) -> Unit,
    onStartNewConversation: () -> Unit,
    onSelectMode: (MerkopMode) -> Unit,
    onAttachImage: (Bitmap?) -> Unit,
    onSendMessage: (String) -> Unit,
    onRenameConversation: (String, String) -> Unit,
    onDeleteConversation: (String) -> Unit,
    onDismissError: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val credentialManager = remember(context) { CredentialManager.create(context) }

    var inputText by rememberSaveable { mutableStateOf("") }
    var renameTarget by remember { mutableStateOf<Conversation?>(null) }
    var showHtmlPreview by rememberSaveable { mutableStateOf(false) }

    if (showHtmlPreview) {
        MerkopHtmlPreviewScreen(
            onBack = { showHtmlPreview = false }
        )
        return
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val bitmap = decodeUriToBitmap(context, uri)
            if (bitmap != null) {
                onAttachImage(bitmap)
            } else {
                scope.launch {
                    snackbarHostState.showSnackbar("Görsel yüklenemedi.")
                }
            }
        }
    }

    val conversations = (conversationsState as? UiState.Success)?.data.orEmpty()
    val activeConversation = remember(conversations, selectedConversationId) {
        conversations.firstOrNull { it.id == selectedConversationId }
    }
    val messages = (messagesState as? UiState.Success)?.data.orEmpty()

    if (renameTarget != null) {
        val target = renameTarget!!
        var newTitle by remember(target.id) { mutableStateOf(target.title) }
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text(stringResource(R.string.dialog_rename_title)) },
            text = {
                OutlinedTextField(
                    value = newTitle,
                    onValueChange = { newTitle = it },
                    singleLine = true,
                    label = { Text(stringResource(R.string.dialog_rename_label)) },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onRenameConversation(target.id, newTitle)
                        renameTarget = null
                    }
                ) {
                    Text(stringResource(R.string.action_save))
                }
            },
            dismissButton = {
                TextButton(onClick = { renameTarget = null }) {
                    Text(stringResource(R.string.action_cancel))
                }
            }
        )
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isExpanded = maxWidth >= 840.dp

        if (isExpanded) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier
                        .width(310.dp)
                        .fillMaxHeight()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                ) {
                    ConversationSidebarContent(
                        conversationsState = conversationsState,
                        selectedConversationId = selectedConversationId,
                        onNewChat = onStartNewConversation,
                        onSelectConversation = onSelectConversation,
                        onRenameConversation = { renameTarget = it },
                        onDeleteConversation = onDeleteConversation
                    )
                }

                Box(modifier = Modifier.weight(1f)) {
                    ChatMainPane(
                        showMenuButton = false,
                        onOpenDrawer = {},
                        snackbarHostState = snackbarHostState,
                        activeConversation = activeConversation,
                        messagesState = messagesState,
                        messages = messages,
                        selectedMode = selectedMode,
                        streamingText = streamingText,
                        isGenerating = isGenerating,
                        aiError = aiError,
                        attachedImage = attachedImage,
                        inputText = inputText,
                        onInputChange = { inputText = it },
                        onNewChat = onStartNewConversation,
                        onSelectMode = onSelectMode,
                        onPickImage = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        onClearImage = { onAttachImage(null) },
                        onSend = { prompt ->
                            onSendMessage(prompt)
                            if (prompt == inputText) {
                                inputText = ""
                            }
                        },
                        onExportHtml = {
                            val conv = activeConversation ?: Conversation(
                                title = "Merkop Sohbeti",
                                mode = selectedMode.id
                            )
                            HtmlTranscriptExporter.shareHtmlTranscript(context, conv, messages)
                        },
                        onOpenHtmlView = { showHtmlPreview = true },
                        onShareFullHtml = { HtmlTranscriptExporter.shareStandaloneAppHtml(context) },
                        onCopyMessage = { copied ->
                            scope.launch {
                                snackbarHostState.showSnackbar("Yanıt panoya kopyalandı.")
                            }
                        },
                        onSignOut = {
                            signOut(credentialManager, scope)
                        },
                        onDismissError = onDismissError
                    )
                }
            }
        } else {
            val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
            BackHandler(enabled = drawerState.isOpen) {
                scope.launch { drawerState.close() }
            }

            ModalNavigationDrawer(
                drawerState = drawerState,
                drawerContent = {
                    ModalDrawerSheet(
                        drawerContainerColor = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.widthIn(max = 310.dp)
                    ) {
                        ConversationSidebarContent(
                            conversationsState = conversationsState,
                            selectedConversationId = selectedConversationId,
                            onNewChat = {
                                onStartNewConversation()
                                scope.launch { drawerState.close() }
                            },
                            onSelectConversation = { conv ->
                                onSelectConversation(conv)
                                scope.launch { drawerState.close() }
                            },
                            onRenameConversation = { renameTarget = it },
                            onDeleteConversation = onDeleteConversation
                        )
                    }
                }
            ) {
                ChatMainPane(
                    showMenuButton = true,
                    onOpenDrawer = { scope.launch { drawerState.open() } },
                    snackbarHostState = snackbarHostState,
                    activeConversation = activeConversation,
                    messagesState = messagesState,
                    messages = messages,
                    selectedMode = selectedMode,
                    streamingText = streamingText,
                    isGenerating = isGenerating,
                    aiError = aiError,
                    attachedImage = attachedImage,
                    inputText = inputText,
                    onInputChange = { inputText = it },
                    onNewChat = onStartNewConversation,
                    onSelectMode = onSelectMode,
                    onPickImage = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    onClearImage = { onAttachImage(null) },
                    onSend = { prompt ->
                        onSendMessage(prompt)
                        if (prompt == inputText) {
                            inputText = ""
                        }
                    },
                    onExportHtml = {
                        val conv = activeConversation ?: Conversation(
                            title = "Merkop Sohbeti",
                            mode = selectedMode.id
                        )
                        HtmlTranscriptExporter.shareHtmlTranscript(context, conv, messages)
                    },
                    onOpenHtmlView = { showHtmlPreview = true },
                    onShareFullHtml = { HtmlTranscriptExporter.shareStandaloneAppHtml(context) },
                    onCopyMessage = {
                        scope.launch {
                            snackbarHostState.showSnackbar("Yanıt panoya kopyalandı.")
                        }
                    },
                    onSignOut = {
                        signOut(credentialManager, scope)
                    },
                    onDismissError = onDismissError
                )
            }
        }
    }
}

@Composable
private fun ChatMainPane(
    showMenuButton: Boolean,
    onOpenDrawer: () -> Unit,
    snackbarHostState: SnackbarHostState,
    activeConversation: Conversation?,
    messagesState: UiState<List<ChatMessage>>,
    messages: List<ChatMessage>,
    selectedMode: MerkopMode,
    streamingText: String?,
    isGenerating: Boolean,
    aiError: String?,
    attachedImage: Bitmap?,
    inputText: String,
    onInputChange: (String) -> Unit,
    onNewChat: () -> Unit,
    onSelectMode: (MerkopMode) -> Unit,
    onPickImage: () -> Unit,
    onClearImage: () -> Unit,
    onSend: (String) -> Unit,
    onExportHtml: () -> Unit,
    onOpenHtmlView: () -> Unit,
    onShareFullHtml: () -> Unit,
    onCopyMessage: (String) -> Unit,
    onSignOut: () -> Unit,
    onDismissError: () -> Unit
) {
    val listState = rememberLazyListState()
    var accountMenuOpen by remember { mutableStateOf(false) }
    val userEmail = Firebase.auth.currentUser?.email.orEmpty()

    LaunchedEffect(messages.size, streamingText) {
        val total = messages.size + if (streamingText != null) 1 else 0
        if (total > 0) {
            listState.animateScrollToItem(total - 1)
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.statusBarsPadding()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (showMenuButton) {
                            IconButton(
                                onClick = onOpenDrawer,
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("drawer_menu_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Menu,
                                    contentDescription = stringResource(R.string.cd_open_drawer),
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        Image(
                            painter = painterResource(id = R.drawable.img_merkop_avatar),
                            contentDescription = stringResource(R.string.cd_merkop_avatar),
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .border(1.5.dp, MaterialTheme.colorScheme.primary, CircleShape)
                        )

                        Spacer(modifier = Modifier.width(10.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = activeConversation?.title?.ifBlank { "Merkop" } ?: "Merkop",
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${selectedMode.label} • Merkop AI",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        IconButton(
                            onClick = onNewChat,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("new_chat_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Add,
                                contentDescription = stringResource(R.string.cd_new_chat),
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }

                        if (messages.isNotEmpty()) {
                            IconButton(
                                onClick = onExportHtml,
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("export_html_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Html,
                                    contentDescription = stringResource(R.string.cd_export_html),
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        Box {
                            IconButton(
                                onClick = { accountMenuOpen = true },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("account_menu_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.MoreVert,
                                    contentDescription = stringResource(R.string.cd_account_menu),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            DropdownMenu(
                                expanded = accountMenuOpen,
                                onDismissRequest = { accountMenuOpen = false }
                            ) {
                                if (userEmail.isNotBlank()) {
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                text = userEmail,
                                                style = MaterialTheme.typography.labelMedium,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        },
                                        onClick = { accountMenuOpen = false }
                                    )
                                    HorizontalDivider()
                                }
                                DropdownMenuItem(
                                    leadingIcon = {
                                        Icon(
                                            Icons.Filled.Html,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    },
                                    text = { Text(stringResource(R.string.action_open_html_view)) },
                                    onClick = {
                                        accountMenuOpen = false
                                        onOpenHtmlView()
                                    },
                                    modifier = Modifier.testTag("open_html_view_button")
                                )
                                DropdownMenuItem(
                                    leadingIcon = {
                                        Icon(
                                            Icons.Filled.Share,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    },
                                    text = { Text(stringResource(R.string.action_share_full_html)) },
                                    onClick = {
                                        accountMenuOpen = false
                                        onShareFullHtml()
                                    },
                                    modifier = Modifier.testTag("share_standalone_html_button")
                                )
                                if (messages.isNotEmpty()) {
                                    DropdownMenuItem(
                                        leadingIcon = {
                                            Icon(Icons.Filled.Html, contentDescription = null)
                                        },
                                        text = { Text(stringResource(R.string.action_export_html)) },
                                        onClick = {
                                            accountMenuOpen = false
                                            onExportHtml()
                                        }
                                    )
                                }
                                DropdownMenuItem(
                                    leadingIcon = {
                                        Icon(
                                            Icons.AutoMirrored.Filled.ExitToApp,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.error
                                        )
                                    },
                                    text = {
                                        Text(
                                            text = stringResource(R.string.action_sign_out),
                                            color = MaterialTheme.colorScheme.error
                                        )
                                    },
                                    onClick = {
                                        accountMenuOpen = false
                                        onSignOut()
                                    },
                                    modifier = Modifier.testTag("sign_out_button")
                                )
                            }
                        }
                    }

                    ModeSelectorRow(
                        selectedMode = selectedMode,
                        onSelectMode = onSelectMode
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                }
            }
        },
        bottomBar = {
            ChatComposerBar(
                inputText = inputText,
                onInputChange = onInputChange,
                attachedImage = attachedImage,
                isGenerating = isGenerating,
                onPickImage = onPickImage,
                onClearImage = onClearImage,
                onSend = { onSend(inputText) }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 760.dp)
            ) {
                AnimatedVisibility(visible = aiError != null) {
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = aiError.orEmpty(),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = onDismissError) {
                                Icon(
                                    imageVector = Icons.Filled.Close,
                                    contentDescription = stringResource(R.string.action_dismiss),
                                    tint = MaterialTheme.colorScheme.onErrorContainer
                                )
                            }
                        }
                    }
                }

                when (messagesState) {
                    is UiState.Loading -> {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                        }
                    }

                    is UiState.Error -> {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = messagesState.message,
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }

                    is UiState.Success -> {
                        if (messages.isEmpty() && streamingText == null) {
                            MerkopWelcomeEmptyState(
                                selectedMode = selectedMode,
                                onPromptClick = { starter -> onSend(starter) }
                            )
                        } else {
                            LazyColumn(
                                state = listState,
                                contentPadding = PaddingValues(
                                    horizontal = 16.dp,
                                    vertical = 16.dp
                                ),
                                verticalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                items(messages, key = { it.id }) { msg ->
                                    ChatMessageBubble(
                                        message = msg,
                                        onCopy = onCopyMessage
                                    )
                                }

                                if (streamingText != null) {
                                    item(key = "streaming_merkop_bubble") {
                                        StreamingMerkopBubble(text = streamingText)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ModeSelectorRow(
    selectedMode: MerkopMode,
    onSelectMode: (MerkopMode) -> Unit
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        items(MerkopMode.entries) { mode ->
            val selected = mode == selectedMode
            FilterChip(
                selected = selected,
                onClick = { onSelectMode(mode) },
                leadingIcon = {
                    Icon(
                        imageVector = modeIcon(mode),
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                },
                label = {
                    Text(
                        text = mode.label,
                        style = MaterialTheme.typography.labelMedium
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                    selectedLeadingIconColor = MaterialTheme.colorScheme.onPrimary,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    labelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    iconColor = MaterialTheme.colorScheme.primary
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = selected,
                    borderColor = MaterialTheme.colorScheme.outline,
                    selectedBorderColor = MaterialTheme.colorScheme.primary
                ),
                modifier = Modifier.testTag("mode_chip_${mode.id}")
            )
        }
    }
}

private fun modeIcon(mode: MerkopMode): ImageVector = when (mode) {
    MerkopMode.GENERAL -> Icons.Filled.AutoAwesome
    MerkopMode.CODER -> Icons.Filled.Code
    MerkopMode.WRITER -> Icons.Filled.Edit
    MerkopMode.TUTOR -> Icons.Filled.School
}

@Composable
private fun MerkopWelcomeEmptyState(
    selectedMode: MerkopMode,
    onPromptClick: (String) -> Unit
) {
    val starterPrompts = remember(selectedMode) {
        when (selectedMode) {
            MerkopMode.GENERAL -> listOf(
                "Bugün verimli geçecek 3 adımlı bir plan hazırla",
                "Yapay zeka nasıl çalışır, basitçe anlat",
                "Sağlıklı ve pratik bir akşam yemeği öner",
                "Merkop olarak neler yapabilirsin?"
            )
            MerkopMode.CODER -> listOf(
                "Kotlin'de temiz bir Coroutine örneği yaz",
                "HTML & CSS ile turuncu-beyaz modern kart tasarla",
                "Python'da JSON verisi okuma ve filtreleme göster",
                "SQL sorgularını hızlandırmanın 5 yolu"
            )
            MerkopMode.WRITER -> listOf(
                "Merkop uygulaması için etkileyici bir tanıtım yazısı yaz",
                "Toplantı erteleme için kibar ve profesyonel bir e-posta yaz",
                "Bilim kurgu temalı kısa bir hikaye başlat",
                "Sosyal medya için 5 yaratıcı içerik fikri ver"
            )
            MerkopMode.TUTOR -> listOf(
                "Kuantum bilgisayarları sıfırdan anlat",
                "İngilizce Past Perfect zamanını örneklerle öğret",
                "Bileşik faiz formülünü gerçek bir örnekle açıkla",
                "Fotosentez sürecini adım adım özetle"
            )
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            tonalElevation = 1.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_merkop_hero),
                        contentDescription = stringResource(R.string.cd_merkop_hero),
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        Color.Transparent,
                                        MaterialTheme.colorScheme.surface.copy(alpha = 0.7f)
                                    )
                                )
                            )
                    )
                    Image(
                        painter = painterResource(id = R.drawable.img_merkop_avatar),
                        contentDescription = stringResource(R.string.cd_merkop_avatar),
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 6.dp)
                            .size(56.dp)
                            .clip(CircleShape)
                            .border(2.5.dp, MaterialTheme.colorScheme.primary, CircleShape)
                    )
                }

                Column(
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = stringResource(R.string.welcome_title),
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = selectedMode.subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = stringResource(R.string.welcome_subtitle),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        Text(
            text = stringResource(R.string.welcome_quick_prompts),
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 10.dp)
        )

        starterPrompts.forEachIndexed { idx, prompt ->
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp)
                    .minimumInteractiveComponentSize()
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { onPromptClick(prompt) }
                    .testTag("starter_prompt_$idx")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.AutoAwesome,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = prompt,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
private fun ChatMessageBubble(
    message: ChatMessage,
    onCopy: (String) -> Unit
) {
    val isUser = message.role == ChatMessage.ROLE_USER
    val clipboard = LocalClipboardManager.current

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        if (isUser) {
            Surface(
                shape = RoundedCornerShape(
                    topStart = 20.dp,
                    topEnd = 20.dp,
                    bottomStart = 20.dp,
                    bottomEnd = 6.dp
                ),
                color = MaterialTheme.colorScheme.primary,
                tonalElevation = 1.dp,
                modifier = Modifier.widthIn(max = 560.dp)
            ) {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                    if (message.hasImage) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(bottom = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Image,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.9f),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = stringResource(R.string.label_image_attached),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.9f)
                            )
                        }
                    }
                    SelectionContainer {
                        Text(
                            text = message.text,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                }
            }
        } else {
            Surface(
                shape = RoundedCornerShape(
                    topStart = 20.dp,
                    topEnd = 20.dp,
                    bottomStart = 6.dp,
                    bottomEnd = 20.dp
                ),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                tonalElevation = 1.dp,
                modifier = Modifier.widthIn(max = 600.dp)
            ) {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_merkop_avatar),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(22.dp)
                                .clip(CircleShape)
                                .border(1.dp, MaterialTheme.colorScheme.primary, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.app_name),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = {
                                clipboard.setText(AnnotatedString(message.text))
                                onCopy(message.text)
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.ContentCopy,
                                contentDescription = stringResource(R.string.cd_copy_message),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    RichMessageContent(
                        rawText = message.text,
                        onCopyCode = { code ->
                            clipboard.setText(AnnotatedString(code))
                            onCopy(code)
                        }
                    )
                }
            }
        }
    }
}

private sealed interface MessageSegment {
    data class Prose(val text: String) : MessageSegment
    data class Code(val language: String, val code: String) : MessageSegment
}

private fun parseMessageSegments(rawText: String): List<MessageSegment> {
    val pattern = Regex("```([a-zA-Z0-9_+.#-]*)\\s*\\n([\\s\\S]*?)```")
    val segments = mutableListOf<MessageSegment>()
    var cursor = 0
    for (match in pattern.findAll(rawText)) {
        if (match.range.first > cursor) {
            val prose = rawText.substring(cursor, match.range.first).trim()
            if (prose.isNotEmpty()) segments.add(MessageSegment.Prose(prose))
        }
        val lang = match.groupValues[1].trim().ifEmpty { "KOD" }.uppercase()
        val code = match.groupValues[2].trimEnd()
        if (code.isNotEmpty()) segments.add(MessageSegment.Code(lang, code))
        cursor = match.range.last + 1
    }
    if (cursor < rawText.length) {
        val tail = rawText.substring(cursor).trim()
        if (tail.isNotEmpty()) segments.add(MessageSegment.Prose(tail))
    }
    if (segments.isEmpty() && rawText.isNotBlank()) {
        segments.add(MessageSegment.Prose(rawText))
    }
    return segments
}

@Composable
private fun RichMessageContent(
    rawText: String,
    onCopyCode: ((String) -> Unit)? = null
) {
    val segments = remember(rawText) { parseMessageSegments(rawText) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        segments.forEach { segment ->
            when (segment) {
                is MessageSegment.Prose -> {
                    SelectionContainer {
                        Text(
                            text = segment.text,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                is MessageSegment.Code -> {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF1F1916),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFF2D2420))
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = segment.language,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1f)
                                )
                                if (onCopyCode != null) {
                                    Text(
                                        text = "Kopyala",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color(0xFFFFD6B8),
                                        fontWeight = FontWeight.SemiBold,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .clickable { onCopyCode(segment.code) }
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                            SelectionContainer {
                                Text(
                                    text = segment.code,
                                    color = Color(0xFFFFF8F3),
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 13.sp,
                                    lineHeight = 19.sp,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState())
                                        .padding(12.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StreamingMerkopBubble(text: String) {
    val infiniteTransition = rememberInfiniteTransition(label = "merkop_pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 700),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Start
    ) {
        Surface(
            shape = RoundedCornerShape(
                topStart = 20.dp,
                topEnd = 20.dp,
                bottomStart = 6.dp,
                bottomEnd = 20.dp
            ),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary),
            modifier = Modifier.widthIn(max = 600.dp)
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .alpha(pulseAlpha)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.merkop_thinking),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                }
                if (text.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    RichMessageContent(rawText = text)
                }
            }
        }
    }
}

@Composable
private fun ChatComposerBar(
    inputText: String,
    onInputChange: (String) -> Unit,
    attachedImage: Bitmap?,
    isGenerating: Boolean,
    onPickImage: () -> Unit,
    onClearImage: () -> Unit,
    onSend: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 6.dp,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .imePadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (attachedImage != null) {
                Row(
                    modifier = Modifier
                        .widthIn(max = 760.dp)
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box {
                        Image(
                            bitmap = attachedImage.asImageBitmap(),
                            contentDescription = stringResource(R.string.cd_attached_image),
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(68.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .border(1.5.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(12.dp))
                        )
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .size(24.dp)
                                .clickable { onClearImage() }
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Close,
                                contentDescription = stringResource(R.string.action_remove_image),
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.padding(4.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = stringResource(R.string.label_image_ready),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Row(
                modifier = Modifier
                    .widthIn(max = 760.dp)
                    .fillMaxWidth(),
                verticalAlignment = Alignment.Bottom
            ) {
                IconButton(
                    onClick = onPickImage,
                    enabled = !isGenerating,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("attach_image_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Image,
                        contentDescription = stringResource(R.string.cd_attach_image),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }

                OutlinedTextField(
                    value = inputText,
                    onValueChange = onInputChange,
                    placeholder = {
                        Text(
                            text = stringResource(R.string.chat_input_placeholder),
                            style = MaterialTheme.typography.bodyLarge
                        )
                    },
                    maxLines = 5,
                    shape = RoundedCornerShape(22.dp),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(
                        onSend = {
                            if (!isGenerating && (inputText.isNotBlank() || attachedImage != null)) {
                                onSend()
                            }
                        }
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                        focusedContainerColor = MaterialTheme.colorScheme.background,
                        unfocusedContainerColor = MaterialTheme.colorScheme.background
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chat_input_field")
                )

                Spacer(modifier = Modifier.width(8.dp))

                val canSend = !isGenerating && (inputText.isNotBlank() || attachedImage != null)
                Surface(
                    shape = CircleShape,
                    color = if (canSend) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier
                        .size(50.dp)
                        .clip(CircleShape)
                        .clickable(enabled = canSend) { onSend() }
                        .testTag("send_message_button")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        if (isGenerating) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(22.dp),
                                color = MaterialTheme.colorScheme.primary,
                                strokeWidth = 2.5.dp
                            )
                        } else {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = stringResource(R.string.cd_send_message),
                                tint = if (canSend) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ConversationSidebarContent(
    conversationsState: UiState<List<Conversation>>,
    selectedConversationId: String?,
    onNewChat: () -> Unit,
    onSelectConversation: (Conversation) -> Unit,
    onRenameConversation: (Conversation) -> Unit,
    onDeleteConversation: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 16.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_merkop_avatar),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .border(1.5.dp, MaterialTheme.colorScheme.primary, CircleShape)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = stringResource(R.string.app_name),
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = stringResource(R.string.sidebar_subtitle),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Button(
            onClick = onNewChat,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("sidebar_new_chat_button")
        ) {
            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = stringResource(R.string.action_new_chat),
                style = MaterialTheme.typography.labelLarge
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = stringResource(R.string.sidebar_history_header),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        when (conversationsState) {
            is UiState.Loading -> {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            is UiState.Error -> {
                Text(
                    text = conversationsState.message,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.error
                )
            }

            is UiState.Success -> {
                val itemsList = conversationsState.data
                if (itemsList.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Outlined.ChatBubbleOutline,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                                modifier = Modifier.size(40.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = stringResource(R.string.sidebar_empty),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(itemsList, key = { it.id }) { conv ->
                            val isSelected = conv.id == selectedConversationId
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = if (isSelected) {
                                    MaterialTheme.colorScheme.primaryContainer
                                } else {
                                    MaterialTheme.colorScheme.surfaceVariant
                                },
                                border = BorderStroke(
                                    width = if (isSelected) 1.5.dp else 1.dp,
                                    color = if (isSelected) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.outlineVariant
                                    }
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .clickable { onSelectConversation(conv) }
                                    .testTag("conversation_item_${conv.id}")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = conv.title,
                                            style = MaterialTheme.typography.titleMedium,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        if (conv.lastMessagePreview.isNotBlank()) {
                                            Text(
                                                text = conv.lastMessagePreview,
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                    IconButton(
                                        onClick = { onRenameConversation(conv) },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Edit,
                                            contentDescription = stringResource(R.string.cd_rename_chat),
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                    IconButton(
                                        onClick = { onDeleteConversation(conv.id) },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.DeleteOutline,
                                            contentDescription = stringResource(R.string.cd_delete_chat),
                                            tint = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun decodeUriToBitmap(context: android.content.Context, uri: Uri): Bitmap? {
    return try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val source = ImageDecoder.createSource(context.contentResolver, uri)
            ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                decoder.isMutableRequired = false
            }
        } else {
            @Suppress("DEPRECATION")
            MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
        }
    } catch (_: Exception) {
        null
    }
}
