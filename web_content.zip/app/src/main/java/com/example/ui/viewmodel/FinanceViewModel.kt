package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.entity.AppSettingsEntity
import com.example.data.entity.LoanEntity
import com.example.data.entity.LoanRepaymentEntity
import com.example.data.entity.SalaryEntity
import com.example.data.entity.TransactionEntity
import com.example.data.entity.TransactionTypes
import com.example.data.repository.FinanceRepository
import com.example.ui.util.BanglaHelper
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class DashboardSummary(
    val todayIncome: Double = 0.0,
    val todayExpense: Double = 0.0,
    val todayDeposit: Double = 0.0,
    val todayLoan: Double = 0.0,
    val todayLoanRepaid: Double = 0.0,
    val monthIncome: Double = 0.0,
    val monthExpense: Double = 0.0,
    val monthDeposit: Double = 0.0,
    val monthLoan: Double = 0.0,
    val monthLoanRepaid: Double = 0.0,
    val monthBalance: Double = 0.0,
    val totalIncome: Double = 0.0,
    val totalExpense: Double = 0.0,
    val totalDeposit: Double = 0.0,
    val totalLoan: Double = 0.0,
    val totalLoanRepaid: Double = 0.0,
    val remainingLoan: Double = 0.0,
    val overallBalance: Double = 0.0
)

data class LenderSummary(
    val lenderName: String,
    val totalLoan: Double,
    val totalRepaid: Double,
    val remainingLoan: Double
)

class FinanceViewModel(
    application: Application,
    private val repository: FinanceRepository
) : AndroidViewModel(application) {

    val allTransactions: StateFlow<List<TransactionEntity>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allLoans: StateFlow<List<LoanEntity>> = repository.allLoans
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allRepayments: StateFlow<List<LoanRepaymentEntity>> = repository.allRepayments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allSalaries: StateFlow<List<SalaryEntity>> = repository.allSalaries
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val settings: StateFlow<AppSettingsEntity?> = repository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _userMessage = MutableSharedFlow<String>()
    val userMessage: SharedFlow<String> = _userMessage.asSharedFlow()

    // Calculated Dashboard Summary
    val dashboardSummary: StateFlow<DashboardSummary> = combine(
        allTransactions,
        allLoans,
        allRepayments
    ) { txList, loanList, repayList ->
        val today = BanglaHelper.getTodayIso()
        val currentMonthPrefix = today.substring(0, 7) // "YYYY-MM"

        // Today's calculations
        val todayIncome = txList.filter {
            it.date == today && isIncomeType(it.type)
        }.sumOf { it.amount }

        val todayExpense = txList.filter {
            it.date == today && isExpenseType(it.type)
        }.sumOf { it.amount }

        val todayDeposit = txList.filter {
            it.date == today && it.type == TransactionTypes.DEPOSIT
        }.sumOf { it.amount }

        val todayLoan = loanList.filter { it.date == today }.sumOf { it.amount }
        val todayLoanRepaid = repayList.filter { it.date == today }.sumOf { it.amount }

        // Month's calculations
        val monthIncome = txList.filter {
            it.date.startsWith(currentMonthPrefix) && isIncomeType(it.type)
        }.sumOf { it.amount }

        val monthExpense = txList.filter {
            it.date.startsWith(currentMonthPrefix) && isExpenseType(it.type)
        }.sumOf { it.amount }

        val monthDeposit = txList.filter {
            it.date.startsWith(currentMonthPrefix) && it.type == TransactionTypes.DEPOSIT
        }.sumOf { it.amount }

        val monthLoan = loanList.filter {
            it.date.startsWith(currentMonthPrefix)
        }.sumOf { it.amount }

        val monthLoanRepaid = repayList.filter {
            it.date.startsWith(currentMonthPrefix)
        }.sumOf { it.amount }

        val monthBalance = monthIncome - monthExpense

        // Total calculations
        val totalIncome = txList.filter { isIncomeType(it.type) }.sumOf { it.amount }
        val totalExpense = txList.filter { isExpenseType(it.type) }.sumOf { it.amount }
        val totalDeposit = txList.filter { it.type == TransactionTypes.DEPOSIT }.sumOf { it.amount }
        val totalLoan = loanList.sumOf { it.amount }
        val totalLoanRepaid = repayList.sumOf { it.amount }
        val remainingLoan = (totalLoan - totalLoanRepaid).coerceAtLeast(0.0)
        val overallBalance = totalIncome - totalExpense

        DashboardSummary(
            todayIncome = todayIncome,
            todayExpense = todayExpense,
            todayDeposit = todayDeposit,
            todayLoan = todayLoan,
            todayLoanRepaid = todayLoanRepaid,
            monthIncome = monthIncome,
            monthExpense = monthExpense,
            monthDeposit = monthDeposit,
            monthLoan = monthLoan,
            monthLoanRepaid = monthLoanRepaid,
            monthBalance = monthBalance,
            totalIncome = totalIncome,
            totalExpense = totalExpense,
            totalDeposit = totalDeposit,
            totalLoan = totalLoan,
            totalLoanRepaid = totalLoanRepaid,
            remainingLoan = remainingLoan,
            overallBalance = overallBalance
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardSummary())

    // Lender Summaries
    val lenderSummaries: StateFlow<List<LenderSummary>> = combine(
        allLoans,
        allRepayments
    ) { loans, repayments ->
        val lenderNames = (loans.map { it.lenderName.trim() } + repayments.map { it.lenderName.trim() })
            .filter { it.isNotBlank() }
            .distinct()
            .sorted()

        lenderNames.map { name ->
            val totalBorrowed = loans.filter { it.lenderName.trim().equals(name, ignoreCase = true) }
                .sumOf { it.amount }
            val totalRepaid = repayments.filter { it.lenderName.trim().equals(name, ignoreCase = true) }
                .sumOf { it.amount }
            val remaining = (totalBorrowed - totalRepaid).coerceAtLeast(0.0)
            LenderSummary(
                lenderName = name,
                totalLoan = totalBorrowed,
                totalRepaid = totalRepaid,
                remainingLoan = remaining
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private fun isIncomeType(type: String): Boolean {
        return type == TransactionTypes.INCOME ||
                type == TransactionTypes.POND_INCOME ||
                type == TransactionTypes.MADRASAH_SALARY_INCOME ||
                type == TransactionTypes.MOSQUE_SALARY_INCOME
    }

    private fun isExpenseType(type: String): Boolean {
        return type == TransactionTypes.EXPENSE ||
                type == TransactionTypes.POND_FEED_EXPENSE
    }

    fun showToast(msg: String) {
        viewModelScope.launch {
            _userMessage.emit(msg)
        }
    }

    // --- Transactions Actions ---
    fun addTransaction(
        type: String,
        categoryLabel: String,
        amount: Double,
        date: String,
        description: String,
        onSuccess: (() -> Unit)? = null
    ) {
        viewModelScope.launch {
            val tx = TransactionEntity(
                type = type,
                categoryLabel = categoryLabel,
                amount = amount,
                date = date,
                description = description.trim()
            )
            repository.insertTransaction(tx)
            showToast("সফলভাবে সংরক্ষণ করা হয়েছে")
            onSuccess?.invoke()
        }
    }

    fun updateTransaction(transaction: TransactionEntity, onSuccess: (() -> Unit)? = null) {
        viewModelScope.launch {
            repository.updateTransaction(transaction)
            showToast("হিসাব আপডেট করা হয়েছে")
            onSuccess?.invoke()
        }
    }

    fun deleteTransaction(id: Long) {
        viewModelScope.launch {
            repository.deleteTransaction(id)
            showToast("হিসাব মুছে ফেলা হয়েছে")
        }
    }

    // --- Loan Actions ---
    fun addLoan(
        lenderName: String,
        amount: Double,
        date: String,
        description: String,
        onSuccess: (() -> Unit)? = null
    ) {
        viewModelScope.launch {
            val loan = LoanEntity(
                lenderName = lenderName.trim(),
                amount = amount,
                date = date,
                description = description.trim()
            )
            repository.insertLoan(loan)
            showToast("ঋণের হিসাব সংরক্ষণ করা হয়েছে")
            onSuccess?.invoke()
        }
    }

    fun updateLoan(loan: LoanEntity, onSuccess: (() -> Unit)? = null) {
        viewModelScope.launch {
            repository.updateLoan(loan)
            showToast("ঋণের হিসাব আপডেট করা হয়েছে")
            onSuccess?.invoke()
        }
    }

    fun deleteLoan(id: Long) {
        viewModelScope.launch {
            repository.deleteLoan(id)
            showToast("ঋণ মুছে ফেলা হয়েছে")
        }
    }

    // --- Loan Repayment Actions ---
    fun addRepayment(
        lenderName: String,
        amount: Double,
        date: String,
        description: String,
        onSuccess: (() -> Unit)? = null
    ) {
        viewModelScope.launch {
            val rep = LoanRepaymentEntity(
                lenderName = lenderName.trim(),
                amount = amount,
                date = date,
                description = description.trim()
            )
            repository.insertRepayment(rep)
            showToast("ঋণ পরিশোধ সংরক্ষণ করা হয়েছে")
            onSuccess?.invoke()
        }
    }

    fun updateRepayment(repayment: LoanRepaymentEntity, onSuccess: (() -> Unit)? = null) {
        viewModelScope.launch {
            repository.updateRepayment(repayment)
            showToast("পরিশোধ তথ্য আপডেট করা হয়েছে")
            onSuccess?.invoke()
        }
    }

    fun deleteRepayment(id: Long) {
        viewModelScope.launch {
            repository.deleteRepayment(id)
            showToast("পরিশোধ মুছে ফেলা হয়েছে")
        }
    }

    // --- Salary Actions ---
    fun addOrUpdateSalary(
        institution: String,
        year: Int,
        monthIndex: Int,
        monthName: String,
        amount: Double,
        date: String,
        description: String,
        isPaid: Boolean,
        allowOverwrite: Boolean = false,
        onDuplicateFound: ((SalaryEntity) -> Unit)? = null,
        onSuccess: (() -> Unit)? = null
    ) {
        viewModelScope.launch {
            val existing = repository.getSalaryByMonth(institution, year, monthIndex)
            if (existing != null && !allowOverwrite) {
                onDuplicateFound?.invoke(existing)
                return@launch
            }

            val salary = SalaryEntity(
                id = existing?.id ?: 0,
                institution = institution,
                year = year,
                monthIndex = monthIndex,
                monthName = monthName,
                amount = amount,
                date = date,
                description = description.trim(),
                isPaid = isPaid
            )

            if (existing != null) {
                repository.updateSalary(salary)
                showToast("$monthName মাসের বেতন আপডেট করা হয়েছে")
            } else {
                repository.insertSalary(salary)
                showToast("$monthName মাসের বেতন যোগ করা হয়েছে")
            }

            // Also record in transactions if paid as income
            if (isPaid && amount > 0) {
                val categoryType = if (institution == "মাদরাসা") {
                    TransactionTypes.MADRASAH_SALARY_INCOME
                } else {
                    TransactionTypes.MOSQUE_SALARY_INCOME
                }
                repository.insertTransaction(
                    TransactionEntity(
                        type = categoryType,
                        categoryLabel = "$institution বেতন ($monthName)",
                        amount = amount,
                        date = date,
                        description = description.ifBlank { "$institution বেতন ($monthName)" }
                    )
                )
            }

            onSuccess?.invoke()
        }
    }

    fun deleteSalary(id: Long) {
        viewModelScope.launch {
            repository.deleteSalary(id)
            showToast("বেতনের হিসাব মুছে ফেলা হয়েছে")
        }
    }

    // --- Profile & Settings Actions ---
    fun updateProfilePhoto(uriString: String?) {
        viewModelScope.launch {
            val current = settings.value ?: AppSettingsEntity()
            repository.saveSettings(current.copy(profileImageUri = uriString))
            showToast("প্রোফাইল ছবি সফলভাবে আপডেট হয়েছে")
        }
    }

    fun clearAllData(onSuccess: (() -> Unit)? = null) {
        viewModelScope.launch {
            repository.clearAllData()
            showToast("সমস্ত ডাটা সফলভাবে মুছে ফেলা হয়েছে")
            onSuccess?.invoke()
        }
    }

    suspend fun getBackupData(): String {
        return repository.exportBackupJson()
    }

    suspend fun restoreData(jsonString: String): Boolean {
        val success = repository.restoreBackupJson(jsonString)
        if (success) {
            showToast("ডাটা সফলভাবে রিস্টোর করা হয়েছে")
        } else {
            showToast("রিস্টোর ব্যর্থ হয়েছে! সঠিক ব্যাকআপ ফাইল নির্বাচন করুন")
        }
        return success
    }

    companion object {
        fun provideFactory(application: Application): ViewModelProvider.Factory {
            return object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    val db = AppDatabase.getDatabase(application)
                    val repo = FinanceRepository(db.financeDao())
                    return FinanceViewModel(application, repo) as T
                }
            }
        }
    }
}
