package com.example.ui.components

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.DojoTab
import com.example.ui.theme.ChakraCyan
import com.example.ui.theme.NarutoOrange

data class NavigationItem(
  val tab: DojoTab,
  val icon: ImageVector,
  val testTag: String
)

@Composable
fun DojoBottomNavigation(
  currentTab: DojoTab,
  onTabSelected: (DojoTab) -> Unit,
  modifier: Modifier = Modifier
) {
  val items = listOf(
    NavigationItem(DojoTab.SYLLABUS, Icons.AutoMirrored.Filled.MenuBook, "nav_syllabus"),
    NavigationItem(DojoTab.TIMER, Icons.Default.HourglassTop, "nav_timer"),
    NavigationItem(DojoTab.QUIZ, Icons.Default.Quiz, "nav_quiz"),
    NavigationItem(DojoTab.SENSEI_CHAT, Icons.Default.Chat, "nav_chat"),
    NavigationItem(DojoTab.STATS, Icons.Default.MilitaryTech, "nav_stats")
  )

  NavigationBar(
    modifier = modifier
      .fillMaxWidth()
      .navigationBarsPadding(),
    containerColor = MaterialTheme.colorScheme.surface,
    tonalElevation = 8.dp
  ) {
    items.forEach { item ->
      val isSelected = currentTab == item.tab
      NavigationBarItem(
        selected = isSelected,
        onClick = { onTabSelected(item.tab) },
        icon = {
          Icon(
            imageVector = item.icon,
            contentDescription = item.tab.label
          )
        },
        label = {
          Text(
            text = item.tab.label,
            style = MaterialTheme.typography.labelSmall.copy(
              fontSize = 11.sp,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
            ),
            maxLines = 1
          )
        },
        colors = NavigationBarItemDefaults.colors(
          selectedIconColor = MaterialTheme.colorScheme.onPrimary,
          selectedTextColor = NarutoOrange,
          indicatorColor = NarutoOrange,
          unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
          unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
        ),
        modifier = Modifier.testTag(item.testTag)
      )
    }
  }
}
