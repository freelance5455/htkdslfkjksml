package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import android.widget.VideoView
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.models.MediaType
import com.example.ui.theme.HazimCyan
import com.example.ui.theme.HazimDarkBackground
import com.example.ui.theme.HazimDarkBorder
import com.example.ui.theme.HazimDarkSurface
import com.example.ui.theme.HazimDarkSurfaceVariant
import com.example.ui.theme.HazimPurple
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import com.example.ui.theme.TextTertiaryDark
import com.example.viewmodel.HazimAiViewModel

@Composable
fun ImageToVideoScreen(
    viewModel: HazimAiViewModel,
    onOpenDrawer: () -> Unit
) {
    val context = LocalContext.current
    val itvSourceImage by viewModel.itvSourceImage.collectAsState()
    val itvMotionPrompt by viewModel.itvMotionPrompt.collectAsState()
    val selectedMotion by viewModel.selectedMotion.collectAsState()
    val videoDuration by viewModel.videoDuration.collectAsState()
    val isGeneratingVideo by viewModel.isGeneratingVideo.collectAsState()
    val generationStage by viewModel.generationStage.collectAsState()
    val lastGeneratedVideo by viewModel.lastGeneratedVideo.collectAsState()
    val isVideoPlaying by viewModel.isVideoPlaying.collectAsState()
    val videoProgress by viewModel.videoProgress.collectAsState()
    val galleryItems by viewModel.galleryItems.collectAsState()

    val motionStyles = listOf(
        "Cinematic Zoom",
        "Dynamic Pan",
        "3D Orbit & Parallax",
        "Slow Drone",
        "Pulse & Glow"
    )

    val imageCandidates = galleryItems.filter { it.type == MediaType.IMAGE }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(HazimDarkBackground)
            .imePadding()
            .navigationBarsPadding()
    ) {
        // Top Bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = HazimDarkBackground
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onOpenDrawer,
                    modifier = Modifier.testTag("itv_open_drawer_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Menu,
                        contentDescription = "Menu",
                        tint = TextPrimaryDark
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Image to Video",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(HazimPurple.copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "ITV 60FPS",
                                color = HazimPurple,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Text(
                        text = "Turn Photos into Motion Cinematics",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondaryDark,
                        fontSize = 11.sp
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Source Image Selector
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    color = HazimDarkSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, HazimDarkBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "1. Select Source Image",
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark,
                            fontSize = 13.sp
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        if (imageCandidates.isNotEmpty()) {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(imageCandidates) { item ->
                                    val isSelected = itvSourceImage?.id == item.id
                                    Box(
                                        modifier = Modifier
                                            .size(76.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .border(
                                                2.dp,
                                                if (isSelected) HazimCyan else Color.Transparent,
                                                RoundedCornerShape(12.dp)
                                            )
                                            .clickable { viewModel.setItvSourceImage(item) }
                                    ) {
                                        AsyncImage(
                                            model = item.mediaUrl,
                                            contentDescription = item.title,
                                            modifier = Modifier.fillMaxSize(),
                                            contentScale = ContentScale.Crop
                                        )
                                    }
                                }
                            }
                        } else {
                            Text(
                                text = "Generate an image in TTI first or select one from sample gallery.",
                                color = TextSecondaryDark,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            // Motion Style & Camera Trajectory
            item {
                Column {
                    Text(
                        text = "2. Camera Motion Style",
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryDark,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(motionStyles) { motion ->
                            val isSelected = selectedMotion == motion
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .border(
                                        1.dp,
                                        if (isSelected) HazimPurple else HazimDarkBorder,
                                        RoundedCornerShape(12.dp)
                                    )
                                    .clickable { viewModel.setSelectedMotion(motion) },
                                color = if (isSelected) HazimPurple.copy(alpha = 0.2f) else HazimDarkSurface
                            ) {
                                Text(
                                    text = motion,
                                    color = if (isSelected) HazimPurple else TextSecondaryDark,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Motion Prompt & Duration
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    color = HazimDarkSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, HazimDarkBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "3. Motion Dynamics Description",
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = itvMotionPrompt,
                            onValueChange = { viewModel.setItvMotionPrompt(it) },
                            placeholder = {
                                Text(
                                    text = "e.g., Water waves rippling gently, dramatic clouds rolling across mountains...",
                                    color = TextTertiaryDark,
                                    fontSize = 12.sp
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("itv_motion_prompt_input"),
                            shape = RoundedCornerShape(10.dp),
                            maxLines = 2
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Duration:",
                                fontSize = 12.sp,
                                color = TextSecondaryDark
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(3, 5, 10).forEach { dur ->
                                    val isSelected = videoDuration == dur
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (isSelected) HazimPurple else HazimDarkSurfaceVariant)
                                            .clickable { viewModel.setVideoDuration(dur) }
                                            .padding(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            text = "${dur}s",
                                            color = if (isSelected) Color.White else TextSecondaryDark,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Generate Button
            item {
                Button(
                    onClick = { viewModel.generateVideo() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("itv_generate_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = HazimPurple,
                        contentColor = Color.White
                    ),
                    enabled = !isGeneratingVideo && itvSourceImage != null
                ) {
                    if (isGeneratingVideo) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = Color.White,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = generationStage.ifBlank { "Rendering Video Frames..." },
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Movie,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Synthesize Video (ITV)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
            }

            // Interactive Video Player Studio
            item {
                val activeVideo = lastGeneratedVideo ?: itvSourceImage
                if (activeVideo != null) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        color = HazimDarkSurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, HazimDarkBorder)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Interactive Motion Player",
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimaryDark,
                                    fontSize = 14.sp
                                )

                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(HazimPurple.copy(alpha = 0.2f))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = selectedMotion,
                                        color = HazimPurple,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Motion Canvas View: dynamically transforms based on videoProgress and selectedMotion
                            val animatedScale by animateFloatAsState(
                                targetValue = when (selectedMotion) {
                                    "Cinematic Zoom" -> 1.0f + (videoProgress * 0.25f)
                                    "Slow Drone" -> 1.15f - (videoProgress * 0.15f)
                                    "Pulse & Glow" -> 1.0f + (kotlin.math.sin(videoProgress * 3.14159f) * 0.12f).toFloat()
                                    else -> 1.05f
                                },
                                label = "scale"
                            )

                            val animatedTranslationX by animateFloatAsState(
                                targetValue = when (selectedMotion) {
                                    "Dynamic Pan" -> (videoProgress - 0.5f) * 60f
                                    "3D Orbit & Parallax" -> kotlin.math.sin(videoProgress * 6.28f).toFloat() * 30f
                                    else -> 0f
                                },
                                label = "transX"
                            )

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(16f / 9f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.Black),
                                contentAlignment = Alignment.Center
                            ) {
                                if (activeVideo.mediaUrl.endsWith(".mp4")) {
                                    AndroidView(
                                        factory = { ctx ->
                                            VideoView(ctx).apply {
                                                setVideoURI(Uri.parse(activeVideo.mediaUrl))
                                                setOnPreparedListener { mp ->
                                                    mp.isLooping = true
                                                    if (isVideoPlaying) start()
                                                }
                                            }
                                        },
                                        update = { videoView ->
                                            if (isVideoPlaying) {
                                                if (!videoView.isPlaying) videoView.start()
                                            } else {
                                                if (videoView.isPlaying) videoView.pause()
                                            }
                                        },
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else {
                                    AsyncImage(
                                        model = activeVideo.mediaUrl,
                                        contentDescription = activeVideo.title,
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .graphicsLayer {
                                                scaleX = animatedScale
                                                scaleY = animatedScale
                                                translationX = animatedTranslationX
                                            },
                                        contentScale = ContentScale.Crop
                                    )
                                }

                                // Overlay glow / cinematic light sweep
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(
                                            Brush.horizontalGradient(
                                                colors = listOf(
                                                    Color.Transparent,
                                                    HazimCyan.copy(alpha = (0.1f * videoProgress).coerceIn(0f, 0.25f)),
                                                    Color.Transparent
                                                )
                                            )
                                        )
                                )

                                // Center play icon overlay if paused
                                if (!isVideoPlaying) {
                                    Box(
                                        modifier = Modifier
                                            .size(54.dp)
                                            .clip(CircleShape)
                                            .background(Color.Black.copy(alpha = 0.65f))
                                            .clickable { viewModel.toggleVideoPlayback() },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.PlayArrow,
                                            contentDescription = "Play",
                                            tint = Color.White,
                                            modifier = Modifier.size(32.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Scrubber timeline
                            Slider(
                                value = videoProgress,
                                onValueChange = { viewModel.setVideoScrubberProgress(it) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("itv_timeline_scrubber"),
                                colors = SliderDefaults.colors(
                                    thumbColor = HazimPurple,
                                    activeTrackColor = HazimPurple,
                                    inactiveTrackColor = HazimDarkBorder
                                )
                            )

                            // Controls Row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = { viewModel.toggleVideoPlayback() },
                                        modifier = Modifier
                                            .size(36.dp)
                                            .testTag("itv_play_pause_button")
                                    ) {
                                        Icon(
                                            imageVector = if (isVideoPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                            contentDescription = if (isVideoPlaying) "Pause" else "Play",
                                            tint = HazimPurple
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(6.dp))

                                    val currentSec = (videoProgress * videoDuration).toInt()
                                    Text(
                                        text = "00:0$currentSec / 00:0$videoDuration",
                                        fontSize = 12.sp,
                                        color = TextSecondaryDark
                                    )
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    IconButton(
                                        onClick = {
                                            val shareIntent = Intent().apply {
                                                action = Intent.ACTION_SEND
                                                putExtra(
                                                    Intent.EXTRA_TEXT,
                                                    "Check out this AI video generated with HAZIM AI (ITV)!\nMotion: $selectedMotion\n${activeVideo.mediaUrl}"
                                                )
                                                type = "text/plain"
                                            }
                                            context.startActivity(
                                                Intent.createChooser(shareIntent, "Share Video")
                                            )
                                        },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Share,
                                            contentDescription = "Share Video",
                                            tint = TextSecondaryDark,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(20.dp)) }
        }
    }
}
