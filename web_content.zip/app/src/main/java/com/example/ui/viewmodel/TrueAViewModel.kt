package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.firebase.AdminRepository
import com.example.data.firebase.AuctionRepository
import com.example.data.firebase.AuthAndWalletRepository
import com.example.data.firebase.extractFirestoreMessage
import com.example.data.model.AdInquiry
import com.example.data.model.Auction
import com.example.data.model.BusinessAd
import com.example.data.model.UiState
import com.example.data.model.UserBidRecord
import com.example.data.model.UserProfile
import com.example.data.model.Wallet
import com.example.data.model.WalletTransaction
import com.example.data.model.WithdrawalRequest
import com.example.util.ADMIN_BOOTSTRAP_EMAIL
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class TrueAViewModel(
    private val authWalletRepo: AuthAndWalletRepository,
    private val auctionRepo: AuctionRepository,
    private val adminRepo: AdminRepository,
    val currentUserId: String
) : ViewModel() {

    private val _nowMillis = MutableStateFlow(System.currentTimeMillis())
    val nowMillis: StateFlow<Long> = _nowMillis.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    val userProfileState: StateFlow<UiState<UserProfile?>> =
        authWalletRepo.observeUserProfile(currentUserId)
            .toUiState("Failed to load profile")

    val walletState: StateFlow<UiState<Wallet?>> =
        authWalletRepo.observeWallet(currentUserId)
            .toUiState("Failed to load wallet")

    val auctionsState: StateFlow<UiState<List<Auction>>> =
        auctionRepo.observeAllAuctions()
            .toUiState("Failed to load live auctions")

    val myBidRecordsState: StateFlow<UiState<List<UserBidRecord>>> =
        auctionRepo.observeUserBidRecords(currentUserId)
            .toUiState("Failed to load bid history")

    val activeBusinessAdsState: StateFlow<UiState<List<BusinessAd>>> =
        auctionRepo.observeActiveBusinessAds()
            .toUiState("Failed to load partner ads")

    val walletTransactionsState: StateFlow<UiState<List<WalletTransaction>>> =
        authWalletRepo.observeWalletTransactions(currentUserId)
            .toUiState("Failed to load transactions")

    val myWithdrawalsState: StateFlow<UiState<List<WithdrawalRequest>>> =
        authWalletRepo.observeMyWithdrawals(currentUserId)
            .toUiState("Failed to load withdrawals")

    val myAdInquiriesState: StateFlow<UiState<List<AdInquiry>>> =
        authWalletRepo.observeMyAdInquiries(currentUserId)
            .toUiState("Failed to load ad inquiries")

    // Admin status: strictly derived from verified bootstrap email or Firestore role == "ADMIN"
    val isAdminState: StateFlow<Boolean> = userProfileState
        .map { state ->
            val firebaseUser = Firebase.auth.currentUser
            val isBootstrapAdmin = firebaseUser?.email == ADMIN_BOOTSTRAP_EMAIL && firebaseUser.isEmailVerified
            val profileRoleAdmin = (state as? UiState.Success)?.data?.role == "ADMIN"
            isBootstrapAdmin || profileRoleAdmin
        }
        .distinctUntilChanged()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS), false)

    // Admin-only collections: only attached when isAdminState is true!
    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val allUsersAdmin: StateFlow<UiState<List<UserProfile>>> = isAdminState
        .flatMapLatest { admin ->
            if (!admin) flowOf<UiState<List<UserProfile>>>(UiState.Success(emptyList()))
            else adminRepo.observeAllUsers().map<List<UserProfile>, UiState<List<UserProfile>>> { UiState.Success(it) }
                .catch { emit(unwrapError(it, "Failed to load users")) }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS), UiState.Loading)

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val allWithdrawalsAdmin: StateFlow<UiState<List<WithdrawalRequest>>> = isAdminState
        .flatMapLatest { admin ->
            if (!admin) flowOf<UiState<List<WithdrawalRequest>>>(UiState.Success(emptyList()))
            else adminRepo.observeAllWithdrawals().map<List<WithdrawalRequest>, UiState<List<WithdrawalRequest>>> { UiState.Success(it) }
                .catch { emit(unwrapError(it, "Failed to load withdrawals")) }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS), UiState.Loading)

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val allBusinessAdsAdmin: StateFlow<UiState<List<BusinessAd>>> = isAdminState
        .flatMapLatest { admin ->
            if (!admin) flowOf<UiState<List<BusinessAd>>>(UiState.Success(emptyList()))
            else adminRepo.observeAllBusinessAds().map<List<BusinessAd>, UiState<List<BusinessAd>>> { UiState.Success(it) }
                .catch { emit(unwrapError(it, "Failed to load business ads")) }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS), UiState.Loading)

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val allAdInquiriesAdmin: StateFlow<UiState<List<AdInquiry>>> = isAdminState
        .flatMapLatest { admin ->
            if (!admin) flowOf<UiState<List<AdInquiry>>>(UiState.Success(emptyList()))
            else adminRepo.observeAllAdInquiries().map<List<AdInquiry>, UiState<List<AdInquiry>>> { UiState.Success(it) }
                .catch { emit(unwrapError(it, "Failed to load ad inquiries")) }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS), UiState.Loading)

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val allTransactionsAdmin: StateFlow<UiState<List<WalletTransaction>>> = isAdminState
        .flatMapLatest { admin ->
            if (!admin) flowOf<UiState<List<WalletTransaction>>>(UiState.Success(emptyList()))
            else adminRepo.observeAllTransactions().map<List<WalletTransaction>, UiState<List<WalletTransaction>>> { UiState.Success(it) }
                .catch { emit(unwrapError(it, "Failed to load transactions")) }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS), UiState.Loading)

    init {
        initializeUserAccount()
        viewModelScope.launch {
            while (true) {
                delay(1000L)
                _nowMillis.value = System.currentTimeMillis()
            }
        }
    }

    private fun initializeUserAccount() {
        val fbUser = Firebase.auth.currentUser ?: return
        viewModelScope.launch {
            val result = authWalletRepo.ensureUserAndWalletInitialized(
                userId = currentUserId,
                displayName = fbUser.displayName ?: "True A Member",
                email = fbUser.email ?: "$currentUserId@truea.app"
            )
            result.onFailure { err ->
                _statusBanner.value = extractFirestoreMessage(err, "Could not initialize bidder profile.")
            }
        }
    }

    fun clearStatusBanner() {
        _statusBanner.value = null
    }

    fun updateProfile(
        displayName: String,
        phone: String,
        bankName: String,
        accountNumber: String,
        accountName: String
    ) {
        runAction("Profile and bank payout details saved.") {
            authWalletRepo.updateUserProfile(
                userId = currentUserId,
                displayName = displayName,
                phone = phone,
                bankName = bankName,
                accountNumber = accountNumber,
                accountName = accountName
            )
        }
    }

    fun depositFunds(amount: Long, methodLabel: String) {
        runAction("₦$amount added to your True A escrow wallet.") {
            authWalletRepo.depositFunds(currentUserId, amount, methodLabel)
        }
    }

    fun requestWithdrawal(
        profile: UserProfile,
        amount: Long,
        bankName: String,
        accountNumber: String,
        accountName: String
    ) {
        runAction("Withdrawal request submitted for verification.") {
            authWalletRepo.requestWithdrawal(
                userId = currentUserId,
                profile = profile,
                amount = amount,
                bankName = bankName,
                accountNumber = accountNumber,
                accountName = accountName
            )
        }
    }

    fun submitAdInquiry(businessName: String, proposedBudget: Long, message: String) {
        runAction("Advertising inquiry sent to True A Admin.") {
            authWalletRepo.submitAdInquiry(currentUserId, businessName, proposedBudget, message)
        }
    }

    fun createAuction(
        profile: UserProfile,
        title: String,
        description: String,
        category: String,
        imageItems: List<String>,
        startingBid: Long,
        minIncrement: Long,
        durationHours: Long,
        featureListing: Boolean,
        onCreated: (String) -> Unit = {}
    ) {
        viewModelScope.launch {
            _isBusy.value = true
            val result = auctionRepo.createAuction(
                profile = profile,
                title = title,
                description = description,
                category = category,
                imageItems = imageItems,
                startingBid = startingBid,
                minIncrement = minIncrement,
                durationHours = durationHours,
                featureListing = featureListing
            )
            _isBusy.value = false
            result.onSuccess { id ->
                _statusBanner.value = if (featureListing) {
                    "Featured Auction published (₦2,000 fee applied)."
                } else {
                    "Auction lot published live!"
                }
                onCreated(id)
            }.onFailure { err ->
                _statusBanner.value = extractFirestoreMessage(err, "Failed to publish auction.")
            }
        }
    }

    fun upgradeAuctionToFeatured(auctionId: String, title: String) {
        runAction("Auction upgraded to Featured (₦2,000)!") {
            auctionRepo.upgradeAuctionToFeatured(currentUserId, auctionId, title)
        }
    }

    fun cancelAuctionBeforeBids(auctionId: String) {
        runAction("Auction listing cancelled.") {
            auctionRepo.cancelAuctionBeforeBids(currentUserId, auctionId)
        }
    }

    // --- ADMIN ACTIONS ---
    fun adminUpdateAuctionStatus(auctionId: String, newStatus: String) {
        runAction("Auction status updated to $newStatus.") {
            adminRepo.updateAuctionStatus(auctionId, newStatus)
        }
    }

    fun adminToggleAuctionFeatured(auctionId: String, featured: Boolean) {
        runAction(if (featured) "Marked as Featured." else "Removed from Featured.") {
            adminRepo.toggleAuctionFeatured(auctionId, featured)
        }
    }

    fun adminDeleteAuction(auctionId: String) {
        runAction("Auction lot removed.") {
            adminRepo.deleteAuction(auctionId)
        }
    }

    fun adminProcessWithdrawal(withdrawalId: String, approve: Boolean, adminNote: String) {
        runAction(if (approve) "Withdrawal approved & disbursed." else "Withdrawal declined & refunded.") {
            adminRepo.processWithdrawal(withdrawalId, approve, adminNote)
        }
    }

    fun adminToggleUserStatus(userId: String, newStatus: String) {
        runAction("User status updated to $newStatus.") {
            adminRepo.toggleUserStatus(userId, newStatus)
        }
    }

    fun adminSaveBusinessAd(
        adId: String?,
        businessName: String,
        tagline: String,
        ctaLabel: String,
        category: String,
        negotiatedFee: Long,
        status: String
    ) {
        runAction("Business ad placement saved.") {
            adminRepo.saveBusinessAd(adId, businessName, tagline, ctaLabel, category, negotiatedFee, status)
        }
    }

    fun adminDeleteBusinessAd(adId: String) {
        runAction("Business ad deleted.") {
            adminRepo.deleteBusinessAd(adId)
        }
    }

    fun adminUpdateAdInquiryStatus(inquiryId: String, status: String, adminNote: String) {
        runAction("Ad inquiry updated to $status.") {
            adminRepo.updateAdInquiryStatus(inquiryId, status, adminNote)
        }
    }

    fun adminSeedShowcase() {
        runAction("Showcase auctions & partner ad seeded!") {
            adminRepo.seedShowcaseMarketplace()
        }
    }

    private fun runAction(successMsg: String, block: suspend () -> Result<Unit>) {
        viewModelScope.launch {
            _isBusy.value = true
            val res = block()
            _isBusy.value = false
            res.onSuccess {
                _statusBanner.value = successMsg
            }.onFailure { err ->
                _statusBanner.value = extractFirestoreMessage(err, "Operation failed.")
            }
        }
    }

    private fun <T> Flow<T>.toUiState(fallbackError: String): StateFlow<UiState<T>> =
        map<T, UiState<T>> { UiState.Success(it) }
            .catch { error -> emit(unwrapError(error, fallbackError)) }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Loading
            )

    private fun <T> unwrapError(error: Throwable, fallback: String): UiState<T> {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val rootError = firestoreError ?: error
        Log.w(TAG, fallback, rootError)
        return UiState.Error(extractFirestoreMessage(rootError, fallback))
    }

    private companion object {
        const val TAG = "TrueAViewModel"
        const val STOP_TIMEOUT_MILLIS = 5000L
    }
}
