package com.example.ui.components

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Cameraswitch
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Checkroom
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Straighten
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import coil.compose.AsyncImage
import com.example.data.model.FashionProduct
import com.example.data.model.UserProfile
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Computed real-time garment sizing and body-mapping metrics derived from the user's
 * saved body measurements (`heightCm`, `weightKg`, `preferredTopSize`, `preferredBottomSize`, `bodyFitPreference`)
 * and the currently selected clothing item's size.
 */
data class RealTimeArSizingMetrics(
    val heightCm: Int,
    val weightKg: Int,
    val recommendedSize: String,
    val activeSize: String,
    val bodyFitPreference: String,
    val estimatedShoulderCm: Float,
    val estimatedChestCm: Float,
    val estimatedTorsoLengthCm: Float,
    val garmentChestCm: Float,
    val shoulderEaseDeltaCm: Float,
    val horizontalWidthScale: Float,
    val verticalLengthScale: Float,
    val fitMatchPercent: Int,
    val fitVerdictTitle: String,
    val fitVerdictDetail: String,
    val isOptimalFit: Boolean
)

fun calculateRealTimeArSizingMetrics(
    userProfile: UserProfile?,
    selectedSize: String,
    productCategory: String
): RealTimeArSizingMetrics {
    val heightCm = (userProfile?.heightCm?.toInt() ?: 172).coerceIn(120, 230)
    val weightKg = (userProfile?.weightKg?.toInt() ?: 68).coerceIn(35, 200)
    val fitPref = userProfile?.bodyFitPreference?.ifBlank { "Tailored Fit" } ?: "Tailored Fit"

    val sizeOrder = listOf("XS", "S", "M", "L", "XL", "XXL")
    val heightM = heightCm / 100.0f
    val bmi = weightKg / (heightM * heightM)

    val computedRecSize = when {
        bmi < 18.5f && heightCm < 168 -> "XS"
        bmi < 20.5f && heightCm < 174 -> "S"
        bmi < 23.8f && heightCm < 182 -> "M"
        bmi < 26.8f && heightCm < 188 -> "L"
        bmi < 30.0f -> "XL"
        else -> "XXL"
    }
    val recommendedSize = userProfile?.preferredTopSize?.takeIf { it in sizeOrder } ?: computedRecSize
    val normalizedSelectedSize = selectedSize.uppercase().let {
        if (it in sizeOrder) it else recommendedSize
    }

    val recIndex = sizeOrder.indexOf(recommendedSize).coerceAtLeast(0)
    val selIndex = sizeOrder.indexOf(normalizedSelectedSize).coerceAtLeast(0)
    val sizeStepDiff = selIndex - recIndex

    // Biometric anthropometric estimates from height & weight
    val estimatedShoulderCm = (heightCm * 0.245f + (weightKg - 65) * 0.11f).coerceIn(36f, 56f)
    val estimatedChestCm = (82f + (weightKg - 55) * 0.52f + (heightCm - 165) * 0.12f).coerceIn(78f, 132f)
    val estimatedTorsoLengthCm = (heightCm * 0.34f).coerceIn(48f, 78f)

    // Standard garment chest width per size (cm)
    val garmentChestCm = when (normalizedSelectedSize) {
        "XS" -> 88f
        "S" -> 94f
        "M" -> 100f
        "L" -> 106f
        "XL" -> 114f
        "XXL" -> 122f
        else -> 100f
    }

    val fitAllowanceModifier = when (fitPref) {
        "Slim Fit" -> -0.04f
        "Tailored Fit" -> 0.0f
        "Regular Fit" -> 0.04f
        "Relaxed / Oversized" -> 0.09f
        else -> 0.0f
    }

    // Calculate visual width & length scale factors so the clothing overlay visibly adapts to body measurements and selected size
    val baseBodyWidthScale = ((weightKg - 68f) / 140f).coerceIn(-0.14f, 0.22f)
    val sizeWidthDelta = sizeStepDiff * 0.075f
    val horizontalWidthScale = (1.0f + baseBodyWidthScale + sizeWidthDelta + fitAllowanceModifier)
        .coerceIn(0.74f, 1.38f)

    val baseTorsoHeightScale = ((heightCm - 172f) / 160f).coerceIn(-0.14f, 0.20f)
    val categoryLengthMultiplier = if (
        productCategory.contains("Ethnic", ignoreCase = true) ||
        productCategory.contains("Kurt", ignoreCase = true) ||
        productCategory.contains("Dress", ignoreCase = true)
    ) {
        1.14f
    } else {
        1.0f
    }
    val verticalLengthScale = ((1.0f + baseTorsoHeightScale + (sizeStepDiff * 0.035f)) * categoryLengthMultiplier)
        .coerceIn(0.78f, 1.42f)

    val shoulderEaseDeltaCm = ((garmentChestCm - estimatedChestCm) * 0.22f) + (sizeStepDiff * 1.6f)

    val (fitMatchPercent, fitVerdictTitle, fitVerdictDetail, isOptimal) = when {
        sizeStepDiff == 0 -> Quadruple(
            98,
            "98% Optimal Biometric Fit ($normalizedSelectedSize)",
            "Calibrated for ${heightCm}cm / ${weightKg}kg ($fitPref). Shoulder seam aligns within +${String.format("%.1f", abs(shoulderEaseDeltaCm).coerceAtLeast(0.8f))}cm ease.",
            true
        )
        sizeStepDiff == 1 -> Quadruple(
            89,
            "89% Relaxed Drape (+1 Size Up)",
            "Size $normalizedSelectedSize gives +${String.format("%.1f", abs(shoulderEaseDeltaCm).coerceAtLeast(2.4f))}cm extra chest & shoulder room over your $recommendedSize measurement profile.",
             true
        )
        sizeStepDiff == -1 -> Quadruple(
            84,
            "84% Snug / Contoured Fit (-1 Size)",
            "Size $normalizedSelectedSize sits closer to your ${estimatedChestCm.roundToInt()}cm chest frame. Switch to $recommendedSize for your saved $fitPref.",
            false
        )
        sizeStepDiff > 1 -> Quadruple(
            74,
            "74% Oversized Silhouette (+$sizeStepDiff Sizes)",
            "Selected $normalizedSelectedSize is $sizeStepDiff sizes larger than your calibrated $recommendedSize (${heightCm}cm, ${weightKg}kg).",
            false
        )
        else -> Quadruple(
            68,
            "68% Tight Warning ($sizeStepDiff Sizes)",
            "Selected $normalizedSelectedSize is smaller than your ${estimatedChestCm.roundToInt()}cm chest & ${estimatedShoulderCm.roundToInt()}cm shoulder profile. Recommended: $recommendedSize.",
            false
        )
    }

    return RealTimeArSizingMetrics(
        heightCm = heightCm,
        weightKg = weightKg,
        recommendedSize = recommendedSize,
        activeSize = normalizedSelectedSize,
        bodyFitPreference = fitPref,
        estimatedShoulderCm = estimatedShoulderCm,
        estimatedChestCm = estimatedChestCm,
        estimatedTorsoLengthCm = estimatedTorsoLengthCm,
        garmentChestCm = garmentChestCm,
        shoulderEaseDeltaCm = shoulderEaseDeltaCm,
        horizontalWidthScale = horizontalWidthScale,
        verticalLengthScale = verticalLengthScale,
        fitMatchPercent = fitMatchPercent,
        fitVerdictTitle = fitVerdictTitle,
        fitVerdictDetail = fitVerdictDetail,
        isOptimalFit = isOptimal
    )
}

private data class Quadruple<A, B, C, D>(
    val first: A,
    val second: B,
    val third: C,
    val fourth: D
)

private fun parseFashionColorAccent(colorName: String): Color {
    val lower = colorName.lowercase()
    return when {
        "black" in lower || "onyx" in lower || "charcoal" in lower -> Color(0xFF26262E)
        "navy" in lower || "blue" in lower || "indigo" in lower || "cobalt" in lower -> Color(0xFF2563EB)
        "emerald" in lower || "green" in lower || "olive" in lower || "sage" in lower -> Color(0xFF10B981)
        "maroon" in lower || "red" in lower || "crimson" in lower || "burgundy" in lower || "wine" in lower -> Color(0xFFE11D48)
        "gold" in lower || "mustard" in lower || "yellow" in lower || "champagne" in lower -> Color(0xFFD97706)
        "ivory" in lower || "white" in lower || "cream" in lower || "pearl" in lower -> Color(0xFFF3F4F6)
        "pink" in lower || "rose" in lower || "blush" in lower -> Color(0xFFEC4899)
        "purple" in lower || "lavender" in lower || "plum" in lower -> Color(0xFF8B5CF6)
        else -> Color(0xFF6366F1)
    }
}

@Composable
fun RealTimeCameraTryOnOverlayCard(
    userProfile: UserProfile?,
    selectedProduct: FashionProduct,
    selectedColor: String,
    selectedSize: String,
    catalogProducts: List<FashionProduct>,
    onSelectProduct: (FashionProduct) -> Unit,
    onSelectColor: (String) -> Unit,
    onSelectSize: (String) -> Unit,
    onCaptureFrameForTryOn: (Bitmap) -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    var lensFacing by remember { mutableIntStateOf(CameraSelector.LENS_FACING_FRONT) }
    var cameraBindError by remember { mutableStateOf<String?>(null) }
    var previewViewRef by remember { mutableStateOf<PreviewView?>(null) }

    // Real-time interactive overlay controls
    var showBiometricGrid by remember { mutableStateOf(true) }
    var showFineTuneControls by remember { mutableStateOf(false) }
    var garmentOpacity by remember { mutableFloatStateOf(0.86f) }
    var manualScaleMultiplier by remember { mutableFloatStateOf(1.0f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(14f) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
    }

    val sizingMetrics = remember(userProfile, selectedSize, selectedProduct.category) {
        calculateRealTimeArSizingMetrics(
            userProfile = userProfile,
            selectedSize = selectedSize,
            productCategory = selectedProduct.category
        )
    }

    val animatedWidthScale by animateFloatAsState(
        targetValue = (sizingMetrics.horizontalWidthScale * manualScaleMultiplier).coerceIn(0.65f, 1.65f),
        animationSpec = tween(durationMillis = 320),
        label = "widthScale"
    )
    val animatedLengthScale by animateFloatAsState(
        targetValue = (sizingMetrics.verticalLengthScale * manualScaleMultiplier).coerceIn(0.65f, 1.65f),
        animationSpec = tween(durationMillis = 320),
        label = "lengthScale"
    )

    val infiniteTransition = rememberInfiniteTransition(label = "arHudScan")
    val scanLineProgress by infiniteTransition.animateFloat(
        initialValue = 0.12f,
        targetValue = 0.88f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scanLine"
    )
    val anchorPulse by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1100, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "anchorPulse"
    )

    // Bind CameraX Preview when permission is granted or lens changes
    LaunchedEffect(hasCameraPermission, lensFacing) {
        if (!hasCameraPermission) return@LaunchedEffect
        val previewView = previewViewRef ?: return@LaunchedEffect
        try {
            val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
            cameraProviderFuture.addListener({
                try {
                    val cameraProvider = cameraProviderFuture.get()
                    val preview = Preview.Builder().build().also {
                        it.surfaceProvider = previewView.surfaceProvider
                    }
                    val selector = CameraSelector.Builder()
                        .requireLensFacing(lensFacing)
                        .build()

                    cameraProvider.unbindAll()
                    if (cameraProvider.hasCamera(selector)) {
                        cameraProvider.bindToLifecycle(lifecycleOwner, selector, preview)
                        cameraBindError = null
                    } else if (cameraProvider.hasCamera(CameraSelector.DEFAULT_BACK_CAMERA)) {
                        cameraProvider.bindToLifecycle(
                            lifecycleOwner,
                            CameraSelector.DEFAULT_BACK_CAMERA,
                            preview
                        )
                        cameraBindError = null
                    } else if (cameraProvider.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA)) {
                        cameraProvider.bindToLifecycle(
                            lifecycleOwner,
                            CameraSelector.DEFAULT_FRONT_CAMERA,
                            preview
                        )
                        cameraBindError = null
                    } else {
                        cameraBindError = "No physical camera stream detected — running AR Body Twin Simulation Mirror"
                    }
                } catch (e: Exception) {
                    cameraBindError = "AR Mirror Standby (${e.localizedMessage ?: "Camera stream unavailable"})"
                }
            }, ContextCompat.getMainExecutor(context))
        } catch (e: Exception) {
            cameraBindError = "AR Mirror Standby"
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            try {
                val provider = ProcessCameraProvider.getInstance(context)
                if (provider.isDone) {
                    provider.get().unbindAll()
                }
            } catch (_: Exception) {
            }
        }
    }

    val garmentTint = remember(selectedColor) { parseFashionColorAccent(selectedColor) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("realtime_camera_tryon_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Top Header with Measurement Calibration Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = CircleShape,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Real-Time AR Camera Outfit Mapper",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Mapped to ${sizingMetrics.heightCm} cm • ${sizingMetrics.weightKg} kg • ${sizingMetrics.bodyFitPreference}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Surface(
                    color = if (sizingMetrics.isOptimalFit) {
                        MaterialTheme.colorScheme.tertiaryContainer
                    } else {
                        MaterialTheme.colorScheme.secondaryContainer
                    },
                    shape = RoundedCornerShape(50),
                    modifier = Modifier.testTag("ar_fit_match_badge")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Straighten,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp),
                            tint = if (sizingMetrics.isOptimalFit) {
                                MaterialTheme.colorScheme.onTertiaryContainer
                            } else {
                                MaterialTheme.colorScheme.onSecondaryContainer
                            }
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${sizingMetrics.fitMatchPercent}% Fit",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (sizingMetrics.isOptimalFit) {
                                MaterialTheme.colorScheme.onTertiaryContainer
                            } else {
                                MaterialTheme.colorScheme.onSecondaryContainer
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Camera Viewport + Real-Time Measurement-Mapped Clothing Overlay
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(440.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color(0xFF0E131F))
                    .border(
                        width = 1.dp,
                        color = Color(0xFF38BDF8).copy(alpha = 0.45f),
                        shape = RoundedCornerShape(18.dp)
                    )
                    .pointerInput(Unit) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            manualScaleMultiplier = (manualScaleMultiplier * zoom).coerceIn(0.75f, 1.45f)
                            offsetX = (offsetX + pan.x).coerceIn(-120f, 120f)
                            offsetY = (offsetY + pan.y).coerceIn(-120f, 140f)
                        }
                    }
                    .testTag("ar_camera_viewport"),
                contentAlignment = Alignment.Center
            ) {
                // 1. Live CameraX Feed (or Styled AR Silhouette Mirror Backdrop when camera permission/stream not active)
                if (hasCameraPermission) {
                    AndroidView(
                        factory = { ctx ->
                            PreviewView(ctx).apply {
                                implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                                scaleType = PreviewView.ScaleType.FILL_CENTER
                                previewViewRef = this
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                // Subtle Dark Ambient Vignette + Fallback Silhouette Twin if no camera stream
                Canvas(modifier = Modifier.fillMaxSize()) {
                    if (!hasCameraPermission || cameraBindError != null) {
                        drawRect(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color(0xFF0F172A),
                                    Color(0xFF1E293B),
                                    Color(0xFF0F172A)
                                )
                            )
                        )
                        // Draw subtle human mannequin twin scaled to user height/weight
                        val centerX = size.width / 2f
                        val headY = size.height * 0.16f
                        drawCircle(
                            color = Color(0xFF94A3B8).copy(alpha = 0.25f),
                            radius = size.width * 0.075f,
                            center = Offset(centerX, headY)
                        )
                        // Neck & torso silhouette
                        drawRoundRect(
                            color = Color(0xFF64748B).copy(alpha = 0.22f),
                            topLeft = Offset(
                                centerX - (size.width * 0.21f * animatedWidthScale),
                                size.height * 0.25f
                            ),
                            size = Size(
                                width = size.width * 0.42f * animatedWidthScale,
                                height = size.height * 0.48f * animatedLengthScale
                            ),
                            cornerRadius = CornerRadius(36f, 36f)
                        )
                    }
                }

                // 2. Biometric Body Tracking & Measurement Calibration Grid Overlay
                if (showBiometricGrid) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("ar_biometric_grid_canvas")
                    ) {
                        val cx = size.width / 2f + offsetX
                        val shoulderY = size.height * 0.27f + offsetY
                        val halfShoulderPx = (size.width * 0.24f * animatedWidthScale)
                        val torsoBottomY = (shoulderY + size.height * 0.43f * animatedLengthScale)
                            .coerceAtMost(size.height * 0.92f)
                        val dashEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 10f), 0f)

                        // Scanning laser line
                        val scanY = size.height * scanLineProgress
                        drawLine(
                            brush = Brush.horizontalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Color(0xFF38BDF8).copy(alpha = 0.75f),
                                    Color(0xFF818CF8).copy(alpha = 0.9f),
                                    Color(0xFF38BDF8).copy(alpha = 0.75f),
                                    Color.Transparent
                                )
                            ),
                            start = Offset(size.width * 0.08f, scanY),
                            end = Offset(size.width * 0.92f, scanY),
                            strokeWidth = 2.5f
                        )

                        // Center spine alignment axis
                        drawLine(
                            color = Color(0xFF38BDF8).copy(alpha = 0.35f),
                            start = Offset(cx, size.height * 0.14f),
                            end = Offset(cx, size.height * 0.88f),
                            strokeWidth = 1.5f,
                            pathEffect = dashEffect
                        )

                        // Shoulder calibration line & pulsing anchor nodes
                        val leftShoulder = Offset(cx - halfShoulderPx, shoulderY)
                        val rightShoulder = Offset(cx + halfShoulderPx, shoulderY)
                        drawLine(
                            color = Color(0xFF34D399).copy(alpha = 0.85f),
                            start = leftShoulder,
                            end = rightShoulder,
                            strokeWidth = 2.5f,
                            pathEffect = dashEffect
                        )

                        listOf(leftShoulder, rightShoulder).forEach { anchor ->
                            drawCircle(
                                color = Color(0xFF34D399).copy(alpha = 0.30f),
                                radius = 14f * anchorPulse,
                                center = anchor
                            )
                            drawCircle(
                                color = Color(0xFF34D399),
                                radius = 6f,
                                center = anchor
                            )
                        }

                        // Chest caliper line
                        val chestY = shoulderY + (torsoBottomY - shoulderY) * 0.32f
                        val halfChestPx = halfShoulderPx * 0.88f
                        drawLine(
                            color = Color(0xFFFBBF24).copy(alpha = 0.8f),
                            start = Offset(cx - halfChestPx, chestY),
                            end = Offset(cx + halfChestPx, chestY),
                            strokeWidth = 2f,
                            pathEffect = dashEffect
                        )

                        // Waist / Hem alignment line
                        val halfWaistPx = halfShoulderPx * 0.78f
                        drawLine(
                            color = Color(0xFF38BDF8).copy(alpha = 0.8f),
                            start = Offset(cx - halfWaistPx, torsoBottomY),
                            end = Offset(cx + halfWaistPx, torsoBottomY),
                            strokeWidth = 2.2f,
                            pathEffect = dashEffect
                        )
                    }
                }

                // 3. Real-Time Mapped Garment Overlay (Scaled by User Measurements + Selected Size)
                val baseGarmentWidthDp = 215.dp
                val baseGarmentHeightDp = 245.dp
                Box(
                    modifier = Modifier
                        .offset {
                            IntOffset(
                                x = offsetX.roundToInt(),
                                y = offsetY.roundToInt()
                            )
                        }
                        .graphicsLayer {
                            scaleX = animatedWidthScale
                            scaleY = animatedLengthScale
                        }
                        .width(baseGarmentWidthDp)
                        .height(baseGarmentHeightDp)
                        .testTag("ar_mapped_garment_box"),
                    contentAlignment = Alignment.Center
                ) {
                    // Product Image mapped onto user's torso
                    AsyncImage(
                        model = selectedProduct.imageUrl,
                        contentDescription = "Real-time AR mapped ${selectedProduct.name}",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(10.dp)
                            .clip(RoundedCornerShape(24.dp))
                            .alpha(garmentOpacity)
                    )

                    // Tailored Vector Garment Silhouette & Seam Frame tinted to Selected Color
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height
                        val garmentPath = Path().apply {
                            // Collar neckline
                            moveTo(w * 0.36f, h * 0.05f)
                            quadraticTo(w * 0.50f, h * 0.13f, w * 0.64f, h * 0.05f)
                            // Right shoulder & sleeve
                            lineTo(w * 0.95f, h * 0.16f)
                            lineTo(w * 0.99f, h * 0.38f)
                            lineTo(w * 0.79f, h * 0.42f)
                            // Right torso side seam
                            lineTo(w * 0.77f, h * 0.95f)
                            // Bottom hem
                            lineTo(w * 0.23f, h * 0.95f)
                            // Left torso side seam
                            lineTo(w * 0.21f, h * 0.42f)
                            // Left sleeve & shoulder
                            lineTo(w * 0.01f, h * 0.38f)
                            lineTo(w * 0.05f, h * 0.16f)
                            close()
                        }

                        // Subtle color tint wash over the garment
                        drawPath(
                            path = garmentPath,
                            color = garmentTint.copy(alpha = 0.22f),
                            blendMode = BlendMode.SrcOver
                        )

                        // Crisp tailored wireframe contour around mapped garment
                        drawPath(
                            path = garmentPath,
                            color = Color.White.copy(alpha = 0.85f),
                            style = Stroke(width = 3.2f)
                        )
                        drawPath(
                            path = garmentPath,
                            color = garmentTint.copy(alpha = 0.9f),
                            style = Stroke(
                                width = 1.8f,
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 8f), 0f)
                            )
                        )
                    }

                    // Floating On-Body Size & Measurement Tag
                    Surface(
                        color = Color(0xCC0F172A),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, Color(0xFF38BDF8).copy(alpha = 0.7f)),
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 8.dp)
                    ) {
                        Text(
                            text = "Size ${sizingMetrics.activeSize} • Chest ${sizingMetrics.garmentChestCm.roundToInt()}cm • Scale ${String.format("%.2f", animatedWidthScale)}x",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                // 4. Top-Left Live Biometric Telemetry Readout Overlay
                Column(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Surface(
                        color = Color(0xBF0F172A),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                            Text(
                                text = "BODY MAPPING TELEMETRY",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF38BDF8),
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Shldr: ${sizingMetrics.estimatedShoulderCm.roundToInt()}cm • Chest: ${sizingMetrics.estimatedChestCm.roundToInt()}cm • Torso: ${sizingMetrics.estimatedTorsoLengthCm.roundToInt()}cm",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White
                            )
                            Text(
                                text = "Rec Size: ${sizingMetrics.recommendedSize} | Active: ${sizingMetrics.activeSize} (${if (sizingMetrics.shoulderEaseDeltaCm >= 0) "+" else ""}${String.format("%.1f", sizingMetrics.shoulderEaseDeltaCm)}cm ease)",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF34D399)
                            )
                        }
                    }

                    if (!hasCameraPermission) {
                        Button(
                            onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF2563EB),
                                contentColor = Color.White
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("ar_grant_camera_permission_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = null,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Enable Live Camera Feed",
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                    } else if (cameraBindError != null) {
                        Surface(
                            color = Color(0xCC1E293B),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = cameraBindError ?: "",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFFFBBF24),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                // 5. Top-Right Floating Camera & Overlay Action Icons
                Column(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    IconButton(
                        onClick = {
                            lensFacing = if (lensFacing == CameraSelector.LENS_FACING_FRONT) {
                                CameraSelector.LENS_FACING_BACK
                            } else {
                                CameraSelector.LENS_FACING_FRONT
                            }
                        },
                        modifier = Modifier
                            .size(38.dp)
                            .background(Color(0xBF0F172A), CircleShape)
                            .testTag("ar_flip_camera_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Cameraswitch,
                            contentDescription = "Switch Front or Rear Camera",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    IconButton(
                        onClick = { showBiometricGrid = !showBiometricGrid },
                        modifier = Modifier
                            .size(38.dp)
                            .background(
                                if (showBiometricGrid) Color(0xCC2563EB) else Color(0xBF0F172A),
                                CircleShape
                            )
                            .testTag("ar_toggle_grid_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.GridOn,
                            contentDescription = "Toggle Biometric Measurement Grid",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    IconButton(
                        onClick = { showFineTuneControls = !showFineTuneControls },
                        modifier = Modifier
                            .size(38.dp)
                            .background(
                                if (showFineTuneControls) Color(0xCC2563EB) else Color(0xBF0F172A),
                                CircleShape
                            )
                            .testTag("ar_toggle_tuning_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "Fine Tune AR Overlay Alignment",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    IconButton(
                        onClick = {
                            manualScaleMultiplier = 1.0f
                            offsetX = 0f
                            offsetY = 14f
                        },
                        modifier = Modifier
                            .size(38.dp)
                            .background(Color(0xBF0F172A), CircleShape)
                            .testTag("ar_reset_alignment_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Reset AR Garment Alignment",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                // 6. Bottom-of-Viewport Live Fit Verdict Banner
                Surface(
                    color = Color(0xD90F172A),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(
                        1.dp,
                        if (sizingMetrics.isOptimalFit) Color(0xFF34D399) else Color(0xFFFBBF24)
                    ),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = if (sizingMetrics.isOptimalFit) Color(0xFF34D399) else Color(0xFFFBBF24),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = sizingMetrics.fitVerdictTitle,
                                style = MaterialTheme.typography.labelLarge,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = sizingMetrics.fitVerdictDetail,
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFFCBD5E1),
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }

            // Optional Fine-Tune Sliders for Opacity & Scale
            AnimatedVisibility(visible = showFineTuneControls) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "AR Garment Overlay Opacity (${(garmentOpacity * 100).roundToInt()}%)",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Slider(
                            value = garmentOpacity,
                            onValueChange = { garmentOpacity = it },
                            valueRange = 0.35f..1.0f,
                            modifier = Modifier.testTag("ar_opacity_slider")
                        )

                        Text(
                            text = "Manual Zoom Override (${(manualScaleMultiplier * 100).roundToInt()}%) • Drag outfit directly on camera to reposition",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Slider(
                            value = manualScaleMultiplier,
                            onValueChange = { manualScaleMultiplier = it },
                            valueRange = 0.75f..1.35f,
                            modifier = Modifier.testTag("ar_zoom_slider")
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Real-Time Size Calibration Strip (Switching sizes dynamically scales the AR overlay!)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Live AR Size Mapping:",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "AI Recommended: ${sizingMetrics.recommendedSize}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val sizesToShow = if (selectedProduct.availableSizes.isNotEmpty()) {
                    selectedProduct.availableSizes
                } else {
                    listOf("XS", "S", "M", "L", "XL", "XXL")
                }
                sizesToShow.forEach { sizeOption ->
                    val isRecommended = sizeOption.equals(sizingMetrics.recommendedSize, ignoreCase = true)
                    FilterChip(
                        selected = selectedSize.equals(sizeOption, ignoreCase = true),
                        onClick = { onSelectSize(sizeOption) },
                        label = {
                            Text(
                                if (isRecommended) "$sizeOption ★" else sizeOption
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier.testTag("ar_size_chip_$sizeOption")
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Quick Colour Variant Switcher for the Live Overlay
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Shade:",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                selectedProduct.availableColors.forEach { colorOption ->
                    FilterChip(
                        selected = selectedColor == colorOption,
                        onClick = { onSelectColor(colorOption) },
                        label = { Text(colorOption) },
                        modifier = Modifier.testTag("ar_color_chip_$colorOption")
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Instant Outfit Carousel to swap clothing items while looking at the live camera mirror
            Text(
                text = "Swap Mapped Clothing Item:",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(vertical = 2.dp)
            ) {
                items(catalogProducts.take(10), key = { it.id }) { item ->
                    val isSelected = item.id == selectedProduct.id
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) {
                            MaterialTheme.colorScheme.primaryContainer
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        },
                        border = BorderStroke(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                            }
                        ),
                        modifier = Modifier
                            .width(150.dp)
                            .clickable { onSelectProduct(item) }
                            .testTag("ar_outfit_switch_${item.id}")
                    ) {
                        Row(
                            modifier = Modifier.padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AsyncImage(
                                model = item.imageUrl,
                                contentDescription = item.name,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(8.dp))
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.brand,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = item.name,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Capture Live AR Frame & Run Gemini High-Res Try-On Button
            Button(
                onClick = {
                    val capturedBitmap = previewViewRef?.bitmap ?: createFallbackArCompositeBitmap(
                        sizingMetrics = sizingMetrics,
                        productTitle = selectedProduct.name
                    )
                    onCaptureFrameForTryOn(capturedBitmap)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("capture_ar_tryon_frame_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            ) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Capture AR Frame & Generate AI Try-On (${sizingMetrics.activeSize})",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

/**
 * Generates a valid non-null portrait bitmap when capturing an AR frame on virtual devices
 * where CameraX `PreviewView.bitmap` is null so that the downstream Gemini Try-On pipeline
 * always receives a valid frame.
 */
private fun createFallbackArCompositeBitmap(
    sizingMetrics: RealTimeArSizingMetrics,
    productTitle: String
): Bitmap {
    val width = 640
    val height = 800
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = AndroidCanvas(bitmap)
    val bgPaint = Paint().apply {
        shader = LinearGradient(
            0f,
            0f,
            0f,
            height.toFloat(),
            intArrayOf(0xFF1E293B.toInt(), 0xFF334155.toInt(), 0xFF0F172A.toInt()),
            null,
            Shader.TileMode.CLAMP
        )
    }
    canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

    val silhouettePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF94A3B8.toInt()
    }
    // Head & torso silhouette
    canvas.drawCircle(width / 2f, height * 0.22f, 58f, silhouettePaint)
    val halfTorso = 125f * sizingMetrics.horizontalWidthScale
    canvas.drawRoundRect(
        width / 2f - halfTorso,
        height * 0.31f,
        width / 2f + halfTorso,
        height * 0.78f,
        36f,
        36f,
        silhouettePaint
    )

    val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt()
        textSize = 24f
    }
    canvas.drawText(
        "AR Frame: ${sizingMetrics.heightCm}cm / ${sizingMetrics.weightKg}kg (${sizingMetrics.activeSize})",
        40f,
        height - 60f,
        textPaint
    )
    canvas.drawText(
        productTitle.take(36),
        40f,
        height - 28f,
        textPaint
    )
    return bitmap
}
