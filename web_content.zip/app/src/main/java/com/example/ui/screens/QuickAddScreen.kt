package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Pool
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.TransactionTypes
import com.example.ui.components.DatePickerHelper
import com.example.ui.components.Elevated3DCard
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.DepositBlue
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.ExpenseRedLight
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.IncomeGreenLight
import com.example.ui.theme.IslamicEmerald
import com.example.ui.theme.IslamicEmeraldLight
import com.example.ui.theme.IslamicGold
import com.example.ui.theme.IslamicGoldDark
import com.example.ui.theme.IslamicGreenDark
import com.example.ui.theme.IslamicGreenPrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.util.BanglaHelper
import com.example.ui.viewmodel.FinanceViewModel

data class QuickAddOption(
    val id: Int,
    val title: String,
    val subtitle: String,
    val type: String,
    val categoryLabel: String,
    val icon: ImageVector,
    val color: Color,
    val bgColor: Color
)

@Composable
fun QuickAddScreen(
    viewModel: FinanceViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val options = remember {
        listOf(
            QuickAddOption(
                id = 0,
                title = "দ্রুত আয় যোগ",
                subtitle = "সাধারণ কোনো আয় সহজে যোগ করুন",
                type = TransactionTypes.INCOME,
                categoryLabel = "সাধারণ আয়",
                icon = Icons.Default.AccountBalanceWallet,
                color = IncomeGreen,
                bgColor = IncomeGreenLight
            ),
            QuickAddOption(
                id = 1,
                title = "দ্রুত খরচ যোগ",
                subtitle = "দৈনন্দিন বাজার বা জরুরি খরচ",
                type = TransactionTypes.EXPENSE,
                categoryLabel = "সাধারণ খরচ",
                icon = Icons.Default.ShoppingCart,
                color = ExpenseRed,
                bgColor = ExpenseRedLight
            ),
            QuickAddOption(
                id = 2,
                title = "পুকুর থেকে বেতন যোগ",
                subtitle = "আয় হিসেবে স্বয়ংক্রিয়ভাবে যোগ হবে",
                type = TransactionTypes.POND_INCOME,
                categoryLabel = "পুকুর থেকে বেতন",
                icon = Icons.Default.Pool,
                color = DepositBlue,
                bgColor = Color(0xFFEFF6FF)
            ),
            QuickAddOption(
                id = 3,
                title = "পুকুরে খাবার যোগ",
                subtitle = "পুকুরের মাছের খাবার খরচ হিসেবে যুক্ত হবে",
                type = TransactionTypes.POND_FEED_EXPENSE,
                categoryLabel = "পুকুরে খাবার",
                icon = Icons.Default.Restaurant,
                color = IslamicGoldDark,
                bgColor = Color(0xFFFEF3C7)
            )
        )
    }

    var selectedOptionIndex by remember { mutableIntStateOf(0) }
    val currentOption = options[selectedOptionIndex]

    var amountInput by remember { mutableStateOf("") }
    var descInput by remember { mutableStateOf("") }
    var selectedDate by remember { mutableStateOf(BanglaHelper.getTodayIso()) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .imePadding()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "কী ধরনের হিসাব যোগ করতে চান?",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        // 4 Quick Options Grid / Cards
        items(options.size) { index ->
            val opt = options[index]
            val isSelected = selectedOptionIndex == index

            Elevated3DCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("quick_add_option_$index"),
                elevation = if (isSelected) 4f else 1f,
                borderColor = if (isSelected) opt.color else BorderSubtle,
                backgroundColor = if (isSelected) opt.bgColor else Color.White,
                onClick = {
                    selectedOptionIndex = index
                    if (opt.type == TransactionTypes.POND_INCOME && descInput.isBlank()) {
                        descInput = "পুকুর থেকে প্রাপ্ত বেতন"
                    } else if (opt.type == TransactionTypes.POND_FEED_EXPENSE && descInput.isBlank()) {
                        descInput = "পুকুরের মাছের খাবার ক্রয়"
                    }
                }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(opt.color.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = opt.icon,
                            contentDescription = opt.title,
                            tint = opt.color,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = opt.title,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) opt.color else TextPrimary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = opt.subtitle,
                            fontSize = 12.sp,
                            color = Color(0xFF6B7280)
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(6.dp))
            Elevated3DCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("quick_add_form_card"),
                elevation = 3f
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "${currentOption.title}-এর তথ্য লিখুন",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = currentOption.color
                    )

                    // Date Picker
                    Text(text = "তারিখ নির্বাচন", fontSize = 12.sp, color = Color(0xFF4B5563))
                    Elevated3DCard(
                        modifier = Modifier.fillMaxWidth(),
                        elevation = 1f,
                        onClick = {
                            DatePickerHelper.showDatePicker(context, selectedDate) { newDate ->
                                selectedDate = newDate
                            }
                        }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = BanglaHelper.formatBanglaDate(selectedDate),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                            Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = currentOption.color)
                        }
                    }

                    // Amount Input
                    Text(text = "টাকার পরিমাণ", fontSize = 12.sp, color = Color(0xFF4B5563))
                    OutlinedTextField(
                        value = amountInput,
                        onValueChange = { amountInput = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("quick_amount_input"),
                        placeholder = { Text("যেমন: ১০০০ বা 1000") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = currentOption.color,
                            unfocusedBorderColor = BorderSubtle
                        )
                    )

                    // Description Input
                    Text(text = "বিবরণ (ঐচ্ছিক)", fontSize = 12.sp, color = Color(0xFF4B5563))
                    OutlinedTextField(
                        value = descInput,
                        onValueChange = { descInput = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("quick_desc_input"),
                        placeholder = { Text("সংক্ষিপ্ত বিবরণ লিখুন...") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = currentOption.color,
                            unfocusedBorderColor = BorderSubtle
                        )
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Button(
                        onClick = {
                            val parsed = BanglaHelper.parseAmount(amountInput)
                            if (parsed == null || parsed <= 0.0) {
                                Toast.makeText(context, "সঠিক টাকার পরিমাণ লিখুন", Toast.LENGTH_SHORT).show()
                                return@Button
                            }

                            val desc = if (descInput.isNotBlank()) descInput.trim() else currentOption.title

                            viewModel.addTransaction(
                                type = currentOption.type,
                                categoryLabel = currentOption.categoryLabel,
                                amount = parsed,
                                date = selectedDate,
                                description = desc
                            ) {
                                amountInput = ""
                                descInput = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = currentOption.color),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("quick_save_button")
                    ) {
                        Icon(Icons.Default.FlashOn, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("দ্রুত সংরক্ষণ করুন", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
