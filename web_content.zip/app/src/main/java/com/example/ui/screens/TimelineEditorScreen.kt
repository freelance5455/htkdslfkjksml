package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.viewmodel.MotionForgeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimelineEditorScreen(
  viewModel: MotionForgeViewModel,
  onBack: () -> Unit,
  onNavigateToPreview: () -> Unit
) {
  val recipe by viewModel.recipe.collectAsState()
  val currentTime by viewModel.currentTime.collectAsState()
  val isPlaying by viewModel.isPlayingState.collectAsState()
  val audioAnalysis by viewModel.audioAnalysis.collectAsState()

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Professional Timeline") },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = null)
          }
        },
        actions = {
          IconButton(onClick = onNavigateToPreview) {
            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
      )
    }
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .background(MaterialTheme.colorScheme.background)
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "Time: ${String.format("%.2f", currentTime)}s / ${recipe?.settings?.durationSeconds ?: 10f}s",
              fontWeight = FontWeight.Bold,
              style = MaterialTheme.typography.titleMedium
            )
            IconButton(onClick = { viewModel.togglePlay() }) {
              Icon(
                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
              )
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          val maxDur = recipe?.settings?.durationSeconds ?: 10f
          Slider(
            value = currentTime,
            onValueChange = { viewModel.seekTo(it) },
            valueRange = 0f..maxDur,
            colors = SliderDefaults.colors(
              thumbColor = MaterialTheme.colorScheme.primary,
              activeTrackColor = MaterialTheme.colorScheme.primary
            )
          )

          audioAnalysis?.let { analysis ->
            Text(
              text = "Audio: ${analysis.trackTitle} (${analysis.bpm} BPM) • ${analysis.beatTimestamps.size} Beats Detected",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }

      Text(
        text = "Composition Layers & Tracks",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )

      val layers = recipe?.scenes?.flatMap { it.layers } ?: emptyList()

      LazyColumn(
        modifier = Modifier.fillMaxWidth().weight(1f),
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        items(layers) { layer ->
          Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(
                    imageVector = when (layer.type) {
                      "text" -> Icons.Default.TextFields
                      "shape" -> Icons.Default.Category
                      "3d" -> Icons.Default.ViewInAr
                      else -> Icons.Default.Image
                    },
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(layer.name, fontWeight = FontWeight.Bold)
                }
                Badge(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)) {
                  Text(layer.type.uppercase(), color = MaterialTheme.colorScheme.primary)
                }
              }

              Spacer(modifier = Modifier.height(8.dp))

              if (layer.textConfig != null) {
                OutlinedTextField(
                  value = layer.textConfig.text,
                  onValueChange = { newText ->
                    viewModel.updateLayerText(layer.id, newText)
                  },
                  label = { Text("Layer Text Content") },
                  modifier = Modifier.fillMaxWidth(),
                  shape = RoundedCornerShape(8.dp)
                )
              } else {
                Text(
                  text = "Start: ${layer.startTime}s | Duration: ${layer.duration}s | Pos: (${layer.posX}, ${layer.posY})",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }
        }
      }
    }
  }
}
