package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AddPhotoAlternate
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.SettingsBrightness
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.rememberAsyncImagePainter
import com.example.R
import com.example.core.AppearanceSettings
import com.example.core.ClassicThemeMode
import com.example.core.DesignSystem
import com.example.core.FlamiStrings
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppearanceScreen(
    strings: FlamiStrings,
    appearance: AppearanceSettings,
    onSelectDesignSystem: (DesignSystem) -> Unit,
    onSelectAnimeBgIndex: (Int) -> Unit,
    onPickCustomAnimeBg: (android.net.Uri) -> Unit,
    onSelectClassicMode: (ClassicThemeMode) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    val customBgPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onPickCustomAnimeBg(uri)
            onSelectDesignSystem(DesignSystem.ANIME_WORLD)
        }
    }

    val backdropModifier = when (appearance.designSystem) {
        DesignSystem.FLAMI_ORIGINAL -> Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0A0614),
                        Color(0xFF1D0B38),
                        Color(0xFF0E081D)
                    )
                )
            )
            .drawBehind {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0x557C3AED), Color.Transparent),
                        center = Offset(size.width * 0.85f, size.height * 0.15f),
                        radius = size.maxDimension * 0.55f
                    )
                )
            }
        DesignSystem.ANIME_WORLD -> Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
        DesignSystem.CLASSIC_AI -> Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    }

    Box(modifier = backdropModifier) {
        if (appearance.designSystem == DesignSystem.ANIME_WORLD) {
            val bgKey = "${appearance.animeBgIndex}_${appearance.customAnimeBgPath.orEmpty()}"
            Crossfade(targetState = bgKey, label = "appearanceAnimeBg") {
                val customFile = appearance.customAnimeBgPath?.let(::File)?.takeIf { it.exists() }
                val painter = if (appearance.animeBgIndex == -1 && customFile != null) {
                    rememberAsyncImagePainter(model = customFile)
                } else {
                    val resId = when (appearance.animeBgIndex) {
                        1 -> R.drawable.img_anime_bg_2
                        2 -> R.drawable.img_anime_bg_3
                        else -> R.drawable.img_anime_bg_1
                    }
                    painterResource(id = resId)
                }
                Box(modifier = Modifier.fillMaxSize()) {
                    Image(
                        painter = painter,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color(0x70090416))
                    )
                }
            }
        }

        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                CenterAlignedTopAppBar(
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = if (appearance.designSystem == DesignSystem.ANIME_WORLD) {
                            MaterialTheme.colorScheme.surface.copy(alpha = 0.72f)
                        } else {
                            MaterialTheme.colorScheme.surface.copy(alpha = 0.90f)
                        }
                    ),
                    navigationIcon = {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier.testTag("appearance_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = strings.backToChat
                            )
                        }
                    },
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Palette,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = strings.appearanceTitle,
                                style = MaterialTheme.typography.titleLarge
                            )
                        }
                    },
                    actions = {
                        TextButton(
                            onClick = onBack,
                            modifier = Modifier.testTag("appearance_done_button")
                        ) {
                            Text(strings.backToChat, style = MaterialTheme.typography.labelLarge)
                        }
                    }
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .navigationBarsPadding(),
                contentAlignment = Alignment.TopCenter
            ) {
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 18.dp, vertical = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp),
                    modifier = Modifier
                        .widthIn(max = 720.dp)
                        .fillMaxSize()
                ) {
                    item {
                        Surface(
                            color = if (appearance.designSystem == DesignSystem.ANIME_WORLD) {
                                MaterialTheme.colorScheme.surface.copy(alpha = 0.72f)
                            } else {
                                Color.Transparent
                            },
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Text(
                                text = strings.appearanceSubtitle,
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (appearance.designSystem == DesignSystem.ANIME_WORLD) {
                                    MaterialTheme.colorScheme.onSurface
                                } else {
                                    MaterialTheme.colorScheme.onSurfaceVariant
                                },
                                modifier = Modifier.padding(
                                    horizontal = if (appearance.designSystem == DesignSystem.ANIME_WORLD) 12.dp else 0.dp,
                                    vertical = if (appearance.designSystem == DesignSystem.ANIME_WORLD) 8.dp else 0.dp
                                )
                            )
                        }
                    }

                    // 1. ANIME WORLD CARD
                    item {
                        val isSelected = appearance.designSystem == DesignSystem.ANIME_WORLD
                        ThemePreviewCardFrame(
                            title = strings.animeThemeTitle,
                            description = strings.animeThemeDesc,
                            isSelected = isSelected,
                            isGlassMode = appearance.designSystem == DesignSystem.ANIME_WORLD,
                            activeBadgeText = strings.activeThemeBadge,
                            selectButtonText = strings.selectThemeAction,
                            accentColor = Color(0xFFFF6EC7),
                            onSelectOnly = { onSelectDesignSystem(DesignSystem.ANIME_WORLD) },
                            onApplyAndOpenChat = {
                                onSelectDesignSystem(DesignSystem.ANIME_WORLD)
                                onBack()
                            },
                            cardModifier = Modifier.testTag("theme_card_anime"),
                            previewContent = {
                                AnimeWorldMiniPreview(appearance = appearance)
                            },
                            extraControls = {
                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text(
                                        text = strings.animeChangeBg,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .horizontalScroll(rememberScrollState()),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        val builtIns = listOf(
                                            0 to R.drawable.img_anime_bg_1,
                                            1 to R.drawable.img_anime_bg_2,
                                            2 to R.drawable.img_anime_bg_3
                                        )
                                        builtIns.forEach { (idx, resId) ->
                                            val selectedThumb = appearance.animeBgIndex == idx
                                            Box(
                                                modifier = Modifier
                                                    .size(width = 64.dp, height = 84.dp)
                                                    .clip(RoundedCornerShape(12.dp))
                                                    .border(
                                                        width = if (selectedThumb) 2.5.dp else 1.dp,
                                                        color = if (selectedThumb) Color(0xFFFF6EC7) else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                                                        shape = RoundedCornerShape(12.dp)
                                                    )
                                                    .clickable {
                                                        onSelectAnimeBgIndex(idx)
                                                        onSelectDesignSystem(DesignSystem.ANIME_WORLD)
                                                    }
                                                    .testTag("anime_bg_thumb_$idx")
                                            ) {
                                                Image(
                                                    painter = painterResource(id = resId),
                                                    contentDescription = "${strings.animeChangeBg} ${idx + 1}",
                                                    contentScale = ContentScale.Crop,
                                                    modifier = Modifier.fillMaxSize()
                                                )
                                                if (selectedThumb) {
                                                    Icon(
                                                        imageVector = Icons.Rounded.CheckCircle,
                                                        contentDescription = null,
                                                        tint = Color(0xFFFF6EC7),
                                                        modifier = Modifier
                                                            .align(Alignment.TopEnd)
                                                            .padding(4.dp)
                                                            .size(18.dp)
                                                            .background(Color(0xAA0A0618), CircleShape)
                                                    )
                                                }
                                            }
                                        }

                                        val hasCustom = appearance.animeBgIndex == -1 &&
                                            !appearance.customAnimeBgPath.isNullOrBlank() &&
                                            File(appearance.customAnimeBgPath).exists()
                                        OutlinedButton(
                                            onClick = {
                                                customBgPicker.launch(
                                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                                )
                                            },
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier
                                                .height(84.dp)
                                                .testTag("anime_custom_photo_button")
                                        ) {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                Icon(
                                                    imageVector = Icons.Rounded.AddPhotoAlternate,
                                                    contentDescription = strings.animeCustomPhoto,
                                                    tint = if (hasCustom) Color(0xFFFF6EC7) else MaterialTheme.colorScheme.primary
                                                )
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(
                                                    text = strings.animeCustomPhoto,
                                                    style = MaterialTheme.typography.labelMedium
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        )
                    }

                    // 2. FLAMI ORIGINAL CARD
                    item {
                        val isSelected = appearance.designSystem == DesignSystem.FLAMI_ORIGINAL
                        ThemePreviewCardFrame(
                            title = strings.flamiOriginalTitle,
                            description = strings.flamiOriginalDesc,
                            isSelected = isSelected,
                            isGlassMode = appearance.designSystem == DesignSystem.ANIME_WORLD,
                            activeBadgeText = strings.activeThemeBadge,
                            selectButtonText = strings.selectThemeAction,
                            accentColor = Color(0xFFA855F7),
                            onSelectOnly = { onSelectDesignSystem(DesignSystem.FLAMI_ORIGINAL) },
                            onApplyAndOpenChat = {
                                onSelectDesignSystem(DesignSystem.FLAMI_ORIGINAL)
                                onBack()
                            },
                            cardModifier = Modifier.testTag("theme_card_original"),
                            previewContent = {
                                FlamiOriginalMiniPreview()
                            }
                        )
                    }

                    // 3. CLASSIC AI (ChatGPT Style) CARD
                    item {
                        val isSelected = appearance.designSystem == DesignSystem.CLASSIC_AI
                        ThemePreviewCardFrame(
                            title = strings.classicAiTitle,
                            description = strings.classicAiDesc,
                            isSelected = isSelected,
                            isGlassMode = appearance.designSystem == DesignSystem.ANIME_WORLD,
                            activeBadgeText = strings.activeThemeBadge,
                            selectButtonText = strings.selectThemeAction,
                            accentColor = Color(0xFF10A37F),
                            onSelectOnly = { onSelectDesignSystem(DesignSystem.CLASSIC_AI) },
                            onApplyAndOpenChat = {
                                onSelectDesignSystem(DesignSystem.CLASSIC_AI)
                                onBack()
                            },
                            cardModifier = Modifier.testTag("theme_card_classic"),
                            previewContent = {
                                ClassicAiMiniPreview(mode = appearance.classicThemeMode)
                            },
                            extraControls = {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    FilterChip(
                                        selected = appearance.classicThemeMode == ClassicThemeMode.SYSTEM,
                                        onClick = {
                                            onSelectClassicMode(ClassicThemeMode.SYSTEM)
                                            onSelectDesignSystem(DesignSystem.CLASSIC_AI)
                                        },
                                        leadingIcon = {
                                            Icon(Icons.Rounded.SettingsBrightness, contentDescription = null, modifier = Modifier.size(16.dp))
                                        },
                                        label = { Text(strings.classicModeSystem) }
                                    )
                                    FilterChip(
                                        selected = appearance.classicThemeMode == ClassicThemeMode.LIGHT,
                                        onClick = {
                                            onSelectClassicMode(ClassicThemeMode.LIGHT)
                                            onSelectDesignSystem(DesignSystem.CLASSIC_AI)
                                        },
                                        leadingIcon = {
                                            Icon(Icons.Rounded.LightMode, contentDescription = null, modifier = Modifier.size(16.dp))
                                        },
                                        label = { Text(strings.classicModeLight) }
                                    )
                                    FilterChip(
                                        selected = appearance.classicThemeMode == ClassicThemeMode.DARK,
                                        onClick = {
                                            onSelectClassicMode(ClassicThemeMode.DARK)
                                            onSelectDesignSystem(DesignSystem.CLASSIC_AI)
                                        },
                                        leadingIcon = {
                                            Icon(Icons.Rounded.DarkMode, contentDescription = null, modifier = Modifier.size(16.dp))
                                        },
                                        label = { Text(strings.classicModeDark) }
                                    )
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ThemePreviewCardFrame(
    title: String,
    description: String,
    isSelected: Boolean,
    isGlassMode: Boolean,
    activeBadgeText: String,
    selectButtonText: String,
    accentColor: Color,
    onSelectOnly: () -> Unit,
    onApplyAndOpenChat: () -> Unit,
    cardModifier: Modifier = Modifier,
    previewContent: @Composable () -> Unit,
    extraControls: (@Composable () -> Unit)? = null
) {
    val borderColor by animateColorAsState(
        targetValue = if (isSelected) accentColor else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
        label = "cardBorder"
    )

    Surface(
        color = if (isGlassMode) {
            MaterialTheme.colorScheme.surface.copy(alpha = 0.78f)
        } else {
            MaterialTheme.colorScheme.surface
        },
        shape = RoundedCornerShape(22.dp),
        tonalElevation = if (isSelected) 4.dp else 1.dp,
        modifier = cardModifier
            .fillMaxWidth()
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = borderColor,
                shape = RoundedCornerShape(22.dp)
            )
            .clickable(onClick = onSelectOnly)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(152.dp)
                    .clip(RoundedCornerShape(16.dp))
            ) {
                previewContent()
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (isSelected) {
                        Badge(
                            containerColor = accentColor.copy(alpha = 0.22f),
                            contentColor = accentColor
                        ) {
                            Text(
                                text = activeBadgeText,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                if (!isSelected) {
                    Button(
                        onClick = onApplyAndOpenChat,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = accentColor,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(selectButtonText, style = MaterialTheme.typography.labelLarge)
                    }
                } else {
                    Icon(
                        imageVector = Icons.Rounded.CheckCircle,
                        contentDescription = activeBadgeText,
                        tint = accentColor,
                        modifier = Modifier
                            .size(28.dp)
                            .clickable(onClick = onApplyAndOpenChat)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (extraControls != null) {
                Spacer(modifier = Modifier.height(14.dp))
                extraControls()
            }
        }
    }
}

@Composable
private fun AnimeWorldMiniPreview(appearance: AppearanceSettings) {
    val customFile = appearance.customAnimeBgPath?.let(::File)?.takeIf { it.exists() }
    val painter = if (appearance.animeBgIndex == -1 && customFile != null) {
        rememberAsyncImagePainter(model = customFile)
    } else {
        val resId = when (appearance.animeBgIndex) {
            1 -> R.drawable.img_anime_bg_2
            2 -> R.drawable.img_anime_bg_3
            else -> R.drawable.img_anime_bg_1
        }
        painterResource(id = resId)
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painter,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0x220A0618), Color(0x880A0618))
                    )
                )
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Surface(
                color = Color(0x99150E2A),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.border(0.8.dp, Color(0x88FF6EC7), RoundedCornerShape(12.dp))
            ) {
                Text(
                    text = "FLAMI • Anime World",
                    color = Color(0xFFF8F5FF),
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Surface(
                    color = Color(0xAA4A133C),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text(
                        text = "Привет! Напиши UI",
                        color = Color(0xFFFFD8EE),
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
                Surface(
                    color = Color(0xB8150E2A),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .border(0.8.dp, Color(0x6638BDF8), RoundedCornerShape(12.dp))
                ) {
                    Text(
                        text = "Готово! Аниме-девушка на фоне.",
                        color = Color(0xFFF8F5FF),
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun FlamiOriginalMiniPreview() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF0A0614), Color(0xFF210C3F), Color(0xFF0C0718))
                )
            )
            .drawBehind {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0x667C3AED), Color.Transparent),
                        center = Offset(size.width * 0.85f, size.height * 0.2f),
                        radius = size.maxDimension * 0.65f
                    )
                )
            }
            .padding(12.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(
                    imageVector = Icons.Rounded.AutoAwesome,
                    contentDescription = null,
                    tint = Color(0xFFA855F7),
                    modifier = Modifier.size(14.dp)
                )
                Text(
                    text = "FLAMI ORIGINAL",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFFF5F2FC)
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .width(3.dp)
                        .height(34.dp)
                        .background(
                            Brush.verticalGradient(listOf(Color(0xFFA855F7), Color(0xFFC026D3))),
                            RoundedCornerShape(2.dp)
                        )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Тёмно-фиолетовый обсидиан и компактный ввод.",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFFF5F2FC)
                )
            }

            Surface(
                color = Color(0xFF140C26),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.8.dp, Color(0xFF3A2463), RoundedCornerShape(14.dp))
            ) {
                Text(
                    text = "Спросите FLAMI AI...",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFFB5A7CE),
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                )
            }
        }
    }
}

@Composable
private fun ClassicAiMiniPreview(mode: ClassicThemeMode) {
    val dark = mode != ClassicThemeMode.LIGHT
    val bg = if (dark) Color(0xFF212121) else Color(0xFFFFFFFF)
    val pill = if (dark) Color(0xFF2F2F2F) else Color(0xFFF4F4F4)
    val text = if (dark) Color(0xFFECECEC) else Color(0xFF0D0D0D)
    val accent = Color(0xFF10A37F)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(bg)
            .padding(12.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = "ChatGPT Style • Gemini 3.8",
            style = MaterialTheme.typography.labelSmall,
            color = accent,
            fontWeight = FontWeight.SemiBold
        )
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Surface(
                color = pill,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.align(Alignment.End)
            ) {
                Text(
                    text = "Объясни алгоритм",
                    style = MaterialTheme.typography.labelSmall,
                    color = text,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }
            Text(
                text = "Вот чистый пошаговый ответ в стиле ChatGPT.",
                style = MaterialTheme.typography.labelSmall,
                color = text
            )
        }
        Surface(
            color = pill,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "Message FLAMI...",
                style = MaterialTheme.typography.labelSmall,
                color = text.copy(alpha = 0.6f),
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
            )
        }
    }
}
