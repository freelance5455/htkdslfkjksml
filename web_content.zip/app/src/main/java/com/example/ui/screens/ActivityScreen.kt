package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.People
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.ArkPost
import com.example.data.model.FollowRequest
import com.example.data.model.FriendRequest
import com.example.data.model.NotificationItem
import com.example.ui.components.ArkAvatarBadge
import com.example.ui.components.EmptyStateGlassCard
import com.example.ui.components.GlowingPillButton
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.UserBadgeChip
import com.example.ui.components.formatPostTimestamp
import com.example.ui.theme.ArkThemeTokens

@Composable
fun ActivityScreen(
    incomingFollowRequests: List<FollowRequest>,
    incomingFriendRequests: List<FriendRequest>,
    pendingTagRequests: List<ArkPost>,
    notifications: List<NotificationItem>,
    onAcceptFollowRequest: (FollowRequest) -> Unit,
    onRejectFollowRequest: (String) -> Unit,
    onAcceptFriendRequest: (FriendRequest) -> Unit,
    onRejectFriendRequest: (String) -> Unit,
    onApproveTag: (String) -> Unit,
    onDeclineTag: (String) -> Unit,
    onNotificationClick: (NotificationItem) -> Unit,
    onMarkAllRead: () -> Unit,
    onOpenUserProfile: (String) -> Unit,
    onOpenFriends: () -> Unit,
    onOpenNotificationRules: () -> Unit
) {
    val colors = ArkThemeTokens.colors
    val dayAgoSec = remember { (System.currentTimeMillis() / 1000L) - 86_400L }
    val todayItems = remember(notifications, dayAgoSec) {
        notifications.filter { (it.createdAt?.seconds ?: Long.MAX_VALUE) >= dayAgoSec }
    }
    val earlierItems = remember(notifications, dayAgoSec) {
        notifications.filter { (it.createdAt?.seconds ?: 0L) < dayAgoSec }
    }
    val hasUnread = notifications.any { !it.isRead }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(key = "activity_header") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Activity", style = MaterialTheme.typography.headlineMedium, color = colors.ink)
                    Text("Requests, tags & interactions", style = MaterialTheme.typography.bodySmall, color = colors.ink2)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (hasUnread) {
                        IconButton(onClick = onMarkAllRead, modifier = Modifier.testTag("activity_mark_all_read")) {
                            Icon(Icons.Default.DoneAll, contentDescription = "Mark all read", tint = colors.accent)
                        }
                    }
                    IconButton(onClick = onOpenFriends, modifier = Modifier.testTag("activity_open_friends")) {
                        Icon(Icons.Default.People, contentDescription = "Friends & Search", tint = colors.ink)
                    }
                    IconButton(onClick = onOpenNotificationRules, modifier = Modifier.testTag("activity_open_rules")) {
                        Icon(Icons.Default.NotificationsActive, contentDescription = "Notification Settings", tint = colors.ink)
                    }
                }
            }
        }

        if (incomingFollowRequests.isNotEmpty()) {
            item(key = "follow_req_header") {
                Text("Follow Requests (${incomingFollowRequests.size})", style = MaterialTheme.typography.titleMedium, color = colors.ink)
            }
            items(incomingFollowRequests, key = { "follreq_${it.id}" }) { req ->
                LiquidGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    accentColor = colors.accent,
                    onClick = { onOpenUserProfile(req.fromUid) }
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            ArkAvatarBadge(avatarPreset = req.fromAvatar, username = req.fromUsername, size = 40.dp)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text("@${req.fromUsername}", style = MaterialTheme.typography.titleSmall, color = colors.ink)
                                Text("Requested to follow you", style = MaterialTheme.typography.bodySmall, color = colors.ink2)
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            IconButton(onClick = { onRejectFollowRequest(req.id) }) {
                                Icon(Icons.Default.Close, contentDescription = "Decline follow request", tint = colors.coral)
                            }
                            IconButton(onClick = { onAcceptFollowRequest(req) }) {
                                Icon(Icons.Default.Check, contentDescription = "Accept follow request", tint = colors.emerald)
                            }
                        }
                    }
                }
            }
        }

        if (incomingFriendRequests.isNotEmpty()) {
            item(key = "friend_req_header") {
                Text("Friend Invitations (${incomingFriendRequests.size})", style = MaterialTheme.typography.titleMedium, color = colors.ink)
            }
            items(incomingFriendRequests, key = { "frreq_${it.id}" }) { req ->
                LiquidGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    accentColor = colors.emerald,
                    onClick = { onOpenUserProfile(req.fromUid) }
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            ArkAvatarBadge(avatarPreset = req.fromAvatar, username = req.fromUsername, size = 40.dp)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text("@${req.fromUsername}", style = MaterialTheme.typography.titleSmall, color = colors.ink)
                                Text("Friend request", style = MaterialTheme.typography.bodySmall, color = colors.ink2)
                            }
                        }
                        Row {
                            IconButton(onClick = { onRejectFriendRequest(req.id) }) {
                                Icon(Icons.Default.Close, contentDescription = "Decline friend request", tint = colors.coral)
                            }
                            IconButton(onClick = { onAcceptFriendRequest(req) }) {
                                Icon(Icons.Default.Check, contentDescription = "Accept friend request", tint = colors.emerald)
                            }
                        }
                    }
                }
            }
        }

        if (pendingTagRequests.isNotEmpty()) {
            item(key = "pending_tag_header") {
                Text("Tag Approval Needed (${pendingTagRequests.size})", style = MaterialTheme.typography.titleMedium, color = colors.ink)
            }
            items(pendingTagRequests, key = { "act_ptag_${it.id}" }) { post ->
                LiquidGlassCard(modifier = Modifier.fillMaxWidth(), accentColor = colors.gold) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("@${post.authorUsername} tagged you in a post", style = MaterialTheme.typography.titleSmall, color = colors.ink)
                            if (post.caption.isNotBlank()) {
                                Text(post.caption, style = MaterialTheme.typography.bodySmall, color = colors.ink2, maxLines = 1)
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = { onDeclineTag(post.id) }) { Text("Hide") }
                            GlowingPillButton(text = "Approve", onClick = { onApproveTag(post.id) })
                        }
                    }
                }
            }
        }

        if (notifications.isEmpty() && incomingFollowRequests.isEmpty() && incomingFriendRequests.isEmpty() && pendingTagRequests.isEmpty()) {
            item {
                EmptyStateGlassCard(
                    icon = Icons.Default.FavoriteBorder,
                    title = "No Recent Activity",
                    subtitle = "Likes, comments, new followers, and challenge updates will show up here.",
                    actionLabel = "Find Friends",
                    onAction = onOpenFriends
                )
            }
        } else {
            if (todayItems.isNotEmpty()) {
                item(key = "today_header") {
                    Text("Today", style = MaterialTheme.typography.titleMedium, color = colors.ink)
                }
                items(todayItems, key = { "notift_${it.id}" }) { item ->
                    ActivityNotificationCard(item = item, onClick = { onNotificationClick(item) })
                }
            }
            if (earlierItems.isNotEmpty()) {
                item(key = "earlier_header") {
                    Text("Earlier", style = MaterialTheme.typography.titleMedium, color = colors.ink)
                }
                items(earlierItems, key = { "notife_${it.id}" }) { item ->
                    ActivityNotificationCard(item = item, onClick = { onNotificationClick(item) })
                }
            }
        }

        item { Spacer(Modifier.height(72.dp)) }
    }
}

@Composable
private fun ActivityNotificationCard(
    item: NotificationItem,
    onClick: () -> Unit
) {
    val colors = ArkThemeTokens.colors
    LiquidGlassCard(
        modifier = Modifier.fillMaxWidth(),
        accentColor = if (!item.isRead) colors.accent else null,
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(item.title, style = MaterialTheme.typography.titleSmall, color = colors.ink)
                    Spacer(Modifier.width(6.dp))
                    Text(formatPostTimestamp(item.createdAt), style = MaterialTheme.typography.labelSmall, color = colors.ink3)
                }
                Spacer(Modifier.height(2.dp))
                Text(item.body, style = MaterialTheme.typography.bodySmall, color = colors.ink2)
            }
            if (!item.isRead) {
                Spacer(Modifier.width(8.dp))
                UserBadgeChip(label = "NEW", accent = colors.accent)
            }
        }
    }
}
