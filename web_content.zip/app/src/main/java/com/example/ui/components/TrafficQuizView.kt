package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.QuizQuestion
import com.example.ui.theme.TrafficGreen
import com.example.ui.theme.TrafficRed
import com.example.ui.theme.TrafficYellow

@Composable
fun TrafficQuizView(
    questions: List<QuizQuestion>,
    currentIndex: Int,
    selectedAnswer: Int?,
    score: Int,
    isFinished: Boolean,
    onSelectOption: (Int) -> Unit,
    onNextQuestion: () -> Unit,
    onResetQuiz: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (isFinished) {
        QuizCompletionCard(
            score = score,
            totalQuestions = questions.size,
            onRetake = onResetQuiz,
            modifier = modifier
        )
        return
    }

    val currentQuestion = questions.getOrNull(currentIndex) ?: return
    val progress = (currentIndex + 1).toFloat() / questions.size.toFloat()

    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            // Header & Progress
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "اختبار الثقافة المرورية",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "السؤال ${currentIndex + 1} من ${questions.size}",
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.LightGray
                    )
                }

                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = Color(0xFF29B6F6),
                    trackColor = Color(0xFF263238),
                )
            }
        }

        // Question Card
        item {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = Color(0xFF171E2A),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF2C394F)),
                shadowElevation = 6.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = currentQuestion.question,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White,
                        lineHeight = 24.sp
                    )

                    // Options list
                    currentQuestion.options.forEachIndexed { optIndex, optionText ->
                        val isSelected = selectedAnswer == optIndex
                        val isCorrect = optIndex == currentQuestion.correctIndex
                        val hasAnswered = selectedAnswer != null

                        val borderColor = when {
                            hasAnswered && isCorrect -> TrafficGreen
                            hasAnswered && isSelected && !isCorrect -> TrafficRed
                            isSelected -> Color(0xFF29B6F6)
                            else -> Color(0xFF2B364A)
                        }

                        val bgColor = when {
                            hasAnswered && isCorrect -> Color(0xFF0C2B18)
                            hasAnswered && isSelected && !isCorrect -> Color(0xFF330C10)
                            isSelected -> Color(0xFF0D253D)
                            else -> Color(0xFF1C2433)
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(bgColor)
                                .border(1.5.dp, borderColor, RoundedCornerShape(12.dp))
                                .clickable(enabled = !hasAnswered) { onSelectOption(optIndex) }
                                .padding(horizontal = 14.dp, vertical = 12.dp)
                                .testTag("quiz_option_$optIndex"),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF283447)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${optIndex + 1}",
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Text(
                                text = optionText,
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White,
                                modifier = Modifier.weight(1f)
                            )

                            if (hasAnswered && isCorrect) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "إجابة صحيحة",
                                    tint = TrafficGreen,
                                    modifier = Modifier.size(20.dp)
                                )
                            } else if (hasAnswered && isSelected && !isCorrect) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "إجابة خاطئة",
                                    tint = TrafficRed,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }

                    // Explanation
                    AnimatedVisibility(visible = selectedAnswer != null) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFF1F2937),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF374151)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = if (selectedAnswer == currentQuestion.correctIndex) "إجابة صحيحة وممتازة!" else "الإجابة الصحيحة هي خيار رقم ${currentQuestion.correctIndex + 1}",
                                    fontWeight = FontWeight.Bold,
                                    color = if (selectedAnswer == currentQuestion.correctIndex) TrafficGreen else TrafficYellow,
                                    fontSize = 13.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = currentQuestion.explanation,
                                    color = Color(0xFFD1D5DB),
                                    fontSize = 12.sp,
                                    lineHeight = 18.sp
                                )
                            }
                        }
                    }

                    // Next Button
                    if (selectedAnswer != null) {
                        Button(
                            onClick = onNextQuestion,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF1976D2),
                                contentColor = Color.White
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("btn_next_quiz")
                        ) {
                            Text(
                                text = if (currentIndex + 1 < questions.size) "السؤال التالي" else "عرض النتيجة النهائية",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun QuizCompletionCard(
    score: Int,
    totalQuestions: Int,
    onRetake: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(22.dp),
        color = Color(0xFF161D28),
        border = androidx.compose.foundation.BorderStroke(2.dp, Color(0xFF2C394F)),
        shadowElevation = 10.dp,
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF2C3720))
                    .border(2.dp, TrafficGreen, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.EmojiEvents,
                    contentDescription = null,
                    tint = TrafficGreen,
                    modifier = Modifier.size(42.dp)
                )
            }

            Text(
                text = "تهانينا! أكملت الاختبار",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            Text(
                text = "نتيجتك: $score من أصل $totalQuestions",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.ExtraBold,
                color = if (score >= totalQuestions / 2) TrafficGreen else TrafficYellow
            )

            Text(
                text = if (score == totalQuestions) {
                    "ممتاز! معرفتك بقواعد وإشارات المرور استثنائية ونموذجية."
                } else if (score >= totalQuestions / 2) {
                    "أداء جيد جداً! لديك إلمام ممتاز بمعظم إرشادات المرور والسلامة."
                } else {
                    "بداية جيدة! نوصيك بمراجعة قسم 'قواعد وإرشادات' لتعزيز ثقافتك المرورية."
                },
                style = MaterialTheme.typography.bodyMedium,
                color = Color.LightGray,
                lineHeight = 22.sp,
                modifier = Modifier.padding(horizontal = 8.dp)
            )

            Button(
                onClick = onRetake,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF1976D2),
                    contentColor = Color.White
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("btn_retake_quiz")
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("إعادة الاختبار مرة أخرى", fontWeight = FontWeight.Bold)
            }
        }
    }
}
