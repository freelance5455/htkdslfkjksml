package com.example.ui.notes

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.NoteEntity
import com.example.data.notes.BlockType
import com.example.data.notes.LineBlock
import com.example.data.notes.NoteAlignment
import com.example.data.notes.NoteFontFamily
import com.example.data.notes.RichNoteDocument
import com.example.data.notes.RichSpan
import com.example.data.notes.UndoRedoManager
import com.example.data.repository.NoteRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class NoteSortMode(val displayName: String) {
    NEWEST("Newest First"),
    TITLE_AZ("Title (A-Z)")
}

enum class AutosaveStatus {
    IDLE,
    SAVING,
    SAVED
}

data class NotesUiState(
    val allNotes: List<NoteEntity> = emptyList(),
    val filteredNotes: List<NoteEntity> = emptyList(),
    val searchQuery: String = "",
    val sortMode: NoteSortMode = NoteSortMode.NEWEST,
    val selectedSubjectFilter: Long? = null,

    // Editor state
    val isEditorOpen: Boolean = false,
    val currentEditingNoteId: Long? = null,
    val editorTitle: String = "",
    val editorDocument: RichNoteDocument = RichNoteDocument(),
    val editorSubjectId: Long? = null,
    val editorIsPinned: Boolean = false,
    val editorCreatedAt: Long = System.currentTimeMillis(),
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val autosaveStatus: AutosaveStatus = AutosaveStatus.IDLE,

    // Delete dialog
    val showDeleteDialog: Boolean = false,
    val noteToDelete: NoteEntity? = null
)

class NotesViewModel(
    private val noteRepository: NoteRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(NotesUiState())
    val uiState: StateFlow<NotesUiState> = _uiState.asStateFlow()

    private val undoRedoManager = UndoRedoManager()
    private var autosaveJob: Job? = null

    init {
        viewModelScope.launch {
            noteRepository.allNotesFlow.collect { notes ->
                _uiState.update { current ->
                    current.copy(
                        allNotes = notes,
                        filteredNotes = applyFilterAndSort(
                            notes = notes,
                            query = current.searchQuery,
                            sortMode = current.sortMode,
                            subjectFilter = current.selectedSubjectFilter
                        )
                    )
                }
            }
        }
    }

    // ==========================================
    // LIST FILTERING & SORTING (PRD section 6.1)
    // ==========================================

    fun onSearchQueryChange(query: String) {
        _uiState.update { current ->
            current.copy(
                searchQuery = query,
                filteredNotes = applyFilterAndSort(
                    notes = current.allNotes,
                    query = query,
                    sortMode = current.sortMode,
                    subjectFilter = current.selectedSubjectFilter
                )
            )
        }
    }

    fun onSortModeChange(mode: NoteSortMode) {
        _uiState.update { current ->
            current.copy(
                sortMode = mode,
                filteredNotes = applyFilterAndSort(
                    notes = current.allNotes,
                    query = current.searchQuery,
                    sortMode = mode,
                    subjectFilter = current.selectedSubjectFilter
                )
            )
        }
    }

    fun onSubjectFilterChange(subjectId: Long?) {
        _uiState.update { current ->
            current.copy(
                selectedSubjectFilter = subjectId,
                filteredNotes = applyFilterAndSort(
                    notes = current.allNotes,
                    query = current.searchQuery,
                    sortMode = current.sortMode,
                    subjectFilter = subjectId
                )
            )
        }
    }

    private fun applyFilterAndSort(
        notes: List<NoteEntity>,
        query: String,
        sortMode: NoteSortMode,
        subjectFilter: Long?
    ): List<NoteEntity> {
        val trimmed = query.trim().lowercase()
        val filtered = notes.filter { note ->
            val matchesSubject = subjectFilter == null || note.subjectId == subjectFilter
            val matchesQuery = trimmed.isEmpty() ||
                note.title.lowercase().contains(trimmed) ||
                note.plainTextPreview.lowercase().contains(trimmed)
            matchesSubject && matchesQuery
        }

        return when (sortMode) {
            NoteSortMode.NEWEST -> filtered.sortedWith(
                compareByDescending<NoteEntity> { it.isPinned }
                    .thenByDescending { it.updatedAt }
            )
            NoteSortMode.TITLE_AZ -> filtered.sortedWith(
                compareByDescending<NoteEntity> { it.isPinned }
                    .thenBy { it.title.lowercase() }
            )
        }
    }

    // ==========================================
    // EDITOR MANAGEMENT & AUTOSAVE (PRD section 6.1 & 6.2)
    // ==========================================

    fun openNewNote(defaultSubjectId: Long? = null) {
        val initialDoc = RichNoteDocument()
        val now = System.currentTimeMillis()
        undoRedoManager.initialize("", initialDoc)

        _uiState.update {
            it.copy(
                isEditorOpen = true,
                currentEditingNoteId = null,
                editorTitle = "",
                editorDocument = initialDoc,
                editorSubjectId = defaultSubjectId,
                editorIsPinned = false,
                editorCreatedAt = now,
                canUndo = false,
                canRedo = false,
                autosaveStatus = AutosaveStatus.IDLE
            )
        }
    }

    fun openEditNote(note: NoteEntity) {
        val doc = RichNoteDocument.fromJson(note.contentJson)
        undoRedoManager.initialize(note.title, doc)

        _uiState.update {
            it.copy(
                isEditorOpen = true,
                currentEditingNoteId = note.id,
                editorTitle = note.title,
                editorDocument = doc,
                editorSubjectId = note.subjectId,
                editorIsPinned = note.isPinned,
                editorCreatedAt = note.createdAt,
                canUndo = false,
                canRedo = false,
                autosaveStatus = AutosaveStatus.SAVED
            )
        }
    }

    fun closeEditor() {
        // Synchronously save pending changes before exiting
        saveImmediately()
        _uiState.update { it.copy(isEditorOpen = false, currentEditingNoteId = null) }
    }

    fun onTitleChange(newTitle: String) {
        _uiState.update { it.copy(editorTitle = newTitle) }
        undoRedoManager.pushSnapshot(newTitle, _uiState.value.editorDocument, force = false)
        updateUndoRedoStates()
        scheduleAutosave()
    }

    fun onDocumentChange(newDocument: RichNoteDocument, forceSnapshot: Boolean = false) {
        _uiState.update { it.copy(editorDocument = newDocument) }
        undoRedoManager.pushSnapshot(_uiState.value.editorTitle, newDocument, force = forceSnapshot)
        updateUndoRedoStates()
        scheduleAutosave()
    }

    fun onSubjectChange(subjectId: Long?) {
        _uiState.update { it.copy(editorSubjectId = subjectId) }
        scheduleAutosave()
    }

    fun onTogglePin() {
        val newPinned = !_uiState.value.editorIsPinned
        _uiState.update { it.copy(editorIsPinned = newPinned) }
        scheduleAutosave()
    }

    fun onTogglePinInList(note: NoteEntity) {
        viewModelScope.launch {
            noteRepository.togglePin(note.id, !note.isPinned)
        }
    }

    // Formatting Actions
    fun onFontFamilyChange(fontFamilyKey: String) {
        val updated = _uiState.value.editorDocument.copy(fontFamily = fontFamilyKey)
        onDocumentChange(updated, forceSnapshot = true)
    }

    fun onFontSizeChange(fontSizeSp: Int) {
        val bounded = fontSizeSp.coerceIn(10, 36)
        val updated = _uiState.value.editorDocument.copy(fontSize = bounded)
        onDocumentChange(updated, forceSnapshot = true)
    }

    fun onAlignmentChange(alignment: NoteAlignment) {
        val updated = _uiState.value.editorDocument.copy(alignment = alignment)
        onDocumentChange(updated, forceSnapshot = true)
    }

    fun setBlockType(blockIndex: Int, newType: BlockType) {
        val currentBlocks = _uiState.value.editorDocument.blocks.toMutableList()
        if (blockIndex in currentBlocks.indices) {
            val old = currentBlocks[blockIndex]
            currentBlocks[blockIndex] = old.copy(type = newType)
            val updatedDoc = _uiState.value.editorDocument.copy(blocks = currentBlocks)
            onDocumentChange(updatedDoc, forceSnapshot = true)
        }
    }

    fun updateBlockText(blockIndex: Int, newText: String) {
        val currentBlocks = _uiState.value.editorDocument.blocks.toMutableList()
        if (blockIndex in currentBlocks.indices) {
            val old = currentBlocks[blockIndex]
            currentBlocks[blockIndex] = old.copy(text = newText)
            val updatedDoc = _uiState.value.editorDocument.copy(blocks = currentBlocks)
            onDocumentChange(updatedDoc, forceSnapshot = false)
        }
    }

    fun toggleChecklist(blockId: String) {
        val currentBlocks = _uiState.value.editorDocument.blocks.toMutableList()
        val index = currentBlocks.indexOfFirst { it.id == blockId }
        if (index >= 0) {
            val old = currentBlocks[index]
            currentBlocks[index] = old.copy(isChecked = !old.isChecked)
            val updatedDoc = _uiState.value.editorDocument.copy(blocks = currentBlocks)
            onDocumentChange(updatedDoc, forceSnapshot = true)
        }
    }

    fun addBlock(afterIndex: Int, type: BlockType = BlockType.PARAGRAPH) {
        val currentBlocks = _uiState.value.editorDocument.blocks.toMutableList()
        val newBlock = LineBlock(type = type)
        val insertIndex = (afterIndex + 1).coerceIn(0, currentBlocks.size)
        currentBlocks.add(insertIndex, newBlock)
        val updatedDoc = _uiState.value.editorDocument.copy(blocks = currentBlocks)
        onDocumentChange(updatedDoc, forceSnapshot = true)
    }

    fun removeBlock(blockIndex: Int) {
        val currentBlocks = _uiState.value.editorDocument.blocks.toMutableList()
        if (currentBlocks.size > 1 && blockIndex in currentBlocks.indices) {
            currentBlocks.removeAt(blockIndex)
            val updatedDoc = _uiState.value.editorDocument.copy(blocks = currentBlocks)
            onDocumentChange(updatedDoc, forceSnapshot = true)
        }
    }

    fun applyInlineSpanToBlock(
        blockIndex: Int,
        start: Int,
        end: Int,
        isBold: Boolean? = null,
        isItalic: Boolean? = null,
        isUnderline: Boolean? = null,
        isStrikethrough: Boolean? = null,
        textColorHex: String? = null,
        highlightColorHex: String? = null
    ) {
        val currentBlocks = _uiState.value.editorDocument.blocks.toMutableList()
        if (blockIndex in currentBlocks.indices && end > start) {
            val old = currentBlocks[blockIndex]
            val newSpan = RichSpan(
                start = start,
                end = end,
                isBold = isBold ?: false,
                isItalic = isItalic ?: false,
                isUnderline = isUnderline ?: false,
                isStrikethrough = isStrikethrough ?: false,
                textColorHex = textColorHex,
                highlightColorHex = highlightColorHex
            )
            val updatedSpans = old.spans + newSpan
            currentBlocks[blockIndex] = old.copy(spans = updatedSpans)
            val updatedDoc = _uiState.value.editorDocument.copy(blocks = currentBlocks)
            onDocumentChange(updatedDoc, forceSnapshot = true)
        }
    }

    // ==========================================
    // UNDO & REDO (PRD section 6.2)
    // ==========================================

    fun undo() {
        val result = undoRedoManager.undo() ?: return
        val (title, doc) = result
        _uiState.update {
            it.copy(
                editorTitle = title,
                editorDocument = doc
            )
        }
        updateUndoRedoStates()
        scheduleAutosave()
    }

    fun redo() {
        val result = undoRedoManager.redo() ?: return
        val (title, doc) = result
        _uiState.update {
            it.copy(
                editorTitle = title,
                editorDocument = doc
            )
        }
        updateUndoRedoStates()
        scheduleAutosave()
    }

    private fun updateUndoRedoStates() {
        _uiState.update {
            it.copy(
                canUndo = undoRedoManager.canUndo(),
                canRedo = undoRedoManager.canRedo()
            )
        }
    }

    // ==========================================
    // AUTOSAVE & SAVE BUTTON (PRD section 6.1)
    // ==========================================

    private fun scheduleAutosave() {
        autosaveJob?.cancel()
        _uiState.update { it.copy(autosaveStatus = AutosaveStatus.SAVING) }

        autosaveJob = viewModelScope.launch {
            // Debounce for smooth typing without lag
            delay(400)
            persistCurrentNote()
            _uiState.update { it.copy(autosaveStatus = AutosaveStatus.SAVED) }
        }
    }

    fun saveNow() {
        autosaveJob?.cancel()
        viewModelScope.launch {
            persistCurrentNote()
            _uiState.update { it.copy(autosaveStatus = AutosaveStatus.SAVED) }
        }
    }

    private fun saveImmediately() {
        autosaveJob?.cancel()
        viewModelScope.launch {
            persistCurrentNote()
        }
    }

    private suspend fun persistCurrentNote() {
        val state = _uiState.value
        val title = state.editorTitle.trim()
        val doc = state.editorDocument
        val plainText = doc.toPlainText().trim()

        // Don't create an empty note if user typed nothing
        if (title.isEmpty() && plainText.isEmpty()) {
            return
        }

        val noteId = state.currentEditingNoteId
        if (noteId == null) {
            val newId = noteRepository.createNote(
                title = title.ifEmpty { "Untitled Note" },
                document = doc,
                subjectId = state.editorSubjectId,
                isPinned = state.editorIsPinned
            )
            _uiState.update { it.copy(currentEditingNoteId = newId) }
        } else {
            noteRepository.updateNote(
                id = noteId,
                title = title.ifEmpty { "Untitled Note" },
                document = doc,
                subjectId = state.editorSubjectId,
                isPinned = state.editorIsPinned,
                createdAt = state.editorCreatedAt
            )
        }
    }

    // ==========================================
    // DELETE NOTE (PRD section 6.1)
    // ==========================================

    fun openDeleteConfirm(note: NoteEntity) {
        _uiState.update {
            it.copy(
                showDeleteDialog = true,
                noteToDelete = note
            )
        }
    }

    fun openDeleteCurrentEditingNote() {
        val id = _uiState.value.currentEditingNoteId ?: return
        val note = _uiState.value.allNotes.firstOrNull { it.id == id } ?: return
        openDeleteConfirm(note)
    }

    fun closeDeleteConfirm() {
        _uiState.update {
            it.copy(
                showDeleteDialog = false,
                noteToDelete = null
            )
        }
    }

    fun confirmDeleteNote() {
        val target = _uiState.value.noteToDelete ?: return
        viewModelScope.launch {
            noteRepository.deleteNote(target.id)
            closeDeleteConfirm()
            if (_uiState.value.currentEditingNoteId == target.id) {
                _uiState.update { it.copy(isEditorOpen = false, currentEditingNoteId = null) }
            }
        }
    }
}

class NotesViewModelFactory(
    private val noteRepository: NoteRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(NotesViewModel::class.java)) {
            return NotesViewModel(noteRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
