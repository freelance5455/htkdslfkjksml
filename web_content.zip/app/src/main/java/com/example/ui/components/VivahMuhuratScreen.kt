package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAlert
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.PanchangStrings
import com.example.model.AppLanguage
import com.example.model.MuhuratCategory
import com.example.model.ShubhMuhurat
import com.example.panchang.VedicPanchangCalculator

@Composable
fun VivahMuhuratScreen(
    language: AppLanguage,
    onSetReminder: (ShubhMuhurat) -> Unit,
    initialCategory: MuhuratCategory? = null,
    onCategoryChanged: ((MuhuratCategory?) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember(initialCategory) { mutableStateOf<MuhuratCategory?>(initialCategory) }

    androidx.compose.runtime.LaunchedEffect(initialCategory) {
        selectedCategory = initialCategory
    }

    val allMuhurats = remember { VedicPanchangCalculator.getAuspiciousMuhurats() }
    val filteredMuhurats = remember(selectedCategory) {
        if (selectedCategory == null) {
            allMuhurats
        } else {
            allMuhurats.filter { it.category == selectedCategory }
        }
    }

    val chipScrollState = rememberScrollState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            // Dynamic Header Hero Banner
            val bannerTitle = when (selectedCategory) {
                MuhuratCategory.GRIHA_PRAVESH -> "🏡 नूतन मकान उद्घाटन व गृह प्रवेश मुहूर्त"
                MuhuratCategory.OFFICE_UDGHATAN -> "🏢 ऑफिस, दुकान व व्यापार उद्घाटन मुहूर्त"
                MuhuratCategory.VIVAH -> "💍 शुभ विवाह लग्न एवं पावन मुहूर्त"
                MuhuratCategory.VAHAN_KHARIDI -> "🚗 वाहन व संपत्ति क्रय मुहूर्त"
                else -> "✨ शुभ मांगलिक मुहूर्त २०२६-२७"
            }
            val bannerSubtitle = when (selectedCategory) {
                MuhuratCategory.GRIHA_PRAVESH -> "वास्तु शांति, देहरी पूजन, कलश स्थापना व स्थिर लग्न"
                MuhuratCategory.OFFICE_UDGHATAN -> "प्रतिष्ठान शुभारंभ, बही-खाता पूजन, रिबन कटिंग व कुबेर योग"
                MuhuratCategory.VIVAH -> "शुद्ध लग्न, नक्षत्र एवं सर्वार्थ सिद्धि वेला की गणना"
                MuhuratCategory.VAHAN_KHARIDI -> "सर्वार्थ सिद्धि व अमृत सिद्धि योग में क्रय"
                else -> "मकान उद्घाटन, ऑफिस मुहूर्त, विवाह व व्यवसाय शुभारंभ"
            }
            val bannerIcon = when (selectedCategory) {
                MuhuratCategory.GRIHA_PRAVESH -> Icons.Default.Home
                MuhuratCategory.OFFICE_UDGHATAN -> Icons.Default.Storefront
                MuhuratCategory.VIVAH -> Icons.Default.Favorite
                MuhuratCategory.VAHAN_KHARIDI -> Icons.Default.Celebration
                else -> Icons.Default.Star
            }
            val bannerColor = when (selectedCategory) {
                MuhuratCategory.GRIHA_PRAVESH -> Color(0xFF2E7D32)
                MuhuratCategory.OFFICE_UDGHATAN -> Color(0xFF1565C0)
                MuhuratCategory.VIVAH -> Color(0xFFC2185B)
                else -> Color(0xFFE65100)
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE0E0E0)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(bannerColor),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = bannerIcon,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(26.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = bannerTitle,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                        Text(
                            text = bannerSubtitle,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF333333)
                        )
                    }
                }
            }
        }

        // Dedicated Option Selector (मकान उद्घाटन व ऑफिस मुहूर्त Quick Switch Cards)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                androidx.compose.material3.OutlinedCard(
                    onClick = {
                        selectedCategory = MuhuratCategory.GRIHA_PRAVESH
                        onCategoryChanged?.invoke(MuhuratCategory.GRIHA_PRAVESH)
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.outlinedCardColors(
                        containerColor = if (selectedCategory == MuhuratCategory.GRIHA_PRAVESH) Color(0xFFE8F5E9) else Color.White
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        width = if (selectedCategory == MuhuratCategory.GRIHA_PRAVESH) 2.dp else 1.dp,
                        color = if (selectedCategory == MuhuratCategory.GRIHA_PRAVESH) Color(0xFF2E7D32) else Color(0xFFE0E0E0)
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "🏡", fontSize = 20.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(
                                text = "मकान उद्घाटन",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedCategory == MuhuratCategory.GRIHA_PRAVESH) Color(0xFF2E7D32) else Color.Black
                            )
                            Text(
                                text = "गृह प्रवेश व वास्तु",
                                fontSize = 9.5.sp,
                                color = Color(0xFF666666)
                            )
                        }
                    }
                }

                androidx.compose.material3.OutlinedCard(
                    onClick = {
                        selectedCategory = MuhuratCategory.OFFICE_UDGHATAN
                        onCategoryChanged?.invoke(MuhuratCategory.OFFICE_UDGHATAN)
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.outlinedCardColors(
                        containerColor = if (selectedCategory == MuhuratCategory.OFFICE_UDGHATAN) Color(0xFFE3F2FD) else Color.White
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        width = if (selectedCategory == MuhuratCategory.OFFICE_UDGHATAN) 2.dp else 1.dp,
                        color = if (selectedCategory == MuhuratCategory.OFFICE_UDGHATAN) Color(0xFF1565C0) else Color(0xFFE0E0E0)
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "🏢", fontSize = 20.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(
                                text = "ऑफिस मुहूर्त",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedCategory == MuhuratCategory.OFFICE_UDGHATAN) Color(0xFF1565C0) else Color.Black
                            )
                            Text(
                                text = "दुकान व व्यापार",
                                fontSize = 9.5.sp,
                                color = Color(0xFF666666)
                            )
                        }
                    }
                }
            }
        }

        // Category Filter Chips (Horizontal Scrollable for quick switching)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(chipScrollState),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedCategory == null,
                    onClick = {
                        selectedCategory = null
                        onCategoryChanged?.invoke(null)
                    },
                    label = { Text("सभी मुहूर्त") },
                    leadingIcon = if (selectedCategory == null) {
                        { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    } else null,
                    modifier = Modifier.testTag("filter_all")
                )

                FilterChip(
                    selected = selectedCategory == MuhuratCategory.GRIHA_PRAVESH,
                    onClick = {
                        selectedCategory = MuhuratCategory.GRIHA_PRAVESH
                        onCategoryChanged?.invoke(MuhuratCategory.GRIHA_PRAVESH)
                    },
                    label = { Text("🏡 मकान उद्घाटन") },
                    leadingIcon = if (selectedCategory == MuhuratCategory.GRIHA_PRAVESH) {
                        { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    } else null,
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFFE8F5E9),
                        selectedLabelColor = Color(0xFF2E7D32)
                    ),
                    modifier = Modifier.testTag("filter_makan_udghatan")
                )

                FilterChip(
                    selected = selectedCategory == MuhuratCategory.OFFICE_UDGHATAN,
                    onClick = {
                        selectedCategory = MuhuratCategory.OFFICE_UDGHATAN
                        onCategoryChanged?.invoke(MuhuratCategory.OFFICE_UDGHATAN)
                    },
                    label = { Text("🏢 ऑफिस मुहूर्त") },
                    leadingIcon = if (selectedCategory == MuhuratCategory.OFFICE_UDGHATAN) {
                        { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    } else null,
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFFE3F2FD),
                        selectedLabelColor = Color(0xFF1565C0)
                    ),
                    modifier = Modifier.testTag("filter_office_muhurat")
                )

                FilterChip(
                    selected = selectedCategory == MuhuratCategory.VIVAH,
                    onClick = {
                        selectedCategory = MuhuratCategory.VIVAH
                        onCategoryChanged?.invoke(MuhuratCategory.VIVAH)
                    },
                    label = { Text("💍 विवाह लग्न") },
                    leadingIcon = if (selectedCategory == MuhuratCategory.VIVAH) {
                        { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    } else null,
                    modifier = Modifier.testTag("filter_vivah")
                )

                FilterChip(
                    selected = selectedCategory == MuhuratCategory.VAHAN_KHARIDI,
                    onClick = {
                        selectedCategory = MuhuratCategory.VAHAN_KHARIDI
                        onCategoryChanged?.invoke(MuhuratCategory.VAHAN_KHARIDI)
                    },
                    label = { Text("🚗 वाहन क्रय") },
                    leadingIcon = if (selectedCategory == MuhuratCategory.VAHAN_KHARIDI) {
                        { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                    } else null,
                    modifier = Modifier.testTag("filter_vahan")
                )
            }
        }

        // Muhurat Cards List
        items(filteredMuhurats) { muhurat ->
            MuhuratCard(
                muhurat = muhurat,
                language = language,
                onSetReminder = { onSetReminder(muhurat) }
            )
        }

        // Specialized Vedic Guidelines Card depending on category
        item {
            when (selectedCategory) {
                MuhuratCategory.GRIHA_PRAVESH -> {
                    MakanUdghatanGuideCard()
                }
                MuhuratCategory.OFFICE_UDGHATAN -> {
                    OfficeUdghatanGuideCard()
                }
                else -> {
                    GeneralMuhuratRulesCard()
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun MakanUdghatanGuideCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFC8E6C9)),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = "🏡", fontSize = 22.sp)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "मकान उद्घाटन (गृह प्रवेश) वैदिक विधि व नियम",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF2E7D32)
                )
            }

            HorizontalDivider(color = Color(0xFFEEEEEE))

            Text(
                text = "• १. मंगल कलश प्रवेश: गृह स्वामिनी को सिर पर जल, अक्षत व नारियल से भरा मंगल कलश लेकर शुभ लग्न में प्रथम प्रवेश करना चाहिए।",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF222222)
            )
            Text(
                text = "• २. देहरी व वास्तु पूजन: मुख्य द्वार पर कुंकुम से स्वास्तिक, आम के पल्लव (तोरण) व ॐ अंकित करें और देहरी पूजन करें।",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF222222)
            )
            Text(
                text = "• ३. दूध उबालने की परंपरा: नए घर की रसोई में तांबे या पीतल के बर्तन में दूध उबालें। दूध का उफनना सुख व समृद्धि का प्रतीक है।",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF222222)
            )
            Text(
                text = "• ४. स्थिर लग्न चयन: वृषभ, सिंह, वृश्चिक व कुम्भ लग्न में गृह प्रवेश करने से घर में स्थायित्व, शांति व लक्ष्मी वास रहता है।",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF222222)
            )
            Text(
                text = "• ५. वर्जित समय: पंचक, भद्रा व राहुकाल के समय गृह प्रवेश व नए मकान का ताला खोलना टालें।",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFFD32F2F)
            )
        }
    }
}

@Composable
private fun OfficeUdghatanGuideCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBBDEFB)),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = "🏢", fontSize = 22.sp)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "ऑफिस व दुकान उद्घाटन (व्यापार शुभारंभ) विधि",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1565C0)
                )
            }

            HorizontalDivider(color = Color(0xFFEEEEEE))

            Text(
                text = "• १. रिबन कटिंग व देहरी पूजन: मुख्य द्वार पर शुभ मुहूर्त में लाल रिबन काटें व केसरिया स्वास्तिक बनाएं।",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF222222)
            )
            Text(
                text = "• २. गणेश-लक्ष्मी व कुबेर पूजन: सर्वप्रथम विघ्नहर्ता गणेश जी व धनदात्री महालक्ष्मी जी का विधिपूर्वक पूजन करें।",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF222222)
            )
            Text(
                text = "• ३. बही-खाता व तिजोरी स्थापना: व्यापारिक बही-खाते, कंप्यूटर व तिजोरी को उत्तर या पूर्व दिशा में कुबेर वास मानकर स्थापित करें।",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF222222)
            )
            Text(
                text = "• ४. प्रथम व्यावसायिक लेन-देन: उद्घाटन के समय पहला लेन-देन किसी आदरणीय व्यक्ति से शुभ शगुन के रूप में करवाएं।",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF222222)
            )
            Text(
                text = "• ५. मंगलकारी महामंत्र: 'ॐ श्रीं ह्रीं क्लीं महालक्ष्म्यै नमः' का 11 बार जप कर सभी आगंतुकों को प्रसाद वितरित करें।",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF222222)
            )
        }
    }
}

@Composable
private fun GeneralMuhuratRulesCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE0E0E0)),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "Info",
                    tint = Color.Black,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "वैदिक मुहूर्त के मुख्य नियम",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )
            }

            HorizontalDivider(color = Color(0xFFEEEEEE))

            Text(
                text = "• मकान उद्घाटन व गृह प्रवेश: स्थिर लग्न (वृषभ, सिंह, वृश्चिक, कुम्भ) में प्रवेश करने से घर में अक्षय शांति रहती है।",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF333333)
            )
            Text(
                text = "• ऑफिस व दुकान उद्घाटन: शुक्ल पक्ष, पुष्य व रोहिणी नक्षत्र में व्यापार आरंभ करने से अटूट समृद्धि होती है।",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF333333)
            )
            Text(
                text = "• विवाह संस्कार: गुरु व शुक्र का बाल्यकाल, वृद्धावस्था अथवा अस्त होना त्याज्य है।",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF333333)
            )
        }
    }
}

@Composable
private fun MuhuratCard(
    muhurat: ShubhMuhurat,
    language: AppLanguage,
    onSetReminder: () -> Unit
) {
    val categoryBadgeText = when (muhurat.category) {
        MuhuratCategory.GRIHA_PRAVESH -> "मकान उद्घाटन"
        MuhuratCategory.OFFICE_UDGHATAN -> "ऑफिस मुहूर्त"
        MuhuratCategory.VIVAH -> "विवाह लग्न"
        MuhuratCategory.VAHAN_KHARIDI -> "वाहन क्रय"
        else -> "शुभ मुहूर्त"
    }

    val categoryBadgeColor = when (muhurat.category) {
        MuhuratCategory.GRIHA_PRAVESH -> Color(0xFF2E7D32)
        MuhuratCategory.OFFICE_UDGHATAN -> Color(0xFF1565C0)
        MuhuratCategory.VIVAH -> Color(0xFFC2185B)
        else -> Color.Black
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE0E0E0)),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(categoryBadgeColor.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (muhurat.category) {
                                MuhuratCategory.VIVAH -> Icons.Default.Favorite
                                MuhuratCategory.GRIHA_PRAVESH -> Icons.Default.Home
                                MuhuratCategory.OFFICE_UDGHATAN -> Icons.Default.Storefront
                                MuhuratCategory.VAHAN_KHARIDI -> Icons.Default.Celebration
                                else -> Icons.Default.Star
                            },
                            contentDescription = null,
                            tint = categoryBadgeColor,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${muhurat.dateString} (${muhurat.dayOfWeek})",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.Black
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(categoryBadgeColor.copy(alpha = 0.15f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = categoryBadgeText,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = categoryBadgeColor
                                )
                            }
                        }
                        Text(
                            text = "${muhurat.tithi} • नक्षत्र: ${muhurat.nakshatra}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF333333),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Button(
                    onClick = onSetReminder,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.Black,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("muhurat_remind_${muhurat.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.AddAlert,
                        contentDescription = "Alert",
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "अलर्ट",
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = Color(0xFFEEEEEE))
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "शुभ लग्न / वेला:",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF666666)
                    )
                    Text(
                        text = muhurat.auspiciousLagna,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "सटीक समय अवधि:",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color(0xFF666666)
                    )
                    Text(
                        text = muhurat.timings,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = categoryBadgeColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "• ${muhurat.notes}",
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF444444),
                lineHeight = 16.sp
            )
        }
    }
}
