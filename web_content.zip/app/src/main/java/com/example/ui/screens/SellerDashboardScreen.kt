package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.Auction
import com.example.data.model.AuctionStatus
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.data.model.Wallet
import com.example.ui.components.CommissionBreakdownCard
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.FeaturedBadge
import com.example.ui.components.LiveCountdownPill
import com.example.ui.components.LotImageDisplay
import com.example.ui.theme.MonoFontFamily
import com.example.util.AUCTION_CATEGORIES
import com.example.util.FEATURED_AUCTION_FEE_NAIRA
import com.example.util.compressImageUriToDataUrl
import com.example.util.formatNaira

@Composable
fun SellerDashboardScreen(
    auctionsState: UiState<List<Auction>>,
    profile: UserProfile?,
    wallet: Wallet?,
    nowMillis: Long,
    currentUserId: String,
    isBusy: Boolean,
    onOpenAuction: (String) -> Unit,
    onCreateAuction: (
        title: String,
        description: String,
        category: String,
        imageItems: List<String>,
        startingBid: Long,
        minIncrement: Long,
        durationHours: Long,
        featureListing: Boolean
    ) -> Unit,
    onUpgradeFeatured: (auctionId: String, title: String) -> Unit,
    onCancelAuction: (auctionId: String) -> Unit
) {
    var showCreateDialog by remember { mutableStateOf(false) }

    val allAuctions = (auctionsState as? UiState.Success)?.data ?: emptyList()
    val myListings = remember(allAuctions, currentUserId) {
        allAuctions.filter { it.sellerId == currentUserId }
    }
    val activeCount = remember(myListings, nowMillis) {
        myListings.count { it.effectiveStatus(nowMillis) == AuctionStatus.ACTIVE }
    }
    val grossSales = remember(myListings) {
        myListings.filter { it.status == "SETTLED" }.sumOf { it.currentBid }
    }

    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Seller Dashboard",
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "3% flat commission • ₦2,000 Featured boost",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Button(
                        onClick = { showCreateDialog = true },
                        enabled = profile != null && !isBusy,
                        modifier = Modifier.testTag("seller_new_auction_button"),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("List Lot")
                    }
                }
            }

            // Seller KPI Row
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    SellerMetricCard(
                        label = "Active Lots",
                        value = activeCount.toString(),
                        modifier = Modifier.weight(1f)
                    )
                    SellerMetricCard(
                        label = "Settled Sales",
                        value = formatNaira(grossSales),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    SellerMetricCard(
                        label = "Net Earned (97%)",
                        value = formatNaira(wallet?.totalEarned ?: 0L),
                        modifier = Modifier.weight(1f)
                    )
                    SellerMetricCard(
                        label = "3% Fees Paid",
                        value = formatNaira(wallet?.totalCommissionPaid ?: 0L),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Commission Formula Example
            item {
                CommissionBreakdownCard(
                    grossAmount = 500000L,
                    title = "Fee Example: ₦500,000 Sale at 3% Commission"
                )
            }

            item {
                Text(
                    text = "My Listed Lots (${myListings.size})",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            if (myListings.isEmpty()) {
                item {
                    EmptyStateCard(
                        title = "You Haven't Listed Any Lots",
                        subtitle = "Upload photos with Android Photo Picker, set your reserve & countdown, and optionally promote with a ₦2,000 Featured placement.",
                        actionLabel = "Create First Listing",
                        onAction = { showCreateDialog = true }
                    )
                }
            } else {
                items(myListings, key = { it.id }) { lot ->
                    SellerLotCard(
                        lot = lot,
                        nowMillis = nowMillis,
                        isBusy = isBusy,
                        onOpen = { onOpenAuction(lot.id) },
                        onFeature = { onUpgradeFeatured(lot.id, lot.title) },
                        onCancel = { onCancelAuction(lot.id) }
                    )
                }
            }
        }
    }

    if (showCreateDialog && profile != null) {
        CreateAuctionDialog(
            walletBalance = wallet?.availableBalance ?: 0L,
            onDismiss = { showCreateDialog = false },
            onSubmit = { title, desc, cat, imgs, startBid, minInc, hours, featured ->
                onCreateAuction(title, desc, cat, imgs, startBid, minInc, hours, featured)
                showCreateDialog = false
            }
        )
    }
}

@Composable
private fun SellerMetricCard(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium.copy(fontFamily = MonoFontFamily),
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun SellerLotCard(
    lot: Auction,
    nowMillis: Long,
    isBusy: Boolean,
    onOpen: () -> Unit,
    onFeature: () -> Unit,
    onCancel: () -> Unit
) {
    val st = lot.effectiveStatus(nowMillis)
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                LotImageDisplay(
                    imageSpec = lot.imageItems.firstOrNull(),
                    contentDescription = lot.title,
                    modifier = Modifier
                        .size(72.dp)
                        .clip(RoundedCornerShape(14.dp))
                )
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (lot.featured) FeaturedBadge()
                        LiveCountdownPill(endsAt = lot.endsAt, nowMillis = nowMillis, status = lot.status)
                    }
                    Text(
                        text = lot.title,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = if (lot.bidCount > 0L) {
                            "Highest: ${formatNaira(lot.currentBid)} (${lot.bidCount} bids • ${lot.highestBidderNumber})"
                        } else {
                            "Opening: ${formatNaira(lot.startingBid)} • 0 bids"
                        },
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = MonoFontFamily),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            if (st == AuctionStatus.ACTIVE) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (!lot.featured) {
                        Button(
                            onClick = onFeature,
                            enabled = !isBusy,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Star, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Feature ₦2,000", maxLines = 1)
                        }
                    }
                    if (lot.bidCount == 0L) {
                        OutlinedButton(
                            onClick = onCancel,
                            enabled = !isBusy,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Cancel Lot")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CreateAuctionDialog(
    walletBalance: Long,
    onDismiss: () -> Unit,
    onSubmit: (
        title: String,
        description: String,
        category: String,
        imageItems: List<String>,
        startingBid: Long,
        minIncrement: Long,
        durationHours: Long,
        featureListing: Boolean
    ) -> Unit
) {
    val context = LocalContext.current
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Watches") }
    var startingBidText by remember { mutableStateOf("100000") }
    var minIncText by remember { mutableStateOf("5000") }
    var durationHours by remember { mutableLongStateOf(24L) }
    var featureListing by remember { mutableStateOf(false) }
    val selectedImages = remember { mutableStateListOf<String>("preset:chronograph") }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 3)
    ) { uris ->
        uris.forEach { uri ->
            if (selectedImages.size < 4) {
                val dataUrl = compressImageUriToDataUrl(context, uri)
                if (dataUrl != null) {
                    selectedImages.add(0, dataUrl)
                }
            }
        }
    }

    val startingBid = startingBidText.toLongOrNull() ?: 0L
    val minInc = minIncText.toLongOrNull() ?: 0L
    val canFeature = walletBalance >= FEATURED_AUCTION_FEE_NAIRA
    val isValid = title.trim().length >= 3 &&
        description.trim().length >= 5 &&
        startingBid >= 100L &&
        minInc >= 100L &&
        (!featureListing || canFeature)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create Auction Listing") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Item Title") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("create_lot_title")
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Provenance & Condition") },
                    minLines = 2,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("create_lot_description")
                )

                Text("Category", style = MaterialTheme.typography.labelMedium)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(AUCTION_CATEGORIES.filter { it != "All" }) { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat) }
                        )
                    }
                }

                // Pictures (Android Photo Picker + Built-in Presets)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Pictures (${selectedImages.size}/4)", style = MaterialTheme.typography.labelMedium)
                    TextButton(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        }
                    ) {
                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Pick Photos")
                    }
                }
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(selectedImages) { img ->
                        Box(modifier = Modifier.size(64.dp)) {
                            LotImageDisplay(
                                imageSpec = img,
                                contentDescription = "Selected lot picture",
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(RoundedCornerShape(10.dp))
                            )
                            IconButton(
                                onClick = { selectedImages.remove(img) },
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .size(22.dp)
                            ) {
                                Surface(
                                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
                                    shape = RoundedCornerShape(50.dp)
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "Remove", modifier = Modifier.size(14.dp))
                                }
                            }
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = startingBidText,
                        onValueChange = { startingBidText = it.filter { c -> c.isDigit() } },
                        label = { Text("Starting Bid (₦)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = minIncText,
                        onValueChange = { minIncText = it.filter { c -> c.isDigit() } },
                        label = { Text("Min Step (₦)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Text("Duration", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(6L to "6h", 24L to "24h", 72L to "3d", 168L to "7d").forEach { (hrs, lbl) ->
                        FilterChip(
                            selected = durationHours == hrs,
                            onClick = { durationHours = hrs },
                            label = { Text(lbl) }
                        )
                    }
                }

                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Feature Auction (₦2,000)",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                            Text(
                                text = if (canFeature) "Pin to top carousel • Wallet: ${formatNaira(walletBalance)}"
                                else "Fund wallet with at least ₦2,000 to feature",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                        Switch(
                            checked = featureListing,
                            onCheckedChange = { if (canFeature || !it) featureListing = it }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSubmit(
                        title.trim(),
                        description.trim(),
                        category,
                        selectedImages.toList(),
                        startingBid,
                        minInc,
                        durationHours,
                        featureListing
                    )
                },
                enabled = isValid,
                modifier = Modifier.testTag("publish_auction_button")
            ) {
                Text("Publish Live")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
