package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Public
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.ArkGroup
import com.example.ui.components.EmptyStateGlassCard
import com.example.ui.components.GlowingPillButton
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.UserBadgeChip
import com.example.ui.theme.ArkThemeTokens

@Composable
fun GroupsScreen(
    myGroups: List<ArkGroup>,
    publicCommunities: List<ArkGroup>,
    currentUserId: String,
    onCreateGroup: (name: String, desc: String, theme: String, isPrivate: Boolean, allowDownloads: Boolean) -> Unit,
    onJoinByCode: (String) -> Unit,
    onJoinPublic: (String) -> Unit,
    onOpenGroup: (String) -> Unit,
    onBack: (() -> Unit)? = null
) {
    BackHandler(enabled = onBack != null) { onBack?.invoke() }
    val colors = ArkThemeTokens.colors
    var selectedTab by remember { mutableIntStateOf(0) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var showJoinDialog by remember { mutableStateOf(false) }
    var inviteInput by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Start
            ) {
                if (onBack != null) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                    }
                }
                Column {
                    Text("Groups & Squads", style = MaterialTheme.typography.headlineMedium, color = colors.textPrimary)
                    Text("Private chat, photo albums & group games", style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                GlowingPillButton(
                    text = "Create Group",
                    icon = Icons.Default.Add,
                    onClick = { showCreateDialog = true },
                    modifier = Modifier.weight(1f).testTag("create_group_button")
                )
                OutlinedButton(
                    onClick = { showJoinDialog = true },
                    modifier = Modifier.height(50.dp).weight(1f).testTag("join_group_code_button"),
                    shape = RoundedCornerShape(25.dp)
                ) {
                    Icon(Icons.Default.Key, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Join Code")
                }
            }
        }

        TabRow(selectedTabIndex = selectedTab, containerColor = colors.glassSurface) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("My Groups (${myGroups.size})") })
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Discover (${publicCommunities.size})") })
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                        .clip(RoundedCornerShape(22.dp))
                ) {
                    AsyncImage(
                        model = R.drawable.img_community_cover,
                        contentDescription = "Communities banner",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.Bottom
                    ) {
                        Text(
                            text = if (selectedTab == 0) "Your Private Spaces" else "Moderated Public Communities",
                            style = MaterialTheme.typography.titleMedium,
                            color = colors.textPrimary
                        )
                    }
                }
            }

            if (selectedTab == 0) {
                if (myGroups.isEmpty()) {
                    item {
                        EmptyStateGlassCard(
                            icon = Icons.Default.Groups,
                            title = "Create Your First Squad",
                            subtitle = "Private groups keep chat, photo albums, and multiplayer games safe among friends.",
                            actionLabel = "Create Private Group",
                            onAction = { showCreateDialog = true }
                        )
                    }
                } else {
                    items(myGroups, key = { it.id }) { grp ->
                        GroupCard(
                            group = grp,
                            isMember = true,
                            onOpen = { onOpenGroup(grp.id) },
                            onJoin = {}
                        )
                    }
                }
            } else {
                val discoverable = publicCommunities.filter { !it.memberUids.contains(currentUserId) }
                if (discoverable.isEmpty()) {
                    item {
                        EmptyStateGlassCard(
                            icon = Icons.Default.Public,
                            title = "No New Communities Right Now",
                            subtitle = "Create a public study, coding, or gaming club to share with the ARK community!"
                        )
                    }
                } else {
                    items(discoverable, key = { it.id }) { grp ->
                        GroupCard(
                            group = grp,
                            isMember = false,
                            onOpen = { onOpenGroup(grp.id) },
                            onJoin = { onJoinPublic(grp.id) }
                        )
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        CreateGroupDialog(
            onDismiss = { showCreateDialog = false },
            onCreate = { name, desc, theme, isPriv, allowDl ->
                onCreateGroup(name, desc, theme, isPriv, allowDl)
                showCreateDialog = false
            }
        )
    }

    if (showJoinDialog) {
        AlertDialog(
            onDismissRequest = { showJoinDialog = false },
            title = { Text("Join Private Group") },
            text = {
                OutlinedTextField(
                    value = inviteInput,
                    onValueChange = { inviteInput = it.uppercase().take(12) },
                    label = { Text("6-character Invite Code") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("group_invite_code_input")
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onJoinByCode(inviteInput)
                        inviteInput = ""
                        showJoinDialog = false
                    }
                ) { Text("Join") }
            },
            dismissButton = {
                TextButton(onClick = { showJoinDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun GroupCard(
    group: ArkGroup,
    isMember: Boolean,
    onOpen: () -> Unit,
    onJoin: () -> Unit
) {
    val colors = ArkThemeTokens.colors
    LiquidGlassCard(
        modifier = Modifier.fillMaxWidth(),
        accentColor = if (group.isPrivate) colors.violet else colors.cyan,
        onClick = if (isMember) onOpen else null
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (group.isPrivate) Icons.Default.Lock else Icons.Default.Public,
                        contentDescription = null,
                        tint = if (group.isPrivate) colors.violet else colors.cyan,
                        modifier = Modifier.padding(end = 6.dp)
                    )
                    Text(
                        group.name,
                        style = MaterialTheme.typography.titleMedium,
                        color = colors.textPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    group.description.ifBlank { "Squad hangout • Chat, albums & games" },
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textSecondary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    UserBadgeChip(label = "${group.memberCount} Members", accent = colors.cyan)
                    if (isMember) {
                        UserBadgeChip(label = "Code: ${group.inviteCode}", accent = colors.gold)
                    }
                }
            }
            if (!isMember) {
                Spacer(Modifier.width(8.dp))
                GlowingPillButton(text = "Join", onClick = onJoin)
            }
        }
    }
}

@Composable
private fun CreateGroupDialog(
    onDismiss: () -> Unit,
    onCreate: (String, String, String, Boolean, Boolean) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var theme by remember { mutableStateOf("aurora") }
    var isPrivate by remember { mutableStateOf(true) }
    var allowDownloads by remember { mutableStateOf(true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create ARK Group") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(40) },
                    label = { Text("Group Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("create_group_name_input")
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it.take(200) },
                    label = { Text("Description") },
                    maxLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Theme", style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("aurora", "cyber", "emerald").forEach { t ->
                        FilterChip(
                            selected = theme == t,
                            onClick = { theme = t },
                            label = { Text(t.replaceFirstChar { it.uppercase() }) }
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Private (Invite-Only)")
                    Switch(checked = isPrivate, onCheckedChange = { isPrivate = it })
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Allow Photo Downloads")
                    Switch(checked = allowDownloads, onCheckedChange = { allowDownloads = it })
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.trim().length >= 2,
                onClick = { onCreate(name, description, theme, isPrivate, allowDownloads) }
            ) { Text("Create") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
