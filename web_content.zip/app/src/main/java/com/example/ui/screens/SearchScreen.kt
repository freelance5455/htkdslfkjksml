package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ClearAll
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.BookingStatus
import com.example.data.model.ClientWithBookings
import com.example.data.model.SearchFilter
import com.example.ui.components.DatePickerTextField
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.SdTopAppBar
import com.example.ui.theme.BackgroundWhite
import com.example.ui.theme.BorderLight
import com.example.ui.theme.GoldSecondary
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.SurfaceLightGray
import com.example.ui.theme.TextSecondary

@Composable
fun SearchScreen(
    filter: SearchFilter,
    results: List<ClientWithBookings>,
    onUpdateFilter: ((SearchFilter) -> SearchFilter) -> Unit,
    onClearFilter: () -> Unit,
    onBack: () -> Unit,
    onOpenClientDetail: (Long) -> Unit,
) {
    var filtersExpanded by remember { mutableStateOf(true) }

    Scaffold(
        containerColor = SurfaceLightGray,
        topBar = {
            SdTopAppBar(
                title = "البحث المتقدم",
                subtitle = "${results.size} نتيجة مطابقة",
                onBack = onBack,
                actions = {
                    if (filter.hasAnyCriteria) {
                        TextButton(
                            onClick = onClearFilter,
                            modifier = Modifier.testTag("search_clear_button"),
                        ) {
                            Icon(Icons.Default.ClearAll, contentDescription = null, tint = GoldSecondary)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("مسح", color = GoldSecondary, fontWeight = FontWeight.Bold)
                        }
                    }
                },
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = BackgroundWhite),
                    border = BorderStroke(1.dp, BorderLight),
                    shape = RoundedCornerShape(16.dp),
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.FilterAlt, contentDescription = null, tint = NavyPrimary)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "معايير البحث المتعدد (يمكن الجمع بينها)",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = NavyPrimary,
                                    fontWeight = FontWeight.Bold,
                                )
                            }
                            OutlinedButton(
                                onClick = { filtersExpanded = !filtersExpanded },
                            ) {
                                Icon(
                                    imageVector = if (filtersExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                    contentDescription = null,
                                )
                                Text(if (filtersExpanded) "إخفاء" else "إظهار")
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            SearchTextField(
                                value = filter.clientCode,
                                onValueChange = { v -> onUpdateFilter { it.copy(clientCode = v) } },
                                label = "كود العميل",
                                modifier = Modifier.weight(1f),
                                testTag = "search_code_input",
                            )
                            SearchTextField(
                                value = filter.fullName,
                                onValueChange = { v -> onUpdateFilter { it.copy(fullName = v) } },
                                label = "اسم العميل",
                                modifier = Modifier.weight(1.4f),
                                testTag = "search_name_input",
                            )
                        }

                        AnimatedVisibility(visible = filtersExpanded) {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    SearchTextField(
                                        value = filter.phone,
                                        onValueChange = { v -> onUpdateFilter { it.copy(phone = v) } },
                                        label = "رقم الهاتف",
                                        modifier = Modifier.weight(1f),
                                        testTag = "search_phone_input",
                                    )
                                    SearchTextField(
                                        value = filter.passportNumber,
                                        onValueChange = { v -> onUpdateFilter { it.copy(passportNumber = v) } },
                                        label = "رقم الجواز",
                                        modifier = Modifier.weight(1f),
                                        testTag = "search_passport_input",
                                    )
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    SearchTextField(
                                        value = filter.companyName,
                                        onValueChange = { v -> onUpdateFilter { it.copy(companyName = v) } },
                                        label = "شركة السياحة",
                                        modifier = Modifier.weight(1f),
                                        testTag = "search_company_input",
                                    )
                                    DatePickerTextField(
                                        label = "تاريخ رحلة محدد",
                                        value = filter.exactTripDate,
                                        onValueSelected = { v -> onUpdateFilter { it.copy(exactTripDate = v) } },
                                        modifier = Modifier.weight(1f),
                                        testTag = "search_exact_date_input",
                                    )
                                }

                                Text(
                                    text = "نطاق تاريخ الرحلة (من - إلى):",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = TextSecondary,
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    DatePickerTextField(
                                        label = "من تاريخ",
                                        value = filter.tripDateFrom,
                                        onValueSelected = { v -> onUpdateFilter { it.copy(tripDateFrom = v) } },
                                        modifier = Modifier.weight(1f),
                                        testTag = "search_date_from",
                                    )
                                    DatePickerTextField(
                                        label = "إلى تاريخ",
                                        value = filter.tripDateTo,
                                        onValueSelected = { v -> onUpdateFilter { it.copy(tripDateTo = v) } },
                                        modifier = Modifier.weight(1f),
                                        testTag = "search_date_to",
                                    )
                                }

                                Text(
                                    text = "حالة الحجز:",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = TextSecondary,
                                )
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    FilterChip(
                                        selected = filter.status == null,
                                        onClick = { onUpdateFilter { it.copy(status = null) } },
                                        label = { Text("الكل") },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = NavyPrimary,
                                            selectedLabelColor = GoldSecondary,
                                        ),
                                    )
                                    BookingStatus.entries.forEach { st ->
                                        FilterChip(
                                            selected = filter.status == st,
                                            onClick = {
                                                onUpdateFilter {
                                                    it.copy(status = if (it.status == st) null else st)
                                                }
                                            },
                                            label = { Text(st.arabicLabel) },
                                            colors = FilterChipDefaults.filterChipColors(
                                                selectedContainerColor = NavyPrimary,
                                                selectedLabelColor = GoldSecondary,
                                            ),
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (results.isEmpty()) {
                item {
                    EmptyStateCard(
                        icon = Icons.Default.Search,
                        title = "لا توجد نتائج مطابقة",
                        subtitle = "حاول تخفيف بعض شروط البحث أو مسح الفلاتر الحالية.",
                        actionLabel = if (filter.hasAnyCriteria) "مسح جميع الفلاتر" else null,
                        onAction = if (filter.hasAnyCriteria) onClearFilter else null,
                    )
                }
            } else {
                items(results, key = { it.client.id }) { item ->
                    ClientSummaryCard(
                        item = item,
                        onClick = { onOpenClientDetail(item.client.id) },
                    )
                }
            }
        }
    }
}

@Composable
private fun SearchTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    testTag: String? = null,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        singleLine = true,
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = NavyPrimary,
            unfocusedBorderColor = BorderLight,
            focusedContainerColor = BackgroundWhite,
            unfocusedContainerColor = BackgroundWhite,
        ),
        modifier = modifier
            .fillMaxWidth()
            .then(if (testTag != null) Modifier.testTag(testTag) else Modifier),
    )
}
