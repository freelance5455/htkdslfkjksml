package com.example.ui

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.chess.AVAILABLE_BOARD_THEMES
import com.example.chess.AnalysisEngines
import com.example.chess.BoardTheme
import com.example.chess.ChessBoardState
import com.example.chess.ChessEngineCore
import com.example.chess.ChessTreeManager
import com.example.chess.EngineChoice
import com.example.chess.EngineEvaluation
import com.example.chess.PieceColor
import com.example.chess.PieceType
import com.example.chess.Square
import com.example.data.BookEntity
import com.example.data.CatalogDiagramEntity
import com.example.data.ImportedGameEntity
import com.example.data.MoonChessDatabase
import com.example.data.MoonChessRepository
import com.example.data.NoteEntity
import com.example.data.PdfAnnotationStroke
import com.example.data.PmsPositionEntity
import com.example.data.PrincipleEntity
import com.example.data.PrinciplePhase
import com.example.pdf.PdfDocumentController
import com.example.pdf.PdfSearchMatch
import com.example.pdf.SampleChessPdfGenerator
import com.example.scanner.CropRect
import com.example.scanner.DiagramRecognitionPipeline
import com.example.scanner.DiagramScanResult
import com.example.scanner.ScannerCrop
import com.example.scanner.ScannerFenAndVoting
import com.example.scanner.ScannerNcc
import com.example.scanner.TemplateCoverage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID
import kotlin.math.roundToInt

enum class AppSection(val title: String) {
    READER("MoonChess Reader"),
    LIBRARY("Book Library"),
    NOTES("My Notes"),
    PRINCIPLES("Principles"),
    GAMES("Import Games")
}

data class ActiveSensorState(
    val pageNumber: Int,
    val normX: Float, // [0..1]
    val normY: Float, // [0..1]
    val normW: Float, // [0..1]
    val normH: Float, // [0..1]
    val isScanning: Boolean = false,
    val preferredTurn: Char = 'w',
    val lastResult: DiagramScanResult? = null,
    val cleanCropBitmap: Bitmap? = null,
    val gridCropBitmap: Bitmap? = null
)

data class BatchScanState(
    val isRunning: Boolean = false,
    val isPaused: Boolean = false,
    val currentPage: Int = 0,
    val totalPages: Int = 0,
    val diagramsFound: Int = 0
)

@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
class MoonChessViewModel(application: Application) : AndroidViewModel(application) {

    val repository = MoonChessRepository(
        application.applicationContext,
        MoonChessDatabase.getInstance(application.applicationContext).dao()
    )

    // ---- Navigation & Active Section ----
    private val _activeSection = MutableStateFlow(AppSection.LIBRARY)
    val activeSection: StateFlow<AppSection> = _activeSection.asStateFlow()

    // ---- Library & Active PDF Book ----
    val books: StateFlow<List<BookEntity>> = repository.booksFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _activeBook = MutableStateFlow<BookEntity?>(null)
    val activeBook: StateFlow<BookEntity?> = _activeBook.asStateFlow()

    private val _pdfController = MutableStateFlow<PdfDocumentController?>(null)
    val pdfController: StateFlow<PdfDocumentController?> = _pdfController.asStateFlow()

    private val _currentPage = MutableStateFlow(1)
    val currentPage: StateFlow<Int> = _currentPage.asStateFlow()

    private val _zoomScale = MutableStateFlow(1.0f)
    val zoomScale: StateFlow<Float> = _zoomScale.asStateFlow()

    // ---- PDF Search ----
    private val _isSearchOpen = MutableStateFlow(false)
    val isSearchOpen: StateFlow<Boolean> = _isSearchOpen.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _searchMatches = MutableStateFlow<List<PdfSearchMatch>>(emptyList())
    val searchMatches: StateFlow<List<PdfSearchMatch>> = _searchMatches.asStateFlow()

    private val _currentMatchIndex = MutableStateFlow(0)
    val currentMatchIndex: StateFlow<Int> = _currentMatchIndex.asStateFlow()

    private val _isSearchingPdf = MutableStateFlow(false)
    val isSearchingPdf: StateFlow<Boolean> = _isSearchingPdf.asStateFlow()

    // ---- PDF Page Annotations ----
    val pageAnnotationsMap: StateFlow<Map<Int, List<PdfAnnotationStroke>>> = _activeBook
        .flatMapLatest { book ->
            if (book == null) flowOf(emptyMap())
            else repository.observeBookAnnotations(book.id).map { list ->
                list.associate { it.pageNumber to repository.parseStrokesJson(it.strokesJson) }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    // ---- Book Learned NCC Templates & Catalog ----
    val activeBookTemplateCoverage: StateFlow<TemplateCoverage> = _activeBook
        .flatMapLatest { book ->
            if (book == null) flowOf(ScannerNcc.calculateTemplateCoverage(emptyMap()))
            else repository.observeBookTemplates(book.id).map { entities ->
                val map = repository.decodeTemplateEntities(entities)
                ScannerNcc.calculateTemplateCoverage(map)
            }
        }
        .stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            ScannerNcc.calculateTemplateCoverage(emptyMap())
        )

    val catalogDiagrams: StateFlow<List<CatalogDiagramEntity>> = _activeBook
        .flatMapLatest { book ->
            if (book == null) flowOf(emptyList())
            else repository.observeCatalogDiagrams(book.id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // ---- Docked Board Drag & Size State (0%..75%, default 48% matching screenshot) ----
    private val _boardSizePercent = MutableStateFlow(48f)
    val boardSizePercent: StateFlow<Float> = _boardSizePercent.asStateFlow()

    private var lastNonZeroBoardPercent = 48f

    // ---- Chessboard Game & Analysis State ----
    private val _boardState = MutableStateFlow(ChessTreeManager.createInitialState())
    val boardState: StateFlow<ChessBoardState> = _boardState.asStateFlow()

    private val _boardTheme = MutableStateFlow(AVAILABLE_BOARD_THEMES.first())
    val boardTheme: StateFlow<BoardTheme> = _boardTheme.asStateFlow()

    private val _isEngineEnabled = MutableStateFlow(true)
    val isEngineEnabled: StateFlow<Boolean> = _isEngineEnabled.asStateFlow()

    private val _engineChoice = MutableStateFlow(EngineChoice.VCH_LOCAL)
    val engineChoice: StateFlow<EngineChoice> = _engineChoice.asStateFlow()

    private val _engineDepth = MutableStateFlow(3)
    val engineDepth: StateFlow<Int> = _engineDepth.asStateFlow()

    private val _engineEval = MutableStateFlow<EngineEvaluation?>(null)
    val engineEval: StateFlow<EngineEvaluation?> = _engineEval.asStateFlow()

    private var engineJob: Job? = null

    // ---- Diagram Sensor & Batch Scanner ----
    private val _activeSensor = MutableStateFlow<ActiveSensorState?>(null)
    val activeSensor: StateFlow<ActiveSensorState?> = _activeSensor.asStateFlow()

    private val _batchScanState = MutableStateFlow(BatchScanState())
    val batchScanState: StateFlow<BatchScanState> = _batchScanState.asStateFlow()
    private var batchJob: Job? = null

    // ---- Notes, Principles & PMS & Imported Games ----
    val notes: StateFlow<List<NoteEntity>> = repository.notesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val principles: StateFlow<List<PrincipleEntity>> = repository.principlesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pmsPositions: StateFlow<List<PmsPositionEntity>> = repository.pmsPositionsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val importedGames: StateFlow<List<ImportedGameEntity>> = repository.importedGamesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // ---- Toast / Status Banner ----
    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    // ---- External URL Event (for Stockfish 19 & Lichess FEN transfer) ----
    private val _openExternalUrl = MutableStateFlow<String?>(null)
    val openExternalUrl: StateFlow<String?> = _openExternalUrl.asStateFlow()

    init {
        restoreSavedSession()
        triggerEngineIfActive()
    }

    private fun restoreSavedSession() {
        viewModelScope.launch {
            repository.getSetting("boardSizePercent")?.toFloatOrNull()?.let { saved ->
                val clamped = saved.coerceIn(0f, 75f)
                _boardSizePercent.value = clamped
                if (clamped >= 15f) lastNonZeroBoardPercent = clamped
            }
            repository.getSetting("boardThemeId")?.let { id ->
                AVAILABLE_BOARD_THEMES.firstOrNull { it.id == id }?.let { _boardTheme.value = it }
            }
            val lastBookId = repository.getSetting("lastOpenedBookId")
            if (!lastBookId.isNullOrBlank()) {
                val book = repository.getBookById(lastBookId)
                if (book != null && File(book.localFilePath).exists()) {
                    openBookInternal(book)
                }
            }
        }
    }

    fun showToast(msg: String) {
        _toastMessage.value = msg
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    fun consumeExternalUrl() {
        _openExternalUrl.value = null
    }

    // ---- Section Navigation ----

    fun selectSection(section: AppSection) {
        if (section == AppSection.READER && _activeBook.value == null) {
            _activeSection.value = AppSection.LIBRARY
        } else {
            _activeSection.value = section
        }
    }

    fun navigateBackToLibrary() {
        viewModelScope.launch {
            _activeSensor.value = null
            _pdfController.value?.close()
            _pdfController.value = null
            _activeBook.value = null
            repository.setSetting("lastOpenedBookId", "")
            _activeSection.value = AppSection.LIBRARY
        }
    }

    // ---- Book Management & PDF Reading ----

    fun importPdfFromUri(uri: Uri) {
        viewModelScope.launch {
            try {
                showToast("Importing PDF book...")
                val book = repository.importPdfUri(uri)
                openBookInternal(book)
                showToast("Opened ${book.title}")
            } catch (e: Exception) {
                showToast("Could not import PDF: ${e.localizedMessage ?: "Invalid file"}")
            }
        }
    }

    fun generateAndOpenSampleBook(isLargeBook: Boolean) {
        viewModelScope.launch {
            try {
                val pages = if (isLargeBook) 60 else 12
                val filename = if (isLargeBook) "grandmaster_anthology_60p.pdf" else "botvinnik_capablanca_primer_12p.pdf"
                val title = if (isLargeBook) {
                    "Grandmaster Anthology (60 Pages)"
                } else {
                    "Botvinnik & Capablanca Study Primer"
                }
                showToast("Preparing offline PDF ($pages pages)...")
                val file = SampleChessPdfGenerator.generateSamplePdfFile(getApplication(), filename, pages)
                val book = repository.registerGeneratedPdfFile(file, title)
                // Seed book's 26 Staunton piece templates from printed calibration sheet so NCC works <10ms offline
                val (calBmp, calGrid) = SampleChessPdfGenerator.createPrintedBookCalibrationPair()
                repository.learnTemplatesFromConfirmedScan(book.id, calBmp, calGrid)
                openBookInternal(book)
                showToast("Ready: $title")
            } catch (e: Exception) {
                showToast("Failed to create sample PDF: ${e.localizedMessage}")
            }
        }
    }

    fun openBook(book: BookEntity) {
        viewModelScope.launch {
            openBookInternal(book)
        }
    }

    private suspend fun openBookInternal(book: BookEntity) {
        val file = File(book.localFilePath)
        if (!file.exists()) {
            showToast("Book file missing on device.")
            return
        }
        _pdfController.value?.close()
        val controller = PdfDocumentController(file)
        val total = controller.open()
        val updatedBook = book.copy(totalPages = total)
        _activeBook.value = updatedBook
        _pdfController.value = controller
        _currentPage.value = updatedBook.lastReadPage.coerceIn(1, total)
        _zoomScale.value = updatedBook.zoom.coerceIn(0.75f, 3.0f)
        _activeSensor.value = null
        _activeSection.value = AppSection.READER
        repository.setSetting("lastOpenedBookId", updatedBook.id)
    }

    fun deleteBook(book: BookEntity) {
        viewModelScope.launch {
            if (_activeBook.value?.id == book.id) {
                navigateBackToLibrary()
            }
            repository.deleteBook(book)
            showToast("Removed ${book.title}")
        }
    }

    fun onPageVisible(pageNumber: Int) {
        val book = _activeBook.value ?: return
        val clamped = pageNumber.coerceIn(1, book.totalPages.coerceAtLeast(1))
        if (_currentPage.value != clamped) {
            _currentPage.value = clamped
            viewModelScope.launch {
                repository.updateReadingProgress(book.id, clamped, _zoomScale.value)
            }
        }
    }

    fun jumpToPage(pageNumber: Int) {
        val book = _activeBook.value ?: return
        val clamped = pageNumber.coerceIn(1, book.totalPages.coerceAtLeast(1))
        _currentPage.value = clamped
        viewModelScope.launch {
            repository.updateReadingProgress(book.id, clamped, _zoomScale.value)
        }
    }

    fun adjustZoom(delta: Float) {
        val next = (_zoomScale.value + delta).coerceIn(0.8f, 3.0f)
        setZoomScale(next)
    }

    fun setZoomScale(scale: Float) {
        val next = scale.coerceIn(0.8f, 3.0f)
        _zoomScale.value = next
        val book = _activeBook.value ?: return
        viewModelScope.launch {
            repository.updateReadingProgress(book.id, _currentPage.value, next)
        }
    }

    // ---- PDF Search ----

    fun toggleSearchBar(open: Boolean = !_isSearchOpen.value) {
        _isSearchOpen.value = open
        if (!open) {
            _searchMatches.value = emptyList()
            _searchQuery.value = ""
        }
    }

    fun runPdfSearch(query: String) {
        _searchQuery.value = query
        val book = _activeBook.value ?: return
        if (query.isBlank()) {
            _searchMatches.value = emptyList()
            return
        }
        viewModelScope.launch {
            _isSearchingPdf.value = true
            val matches = PdfDocumentController.searchInPdf(File(book.localFilePath), query)
            _searchMatches.value = matches
            _currentMatchIndex.value = 0
            _isSearchingPdf.value = false
            if (matches.isNotEmpty()) {
                jumpToPage(matches[0].pageNumber)
            }
        }
    }

    fun stepSearchMatch(delta: Int) {
        val list = _searchMatches.value
        if (list.isEmpty()) return
        val nextIdx = (_currentMatchIndex.value + delta).mod(list.size)
        _currentMatchIndex.value = nextIdx
        jumpToPage(list[nextIdx].pageNumber)
    }

    // ---- PDF Page Annotations ----

    fun addPageStroke(pageNumber: Int, stroke: PdfAnnotationStroke) {
        val book = _activeBook.value ?: return
        val existing = pageAnnotationsMap.value[pageNumber].orEmpty()
        viewModelScope.launch {
            repository.savePageStrokes(book.id, pageNumber, existing + stroke)
        }
    }

    fun undoLastPageStroke(pageNumber: Int) {
        val book = _activeBook.value ?: return
        val existing = pageAnnotationsMap.value[pageNumber].orEmpty()
        if (existing.isEmpty()) return
        viewModelScope.launch {
            repository.savePageStrokes(book.id, pageNumber, existing.dropLast(1))
        }
    }

    fun clearPageStrokes(pageNumber: Int) {
        val book = _activeBook.value ?: return
        viewModelScope.launch {
            repository.savePageStrokes(book.id, pageNumber, emptyList())
        }
    }

    // ---- Docked Board Drag & Quick Resize (Exact AppLayout.tsx Limits) ----

    fun updateBoardDragPercent(rawPercent: Float, isLandscape: Boolean, persistNow: Boolean = false) {
        val snapHideThreshold = if (isLandscape) 10f else 6f
        val effective = if (rawPercent < snapHideThreshold) 0f else rawPercent.coerceIn(0f, 75f)
        _boardSizePercent.value = effective
        if (effective >= 18f) {
            lastNonZeroBoardPercent = effective
        }
        if (persistNow) {
            viewModelScope.launch {
                repository.setSetting("boardSizePercent", effective.roundToInt().toString())
            }
        }
    }

    fun toggleKingDockedBoard() {
        val current = _boardSizePercent.value
        val next = if (current > 5f) 0f else lastNonZeroBoardPercent.coerceIn(45f, 72f)
        _boardSizePercent.value = next
        viewModelScope.launch {
            repository.setSetting("boardSizePercent", next.roundToInt().toString())
        }
    }

    fun cycleQuickSplitSize() {
        val cur = _boardSizePercent.value
        val next = when {
            cur < 10f -> 48f
            cur < 60f -> 72f
            else -> 0f
        }
        if (next > 0f) lastNonZeroBoardPercent = next
        _boardSizePercent.value = next
        viewModelScope.launch {
            repository.setSetting("boardSizePercent", next.roundToInt().toString())
        }
    }

    // ---- Chessboard Moves, Variations, Comments & PGN ----

    fun makeMove(from: Square, to: Square, promotion: PieceType? = null) {
        val updated = ChessTreeManager.playMove(_boardState.value, from, to, promotion)
        _boardState.value = updated
        persistLoadedGameIfNeeded(updated)
        triggerEngineIfActive()
    }

    fun goStart() {
        _boardState.value = ChessTreeManager.goToStart(_boardState.value)
        triggerEngineIfActive()
    }

    fun goPrev() {
        _boardState.value = ChessTreeManager.goToPrev(_boardState.value)
        triggerEngineIfActive()
    }

    fun goNext() {
        _boardState.value = ChessTreeManager.goToNext(_boardState.value)
        triggerEngineIfActive()
    }

    fun goEnd() {
        _boardState.value = ChessTreeManager.goToEnd(_boardState.value)
        triggerEngineIfActive()
    }

    fun selectMoveNode(nodeId: String) {
        _boardState.value = ChessTreeManager.selectNode(_boardState.value, nodeId)
        triggerEngineIfActive()
    }

    fun flipBoard() {
        _boardState.value = ChessTreeManager.flipOrientation(_boardState.value)
    }

    fun resetBoardToStart() {
        _boardState.value = ChessTreeManager.createInitialState(_boardState.value.orientation)
        triggerEngineIfActive()
    }

    fun loadFenOntoBoard(fen: String, title: String? = null) {
        val next = ChessTreeManager.loadFenPosition(fen, title = title)
        _boardState.value = next
        if (_boardSizePercent.value < 25f) {
            _boardSizePercent.value = 48f
        }
        triggerEngineIfActive()
        if (title != null) showToast("Loaded: $title")
    }

    fun updateCurrentMoveComment(comment: String) {
        val state = _boardState.value
        val updated = ChessTreeManager.setNodeComment(state, state.currentNodeId, comment)
        _boardState.value = updated
        persistLoadedGameIfNeeded(updated)
    }

    fun toggleCurrentMoveNag(nag: String) {
        val state = _boardState.value
        if (state.currentNodeId == state.rootNodeId) return
        val updated = ChessTreeManager.toggleNodeNag(state, state.currentNodeId, nag)
        _boardState.value = updated
        persistLoadedGameIfNeeded(updated)
    }

    fun promoteNodeVariation(nodeId: String) {
        val updated = ChessTreeManager.promoteVariation(_boardState.value, nodeId)
        _boardState.value = updated
        persistLoadedGameIfNeeded(updated)
    }

    fun deleteMoveBranch(nodeId: String) {
        val updated = ChessTreeManager.deleteNode(_boardState.value, nodeId)
        _boardState.value = updated
        persistLoadedGameIfNeeded(updated)
        triggerEngineIfActive()
    }

    fun importPgnToBoard(pgn: String, saveToGamesHub: Boolean = false) {
        val loaded = ChessTreeManager.importPgn(pgn)
        if (loaded == null) {
            showToast("Invalid or unreadable PGN.")
            return
        }
        _boardState.value = loaded
        if (_boardSizePercent.value < 25f) _boardSizePercent.value = 48f
        triggerEngineIfActive()
        if (saveToGamesHub) {
            viewModelScope.launch {
                val saved = repository.saveCustomPgnGame(pgn)
                _boardState.value = loaded.copy(loadedGameId = saved.id)
            }
        }
        showToast("PGN loaded onto analysis board")
    }

    fun openImportedGameOnBoard(game: ImportedGameEntity) {
        val loaded = ChessTreeManager.importPgn(
            pgnText = game.pgn,
            gameId = game.id,
            customTitle = "${game.white} vs ${game.black}"
        )
        if (loaded == null) {
            showToast("Could not parse game PGN.")
            return
        }
        _boardState.value = loaded
        if (_boardSizePercent.value < 35f) _boardSizePercent.value = 50f
        _activeSection.value = if (_activeBook.value != null) AppSection.READER else AppSection.LIBRARY
        triggerEngineIfActive()
        showToast("Loaded ${game.white} vs ${game.black} — add comments on any move!")
    }

    fun exportCurrentPgn(): String = ChessTreeManager.exportPgn(_boardState.value)

    private fun persistLoadedGameIfNeeded(state: ChessBoardState) {
        val gid = state.loadedGameId ?: return
        viewModelScope.launch {
            val pgn = ChessTreeManager.exportPgn(state)
            repository.updateSavedGamePgn(gid, pgn)
        }
    }

    fun selectBoardTheme(theme: BoardTheme) {
        _boardTheme.value = theme
        viewModelScope.launch {
            repository.setSetting("boardThemeId", theme.id)
        }
    }

    // ---- Engine Controls (VCH Local, Lichess Cloud, Stockfish 19 & Lichess Transfer) ----

    fun setEngineEnabled(enabled: Boolean) {
        _isEngineEnabled.value = enabled
        if (enabled) triggerEngineIfActive()
        else {
            engineJob?.cancel()
            _engineEval.value = null
        }
    }

    fun selectEngineChoice(choice: EngineChoice) {
        if (choice == EngineChoice.STOCKFISH_19_LICHESS) {
            val state = _boardState.value
            val url = AnalysisEngines.buildLichessStockfish19Url(state.fen, state.orientation)
            _openExternalUrl.value = url
            showToast("Opening position in Lichess Stockfish 19 Analysis...")
            return
        }
        _engineChoice.value = choice
        if (_isEngineEnabled.value) triggerEngineIfActive()
    }

    fun incrementEngineDepth() {
        val next = if (_engineDepth.value >= 4) 2 else _engineDepth.value + 1
        _engineDepth.value = next
        if (_isEngineEnabled.value) triggerEngineIfActive()
    }

    private fun triggerEngineIfActive() {
        if (!_isEngineEnabled.value) return
        engineJob?.cancel()
        val fen = _boardState.value.fen
        val choice = _engineChoice.value
        val depth = _engineDepth.value

        engineJob = viewModelScope.launch {
            _engineEval.value = (_engineEval.value ?: EngineEvaluation(
                scoreText = "...",
                scoreCentipawns = 0,
                depth = depth,
                engineName = choice.shortLabel,
                pvLines = emptyList(),
                bestMoveArrows = emptyList()
            )).copy(isCalculating = true)

            val result = when (choice) {
                EngineChoice.LICHESS_CLOUD -> AnalysisEngines.evaluateLichessCloudOrLocal(fen, depth)
                else -> AnalysisEngines.evaluateVchLocal(fen, depth)
            }
            _engineEval.value = result.copy(isCalculating = false)
        }
    }

    // ---- 4-Phase Chess Diagram Sensor & Scanner ----

    fun openDiagramSensorOnPage(pageNumber: Int, tapNormX: Float = 0.5f, tapNormY: Float = 0.32f) {
        val controller = _pdfController.value ?: return
        viewModelScope.launch {
            val hiRes = controller.renderPage(pageNumber, 1440) ?: return@launch
            val aspect = hiRes.width.toFloat() / hiRes.height.toFloat()

            // Auto-detect diagram near tap first; fallback to proportional 1:1 square centered at tap
            val candidates = PdfDocumentController.detectDiagramCandidatesOnPage(hiRes)
            val tapPxX = tapNormX * hiRes.width
            val tapPxY = tapNormY * hiRes.height

            val matchedCandidate = candidates.firstOrNull { rect ->
                tapPxX >= rect.x - 40 && tapPxX <= rect.x + rect.width + 40 &&
                    tapPxY >= rect.y - 40 && tapPxY <= rect.y + rect.height + 40
            } ?: candidates.firstOrNull()

            val (nx, ny, nw, nh) = if (matchedCandidate != null) {
                listOf(
                    matchedCandidate.x.toFloat() / hiRes.width,
                    matchedCandidate.y.toFloat() / hiRes.height,
                    matchedCandidate.width.toFloat() / hiRes.width,
                    matchedCandidate.height.toFloat() / hiRes.height
                )
            } else {
                val w = 0.52f
                val h = (w * aspect).coerceIn(0.25f, 0.65f)
                val x = (tapNormX - w / 2f).coerceIn(0.02f, 0.98f - w)
                val y = (tapNormY - h / 2f).coerceIn(0.02f, 0.98f - h)
                listOf(x, y, w, h)
            }

            val initialSensor = ActiveSensorState(
                pageNumber = pageNumber,
                normX = nx,
                normY = ny,
                normW = nw,
                normH = nh,
                isScanning = true
            )
            _activeSensor.value = initialSensor
            runSensorScan(initialSensor, allowCloudGemini = false)
        }
    }

    fun updateSensorBox(normX: Float, normY: Float, normW: Float, normH: Float, rescanNow: Boolean) {
        val cur = _activeSensor.value ?: return
        val updated = cur.copy(
            normX = normX.coerceIn(0.01f, 0.95f),
            normY = normY.coerceIn(0.01f, 0.95f),
            normW = normW.coerceIn(0.18f, 0.98f),
            normH = normH.coerceIn(0.14f, 0.98f)
        )
        _activeSensor.value = updated
        if (rescanNow) {
            runSensorScan(updated, allowCloudGemini = false)
        }
    }

    fun toggleSensorTurn() {
        val cur = _activeSensor.value ?: return
        val nextTurn = if (cur.preferredTurn == 'w') 'b' else 'w'
        val prevRes = cur.lastResult
        if (prevRes != null) {
            val revalidated = ScannerFenAndVoting.validateBoard(
                grid = prevRes.grid,
                preferredSideToMove = nextTurn,
                orientation = prevRes.orientation
            )
            _activeSensor.value = cur.copy(
                preferredTurn = nextTurn,
                lastResult = prevRes.copy(
                    fen = revalidated.fen,
                    sideToMove = revalidated.sideToMove,
                    isValid = revalidated.isValid,
                    validation = revalidated
                )
            )
        } else {
            _activeSensor.value = cur.copy(preferredTurn = nextTurn)
        }
    }

    fun triggerGeminiCloudScanOnSensor() {
        val cur = _activeSensor.value ?: return
        runSensorScan(cur, allowCloudGemini = true)
    }

    private fun runSensorScan(sensor: ActiveSensorState, allowCloudGemini: Boolean) {
        val controller = _pdfController.value ?: return
        val book = _activeBook.value ?: return
        viewModelScope.launch {
            _activeSensor.value = sensor.copy(isScanning = true)
            try {
                val pageBmp = controller.renderPage(sensor.pageNumber, 1600) ?: return@launch
                val manualCrop = CropRect(
                    x = (sensor.normX * pageBmp.width).roundToInt(),
                    y = (sensor.normY * pageBmp.height).roundToInt(),
                    width = (sensor.normW * pageBmp.width).roundToInt(),
                    height = (sensor.normH * pageBmp.height).roundToInt()
                )
                val templates = repository.loadBookTemplateMap(book.id)
                val scanResult = DiagramRecognitionPipeline.recognize(
                    sourceBitmap = pageBmp,
                    manualCropRect = manualCrop,
                    templates = templates,
                    preferredSideToMove = sensor.preferredTurn,
                    surroundingText = "",
                    allowOnlineGeminiFallback = allowCloudGemini
                )
                val prepared = ScannerCrop.prepareDiagramImages(pageBmp, scanResult.cropRect, 640)
                _activeSensor.value = _activeSensor.value?.copy(
                    isScanning = false,
                    lastResult = scanResult,
                    cleanCropBitmap = prepared.cleanBitmap,
                    gridCropBitmap = prepared.gridBitmap
                )
                if (scanResult.errorNote != null && allowCloudGemini) {
                    showToast(scanResult.errorNote)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _activeSensor.value = _activeSensor.value?.copy(isScanning = false)
                showToast("Scan error: ${e.localizedMessage ?: "Failed"}")
            }
        }
    }

    fun closeSensor() {
        _activeSensor.value = null
    }

    fun confirmAndLoadSensorDiagram(editedGrid: Array<Array<String>>? = null, learnTemplates: Boolean = true) {
        val sensor = _activeSensor.value ?: return
        val res = sensor.lastResult ?: return
        val book = _activeBook.value
        val finalGrid = editedGrid ?: res.grid
        val validation = ScannerFenAndVoting.validateBoard(
            grid = finalGrid,
            preferredSideToMove = sensor.preferredTurn,
            orientation = res.orientation
        )
        loadFenOntoBoard(validation.fen, "Page ${sensor.pageNumber} Diagram")
        _activeSensor.value = null

        if (book != null) {
            viewModelScope.launch {
                if (learnTemplates && sensor.cleanCropBitmap != null) {
                    repository.learnTemplatesFromConfirmedScan(book.id, sensor.cleanCropBitmap, finalGrid)
                }
                repository.saveCatalogDiagram(
                    CatalogDiagramEntity(
                        id = "diag_${book.id}_p${sensor.pageNumber}_${System.currentTimeMillis() % 10000}",
                        bookId = book.id,
                        pageNumber = sensor.pageNumber,
                        title = "Page ${sensor.pageNumber} Diagram",
                        fen = validation.fen,
                        turn = validation.sideToMove.toString(),
                        confidence = res.confidence,
                        sourceMethod = res.sourceMethod,
                        cropX = res.cropRect.x,
                        cropY = res.cropRect.y,
                        cropW = res.cropRect.width,
                        cropH = res.cropRect.height,
                        uncertainSquaresCsv = res.uncertainSquares.joinToString(",")
                    )
                )
            }
        }
    }

    // ---- Background Batch Diagram Scanner ----

    fun startBatchCatalogScan() {
        val book = _activeBook.value ?: return
        val controller = _pdfController.value ?: return
        batchJob?.cancel()
        batchJob = viewModelScope.launch {
            val total = book.totalPages.coerceAtLeast(1)
            _batchScanState.value = BatchScanState(isRunning = true, currentPage = 1, totalPages = total, diagramsFound = 0)
            var foundCount = 0
            val templates = repository.loadBookTemplateMap(book.id)

            for (p in 1..total) {
                while (_batchScanState.value.isPaused) {
                    kotlinx.coroutines.delay(250)
                }
                if (!_batchScanState.value.isRunning) break
                _batchScanState.value = _batchScanState.value.copy(currentPage = p)
                val bmp = controller.renderPage(p, 1200) ?: continue
                val candidates = PdfDocumentController.detectDiagramCandidatesOnPage(bmp)
                for ((idx, rect) in candidates.withIndex()) {
                    val scan = DiagramRecognitionPipeline.recognize(
                        sourceBitmap = bmp,
                        manualCropRect = rect,
                        templates = templates,
                        preferredSideToMove = 'w',
                        allowOnlineGeminiFallback = false
                    )
                    if (scan.isValid) {
                        foundCount++
                        repository.saveCatalogDiagram(
                            CatalogDiagramEntity(
                                id = "batch_${book.id}_p${p}_${idx + 1}",
                                bookId = book.id,
                                pageNumber = p,
                                title = "Page $p Diagram ${idx + 1}",
                                fen = scan.fen,
                                turn = scan.sideToMove.toString(),
                                confidence = scan.confidence,
                                sourceMethod = scan.sourceMethod,
                                cropX = scan.cropRect.x,
                                cropY = scan.cropRect.y,
                                cropW = scan.cropRect.width,
                                cropH = scan.cropRect.height
                            )
                        )
                        _batchScanState.value = _batchScanState.value.copy(diagramsFound = foundCount)
                    }
                }
            }
            _batchScanState.value = _batchScanState.value.copy(isRunning = false, isPaused = false)
            showToast("Catalog scan finished: $foundCount diagrams indexed offline.")
        }
    }

    fun togglePauseBatchScan() {
        val cur = _batchScanState.value
        if (!cur.isRunning) return
        _batchScanState.value = cur.copy(isPaused = !cur.isPaused)
    }

    fun cancelBatchScan() {
        batchJob?.cancel()
        _batchScanState.value = BatchScanState()
    }

    // ---- PMS Positions ----

    fun saveCurrentPositionToPms(title: String, note: String) {
        val state = _boardState.value
        val book = _activeBook.value
        val turn = ChessEngineCore.parseFen(state.fen)?.turn?.code?.toString() ?: "w"
        viewModelScope.launch {
            repository.savePmsPosition(
                PmsPositionEntity(
                    id = "pms_${UUID.randomUUID().toString().take(8)}",
                    title = title.trim().ifBlank { "Saved Study Position" },
                    fen = state.fen,
                    bookId = book?.id,
                    bookTitle = book?.title,
                    pageNumber = if (book != null) _currentPage.value else null,
                    note = note.trim(),
                    turn = turn
                )
            )
            showToast("Position saved to Study Library")
        }
    }

    fun deletePmsPosition(id: String) {
        viewModelScope.launch { repository.deletePmsPosition(id) }
    }

    // ---- Notes (Starts Empty; User-Authored Only) ----

    fun saveStudyNote(
        existingId: String?,
        title: String,
        content: String,
        tags: String,
        attachCurrentBoardFen: Boolean,
        existingLinkedFen: String?,
        isPinned: Boolean
    ) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val fenToSave = if (attachCurrentBoardFen) _boardState.value.fen else existingLinkedFen
            repository.saveNote(
                NoteEntity(
                    id = existingId ?: "note_${UUID.randomUUID().toString().take(8)}",
                    title = title.trim().ifBlank { "Untitled Note" },
                    content = content,
                    tags = tags.trim(),
                    linkedFen = fenToSave,
                    isPinned = isPinned,
                    createdAt = now,
                    updatedAt = now
                )
            )
            showToast("Note saved")
        }
    }

    fun togglePinNote(note: NoteEntity) {
        viewModelScope.launch {
            repository.saveNote(note.copy(isPinned = !note.isPinned, updatedAt = System.currentTimeMillis()))
        }
    }

    fun deleteStudyNote(id: String) {
        viewModelScope.launch {
            repository.deleteNote(id)
            showToast("Note deleted")
        }
    }

    // ---- Principles: Opening / Middlegame / Endgame (Starts Empty; User-Authored Only) ----

    fun savePrinciple(
        existingId: String?,
        phase: PrinciplePhase,
        title: String,
        description: String,
        attachCurrentBoardFen: Boolean,
        existingLinkedFen: String?
    ) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val fenToSave = if (attachCurrentBoardFen) _boardState.value.fen else existingLinkedFen
            repository.savePrinciple(
                PrincipleEntity(
                    id = existingId ?: "prin_${UUID.randomUUID().toString().take(8)}",
                    phase = phase.name,
                    title = title.trim().ifBlank { "Untitled Principle" },
                    description = description,
                    linkedFen = fenToSave,
                    createdAt = now,
                    updatedAt = now
                )
            )
            showToast("Saved to ${phase.label} Principles")
        }
    }

    fun deletePrinciple(id: String) {
        viewModelScope.launch {
            repository.deletePrinciple(id)
            showToast("Principle deleted")
        }
    }

    // ---- Lichess & Chess.com Game Import ----

    private val _isFetchingOnlineGames = MutableStateFlow(false)
    val isFetchingOnlineGames: StateFlow<Boolean> = _isFetchingOnlineGames.asStateFlow()

    fun fetchLichessGames(username: String) {
        viewModelScope.launch {
            _isFetchingOnlineGames.value = true
            try {
                val list = repository.fetchLichessGamesByUsername(username)
                showToast("Imported ${list.size} games from Lichess ($username)")
            } catch (e: Exception) {
                showToast(e.localizedMessage ?: "Failed to fetch Lichess games")
            } finally {
                _isFetchingOnlineGames.value = false
            }
        }
    }

    fun fetchChessComGames(username: String) {
        viewModelScope.launch {
            _isFetchingOnlineGames.value = true
            try {
                val list = repository.fetchChessComGamesByUsername(username)
                showToast("Imported ${list.size} games from Chess.com ($username)")
            } catch (e: Exception) {
                showToast(e.localizedMessage ?: "Failed to fetch Chess.com games")
            } finally {
                _isFetchingOnlineGames.value = false
            }
        }
    }

    fun deleteImportedGame(gameId: String) {
        viewModelScope.launch {
            repository.deleteImportedGame(gameId)
        }
    }
}
