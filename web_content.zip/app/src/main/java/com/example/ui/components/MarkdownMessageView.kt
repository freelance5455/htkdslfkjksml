package com.example.ui.components

import android.graphics.BitmapFactory
import android.util.Base64
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ChatMessage
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NovaDeepViolet
import com.example.ui.theme.NovaElectricBlue
import com.example.ui.theme.NovaUserBubbleEnd
import com.example.ui.theme.NovaUserBubbleStart
import com.example.ui.theme.NovaVioletGlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * Mandatory Chat Layout with Subtle Slide-In Animation & AURA AI Next-Gen Glass UI:
 * - USER MESSAGES: Displayed on the RIGHT side with an Aurora Cyan-Indigo gradient bubble,
 *   attachment preview, timestamp, Copy, and Edit & Resend actions.
 * - AURA AI MESSAGES: Displayed on the LEFT side with a subtle slide-in + fade + spring animation,
 *   frosted glass card with a glowing Aurora left accent bar, verified neural badge, Markdown rendering,
 *   and pill-shaped quick actions.
 */
@Composable
fun ChatMessageRow(
    message: ChatMessage,
    onCopyText: (String) -> Unit,
    onEditUserMessage: (ChatMessage) -> Unit,
    onRegenerateAiMessage: (ChatMessage) -> Unit,
    onSpeakMessage: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val isUser = message.role == "user"
    val timestampStr = remember(message.createdAt) {
        val date = (message.createdAt ?: message.updatedAt)?.toDate()
        if (date != null) {
            SimpleDateFormat("hh:mm a", Locale.getDefault()).format(date)
        } else {
            "Just now"
        }
    }

    // Subtle slide-in + fade + micro-scale animation on message entry
    val slideOffsetX = remember(message.id) { Animatable(if (isUser) 24f else -32f) }
    val slideOffsetY = remember(message.id) { Animatable(14f) }
    val entryAlpha = remember(message.id) { Animatable(0f) }
    val entryScale = remember(message.id) { Animatable(0.975f) }

    LaunchedEffect(message.id) {
        launch {
            slideOffsetX.animateTo(
                targetValue = 0f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioNoBouncy,
                    stiffness = Spring.StiffnessMediumLow
                )
            )
        }
        launch {
            slideOffsetY.animateTo(
                targetValue = 0f,
                animationSpec = tween(durationMillis = 260, easing = FastOutSlowInEasing)
            )
        }
        launch {
            entryAlpha.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 240, easing = FastOutSlowInEasing)
            )
        }
        launch {
            entryScale.animateTo(
                targetValue = 1f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioLowBouncy,
                    stiffness = Spring.StiffnessMedium
                )
            )
        }
    }

    if (isUser) {
        // USER MESSAGE -> STRICTLY ON THE RIGHT SIDE
        Row(
            modifier = modifier
                .fillMaxWidth()
                .graphicsLayer {
                    translationX = slideOffsetX.value
                    translationY = slideOffsetY.value
                    alpha = entryAlpha.value
                    scaleX = entryScale.value
                    scaleY = entryScale.value
                }
                .padding(horizontal = 12.dp, vertical = 6.dp)
                .testTag("user_message_row_${message.id}"),
            horizontalArrangement = Arrangement.End
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.86f)
                    .widthIn(max = 520.dp),
                horizontalAlignment = Alignment.End
            ) {
                Box(
                    modifier = Modifier
                        .clip(
                            RoundedCornerShape(
                                topStart = 22.dp,
                                topEnd = 22.dp,
                                bottomStart = 22.dp,
                                bottomEnd = 4.dp
                            )
                        )
                        .background(
                            Brush.linearGradient(
                                colors = listOf(NovaUserBubbleStart, NovaUserBubbleEnd)
                            )
                        )
                        .border(
                            width = 1.dp,
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    NovaElectricBlue.copy(alpha = 0.45f),
                                    NovaDeepViolet.copy(alpha = 0.55f)
                                )
                            ),
                            shape = RoundedCornerShape(
                                topStart = 22.dp,
                                topEnd = 22.dp,
                                bottomStart = 22.dp,
                                bottomEnd = 4.dp
                            )
                        )
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Column(horizontalAlignment = Alignment.Start) {
                        // Attachment summary chip if present
                        if (!message.attachmentSummary.isNullOrBlank()) {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = Color.Black.copy(alpha = 0.28f),
                                modifier = Modifier.padding(bottom = 8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AttachFile,
                                        contentDescription = "Attachment",
                                        tint = NovaElectricBlue,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = message.attachmentSummary,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color(0xFFE2E8FF)
                                    )
                                }
                            }
                        }

                        // Attached image preview inside user bubble if present
                        if (!message.generatedImageBase64.isNullOrBlank()) {
                            Base64ImagePreview(
                                base64 = message.generatedImageBase64,
                                contentDescription = "User attached image",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(max = 220.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .padding(bottom = 8.dp)
                            )
                        }

                        SelectionContainer {
                            Text(
                                text = message.content,
                                style = MaterialTheme.typography.bodyLarge,
                                color = Color(0xFFF8FAFC)
                            )
                        }
                    }
                }

                // User Message Footer: Timestamp + Copy + Edit
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.End,
                    modifier = Modifier.padding(top = 3.dp)
                ) {
                    Text(
                        text = timestampStr,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.72f)
                    )
                    IconButton(
                        onClick = { onCopyText(message.content) },
                        modifier = Modifier.size(30.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy user message",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                    IconButton(
                        onClick = { onEditUserMessage(message) },
                        modifier = Modifier.size(30.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit and resend message",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }
    } else {
        // AURA AI MESSAGE -> STRICTLY ON THE LEFT SIDE WITH SUBTLE SLIDE-IN ANIMATION & NEW AURORA GLASS CARD
        val aiCardShape = RoundedCornerShape(
            topStart = 6.dp,
            topEnd = 20.dp,
            bottomEnd = 20.dp,
            bottomStart = 20.dp
        )
        Row(
            modifier = modifier
                .fillMaxWidth()
                .graphicsLayer {
                    translationX = slideOffsetX.value
                    translationY = slideOffsetY.value
                    alpha = entryAlpha.value
                    scaleX = entryScale.value
                    scaleY = entryScale.value
                }
                .padding(horizontal = 12.dp, vertical = 7.dp)
                .testTag("ai_message_row_${message.id}"),
            horizontalArrangement = Arrangement.Start,
            verticalAlignment = Alignment.Top
        ) {
            // AURA AI Holographic Prism Avatar on the Left
            Box(
                modifier = Modifier
                    .padding(top = 2.dp)
                    .size(34.dp)
                    .clip(RoundedCornerShape(11.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                NovaElectricBlue.copy(alpha = 0.28f),
                                NovaDeepViolet.copy(alpha = 0.42f)
                            )
                        )
                    )
                    .border(
                        width = 1.2.dp,
                        brush = Brush.linearGradient(listOf(NovaElectricBlue, NovaDeepViolet)),
                        shape = RoundedCornerShape(11.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "AURA AI",
                    tint = NovaElectricBlue,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Surface(
                shape = aiCardShape,
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.58f),
                tonalElevation = 3.dp,
                modifier = Modifier
                    .weight(1f)
                    .widthIn(max = 680.dp)
                    .border(
                        width = 1.dp,
                        brush = Brush.linearGradient(
                            colors = listOf(
                                NovaElectricBlue.copy(alpha = 0.35f),
                                MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                            )
                        ),
                        shape = aiCardShape
                    )
                    .drawBehind {
                        // Subtle glowing Aurora accent bar on left edge
                        drawRoundRect(
                            brush = Brush.verticalGradient(
                                colors = listOf(NovaElectricBlue, NovaVioletGlow, NovaDeepViolet)
                            ),
                            topLeft = Offset(0f, 18f),
                            size = Size(3.5.dp.toPx(), (size.height - 36f).coerceAtLeast(16f)),
                            cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                        )
                    }
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                    horizontalAlignment = Alignment.Start
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "✦ AURA AI",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = NovaElectricBlue
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(999.dp),
                                color = NovaElectricBlue.copy(alpha = 0.14f)
                            ) {
                                Text(
                                    text = "NEURAL",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = NovaElectricBlue,
                                    fontSize = 9.sp,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = timestampStr,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Generated Image if available
                    if (!message.generatedImageBase64.isNullOrBlank()) {
                        Base64ImagePreview(
                            base64 = message.generatedImageBase64,
                            contentDescription = "AURA AI generated artwork",
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 180.dp, max = 340.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                                .padding(bottom = 10.dp)
                        )
                    }

                    // Rich Markdown Content
                    SelectionContainer {
                        RichMarkdownContent(
                            markdown = message.content,
                            onCopyCode = onCopyText
                        )
                    }

                    // Web Research Citations Card if present
                    if (!message.citations.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.75f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Public,
                                        contentDescription = "Sources",
                                        tint = NovaElectricBlue,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Research Grounding & Sources",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = message.citations,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // AI Action Pill Toolbar: Speak Aloud, Copy, Regenerate
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        AiActionPill(
                            icon = Icons.Default.VolumeUp,
                            label = "Listen",
                            contentDescription = "Speak response aloud",
                            onClick = { onSpeakMessage(message.content) }
                        )
                        AiActionPill(
                            icon = Icons.Default.ContentCopy,
                            label = "Copy",
                            contentDescription = "Copy AI response",
                            onClick = { onCopyText(message.content) }
                        )
                        AiActionPill(
                            icon = Icons.Default.Refresh,
                            label = "Retry",
                            contentDescription = "Regenerate response",
                            onClick = { onRegenerateAiMessage(message) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AiActionPill(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    contentDescription: String,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.65f),
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                shape = RoundedCornerShape(10.dp)
            )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = NovaElectricBlue,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun Base64ImagePreview(
    base64: String,
    contentDescription: String,
    modifier: Modifier = Modifier
) {
    val imageBitmap = remember(base64) {
        try {
            val clean = base64.substringAfter("base64,", base64)
            val bytes = Base64.decode(clean, Base64.DEFAULT)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
        } catch (_: Exception) {
            null
        }
    }
    if (imageBitmap != null) {
        Image(
            bitmap = imageBitmap,
            contentDescription = contentDescription,
            contentScale = ContentScale.Crop,
            modifier = modifier
        )
    }
}

private sealed interface MarkdownBlock {
    data class Heading(val level: Int, val text: String) : MarkdownBlock
    data class Paragraph(val text: String) : MarkdownBlock
    data class BulletItem(val bullet: String, val text: String) : MarkdownBlock
    data class QuoteBlock(val text: String) : MarkdownBlock
    data object DividerBlock : MarkdownBlock
    data class CodeBlock(val language: String, val code: String) : MarkdownBlock
    data class TableBlock(val rows: List<List<String>>) : MarkdownBlock
    data class MathBlock(val expression: String) : MarkdownBlock
}

@Composable
fun RichMarkdownContent(
    markdown: String,
    onCopyCode: (String) -> Unit
) {
    val blocks = remember(markdown) { parseMarkdownBlocks(markdown) }

    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
        blocks.forEach { block ->
            when (block) {
                is MarkdownBlock.Heading -> {
                    val style = when (block.level) {
                        1 -> MaterialTheme.typography.titleLarge
                        2 -> MaterialTheme.typography.titleMedium
                        else -> MaterialTheme.typography.titleSmall
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(top = 6.dp, bottom = 2.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .width(3.5.dp)
                                .height(16.dp)
                                .clip(RoundedCornerShape(999.dp))
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(NovaElectricBlue, NovaVioletGlow)
                                    )
                                )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = parseInlineMarkdown(block.text),
                            style = style,
                            fontWeight = FontWeight.ExtraBold,
                            color = NovaElectricBlue
                        )
                    }
                }
                is MarkdownBlock.Paragraph -> {
                    Text(
                        text = parseInlineMarkdown(block.text),
                        style = MaterialTheme.typography.bodyLarge,
                        lineHeight = 23.sp,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
                is MarkdownBlock.BulletItem -> {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 2.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(
                            text = block.bullet,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = NovaElectricBlue,
                            modifier = Modifier.width(24.dp)
                        )
                        Text(
                            text = parseInlineMarkdown(block.text),
                            style = MaterialTheme.typography.bodyLarge,
                            lineHeight = 22.sp,
                            color = MaterialTheme.colorScheme.onBackground,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                is MarkdownBlock.QuoteBlock -> {
                    Surface(
                        shape = RoundedCornerShape(topStart = 4.dp, topEnd = 12.dp, bottomEnd = 12.dp, bottomStart = 4.dp),
                        color = NovaElectricBlue.copy(alpha = 0.08f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = 1.dp,
                                color = NovaElectricBlue.copy(alpha = 0.25f),
                                shape = RoundedCornerShape(topStart = 4.dp, topEnd = 12.dp, bottomEnd = 12.dp, bottomStart = 4.dp)
                            )
                    ) {
                        Text(
                            text = parseInlineMarkdown(block.text),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
                is MarkdownBlock.DividerBlock -> {
                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }
                is MarkdownBlock.CodeBlock -> {
                    CodeBlockCard(
                        language = block.language,
                        code = block.code,
                        onCopyCode = onCopyCode
                    )
                }
                is MarkdownBlock.TableBlock -> {
                    MarkdownTableCard(rows = block.rows)
                }
                is MarkdownBlock.MathBlock -> {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = block.expression,
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 14.sp,
                            color = NovaElectricBlue,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CodeBlockCard(
    language: String,
    code: String,
    onCopyCode: (String) -> Unit
) {
    val clipboard = LocalClipboardManager.current
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF0A0D18),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF252D47), RoundedCornerShape(12.dp))
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF14192B))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = language.ifBlank { "code" }.uppercase(Locale.ROOT),
                    style = MaterialTheme.typography.labelSmall,
                    color = NovaElectricBlue
                )
                IconButton(
                    onClick = {
                        clipboard.setText(AnnotatedString(code))
                        onCopyCode(code)
                    },
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy code block",
                        tint = Color(0xFFB5C0E0),
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(12.dp)
            ) {
                Text(
                    text = code,
                    fontFamily = JetBrainsMonoFontFamily,
                    fontSize = 13.sp,
                    lineHeight = 19.sp,
                    color = Color(0xFFE6ECFF)
                )
            }
        }
    }
}

@Composable
private fun MarkdownTableCard(rows: List<List<String>>) {
    if (rows.isEmpty()) return
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(10.dp))
    ) {
        Column(
            modifier = Modifier
                .horizontalScroll(rememberScrollState())
                .padding(8.dp)
        ) {
            rows.forEachIndexed { rowIdx, row ->
                Row(modifier = Modifier.padding(vertical = 4.dp)) {
                    row.forEach { cell ->
                        Text(
                            text = parseInlineMarkdown(cell.trim()),
                            style = if (rowIdx == 0) MaterialTheme.typography.labelLarge else MaterialTheme.typography.bodyMedium,
                            color = if (rowIdx == 0) NovaElectricBlue else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier
                                .widthIn(min = 100.dp, max = 220.dp)
                                .padding(horizontal = 8.dp)
                        )
                    }
                }
                if (rowIdx == 0 && rows.size > 1) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                }
            }
        }
    }
}

private fun parseMarkdownBlocks(raw: String): List<MarkdownBlock> {
    val sanitized = raw
        .replace(Regex("<think>[\\s\\S]*?</think>", RegexOption.IGNORE_CASE), "")
        .replace(Regex("\\n*---\\s*\\n*\\*?\\*?Support Pollinations[\\s\\S]*$", RegexOption.IGNORE_CASE), "")
        .trim()
    val lines = sanitized.lines()
    val blocks = mutableListOf<MarkdownBlock>()
    var i = 0
    while (i < lines.size) {
        val line = lines[i]
        val trimmed = line.trim()

        // 1. Fenced code block
        if (trimmed.startsWith("```")) {
            val lang = trimmed.removePrefix("```").trim()
            val codeBuilder = StringBuilder()
            i++
            while (i < lines.size && !lines[i].trim().startsWith("```")) {
                codeBuilder.appendLine(lines[i])
                i++
            }
            blocks.add(MarkdownBlock.CodeBlock(lang, codeBuilder.toString().trimEnd()))
            i++
            continue
        }

        // 2. Display math block $$ ... $$
        if (trimmed.startsWith("$$")) {
            val mathBuilder = StringBuilder()
            if (trimmed.endsWith("$$") && trimmed.length > 4) {
                blocks.add(MarkdownBlock.MathBlock(trimmed.removeSurrounding("$$").trim()))
                i++
                continue
            }
            i++
            while (i < lines.size && !lines[i].trim().startsWith("$$")) {
                mathBuilder.appendLine(lines[i])
                i++
            }
            blocks.add(MarkdownBlock.MathBlock(mathBuilder.toString().trim()))
            i++
            continue
        }

        // 3. Markdown Table
        if (trimmed.startsWith("|") && trimmed.endsWith("|")) {
            val tableRows = mutableListOf<List<String>>()
            while (i < lines.size && lines[i].trim().let { it.startsWith("|") && it.endsWith("|") }) {
                val rowLine = lines[i].trim().removeSurrounding("|")
                val cells = rowLine.split("|")
                val isSeparator = cells.all { cell -> cell.trim().all { ch -> ch == '-' || ch == ':' } }
                if (!isSeparator) {
                    tableRows.add(cells)
                }
                i++
            }
            if (tableRows.isNotEmpty()) {
                blocks.add(MarkdownBlock.TableBlock(tableRows))
            }
            continue
        }

        // 4. Horizontal Rule
        if (trimmed == "---" || trimmed == "***" || trimmed == "___") {
            blocks.add(MarkdownBlock.DividerBlock)
            i++
            continue
        }

        // 5. Headings
        if (trimmed.startsWith("#### ")) {
            blocks.add(MarkdownBlock.Heading(3, trimmed.removePrefix("#### ").trim().removeSurrounding("**")))
            i++
            continue
        }
        if (trimmed.startsWith("### ")) {
            blocks.add(MarkdownBlock.Heading(3, trimmed.removePrefix("### ").trim().removeSurrounding("**")))
            i++
            continue
        }
        if (trimmed.startsWith("## ")) {
            blocks.add(MarkdownBlock.Heading(2, trimmed.removePrefix("## ").trim().removeSurrounding("**")))
            i++
            continue
        }
        if (trimmed.startsWith("# ")) {
            blocks.add(MarkdownBlock.Heading(1, trimmed.removePrefix("# ").trim().removeSurrounding("**")))
            i++
            continue
        }

        // 6. Blockquote
        if (trimmed.startsWith("> ")) {
            blocks.add(MarkdownBlock.QuoteBlock(trimmed.removePrefix("> ").trim()))
            i++
            continue
        }

        // 7. Bullet or numbered list
        if (trimmed.startsWith("- ") || trimmed.startsWith("* ") || trimmed.startsWith("• ")) {
            blocks.add(MarkdownBlock.BulletItem("•", trimmed.substring(2).trim()))
            i++
            continue
        }
        val numMatch = Regex("""^(\d+[\.\)])\s+(.+)$""").find(trimmed)
        if (numMatch != null) {
            blocks.add(MarkdownBlock.BulletItem(numMatch.groupValues[1], numMatch.groupValues[2]))
            i++
            continue
        }

        // 8. Regular paragraph
        if (trimmed.isNotEmpty()) {
            blocks.add(MarkdownBlock.Paragraph(trimmed))
        }
        i++
    }
    return blocks
}

private fun parseInlineMarkdown(text: String): AnnotatedString {
    return buildAnnotatedString {
        var idx = 0
        while (idx < text.length) {
            when {
                text.startsWith("**", idx) -> {
                    val end = text.indexOf("**", idx + 2)
                    if (end != -1) {
                        withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                            append(text.substring(idx + 2, end))
                        }
                        idx = end + 2
                    } else {
                        append(text[idx])
                        idx++
                    }
                }
                text.startsWith("`", idx) -> {
                    val end = text.indexOf("`", idx + 1)
                    if (end != -1) {
                        withStyle(
                            SpanStyle(
                                fontFamily = JetBrainsMonoFontFamily,
                                background = Color(0x3300E5FF),
                                color = NovaElectricBlue
                            )
                        ) {
                            append(" " + text.substring(idx + 1, end) + " ")
                        }
                        idx = end + 1
                    } else {
                        append(text[idx])
                        idx++
                    }
                }
                text.startsWith("*", idx) -> {
                    val end = text.indexOf("*", idx + 1)
                    if (end != -1) {
                        withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                            append(text.substring(idx + 1, end))
                        }
                        idx = end + 1
                    } else {
                        append(text[idx])
                        idx++
                    }
                }
                else -> {
                    append(text[idx])
                    idx++
                }
            }
        }
    }
}
