package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.example.data.local.BookingEntity
import com.example.data.model.BookingStatus
import com.example.data.model.DocumentType
import com.example.data.model.PendingAttachment
import com.example.data.model.TripType
import com.example.data.repository.SaveResult
import com.example.ui.components.AttachDocumentDialog
import com.example.ui.components.DatePickerTextField
import com.example.ui.components.SdTopAppBar
import com.example.ui.components.SectionHeaderCard
import com.example.ui.theme.BackgroundWhite
import com.example.ui.theme.BorderLight
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.GoldSecondary
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.StatusCancelledBg
import com.example.ui.theme.StatusCancelledFg
import com.example.ui.theme.StatusConfirmedFg
import com.example.ui.theme.SurfaceLightGray
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainViewModel
import com.example.utils.CurrencyFormatters
import com.example.utils.DateFormatters
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun AddBookingScreen(
    viewModel: MainViewModel,
    existingClientId: Long? = null,
    onBack: () -> Unit,
    onSavedSuccess: (Long) -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var clientCode by remember { mutableStateOf("") }
    var fullName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var whatsapp by remember { mutableStateOf("") }
    var nationalId by remember { mutableStateOf("") }
    var passportNumber by remember { mutableStateOf("") }
    var birthDate by remember { mutableStateOf("") }

    var tripDate by remember { mutableStateOf(DateFormatters.todayIso()) }
    var returnDate by remember { mutableStateOf("") }
    var tripType by remember { mutableStateOf(TripType.EIGHT_DAYS) }
    var customTripLabel by remember { mutableStateOf("") }
    var companyName by remember { mutableStateOf("") }
    var makkahHotel by remember { mutableStateOf("") }
    var madinahHotel by remember { mutableStateOf("") }

    var totalPriceStr by remember { mutableStateOf("") }
    var depositStr by remember { mutableStateOf("") }
    var extraAmountStr by remember { mutableStateOf("") }
    var costAmountStr by remember { mutableStateOf("") }
    var bookingStatus by remember { mutableStateOf(BookingStatus.PENDING) }
    var notes by remember { mutableStateOf("") }

    var codeDuplicateError by remember { mutableStateOf<String?>(null) }
    var formError by remember { mutableStateOf<String?>(null) }
    var isSaving by remember { mutableStateOf(false) }

    val pendingAttachments = remember { mutableStateListOf<PendingAttachment>() }
    var showAttachDialog by remember { mutableStateOf(false) }
    var pendingDocType by remember { mutableStateOf(DocumentType.PASSPORT) }
    var pendingDocTitle by remember { mutableStateOf("") }
    var activeCameraTempFile by remember { mutableStateOf<File?>(null) }

    // Pre-fill client details when adding another booking to an existing client
    LaunchedEffect(existingClientId) {
        if (existingClientId != null && existingClientId > 0L) {
            viewModel.observeClient(existingClientId).collect { cwb ->
                if (cwb != null) {
                    clientCode = cwb.client.clientCode
                    fullName = cwb.client.fullName
                    phone = cwb.client.phone
                    whatsapp = cwb.client.whatsapp
                    nationalId = cwb.client.nationalId
                    passportNumber = cwb.client.passportNumber
                    birthDate = cwb.client.birthDate
                }
            }
        }
    }

    // Check duplicate clientCode live when creating a new client
    LaunchedEffect(clientCode, existingClientId) {
        if (existingClientId == null && clientCode.trim().isNotEmpty()) {
            val available = viewModel.checkCodeAvailable(clientCode)
            codeDuplicateError = if (!available) {
                "كود العميل (${clientCode.trim()}) مسجل مسبقًا لعميل آخر"
            } else {
                null
            }
        } else {
            codeDuplicateError = null
        }
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val tempFile = viewModel.documentStorage.copyUriToTempFile(uri)
                if (tempFile != null) {
                    pendingAttachments.add(
                        PendingAttachment(
                            docType = pendingDocType,
                            title = pendingDocTitle,
                            tempFilePath = tempFile.absolutePath,
                        )
                    )
                }
            }
        }
    }

    val takePictureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        val file = activeCameraTempFile
        if (success && file != null && file.exists()) {
            pendingAttachments.add(
                PendingAttachment(
                    docType = pendingDocType,
                    title = pendingDocTitle,
                    tempFilePath = file.absolutePath,
                )
            )
        } else {
            file?.delete()
        }
        activeCameraTempFile = null
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            val (file, uri) = viewModel.documentStorage.createTempCameraFileAndUri()
            activeCameraTempFile = file
            takePictureLauncher.launch(uri)
        } else {
            formError = "يرجى منح صلاحية الكاميرا للتصوير المباشر أو استخدام المعرض."
        }
    }

    val totalPrice = totalPriceStr.toDoubleOrNull() ?: 0.0
    val depositAmount = depositStr.toDoubleOrNull() ?: 0.0
    val extraAmount = extraAmountStr.toDoubleOrNull() ?: 0.0
    val costAmount = costAmountStr.toDoubleOrNull() ?: 0.0
    val remainingPreview = (totalPrice + extraAmount) - depositAmount

    Scaffold(
        containerColor = SurfaceLightGray,
        topBar = {
            SdTopAppBar(
                title = if (existingClientId != null) "إضافة حجز جديد للعميل" else "إضافة حجز جديد",
                subtitle = "إدخال يدوي لكود العميل وحفظ محلي فوري",
                onBack = onBack,
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (formError != null) {
                item {
                    Surface(
                        color = StatusCancelledBg,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, StatusCancelledFg.copy(alpha = 0.4f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("form_error_banner"),
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = StatusCancelledFg)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = formError.orEmpty(),
                                color = StatusCancelledFg,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                }
            }

            // Section 1: Client Code & Personal Info
            item {
                FormCard {
                    SectionHeaderCard(title = "1. بيانات العميل والكود اليدوي", icon = Icons.Default.Person)
                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = clientCode,
                        onValueChange = { if (existingClientId == null) clientCode = it },
                        readOnly = existingClientId != null,
                        label = { Text("كود العميل (إجباري ويدوي) *") },
                        placeholder = { Text("مثال: SD-105") },
                        leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null, tint = NavyPrimary) },
                        isError = codeDuplicateError != null,
                        supportingText = {
                            if (codeDuplicateError != null) {
                                Text(codeDuplicateError!!, color = StatusCancelledFg)
                            } else {
                                Text("يُمنع التكرار ولا يتم إنشاء الكود تلقائيًا")
                            }
                        },
                        singleLine = true,
                        colors = formFieldColors(),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_client_code"),
                    )

                    FormField(
                        value = fullName,
                        onValueChange = { if (existingClientId == null) fullName = it },
                        readOnly = existingClientId != null,
                        label = "اسم العميل بالكامل *",
                        testTag = "input_full_name",
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        FormField(
                            value = phone,
                            onValueChange = { if (existingClientId == null) phone = it },
                            readOnly = existingClientId != null,
                            label = "رقم الهاتف",
                            keyboardType = KeyboardType.Phone,
                            modifier = Modifier.weight(1f),
                            testTag = "input_phone",
                        )
                        FormField(
                            value = whatsapp,
                            onValueChange = { if (existingClientId == null) whatsapp = it },
                            readOnly = existingClientId != null,
                            label = "رقم الواتساب",
                            keyboardType = KeyboardType.Phone,
                            modifier = Modifier.weight(1f),
                            testTag = "input_whatsapp",
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        FormField(
                            value = nationalId,
                            onValueChange = { if (existingClientId == null) nationalId = it },
                            readOnly = existingClientId != null,
                            label = "رقم البطاقة الشخصية",
                            keyboardType = KeyboardType.Number,
                            modifier = Modifier.weight(1f),
                            testTag = "input_national_id",
                        )
                        FormField(
                            value = passportNumber,
                            onValueChange = { if (existingClientId == null) passportNumber = it },
                            readOnly = existingClientId != null,
                            label = "رقم جواز السفر",
                            modifier = Modifier.weight(1f),
                            testTag = "input_passport_number",
                        )
                    }

                    DatePickerTextField(
                        label = "تاريخ الميلاد",
                        value = birthDate,
                        onValueSelected = { if (existingClientId == null) birthDate = it },
                        testTag = "input_birth_date",
                    )
                }
            }

            // Section 2: Trip Details
            item {
                FormCard {
                    SectionHeaderCard(title = "2. تفاصيل رحلة العمرة", icon = Icons.Default.Flight)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        DatePickerTextField(
                            label = "تاريخ الرحلة",
                            value = tripDate,
                            onValueSelected = { tripDate = it },
                            modifier = Modifier.weight(1f),
                            testTag = "input_trip_date",
                        )
                        DatePickerTextField(
                            label = "تاريخ العودة",
                            value = returnDate,
                            onValueSelected = { returnDate = it },
                            modifier = Modifier.weight(1f),
                            testTag = "input_return_date",
                        )
                    }

                    Text(
                        text = "نوع الرحلة:",
                        style = MaterialTheme.typography.labelLarge,
                        color = TextSecondary,
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        TripType.entries.forEach { type ->
                            FilterChip(
                                selected = tripType == type,
                                onClick = { tripType = type },
                                label = { Text(type.arabicLabel) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = NavyPrimary,
                                    selectedLabelColor = GoldSecondary,
                                ),
                                modifier = Modifier.testTag("trip_type_${type.name}"),
                            )
                        }
                    }

                    if (tripType == TripType.CUSTOM) {
                        FormField(
                            value = customTripLabel,
                            onValueChange = { customTripLabel = it },
                            label = "تفاصيل البرنامج المخصص (مثال: 10 أيام طيران)",
                            testTag = "input_custom_trip_label",
                        )
                    }

                    FormField(
                        value = companyName,
                        onValueChange = { companyName = it },
                        label = "اسم شركة السياحة",
                        testTag = "input_company_name",
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        FormField(
                            value = makkahHotel,
                            onValueChange = { makkahHotel = it },
                            label = "اسم الفندق في مكة",
                            modifier = Modifier.weight(1f),
                            testTag = "input_makkah_hotel",
                        )
                        FormField(
                            value = madinahHotel,
                            onValueChange = { madinahHotel = it },
                            label = "اسم الفندق في المدينة",
                            modifier = Modifier.weight(1f),
                            testTag = "input_madinah_hotel",
                        )
                    }

                    Text(
                        text = "حالة الحجز:",
                        style = MaterialTheme.typography.labelLarge,
                        color = TextSecondary,
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        BookingStatus.entries.forEach { status ->
                            FilterChip(
                                selected = bookingStatus == status,
                                onClick = { bookingStatus = status },
                                label = { Text(status.arabicLabel) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = NavyPrimary,
                                    selectedLabelColor = GoldSecondary,
                                ),
                                modifier = Modifier.testTag("booking_status_${status.name}"),
                            )
                        }
                    }
                }
            }

            // Section 3: Financial Details
            item {
                FormCard {
                    SectionHeaderCard(title = "3. البيانات المالية والحسابات", icon = Icons.Default.Payments)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        FormField(
                            value = totalPriceStr,
                            onValueChange = { totalPriceStr = it },
                            label = "سعر الرحلة الإجمالي",
                            keyboardType = KeyboardType.Decimal,
                            modifier = Modifier.weight(1f),
                            testTag = "input_total_price",
                        )
                        FormField(
                            value = depositStr,
                            onValueChange = { depositStr = it },
                            label = "مبلغ المقدم",
                            keyboardType = KeyboardType.Decimal,
                            modifier = Modifier.weight(1f),
                            testTag = "input_deposit",
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        FormField(
                            value = extraAmountStr,
                            onValueChange = { extraAmountStr = it },
                            label = "المبالغ الإضافية",
                            keyboardType = KeyboardType.Decimal,
                            modifier = Modifier.weight(1f),
                            testTag = "input_extra_amount",
                        )
                        FormField(
                            value = costAmountStr,
                            onValueChange = { costAmountStr = it },
                            label = "التكلفة الفعلية (اختياري)",
                            keyboardType = KeyboardType.Decimal,
                            modifier = Modifier.weight(1f),
                            testTag = "input_cost_amount",
                        )
                    }

                    // Live automatic financial calculation box
                    Surface(
                        color = GoldContainer,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, GoldSecondary),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Column {
                                Text("إجمالي المدفوع (المقدم)", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                                Text(
                                    text = CurrencyFormatters.formatMoney(depositAmount),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = StatusConfirmedFg,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.testTag("preview_total_paid"),
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("المبلغ المتبقي (تلقائي)", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                                Text(
                                    text = CurrencyFormatters.formatMoney(remainingPreview),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = NavyPrimary,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.testTag("preview_remaining"),
                                )
                            }
                        }
                    }

                    FormField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = "ملاحظات خاصة بالعميل والحجز",
                        singleLine = false,
                        minLines = 3,
                        testTag = "input_notes",
                    )
                }
            }

            // Section 4: Attach Photos & Documents
            item {
                FormCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        SectionHeaderCard(
                            title = "4. الصور والمستندات (${pendingAttachments.size})",
                            icon = Icons.Default.AttachFile,
                            modifier = Modifier.weight(1f),
                        )
                        OutlinedButton(
                            onClick = { showAttachDialog = true },
                            border = BorderStroke(1.dp, NavyPrimary),
                            modifier = Modifier.testTag("add_attachment_button"),
                        ) {
                            Text("إرفاق صورة", color = NavyPrimary, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (pendingAttachments.isEmpty()) {
                        Text(
                            text = "يمكنك إرفاق صور جواز السفر، البطاقة، التأشيرة، تذكرة الطيران، أو إيصالات الدفع الآن أو لاحقًا من ملف العميل.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            pendingAttachments.forEachIndexed { index, att ->
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = SurfaceLightGray,
                                    border = BorderStroke(1.dp, BorderLight),
                                    modifier = Modifier.fillMaxWidth(),
                                ) {
                                    Row(
                                        modifier = Modifier.padding(8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                    ) {
                                        AsyncImage(
                                            model = File(att.tempFilePath),
                                            contentDescription = att.docType.arabicLabel,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier
                                                .size(56.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .border(1.dp, BorderLight, RoundedCornerShape(8.dp)),
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = att.docType.arabicLabel,
                                                style = MaterialTheme.typography.titleSmall,
                                                color = NavyPrimary,
                                                fontWeight = FontWeight.Bold,
                                            )
                                            if (att.title.isNotBlank()) {
                                                Text(
                                                    text = att.title,
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = TextSecondary,
                                                )
                                            }
                                        }
                                        IconButton(onClick = {
                                            runCatching { File(att.tempFilePath).delete() }
                                            pendingAttachments.removeAt(index)
                                        }) {
                                            Icon(Icons.Default.Close, contentDescription = "حذف المرفق", tint = StatusCancelledFg)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Save Button
            item {
                Button(
                    enabled = !isSaving,
                    onClick = {
                        formError = null
                        if (existingClientId == null && clientCode.trim().isEmpty()) {
                            formError = "يرجى إدخال كود العميل يدويًا (إجباري)."
                            return@Button
                        }
                        if (existingClientId == null && codeDuplicateError != null) {
                            formError = codeDuplicateError
                            return@Button
                        }
                        if (fullName.trim().isEmpty()) {
                            formError = "يرجى إدخال اسم العميل بالكامل."
                            return@Button
                        }

                        isSaving = true
                        val booking = BookingEntity(
                            clientId = existingClientId ?: 0L,
                            tripDate = tripDate.trim(),
                            returnDate = returnDate.trim(),
                            tripType = tripType,
                            customTripLabel = if (tripType == TripType.CUSTOM) customTripLabel.trim() else "",
                            companyName = companyName.trim(),
                            makkahHotel = makkahHotel.trim(),
                            madinahHotel = madinahHotel.trim(),
                            totalPrice = totalPrice,
                            extraAmount = extraAmount,
                            costAmount = costAmount,
                            status = bookingStatus,
                            notes = notes.trim(),
                        )

                        val handleResult: (SaveResult) -> Unit = { res ->
                            isSaving = false
                            when (res) {
                                is SaveResult.Success -> onSavedSuccess(res.clientId)
                                is SaveResult.ValidationError -> formError = res.message
                            }
                        }

                        if (existingClientId != null && existingClientId > 0L) {
                            viewModel.addBookingForExistingClient(
                                clientId = existingClientId,
                                booking = booking,
                                depositAmount = depositAmount,
                                attachments = pendingAttachments.toList(),
                                onResult = handleResult,
                            )
                        } else {
                            viewModel.saveNewClientAndBooking(
                                clientCode = clientCode,
                                fullName = fullName,
                                phone = phone,
                                whatsapp = whatsapp,
                                nationalId = nationalId,
                                passportNumber = passportNumber,
                                birthDate = birthDate,
                                clientNotes = notes,
                                booking = booking,
                                depositAmount = depositAmount,
                                attachments = pendingAttachments.toList(),
                                onResult = handleResult,
                            )
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NavyPrimary,
                        contentColor = BackgroundWhite,
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("save_booking_button"),
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, tint = GoldSecondary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isSaving) "جاري الحفظ..." else "حفظ الحجز والبيانات",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
    }

    if (showAttachDialog) {
        AttachDocumentDialog(
            onPickGallery = { type, title ->
                pendingDocType = type
                pendingDocTitle = title
                showAttachDialog = false
                photoPickerLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                )
            },
            onCaptureCamera = { type, title ->
                pendingDocType = type
                pendingDocTitle = title
                showAttachDialog = false
                val hasCam = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.CAMERA,
                ) == PackageManager.PERMISSION_GRANTED
                if (hasCam) {
                    val (file, uri) = viewModel.documentStorage.createTempCameraFileAndUri()
                    activeCameraTempFile = file
                    takePictureLauncher.launch(uri)
                } else {
                    cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                }
            },
            onDismiss = { showAttachDialog = false },
        )
    }
}

@Composable
private fun FormCard(content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = BackgroundWhite),
        border = BorderStroke(1.dp, BorderLight),
        shape = RoundedCornerShape(16.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            content()
        }
    }
}

@Composable
private fun FormField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    readOnly: Boolean = false,
    keyboardType: KeyboardType = KeyboardType.Text,
    singleLine: Boolean = true,
    minLines: Int = 1,
    testTag: String? = null,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        readOnly = readOnly,
        label = { Text(label) },
        singleLine = singleLine,
        minLines = minLines,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        colors = formFieldColors(),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
            .fillMaxWidth()
            .then(if (testTag != null) Modifier.testTag(testTag) else Modifier),
    )
}

@Composable
private fun formFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = NavyPrimary,
    unfocusedBorderColor = BorderLight,
    focusedContainerColor = BackgroundWhite,
    unfocusedContainerColor = BackgroundWhite,
)
