package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.R
import com.example.auth.JobyAuthScreen
import com.example.auth.signOut
import com.example.data.JobyRepository
import com.example.localization.AppLocalization
import com.example.localization.LocalAppStrings
import com.example.model.JobListing
import com.example.model.UserProfile
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.JobyTopBar
import com.example.ui.screens.AdminCenterScreen
import com.example.ui.screens.EmployerCandidatesScreen
import com.example.ui.screens.EmployerDashboardScreen
import com.example.ui.screens.EmployerPostingsScreen
import com.example.ui.screens.ExploreJobsScreen
import com.example.ui.screens.JobDetailBottomSheet
import com.example.ui.screens.MessagesScreen
import com.example.ui.screens.NotificationsSheet
import com.example.ui.screens.ProfileAndSettingsScreen
import com.example.ui.screens.ProfileSetupOrEditScreen
import com.example.ui.screens.SeekerApplicationsScreen
import com.example.ui.screens.SeekerHomeScreen
import com.example.ui.screens.SideQuestsScreen
import com.example.ui.screens.WebPortalScreen
import com.example.ui.viewmodel.JobyViewModel
import com.example.ui.viewmodel.UiState
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore

private data class NavTab(
  val id: String,
  val label: String,
  val icon: ImageVector
)

@Composable
fun AppNavigation() {
  var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }

  DisposableEffect(Unit) {
    val listener = FirebaseAuth.AuthStateListener { auth ->
      currentUser = auth.currentUser
    }
    Firebase.auth.addAuthStateListener(listener)
    onDispose {
      Firebase.auth.removeAuthStateListener(listener)
    }
  }

  val user = currentUser
  if (user == null) {
    JobyAuthScreen(
      onAuthSuccess = { currentUser = Firebase.auth.currentUser }
    )
  } else {
    val uid = user.uid
    key(uid) {
      JobyAuthenticatedRoot(
        currentUserId = uid,
        userEmail = user.email ?: "",
        userDisplayName = user.displayName ?: ""
      )
    }
  }
}

@Composable
private fun JobyAuthenticatedRoot(
  currentUserId: String,
  userEmail: String,
  userDisplayName: String
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val credentialManager = remember(context) { CredentialManager.create(context) }

  val viewModel: JobyViewModel = viewModel(
    key = currentUserId,
    factory = viewModelFactory {
      initializer {
        val app = checkNotNull(this[APPLICATION_KEY]) { "APPLICATION_KEY missing" }
        val databaseId = app.getString(R.string.firestore_database_id)
        val db = FirebaseFirestore.getInstance(databaseId)
        JobyViewModel(
          repository = JobyRepository(db),
          currentUserId = currentUserId,
          userEmail = userEmail,
          userDisplayName = userDisplayName
        )
      }
    }
  )

  val profileState by viewModel.userProfileState.collectAsStateWithLifecycle()
  val approvedJobsState by viewModel.approvedJobsState.collectAsStateWithLifecycle()
  val employerJobsState by viewModel.employerJobsState.collectAsStateWithLifecycle()
  val approvedQuestsState by viewModel.approvedSideQuestsState.collectAsStateWithLifecycle()
  val employerQuestsState by viewModel.employerSideQuestsState.collectAsStateWithLifecycle()
  val seekerAppsState by viewModel.seekerApplicationsState.collectAsStateWithLifecycle()
  val employerAppsState by viewModel.employerApplicationsState.collectAsStateWithLifecycle()
  val conversationsState by viewModel.conversationsState.collectAsStateWithLifecycle()
  val activeConvId by viewModel.activeConversationId.collectAsStateWithLifecycle()
  val messagesState by viewModel.activeMessagesState.collectAsStateWithLifecycle()
  val notificationsState by viewModel.notificationsState.collectAsStateWithLifecycle()
  val plansState by viewModel.subscriptionPlansState.collectAsStateWithLifecycle()
  val userTxnsState by viewModel.userTransactionsState.collectAsStateWithLifecycle()
  val filterState by viewModel.filterState.collectAsStateWithLifecycle()
  val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()
  val isBusy by viewModel.isBusy.collectAsStateWithLifecycle()

  // Admin flows
  val allUsersAdmin by viewModel.allUsersAdminState.collectAsStateWithLifecycle()
  val allJobsAdmin by viewModel.allJobsAdminState.collectAsStateWithLifecycle()
  val allQuestsAdmin by viewModel.allSideQuestsAdminState.collectAsStateWithLifecycle()
  val allReportsAdmin by viewModel.allReportsAdminState.collectAsStateWithLifecycle()
  val allTxnsAdmin by viewModel.allTransactionsAdminState.collectAsStateWithLifecycle()

  val snackbarHostState = remember { SnackbarHostState() }
  LaunchedEffect(snackbarMessage) {
    val msg = snackbarMessage
    if (msg != null) {
      snackbarHostState.showSnackbar(msg)
      viewModel.clearSnackbar()
    }
  }

  when (val pState = profileState) {
    UiState.Loading -> {
      Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator()
      }
    }
    is UiState.Error -> {
      Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        EmptyStateCard(
          title = "Unable to load profile",
          subtitle = pState.message
        )
      }
    }
    is UiState.Success -> {
      val profile = pState.data
      if (profile == null) {
        ProfileSetupOrEditScreen(
          existingProfile = null,
          userId = currentUserId,
          defaultEmail = userEmail,
          defaultName = userDisplayName,
          isBusy = isBusy,
          isFirstTimeSetup = true,
          onSave = { viewModel.saveUserProfile(it) }
        )
      } else {
        val strings = remember(profile.preferredLanguage) {
          AppLocalization.forCode(profile.preferredLanguage)
        }
        CompositionLocalProvider(LocalAppStrings provides strings) {
          JobyMarketplaceShell(
            profile = profile,
            viewModel = viewModel,
            snackbarHostState = snackbarHostState,
            approvedJobs = (approvedJobsState as? UiState.Success)?.data ?: emptyList(),
            employerJobs = (employerJobsState as? UiState.Success)?.data ?: emptyList(),
            approvedQuests = (approvedQuestsState as? UiState.Success)?.data ?: emptyList(),
            employerQuests = (employerQuestsState as? UiState.Success)?.data ?: emptyList(),
            seekerApps = (seekerAppsState as? UiState.Success)?.data ?: emptyList(),
            employerApps = (employerAppsState as? UiState.Success)?.data ?: emptyList(),
            conversations = (conversationsState as? UiState.Success)?.data ?: emptyList(),
            activeConvId = activeConvId,
            messages = (messagesState as? UiState.Success)?.data ?: emptyList(),
            notifications = (notificationsState as? UiState.Success)?.data ?: emptyList(),
            plans = (plansState as? UiState.Success)?.data ?: emptyList(),
            userTxns = (userTxnsState as? UiState.Success)?.data ?: emptyList(),
            allUsersAdmin = (allUsersAdmin as? UiState.Success)?.data ?: emptyList(),
            allJobsAdmin = (allJobsAdmin as? UiState.Success)?.data ?: emptyList(),
            allQuestsAdmin = (allQuestsAdmin as? UiState.Success)?.data ?: emptyList(),
            allReportsAdmin = (allReportsAdmin as? UiState.Success)?.data ?: emptyList(),
            allTxnsAdmin = (allTxnsAdmin as? UiState.Success)?.data ?: emptyList(),
            filterState = filterState,
            isBusy = isBusy,
            onSignOut = {
              signOut(credentialManager = credentialManager, scope = scope)
            }
          )
        }
      }
    }
  }
}

@Composable
private fun JobyMarketplaceShell(
  profile: UserProfile,
  viewModel: JobyViewModel,
  snackbarHostState: SnackbarHostState,
  approvedJobs: List<JobListing>,
  employerJobs: List<JobListing>,
  approvedQuests: List<com.example.model.SideQuest>,
  employerQuests: List<com.example.model.SideQuest>,
  seekerApps: List<com.example.model.JobApplication>,
  employerApps: List<com.example.model.JobApplication>,
  conversations: List<com.example.model.Conversation>,
  activeConvId: String?,
  messages: List<com.example.model.ChatMessage>,
  notifications: List<com.example.model.AppNotification>,
  plans: List<com.example.model.SubscriptionPlan>,
  userTxns: List<com.example.model.PaymentTransaction>,
  allUsersAdmin: List<UserProfile>,
  allJobsAdmin: List<JobListing>,
  allQuestsAdmin: List<com.example.model.SideQuest>,
  allReportsAdmin: List<com.example.model.ModerationReport>,
  allTxnsAdmin: List<com.example.model.PaymentTransaction>,
  filterState: com.example.ui.viewmodel.JobFilterState,
  isBusy: Boolean,
  onSignOut: () -> Unit
) {
  val strings = LocalAppStrings.current
  val isEmployer = profile.role == "EMPLOYER"

  val tabs = remember(isEmployer, strings) {
    if (isEmployer) {
      listOf(
        NavTab("EMP_DASH", strings.navDashboard, Icons.Filled.Dashboard),
        NavTab("EMP_POSTS", strings.navPostings, Icons.Filled.Work),
        NavTab("EMP_CANDS", strings.navCandidates, Icons.Filled.People),
        NavTab("MESSAGES", strings.navMessages, Icons.Filled.Chat),
        NavTab("PROFILE", strings.navProfile, Icons.Filled.Person)
      )
    } else {
      listOf(
        NavTab("HOME", strings.navHome, Icons.Filled.Home),
        NavTab("EXPLORE", strings.navExplore, Icons.Filled.Explore),
        NavTab("SIDE_QUESTS", strings.navSideQuests, Icons.Filled.Bolt),
        NavTab("APPLICATIONS", strings.navApplications, Icons.Filled.Assignment),
        NavTab("PROFILE", strings.navProfile, Icons.Filled.Person)
      )
    }
  }

  var currentTab by remember(isEmployer) {
    mutableStateOf(if (isEmployer) "EMP_DASH" else "HOME")
  }
  var showNotifications by remember { mutableStateOf(false) }
  var selectedJobForDetail by remember { mutableStateOf<JobListing?>(null) }
  var showEditProfile by remember { mutableStateOf(false) }
  var showAdminCenter by remember { mutableStateOf(false) }
  var showWebPortal by remember { mutableStateOf(false) }
  var showSeekerChat by remember { mutableStateOf(false) }

  if (showEditProfile) {
    BackHandler { showEditProfile = false }
  } else if (showAdminCenter) {
    BackHandler { showAdminCenter = false }
  } else if (showWebPortal) {
    BackHandler { showWebPortal = false }
  } else if (showSeekerChat && !isEmployer) {
    BackHandler {
      viewModel.openConversation(null)
      showSeekerChat = false
    }
  }

  val unreadCount = remember(notifications) { notifications.count { !it.isRead } }

  BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
    val useRail = maxWidth >= 600.dp

    Scaffold(
      contentWindowInsets = WindowInsets(0, 0, 0, 0),
      snackbarHost = { SnackbarHost(snackbarHostState) },
      topBar = {
        JobyTopBar(
          roleLabel = when {
            showAdminCenter -> "ADMIN CONTROL"
            showWebPortal -> "WEB PORTAL"
            isEmployer -> "EMPLOYER MODE"
            else -> "JOB SEEKER"
          },
          unreadNotifications = unreadCount,
          currentLanguage = profile.preferredLanguage,
          onLanguageSelected = { viewModel.switchLanguage(it) },
          onNotificationsClick = { showNotifications = true },
          modifier = Modifier.statusBarsPadding()
        )
      },
      bottomBar = {
        if (!useRail && !showEditProfile && !showAdminCenter && !showWebPortal) {
          NavigationBar(
            containerColor = MaterialTheme.colorScheme.surface,
            modifier = Modifier.navigationBarsPadding()
          ) {
            tabs.forEach { tab ->
              NavigationBarItem(
                selected = currentTab == tab.id && !showSeekerChat,
                onClick = {
                  showSeekerChat = false
                  currentTab = tab.id
                },
                icon = { Icon(tab.icon, contentDescription = tab.label) },
                label = { Text(tab.label, maxLines = 1) }
              )
            }
          }
        }
      }
    ) { innerPadding ->
      Row(
        modifier = Modifier
          .fillMaxSize()
          .padding(innerPadding)
      ) {
        if (useRail && !showEditProfile && !showAdminCenter && !showWebPortal) {
          NavigationRail {
            tabs.forEach { tab ->
              NavigationRailItem(
                selected = currentTab == tab.id && !showSeekerChat,
                onClick = {
                  showSeekerChat = false
                  currentTab = tab.id
                },
                icon = { Icon(tab.icon, contentDescription = tab.label) },
                label = { Text(tab.label) }
              )
            }
          }
        }

        Column(modifier = Modifier.weight(1f).fillMaxSize()) {
          when {
            showEditProfile -> {
              ProfileSetupOrEditScreen(
                existingProfile = profile,
                userId = profile.userId,
                defaultEmail = profile.email,
                defaultName = profile.displayName,
                isBusy = isBusy,
                isFirstTimeSetup = false,
                onSave = { updated ->
                  viewModel.saveUserProfile(updated) { showEditProfile = false }
                },
                onCancel = { showEditProfile = false }
              )
            }
            showAdminCenter && viewModel.isAdminUser -> {
              AdminCenterScreen(
                allUsers = allUsersAdmin,
                allJobs = allJobsAdmin,
                allQuests = allQuestsAdmin,
                allReports = allReportsAdmin,
                plans = plans,
                transactions = allTxnsAdmin,
                isBusy = isBusy,
                onBack = { showAdminCenter = false },
                onSeedMarketplace = { viewModel.seedMarketplaceSampleData() },
                onModerateJob = { id, st -> viewModel.moderateJob(id, st) },
                onModerateQuest = { id, st -> viewModel.moderateSideQuest(id, st) },
                onVerifyCompany = { uid, v -> viewModel.setCompanyVerifiedAdmin(uid, v) },
                onSetUserStatus = { uid, st -> viewModel.setUserStatusAdmin(uid, st) },
                onResolveReport = { id, st, note -> viewModel.resolveReportAdmin(id, st, note) },
                onSavePlan = { viewModel.saveSubscriptionPlanAdmin(it) }
              )
            }
            showWebPortal -> {
              WebPortalScreen(onBack = { showWebPortal = false })
            }
            showSeekerChat && !isEmployer -> {
              MessagesScreen(
                profile = profile,
                conversations = conversations,
                activeConversationId = activeConvId,
                messages = messages,
                onOpenConversation = { id ->
                  if (id == null) {
                    viewModel.openConversation(null)
                    showSeekerChat = false
                  } else {
                    viewModel.openConversation(id)
                  }
                },
                onSendMessage = { conv, txt -> viewModel.sendMessage(conv, profile.displayName, txt) }
              )
            }
            currentTab == "HOME" -> {
              SeekerHomeScreen(
                profile = profile,
                jobs = approvedJobs,
                quests = approvedQuests,
                applications = seekerApps,
                isAdminUser = viewModel.isAdminUser,
                onSeedSampleData = { viewModel.seedMarketplaceSampleData() },
                onToggleSave = { viewModel.toggleSavedJob(profile.savedJobIds, it) },
                onSelectJob = { selectedJobForDetail = it },
                onNavigateExplore = { currentTab = "EXPLORE" },
                onNavigateSideQuests = { currentTab = "SIDE_QUESTS" },
                onNavigateProfileEdit = { showEditProfile = true }
              )
            }
            currentTab == "EXPLORE" -> {
              ExploreJobsScreen(
                profile = profile,
                jobs = approvedJobs,
                filterState = filterState,
                onUpdateFilter = { viewModel.updateFilter(it) },
                onToggleSave = { viewModel.toggleSavedJob(profile.savedJobIds, it) },
                onSelectJob = { selectedJobForDetail = it }
              )
            }
            currentTab == "SIDE_QUESTS" -> {
              SideQuestsScreen(
                profile = profile,
                quests = approvedQuests,
                onClaimQuest = { viewModel.claimSideQuest(it, profile) },
                onSubmitProof = { q, note -> viewModel.submitSideQuestProof(q, note) }
              )
            }
            currentTab == "APPLICATIONS" -> {
              SeekerApplicationsScreen(
                applications = seekerApps,
                onWithdraw = { viewModel.updateApplicationStatus(it, "WITHDRAWN") },
                onMessageEmployer = { app ->
                  viewModel.startConversation(
                    seekerId = app.seekerId,
                    employerId = app.employerId,
                    seekerName = app.seekerName,
                    employerName = app.companyName,
                    jobTitle = app.jobTitle
                  ) {
                    showSeekerChat = true
                  }
                }
              )
            }
            currentTab == "EMP_DASH" -> {
              EmployerDashboardScreen(
                profile = profile,
                employerJobs = employerJobs,
                employerQuests = employerQuests,
                applications = employerApps,
                plans = plans,
                isBusy = isBusy,
                onUpgradePlan = { plan, method -> viewModel.upgradeSubscription(profile, plan, method) }
              )
            }
            currentTab == "EMP_POSTS" -> {
              EmployerPostingsScreen(
                profile = profile,
                employerJobs = employerJobs,
                employerQuests = employerQuests,
                isBusy = isBusy,
                onCreateJob = { viewModel.createJob(it) },
                onToggleJobActive = { id, active -> viewModel.toggleJobActive(id, active) },
                onCreateQuest = { viewModel.createSideQuest(it) },
                onReleaseQuestPayout = { viewModel.releaseSideQuestPayout(it) }
              )
            }
            currentTab == "EMP_CANDS" -> {
              EmployerCandidatesScreen(
                applications = employerApps,
                onUpdateStatus = { app, st, note -> viewModel.updateApplicationStatus(app, st, note) },
                onMessageCandidate = { app ->
                  viewModel.startConversation(
                    seekerId = app.seekerId,
                    employerId = app.employerId,
                    seekerName = app.seekerName,
                    employerName = app.companyName,
                    jobTitle = app.jobTitle
                  ) {
                    currentTab = "MESSAGES"
                  }
                }
              )
            }
            currentTab == "MESSAGES" -> {
              MessagesScreen(
                profile = profile,
                conversations = conversations,
                activeConversationId = activeConvId,
                messages = messages,
                onOpenConversation = { viewModel.openConversation(it) },
                onSendMessage = { conv, txt -> viewModel.sendMessage(conv, profile.displayName, txt) }
              )
            }
            currentTab == "PROFILE" -> {
              val savedJobs = remember(approvedJobs, profile.savedJobIds) {
                approvedJobs.filter { it.id in profile.savedJobIds }
              }
              ProfileAndSettingsScreen(
                profile = profile,
                savedJobs = savedJobs,
                transactions = userTxns,
                isAdminUser = viewModel.isAdminUser,
                onEditProfile = { showEditProfile = true },
                onSwitchRole = { newRole ->
                  viewModel.saveUserProfile(
                    profile.copy(
                      role = newRole,
                      companyName = if (newRole == "EMPLOYER" && profile.companyName.isBlank()) "${profile.displayName} Enterprises" else profile.companyName
                    )
                  )
                },
                onOpenAdminCenter = { showAdminCenter = true },
                onOpenWebPortal = { showWebPortal = true },
                onSelectSavedJob = { selectedJobForDetail = it },
                onToggleSave = { viewModel.toggleSavedJob(profile.savedJobIds, it) },
                onSignOut = onSignOut
              )
            }
          }
        }
      }
    }
  }

  if (selectedJobForDetail != null) {
    val job = selectedJobForDetail!!
    val alreadyApplied = seekerApps.any { it.jobId == job.id && it.status != "WITHDRAWN" }
    JobDetailBottomSheet(
      job = job,
      profile = profile,
      alreadyApplied = alreadyApplied,
      isBusy = isBusy,
      onDismiss = { selectedJobForDetail = null },
      onApply = { note ->
        viewModel.applyToJob(job, profile, note) {
          selectedJobForDetail = null
        }
      },
      onMessageEmployer = {
        viewModel.startConversation(
          seekerId = profile.userId,
          employerId = job.employerId,
          seekerName = profile.displayName,
          employerName = job.companyName,
          jobTitle = job.title
        ) {
          selectedJobForDetail = null
          if (isEmployer) currentTab = "MESSAGES" else showSeekerChat = true
        }
      },
      onSubmitReport = { reason, details ->
        viewModel.submitReport("JOB", job.id, job.title, reason, details)
      }
    )
  }

  if (showNotifications) {
    NotificationsSheet(
      notifications = notifications,
      onMarkRead = { viewModel.markNotificationRead(it) },
      onDismiss = { showNotifications = false }
    )
  }
}
