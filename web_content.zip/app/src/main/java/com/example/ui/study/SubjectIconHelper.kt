package com.example.ui.study

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Science
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

data class PresetSubjectIcon(
    val name: String,
    val label: String,
    val icon: ImageVector
)

data class PresetSubjectColor(
    val hex: String,
    val label: String,
    val color: Color
)

object SubjectStylePresets {
    val ICONS = listOf(
        PresetSubjectIcon("school", "General", Icons.Default.School),
        PresetSubjectIcon("book", "Reading", Icons.Default.MenuBook),
        PresetSubjectIcon("calculate", "Math", Icons.Default.Calculate),
        PresetSubjectIcon("science", "Science", Icons.Default.Science),
        PresetSubjectIcon("code", "Code", Icons.Default.Code),
        PresetSubjectIcon("gavel", "Law", Icons.Default.Gavel),
        PresetSubjectIcon("language", "Language", Icons.Default.Public),
        PresetSubjectIcon("palette", "Arts", Icons.Default.Palette)
    )

    val COLORS = listOf(
        PresetSubjectColor("#2563EB", "Blue", Color(0xFF2563EB)),
        PresetSubjectColor("#0D9488", "Teal", Color(0xFF0D9488)),
        PresetSubjectColor("#16A34A", "Green", Color(0xFF16A34A)),
        PresetSubjectColor("#D97706", "Amber", Color(0xFFD97706)),
        PresetSubjectColor("#E11D48", "Rose", Color(0xFFE11D48)),
        PresetSubjectColor("#7C3AED", "Purple", Color(0xFF7C3AED)),
        PresetSubjectColor("#0891B2", "Cyan", Color(0xFF0891B2)),
        PresetSubjectColor("#EA580C", "Orange", Color(0xFFEA580C))
    )

    fun getIcon(name: String): ImageVector {
        return ICONS.find { it.name.equals(name, ignoreCase = true) }?.icon ?: Icons.Default.School
    }

    fun getColor(hex: String): Color {
        return try {
            Color(android.graphics.Color.parseColor(hex))
        } catch (e: Exception) {
            Color(0xFF2563EB)
        }
    }
}
