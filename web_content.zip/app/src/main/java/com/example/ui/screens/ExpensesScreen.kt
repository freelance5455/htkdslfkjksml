package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.EXPENSE_CATEGORIES
import com.example.data.model.ExpenseEntity
import com.example.data.model.PAYMENT_METHODS
import com.example.data.model.RecurrenceFrequency
import com.example.ui.components.FinancialInputField
import com.example.ui.viewmodel.BusinessViewModel
import com.example.util.DateUtils
import com.example.util.FinancialMath

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpensesScreen(
    viewModel: BusinessViewModel,
    modifier: Modifier = Modifier
) {
    val expenses by viewModel.allExpenses.collectAsStateWithLifecycle()

    var showAddDialog by remember { mutableStateOf(false) }
    var expenseToEdit by remember { mutableStateOf<ExpenseEntity?>(null) }
    var expenseToDelete by remember { mutableStateOf<ExpenseEntity?>(null) }
    var selectedCategoryFilter by remember { mutableStateOf("ALL") }

    val filteredExpenses = remember(expenses, selectedCategoryFilter) {
        if (selectedCategoryFilter == "ALL") expenses
        else expenses.filter { it.category == selectedCategoryFilter }
    }

    val totalExpenseSum = remember(filteredExpenses) {
        filteredExpenses.sumOf { it.amount }
    }
    val paidSum = remember(filteredExpenses) {
        filteredExpenses.filter { it.isPaid }.sumOf { it.amount }
    }
    val unpaidSum = remember(filteredExpenses) {
        filteredExpenses.filter { !it.isPaid }.sumOf { it.amount }
    }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text(
                            text = "Operating Expenses",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Track overhead, platform charges & recurring bills",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Button(
                        onClick = { showAddDialog = true },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("add_expense_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Summary Card
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.35f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Column {
                            Text("Total Expenses", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(FinancialMath.formatInr(totalExpenseSum), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("Paid", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(FinancialMath.formatInr(paidSum), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF0D652D))
                        }
                        Column {
                            Text("Unpaid / Scheduled", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(FinancialMath.formatInr(unpaidSum), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFFC5221F))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Category Filter Row
                Text(
                    text = "Filter by Category",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    FilterChip(
                        selected = selectedCategoryFilter == "ALL",
                        onClick = { selectedCategoryFilter = "ALL" },
                        label = { Text("All (${expenses.size})") }
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
            }

            if (filteredExpenses.isEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 24.dp)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp)
                        ) {
                            Icon(Icons.Default.MoneyOff, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("No expenses recorded")
                            Text("Click '+ Add' to record overhead, rent, subscriptions, or bank charges.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            } else {
                items(filteredExpenses, key = { it.id }) { expense ->
                    ExpenseCard(
                        expense = expense,
                        onTogglePaid = { viewModel.toggleExpensePaidStatus(expense) },
                        onToggleRecurring = { viewModel.toggleRecurringStatus(expense) },
                        onEdit = { expenseToEdit = expense },
                        onDelete = { expenseToDelete = expense }
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                }
            }

            item {
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }

    if (showAddDialog) {
        ExpenseDialog(
            title = "Record Business Expense",
            initialExpense = null,
            onDismiss = { showAddDialog = false },
            onSave = { name, cat, amount, method, isPaid, notes, recurrence, start, end, linkedTx ->
                viewModel.addExpense(
                    name = name,
                    category = cat,
                    amount = amount,
                    date = System.currentTimeMillis(),
                    paymentMethod = method,
                    isPaid = isPaid,
                    notes = notes,
                    recurrence = recurrence,
                    startDate = start,
                    endDate = end,
                    linkedTxId = linkedTx
                )
                showAddDialog = false
            }
        )
    }

    expenseToEdit?.let { exp ->
        ExpenseDialog(
            title = "Edit Expense",
            initialExpense = exp,
            onDismiss = { expenseToEdit = null },
            onSave = { name, cat, amount, method, isPaid, notes, recurrence, start, end, linkedTx ->
                viewModel.updateExpense(
                    exp.copy(
                        name = name,
                        category = cat,
                        amount = amount,
                        paymentMethod = method,
                        isPaid = isPaid,
                        notes = notes,
                        recurrence = recurrence,
                        startDate = start,
                        endDate = end,
                        linkedTransactionId = linkedTx
                    )
                )
                expenseToEdit = null
            }
        )
    }

    expenseToDelete?.let { exp ->
        AlertDialog(
            onDismissRequest = { expenseToDelete = null },
            title = { Text("Delete Expense") },
            text = { Text("Delete '${exp.name}' (${FinancialMath.formatInr(exp.amount)})? This action cannot be undone.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteExpense(exp.id)
                        expenseToDelete = null
                    }
                ) {
                    Text("Delete", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { expenseToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun ExpenseCard(
    expense: ExpenseEntity,
    onTogglePaid: () -> Unit,
    onToggleRecurring: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
        ),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(expense.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "${expense.category} • ${DateUtils.formatDate(expense.date)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(FinancialMath.formatInr(expense.amount), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.error)
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (expense.isPaid) Color(0xFFE6F4EA) else Color(0xFFFCE8E6),
                        modifier = Modifier.padding(top = 2.dp)
                    ) {
                        Text(
                            text = if (expense.isPaid) "PAID" else "UNPAID",
                            color = if (expense.isPaid) Color(0xFF137333) else Color(0xFFC5221F),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            if (expense.notes.isNotBlank()) {
                Text(
                    text = expense.notes,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Recurrence: ${expense.recurrence}",
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (expense.recurrence != RecurrenceFrequency.ONE_TIME.name) {
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(onClick = onToggleRecurring, modifier = Modifier.size(24.dp)) {
                            Icon(
                                imageVector = if (expense.isRecurringActive) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Toggle recurrence",
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = onTogglePaid) {
                        Text(if (expense.isPaid) "Mark Unpaid" else "Mark Paid", fontSize = 12.sp)
                    }
                    IconButton(onClick = onEdit, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit", modifier = Modifier.size(16.dp))
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpenseDialog(
    title: String,
    initialExpense: ExpenseEntity?,
    onDismiss: () -> Unit,
    onSave: (
        name: String,
        category: String,
        amount: Double,
        paymentMethod: String,
        isPaid: Boolean,
        notes: String,
        recurrence: String,
        startDate: Long,
        endDate: Long?,
        linkedTx: String?
    ) -> Unit
) {
    var name by remember { mutableStateOf(initialExpense?.name ?: "") }
    var category by remember { mutableStateOf(initialExpense?.category ?: EXPENSE_CATEGORIES.first()) }
    var isCategoryExpanded by remember { mutableStateOf(false) }

    var amountText by remember { mutableStateOf(initialExpense?.amount?.toString() ?: "") }
    var paymentMethod by remember { mutableStateOf(initialExpense?.paymentMethod ?: "UPI") }
    var isMethodExpanded by remember { mutableStateOf(false) }

    var isPaid by remember { mutableStateOf(initialExpense?.isPaid ?: true) }
    var recurrence by remember { mutableStateOf(initialExpense?.recurrence ?: RecurrenceFrequency.ONE_TIME.name) }
    var isRecurrenceExpanded by remember { mutableStateOf(false) }

    var notes by remember { mutableStateOf(initialExpense?.notes ?: "") }
    var linkedTx by remember { mutableStateOf(initialExpense?.linkedTransactionId ?: "") }

    val amountValidation = FinancialMath.validateAmount(amountText, "Expense Amount")
    val isFormValid = name.isNotBlank() && amountValidation.isValid

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Expense Name *") },
                    placeholder = { Text("e.g. Office Rent, POS Machine Fee") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                FinancialInputField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = "Amount (₹) *",
                    placeholder = "0.00",
                    validationResult = amountValidation
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Category Dropdown
                ExposedDropdownMenuBox(
                    expanded = isCategoryExpanded,
                    onExpandedChange = { isCategoryExpanded = !isCategoryExpanded }
                ) {
                    OutlinedTextField(
                        value = category,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Category") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isCategoryExpanded) },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = isCategoryExpanded,
                        onDismissRequest = { isCategoryExpanded = false }
                    ) {
                        EXPENSE_CATEGORIES.forEach { cat ->
                            DropdownMenuItem(
                                text = { Text(cat) },
                                onClick = {
                                    category = cat
                                    isCategoryExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Recurrence Dropdown
                ExposedDropdownMenuBox(
                    expanded = isRecurrenceExpanded,
                    onExpandedChange = { isRecurrenceExpanded = !isRecurrenceExpanded }
                ) {
                    OutlinedTextField(
                        value = recurrence,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Recurrence") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isRecurrenceExpanded) },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = isRecurrenceExpanded,
                        onDismissRequest = { isRecurrenceExpanded = false }
                    ) {
                        RecurrenceFrequency.entries.forEach { rf ->
                            DropdownMenuItem(
                                text = { Text(rf.name.replace("_", " ")) },
                                onClick = {
                                    recurrence = rf.name
                                    isRecurrenceExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Paid toggle
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Payment Status: ${if (isPaid) "Paid" else "Unpaid"}", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = isPaid, onCheckedChange = { isPaid = it })
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes (Optional)") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (isFormValid) {
                        val amt = FinancialMath.parseDoubleOrNull(amountText) ?: 0.0
                        onSave(
                            name,
                            category,
                            amt,
                            paymentMethod,
                            isPaid,
                            notes,
                            recurrence,
                            System.currentTimeMillis(),
                            null,
                            linkedTx.ifBlank { null }
                        )
                    }
                },
                enabled = isFormValid
            ) {
                Text("Save Expense")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
