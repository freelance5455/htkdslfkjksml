package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CycleSummary
import com.example.ui.theme.Cycle1Color
import com.example.ui.theme.Cycle2Color
import com.example.ui.theme.Cycle3Color
import com.example.ui.theme.DexterSurface

@Composable
fun CycleCard(
    cycle: CycleSummary,
    onStatusChange: (newStatus: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val accentColor = when (cycle.cycleNumber) {
        1 -> Cycle1Color
        2 -> Cycle2Color
        else -> Cycle3Color
    }

    var showMenu by remember { mutableStateOf(false) }

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = DexterSurface),
        border = BorderStroke(
            width = if (cycle.isCurrent) 1.8.dp else 1.dp,
            color = if (cycle.isCurrent) accentColor else Color(0xFF1E293B)
        ),
        elevation = CardDefaults.cardElevation(if (cycle.isCurrent) 6.dp else 2.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    if (cycle.isCurrent) {
                        Brush.verticalGradient(
                            colors = listOf(
                                accentColor.copy(alpha = 0.09f),
                                DexterSurface
                            )
                        )
                    } else {
                        Brush.linearGradient(
                            colors = listOf(
                                Color(0xFF0F172A),
                                Color(0xFF0D1527)
                            )
                        )
                    }
                )
                .padding(16.dp)
        ) {
            Column {
                // Top Row: Title + Date Range + Status Chip
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(accentColor)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Cycle ${cycle.cycleNumber}",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 16.sp,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "(${cycle.dateRangeText})",
                            fontSize = 12.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }

                    // Status Badge with Dropdown
                    Box {
                        val (statusBg, statusFg, statusIcon) = when (cycle.status) {
                            "PAID" -> Triple(
                                Color(0xFF064E3B),
                                Color(0xFF34D399),
                                Icons.Default.CheckCircle
                            )
                            "INVOICED" -> Triple(
                                Color(0xFF0C3553),
                                Color(0xFF38BDF8),
                                Icons.Default.Receipt
                            )
                            else -> Triple(
                                Color(0xFF451A03),
                                Color(0xFFFBBF24),
                                Icons.Default.HourglassEmpty
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = statusBg,
                            border = BorderStroke(1.dp, statusFg.copy(alpha = 0.5f)),
                            modifier = Modifier.clickable { showMenu = true }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            ) {
                                Icon(
                                    statusIcon,
                                    contentDescription = null,
                                    tint = statusFg,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = cycle.status,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = statusFg,
                                    letterSpacing = 0.5.sp
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false },
                            modifier = Modifier.background(Color(0xFF1E293B))
                        ) {
                            DropdownMenuItem(
                                text = { Text("Pending Payout", color = Color(0xFFFBBF24), fontWeight = FontWeight.Bold) },
                                onClick = {
                                    onStatusChange("PENDING")
                                    showMenu = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Invoice Generated", color = Color(0xFF38BDF8), fontWeight = FontWeight.Bold) },
                                onClick = {
                                    onStatusChange("INVOICED")
                                    showMenu = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Paid / Settled", color = Color(0xFF34D399), fontWeight = FontWeight.Bold) },
                                onClick = {
                                    onStatusChange("PAID")
                                    showMenu = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Middle: Metrics Row
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text(
                            text = "DELIVERIES",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF64748B),
                            letterSpacing = 0.6.sp
                        )
                        Text(
                            text = "${cycle.totalDeliveries}",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                        Text(
                            text = "${cycle.entryCount} days logged",
                            fontSize = 11.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "CYCLE KAMAI",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF64748B),
                            letterSpacing = 0.6.sp
                        )
                        Text(
                            text = "₹${cycle.totalEarnings.toInt()}",
                            fontSize = 26.sp,
                            fontWeight = FontWeight.Black,
                            color = accentColor
                        )
                        if (cycle.isCurrent) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = accentColor.copy(alpha = 0.18f),
                                border = BorderStroke(0.8.dp, accentColor.copy(alpha = 0.4f)),
                                modifier = Modifier.padding(top = 3.dp)
                            ) {
                                Text(
                                    text = "CURRENT CYCLE",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Black,
                                    color = accentColor,
                                    letterSpacing = 0.5.sp,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }

                // Mini Cycle Progress Bar
                Spacer(modifier = Modifier.height(10.dp))
                val progress = (cycle.entryCount / 10f).coerceIn(0f, 1f)
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp)),
                    color = accentColor,
                    trackColor = Color(0xFF1E293B)
                )
            }
        }
    }
}
