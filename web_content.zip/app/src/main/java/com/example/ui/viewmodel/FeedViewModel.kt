package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.ComicSeries
import com.example.data.model.CommentItem
import com.example.data.model.MediaItem
import com.example.data.model.MediaSource
import com.example.data.model.MediaType
import com.example.data.model.TagItem
import com.example.data.preferences.UserPreferences
import com.example.data.preferences.UserPreferencesRepository
import com.example.data.repository.MediaRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class MainNavigationTab {
    PROFILE,
    VIDEOS,
    PICTURES,
    COMICS,
    MISC
}

data class FeedUiState(
    val currentTab: MainNavigationTab = MainNavigationTab.VIDEOS,
    val items: List<MediaItem> = emptyList(),
    val comics: List<ComicSeries> = emptyList(),
    val selectedSourceFilter: MediaSource? = null,
    val searchQuery: String = "",
    val isLoading: Boolean = false,
    val activePostForComments: MediaItem? = null,
    val isCommentsSheetVisible: Boolean = false,
    val activeCommentsPage: Int = 0, // 0 = comments, 1 = tags list
    val currentPostComments: List<CommentItem> = emptyList(),
    val currentPostTags: List<TagItem> = emptyList(),
    val isSidebarOpen: Boolean = false,
    val isAddSourceDialogOpen: Boolean = false,
    val activeComicForReading: ComicSeries? = null,
    val isComicReaderOpen: Boolean = false,
    val statusMessage: String? = null
)

class FeedViewModel(
    private val mediaRepository: MediaRepository,
    private val preferencesRepository: UserPreferencesRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(FeedUiState())
    val uiState: StateFlow<FeedUiState> = _uiState.asStateFlow()

    val userPreferences: StateFlow<UserPreferences> = preferencesRepository.userPreferencesFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = UserPreferences()
        )

    init {
        loadContent()
    }

    fun selectTab(tab: MainNavigationTab) {
        _uiState.value = _uiState.value.copy(currentTab = tab, selectedSourceFilter = null)
        loadContent()
    }

    fun setSourceFilter(source: MediaSource?) {
        _uiState.value = _uiState.value.copy(selectedSourceFilter = source)
        loadContent()
    }

    fun updateSearchQuery(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
        loadContent()
    }

    fun setGenderFilter(filter: com.example.data.model.GenderFilter) {
        viewModelScope.launch {
            preferencesRepository.setGenderFilter(filter)
            loadContent()
        }
    }

    fun toggleMalesOnly(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setMalesOnly(enabled)
            loadContent()
        }
    }

    fun refreshContent() {
        loadContent()
    }

    fun loadContent() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            val currentState = _uiState.value
            when (currentState.currentTab) {
                MainNavigationTab.VIDEOS -> {
                    val feed = mediaRepository.getFeedItems(
                        type = MediaType.VIDEO,
                        filterSource = currentState.selectedSourceFilter,
                        searchQuery = currentState.searchQuery
                    )
                    _uiState.value = _uiState.value.copy(items = feed, isLoading = false)
                }
                MainNavigationTab.PICTURES -> {
                    val feed = mediaRepository.getFeedItems(
                        type = MediaType.PICTURE,
                        filterSource = currentState.selectedSourceFilter,
                        searchQuery = currentState.searchQuery
                    )
                    _uiState.value = _uiState.value.copy(items = feed, isLoading = false)
                }
                MainNavigationTab.COMICS -> {
                    val comics = mediaRepository.getComics(searchQuery = currentState.searchQuery)
                    _uiState.value = _uiState.value.copy(comics = comics, isLoading = false)
                }
                MainNavigationTab.MISC -> {
                    val feed = mediaRepository.getFeedItems(
                        type = MediaType.MISC,
                        filterSource = currentState.selectedSourceFilter,
                        searchQuery = currentState.searchQuery
                    )
                    _uiState.value = _uiState.value.copy(items = feed, isLoading = false)
                }
                MainNavigationTab.PROFILE -> {
                    _uiState.value = _uiState.value.copy(isLoading = false)
                }
            }
        }
    }

    fun onMediaItemVisible(item: MediaItem) {
        viewModelScope.launch {
            mediaRepository.recordView(item)
        }
    }

    fun toggleLike(item: MediaItem) {
        viewModelScope.launch {
            val newLiked = mediaRepository.toggleLike(item)
            val updatedList = _uiState.value.items.map {
                if (it.id == item.id) {
                    it.copy(
                        isLiked = newLiked,
                        likesCount = if (newLiked) it.likesCount + 1 else (it.likesCount - 1).coerceAtLeast(0)
                    )
                } else it
            }
            _uiState.value = _uiState.value.copy(items = updatedList)
        }
    }

    fun toggleFavorite(item: MediaItem) {
        viewModelScope.launch {
            val newFav = mediaRepository.toggleFavorite(item)
            val updatedList = _uiState.value.items.map {
                if (it.id == item.id) it.copy(isFavorited = newFav) else it
            }
            _uiState.value = _uiState.value.copy(items = updatedList)
        }
    }

    fun openCommentsSheet(item: MediaItem) {
        val comments = mediaRepository.getCommentsForPost(item.id, item.source)
        val categorizedTags = mediaRepository.categorizeTags(item.tags)
        _uiState.value = _uiState.value.copy(
            activePostForComments = item,
            isCommentsSheetVisible = true,
            activeCommentsPage = 0,
            currentPostComments = comments,
            currentPostTags = categorizedTags
        )
    }

    fun setCommentsSheetPage(page: Int) {
        _uiState.value = _uiState.value.copy(activeCommentsPage = page)
    }

    fun closeCommentsSheet() {
        _uiState.value = _uiState.value.copy(isCommentsSheetVisible = false, activePostForComments = null)
    }

    fun postComment(text: String) {
        val activeItem = _uiState.value.activePostForComments ?: return
        if (text.isBlank()) return
        viewModelScope.launch {
            mediaRepository.addComment(activeItem.id, activeItem.title, activeItem.source, text)
            val newComment = CommentItem(
                id = "c_user_${System.currentTimeMillis()}",
                postId = activeItem.id,
                author = userPreferences.value.userName,
                content = text,
                createdAt = System.currentTimeMillis(),
                likesCount = 0,
                platform = activeItem.source
            )
            _uiState.value = _uiState.value.copy(
                currentPostComments = listOf(newComment) + _uiState.value.currentPostComments
            )
        }
    }

    fun downloadItem(item: MediaItem) {
        viewModelScope.launch {
            val folder = userPreferences.value.downloadFolder
            val path = mediaRepository.saveToLocalHiddenFolder(item, folder)
            _uiState.value = _uiState.value.copy(
                statusMessage = "Downloaded to hidden folder: $path"
            )
        }
    }

    fun openComicReader(comic: ComicSeries) {
        _uiState.value = _uiState.value.copy(activeComicForReading = comic, isComicReaderOpen = true)
    }

    fun closeComicReader() {
        _uiState.value = _uiState.value.copy(activeComicForReading = null, isComicReaderOpen = false)
    }

    fun toggleSidebar(open: Boolean) {
        _uiState.value = _uiState.value.copy(isSidebarOpen = open)
    }

    fun toggleAddSourceDialog(open: Boolean) {
        _uiState.value = _uiState.value.copy(isAddSourceDialogOpen = open)
    }

    fun addCustomSource(sourceName: String) {
        viewModelScope.launch {
            preferencesRepository.toggleSource(sourceName)
            loadContent()
            _uiState.value = _uiState.value.copy(isAddSourceDialogOpen = false)
        }
    }

    fun clearStatusMessage() {
        _uiState.value = _uiState.value.copy(statusMessage = null)
    }
}
