package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.localization.AppLang
import com.example.localization.SjsStrings
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import java.util.Locale

@Composable
fun CompanyDetailScreen(
    provider: SecurityProvider,
    services: List<SecurityServiceListing>,
    userProfile: UserProfile?,
    lang: AppLang,
    initialService: SecurityServiceListing? = null,
    isBusy: Boolean,
    onBack: () -> Unit,
    onSubmitOrderRequest: (
        customerName: String,
        customerPhone: String,
        service: SecurityServiceListing?,
        category: ServiceCategory,
        serviceTitle: String,
        location: String,
        description: String,
        photos: List<String>
    ) -> Unit
) {
    BackHandler(onBack = onBack)

    var bookingTargetService by remember(initialService) { mutableStateOf(initialService) }
    var showBookingModal by remember(initialService) { mutableStateOf(initialService != null) }

    val companyServices = remember(services, provider.id) {
        services.filter { it.providerId == provider.id && it.active }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(OffWhite),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Box(modifier = Modifier.fillMaxWidth().height(210.dp)) {
                Base64Image(
                    base64 = provider.logoBase64,
                    contentDescription = provider.companyName,
                    modifier = Modifier.fillMaxSize(),
                    fallbackResId = R.drawable.img_security_ops
                )
                IconButton(
                    onClick = onBack,
                    colors = IconButtonDefaults.iconButtonColors(containerColor = NavyDeep.copy(alpha = 0.8f), contentColor = PureWhite),
                    modifier = Modifier
                        .padding(14.dp)
                        .align(Alignment.TopStart)
                        .testTag("company_back_button")
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Box(modifier = Modifier.padding(14.dp).align(Alignment.BottomStart)) {
                    VerifiedBadgeChip(lang = lang, verified = provider.verifiedBadge)
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(provider.companyName, style = MaterialTheme.typography.headlineSmall, color = NavyDeep)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Star, null, tint = OrangeBrand, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(
                                String.format(Locale.US, "%.1f (%d reviews)", provider.ratingAvg, provider.ratingCount),
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                        Text("• ${provider.completedOrdersCount} ${SjsStrings.t(lang, "oda zilizokamilika", "completed")}", style = MaterialTheme.typography.bodySmall, color = SlateGrey)
                    }
                    Text(provider.description, style = MaterialTheme.typography.bodyMedium, color = CharcoalGrey)
                    HorizontalDivider()
                    Text(
                        text = "${SjsStrings.t(lang, "Maeneo", "Coverage")}: ${provider.locations.joinToString(", ")}",
                        style = MaterialTheme.typography.bodySmall,
                        color = DarkGrey
                    )
                    Text(
                        text = "BRELA: ${provider.businessRegNumber} • PSRA License: ${provider.securityLicenseNumber}",
                        style = MaterialTheme.typography.labelSmall,
                        color = SlateGrey
                    )
                    if (!provider.isEligibleToReceiveOrders()) {
                        Surface(color = ErrorRedContainer, shape = RoundedCornerShape(10.dp)) {
                            Text(
                                text = SjsStrings.t(
                                    lang,
                                    "Kampuni hii inasubiri kuhuisha usajili wa mwezi kabla ya kupokea oda mpya.",
                                    "Provider subscription expired; renewal required before accepting new orders."
                                ),
                                style = MaterialTheme.typography.bodySmall,
                                color = ErrorRed,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    } else {
                        Button(
                            onClick = {
                                bookingTargetService = null
                                showBookingModal = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = OrangeBrand),
                            modifier = Modifier.fillMaxWidth().testTag("request_quote_general_button")
                        ) {
                            Icon(Icons.Filled.RequestQuote, null)
                            Spacer(Modifier.width(8.dp))
                            Text(SjsStrings.t(lang, "Omba Nukuu ya Bei (Request Quote)", "Request Quotation / Book"))
                        }
                    }
                }
            }
        }

        if (provider.galleryBase64.isNotEmpty()) {
            item {
                Text(
                    text = SjsStrings.t(lang, "Picha za Kampuni", "Company Gallery"),
                    style = MaterialTheme.typography.titleMedium,
                    color = NavyDeep,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
                Spacer(Modifier.height(8.dp))
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(provider.galleryBase64) { img ->
                        Base64Image(
                            base64 = img,
                            contentDescription = "Provider gallery photo",
                            modifier = Modifier
                                .size(150.dp, 110.dp)
                                .clip(RoundedCornerShape(14.dp))
                        )
                    }
                }
            }
        }

        item {
            Text(
                text = SjsStrings.t(lang, "Huduma & Bei (TZS)", "Services & Pricing (TZS)"),
                style = MaterialTheme.typography.titleLarge,
                color = NavyDeep,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }

        if (companyServices.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite)
                ) {
                    Text(
                        text = SjsStrings.t(
                            lang,
                            "Kampuni haijaorodhesha vifurushi maalum bado. Tumia kitufe cha 'Omba Nukuu' hapo juu.",
                            "No fixed packages listed yet. Use 'Request Quotation' above for custom pricing."
                        ),
                        style = MaterialTheme.typography.bodyMedium,
                        color = SlateGrey,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        } else {
            items(companyServices, key = { it.id }) { srv ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(srv.title, style = MaterialTheme.typography.titleMedium, color = NavyDeep, modifier = Modifier.weight(1f))
                            Text(TzsFormatter.format(srv.priceTzs), style = MaterialTheme.typography.labelLarge, color = OrangeBrand)
                        }
                        Text(srv.description, style = MaterialTheme.typography.bodySmall, color = CharcoalGrey)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("${SjsStrings.categoryLabel(srv.categoryEnum(), lang)} • ${srv.location}", style = MaterialTheme.typography.labelSmall, color = SlateGrey)
                            Button(
                                onClick = {
                                    bookingTargetService = srv
                                    showBookingModal = true
                                },
                                enabled = provider.isEligibleToReceiveOrders(),
                                colors = ButtonDefaults.buttonColors(containerColor = NavyDeep)
                            ) {
                                Text(SjsStrings.t(lang, "Weka Oda", "Book"))
                            }
                        }
                    }
                }
            }
        }
    }

    if (showBookingModal) {
        BookingRequestDialog(
            lang = lang,
            provider = provider,
            service = bookingTargetService,
            userProfile = userProfile,
            isBusy = isBusy,
            onSubmit = { name, phone, cat, title, loc, desc, photos ->
                onSubmitOrderRequest(name, phone, bookingTargetService, cat, title, loc, desc, photos)
                showBookingModal = false
            },
            onDismiss = { showBookingModal = false }
        )
    }
}

@Composable
private fun BookingRequestDialog(
    lang: AppLang,
    provider: SecurityProvider,
    service: SecurityServiceListing?,
    userProfile: UserProfile?,
    isBusy: Boolean,
    onSubmit: (String, String, ServiceCategory, String, String, String, List<String>) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var customerName by remember { mutableStateOf(userProfile?.fullName ?: "") }
    var customerPhone by remember { mutableStateOf(userProfile?.phone ?: "07") }
    var selectedCategory by remember {
        mutableStateOf(
            service?.categoryEnum()
                ?: provider.categories.firstOrNull()?.let { ServiceCategory.safeValueOf(it) }
                ?: ServiceCategory.SECURITY_GUARDS
        )
    }
    var serviceTitle by remember {
        mutableStateOf(service?.title ?: SjsStrings.categoryLabel(selectedCategory, lang))
    }
    var location by remember {
        mutableStateOf(service?.location ?: userProfile?.region ?: provider.locations.firstOrNull() ?: "Dar es Salaam")
    }
    var description by remember { mutableStateOf("") }
    var attachedPhotos by remember { mutableStateOf<List<String>>(emptyList()) }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 2)
    ) { uris ->
        val encoded = uris.mapNotNull { PhotoCodec.uriToCompressedBase64(context, it, maxDim = 360) }.take(2)
        attachedPhotos = encoded
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(SjsStrings.t(lang, "Omba Huduma / Nukuu", "Request Quotation / Book Service"))
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(provider.companyName, style = MaterialTheme.typography.labelLarge, color = OrangeBrand)
                OutlinedTextField(
                    value = customerName,
                    onValueChange = { customerName = it },
                    label = { Text(SjsStrings.t(lang, "Jina Lako", "Your Name")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = customerPhone,
                    onValueChange = { customerPhone = it },
                    label = { Text(SjsStrings.t(lang, "Namba ya Simu (mf. 078...)", "Phone Number")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = serviceTitle,
                    onValueChange = { serviceTitle = it },
                    label = { Text(SjsStrings.t(lang, "Huduma", "Service Title")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it },
                    label = { Text(SjsStrings.t(lang, "Eneo / Mkoa", "Location / District")) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text(SjsStrings.t(lang, "Maelezo ya mahitaji yako ya ulinzi", "Security requirements")) },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth().testTag("order_requirement_input")
                )
                OutlinedButton(
                    onClick = {
                        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    modifier = Modifier.fillMaxWidth().testTag("pick_requirement_photos_button")
                ) {
                    Icon(Icons.Filled.AddAPhoto, null)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        SjsStrings.t(
                            lang,
                            "Pakia Picha za Eneo (${attachedPhotos.size}/2)",
                            "Upload Requirement Photos (${attachedPhotos.size}/2)"
                        )
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSubmit(customerName, customerPhone, selectedCategory, serviceTitle, location, description, attachedPhotos)
                },
                enabled = !isBusy && description.trim().length >= 5 && customerPhone.trim().length >= 9,
                colors = ButtonDefaults.buttonColors(containerColor = OrangeBrand),
                modifier = Modifier.testTag("submit_order_request_button")
            ) {
                Text(SjsStrings.t(lang, "Tuma Ombi", "Submit Request"))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(SjsStrings.t(lang, "Ghairi", "Cancel"))
            }
        }
    )
}
