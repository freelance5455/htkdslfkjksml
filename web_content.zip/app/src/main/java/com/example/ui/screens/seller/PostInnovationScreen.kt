package com.example.ui.screens.seller

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.IgnisTechBlue

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PostInnovationScreen(
    onBack: () -> Unit,
    onPostCreated: (title: String, content: String, tags: List<String>) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var tagsString by remember { mutableStateOf("Hardware, Prototype, Testing") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Share Innovation Update",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Keep your followers, innovators, and consumers engaged with development progress, prototype updates, and technical milestones.",
                style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
            )

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Update Title") },
                placeholder = { Text("e.g. Prototype v2.1 Thermal Testing Results") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            OutlinedTextField(
                value = content,
                onValueChange = { content = it },
                label = { Text("Post Content / Engineering Notes") },
                placeholder = { Text("Describe the breakthrough, testing results, or upcoming release timeline...") },
                minLines = 5,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            OutlinedTextField(
                value = tagsString,
                onValueChange = { tagsString = it },
                label = { Text("Tags (comma separated)") },
                placeholder = { Text("Hardware, Prototype, Wireless") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = {
                    val tags = tagsString.split(",").map { it.trim() }.filter { it.isNotBlank() }
                    onPostCreated(
                        title.ifBlank { "New Innovation Breakthrough" },
                        content.ifBlank { "We're testing our latest components with improved efficiency and durability." },
                        tags.ifEmpty { listOf("Innovation", "Tech") }
                    )
                },
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = IgnisTechBlue),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("submit_post_button")
            ) {
                Text("Publish to Public Space", fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}
