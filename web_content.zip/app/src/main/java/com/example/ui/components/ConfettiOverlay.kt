package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import com.example.ui.ConfettiBurst
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private data class Particle(
    val angle: Float,
    val speed: Float,
    val color: Color,
    val size: Float,
    val rotationSpeed: Float,
    val gravity: Float
)

@Composable
fun ConfettiOverlay(
    burst: ConfettiBurst?,
    onFinished: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (burst == null) return

    val progress = remember(burst.id) { Animatable(0f) }
    val particles = remember(burst.id) {
        val palette = listOf(
            Color(0xFF10B981),
            Color(0xFF6366F1),
            Color(0xFFF59E0B),
            Color(0xFFEC4899),
            Color(0xFF06B6D4)
        )
        val rng = Random(burst.id)
        List(burst.particleCount) {
            Particle(
                angle = rng.nextFloat() * 360f,
                speed = 250f + rng.nextFloat() * 650f,
                color = palette[rng.nextInt(palette.size)],
                size = 8f + rng.nextFloat() * 10f,
                rotationSpeed = -360f + rng.nextFloat() * 720f,
                gravity = 600f + rng.nextFloat() * 450f
            )
        }
    }

    LaunchedEffect(burst.id) {
        progress.snapTo(0f)
        progress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 1250, easing = LinearEasing)
        )
        onFinished()
    }

    val t = progress.value
    Canvas(modifier = modifier.fillMaxSize()) {
        val originX = size.width * 0.5f
        val originY = size.height * 0.38f
        val alpha = (1f - t).coerceIn(0f, 1f)

        particles.forEach { p ->
            val rad = Math.toRadians(p.angle.toDouble())
            val dx = (cos(rad) * p.speed * t).toFloat()
            val dy = (sin(rad) * p.speed * t + 0.5f * p.gravity * t * t).toFloat()
            val x = originX + dx
            val y = originY + dy
            rotate(degrees = p.rotationSpeed * t, pivot = Offset(x, y)) {
                drawRect(
                    color = p.color.copy(alpha = alpha),
                    topLeft = Offset(x - p.size / 2f, y - p.size / 2f),
                    size = Size(p.size, p.size * 0.65f)
                )
            }
        }
    }
}
