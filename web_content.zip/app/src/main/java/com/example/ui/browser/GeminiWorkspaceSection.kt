package com.example.ui.browser

import android.annotation.SuppressLint
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.BookmarkAdd
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.AlabasterSurface
import com.example.ui.theme.DeepInk
import com.example.ui.theme.GeminiBlue
import com.example.ui.theme.GeminiBorder
import com.example.ui.theme.GeminiSoftBg
import com.example.ui.theme.HairlineBorder
import com.example.ui.theme.MutedSlate
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SlateSecondary
import org.json.JSONObject

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun GeminiWorkspaceSection(
    lastSearchedQuery: String,
    geminiState: GeminiUiState,
    onAskGemini: (String) -> Unit,
    onGenerateInteractiveHtml: (String) -> Unit,
    onSaveToVault: (title: String, url: String, category: String, note: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var customFollowUpQuery by remember(lastSearchedQuery) { mutableStateOf(lastSearchedQuery) }
    var showIndexHtmlPreview by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(PureWhite)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header Card explaining automatic query handoff
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            color = AlabasterSurface,
            border = BorderStroke(1.dp, GeminiBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .background(GeminiSoftBg),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.AutoAwesome,
                                contentDescription = "Gemini Sekmesi",
                                tint = GeminiBlue,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "✦ Gemini Otomatik Araştırma Sekmesi",
                                style = MaterialTheme.typography.titleMedium,
                                color = DeepInk
                            )
                            Text(
                                text = "Aradığınız sorgu otomatik olarak Gemini'ye iletilir",
                                style = MaterialTheme.typography.bodyMedium,
                                color = SlateSecondary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = customFollowUpQuery,
                    onValueChange = { customFollowUpQuery = it },
                    placeholder = {
                        Text(
                            text = "Gemini'ye doğrudan bir konu sorun...",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MutedSlate
                        )
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(
                        onSearch = {
                            if (customFollowUpQuery.isNotBlank()) {
                                onAskGemini(customFollowUpQuery)
                            }
                        }
                    ),
                    trailingIcon = {
                        IconButton(
                            onClick = {
                                if (customFollowUpQuery.isNotBlank()) {
                                    onAskGemini(customFollowUpQuery)
                                }
                            },
                            modifier = Modifier.testTag("gemini_query_send_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Outlined.Send,
                                contentDescription = "Gemini'ye Sor",
                                tint = GeminiBlue
                            )
                        }
                    },
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = PureWhite,
                        unfocusedContainerColor = PureWhite,
                        focusedBorderColor = GeminiBlue,
                        unfocusedBorderColor = HairlineBorder
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("gemini_query_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Quick topic chips if user hasn't searched yet
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(
                        "Kuantum bilgisayarlar nasıl çalışır?",
                        "Yapay zeka mimarileri 2026",
                        "Zero-Trust güvenlik modeli",
                        "Modern Kotlin Coroutines"
                    ).forEach { topic ->
                        FilterChip(
                            selected = customFollowUpQuery == topic,
                            onClick = {
                                customFollowUpQuery = topic
                                onAskGemini(topic)
                            },
                            label = {
                                Text(
                                    text = topic,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = PureWhite,
                                selectedContainerColor = GeminiSoftBg,
                                selectedLabelColor = GeminiBlue
                            )
                        )
                    }
                }
            }
        }

        // View mode switcher: Okuma Görünümü vs index.html Canlı Görünüm
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilterChip(
                selected = !showIndexHtmlPreview,
                onClick = { showIndexHtmlPreview = false },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Outlined.Description,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                },
                label = { Text("Minimalist Yanıt Kartı") },
                modifier = Modifier.testTag("gemini_text_mode_chip")
            )
            FilterChip(
                selected = showIndexHtmlPreview,
                onClick = { showIndexHtmlPreview = true },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Outlined.Code,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                },
                label = { Text("index.html Canlı Görünüm") },
                modifier = Modifier.testTag("gemini_html_mode_chip")
            )
        }

        when (geminiState) {
            is GeminiUiState.Idle -> {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, HairlineBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.AutoAwesome,
                            contentDescription = null,
                            tint = GeminiBlue,
                            modifier = Modifier.size(34.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Bir Konu Araştırın, Gemini Anında Yanıtlasın",
                            style = MaterialTheme.typography.titleMedium,
                            color = DeepInk
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Üst arama çubuğunda veya index.html sayfasında herhangi bir arama yaptığınızda ve bu sekmeye dokunduğunuzda sorgunuz otomatik olarak Gemini'ye iletilir.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = SlateSecondary
                        )
                    }
                }
            }

            is GeminiUiState.Loading -> {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = BorderStroke(1.dp, GeminiBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(24.dp),
                            color = GeminiBlue,
                            strokeWidth = 2.5.dp
                        )
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text(
                                text = "\"${geminiState.query}\" araştırılıyor...",
                                style = MaterialTheme.typography.titleMedium,
                                color = DeepInk
                            )
                            Text(
                                text = "Gemini hızlı yanıt hazırlıyor...",
                                style = MaterialTheme.typography.bodyMedium,
                                color = SlateSecondary
                            )
                        }
                    }
                }
            }

            is GeminiUiState.Streaming -> {
                GeminiAnswerContentCard(
                    query = geminiState.query,
                    answerText = geminiState.partialText,
                    generatedHtmlSnippet = "",
                    isStreaming = true,
                    showIndexHtmlPreview = showIndexHtmlPreview,
                    onSaveToVault = {
                        onSaveToVault(
                            geminiState.query,
                            "beyaz://index.html",
                            "Gemini Özeti",
                            geminiState.partialText
                        )
                    },
                    onGenerateInteractiveHtml = {
                        showIndexHtmlPreview = true
                        onGenerateInteractiveHtml(geminiState.query)
                    },
                    onRetry = { onAskGemini(geminiState.query) }
                )
            }

            is GeminiUiState.Success -> {
                GeminiAnswerContentCard(
                    query = geminiState.query,
                    answerText = geminiState.responseText,
                    generatedHtmlSnippet = geminiState.generatedHtmlSnippet,
                    isStreaming = false,
                    showIndexHtmlPreview = showIndexHtmlPreview,
                    onSaveToVault = {
                        onSaveToVault(
                            geminiState.query,
                            "beyaz://index.html",
                            "Gemini Özeti",
                            geminiState.responseText
                        )
                    },
                    onGenerateInteractiveHtml = {
                        showIndexHtmlPreview = true
                        onGenerateInteractiveHtml(geminiState.query)
                    },
                    onRetry = { onAskGemini(geminiState.query) }
                )
            }

            is GeminiUiState.Error -> {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    )
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "Gemini Yanıt Hatası (${geminiState.query})",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = geminiState.message,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = { onAskGemini(geminiState.query) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DeepInk,
                                contentColor = PureWhite
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Refresh,
                                contentDescription = "Tekrar Dene",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Tekrar Dene")
                        }
                    }
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun GeminiAnswerContentCard(
    query: String,
    answerText: String,
    generatedHtmlSnippet: String,
    isStreaming: Boolean,
    showIndexHtmlPreview: Boolean,
    onSaveToVault: () -> Unit,
    onGenerateInteractiveHtml: () -> Unit,
    onRetry: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        border = BorderStroke(1.dp, GeminiBorder)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = CircleShape,
                    color = GeminiSoftBg
                ) {
                    Text(
                        text = if (isStreaming) "✦ GEMINI YAZIYOR..." else "✦ GEMINI HIZLI YANIT",
                        style = MaterialTheme.typography.labelSmall,
                        color = GeminiBlue,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }

                IconButton(
                    onClick = onRetry,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Refresh,
                        contentDescription = "Yanıtı Yenile",
                        tint = SlateSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = query,
                style = MaterialTheme.typography.titleLarge,
                color = DeepInk
            )

            Spacer(modifier = Modifier.height(12.dp))

            if (showIndexHtmlPreview) {
                // Renders index.html inside WebView and injects the live Gemini answer or custom HTML
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 340.dp, max = 520.dp),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, HairlineBorder)
                ) {
                    AndroidView(
                        factory = { ctx ->
                            WebView(ctx).apply {
                                settings.javaScriptEnabled = true
                                settings.domStorageEnabled = true
                                webViewClient = object : WebViewClient() {
                                    override fun onPageFinished(view: WebView?, url: String?) {
                                        super.onPageFinished(view, url)
                                        val qEscaped = JSONObject.quote(query)
                                        val aEscaped = JSONObject.quote(answerText)
                                        val statusEscaped = JSONObject.quote(
                                            if (isStreaming) "Canlı Akış..." else "Gemini index.html Senkronize"
                                        )
                                        view?.evaluateJavascript(
                                            "if(window.updateIndexGeminiState){window.updateIndexGeminiState($qEscaped, $aEscaped, $statusEscaped);}",
                                            null
                                        )
                                    }
                                }
                                if (generatedHtmlSnippet.isNotBlank()) {
                                    val fullHtml = """
                                        <!DOCTYPE html>
                                        <html lang="tr">
                                        <head>
                                        <meta charset="UTF-8"/>
                                        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
                                        <style>
                                          body { font-family: -apple-system, sans-serif; background: #FFFFFF; color: #0F172A; padding: 16px; line-height: 1.6; }
                                        </style>
                                        </head>
                                        <body>$generatedHtmlSnippet</body>
                                        </html>
                                    """.trimIndent()
                                    loadDataWithBaseURL(
                                        "file:///android_asset/",
                                        fullHtml,
                                        "text/html",
                                        "UTF-8",
                                        null
                                    )
                                } else {
                                    loadUrl("file:///android_asset/index.html")
                                }
                            }
                        },
                        update = { webView ->
                            val qEscaped = JSONObject.quote(query)
                            val aEscaped = JSONObject.quote(answerText)
                            val statusEscaped = JSONObject.quote(
                                if (isStreaming) "Canlı Akış..." else "Gemini index.html Senkronize"
                            )
                            webView.evaluateJavascript(
                                "if(window.updateIndexGeminiState){window.updateIndexGeminiState($qEscaped, $aEscaped, $statusEscaped);}",
                                null
                            )
                        }
                    )
                }
            } else {
                Text(
                    text = answerText,
                    style = MaterialTheme.typography.bodyLarge,
                    color = DeepInk
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onSaveToVault,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("save_gemini_to_vault_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = DeepInk,
                        contentColor = PureWhite
                    )
                ) {
                    Icon(
                        imageVector = Icons.Outlined.BookmarkAdd,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Güvenli Kasaya Kaydet")
                }

                OutlinedButton(
                    onClick = onGenerateInteractiveHtml,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("generate_index_html_button"),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, GeminiBlue)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Code,
                        contentDescription = null,
                        tint = GeminiBlue,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Özel index.html Üret",
                        color = GeminiBlue
                    )
                }
            }
        }
    }
}
