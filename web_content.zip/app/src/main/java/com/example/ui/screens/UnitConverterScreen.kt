package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.SwapVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ConversionUnit
import com.example.data.model.UnitData
import com.example.data.model.UnitType
import com.example.ui.components.AppTopBar
import com.example.ui.components.BannerAdView
import com.example.ui.localization.AppStrings
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.SubtleMint
import com.example.ui.viewmodel.MainUiState

@Composable
fun UnitConverterScreen(
    uiState: MainUiState,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val language = uiState.language

    var selectedType by remember { mutableStateOf(UnitType.LENGTH) }

    val currentUnits = remember(selectedType) {
        when (selectedType) {
            UnitType.LENGTH -> UnitData.lengthUnits
            UnitType.WEIGHT -> UnitData.weightUnits
            UnitType.TEMPERATURE -> UnitData.tempUnits
            UnitType.SPEED -> UnitData.speedUnits
            UnitType.AREA -> UnitData.areaUnits
            UnitType.VOLUME -> UnitData.volumeUnits
        }
    }

    var fromUnit by remember(selectedType) { mutableStateOf(currentUnits.first()) }
    var toUnit by remember(selectedType) { mutableStateOf(currentUnits.getOrElse(1) { currentUnits.first() }) }
    var inputValueText by remember { mutableStateOf("1") }

    val inputValue = inputValueText.toDoubleOrNull() ?: 0.0
    val convertedResult = remember(inputValue, fromUnit, toUnit, selectedType) {
        UnitData.convert(inputValue, fromUnit, toUnit, selectedType)
    }

    val cardShape = RoundedCornerShape(18.dp)

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        AppTopBar(
            title = AppStrings.get("tool_unit", language),
            navigationIcon = Icons.AutoMirrored.Outlined.ArrowBack,
            onNavigationClick = onBack
        )

        // Unit Type Category Selector Chips
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(UnitType.values()) { type ->
                val isSelected = selectedType == type
                val chipShape = RoundedCornerShape(12.dp)
                Box(
                    modifier = Modifier
                        .testTag("unit_type_${type.name}")
                        .clip(chipShape)
                        .background(if (isSelected) ElectricBlue else MaterialTheme.colorScheme.surface)
                        .border(
                            0.8.dp,
                            if (isSelected) ElectricBlue else MaterialTheme.colorScheme.outline.copy(alpha = 0.35f),
                            chipShape
                        )
                        .clickable { selectedType = type }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = AppStrings.get(type.titleKey, language),
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        ),
                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Value Input Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(cardShape)
                    .background(MaterialTheme.colorScheme.surface)
                    .border(0.8.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f), cardShape)
                    .padding(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    // Input Text Field
                    OutlinedTextField(
                        value = inputValueText,
                        onValueChange = { inputValueText = it },
                        label = { Text("Value to Convert") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("unit_input_val"),
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricBlue,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                        )
                    )

                    // From Unit Selector Row
                    UnitSelector(
                        label = AppStrings.get("from", language),
                        selected = fromUnit,
                        options = currentUnits,
                        testTag = "unit_selector_from",
                        onSelect = { fromUnit = it }
                    )

                    // Swap Button
                    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        IconButton(
                            onClick = {
                                val temp = fromUnit
                                fromUnit = toUnit
                                toUnit = temp
                            },
                            modifier = Modifier
                                .testTag("unit_btn_swap")
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f))
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.SwapVert,
                                contentDescription = "Swap Units",
                                tint = ElectricBlue,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }

                    // To Unit Selector Row
                    UnitSelector(
                        label = AppStrings.get("to", language),
                        selected = toUnit,
                        options = currentUnits,
                        testTag = "unit_selector_to",
                        onSelect = { toUnit = it }
                    )
                }
            }

            // Converted Result Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(cardShape)
                    .background(MaterialTheme.colorScheme.surface)
                    .border(0.8.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f), cardShape)
                    .padding(20.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Converted Result",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        IconButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("Unit Result", "%.4f %s".format(convertedResult, toUnit.symbol))
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, AppStrings.get("copied", language), Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.ContentCopy,
                                contentDescription = "Copy",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = if (convertedResult == convertedResult.toLong().toDouble() && convertedResult < 1e9) {
                            "%,d %s".format(convertedResult.toLong(), toUnit.symbol)
                        } else {
                            "%,.4f %s".format(convertedResult, toUnit.symbol)
                        },
                        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                        color = SubtleMint
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "1 ${fromUnit.symbol} = %.4f ${toUnit.symbol}".format(
                            UnitData.convert(1.0, fromUnit, toUnit, selectedType)
                        ),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        BannerAdView()
    }
}

@Composable
private fun UnitSelector(
    label: String,
    selected: ConversionUnit,
    options: List<ConversionUnit>,
    testTag: String,
    onSelect: (ConversionUnit) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Column {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(4.dp))
        Box {
            Row(
                modifier = Modifier
                    .testTag(testTag)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    .border(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                    .clickable { expanded = true }
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${selected.name} (${selected.symbol})",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "▼",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false },
                modifier = Modifier.background(MaterialTheme.colorScheme.surface)
            ) {
                options.forEach { unit ->
                    DropdownMenuItem(
                        text = { Text("${unit.name} (${unit.symbol})") },
                        onClick = {
                            onSelect(unit)
                            expanded = false
                        }
                    )
                }
            }
        }
    }
}
