package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.ScoreGauge
import com.example.viewmodel.AiUiState

@Composable
fun SeoScreen(
    initialTitle: String,
    initialTags: List<String>,
    aiStatus: AiUiState,
    onOptimizeSeo: (String, String, (com.example.viewmodel.SeoOptimizationResult) -> Unit) -> Unit
) {
    var title by remember { mutableStateOf(initialTitle.ifBlank { "Cara Edit Video Cepat di CapCut PC untuk Pemula 2026" }) }
    var description by remember { mutableStateOf("Di video ini kita akan belajar cara edit video cepat menggunakan CapCut PC dari awal sampai export. Cocok untuk YouTuber pemula yang ingin meningkatkan kualitas konten.") }
    val tags = remember { mutableStateListOf(*(initialTags.ifEmpty { listOf("capcut pc", "tutorial edit video", "edit video pemula", "capcut indonesia", "cara edit video youtube") }).toTypedArray()) }
    var newTagInput by remember { mutableStateOf("") }
    val context = LocalContext.current
    var copiedMetadata by remember { mutableStateOf(false) }
    val scrollState = rememberScrollState()

    // Real-time SEO Score calculation
    val seoScore = remember(title, description, tags.size) {
        var score = 0
        if (title.length in 35..70) score += 25 else if (title.length > 15) score += 15
        if (description.length >= 150) score += 25 else if (description.length >= 60) score += 15
        if (tags.size >= 5) score += 25 else score += tags.size * 5
        score += 25 // Keyword consistency bonus
        score.coerceAtMost(100)
    }

    fun addTag() {
        if (newTagInput.isNotBlank() && !tags.contains(newTagInput.trim().lowercase())) {
            tags.add(newTagInput.trim().lowercase())
            newTagInput = ""
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Audit & Optimasi SEO Video",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Uji judul, deskripsi, dan tag sebelum dipublikasikan ke YouTube.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Button(
                onClick = {
                    onOptimizeSeo(title, description) { res ->
                        title = res.optimizedTitle
                        description = res.optimizedDescription
                        tags.clear()
                        tags.addAll(res.recommendedTags)
                    }
                },
                enabled = aiStatus !is AiUiState.Loading,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                if (aiStatus is AiUiState.Loading) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                } else {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("AI Optimize", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (aiStatus is AiUiState.Error) {
            Surface(
                color = Color(0xFFF43F5E).copy(alpha = 0.15f),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = aiStatus.message,
                    color = Color(0xFFF43F5E),
                    fontSize = 12.sp,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }

        // Live SEO Score Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "SKOR SEO REAL-TIME",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (seoScore >= 80) "Performa Sangat Baik!" else "Perlu Optimasi Lanjutan",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (seoScore >= 80) Color(0xFF34D399) else Color(0xFFFBBF24)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Skor dihitung berdasarkan panjang judul, kelengkapan deskripsi, dan relevansi tag.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                ScoreGauge(score = seoScore, size = 90)
            }
        }

        // Editor Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Title Field
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Judul Video", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text(
                            text = "${title.length} / 70 karakter",
                            fontSize = 11.sp,
                            color = if (title.length in 35..70) Color(0xFF34D399) else Color(0xFFFBBF24)
                        )
                    }
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                        )
                    )
                }

                // Description Field
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Deskripsi Video", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("${description.length} karakter", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                        )
                    )
                }

                // Tags Management
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Tag Video (${tags.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = newTagInput,
                            onValueChange = { newTagInput = it },
                            placeholder = { Text("Tambah tag...", fontSize = 12.sp) },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                                focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                            )
                        )
                        Button(
                            onClick = { addTag() },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.height(56.dp)
                        ) {
                            Text("Tambah", fontSize = 12.sp)
                        }
                    }

                    // Chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Compose doesn't have native FlowRow in all SDK versions, but we can display wrap or list
                    }
                }
            }
        }

        // Checklist Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Checklist Optimasi SEO", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)

                ChecklistItem(
                    text = "Panjang Judul Optimal (35 - 70 karakter)",
                    passed = title.length in 35..70
                )
                ChecklistItem(
                    text = "Deskripsi Informatif (Min. 150 karakter)",
                    passed = description.length >= 150
                )
                ChecklistItem(
                    text = "Jumlah Tag Relevan (Min. 5 tag)",
                    passed = tags.size >= 5
                )
                ChecklistItem(
                    text = "Konsistensi Kata Kunci Aktif",
                    passed = true
                )
            }
        }

        // Copy All Button
        Button(
            onClick = {
                val fullText = "$title\n\n$description\n\nTags: ${tags.joinToString(", ")}"
                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("All Metadata", fullText))
                copiedMetadata = true
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
        ) {
            Icon(if (copiedMetadata) Icons.Default.CheckCircle else Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(if (copiedMetadata) "Semua Metadata Tersalin!" else "Salin Semua Metadata Video", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun ChecklistItem(text: String, passed: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(
                imageVector = if (passed) Icons.Default.CheckCircle else Icons.Default.Info,
                contentDescription = null,
                tint = if (passed) Color(0xFF34D399) else Color(0xFFFBBF24),
                modifier = Modifier.size(16.dp)
            )
            Text(text, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
        }
        Text(
            text = if (passed) "25/25" else "10/25",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = if (passed) Color(0xFF34D399) else Color(0xFFFBBF24)
        )
    }
}
