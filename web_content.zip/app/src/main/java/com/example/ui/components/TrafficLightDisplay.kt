package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.FrontHand
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.LightColor
import com.example.model.OperatingMode
import com.example.model.PedestrianState
import com.example.model.SignalPhase
import com.example.ui.theme.PedestrianWaitRed
import com.example.ui.theme.PedestrianWalkGreen
import com.example.ui.theme.TrafficGreen
import com.example.ui.theme.TrafficGreenDark
import com.example.ui.theme.TrafficGreenGlow
import com.example.ui.theme.TrafficHousing
import com.example.ui.theme.TrafficHousingBorder
import com.example.ui.theme.TrafficHousingCap
import com.example.ui.theme.TrafficRed
import com.example.ui.theme.TrafficRedDark
import com.example.ui.theme.TrafficRedGlow
import com.example.ui.theme.TrafficYellow
import com.example.ui.theme.TrafficYellowDark
import com.example.ui.theme.TrafficYellowGlow

@Composable
fun TrafficLightDisplay(
    currentPhase: SignalPhase,
    secondsRemaining: Int,
    operatingMode: OperatingMode,
    isNightFlashOn: Boolean,
    pedestrianState: PedestrianState,
    isPedestrianRequested: Boolean,
    pedestrianSecondsRemaining: Int,
    onLampClick: (SignalPhase) -> Unit,
    onPedestrianButtonClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Determine which lamps are lit
    val isRedLit = when (currentPhase) {
        SignalPhase.RED, SignalPhase.RED_YELLOW -> true
        SignalPhase.FLASHING_RED -> isNightFlashOn
        else -> false
    }

    val isYellowLit = when (currentPhase) {
        SignalPhase.YELLOW, SignalPhase.RED_YELLOW -> true
        SignalPhase.FLASHING_YELLOW -> isNightFlashOn
        else -> false
    }

    val isGreenLit = when (currentPhase) {
        SignalPhase.GREEN -> true
        else -> false
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Main Traffic Signal Head
        TrafficSignalHead(
            isRedLit = isRedLit,
            isYellowLit = isYellowLit,
            isGreenLit = isGreenLit,
            currentPhase = currentPhase,
            secondsRemaining = secondsRemaining,
            operatingMode = operatingMode,
            onLampClick = onLampClick
        )

        Spacer(modifier = Modifier.width(20.dp))

        // Pedestrian Signal & Crossing Button Unit
        PedestrianSignalUnit(
            pedestrianState = pedestrianState,
            pedestrianSecondsRemaining = pedestrianSecondsRemaining,
            isPedestrianRequested = isPedestrianRequested,
            onPedestrianButtonClick = onPedestrianButtonClick
        )
    }
}

@Composable
fun TrafficSignalHead(
    isRedLit: Boolean,
    isYellowLit: Boolean,
    isGreenLit: Boolean,
    currentPhase: SignalPhase,
    secondsRemaining: Int,
    operatingMode: OperatingMode,
    onLampClick: (SignalPhase) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
    ) {
        // Top Mounting Bracket / Cap
        Box(
            modifier = Modifier
                .width(48.dp)
                .height(10.dp)
                .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                .background(TrafficHousingCap)
                .border(1.dp, TrafficHousingBorder, RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
        )

        // Main Signal Housing
        Box(
            modifier = Modifier
                .shadow(16.dp, RoundedCornerShape(28.dp), ambientColor = Color.Black)
                .clip(RoundedCornerShape(28.dp))
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            TrafficHousingCap,
                            TrafficHousing,
                            Color(0xFF0F1318)
                        )
                    )
                )
                .border(3.dp, TrafficHousingBorder, RoundedCornerShape(28.dp))
                .padding(horizontal = 14.dp, vertical = 18.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // RED LAMP
                TrafficLampItem(
                    color = LightColor.RED,
                    isLit = isRedLit,
                    countdownNumber = if (isRedLit && operatingMode == OperatingMode.AUTOMATIC) secondsRemaining else null,
                    labelAr = "أحمر",
                    onClick = { onLampClick(SignalPhase.RED) },
                    testTag = "lamp_red"
                )

                // YELLOW LAMP
                TrafficLampItem(
                    color = LightColor.YELLOW,
                    isLit = isYellowLit,
                    countdownNumber = if (isYellowLit && operatingMode == OperatingMode.AUTOMATIC) secondsRemaining else null,
                    labelAr = "أصفر",
                    onClick = { onLampClick(SignalPhase.YELLOW) },
                    testTag = "lamp_yellow"
                )

                // GREEN LAMP
                TrafficLampItem(
                    color = LightColor.GREEN,
                    isLit = isGreenLit,
                    countdownNumber = if (isGreenLit && operatingMode == OperatingMode.AUTOMATIC) secondsRemaining else null,
                    labelAr = "أخضر",
                    onClick = { onLampClick(SignalPhase.GREEN) },
                    testTag = "lamp_green"
                )
            }
        }

        // Bottom Mounting Pole segment
        Box(
            modifier = Modifier
                .width(32.dp)
                .height(28.dp)
                .clip(RoundedCornerShape(bottomStart = 4.dp, bottomEnd = 4.dp))
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            Color(0xFF1E2530),
                            Color(0xFF384357),
                            Color(0xFF161C24)
                        )
                    )
                )
                .border(1.dp, TrafficHousingBorder)
        )
    }
}

@Composable
fun TrafficLampItem(
    color: LightColor,
    isLit: Boolean,
    countdownNumber: Int?,
    labelAr: String,
    onClick: () -> Unit,
    testTag: String
) {
    val interactionSource = remember { MutableInteractionSource() }

    // Pulsing halo animation when lit
    val infiniteTransition = rememberInfiniteTransition(label = "halo_pulse")
    val haloAlpha by infiniteTransition.animateFloat(
        initialValue = 0.45f,
        targetValue = 0.75f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "halo_alpha"
    )

    val (onColor, glowColor, darkColor) = when (color) {
        LightColor.RED -> Triple(TrafficRed, TrafficRedGlow, TrafficRedDark)
        LightColor.YELLOW -> Triple(TrafficYellow, TrafficYellowGlow, TrafficYellowDark)
        LightColor.GREEN -> Triple(TrafficGreen, TrafficGreenGlow, TrafficGreenDark)
        LightColor.OFF -> Triple(Color.Gray, Color.DarkGray, Color.Black)
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Sun Visor / Hood (Curved metallic hood overhang)
        Canvas(
            modifier = Modifier
                .width(82.dp)
                .height(12.dp)
        ) {
            drawSunHood(size.width, size.height)
        }

        // Lamp Lens with Glow and Fresnel Texture
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(76.dp)
                .testTag(testTag)
                .clickable(
                    interactionSource = interactionSource,
                    indication = null,
                    onClick = onClick
                )
        ) {
            // Radiant Outer Glow/Halo when lit
            if (isLit) {
                Box(
                    modifier = Modifier
                        .size(92.dp)
                        .drawBehind {
                            drawCircle(
                                brush = Brush.radialGradient(
                                    colors = listOf(
                                        glowColor.copy(alpha = haloAlpha * 0.8f),
                                        glowColor.copy(alpha = haloAlpha * 0.35f),
                                        Color.Transparent
                                    ),
                                    center = center,
                                    radius = size.width / 1.8f
                                )
                            )
                        }
                )
            }

            // Lamp Outer Beveled Rim
            Box(
                modifier = Modifier
                    .size(76.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                Color(0xFF28313F),
                                Color(0xFF141921)
                            )
                        )
                    )
                    .border(2.5.dp, Color(0xFF3B475A), CircleShape)
            )

            // Inner Glass Lens with Fresnel Rings & Texture
            Canvas(
                modifier = Modifier
                    .size(68.dp)
                    .clip(CircleShape)
            ) {
                // Glass Base Color
                if (isLit) {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color.White.copy(alpha = 0.95f),
                                onColor,
                                glowColor,
                                darkColor
                            ),
                            center = Offset(size.width * 0.45f, size.height * 0.4f),
                            radius = size.width * 0.6f
                        )
                    )
                } else {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                darkColor.copy(alpha = 0.9f),
                                Color(0xFF0C1017)
                            ),
                            center = Offset(size.width * 0.45f, size.height * 0.4f),
                            radius = size.width * 0.65f
                        )
                    )
                }

                // Fresnel concentric circles etched onto the lens
                val ringCount = 5
                for (i in 1..ringCount) {
                    val radius = (size.width / 2f) * (i.toFloat() / (ringCount + 1))
                    drawCircle(
                        color = if (isLit) Color.White.copy(alpha = 0.22f) else Color.White.copy(alpha = 0.05f),
                        radius = radius,
                        style = Stroke(width = 1.2f)
                    )
                }

                // LED matrix dot texture
                val dotRows = 5
                val dotCols = 5
                for (r in 0 until dotRows) {
                    for (c in 0 until dotCols) {
                        val dx = size.width * (0.22f + c * 0.14f)
                        val dy = size.height * (0.22f + r * 0.14f)
                        val distFromCenter = kotlin.math.hypot(dx - size.width / 2, dy - size.height / 2)
                        if (distFromCenter < size.width * 0.38f) {
                            drawCircle(
                                color = if (isLit) Color.White.copy(alpha = 0.4f) else Color.White.copy(alpha = 0.06f),
                                radius = 1.6f,
                                center = Offset(dx, dy)
                            )
                        }
                    }
                }

                // Glass diagonal surface shine reflection
                drawArc(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color.White.copy(alpha = if (isLit) 0.35f else 0.12f),
                            Color.Transparent
                        )
                    ),
                    startAngle = 200f,
                    sweepAngle = 100f,
                    useCenter = true,
                    size = Size(size.width * 0.9f, size.height * 0.9f),
                    topLeft = Offset(size.width * 0.05f, size.height * 0.05f)
                )
            }

            // Digital Countdown Timer Display inside the lit lamp
            if (isLit && countdownNumber != null && countdownNumber > 0) {
                Text(
                    text = "$countdownNumber",
                    color = Color.White,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.shadow(8.dp, CircleShape, spotColor = Color.Black)
                )
            }
        }
    }
}

private fun DrawScope.drawSunHood(width: Float, height: Float) {
    val path = Path().apply {
        moveTo(0f, height)
        cubicTo(
            width * 0.15f, 0f,
            width * 0.85f, 0f,
            width, height
        )
        lineTo(width * 0.92f, height)
        cubicTo(
            width * 0.82f, height * 0.25f,
            width * 0.18f, height * 0.25f,
            width * 0.08f, height
        )
        close()
    }
    drawPath(
        path = path,
        brush = Brush.verticalGradient(
            colors = listOf(
                Color(0xFF384457),
                Color(0xFF1E2530),
                Color(0xFF13171E)
            )
        )
    )
}

@Composable
fun PedestrianSignalUnit(
    pedestrianState: PedestrianState,
    pedestrianSecondsRemaining: Int,
    isPedestrianRequested: Boolean,
    onPedestrianButtonClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isWalk = pedestrianState == PedestrianState.WALK
    val isFlashingDontWalk = pedestrianState == PedestrianState.FLASHING_DONT_WALK
    val isDontWalk = pedestrianState == PedestrianState.DONT_WALK || isFlashingDontWalk

    val infiniteTransition = rememberInfiniteTransition(label = "ped_flash")
    val flashAlpha by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 0.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "flash_alpha"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = modifier
    ) {
        // Pedestrian Signal Head
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = TrafficHousing,
            border = androidx.compose.foundation.BorderStroke(2.dp, TrafficHousingBorder),
            shadowElevation = 10.dp,
            modifier = Modifier.width(96.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.padding(10.dp)
            ) {
                // Header tag
                Text(
                    text = "المشاة",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.Gray,
                    fontWeight = FontWeight.Bold
                )

                // Top: Don't Walk (Hand/Standing Red Figure)
                val handAlpha = if (isFlashingDontWalk) flashAlpha else if (isDontWalk) 1f else 0.15f
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(62.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            if (isDontWalk) Color(0xFF2A0D11) else Color(0xFF10141A)
                        )
                        .border(
                            1.dp,
                            if (isDontWalk) PedestrianWaitRed.copy(alpha = 0.6f) else Color(0xFF252C3A),
                            RoundedCornerShape(14.dp)
                        )
                ) {
                    Icon(
                        imageVector = Icons.Default.FrontHand,
                        contentDescription = "قف - لا تعبر",
                        tint = PedestrianWaitRed.copy(alpha = handAlpha),
                        modifier = Modifier.size(36.dp)
                    )
                }

                // Bottom: Walk (Walking Man Green Figure)
                val walkAlpha = if (isWalk) 1f else 0.15f
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(62.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            if (isWalk) Color(0xFF072615) else Color(0xFF10141A)
                        )
                        .border(
                            1.dp,
                            if (isWalk) PedestrianWalkGreen.copy(alpha = 0.6f) else Color(0xFF252C3A),
                            RoundedCornerShape(14.dp)
                        )
                ) {
                    Icon(
                        imageVector = Icons.Default.DirectionsWalk,
                        contentDescription = "اعبر بأمان",
                        tint = PedestrianWalkGreen.copy(alpha = walkAlpha),
                        modifier = Modifier.size(38.dp)
                    )
                }

                // Countdown Timer for Pedestrian Walk
                if (isWalk || isFlashingDontWalk) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF0B0F15))
                            .padding(vertical = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${pedestrianSecondsRemaining}s",
                            color = if (isFlashingDontWalk) TrafficYellow else PedestrianWalkGreen,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 16.sp
                        )
                    }
                }
            }
        }

        // "PUSH TO WALK" Street Call Button Box (صندوق زر طلب العبور)
        PedestrianCallButtonBox(
            isRequested = isPedestrianRequested,
            onClick = onPedestrianButtonClick
        )
    }
}

@Composable
fun PedestrianCallButtonBox(
    isRequested: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val waitTextColor by animateColorAsState(
        targetValue = if (isRequested) TrafficYellow else Color(0xFF424242),
        label = "wait_text_color"
    )

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = Color(0xFF181F2A),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF333E52)),
        shadowElevation = 6.dp,
        modifier = modifier
            .width(96.dp)
            .clickable(onClick = onClick)
            .testTag("pedestrian_push_button")
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // "WAIT" Indicator Lamp
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(
                        if (isRequested) Color(0xFF332605) else Color(0xFF0F141C)
                    )
                    .border(
                        1.dp,
                        if (isRequested) TrafficYellow.copy(alpha = 0.8f) else Color(0xFF222938),
                        RoundedCornerShape(6.dp)
                    )
                    .padding(vertical = 3.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isRequested) "انتظر" else "طلب عبور",
                    color = waitTextColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }

            // Big Round Metallic Push Button
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                Color(0xFF4E5D73),
                                Color(0xFF28313E),
                                Color(0xFF181F28)
                            )
                        )
                    )
                    .border(2.dp, Color(0xFF63748E), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.TouchApp,
                    contentDescription = "اضغط لطلب عبور المشاة",
                    tint = if (isRequested) TrafficYellow else Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }

            Text(
                text = "اضغط هنا",
                style = MaterialTheme.typography.labelSmall,
                color = Color.LightGray,
                fontSize = 11.sp
            )
        }
    }
}
