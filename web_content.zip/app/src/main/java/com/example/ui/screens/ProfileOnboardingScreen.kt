package com.example.ui.screens

import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.model.JobyConstants
import com.example.model.UserProfile

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ProfileSetupOrEditScreen(
  existingProfile: UserProfile?,
  userId: String,
  defaultEmail: String,
  defaultName: String,
  isBusy: Boolean,
  isFirstTimeSetup: Boolean,
  onSave: (UserProfile) -> Unit,
  onCancel: (() -> Unit)? = null
) {
  val context = LocalContext.current

  var role by remember(existingProfile) { mutableStateOf(existingProfile?.role ?: "SEEKER") }
  var displayName by remember(existingProfile) {
    mutableStateOf(existingProfile?.displayName?.ifBlank { defaultName } ?: defaultName.ifBlank { "Aarav Kumar" })
  }
  var ageText by remember(existingProfile) { mutableStateOf((existingProfile?.age ?: 22L).toString()) }
  var phone by remember(existingProfile) { mutableStateOf(existingProfile?.phone ?: "") }
  var selectedState by remember(existingProfile) {
    mutableStateOf(existingProfile?.state?.ifBlank { "Karnataka" } ?: "Karnataka")
  }
  var city by remember(existingProfile) { mutableStateOf(existingProfile?.city ?: "Bengaluru") }
  var pincode by remember(existingProfile) { mutableStateOf(existingProfile?.pincode ?: "560001") }
  var skillsText by remember(existingProfile) {
    mutableStateOf(existingProfile?.skills?.joinToString(", ") ?: "Kotlin, Customer Support, Excel")
  }
  var education by remember(existingProfile) { mutableStateOf(existingProfile?.education ?: "") }
  var bio by remember(existingProfile) { mutableStateOf(existingProfile?.bio ?: "") }
  var resumeLabel by remember(existingProfile) { mutableStateOf(existingProfile?.resumeLabel ?: "") }
  var companyName by remember(existingProfile) { mutableStateOf(existingProfile?.companyName ?: "") }
  var gstNumber by remember(existingProfile) { mutableStateOf(existingProfile?.gstOrRegNumber ?: "") }
  var preferredLanguage by remember(existingProfile) { mutableStateOf(existingProfile?.preferredLanguage ?: "EN") }
  var stateDropdownExpanded by remember { mutableStateOf(false) }
  var validationError by remember { mutableStateOf<String?>(null) }

  // Zero-permission Storage Access Framework document picker for Resume PDF/Doc name
  val resumePicker = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.OpenDocument()
  ) { uri: Uri? ->
    if (uri != null) {
      val cursor = context.contentResolver.query(uri, null, null, null, null)
      val name = cursor?.use {
        val idx = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (it.moveToFirst() && idx >= 0) it.getString(idx) else null
      } ?: "selected_resume.pdf"
      resumeLabel = name
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .then(if (isFirstTimeSetup) Modifier.statusBarsPadding().navigationBarsPadding() else Modifier)
      .verticalScroll(rememberScrollState())
      .padding(20.dp)
  ) {
    Text(
      text = if (isFirstTimeSetup) "Complete Your JOBY Profile" else "Edit Profile",
      style = MaterialTheme.typography.headlineSmall,
      color = MaterialTheme.colorScheme.onBackground
    )
    Spacer(modifier = Modifier.height(6.dp))
    Text(
      text = "Verified identity & age compliance keeps India's marketplace safe and 100% fee-free.",
      style = MaterialTheme.typography.bodyMedium,
      color = MaterialTheme.colorScheme.onSurfaceVariant
    )

    Spacer(modifier = Modifier.height(16.dp))

    Text("Select Account Role", style = MaterialTheme.typography.titleSmall)
    Spacer(modifier = Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
      FilterChip(
        selected = role == "SEEKER",
        onClick = { role = "SEEKER" },
        label = { Text("Job Seeker") },
        leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null) },
        modifier = Modifier.weight(1f).testTag("role_seeker_chip")
      )
      FilterChip(
        selected = role == "EMPLOYER",
        onClick = { role = "EMPLOYER" },
        label = { Text("Employer / Hirer") },
        leadingIcon = { Icon(Icons.Filled.Business, contentDescription = null) },
        modifier = Modifier.weight(1f).testTag("role_employer_chip")
      )
    }

    Spacer(modifier = Modifier.height(14.dp))

    OutlinedTextField(
      value = displayName,
      onValueChange = { displayName = it },
      label = { Text("Full Name *") },
      singleLine = true,
      modifier = Modifier.fillMaxWidth().testTag("profile_name_input")
    )
    Spacer(modifier = Modifier.height(10.dp))

    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
      OutlinedTextField(
        value = ageText,
        onValueChange = { ageText = it.filter { ch -> ch.isDigit() }.take(3) },
        label = { Text("Age (14+) *") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        singleLine = true,
        modifier = Modifier.weight(0.9f).testTag("profile_age_input")
      )
      OutlinedTextField(
        value = phone,
        onValueChange = { phone = it.take(15) },
        label = { Text("Mobile (+91)") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
        singleLine = true,
        modifier = Modifier.weight(1.3f).testTag("profile_phone_input")
      )
    }

    val parsedAge = ageText.toLongOrNull() ?: 0L
    if (parsedAge in 1L..17L) {
      Spacer(modifier = Modifier.height(8.dp))
      Surface(
        color = MaterialTheme.colorScheme.secondaryContainer,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Filled.Shield, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Under-18 protection active: Hazardous and 18+ restricted jobs will be blocked per Indian labour laws.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSecondaryContainer
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    ExposedDropdownMenuBox(
      expanded = stateDropdownExpanded,
      onExpandedChange = { stateDropdownExpanded = !stateDropdownExpanded }
    ) {
      OutlinedTextField(
        value = selectedState,
        onValueChange = {},
        readOnly = true,
        label = { Text("State / Union Territory *") },
        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = stateDropdownExpanded) },
        modifier = Modifier
          .fillMaxWidth()
          .menuAnchor()
      )
      ExposedDropdownMenu(
        expanded = stateDropdownExpanded,
        onDismissRequest = { stateDropdownExpanded = false }
      ) {
        JobyConstants.INDIAN_STATES.filter { it != "All India" }.forEach { st ->
          DropdownMenuItem(
            text = { Text(st) },
            onClick = {
              selectedState = st
              stateDropdownExpanded = false
            }
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
      OutlinedTextField(
        value = city,
        onValueChange = { city = it },
        label = { Text("City / District *") },
        singleLine = true,
        modifier = Modifier.weight(1.2f).testTag("profile_city_input")
      )
      OutlinedTextField(
        value = pincode,
        onValueChange = { pincode = it.filter { ch -> ch.isDigit() }.take(6) },
        label = { Text("PIN Code *") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        singleLine = true,
        modifier = Modifier.weight(1f).testTag("profile_pincode_input")
      )
    }

    Spacer(modifier = Modifier.height(12.dp))

    if (role == "EMPLOYER") {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Text("Company Details", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
          Spacer(modifier = Modifier.height(8.dp))
          OutlinedTextField(
            value = companyName,
            onValueChange = { companyName = it },
            label = { Text("Company / Business Name *") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("profile_company_input")
          )
          Spacer(modifier = Modifier.height(8.dp))
          OutlinedTextField(
            value = gstNumber,
            onValueChange = { gstNumber = it },
            label = { Text("GSTIN / MSME Udyam Reg (Optional)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
        }
      }
    } else {
      OutlinedTextField(
        value = skillsText,
        onValueChange = { skillsText = it },
        label = { Text("Skills (comma separated)") },
        modifier = Modifier.fillMaxWidth()
      )
      Spacer(modifier = Modifier.height(10.dp))
      OutlinedTextField(
        value = education,
        onValueChange = { education = it },
        label = { Text("Education / Qualification") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
      )
      Spacer(modifier = Modifier.height(10.dp))
      OutlinedButton(
        onClick = { resumePicker.launch(arrayOf("application/pdf", "application/msword", "*/*")) },
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth().testTag("pick_resume_button")
      ) {
        Icon(Icons.Filled.AttachFile, contentDescription = null)
        Spacer(modifier = Modifier.width(8.dp))
        Text(if (resumeLabel.isBlank()) "Attach Resume / CV File" else "Resume: $resumeLabel")
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    OutlinedTextField(
      value = bio,
      onValueChange = { bio = it.take(500) },
      label = { Text(if (role == "EMPLOYER") "About Company" else "Short Bio / Experience") },
      minLines = 2,
      maxLines = 4,
      modifier = Modifier.fillMaxWidth()
    )

    Spacer(modifier = Modifier.height(12.dp))
    Text("Preferred App Language", style = MaterialTheme.typography.titleSmall)
    Spacer(modifier = Modifier.height(6.dp))
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      listOf("EN" to "English", "HI" to "हिन्दी", "TA" to "தமிழ்").forEach { (code, label) ->
        FilterChip(
          selected = preferredLanguage == code,
          onClick = { preferredLanguage = code },
          label = { Text(label) }
        )
      }
    }

    if (validationError != null) {
      Spacer(modifier = Modifier.height(10.dp))
      Text(
        text = validationError!!,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.error
      )
    }

    Spacer(modifier = Modifier.height(18.dp))

    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
      if (onCancel != null) {
        OutlinedButton(
          onClick = onCancel,
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.weight(1f).height(50.dp)
        ) {
          Text("Cancel")
        }
      }
      Button(
        onClick = {
          val ageVal = ageText.toLongOrNull()
          when {
            displayName.trim().length < 2 -> validationError = "Enter your full name (at least 2 characters)."
            ageVal == null || ageVal < 14L || ageVal > 100L ->
              validationError = "Age must be between 14 and 100 per Indian employment rules."
            city.trim().length < 2 -> validationError = "Enter your city or district."
            pincode.trim().length < 4 -> validationError = "Enter a valid PIN code."
            role == "EMPLOYER" && companyName.trim().length < 2 ->
              validationError = "Enter your company or business name."
            else -> {
              validationError = null
              val parsedSkills = skillsText.split(",")
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .take(15)
              onSave(
                (existingProfile ?: UserProfile(userId = userId, email = defaultEmail)).copy(
                  userId = userId,
                  displayName = displayName.trim(),
                  email = defaultEmail,
                  phone = phone.trim(),
                  state = selectedState,
                  city = city.trim(),
                  pincode = pincode.trim(),
                  role = role,
                  age = ageVal,
                  isAgeVerified = true,
                  skills = parsedSkills,
                  education = education.trim(),
                  bio = bio.trim(),
                  resumeLabel = resumeLabel.trim(),
                  companyName = companyName.trim(),
                  gstOrRegNumber = gstNumber.trim(),
                  preferredLanguage = preferredLanguage
                )
              )
            }
          }
        },
        enabled = !isBusy,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
          .weight(1f)
          .height(50.dp)
          .testTag("save_profile_button")
      ) {
        Text(if (isBusy) "Saving..." else "Save & Continue")
      }
    }

    Spacer(modifier = Modifier.height(24.dp))
  }
}
