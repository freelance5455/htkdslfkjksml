package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Checkroom
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Straighten
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import com.example.data.model.FashionProduct
import com.example.data.model.RecentlyViewedProduct
import com.example.data.model.SavedOutfit
import com.example.data.model.TryOnSession
import com.example.data.model.UserProfile
import com.example.ui.components.RealTimeCameraTryOnOverlayCard
import com.example.ui.viewmodel.DataUiState
import com.example.ui.viewmodel.TryOnUiState
import com.example.util.PrivatePhotoStorage

@Composable
fun VirtualTryOnScreen(
    userProfileState: DataUiState<UserProfile?>,
    userPhotoBitmap: Bitmap?,
    photoConsentAccepted: Boolean,
    selectedProduct: FashionProduct,
    selectedColor: String,
    selectedSize: String,
    catalogProducts: List<FashionProduct>,
    tryOnUiState: TryOnUiState,
    onPhotoConsentChanged: (Boolean) -> Unit,
    onPhotoCaptured: (Bitmap) -> Unit,
    onPhotoSelectedFromUri: (Uri) -> Unit,
    onUploadStudioPreset: (String) -> Unit = {},
    onDeletePhoto: () -> Unit,
    onSelectProduct: (FashionProduct) -> Unit,
    onSelectColor: (String) -> Unit,
    onSelectSize: (String) -> Unit,
    onGenerateTryOn: () -> Unit,
    onSaveOutfitToWardrobe: (FashionProduct) -> Unit,
    onComparePrices: (FashionProduct) -> Unit
) {
    val context = LocalContext.current
    val userProfile = (userProfileState as? DataUiState.Success)?.data
    var showSideBySideComparison by remember { mutableStateOf(true) }
    var isLiveArOverlayExpanded by remember { mutableStateOf(false) }

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            onPhotoSelectedFromUri(uri)
        }
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onPhotoSelectedFromUri(uri)
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->
        if (bitmap != null) {
            onPhotoCaptured(bitmap)
        } else {
            // Fallback on cloud emulator when hardware camera preview returns null
            onUploadStudioPreset("MALE")
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            try {
                cameraLauncher.launch(null)
            } catch (e: Exception) {
                onUploadStudioPreset("MALE")
            }
        } else {
            onUploadStudioPreset("MALE")
        }
    }

    val launchGalleryPickerSafely: () -> Unit = {
        try {
            photoPickerLauncher.launch(
                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
            )
        } catch (e: Exception) {
            try {
                filePickerLauncher.launch("image/*")
            } catch (ex: Exception) {
                onUploadStudioPreset("MALE")
            }
        }
    }

    val launchCameraSafely: () -> Unit = {
        val hasCamPerm = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED
        if (hasCamPerm) {
            try {
                cameraLauncher.launch(null)
            } catch (e: Exception) {
                onUploadStudioPreset("MALE")
            }
        } else {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("virtual_tryon_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Column {
                Text(
                    text = "AI Virtual Try-On Studio",
                    style = MaterialTheme.typography.headlineLarge
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Upload your personal photo or use the real-time measurement-mapped AR camera overlay.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.secondary
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilterChip(
                        selected = isLiveArOverlayExpanded,
                        onClick = { isLiveArOverlayExpanded = !isLiveArOverlayExpanded },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        label = {
                            Text(
                                if (isLiveArOverlayExpanded) {
                                    "Hide Live AR Camera"
                                } else {
                                    "Open Live AR Camera Overlay"
                                }
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                            selectedLeadingIconColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        modifier = Modifier.testTag("toggle_live_ar_camera_button")
                    )

                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        shape = RoundedCornerShape(50)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Straighten,
                                contentDescription = null,
                                modifier = Modifier.size(15.dp),
                                tint = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${userProfile?.heightCm ?: 172} cm • ${userProfile?.weightKg ?: 68} kg • ${userProfile?.preferredTopSize ?: "M"}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        // Step 1: Personal Photo Upload System (Placed FIRST for immediate visibility & reliability)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(
                    width = if (userPhotoBitmap != null) 1.5.dp else 1.dp,
                    color = if (userPhotoBitmap != null) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.outline
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "1. Upload Your Personal Photo",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.tertiary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Private On-Device",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.tertiary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Upload from Gallery/Files, take a Camera snapshot, or tap an Instant Studio Portrait below to test AI Virtual Try-On immediately.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    if (userPhotoBitmap != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(260.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                bitmap = userPhotoBitmap.asImageBitmap(),
                                contentDescription = "Uploaded personal photo preview",
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.fillMaxSize()
                            )
                            Surface(
                                color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.92f),
                                shape = RoundedCornerShape(50),
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onSecondaryContainer,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "Photo Ready",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSecondaryContainer
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Retake, Replace, Browse Files, Delete Photo Controls
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = launchCameraSafely,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("retake_photo_button")
                            ) {
                                Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Camera")
                            }

                            OutlinedButton(
                                onClick = launchGalleryPickerSafely,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("replace_photo_button")
                            ) {
                                Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Gallery")
                            }

                            OutlinedButton(
                                onClick = onDeletePhoto,
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = MaterialTheme.colorScheme.error
                                ),
                                modifier = Modifier.testTag("delete_photo_button")
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete Photo", modifier = Modifier.size(16.dp))
                            }
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = launchGalleryPickerSafely,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(50.dp)
                                    .testTag("gallery_upload_button")
                            ) {
                                Icon(Icons.Default.PhotoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Upload Photo")
                            }

                            OutlinedButton(
                                onClick = launchCameraSafely,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(50.dp)
                                    .testTag("camera_capture_button")
                            ) {
                                Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Camera")
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Instant 1-Tap Studio Portrait Uploaders (Works 100% on Emulators & Devices without local gallery images)
                    Text(
                        text = "Instant 1-Tap Studio Photo Upload (Or Browse Device Files):",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = false,
                            onClick = { onUploadStudioPreset("MALE") },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            label = { Text("Upload Male Studio Photo") },
                            modifier = Modifier.testTag("upload_preset_male_photo")
                        )
                        FilterChip(
                            selected = false,
                            onClick = { onUploadStudioPreset("FEMALE") },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            label = { Text("Upload Female Studio Photo") },
                            modifier = Modifier.testTag("upload_preset_female_photo")
                        )
                        FilterChip(
                            selected = false,
                            onClick = { onUploadStudioPreset("STREETWEAR") },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            label = { Text("Upload Streetwear Portrait") },
                            modifier = Modifier.testTag("upload_preset_street_photo")
                        )
                        FilterChip(
                            selected = false,
                            onClick = {
                                try {
                                    filePickerLauncher.launch("image/*")
                                } catch (e: Exception) {
                                    onUploadStudioPreset("MALE")
                                }
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.PhotoLibrary,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            label = { Text("Browse Device Files") },
                            modifier = Modifier.testTag("browse_device_files_photo")
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Save Try-On Previews to Private Wardrobe",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Switch(
                            checked = photoConsentAccepted,
                            onCheckedChange = onPhotoConsentChanged
                        )
                    }
                }
            }
        }

        // Optional Real-Time AR Camera Overlay Mapped with User Body Measurements
        if (isLiveArOverlayExpanded) {
            item {
                RealTimeCameraTryOnOverlayCard(
                    userProfile = userProfile,
                    selectedProduct = selectedProduct,
                    selectedColor = selectedColor,
                    selectedSize = selectedSize,
                    catalogProducts = catalogProducts,
                    onSelectProduct = onSelectProduct,
                    onSelectColor = onSelectColor,
                    onSelectSize = onSelectSize,
                    onCaptureFrameForTryOn = { capturedBitmap ->
                        onPhotoCaptured(capturedBitmap)
                        if (!photoConsentAccepted) {
                            onPhotoConsentChanged(true)
                        }
                        onGenerateTryOn()
                    }
                )
            }
        }

        // Step 2: Select Outfit & Customize Colour/Size for Virtual Try-On
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "2. Selected Outfit for Virtual Try-On",
                        style = MaterialTheme.typography.titleLarge
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AsyncImage(
                            model = selectedProduct.imageUrl,
                            contentDescription = selectedProduct.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(90.dp)
                                .clip(RoundedCornerShape(14.dp))
                        )
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = selectedProduct.brand.uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.secondary
                            )
                            Text(
                                text = selectedProduct.name,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = "₹${selectedProduct.priceInr} • ${selectedProduct.category}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text("Colour Variant: $selectedColor", style = MaterialTheme.typography.labelLarge)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        selectedProduct.availableColors.forEach { col ->
                            FilterChip(
                                selected = selectedColor == col,
                                onClick = { onSelectColor(col) },
                                label = { Text(col) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text("Garment Size: $selectedSize", style = MaterialTheme.typography.labelLarge)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        selectedProduct.availableSizes.forEach { sz ->
                            FilterChip(
                                selected = selectedSize == sz,
                                onClick = { onSelectSize(sz) },
                                label = { Text(sz) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Switch to Another Catalogue Outfit:",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(catalogProducts, key = { "tryon_pick_${it.id}" }) { item ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(
                                    width = if (item.id == selectedProduct.id) 2.dp else 1.dp,
                                    color = if (item.id == selectedProduct.id) MaterialTheme.colorScheme.secondary
                                    else MaterialTheme.colorScheme.outline
                                ),
                                modifier = Modifier
                                    .width(130.dp)
                                    .clickable { onSelectProduct(item) }
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    AsyncImage(
                                        model = item.imageUrl,
                                        contentDescription = item.name,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(76.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = item.name,
                                        style = MaterialTheme.typography.labelSmall,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = onGenerateTryOn,
                        enabled = tryOnUiState !is TryOnUiState.Generating,
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.secondary,
                            contentColor = MaterialTheme.colorScheme.onSecondary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("generate_virtual_tryon_button")
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (tryOnUiState is TryOnUiState.Generating) {
                                "Synthesizing Realistic Try-On (30-60s)..."
                            } else {
                                "Generate Realistic AI Virtual Try-On"
                            },
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Step 3: AI Try-On Result & Before-and-After Comparison
        item {
            when (tryOnUiState) {
                is TryOnUiState.Idle -> {
                    // Ready state
                }

                is TryOnUiState.Generating -> {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            CircularProgressIndicator(
                                color = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(44.dp)
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "Generating Realistic AI Virtual Try-On...",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Gemini Nano Banana 2.1 is preserving your facial features and pose while tailoring ${selectedProduct.name} ($selectedColor). This typically takes 30–60 seconds.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                is TryOnUiState.Error -> {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.14f)
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "Virtual Try-On Notice",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.error
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = tryOnUiState.message,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                is TryOnUiState.Success -> {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Before & After Comparison",
                                    style = MaterialTheme.typography.titleLarge
                                )
                                TextButton(
                                    onClick = { showSideBySideComparison = !showSideBySideComparison }
                                ) {
                                    Icon(Icons.Default.Compare, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(if (showSideBySideComparison) "Full AI View" else "Side-by-Side")
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            if (showSideBySideComparison) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.weight(1f),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text("ORIGINAL PHOTO", style = MaterialTheme.typography.labelSmall)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Image(
                                            bitmap = tryOnUiState.originalBitmap.asImageBitmap(),
                                            contentDescription = "Original Personal Photo",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(230.dp)
                                                .clip(RoundedCornerShape(14.dp))
                                        )
                                    }

                                    Column(
                                        modifier = Modifier.weight(1f),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            text = "AI TRY-ON PREVIEW",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.secondary
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Image(
                                            bitmap = tryOnUiState.generatedBitmap.asImageBitmap(),
                                            contentDescription = "Generated AI Virtual Try-On Preview",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(230.dp)
                                                .clip(RoundedCornerShape(14.dp))
                                        )
                                    }
                                }
                            } else {
                                Image(
                                    bitmap = tryOnUiState.generatedBitmap.asImageBitmap(),
                                    contentDescription = "Full AI Virtual Try-On Preview",
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(340.dp)
                                        .clip(RoundedCornerShape(16.dp))
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = tryOnUiState.aiFitNotes,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = { onComparePrices(tryOnUiState.product) },
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Compare Prices & Buy")
                                }
                                OutlinedButton(
                                    onClick = { onSaveOutfitToWardrobe(tryOnUiState.product) },
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Save Outfit")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WardrobeAndProfileScreen(
    isProfileTab: Boolean,
    userProfileState: DataUiState<UserProfile?>,
    savedOutfitsState: DataUiState<List<SavedOutfit>>,
    tryOnSessionsState: DataUiState<List<TryOnSession>>,
    recentlyViewedState: DataUiState<List<RecentlyViewedProduct>>,
    onRemoveSavedOutfit: (String) -> Unit,
    onDeleteTryOnSession: (String) -> Unit,
    onToggleMembershipTier: (String) -> Unit,
    onSaveBodyMeasurements: (heightCm: Int, weightKg: Int, topSize: String, bottomSize: String, fitPreference: String) -> Unit = { _, _, _, _, _ -> },
    onSignOut: () -> Unit,
    onDeleteAccountAndData: () -> Unit
) {
    val context = LocalContext.current
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }

    val profile = (userProfileState as? DataUiState.Success)?.data

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag(if (isProfileTab) "profile_screen" else "wardrobe_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        if (!isProfileTab) {
            item {
                Text(
                    text = "My Wardrobe & Saved Try-Ons",
                    style = MaterialTheme.typography.headlineLarge
                )
                Text(
                    text = "Your favourite outfits, saved virtual try-on previews, and recently viewed items.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Saved Outfits Section
            item {
                Text(
                    text = "Favourite Outfits",
                    style = MaterialTheme.typography.headlineMedium
                )
            }

            when (savedOutfitsState) {
                is DataUiState.Loading -> {
                    item { CircularProgressIndicator() }
                }
                is DataUiState.Error -> {
                    item {
                        Text(savedOutfitsState.message, color = MaterialTheme.colorScheme.error)
                    }
                }
                is DataUiState.Success -> {
                    if (savedOutfitsState.data.isEmpty()) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Text(
                                    text = "No favourite outfits saved yet. Browse Discover or ask the AI Stylist to save looks to your wardrobe.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.padding(16.dp)
                                )
                            }
                        }
                    } else {
                        items(savedOutfitsState.data, key = { "saved_${it.id}" }) { outfit ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    AsyncImage(
                                        model = outfit.imageUrl,
                                        contentDescription = outfit.title,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .size(80.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "${outfit.brand} • ${outfit.occasion}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.secondary
                                        )
                                        Text(
                                            text = outfit.title,
                                            style = MaterialTheme.typography.titleMedium
                                        )
                                        Text(
                                            text = "₹${outfit.priceInr} on ${outfit.retailer} • Colour: ${outfit.color}",
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                        Text(
                                            text = "Shoes: ${outfit.matchingShoes}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            TextButton(
                                                onClick = {
                                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(outfit.productUrl))
                                                    context.startActivity(intent)
                                                }
                                            ) {
                                                Text("Buy Now")
                                            }
                                            TextButton(
                                                onClick = { onRemoveSavedOutfit(outfit.id) }
                                            ) {
                                                Text("Remove", color = MaterialTheme.colorScheme.error)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Saved Virtual Try-On Sessions
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Saved Virtual Try-On Previews",
                    style = MaterialTheme.typography.headlineMedium
                )
            }

            when (tryOnSessionsState) {
                is DataUiState.Loading -> item { CircularProgressIndicator() }
                is DataUiState.Error -> item {
                    Text(tryOnSessionsState.message, color = MaterialTheme.colorScheme.error)
                }
                is DataUiState.Success -> {
                    if (tryOnSessionsState.data.isEmpty()) {
                        item {
                            Text(
                                text = "No saved virtual try-on previews yet.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        items(tryOnSessionsState.data, key = { "tryon_${it.id}" }) { session ->
                            SavedTryOnSessionCard(
                                session = session,
                                onDelete = { onDeleteTryOnSession(session.id) }
                            )
                        }
                    }
                }
            }

            // Recently Viewed Products
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Recently Viewed Products",
                        style = MaterialTheme.typography.headlineMedium
                    )
                }
            }

            when (recentlyViewedState) {
                is DataUiState.Loading -> item { CircularProgressIndicator() }
                is DataUiState.Error -> item {
                    Text(recentlyViewedState.message, color = MaterialTheme.colorScheme.error)
                }
                is DataUiState.Success -> {
                    if (recentlyViewedState.data.isEmpty()) {
                        item {
                            Text(
                                text = "Products you inspect in the catalogue will appear here.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        item {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                items(recentlyViewedState.data, key = { "recent_${it.id}" }) { rec ->
                                    Card(
                                        modifier = Modifier.width(170.dp),
                                        shape = RoundedCornerShape(14.dp),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp)) {
                                            AsyncImage(
                                                model = rec.imageUrl,
                                                contentDescription = rec.productName,
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(100.dp)
                                                    .clip(RoundedCornerShape(10.dp))
                                            )
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(
                                                text = rec.productName,
                                                style = MaterialTheme.typography.titleSmall,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = "₹${rec.priceInr} • ${rec.retailer}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.secondary
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // PROFILE & MEMBERSHIP TAB
            item {
                Text(
                    text = "Profile & Membership",
                    style = MaterialTheme.typography.headlineLarge
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Manage your StyleAI account, styling preferences, membership tier, and personal data privacy.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Membership Tier Card (Free vs Premium)
            item {
                val currentTier = profile?.membershipTier ?: "FREE"
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Star,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.secondary
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (currentTier == "PREMIUM") "StyleAI Noir Atelier Premium" else "StyleAI Free Membership",
                                    style = MaterialTheme.typography.titleLarge
                                )
                            }
                            Surface(
                                color = MaterialTheme.colorScheme.secondaryContainer,
                                shape = RoundedCornerShape(50)
                            ) {
                                Text(
                                    text = currentTier,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "Usage Counter: ${profile?.tryOnCountUsed ?: 0L} Virtual Try-Ons used • ${profile?.recommendationsUsed ?: 0L} AI Stylist sessions used",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.secondary
                        )

                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                        Text(
                            text = "Free Membership: Up to 5 AI recommendation sessions, 3 Virtual Try-Ons, full clothing catalogue & multi-platform price comparison.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Premium Membership: Unlimited Virtual Try-Ons, advanced styling recommendations, unlimited outfit saving, and personalized seasonal wardrobe planning.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = { onToggleMembershipTier(currentTier) },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.secondary,
                                contentColor = MaterialTheme.colorScheme.onSecondary
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("toggle_membership_tier_button")
                        ) {
                            Text(
                                text = if (currentTier == "PREMIUM") "Switch to Free Plan" else "Upgrade to Premium Membership"
                            )
                        }
                    }
                }
            }

            // BODY MEASUREMENTS & VIRTUAL TRY-ON FIT CALIBRATION FORM
            item {
                BodyMeasurementsCalibrationCard(
                    profile = profile,
                    onSaveBodyMeasurements = onSaveBodyMeasurements
                )
            }

            // Saved Styling & Shopping Preferences
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Saved Styling & Shopping Preferences",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "• Calibrated Measurements: ${profile?.heightCm ?: 172L} cm • ${profile?.weightKg ?: 68L} kg • Top ${profile?.preferredTopSize ?: "M"} / Waist ${profile?.preferredBottomSize ?: "32"} (${profile?.bodyFitPreference ?: "Tailored Fit"})",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Text(
                            text = "• Preferred Style: ${profile?.preferredStyle ?: "Luxury Minimalist"}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "• Primary Occasion: ${profile?.preferredOccasion ?: "Casual"}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "• Colour Palette: ${profile?.preferredColors ?: "Black, White, Charcoal"}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "• Max Budget: ₹${profile?.budgetMaxInr ?: 5000L}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Text(
                            text = "• Preferred Retailers: ${profile?.preferredRetailers ?: "Myntra, AJIO, Amazon, Flipkart"}",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }

            // Account Actions & Data Deletion
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Account Security & Personal Data Privacy",
                            style = MaterialTheme.typography.titleMedium
                        )

                        OutlinedButton(
                            onClick = onSignOut,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("sign_out_button")
                        ) {
                            Icon(Icons.Default.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Sign Out")
                        }

                        Button(
                            onClick = { showDeleteConfirmDialog = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.error,
                                contentColor = MaterialTheme.colorScheme.onError
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("delete_account_data_button")
                        ) {
                            Icon(Icons.Default.DeleteForever, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Delete Account & Uploaded Personal Data")
                        }
                    }
                }
            }
        }
    }

    if (showDeleteConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = { Text("Delete Account & Personal Data?") },
            text = {
                Text("This permanently deletes your uploaded personal photos, AI virtual try-on previews, saved wardrobe outfits, and Firestore profile.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirmDialog = false
                        onDeleteAccountAndData()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Permanently Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun SavedTryOnSessionCard(
    session: TryOnSession,
    onDelete: () -> Unit
) {
    val context = LocalContext.current
    var previewBitmap by remember { mutableStateOf<Bitmap?>(null) }

    LaunchedEffect(session.localPreviewFilename) {
        previewBitmap = PrivatePhotoStorage.loadTryOnPreviewBitmap(context, session.localPreviewFilename)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (previewBitmap != null) {
                Image(
                    bitmap = previewBitmap!!.asImageBitmap(),
                    contentDescription = session.outfitTitle,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(84.dp)
                        .clip(RoundedCornerShape(12.dp))
                )
            } else {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.size(84.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Checkroom, contentDescription = null)
                    }
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = session.outfitTitle,
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = "${session.outfitCategory} • Colour: ${session.selectedColor} • Size: ${session.selectedSize}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = session.aiFitNotes,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(onClick = onDelete) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete Try-On Session",
                    tint = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}

@Composable
private fun BodyMeasurementsCalibrationCard(
    profile: UserProfile?,
    onSaveBodyMeasurements: (heightCm: Int, weightKg: Int, topSize: String, bottomSize: String, fitPreference: String) -> Unit
) {
    var heightText by remember(profile?.heightCm) {
        mutableStateOf((profile?.heightCm ?: 172L).toString())
    }
    var weightText by remember(profile?.weightKg) {
        mutableStateOf((profile?.weightKg ?: 68L).toString())
    }
    var selectedTopSize by remember(profile?.preferredTopSize) {
        mutableStateOf(profile?.preferredTopSize?.ifBlank { "M" } ?: "M")
    }
    var selectedBottomSize by remember(profile?.preferredBottomSize) {
        mutableStateOf(profile?.preferredBottomSize?.ifBlank { "32" } ?: "32")
    }
    var selectedFitPreference by remember(profile?.bodyFitPreference) {
        mutableStateOf(profile?.bodyFitPreference?.ifBlank { "Tailored Fit" } ?: "Tailored Fit")
    }

    val parsedHeight = heightText.toIntOrNull()?.coerceIn(100, 250) ?: 172
    val parsedWeight = weightText.toIntOrNull()?.coerceIn(30, 250) ?: 68

    // Smart AI Size Estimator based on height (cm) and weight (kg)
    val (suggestedTop, suggestedBottom) = remember(parsedHeight, parsedWeight) {
        when {
            parsedWeight < 54 -> "XS" to "28"
            parsedWeight < 63 -> "S" to "30"
            parsedWeight < 74 && parsedHeight < 180 -> "M" to "32"
            parsedWeight < 84 -> "L" to "34"
            parsedWeight < 96 -> "XL" to "36"
            else -> "XXL" to "38"
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("body_measurements_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.2.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.7f))
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Straighten,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "Body Measurements & Size Calibration",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Calibrates garment drape, sleeve length, and sizing accuracy for AI Virtual Try-On & Stylist suggestions.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Height (cm) & Weight (kg) Input Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = heightText,
                    onValueChange = { input ->
                        if (input.length <= 3 && input.all { it.isDigit() }) {
                            heightText = input
                        }
                    },
                    label = { Text("Height (cm)") },
                    placeholder = { Text("172") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("measurement_height_input")
                )

                OutlinedTextField(
                    value = weightText,
                    onValueChange = { input ->
                        if (input.length <= 3 && input.all { it.isDigit() }) {
                            weightText = input
                        }
                    },
                    label = { Text("Weight (kg)") },
                    placeholder = { Text("68") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("measurement_weight_input")
                )
            }

            // AI Recommended Size Estimator Banner
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.4f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "AI Recommended Size for ${parsedHeight} cm / ${parsedWeight} kg:",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Top: $suggestedTop • Waist/Bottom: $suggestedBottom",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.secondary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    TextButton(
                        onClick = {
                            selectedTopSize = suggestedTop
                            selectedBottomSize = suggestedBottom
                        },
                        modifier = Modifier.testTag("apply_suggested_size_button")
                    ) {
                        Text("Apply Suggested")
                    }
                }
            }

            // Preferred Top / Shirt / Kurta Size Selector
            Text(
                text = "Preferred Top / Kurta / Jacket Size:",
                style = MaterialTheme.typography.labelLarge
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("XS", "S", "M", "L", "XL", "XXL").forEach { sizeOption ->
                    FilterChip(
                        selected = selectedTopSize == sizeOption,
                        onClick = { selectedTopSize = sizeOption },
                        label = { Text(sizeOption) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.24f),
                            selectedLabelColor = MaterialTheme.colorScheme.secondary
                        ),
                        modifier = Modifier.testTag("measurement_top_size_$sizeOption")
                    )
                }
            }

            // Preferred Waist / Bottom Size Selector
            Text(
                text = "Preferred Waist / Bottom Size:",
                style = MaterialTheme.typography.labelLarge
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("28", "30", "32", "34", "36", "38", "40").forEach { waistOption ->
                    FilterChip(
                        selected = selectedBottomSize == waistOption,
                        onClick = { selectedBottomSize = waistOption },
                        label = { Text(waistOption) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.24f),
                            selectedLabelColor = MaterialTheme.colorScheme.secondary
                        ),
                        modifier = Modifier.testTag("measurement_bottom_size_$waistOption")
                    )
                }
            }

            // Fit & Silhouette Preference
            Text(
                text = "Silhouette & Drape Fit Preference:",
                style = MaterialTheme.typography.labelLarge
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("Slim Fit", "Tailored Fit", "Regular Fit", "Relaxed / Oversized").forEach { fitOption ->
                    FilterChip(
                        selected = selectedFitPreference == fitOption,
                        onClick = { selectedFitPreference = fitOption },
                        label = { Text(fitOption) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.24f),
                            selectedLabelColor = MaterialTheme.colorScheme.secondary
                        ),
                        modifier = Modifier.testTag("measurement_fit_${fitOption.take(6).lowercase()}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Button(
                onClick = {
                    onSaveBodyMeasurements(
                        parsedHeight,
                        parsedWeight,
                        selectedTopSize,
                        selectedBottomSize,
                        selectedFitPreference
                    )
                },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("save_body_measurements_button")
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Save Measurements & Calibrate Try-On",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

