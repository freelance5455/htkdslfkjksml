package com.example.ui

import android.graphics.Bitmap
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PanTool
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.BookEntity
import com.example.data.PdfAnnotationStroke
import com.example.pdf.PdfDocumentController
import com.example.pdf.PdfSearchMatch
import com.example.ui.theme.MerriweatherFontFamily
import com.example.ui.theme.ReaderActiveGreenDot
import com.example.ui.theme.ReaderCanvasBg
import com.example.ui.theme.ReaderPageDividerGray
import com.example.ui.theme.ReaderPageInputBorder
import com.example.ui.theme.ReaderPageInputPurple
import com.example.ui.theme.ReaderTopBarIndigo
import com.example.ui.theme.ReaderTopBarIndigoDark
import kotlinx.coroutines.flow.distinctUntilChanged
import java.util.UUID
import kotlin.math.roundToInt

@Composable
fun MoonChessTopBar(
    activeSection: AppSection,
    activeBook: BookEntity?,
    currentPage: Int,
    isDockedBoardOpen: Boolean,
    onBackClick: () -> Unit,
    onSelectSection: (AppSection) -> Unit,
    onCycleSplitBoard: () -> Unit,
    onJumpToPage: (Int) -> Unit,
    onToggleSearch: () -> Unit,
    onZoomOut: () -> Unit,
    onZoomIn: () -> Unit,
    onOpenExportZipDialog: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var sectionMenuExpanded by remember { mutableStateOf(false) }
    var pageInputText by remember(currentPage) { mutableStateOf(currentPage.toString()) }
    val focusManager = LocalFocusManager.current

    Surface(
        color = ReaderTopBarIndigo,
        shadowElevation = 6.dp,
        modifier = modifier
            .fillMaxWidth()
            .testTag("moonchess_top_bar")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .height(54.dp)
                .padding(horizontal = 6.dp)
        ) {
            // Left: "< Back" matching screenshot + Upper Heading Dropdown Switcher
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f, fill = false)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .height(48.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onBackClick() }
                        .padding(horizontal = 4.dp)
                        .testTag("top_bar_back_button")
                ) {
                    // Triangle left arrow matching screenshot
                    Canvas(modifier = Modifier.size(14.dp)) {
                        val p = Path().apply {
                            moveTo(size.width * 0.85f, size.height * 0.1f)
                            lineTo(size.width * 0.15f, size.height * 0.5f)
                            lineTo(size.width * 0.85f, size.height * 0.9f)
                            close()
                        }
                        drawPath(p, color = Color(0xFFD4D4D8))
                    }
                    Spacer(Modifier.width(5.dp))
                    Text(
                        text = stringResource(R.string.back_label),
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(Modifier.width(4.dp))

                // Upper Heading Switcher (opens list: Reader, Library, My Notes, Principles, Import Games)
                Box {
                    Surface(
                        color = ReaderTopBarIndigoDark,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, ReaderPageInputBorder.copy(alpha = 0.7f)),
                        modifier = Modifier
                            .height(34.dp)
                            .clickable { sectionMenuExpanded = true }
                            .testTag("upper_heading_section_menu_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(start = 8.dp, end = 4.dp)
                        ) {
                            val shortHeading = when (activeSection) {
                                AppSection.READER -> "Reader"
                                AppSection.LIBRARY -> "Library"
                                AppSection.NOTES -> "Notes"
                                AppSection.PRINCIPLES -> "Principles"
                                AppSection.GAMES -> "Games"
                            }
                            Text(
                                text = shortHeading,
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = "Switch app section",
                                tint = Color(0xFFC7D2FE),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = sectionMenuExpanded,
                        onDismissRequest = { sectionMenuExpanded = false }
                    ) {
                        val entries = listOf(
                            AppSection.READER to stringResource(R.string.section_reader),
                            AppSection.LIBRARY to stringResource(R.string.section_library),
                            AppSection.NOTES to stringResource(R.string.section_notes),
                            AppSection.PRINCIPLES to stringResource(R.string.section_principles),
                            AppSection.GAMES to stringResource(R.string.section_games)
                        )
                        for ((sec, label) in entries) {
                            val enabled = sec != AppSection.READER || activeBook != null
                            DropdownMenuItem(
                                enabled = enabled,
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = label,
                                            fontWeight = if (sec == activeSection) FontWeight.Bold else FontWeight.Normal
                                        )
                                        if (sec == activeSection) {
                                            Spacer(Modifier.width(8.dp))
                                            Icon(
                                                Icons.Default.Check,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                },
                                onClick = {
                                    sectionMenuExpanded = false
                                    onSelectSection(sec)
                                },
                                modifier = Modifier.testTag("section_menu_item_${sec.name.lowercase()}")
                            )
                        }
                        androidx.compose.material3.HorizontalDivider()
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = "Export Project (.zip)",
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            },
                            onClick = {
                                sectionMenuExpanded = false
                                onOpenExportZipDialog()
                            },
                            modifier = Modifier.testTag("section_menu_item_export_zip")
                        )
                    }
                }
            }

            // Center-Right Controls: Split-Board Icon w/ Green Dot + Page Input + Search + Zoom (- | +)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                // Split-screen board icon with green active dot (matches screenshot)
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onCycleSplitBoard() }
                        .testTag("top_bar_split_board_button")
                ) {
                    Canvas(modifier = Modifier.size(22.dp)) {
                        drawRoundRect(
                            color = Color(0xFFE4E4E7),
                            cornerRadius = CornerRadius(3.dp.toPx(), 3.dp.toPx()),
                            style = Stroke(width = 1.8.dp.toPx())
                        )
                        // Vertical split bar inside icon
                        drawLine(
                            color = Color(0xFFE4E4E7),
                            start = Offset(size.width * 0.45f, 0f),
                            end = Offset(size.width * 0.45f, size.height),
                            strokeWidth = 1.8.dp.toPx()
                        )
                        // Filled right pane
                        drawRect(
                            color = Color(0xFFE4E4E7).copy(alpha = 0.35f),
                            topLeft = Offset(size.width * 0.47f, 1.5.dp.toPx()),
                            size = Size(size.width * 0.50f, size.height - 3.dp.toPx())
                        )
                        if (isDockedBoardOpen) {
                            drawCircle(
                                color = ReaderActiveGreenDot,
                                radius = 4.5.dp.toPx(),
                                center = Offset(size.width * 0.92f, size.height * 0.12f)
                            )
                        }
                    }
                }

                // Page Number Box + "of 552" (when in Reader with an active book)
                if (activeSection == AppSection.READER && activeBook != null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            contentAlignment = Alignment.CenterEnd,
                            modifier = Modifier
                                .width(46.dp)
                                .height(32.dp)
                                .clip(RoundedCornerShape(5.dp))
                                .background(ReaderPageInputPurple)
                                .border(1.dp, ReaderPageInputBorder, RoundedCornerShape(5.dp))
                                .padding(horizontal = 6.dp)
                        ) {
                            BasicTextField(
                                value = pageInputText,
                                onValueChange = { raw ->
                                    if (raw.length <= 4 && raw.all { it.isDigit() }) {
                                        pageInputText = raw
                                    }
                                },
                                singleLine = true,
                                cursorBrush = SolidColor(Color.White),
                                textStyle = TextStyle(
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium,
                                    textAlign = TextAlign.End
                                ),
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Number,
                                    imeAction = ImeAction.Go
                                ),
                                keyboardActions = KeyboardActions(
                                    onGo = {
                                        pageInputText.toIntOrNull()?.let { onJumpToPage(it) }
                                        focusManager.clearFocus()
                                    }
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("top_bar_page_input")
                            )
                        }
                        Spacer(Modifier.width(5.dp))
                        Text(
                            text = stringResource(R.string.of_pages_format, activeBook.totalPages),
                            color = Color(0xFFE4E4E7),
                            fontSize = 13.sp,
                            maxLines = 1
                        )
                    }

                    // Search magnifying glass icon
                    IconButton(
                        onClick = onToggleSearch,
                        modifier = Modifier.size(40.dp).testTag("top_bar_search_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = stringResource(R.string.cd_search_pdf),
                            tint = Color.White,
                            modifier = Modifier.size(21.dp)
                        )
                    }

                    // "- | +" Zoom Controls matching screenshot
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = onZoomOut,
                            modifier = Modifier.size(36.dp).testTag("top_bar_zoom_out")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Remove,
                                contentDescription = stringResource(R.string.cd_zoom_out),
                                tint = Color.White,
                                modifier = Modifier.size(19.dp)
                            )
                        }
                        VerticalDivider(
                            color = Color.White.copy(alpha = 0.25f),
                            modifier = Modifier.height(18.dp)
                        )
                        IconButton(
                            onClick = onZoomIn,
                            modifier = Modifier.size(36.dp).testTag("top_bar_zoom_in")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = stringResource(R.string.cd_zoom_in),
                                tint = Color.White,
                                modifier = Modifier.size(19.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PdfReaderContent(
    book: BookEntity,
    controller: PdfDocumentController,
    currentPage: Int,
    zoomScale: Float,
    isSearchOpen: Boolean,
    searchQuery: String,
    searchMatches: List<PdfSearchMatch>,
    currentMatchIndex: Int,
    isSearchingPdf: Boolean,
    pageAnnotationsMap: Map<Int, List<PdfAnnotationStroke>>,
    activeSensor: ActiveSensorState?,
    onPageVisible: (Int) -> Unit,
    onRunSearch: (String) -> Unit,
    onStepSearchMatch: (Int) -> Unit,
    onCloseSearch: () -> Unit,
    onOpenSensorAt: (pageNumber: Int, normX: Float, normY: Float) -> Unit,
    onUpdateSensorBox: (normX: Float, normY: Float, normW: Float, normH: Float, rescan: Boolean) -> Unit,
    onToggleSensorTurn: () -> Unit,
    onLoadSensorDiagram: () -> Unit,
    onOpenDiagramReviewModal: () -> Unit,
    onTriggerGeminiScan: () -> Unit,
    onCloseSensor: () -> Unit,
    onAddPageStroke: (Int, PdfAnnotationStroke) -> Unit,
    onUndoPageStroke: (Int) -> Unit,
    onClearPageStrokes: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState(
        initialFirstVisibleItemIndex = (currentPage - 1).coerceIn(0, (book.totalPages - 1).coerceAtLeast(0))
    )

    // Annotation toolbar state
    var showAnnotationToolbar by remember { mutableStateOf(false) }
    var activeDrawTool by remember { mutableStateOf("pan") } // "pan", "pen", "highlighter"
    var activeDrawColor by remember { mutableLongStateOf(0xFFDC2626L) }
    var showAnnotations by remember { mutableStateOf(true) }

    // Sync programmatic page jumps without fighting manual scroll
    LaunchedEffect(currentPage, book.id) {
        val targetIdx = (currentPage - 1).coerceIn(0, (book.totalPages - 1).coerceAtLeast(0))
        val visibleIndices = listState.layoutInfo.visibleItemsInfo.map { it.index }
        if (targetIdx !in visibleIndices) {
            listState.scrollToItem(targetIdx)
        }
    }

    // Track visible page while scrolling and save reading progress offline
    LaunchedEffect(listState, book.id) {
        snapshotFlow { listState.firstVisibleItemIndex }
            .distinctUntilChanged()
            .collect { firstIdx ->
                onPageVisible(firstIdx + 1)
            }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ReaderCanvasBg)
    ) {
        // Collapsible PDF Search Bar
        if (isSearchOpen) {
            Surface(
                color = Color(0xFF251F5E),
                shadowElevation = 4.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = onRunSearch,
                        placeholder = { Text("Search text in book...", color = Color(0xFFC7D2FE), fontSize = 13.sp) },
                        singleLine = true,
                        textStyle = TextStyle(color = Color.White, fontSize = 13.sp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("pdf_search_input")
                    )
                    if (isSearchingPdf) {
                        CircularProgressIndicator(
                            color = Color.White,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(18.dp)
                        )
                    } else {
                        Text(
                            text = if (searchMatches.isEmpty()) "0/0" else "${currentMatchIndex + 1}/${searchMatches.size}",
                            color = Color.White,
                            fontSize = 12.sp
                        )
                    }
                    IconButton(onClick = { onStepSearchMatch(-1) }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Previous match", tint = Color.White)
                    }
                    IconButton(onClick = { onStepSearchMatch(1) }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Next match", tint = Color.White)
                    }
                    IconButton(onClick = onCloseSearch, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close search", tint = Color.White)
                    }
                }
            }
        }

        // Collapsible PDF Page Annotation Bar
        if (showAnnotationToolbar) {
            Surface(
                color = Color(0xFFF8FAFC),
                shadowElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    IconButton(
                        onClick = { activeDrawTool = "pan" },
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (activeDrawTool == "pan") Color(0xFFE0E7FF) else Color.Transparent)
                    ) {
                        Icon(Icons.Default.PanTool, contentDescription = "Scroll mode", modifier = Modifier.size(18.dp))
                    }
                    IconButton(
                        onClick = { activeDrawTool = "pen" },
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (activeDrawTool == "pen") Color(0xFFE0E7FF) else Color.Transparent)
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "Pen tool", modifier = Modifier.size(18.dp))
                    }
                    IconButton(
                        onClick = { activeDrawTool = "highlighter" },
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (activeDrawTool == "highlighter") Color(0xFFE0E7FF) else Color.Transparent)
                    ) {
                        Icon(Icons.Default.Brush, contentDescription = "Highlighter tool", modifier = Modifier.size(18.dp))
                    }

                    for (swatch in listOf(0xFFDC2626L, 0xFF2563EBL, 0xFF16A34AL, 0xFFD97706L)) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(Color(swatch))
                                .border(
                                    width = if (activeDrawColor == swatch) 2.5.dp else 1.dp,
                                    color = if (activeDrawColor == swatch) Color.Black else Color.LightGray,
                                    shape = CircleShape
                                )
                                .clickable { activeDrawColor = swatch }
                        )
                    }

                    IconButton(onClick = { onUndoPageStroke(currentPage) }, modifier = Modifier.size(38.dp)) {
                        Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = "Undo stroke", modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = { onClearPageStrokes(currentPage) }, modifier = Modifier.size(38.dp)) {
                        Icon(Icons.Default.DeleteSweep, contentDescription = "Clear page annotations", modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = { showAnnotations = !showAnnotations }, modifier = Modifier.size(38.dp)) {
                        Icon(
                            if (showAnnotations) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                            contentDescription = "Toggle annotations visibility",
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(
                        onClick = {
                            activeDrawTool = "pan"
                            showAnnotationToolbar = false
                        },
                        modifier = Modifier.size(38.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close annotation toolbar", modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        // Main Continuous PDF Pages Area + Subtle Quick Scan / Annotate Floating Controls
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val viewportWidthDp = maxWidth
            val density = LocalDensity.current
            val horizontalScrollState = rememberScrollState()
            val scaledWidthDp = viewportWidthDp * zoomScale

            LazyColumn(
                state = listState,
                userScrollEnabled = activeDrawTool == "pan" && activeSensor == null,
                modifier = Modifier
                    .fillMaxSize()
                    .then(
                        if (zoomScale > 1.02f) Modifier.horizontalScroll(horizontalScrollState)
                        else Modifier
                    )
                    .testTag("pdf_pages_lazy_column")
            ) {
                items(
                    count = book.totalPages.coerceAtLeast(1),
                    key = { idx -> "${book.id}_page_${idx + 1}" }
                ) { idx ->
                    val pageNumber = idx + 1
                    val renderPx = with(density) {
                        (scaledWidthDp.toPx() * 1.15f).roundToInt().coerceIn(720, 2200)
                    }

                    Column(modifier = Modifier.width(scaledWidthDp)) {
                        // Inter-page dark gray bar matching screenshot (#3F3F46)
                        if (pageNumber > 1) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(9.dp)
                                    .background(ReaderPageDividerGray)
                            )
                        }

                        PdfSinglePageItem(
                            controller = controller,
                            pageNumber = pageNumber,
                            renderWidthPx = renderPx,
                            strokes = if (showAnnotations) pageAnnotationsMap[pageNumber].orEmpty() else emptyList(),
                            activeDrawTool = activeDrawTool,
                            activeDrawColor = activeDrawColor,
                            sensorOnThisPage = activeSensor?.takeIf { it.pageNumber == pageNumber },
                            onDoubleTapPage = { normX, normY ->
                                onOpenSensorAt(pageNumber, normX, normY)
                            },
                            onAddStroke = { stroke -> onAddPageStroke(pageNumber, stroke) },
                            onUpdateSensorBox = onUpdateSensorBox,
                            onToggleSensorTurn = onToggleSensorTurn,
                            onLoadSensorDiagram = onLoadSensorDiagram,
                            onOpenDiagramReviewModal = onOpenDiagramReviewModal,
                            onTriggerGeminiScan = onTriggerGeminiScan,
                            onCloseSensor = onCloseSensor
                        )

                        // Bottom page footer strip with centered serif page number (matching "18" in screenshot)
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.White)
                                .padding(vertical = 4.dp)
                        ) {
                            Text(
                                text = pageNumber.toString(),
                                fontFamily = MerriweatherFontFamily,
                                fontSize = 11.sp,
                                color = Color(0xFF27272A)
                            )
                        }
                    }
                }
            }

            // Non-intrusive Quick Sensor & Pen Floating Pills in Top-Right of Reader
            if (activeSensor == null) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 8.dp, end = 8.dp)
                ) {
                    Surface(
                        color = ReaderTopBarIndigo.copy(alpha = 0.86f),
                        shape = CircleShape,
                        shadowElevation = 4.dp,
                        modifier = Modifier
                            .height(34.dp)
                            .clickable { onOpenSensorAt(currentPage, 0.5f, 0.30f) }
                            .testTag("quick_scan_diagram_pill")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp)
                        ) {
                            Icon(
                                Icons.Default.CenterFocusStrong,
                                contentDescription = stringResource(R.string.cd_scan_diagram),
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(Modifier.width(4.dp))
                            Text("Scan", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }

                    Surface(
                        color = if (showAnnotationToolbar) Color(0xFFD97706) else ReaderTopBarIndigo.copy(alpha = 0.82f),
                        shape = CircleShape,
                        shadowElevation = 4.dp,
                        modifier = Modifier
                            .size(34.dp)
                            .clickable { showAnnotationToolbar = !showAnnotationToolbar }
                            .testTag("quick_annotate_pdf_pill")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Default.Edit,
                                contentDescription = stringResource(R.string.cd_annotate_pdf),
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PdfSinglePageItem(
    controller: PdfDocumentController,
    pageNumber: Int,
    renderWidthPx: Int,
    strokes: List<PdfAnnotationStroke>,
    activeDrawTool: String,
    activeDrawColor: Long,
    sensorOnThisPage: ActiveSensorState?,
    onDoubleTapPage: (Float, Float) -> Unit,
    onAddStroke: (PdfAnnotationStroke) -> Unit,
    onUpdateSensorBox: (Float, Float, Float, Float, Boolean) -> Unit,
    onToggleSensorTurn: () -> Unit,
    onLoadSensorDiagram: () -> Unit,
    onOpenDiagramReviewModal: () -> Unit,
    onTriggerGeminiScan: () -> Unit,
    onCloseSensor: () -> Unit
) {
    val pageBitmap by produceState<Bitmap?>(initialValue = null, controller, pageNumber, renderWidthPx) {
        value = controller.renderPage(pageNumber, renderWidthPx)
    }

    val aspectRatio by remember(pageBitmap) {
        derivedStateOf {
            val bmp = pageBitmap
            if (bmp != null && bmp.height > 0) bmp.width.toFloat() / bmp.height.toFloat() else 0.72f
        }
    }

    var boxSize by remember { mutableStateOf(IntSize.Zero) }
    val draftPoints = remember { mutableStateListOf<Pair<Float, Float>>() }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(aspectRatio)
            .background(Color.White)
            .onSizeChanged { boxSize = it }
            .pointerInput(pageNumber, activeDrawTool, sensorOnThisPage == null) {
                if (activeDrawTool == "pan" && sensorOnThisPage == null) {
                    detectTapGestures(
                        onDoubleTap = { offset ->
                            if (boxSize.width > 0 && boxSize.height > 0) {
                                onDoubleTapPage(
                                    (offset.x / boxSize.width).coerceIn(0.05f, 0.95f),
                                    (offset.y / boxSize.height).coerceIn(0.05f, 0.95f)
                                )
                            }
                        }
                    )
                }
            }
            .pointerInput(pageNumber, activeDrawTool, activeDrawColor) {
                if (activeDrawTool == "pen" || activeDrawTool == "highlighter") {
                    detectDragGestures(
                        onDragStart = { start ->
                            draftPoints.clear()
                            if (boxSize.width > 0 && boxSize.height > 0) {
                                draftPoints.add(
                                    (start.x / boxSize.width).coerceIn(0f, 1f) to
                                        (start.y / boxSize.height).coerceIn(0f, 1f)
                                )
                            }
                        },
                        onDrag = { change, _ ->
                            change.consume()
                            if (boxSize.width > 0 && boxSize.height > 0) {
                                draftPoints.add(
                                    (change.position.x / boxSize.width).coerceIn(0f, 1f) to
                                        (change.position.y / boxSize.height).coerceIn(0f, 1f)
                                )
                            }
                        },
                        onDragEnd = {
                            if (draftPoints.size >= 2) {
                                onAddStroke(
                                    PdfAnnotationStroke(
                                        id = UUID.randomUUID().toString().take(8),
                                        tool = activeDrawTool,
                                        colorHex = activeDrawColor,
                                        strokeWidth = if (activeDrawTool == "highlighter") 14f else 3.2f,
                                        points = draftPoints.toList()
                                    )
                                )
                            }
                            draftPoints.clear()
                        }
                    )
                }
            }
            .testTag("pdf_page_box_$pageNumber")
    ) {
        val bmp = pageBitmap
        if (bmp != null) {
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = "PDF Page $pageNumber",
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.size(28.dp))
            }
        }

        // Draw saved + live vector annotations
        if (strokes.isNotEmpty() || draftPoints.isNotEmpty()) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                fun drawPointsList(pts: List<Pair<Float, Float>>, colorHex: Long, tool: String, widthDp: Float) {
                    if (pts.size < 2) return
                    val path = Path()
                    path.moveTo(pts[0].first * size.width, pts[0].second * size.height)
                    for (i in 1 until pts.size) {
                        path.lineTo(pts[i].first * size.width, pts[i].second * size.height)
                    }
                    val alpha = if (tool == "highlighter") 0.35f else 0.92f
                    drawPath(
                        path = path,
                        color = Color(colorHex).copy(alpha = alpha),
                        style = Stroke(
                            width = widthDp.dp.toPx(),
                            cap = StrokeCap.Round,
                            join = StrokeJoin.Round
                        )
                    )
                }
                for (s in strokes) {
                    drawPointsList(s.points, s.colorHex, s.tool, s.strokeWidth)
                }
                if (draftPoints.size >= 2) {
                    drawPointsList(
                        draftPoints,
                        activeDrawColor,
                        activeDrawTool,
                        if (activeDrawTool == "highlighter") 14f else 3.2f
                    )
                }
            }
        }

        // Draggable & Resizable Diagram Sensor Overlay
        if (sensorOnThisPage != null && boxSize.width > 0 && boxSize.height > 0) {
            DraggableDiagramSensorOverlay(
                sensor = sensorOnThisPage,
                pageWidthPx = boxSize.width.toFloat(),
                pageHeightPx = boxSize.height.toFloat(),
                onUpdateBox = onUpdateSensorBox,
                onToggleTurn = onToggleSensorTurn,
                onLoadBoard = onLoadSensorDiagram,
                onReviewAndLearn = onOpenDiagramReviewModal,
                onGeminiScan = onTriggerGeminiScan,
                onClose = onCloseSensor
            )
        }
    }
}

@Composable
fun DraggableDiagramSensorOverlay(
    sensor: ActiveSensorState,
    pageWidthPx: Float,
    pageHeightPx: Float,
    onUpdateBox: (Float, Float, Float, Float, Boolean) -> Unit,
    onToggleTurn: () -> Unit,
    onLoadBoard: () -> Unit,
    onReviewAndLearn: () -> Unit,
    onGeminiScan: () -> Unit,
    onClose: () -> Unit
) {
    var localX by remember(sensor.normX) { mutableFloatStateOf(sensor.normX) }
    var localY by remember(sensor.normY) { mutableFloatStateOf(sensor.normY) }
    var localW by remember(sensor.normW) { mutableFloatStateOf(sensor.normW) }
    var localH by remember(sensor.normH) { mutableFloatStateOf(sensor.normH) }

    val density = LocalDensity.current
    val boxLeftPx = (localX * pageWidthPx).roundToInt()
    val boxTopPx = (localY * pageHeightPx).roundToInt()
    val boxWidthDp = with(density) { (localW * pageWidthPx).toDp() }
    val boxHeightDp = with(density) { (localH * pageHeightPx).toDp() }

    val scan = sensor.lastResult
    val borderColor = when {
        sensor.isScanning -> Color(0xFF2563EB)
        scan != null && scan.confidence >= 0.85f -> Color(0xFF16A34A)
        scan != null && scan.confidence >= 0.70f -> Color(0xFFD97706)
        else -> Color(0xFF7C3AED)
    }

    // Dim surround slightly to highlight diagram sensor
    Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.14f))) {
        // Crop Bounding Box
        Box(
            modifier = Modifier
                .offset { IntOffset(boxLeftPx, boxTopPx) }
                .size(boxWidthDp, boxHeightDp)
                .border(2.5.dp, borderColor, RoundedCornerShape(4.dp))
                .background(borderColor.copy(alpha = 0.08f))
                .pointerInput(pageWidthPx, pageHeightPx) {
                    detectDragGestures(
                        onDrag = { change, dragAmount ->
                            change.consume()
                            localX = (localX + dragAmount.x / pageWidthPx).coerceIn(0.01f, 0.98f - localW)
                            localY = (localY + dragAmount.y / pageHeightPx).coerceIn(0.01f, 0.98f - localH)
                            onUpdateBox(localX, localY, localW, localH, false)
                        },
                        onDragEnd = {
                            onUpdateBox(localX, localY, localW, localH, true)
                        }
                    )
                }
                .testTag("diagram_sensor_crop_box")
        ) {
            // Subtle 8x8 alignment grid lines inside sensor box
            Canvas(modifier = Modifier.fillMaxSize()) {
                for (i in 1..7) {
                    val x = size.width * i / 8f
                    val y = size.height * i / 8f
                    drawLine(borderColor.copy(alpha = 0.32f), Offset(x, 0f), Offset(x, size.height), 1f)
                    drawLine(borderColor.copy(alpha = 0.32f), Offset(0f, y), Offset(size.width, y), 1f)
                }
            }

            // Bottom-Right Resize Handle
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .size(26.dp)
                    .clip(RoundedCornerShape(topStart = 8.dp))
                    .background(borderColor)
                    .pointerInput(pageWidthPx, pageHeightPx) {
                        detectDragGestures(
                            onDrag = { change, dragAmount ->
                                change.consume()
                                localW = (localW + dragAmount.x / pageWidthPx).coerceIn(0.20f, 0.98f - localX)
                                localH = (localH + dragAmount.y / pageHeightPx).coerceIn(0.16f, 0.98f - localY)
                                onUpdateBox(localX, localY, localW, localH, false)
                            },
                            onDragEnd = {
                                onUpdateBox(localX, localY, localW, localH, true)
                            }
                        )
                    }
            )
        }

        // Control HUD Card anchored near bottom/top of page
        val placeControlAbove = (localY + localH) > 0.72f
        Surface(
            color = Color(0xFF18181B).copy(alpha = 0.95f),
            shape = RoundedCornerShape(12.dp),
            shadowElevation = 8.dp,
            modifier = Modifier
                .align(if (placeControlAbove) Alignment.TopCenter else Alignment.BottomCenter)
                .padding(10.dp)
                .fillMaxWidth(0.95f)
                .testTag("diagram_sensor_hud")
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.padding(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(
                            modifier = Modifier
                                .size(9.dp)
                                .clip(CircleShape)
                                .background(borderColor)
                        )
                        Text(
                            text = if (sensor.isScanning) {
                                "Scanning diagram..."
                            } else if (scan != null) {
                                "${(scan.confidence * 100).roundToInt()}% • ${scan.sourceMethod}"
                            } else {
                                "Drag box over diagram"
                            },
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        // Turn selector pill
                        Surface(
                            color = Color(0xFF3F3F46),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.clickable { onToggleTurn() }.testTag("sensor_turn_toggle")
                        ) {
                            Text(
                                text = if (sensor.preferredTurn == 'w') "White to move" else "Black to move",
                                color = Color.White,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                        IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Close scanner", tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                    }
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Button(
                        onClick = onLoadBoard,
                        enabled = !sensor.isScanning && scan != null,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                        modifier = Modifier.weight(1.15f).testTag("sensor_load_board_button")
                    ) {
                        Text(stringResource(R.string.scan_load_board), fontSize = 12.sp, maxLines = 1)
                    }

                    OutlinedButton(
                        onClick = onReviewAndLearn,
                        enabled = !sensor.isScanning && scan != null,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                        border = BorderStroke(1.dp, Color(0xFFA1A1AA)),
                        modifier = Modifier.weight(1f).testTag("sensor_review_button")
                    ) {
                        Text(stringResource(R.string.scan_review_edit), color = Color.White, fontSize = 12.sp, maxLines = 1)
                    }

                    OutlinedButton(
                        onClick = onGeminiScan,
                        enabled = !sensor.isScanning,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                        border = BorderStroke(1.dp, Color(0xFF818CF8)),
                        modifier = Modifier.weight(0.95f).testTag("sensor_gemini_ai_button")
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFFA5B4FC), modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("AI Scan", color = Color(0xFFE0E7FF), fontSize = 12.sp, maxLines = 1)
                    }
                }
            }
        }
    }
}
