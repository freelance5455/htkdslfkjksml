package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withLink
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.RaynoxCodeBlockBgDark
import com.example.ui.theme.RaynoxCyanAccent
import com.example.ui.theme.RaynoxIndigo
import kotlinx.coroutines.delay

sealed class MarkdownBlock {
    data class Heading(val level: Int, val text: String) : MarkdownBlock()
    data class Paragraph(val text: String) : MarkdownBlock()
    data class BulletItem(val bullet: String, val text: String) : MarkdownBlock()
    data class Quote(val text: String) : MarkdownBlock()
    data class CodeBlock(val language: String, val code: String) : MarkdownBlock()
    data class Table(val headers: List<String>, val rows: List<List<String>>) : MarkdownBlock()
    data object Divider : MarkdownBlock()
}

fun parseMarkdownBlocks(raw: String): List<MarkdownBlock> {
    if (raw.isBlank()) return emptyList()
    val blocks = mutableListOf<MarkdownBlock>()
    val lines = raw.replace("\r\n", "\n").lines()

    var i = 0
    val paragraphBuffer = StringBuilder()

    fun flushParagraph() {
        val text = paragraphBuffer.toString().trim()
        if (text.isNotEmpty()) {
            blocks.add(MarkdownBlock.Paragraph(text))
            paragraphBuffer.clear()
        }
    }

    while (i < lines.size) {
        val line = lines[i]
        val trimmed = line.trim()

        // Fenced code block
        if (trimmed.startsWith("```")) {
            flushParagraph()
            val lang = trimmed.removePrefix("```").trim().ifEmpty { "code" }
            val codeBuilder = StringBuilder()
            i++
            while (i < lines.size && !lines[i].trim().startsWith("```")) {
                if (codeBuilder.isNotEmpty()) codeBuilder.append("\n")
                codeBuilder.append(lines[i])
                i++
            }
            blocks.add(MarkdownBlock.CodeBlock(language = lang, code = codeBuilder.toString()))
            i++
            continue
        }

        // Markdown Table detection: starts and ends with '|'
        if (trimmed.startsWith("|") && trimmed.endsWith("|") && trimmed.count { it == '|' } >= 2) {
            val nextLine = lines.getOrNull(i + 1)?.trim()
            if (nextLine != null && nextLine.startsWith("|") && nextLine.contains("---")) {
                flushParagraph()
                val headers = trimmed.split("|")
                    .map { it.trim() }
                    .filterIndexed { idx, _ -> idx != 0 && idx != trimmed.split("|").lastIndex }

                i += 2 // skip header and delimiter line
                val rows = mutableListOf<List<String>>()
                while (i < lines.size) {
                    val rowLine = lines[i].trim()
                    if (rowLine.startsWith("|") && rowLine.endsWith("|") && rowLine.count { it == '|' } >= 2) {
                        val cells = rowLine.split("|")
                            .map { it.trim() }
                            .filterIndexed { idx, _ -> idx != 0 && idx != rowLine.split("|").lastIndex }
                        rows.add(cells)
                        i++
                    } else {
                        break
                    }
                }
                if (headers.isNotEmpty() && rows.isNotEmpty()) {
                    blocks.add(MarkdownBlock.Table(headers = headers, rows = rows))
                }
                continue
            }
        }

        // Empty line separates paragraphs
        if (trimmed.isEmpty()) {
            flushParagraph()
            i++
            continue
        }

        // Horizontal rule
        if (trimmed == "---" || trimmed == "***" || trimmed == "___") {
            flushParagraph()
            blocks.add(MarkdownBlock.Divider)
            i++
            continue
        }

        // Headings (#, ##, ###, ####)
        val headingMatch = Regex("^(#{1,4})\\s+(.+)$").find(trimmed)
        if (headingMatch != null) {
            flushParagraph()
            val level = headingMatch.groupValues[1].length
            val text = headingMatch.groupValues[2].trim()
            blocks.add(MarkdownBlock.Heading(level = level, text = text))
            i++
            continue
        }

        // Bullet list item
        val bulletMatch = Regex("^([-*•])\\s+(.+)$").find(trimmed)
        if (bulletMatch != null) {
            flushParagraph()
            blocks.add(MarkdownBlock.BulletItem(bullet = "•", text = bulletMatch.groupValues[2].trim()))
            i++
            continue
        }

        // Numbered list item
        val numberedMatch = Regex("^(\\d+\\.)\\s+(.+)$").find(trimmed)
        if (numberedMatch != null) {
            flushParagraph()
            blocks.add(
                MarkdownBlock.BulletItem(
                    bullet = numberedMatch.groupValues[1],
                    text = numberedMatch.groupValues[2].trim()
                )
            )
            i++
            continue
        }

        // Blockquote
        if (trimmed.startsWith(">")) {
            flushParagraph()
            blocks.add(MarkdownBlock.Quote(trimmed.removePrefix(">").trim()))
            i++
            continue
        }

        if (paragraphBuffer.isNotEmpty()) {
            paragraphBuffer.append("\n")
        }
        paragraphBuffer.append(line)
        i++
    }

    flushParagraph()
    return blocks
}

@Composable
fun MarkdownText(
    markdown: String,
    modifier: Modifier = Modifier,
    textColor: Color = MaterialTheme.colorScheme.onBackground
) {
    val blocks = remember(markdown) { parseMarkdownBlocks(markdown) }
    val inlineCodeBg = MaterialTheme.colorScheme.surfaceVariant
    val linkColor = MaterialTheme.colorScheme.secondary

    SelectionContainer(modifier = modifier) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            blocks.forEach { block ->
                when (block) {
                    is MarkdownBlock.Heading -> {
                        val style = when (block.level) {
                            1 -> MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold)
                            2 -> MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                            3 -> MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                            else -> MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
                        }
                        Text(
                            text = buildInlineAnnotatedString(block.text, inlineCodeBg, linkColor),
                            style = style,
                            color = textColor,
                            modifier = Modifier.padding(top = 8.dp, bottom = 2.dp)
                        )
                    }

                    is MarkdownBlock.Paragraph -> {
                        Text(
                            text = buildInlineAnnotatedString(block.text, inlineCodeBg, linkColor),
                            style = MaterialTheme.typography.bodyLarge,
                            color = textColor
                        )
                    }

                    is MarkdownBlock.BulletItem -> {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(start = 2.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Text(
                                text = block.bullet,
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    color = RaynoxIndigo
                                ),
                                modifier = Modifier.width(22.dp)
                            )
                            Text(
                                text = buildInlineAnnotatedString(block.text, inlineCodeBg, linkColor),
                                style = MaterialTheme.typography.bodyLarge,
                                color = textColor,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    is MarkdownBlock.Quote -> {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(3.dp)
                                    .height(24.dp)
                                    .background(RaynoxIndigo, RoundedCornerShape(2.dp))
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = buildInlineAnnotatedString(block.text, inlineCodeBg, linkColor),
                                style = MaterialTheme.typography.bodyMedium.copy(fontStyle = FontStyle.Italic),
                                color = textColor.copy(alpha = 0.9f)
                            )
                        }
                    }

                    is MarkdownBlock.CodeBlock -> {
                        FormattedCodeBlockCard(
                            language = block.language,
                            code = block.code
                        )
                    }

                    is MarkdownBlock.Table -> {
                        MarkdownTableCard(table = block)
                    }

                    is MarkdownBlock.Divider -> {
                        HorizontalDivider(
                            modifier = Modifier.padding(vertical = 6.dp),
                            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MarkdownTableCard(table: MarkdownBlock.Table) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(10.dp))
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
            .horizontalScroll(rememberScrollState())
    ) {
        // Table Header Row
        Row(
            modifier = Modifier
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            table.headers.forEach { header ->
                Text(
                    text = header,
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .widthIn(min = 100.dp, max = 220.dp)
                        .padding(horizontal = 6.dp)
                )
            }
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))

        // Table Data Rows
        table.rows.forEachIndexed { index, row ->
            val rowBg = if (index % 2 == 1) {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)
            } else {
                Color.Transparent
            }
            Row(
                modifier = Modifier
                    .background(rowBg)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                row.forEach { cell ->
                    Text(
                        text = cell,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier
                            .widthIn(min = 100.dp, max = 220.dp)
                            .padding(horizontal = 6.dp)
                    )
                }
            }
            if (index < table.rows.lastIndex) {
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            }
        }
    }
}

@Composable
private fun FormattedCodeBlockCard(
    language: String,
    code: String
) {
    val context = LocalContext.current
    var copied by remember { mutableStateOf(false) }

    LaunchedEffect(copied) {
        if (copied) {
            delay(2000L)
            copied = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(RaynoxCodeBlockBgDark)
            .border(1.dp, Color(0xFF262A3A), RoundedCornerShape(12.dp))
    ) {
        // Code Header Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF151822))
                .padding(horizontal = 12.dp, vertical = 7.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = language.lowercase(),
                style = MaterialTheme.typography.labelMedium.copy(
                    fontFamily = JetBrainsMonoFamily,
                    color = RaynoxCyanAccent
                )
            )

            Surface(
                onClick = {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("Code Block", code))
                    copied = true
                },
                shape = RoundedCornerShape(6.dp),
                color = Color.Transparent
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (copied) Icons.Outlined.Check else Icons.Outlined.ContentCopy,
                        contentDescription = "Copy code",
                        tint = if (copied) Color(0xFF10B981) else Color(0xFF9CA3AF),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (copied) "Copied" else "Copy code",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (copied) Color(0xFF10B981) else Color(0xFFD1D5DB)
                    )
                }
            }
        }

        // Scrollable Code Content
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(14.dp)
        ) {
            Text(
                text = code.ifEmpty { " " },
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontFamily = JetBrainsMonoFamily,
                    fontSize = 13.sp,
                    lineHeight = 20.sp,
                    color = Color(0xFFECEFF4)
                )
            )
        }
    }
}

private val INLINE_TOKEN_REGEX = Regex(
    "(`[^`]+`)|(\\*\\*[^*]+\\*\\*)|(\\*[^*]+\\*)|(\\[([^]]+)]\\((https?://[^)\\s]+)\\))|(https?://\\S+)"
)

fun buildInlineAnnotatedString(
    text: String,
    inlineCodeBg: Color,
    linkColor: Color
): AnnotatedString = buildAnnotatedString {
    var cursor = 0
    for (match in INLINE_TOKEN_REGEX.findAll(text)) {
        if (match.range.first > cursor) {
            append(text.substring(cursor, match.range.first))
        }
        val token = match.value
        when {
            token.startsWith("`") && token.endsWith("`") && token.length >= 2 -> {
                withStyle(
                    SpanStyle(
                        fontFamily = JetBrainsMonoFamily,
                        background = inlineCodeBg,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Medium
                    )
                ) {
                    append(" ${token.substring(1, token.length - 1)} ")
                }
            }

            token.startsWith("**") && token.endsWith("**") && token.length >= 4 -> {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                    append(token.substring(2, token.length - 2))
                }
            }

            token.startsWith("*") && token.endsWith("*") && token.length >= 2 -> {
                withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                    append(token.substring(1, token.length - 1))
                }
            }

            match.groups[4] != null -> {
                val label = match.groups[5]?.value ?: token
                val url = match.groups[6]?.value ?: ""
                withLink(
                    LinkAnnotation.Url(
                        url = url,
                        styles = TextLinkStyles(
                            style = SpanStyle(
                                color = linkColor,
                                textDecoration = TextDecoration.Underline,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    )
                ) {
                    append(label)
                }
            }

            match.groups[7] != null -> {
                val url = match.groups[7]?.value ?: token
                withLink(
                    LinkAnnotation.Url(
                        url = url,
                        styles = TextLinkStyles(
                            style = SpanStyle(
                                color = linkColor,
                                textDecoration = TextDecoration.Underline
                            )
                        )
                    )
                ) {
                    append(url)
                }
            }

            else -> append(token)
        }
        cursor = match.range.last + 1
    }
    if (cursor < text.length) {
        append(text.substring(cursor))
    }
}
