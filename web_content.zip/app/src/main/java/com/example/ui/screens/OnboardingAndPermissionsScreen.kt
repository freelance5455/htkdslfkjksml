package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.usb.UsbManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.R
import com.example.data.model.StorageRootType
import com.example.data.model.StorageVolumeInfo

@Composable
fun OnboardingScreen(
    volumes: List<StorageVolumeInfo>,
    onGrantSafFolder: () -> Unit,
    onContinue: () -> Unit
) {
    val context = LocalContext.current
    var refreshTrigger by remember { mutableIntStateOf(0) }

    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        refreshTrigger++
    }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        refreshTrigger++
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        refreshTrigger++
    }

    val hasCamera = remember(refreshTrigger) { isGranted(context, Manifest.permission.CAMERA) }
    val hasMic = remember(refreshTrigger) { isGranted(context, Manifest.permission.RECORD_AUDIO) }
    val hasNotif = remember(refreshTrigger) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            isGranted(context, Manifest.permission.POST_NOTIFICATIONS)
        } else true
    }
    val safFoldersCount = volumes.count { it.type == StorageRootType.SAF_FOLDER || it.type == StorageRootType.SAF_CLOUD }
    val usbDevicesCount = remember(refreshTrigger, volumes) {
        val usbManager = context.getSystemService(Context.USB_SERVICE) as? UsbManager
        (usbManager?.deviceList?.size ?: 0) + volumes.count { it.type == StorageRootType.USB_OTG }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Column(
                    modifier = Modifier.widthIn(max = 560.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_onboarding_hero_1793152707878),
                        contentDescription = "My Files Onboarding Banner",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(190.dp)
                            .clip(RoundedCornerShape(26.dp))
                    )
                    Spacer(Modifier.height(18.dp))
                    Text(
                        text = "Welcome to My Files",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "Grant access below to browse device folders, capture photos & videos directly into folders, and connect USB OTG drives. Denied permissions are handled gracefully.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            item {
                PermissionAccessCard(
                    icon = Icons.Filled.FolderOpen,
                    title = "Storage & Device Folders (SAF)",
                    description = "Mount Downloads, Documents, DCIM, or SD folders via Android Storage Access Framework.",
                    statusText = if (safFoldersCount > 0) "$safFoldersCount folder(s) mounted" else "Workspace ready • Add folder",
                    isGranted = safFoldersCount > 0,
                    actionLabel = "Select Folder",
                    testTag = "perm_saf_button",
                    onRequest = onGrantSafFolder
                )
            }

            item {
                PermissionAccessCard(
                    icon = Icons.Filled.CameraAlt,
                    title = "Camera",
                    description = "Capture high-resolution photos and videos directly into DCIM/Camera or any open folder.",
                    statusText = if (hasCamera) "Granted" else "Not granted",
                    isGranted = hasCamera,
                    actionLabel = "Allow",
                    testTag = "perm_camera_button",
                    onRequest = { cameraLauncher.launch(Manifest.permission.CAMERA) }
                )
            }

            item {
                PermissionAccessCard(
                    icon = Icons.Filled.Mic,
                    title = "Microphone",
                    description = "Record clear audio tracks when capturing video clips in the in-app camera.",
                    statusText = if (hasMic) "Granted" else "Not granted",
                    isGranted = hasMic,
                    actionLabel = "Allow",
                    testTag = "perm_mic_button",
                    onRequest = { micLauncher.launch(Manifest.permission.RECORD_AUDIO) }
                )
            }

            item {
                PermissionAccessCard(
                    icon = Icons.Filled.Notifications,
                    title = "Notifications",
                    description = "Receive completion alerts for large file transfers, ZIP archiving, and AI video exports.",
                    statusText = if (hasNotif) "Granted" else "Optional",
                    isGranted = hasNotif,
                    actionLabel = "Allow",
                    testTag = "perm_notif_button",
                    onRequest = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    }
                )
            }

            item {
                PermissionAccessCard(
                    icon = Icons.Filled.Usb,
                    title = "USB / OTG Storage",
                    description = "Automatically detect FAT32, exFAT, NTFS, and ext4 external drives when plugged in.",
                    statusText = if (usbDevicesCount > 0) "$usbDevicesCount USB volume(s) detected" else "Listening for OTG hardware",
                    isGranted = usbDevicesCount > 0,
                    actionLabel = "Mount USB Tree",
                    testTag = "perm_usb_button",
                    onRequest = onGrantSafFolder
                )
            }

            item {
                Column(
                    modifier = Modifier
                        .widthIn(max = 560.dp)
                        .fillMaxWidth()
                        .padding(top = 8.dp, bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onContinue,
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("onboarding_continue_button")
                    ) {
                        Text("Start using My Files", style = MaterialTheme.typography.titleMedium)
                    }
                    TextButton(
                        onClick = onContinue,
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    ) {
                        Text("Skip for now")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PermissionsSettingsScreen(
    volumes: List<StorageVolumeInfo>,
    onGrantSafFolder: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    var refreshTrigger by remember { mutableIntStateOf(0) }

    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { refreshTrigger++ }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { refreshTrigger++ }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { refreshTrigger++ }

    val hasCamera = remember(refreshTrigger) { isGranted(context, Manifest.permission.CAMERA) }
    val hasMic = remember(refreshTrigger) { isGranted(context, Manifest.permission.RECORD_AUDIO) }
    val hasNotif = remember(refreshTrigger) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            isGranted(context, Manifest.permission.POST_NOTIFICATIONS)
        } else true
    }
    val safFolders = volumes.filter { it.type == StorageRootType.SAF_FOLDER || it.type == StorageRootType.SAF_CLOUD }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Permissions & Access") },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("permissions_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                PermissionAccessCard(
                    icon = Icons.Filled.FolderOpen,
                    title = "Storage &SAF Folders",
                    description = if (safFolders.isEmpty()) {
                        "No external device folders mounted yet. Tap Re-request to grant folder access."
                    } else {
                        "Mounted folders: ${safFolders.joinToString { it.title }}"
                    },
                    statusText = "${safFolders.size} active folder grant(s)",
                    isGranted = safFolders.isNotEmpty(),
                    actionLabel = "Add Folder",
                    testTag = "settings_perm_saf",
                    onRequest = onGrantSafFolder
                )
            }
            item {
                PermissionAccessCard(
                    icon = Icons.Filled.CameraAlt,
                    title = "Camera Access",
                    description = "Required for direct photo and video capture into folders.",
                    statusText = if (hasCamera) "Granted" else "Denied / Not requested",
                    isGranted = hasCamera,
                    actionLabel = "Re-request",
                    testTag = "settings_perm_camera",
                    onRequest = { cameraLauncher.launch(Manifest.permission.CAMERA) }
                )
            }
            item {
                PermissionAccessCard(
                    icon = Icons.Filled.Mic,
                    title = "Microphone Access",
                    description = "Required for audio track capture during video recording.",
                    statusText = if (hasMic) "Granted" else "Denied / Not requested",
                    isGranted = hasMic,
                    actionLabel = "Re-request",
                    testTag = "settings_perm_mic",
                    onRequest = { micLauncher.launch(Manifest.permission.RECORD_AUDIO) }
                )
            }
            item {
                PermissionAccessCard(
                    icon = Icons.Filled.Notifications,
                    title = "Notifications",
                    description = "Used to report background file operation and export status.",
                    statusText = if (hasNotif) "Granted" else "Denied / Not requested",
                    isGranted = hasNotif,
                    actionLabel = "Re-request",
                    testTag = "settings_perm_notif",
                    onRequest = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    }
                )
            }
            item {
                PermissionAccessCard(
                    icon = Icons.Filled.Usb,
                    title = "USB / OTG Hardware",
                    description = "Connect any USB-C flash drive or OTG adapter and mount its root folder.",
                    statusText = "Hardware listener active",
                    isGranted = true,
                    actionLabel = "Mount USB",
                    testTag = "settings_perm_usb",
                    onRequest = onGrantSafFolder
                )
            }
        }
    }
}

@Composable
private fun PermissionAccessCard(
    icon: ImageVector,
    title: String,
    description: String,
    statusText: String,
    isGranted: Boolean,
    actionLabel: String,
    testTag: String,
    onRequest: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier
            .widthIn(max = 560.dp)
            .fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.size(48.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(12.dp)
                )
            }
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(
                    description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isGranted) {
                        Icon(
                            Icons.Filled.CheckCircle,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                    }
                    Text(
                        text = statusText,
                        style = MaterialTheme.typography.labelMedium,
                        color = if (isGranted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(Modifier.width(10.dp))
            FilledTonalButton(
                onClick = onRequest,
                modifier = Modifier.testTag(testTag)
            ) {
                Text(actionLabel)
            }
        }
    }
}

private fun isGranted(context: Context, permission: String): Boolean {
    return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
}
