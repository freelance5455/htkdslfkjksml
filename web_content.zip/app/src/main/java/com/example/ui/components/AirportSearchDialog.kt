package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Airport
import com.example.ui.screens.home.AirportFilterTab
import com.example.ui.theme.*
import com.example.ui.viewmodel.WeatherViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AirportSearchDialog(
  viewModel: WeatherViewModel,
  onDismiss: () -> Unit,
  onAirportSelected: (Airport) -> Unit
) {
  val searchQuery by viewModel.searchQuery.collectAsState()
  val searchResults by viewModel.searchResults.collectAsState()
  var filterTab by remember { mutableStateOf(AirportFilterTab.ALL) }

  val filteredList = remember(searchResults, filterTab) {
    when (filterTab) {
      AirportFilterTab.ALL -> searchResults
      AirportFilterTab.DOMESTIC -> searchResults.filter { it.icao.startsWith("OI") || it.countryEn.equals("Iran", ignoreCase = true) }
      AirportFilterTab.INTERNATIONAL -> searchResults.filter { !it.icao.startsWith("OI") && !it.countryEn.equals("Iran", ignoreCase = true) }
    }
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = Color.White,
      modifier = Modifier
        .fillMaxWidth(0.95f)
        .fillMaxHeight(0.85f)
        .testTag("airport_search_dialog")
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Search, contentDescription = null, tint = OceanBlue)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Airport Search & Selection",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = AtcTextMain
            )
          }
          IconButton(onClick = onDismiss) {
            Icon(Icons.Default.Clear, contentDescription = "Close", tint = AtcTextMuted)
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Domestic vs International Tabs
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          AirportFilterTab.values().forEach { tab ->
            val isSelected = filterTab == tab
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = if (isSelected) OceanBlue else Color(0xFFF1F5F9),
              modifier = Modifier
                .weight(1f)
                .clickable { filterTab = tab }
            ) {
              Box(
                modifier = Modifier.padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = tab.label,
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                  color = if (isSelected) Color.White else AtcTextMain,
                  fontSize = 11.sp
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = searchQuery,
          onValueChange = { viewModel.onSearchQueryChanged(it) },
          placeholder = { Text("Search ICAO, IATA, City, or Country...", color = AtcTextMuted) },
          leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = OceanBlue) },
          trailingIcon = {
            if (searchQuery.isNotBlank()) {
              IconButton(onClick = { viewModel.onSearchQueryChanged("") }) {
                Icon(Icons.Default.Clear, contentDescription = "Clear", tint = AtcTextMuted)
              }
            }
          },
          singleLine = true,
          shape = RoundedCornerShape(10.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = OceanBlue,
            unfocusedBorderColor = Color(0xFFCBD5E1)
          ),
          modifier = Modifier.fillMaxWidth().testTag("input_airport_search")
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
          text = "Results (${filteredList.size} airports):",
          style = MaterialTheme.typography.labelSmall,
          fontWeight = FontWeight.SemiBold,
          color = AtcTextMuted
        )

        Spacer(modifier = Modifier.height(6.dp))

        LazyColumn(
          modifier = Modifier.weight(1f),
          verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          items(filteredList) { apt ->
            val isDomestic = apt.icao.startsWith("OI") || apt.countryEn.equals("Iran", ignoreCase = true)
            Card(
              shape = RoundedCornerShape(10.dp),
              colors = CardDefaults.cardColors(containerColor = if (isDomestic) Color(0xFFF8FAFC) else Color(0xFFFFFDF7)),
              border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
              modifier = Modifier
                .fillMaxWidth()
                .clickable {
                  viewModel.selectAirport(apt)
                  onAirportSelected(apt)
                }
                .testTag("search_item_${apt.icao}")
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                      text = apt.icao,
                      style = MaterialTheme.typography.titleMedium,
                      fontWeight = FontWeight.Bold,
                      color = OceanBlue
                    )
                    if (apt.iata.isNotBlank()) {
                      Spacer(modifier = Modifier.width(6.dp))
                      Text(
                        text = "(${apt.iata})",
                        style = MaterialTheme.typography.labelSmall,
                        color = AtcTextMuted
                      )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                      shape = RoundedCornerShape(4.dp),
                      color = if (isDomestic) Color(0xFFDCFCE7) else Color(0xFFFFEDD5)
                    ) {
                      Text(
                        text = if (isDomestic) "DOMESTIC" else "INTL",
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isDomestic) Color(0xFF15803D) else Color(0xFFC2410C),
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                      )
                    }
                  }
                  Text(
                    text = "${apt.nameEn} (${apt.nameFa})",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Medium,
                    color = AtcTextMain
                  )
                  Text(
                    text = "${apt.cityEn}, ${apt.countryEn} • Elev: ${apt.elevationFt} FT",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 11.sp,
                    color = AtcTextMuted
                  )
                }

                Surface(
                  shape = RoundedCornerShape(4.dp),
                  color = Color(0xFFE0F2FE)
                ) {
                  Text(
                    text = "FIR ${apt.fir}",
                    style = MaterialTheme.typography.labelSmall,
                    color = OceanBlueDark,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}
