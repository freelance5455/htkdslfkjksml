package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ServerFilesTab(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedFileIndex by remember { mutableIntStateOf(0) }

    val fileList = listOf(
        Pair("server.js", SERVER_JS_CODE),
        Pair("package.json", PACKAGE_JSON_CODE),
        Pair("public/index.html", INDEX_HTML_CODE),
        Pair("scripts/main.js", MAIN_JS_CODE)
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "ARCHIVOS COMPLETOS DEL SISTEMA",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFA0AEC0)
                )
                Text(
                    text = "Servidor Node.js, Web PWA y Addon Bedrock Script API listos.",
                    fontSize = 11.sp,
                    color = Color(0xFF718096)
                )
            }

            Button(
                onClick = {
                    val current = fileList[selectedFileIndex]
                    copyToClipboard(context, current.first, current.second)
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB703)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("btn_copy_file_code")
            ) {
                Icon(Icons.Default.ContentCopy, contentDescription = "Copiar", tint = Color.Black)
                Text(" Copiar", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        ScrollableTabRow(
            selectedTabIndex = selectedFileIndex,
            containerColor = Color(0xFF1B2028),
            contentColor = Color(0xFFFFB703),
            edgePadding = 0.dp,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedFileIndex]),
                    color = Color(0xFFFFB703)
                )
            }
        ) {
            fileList.forEachIndexed { index, pair ->
                Tab(
                    selected = selectedFileIndex == index,
                    onClick = { selectedFileIndex = index },
                    text = {
                        Text(
                            text = pair.first,
                            fontSize = 12.sp,
                            fontWeight = if (selectedFileIndex == index) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedFileIndex == index) Color(0xFFFFB703) else Color(0xFFA0AEC0)
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Visor de Código con Scroll
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.Black),
            shape = RoundedCornerShape(10.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2C3442)),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            LazyColumn(modifier = Modifier.padding(12.dp)) {
                item {
                    val code = fileList[selectedFileIndex].second
                    Box(modifier = Modifier.horizontalScroll(rememberScrollState())) {
                        Text(
                            text = code,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = Color(0xFFE2E8F0)
                        )
                    }
                }
            }
        }
    }
}

private fun copyToClipboard(context: Context, filename: String, content: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText(filename, content)
    clipboard.setPrimaryClip(clip)
    Toast.makeText(context, "$filename copiado al portapapeles", Toast.LENGTH_SHORT).show()
}

private const val PACKAGE_JSON_CODE = """{
  "name": "chaufaland-server",
  "version": "1.0.0",
  "description": "CHAUFALAND - Servidor WebRTC, Bedrock WebSocket y Exaroton",
  "main": "server.js",
  "scripts": {
    "start": "node server.js"
  },
  "dependencies": {
    "cors": "^2.8.5",
    "express": "^4.19.2",
    "socket.io": "^4.7.5",
    "ws": "^8.17.0"
  }
}"""

private const val MAIN_JS_CODE = """// scripts/main.js - Minecraft Bedrock Script API
import { world, system } from "@minecraft/server";
import { http, HttpRequest, HttpRequestMethod } from "@minecraft/server-net";

const BRIDGE_WS_URL = "ws://localhost:3000/bedrock-ws";
let wsClient = null;

world.afterEvents.playerSpawn.subscribe((event) => {
  if (event.initialSpawn) {
    const p = event.player;
    sendPacket("player_join", {
      gamerTag: p.name,
      dimension: p.dimension.id.replace("minecraft:", ""),
      x: Math.round(p.location.x),
      y: Math.round(p.location.y),
      z: Math.round(p.location.z)
    });
  }
});

system.runInterval(() => {
  for (const player of world.getAllPlayers()) {
    sendPacket("player_telemetry", {
      gamerTag: player.name,
      dimension: player.dimension.id.replace("minecraft:", ""),
      x: Math.round(player.location.x),
      y: Math.round(player.location.y),
      z: Math.round(player.location.z)
    });
  }
}, 40);

function sendPacket(event, payload) {
  if (wsClient && wsClient.readyState === 1) {
    wsClient.send(JSON.stringify({ event, ...payload }));
  }
}"""

private const val SERVER_JS_CODE = """// server.js - Express + Socket.io + WebRTC + Exaroton + Bedrock WS
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const WebSocket = require('ws');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });
const PORT = process.env.PORT || 3000;
const ADMIN_SECRET = 'JuancitoChen23';

// Bedrock WebSocket Bridge en /bedrock-ws
const wssBedrock = new WebSocket.Server({ noServer: true });
server.on('upgrade', (req, sock, head) => {
  if (req.url.startsWith('/bedrock-ws')) {
    wssBedrock.handleUpgrade(req, sock, head, (ws) => wssBedrock.emit('connection', ws, req));
  }
});

server.listen(PORT, () => console.log('CHAUFALAND Server activo en puerto ' + PORT));"""

private const val INDEX_HTML_CODE = """<!-- public/index.html - Web / PWA Interactiva CHAUFALAND -->
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>CHAUFALAND - Panel & Voz</title>
  <link rel="stylesheet" href="style.css">
  <script src="/socket.io/socket.io.js"></script>
</head>
<body>
  <!-- Header con Logo 3D CHAUFALAND y fondo dirt -->
  <!-- Canales de Voz WebRTC y Estado Exaroton / Aternos -->
</body>
</html>"""
