package com.example.ui.game

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class GameState(
    val currentStage: Int = 1,
    val food: Int = 150,
    val wood: Int = 200,
    val stone: Int = 100,
    val gold: Int = 50,
    val population: Int = 5,
    val maxPopulation: Int = 10,
    val isPaused: Boolean = false,
    val isVictory: Boolean = false,
    val isGameOver: Boolean = false
)

class GameViewModel : ViewModel() {
    private val _state = MutableStateFlow(GameState())
    val state: StateFlow<GameState> = _state.asStateFlow()

    fun updateResources(food: Int, wood: Int, stone: Int, gold: Int, pop: Int, maxPop: Int) {
        _state.value = _state.value.copy(
            food = food,
            wood = wood,
            stone = stone,
            gold = gold,
            population = pop,
            maxPopulation = maxPop
        )
    }

    fun setStage(stage: Int) {
        _state.value = _state.value.copy(currentStage = stage, isVictory = false, isGameOver = false)
    }

    fun togglePause() {
        _state.value = _state.value.copy(isPaused = !_state.value.isPaused)
    }

    fun triggerVictory() {
        _state.value = _state.value.copy(isVictory = true)
    }

    fun triggerGameOver() {
        _state.value = _state.value.copy(isGameOver = true)
    }
}
