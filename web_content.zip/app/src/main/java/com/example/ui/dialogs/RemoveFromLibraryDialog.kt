package com.example.ui.dialogs

import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import com.example.data.model.SongEntity
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkError
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun RemoveFromLibraryDialog(
    song: SongEntity?,
    multipleCount: Int = 0,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    val title = if (song != null) "Remove from Library?" else "Remove $multipleCount songs?"
    val message = if (song != null) {
        "\"${song.title}\" will be removed from your app library and playlists.\n\nThe copied audio file will remain stored on your device and will NOT be deleted."
    } else {
        "$multipleCount songs will be removed from your app library and playlists.\n\nThe copied audio files will remain stored on your device and will NOT be deleted."
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurfaceElevated,
        title = {
            Text(title, style = MaterialTheme.typography.titleLarge, color = TextPrimary)
        },
        text = {
            Text(message, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(
                    containerColor = DarkError,
                    contentColor = DarkBackground
                )
            ) {
                Text("Remove")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}
