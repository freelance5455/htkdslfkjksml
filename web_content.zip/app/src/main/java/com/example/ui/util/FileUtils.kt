package com.example.ui.util

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object FileUtils {

    /**
     * Creates a temporary file and returns its FileProvider content URI for the camera.
     */
    fun createCameraImageUri(context: Context): Uri {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val storageDir = File(context.cacheDir, "camera_photos").apply {
            if (!exists()) mkdirs()
        }
        val file = File(storageDir, "JPEG_${timeStamp}.jpg")
        val authority = "${context.packageName}.fileprovider"
        return FileProvider.getUriForFile(context, authority, file)
    }

    /**
     * Reads an image URI into a Base64 string with appropriate scaling.
     */
    suspend fun uriToBase64(context: Context, uri: Uri): Pair<String, String>? = withContext(Dispatchers.IO) {
        try {
            val contentResolver = context.contentResolver
            val mimeType = contentResolver.getType(uri) ?: "image/jpeg"

            val inputStream: InputStream? = contentResolver.openInputStream(uri)
            val originalBitmap = BitmapFactory.decodeStream(inputStream)
            inputStream?.close()

            if (originalBitmap == null) return@withContext null

            // Scale if too large (max dimension 1024px)
            val maxDimension = 1024
            val width = originalBitmap.width
            val height = originalBitmap.height
            val scaledBitmap = if (width > maxDimension || height > maxDimension) {
                val ratio = width.toFloat() / height.toFloat()
                val targetW = if (width > height) maxDimension else (maxDimension * ratio).toInt()
                val targetH = if (width > height) (maxDimension / ratio).toInt() else maxDimension
                Bitmap.createScaledBitmap(originalBitmap, targetW, targetH, true)
            } else {
                originalBitmap
            }

            val outputStream = ByteArrayOutputStream()
            scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 85, outputStream)
            val bytes = outputStream.toByteArray()
            val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
            Pair(base64, mimeType)
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Reads text content from a file URI (TXT, CSV, JSON, XML, MD, etc.)
     */
    suspend fun readFileContent(context: Context, uri: Uri): String = withContext(Dispatchers.IO) {
        try {
            val inputStream = context.contentResolver.openInputStream(uri) ?: return@withContext ""
            val reader = inputStream.bufferedReader()
            val sb = StringBuilder()
            var lines = 0
            // Read up to 2500 lines to keep reasonable token budget
            while (reader.ready() && lines < 2500) {
                val line = reader.readLine() ?: break
                sb.appendLine(line)
                lines++
            }
            reader.close()
            sb.toString()
        } catch (e: Exception) {
            "Dosya okunamadı: ${e.message}"
        }
    }

    /**
     * Extracts filename from URI
     */
    fun getFileName(context: Context, uri: Uri): String {
        var name = "dosya"
        try {
            val cursor = context.contentResolver.query(uri, null, null, null, null)
            cursor?.use {
                if (it.moveToFirst()) {
                    val nameIndex = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (nameIndex != -1) {
                        name = it.getString(nameIndex) ?: name
                    }
                }
            }
        } catch (e: Exception) {
            name = uri.lastPathSegment ?: "dosya"
        }
        return name
    }

    /**
     * Saves byte array image to external gallery/pictures
     */
    suspend fun saveImageToGallery(context: Context, imageBytes: ByteArray, prefix: String = "SuesaAI"): Uri? = withContext(Dispatchers.IO) {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val fileName = "${prefix}_${timeStamp}.jpg"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/SuesaAI")
            }
            val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                context.contentResolver.openOutputStream(uri)?.use { stream ->
                    stream.write(imageBytes)
                }
                return@withContext uri
            }
        } else {
            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
            val subDir = File(dir, "SuesaAI").apply { if (!exists()) mkdirs() }
            val file = File(subDir, fileName)
            FileOutputStream(file).use { stream ->
                stream.write(imageBytes)
            }
            return@withContext Uri.fromFile(file)
        }
        null
    }

    /**
     * Share text via Android intent
     */
    fun shareText(context: Context, text: String, title: String = "Suesa AI Mesajı") {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        context.startActivity(Intent.createChooser(intent, title))
    }

    /**
     * Share image URI via Android intent
     */
    fun shareImage(context: Context, imageUri: Uri) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/*"
            putExtra(Intent.EXTRA_STREAM, imageUri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Görseli Paylaş"))
    }
}
