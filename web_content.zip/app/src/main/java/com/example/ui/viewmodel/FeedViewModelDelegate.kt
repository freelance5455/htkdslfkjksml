package com.example.ui.viewmodel

import android.content.Context
import com.example.data.model.ArkFeedIds
import com.example.data.model.ArkGroup
import com.example.data.model.ArkPost
import com.example.data.model.ArkStory
import com.example.data.model.BlockedUser
import com.example.data.model.FollowEdge
import com.example.data.model.FriendEdge
import com.example.data.model.PostComment
import com.example.data.model.PostDraft
import com.example.data.model.PostReaction
import com.example.data.model.StoryReaction
import com.example.data.model.StoryViewer
import com.example.data.model.UserProfile
import com.example.data.repository.FeedRepository
import com.example.data.repository.GroupRepository
import com.example.data.repository.StoryRepository
import com.example.data.repository.UserRepository
import com.google.firebase.firestore.DocumentSnapshot
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalCoroutinesApi::class)
class FeedViewModelDelegate(
    private val currentUserId: String,
    private val scope: CoroutineScope,
    private val feedRepo: FeedRepository,
    private val storyRepo: StoryRepository,
    private val userRepo: UserRepository,
    private val groupRepo: GroupRepository,
    private val blockedUsersFlow: StateFlow<UiState<List<BlockedUser>>>,
    private val followersFlow: StateFlow<List<FollowEdge>> = MutableStateFlow(emptyList()),
    private val postMessage: (String) -> Unit
) {
    private val _mutedUids = feedRepo.observeMutedUsers(currentUserId)
        .map { list -> list.map { it.mutedUid }.toSet() }
        .catch { emit(emptySet()) }
        .stateIn(scope, SharingStarted.WhileSubscribed(5000L), emptySet())

    private val _hiddenPostIds = feedRepo.observeHiddenPosts(currentUserId)
        .map { list -> list.map { it.postId }.toSet() }
        .catch { emit(emptySet()) }
        .stateIn(scope, SharingStarted.WhileSubscribed(5000L), emptySet())

    private val _latestHomePosts = feedRepo.observeLatestHomePosts(currentUserId, limitCount = 15L)
        .catch { emit(emptyList()) }
        .stateIn(scope, SharingStarted.WhileSubscribed(5000L), emptyList())

    private val _paginatedFeedPosts = MutableStateFlow<List<ArkPost>>(emptyList())
    private var lastFeedDoc: DocumentSnapshot? = null

    private val _isFeedLoading = MutableStateFlow(false)
    val isFeedLoading = _isFeedLoading.asStateFlow()

    private val _isLoadingMoreFeed = MutableStateFlow(false)
    val isLoadingMoreFeed = _isLoadingMoreFeed.asStateFlow()

    private val _hasMoreFeed = MutableStateFlow(true)
    val hasMoreFeed = _hasMoreFeed.asStateFlow()

    private val _rawExplorePosts = MutableStateFlow<List<ArkPost>>(emptyList())
    private var lastExploreDoc: DocumentSnapshot? = null

    private val _exploreCategory = MutableStateFlow("All")
    val exploreCategory = _exploreCategory.asStateFlow()

    private val _isExploreLoading = MutableStateFlow(false)
    val isExploreLoading = _isExploreLoading.asStateFlow()

    private val _hasMoreExplore = MutableStateFlow(true)
    val hasMoreExplore = _hasMoreExplore.asStateFlow()

    private val _isPublishingPost = MutableStateFlow(false)
    val isPublishingPost = _isPublishingPost.asStateFlow()

    val bookmarkedIds: StateFlow<Set<String>> = feedRepo.observeBookmarks(currentUserId)
        .map { list -> list.map { it.postId }.toSet() }
        .catch { emit(emptySet()) }
        .stateIn(scope, SharingStarted.WhileSubscribed(5000L), emptySet())

    private val _savedPosts = MutableStateFlow<List<ArkPost>>(emptyList())
    val savedPosts = _savedPosts.asStateFlow()

    val drafts: StateFlow<List<PostDraft>> = feedRepo.observeDrafts(currentUserId)
        .catch { emit(emptyList()) }
        .stateIn(scope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val myPosts: StateFlow<List<ArkPost>> = feedRepo.observeUserPosts(currentUserId, limitCount = 40L)
        .catch { emit(emptyList()) }
        .stateIn(scope, SharingStarted.WhileSubscribed(5000L), emptyList())

    private val _myReactions = MutableStateFlow<Map<String, String>>(emptyMap())
    val myReactions = _myReactions.asStateFlow()

    private val _myPollVotes = MutableStateFlow<Map<String, Int>>(emptyMap())
    val myPollVotes = _myPollVotes.asStateFlow()

    val feedPosts: StateFlow<List<ArkPost>> = combine(
        _latestHomePosts,
        _paginatedFeedPosts,
        blockedUsersFlow,
        _mutedUids,
        _hiddenPostIds
    ) { live, paged, blockedState, muted, hidden ->
        val blockedSet = (blockedState as? UiState.Success)?.data?.map { it.blockedUid }?.toSet() ?: emptySet()
        val merged = linkedMapOf<String, ArkPost>()
        live.forEach { merged[it.id] = it }
        paged.forEach { if (!merged.containsKey(it.id)) merged[it.id] = it }
        merged.values.filter { post ->
            !hidden.contains(post.id) &&
                !muted.contains(post.authorId) &&
                !blockedSet.contains(post.authorId)
        }
    }.stateIn(scope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val explorePosts: StateFlow<List<ArkPost>> = combine(
        _rawExplorePosts,
        _exploreCategory,
        blockedUsersFlow,
        _mutedUids,
        _hiddenPostIds
    ) { raw, cat, blockedState, muted, hidden ->
        val blockedSet = (blockedState as? UiState.Success)?.data?.map { it.blockedUid }?.toSet() ?: emptySet()
        raw.filter { post ->
            !hidden.contains(post.id) &&
                !muted.contains(post.authorId) &&
                !blockedSet.contains(post.authorId) &&
                (cat == "All" || post.category == cat)
        }.sortedByDescending { it.likeCount * 2L + it.commentCount + it.shareCount }
    }.stateIn(scope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val stories: StateFlow<List<ArkStory>> = combine(
        storyRepo.observeActiveStories(currentUserId).catch { emit(emptyList()) },
        blockedUsersFlow,
        _mutedUids
    ) { list, blockedState, muted ->
        val blockedSet = (blockedState as? UiState.Success)?.data?.map { it.blockedUid }?.toSet() ?: emptySet()
        list.filter { st -> !blockedSet.contains(st.authorId) && !muted.contains(st.authorId) }
    }.stateIn(scope, SharingStarted.WhileSubscribed(5000L), emptyList())

    private val _viewedStoryIds = MutableStateFlow<Set<String>>(emptySet())
    val viewedStoryIds = _viewedStoryIds.asStateFlow()

    private val _selectedStoryIdForViewers = MutableStateFlow<String?>(null)
    val activeStoryViewers: StateFlow<List<StoryViewer>> = _selectedStoryIdForViewers.flatMapLatest { sid ->
        if (sid == null) flowOf(emptyList()) else storyRepo.observeStoryViewers(sid)
    }.catch { emit(emptyList()) }
        .stateIn(scope, SharingStarted.WhileSubscribed(5000L), emptyList())

    private val _activeStoryIdForReactions = MutableStateFlow<String?>(null)
    val activeStoryReactions: StateFlow<List<StoryReaction>> = _activeStoryIdForReactions.flatMapLatest { sid ->
        if (sid == null) flowOf(emptyList()) else storyRepo.observeStoryReactions(sid)
    }.catch { emit(emptyList()) }
        .stateIn(scope, SharingStarted.WhileSubscribed(5000L), emptyList())

    private val _commentsPost = MutableStateFlow<ArkPost?>(null)
    val commentsPost = _commentsPost.asStateFlow()

    val activeComments: StateFlow<List<PostComment>> = _commentsPost.flatMapLatest { post ->
        if (post == null) flowOf(emptyList()) else feedRepo.observeComments(post.id)
    }.catch { emit(emptyList()) }
        .stateIn(scope, SharingStarted.WhileSubscribed(5000L), emptyList())

    private val checkedMetaPostIds = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()

    init {
        refreshFeed()
        refreshExplore()
        scope.launch {
            bookmarkedIds.collect { ids ->
                if (ids.isEmpty()) {
                    _savedPosts.value = emptyList()
                } else {
                    _savedPosts.value = feedRepo.fetchPostsByIds(ids.toList())
                }
            }
        }
        scope.launch {
            feedPosts.collect { list ->
                syncUserMetadataForPosts(list.take(15))
            }
        }
    }

    private fun syncUserMetadataForPosts(posts: List<ArkPost>) {
        if (posts.isEmpty()) return
        val unchecked = posts.filter { checkedMetaPostIds.add(it.id) }
        if (unchecked.isEmpty()) return

        scope.launch {
            val reactionResults = coroutineScope {
                unchecked.map { p ->
                    async { p.id to feedRepo.getMyReaction(p.id) }
                }.awaitAll()
            }
            val pollResults = coroutineScope {
                unchecked.filter { it.postType == "poll" }.map { p ->
                    async { p.id to feedRepo.getMyPollVote(p.id) }
                }.awaitAll()
            }

            val reactUpdates = _myReactions.value.toMutableMap()
            val voteUpdates = _myPollVotes.value.toMutableMap()
            var reactChanged = false
            var voteChanged = false

            reactionResults.forEach { (id, r) ->
                if (r != null && reactUpdates[id] != r) {
                    reactUpdates[id] = r
                    reactChanged = true
                }
            }
            pollResults.forEach { (id, v) ->
                if (v != null && voteUpdates[id] != v) {
                    voteUpdates[id] = v
                    voteChanged = true
                }
            }
            if (reactChanged) _myReactions.value = reactUpdates
            if (voteChanged) _myPollVotes.value = voteUpdates
        }
    }

    fun refreshFeed() {
        if (_isFeedLoading.value) return
        scope.launch {
            _isFeedLoading.value = true
            lastFeedDoc = null
            feedRepo.fetchFeedPage(currentUserId, pageSize = 10L, lastDocument = null)
                .onSuccess { page ->
                    _paginatedFeedPosts.value = page.posts
                    lastFeedDoc = page.lastDocument
                    _hasMoreFeed.value = page.hasMore
                    syncUserMetadataForPosts(page.posts)
                }
            _isFeedLoading.value = false
        }
    }

    fun loadMoreFeed() {
        if (_isLoadingMoreFeed.value || !_hasMoreFeed.value || lastFeedDoc == null) return
        scope.launch {
            _isLoadingMoreFeed.value = true
            feedRepo.fetchFeedPage(currentUserId, pageSize = 10L, lastDocument = lastFeedDoc)
                .onSuccess { page ->
                    val combined = (_paginatedFeedPosts.value + page.posts).distinctBy { it.id }
                    _paginatedFeedPosts.value = combined
                    lastFeedDoc = page.lastDocument
                    _hasMoreFeed.value = page.hasMore
                    syncUserMetadataForPosts(page.posts)
                }
            _isLoadingMoreFeed.value = false
        }
    }

    fun setExploreCategory(cat: String) {
        _exploreCategory.value = cat
    }

    fun refreshExplore() {
        if (_isExploreLoading.value) return
        scope.launch {
            _isExploreLoading.value = true
            lastExploreDoc = null
            feedRepo.fetchExplorePage(pageSize = 15L, lastDocument = null)
                .onSuccess { page ->
                    _rawExplorePosts.value = page.posts
                    lastExploreDoc = page.lastDocument
                    _hasMoreExplore.value = page.hasMore
                    syncUserMetadataForPosts(page.posts)
                }
            _isExploreLoading.value = false
        }
    }

    fun loadMoreExplore() {
        if (_isExploreLoading.value || !_hasMoreExplore.value || lastExploreDoc == null) return
        scope.launch {
            _isExploreLoading.value = true
            feedRepo.fetchExplorePage(pageSize = 15L, lastDocument = lastExploreDoc)
                .onSuccess { page ->
                    _rawExplorePosts.value = (_rawExplorePosts.value + page.posts).distinctBy { it.id }
                    lastExploreDoc = page.lastDocument
                    _hasMoreExplore.value = page.hasMore
                }
            _isExploreLoading.value = false
        }
    }

    fun createPost(
        author: UserProfile,
        postType: String,
        category: String,
        caption: String,
        imageBase64List: List<String>,
        visibility: String,
        friends: List<FriendEdge>,
        selectedGroups: List<ArkGroup>,
        locationLabel: String? = null,
        altTexts: List<String> = emptyList(),
        taggedUids: List<String> = emptyList(),
        pollQuestion: String? = null,
        pollOptions: List<String>? = null,
        videoThumbnailBase64: String? = null,
        videoDurationMs: Long = 0L,
        videoChunksBase64: List<String> = emptyList(),
        metaGameName: String? = null,
        metaScoreLabel: String? = null,
        metaWinner: String? = null,
        metaBadge: String? = null,
        draftIdToDelete: String? = null,
        onPublished: () -> Unit = {}
    ) {
        if (_isPublishingPost.value) return
        scope.launch {
            _isPublishingPost.value = true
            try {
                feedRepo.createPost(
                    author = author,
                    postType = postType,
                    category = category,
                    caption = caption,
                    imageBase64List = imageBase64List,
                    visibility = visibility,
                    friends = friends,
                    selectedGroups = selectedGroups,
                    followers = followersFlow.value,
                    locationLabel = locationLabel,
                    altTexts = altTexts,
                    taggedUids = taggedUids,
                    pollQuestion = pollQuestion,
                    pollOptions = pollOptions,
                    videoThumbnailBase64 = videoThumbnailBase64,
                    videoDurationMs = videoDurationMs,
                    videoChunksBase64 = videoChunksBase64,
                    metaGameName = metaGameName,
                    metaScoreLabel = metaScoreLabel,
                    metaWinner = metaWinner,
                    metaBadge = metaBadge
                ).onSuccess {
                    if (!draftIdToDelete.isNullOrBlank()) {
                        feedRepo.deleteDraft(draftIdToDelete)
                    }
                    refreshFeed()
                    if (visibility == "public") refreshExplore()
                    postMessage("Posted to ARK Feed!")
                    onPublished()
                }.onFailure {
                    postMessage(it.message ?: "Failed to publish post.")
                }
            } finally {
                _isPublishingPost.value = false
            }
        }
    }

    fun updatePostCaption(postId: String, newCaption: String) {
        scope.launch {
            feedRepo.updatePostCaption(postId, newCaption)
                .onSuccess {
                    val clean = newCaption.trim()
                    val tags = ArkFeedIds.extractHashtags(clean)
                    _paginatedFeedPosts.value = _paginatedFeedPosts.value.map {
                        if (it.id == postId) it.copy(caption = clean, hashtags = tags) else it
                    }
                    postMessage("Post updated.")
                }
                .onFailure { postMessage(it.message ?: "Could not edit post.") }
        }
    }

    fun toggleCommentsDisabled(postId: String, disabled: Boolean) {
        scope.launch {
            feedRepo.toggleCommentsDisabled(postId, disabled)
                .onSuccess {
                    _paginatedFeedPosts.value = _paginatedFeedPosts.value.map {
                        if (it.id == postId) it.copy(commentsDisabled = disabled) else it
                    }
                    if (_commentsPost.value?.id == postId) {
                        _commentsPost.value = _commentsPost.value?.copy(commentsDisabled = disabled)
                    }
                    postMessage(if (disabled) "Comments turned off." else "Comments enabled.")
                }
        }
    }

    fun deletePost(postId: String) {
        scope.launch {
            feedRepo.deletePost(postId)
                .onSuccess {
                    _paginatedFeedPosts.value = _paginatedFeedPosts.value.filterNot { it.id == postId }
                    _rawExplorePosts.value = _rawExplorePosts.value.filterNot { it.id == postId }
                    postMessage("Post deleted.")
                }
                .onFailure { postMessage(it.message ?: "Failed to delete post.") }
        }
    }

    fun toggleReaction(post: ArkPost, currentUser: UserProfile, reactionKey: String) {
        scope.launch {
            val prev = _myReactions.value[post.id]
            feedRepo.toggleReaction(post.id, currentUser.username, reactionKey)
                .onSuccess { newReact ->
                    val nextMap = _myReactions.value.toMutableMap()
                    if (newReact == null) nextMap.remove(post.id) else nextMap[post.id] = newReact
                    _myReactions.value = nextMap

                    if (newReact != null && prev == null && post.authorId != currentUser.userId) {
                        userRepo.sendNotification(
                            recipientUid = post.authorId,
                            senderUsername = currentUser.username,
                            type = "post_like",
                            title = "${ArkFeedIds.reactionEmoji(newReact)} New Reaction",
                            body = "@${currentUser.username} reacted to your ARK post",
                            refId = post.id
                        )
                    }
                }
                .onFailure { postMessage(it.message ?: "Reaction failed.") }
        }
    }

    fun votePoll(postId: String, optionIndex: Int) {
        scope.launch {
            feedRepo.votePoll(postId, optionIndex)
                .onSuccess {
                    _myPollVotes.value = _myPollVotes.value + (postId to optionIndex)
                    refreshFeed()
                }
                .onFailure { postMessage(it.message ?: "Unable to submit vote.") }
        }
    }

    fun toggleBookmark(postId: String) {
        scope.launch {
            feedRepo.toggleBookmark(postId)
                .onSuccess { saved -> postMessage(if (saved) "Saved to Bookmarks." else "Removed from Saved.") }
                .onFailure { postMessage(it.message ?: "Bookmark failed.") }
        }
    }

    fun openComments(post: ArkPost) {
        _commentsPost.value = post
    }

    fun closeComments() {
        _commentsPost.value = null
    }

    fun addComment(
        post: ArkPost,
        author: UserProfile,
        text: String,
        parentCommentId: String? = null,
        replyToUsername: String? = null
    ) {
        scope.launch {
            feedRepo.addComment(post, author, text, parentCommentId, replyToUsername)
                .onSuccess {
                    if (post.authorId != author.userId) {
                        userRepo.sendNotification(
                            recipientUid = post.authorId,
                            senderUsername = author.username,
                            type = "post_comment",
                            title = "New Comment",
                            body = "@${author.username}: ${text.trim().take(80)}",
                            refId = post.id
                        )
                    }
                }
                .onFailure { postMessage(it.message ?: "Could not add comment.") }
        }
    }

    suspend fun fetchLikers(postId: String): List<PostReaction> =
        feedRepo.fetchLikers(postId)

    fun toggleCommentLike(postId: String, commentId: String) {
        scope.launch { feedRepo.toggleCommentLike(postId, commentId) }
    }

    fun updateComment(postId: String, commentId: String, newText: String) {
        scope.launch {
            feedRepo.updateComment(postId, commentId, newText)
                .onSuccess { postMessage("Comment updated.") }
                .onFailure { postMessage(it.message ?: "Could not edit comment.") }
        }
    }

    fun deleteComment(postId: String, commentId: String) {
        scope.launch {
            feedRepo.deleteComment(postId, commentId)
                .onSuccess { postMessage("Comment deleted.") }
        }
    }

    fun sharePostToFriend(post: ArkPost, sender: UserProfile, friend: FriendEdge) {
        if (post.visibility != "public" && !post.visibleToUids.contains(friend.friendUid)) {
            postMessage("Private post cannot be shared outside its original audience.")
            return
        }
        scope.launch {
            userRepo.sendNotification(
                recipientUid = friend.friendUid,
                senderUsername = sender.username,
                type = "post_share",
                title = "Post Shared With You",
                body = "@${sender.username} shared @${post.authorUsername}'s post: ${post.caption.take(60)}",
                refId = post.id
            )
            feedRepo.incrementShareCount(post.id)
            postMessage("Shared with @${friend.friendUsername}!")
        }
    }

    fun sharePostToGroup(post: ArkPost, sender: UserProfile, group: ArkGroup) {
        val allowed = post.visibility == "public" || post.groupIds.contains(group.id)
        if (!allowed) {
            postMessage("Private post cannot bypass original group/friends permissions.")
            return
        }
        scope.launch {
            val preview = "Shared Post by @${post.authorUsername}: ${post.caption.ifBlank { post.postType }.take(140)}"
            groupRepo.sendMessage(group = group, sender = sender, text = preview)
                .onSuccess {
                    feedRepo.incrementShareCount(post.id)
                    postMessage("Shared inside ${group.name}!")
                }
                .onFailure { postMessage(it.message ?: "Could not share to group.") }
        }
    }

    fun recordExternalShare(post: ArkPost) {
        if (post.visibility != "public") return
        scope.launch { feedRepo.incrementShareCount(post.id) }
    }

    fun saveDraft(
        draftId: String?,
        postType: String,
        category: String,
        caption: String,
        imageBase64List: List<String>,
        visibility: String,
        pollQuestion: String,
        pollOptions: List<String>,
        locationLabel: String = "",
        altTexts: List<String> = emptyList(),
        onSaved: () -> Unit = {}
    ) {
        scope.launch {
            feedRepo.saveDraft(
                draftId = draftId,
                postType = postType,
                category = category,
                caption = caption,
                imageBase64List = imageBase64List,
                visibility = visibility,
                pollQuestion = pollQuestion,
                pollOptions = pollOptions,
                locationLabel = locationLabel,
                altTexts = altTexts
            ).onSuccess {
                postMessage("Draft saved.")
                onSaved()
            }.onFailure { postMessage(it.message ?: "Could not save draft.") }
        }
    }

    fun deleteDraft(draftId: String) {
        scope.launch {
            feedRepo.deleteDraft(draftId)
                .onSuccess { postMessage("Draft deleted.") }
        }
    }

    fun muteUser(mutedUid: String, username: String) {
        scope.launch {
            feedRepo.muteUser(mutedUid)
                .onSuccess { postMessage("Muted @$username's posts.") }
        }
    }

    fun hidePost(postId: String) {
        scope.launch {
            feedRepo.hidePost(postId)
                .onSuccess { postMessage("Post hidden from your feed.") }
        }
    }

    fun createStory(
        author: UserProfile,
        mediaType: String,
        imageBase64: String,
        caption: String,
        visibility: String,
        friends: List<FriendEdge>,
        selectedGroups: List<ArkGroup>,
        hiddenFromUids: List<String> = author.hiddenStoryFromUids,
        videoDurationMs: Long = 0L,
        videoChunksBase64: List<String> = emptyList(),
        onPublished: () -> Unit = {}
    ) {
        scope.launch {
            if (videoChunksBase64.isNotEmpty()) {
                postMessage("Uploading video story...")
            }
            storyRepo.createStory(
                author = author,
                mediaType = mediaType,
                imageBase64 = imageBase64,
                caption = caption,
                visibility = visibility,
                friends = friends,
                selectedGroups = selectedGroups,
                followers = followersFlow.value,
                hiddenFromUids = hiddenFromUids,
                videoDurationMs = videoDurationMs,
                videoChunksBase64 = videoChunksBase64
            ).onSuccess {
                postMessage("Story live for 24 hours!")
                onPublished()
            }.onFailure { postMessage(it.message ?: "Failed to upload story.") }
        }
    }

    fun markStoryViewed(story: ArkStory, viewer: UserProfile) {
        _viewedStoryIds.value = _viewedStoryIds.value + story.id
        _activeStoryIdForReactions.value = story.id
        if (story.authorId == viewer.userId) {
            _selectedStoryIdForViewers.value = story.id
        } else {
            _selectedStoryIdForViewers.value = null
            scope.launch { storyRepo.markStoryViewed(story, viewer) }
        }
    }

    fun reactToStory(story: ArkStory, currentUser: UserProfile, reactionKey: String) {
        scope.launch {
            storyRepo.reactToStory(story.id, currentUser.username, reactionKey)
                .onSuccess { key ->
                    if (story.authorId != currentUser.userId) {
                        userRepo.sendNotification(
                            recipientUid = story.authorId,
                            senderUsername = currentUser.username,
                            type = "story_reaction",
                            title = "${ArkFeedIds.reactionEmoji(key)} Story Reaction",
                            body = "@${currentUser.username} reacted to your ARK story",
                            refId = story.id
                        )
                    }
                }
                .onFailure { postMessage(it.message ?: "Reaction failed.") }
        }
    }

    fun deleteStory(storyId: String, onDeleted: () -> Unit = {}) {
        scope.launch {
            storyRepo.deleteStory(storyId)
                .onSuccess {
                    postMessage("Story deleted.")
                    onDeleted()
                }
                .onFailure { postMessage(it.message ?: "Could not delete story.") }
        }
    }

    suspend fun loadPostVideoFile(context: Context, postId: String): File? =
        feedRepo.fetchPostVideoFile(context, postId)

    suspend fun loadStoryVideoFile(context: Context, storyId: String): File? =
        storyRepo.fetchStoryVideoFile(context, storyId)
}
