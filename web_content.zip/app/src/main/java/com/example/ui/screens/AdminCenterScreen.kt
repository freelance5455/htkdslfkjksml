package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Dataset
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.model.JobListing
import com.example.model.ModerationReport
import com.example.model.PaymentTransaction
import com.example.model.SideQuest
import com.example.model.SubscriptionPlan
import com.example.model.UserProfile
import com.example.ui.components.BarMetricChart
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.StatusPill
import com.example.ui.components.formatInr

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdminCenterScreen(
  allUsers: List<UserProfile>,
  allJobs: List<JobListing>,
  allQuests: List<SideQuest>,
  allReports: List<ModerationReport>,
  plans: List<SubscriptionPlan>,
  transactions: List<PaymentTransaction>,
  isBusy: Boolean,
  onBack: (() -> Unit)? = null,
  onSeedMarketplace: () -> Unit,
  onModerateJob: (String, String) -> Unit,
  onModerateQuest: (String, String) -> Unit,
  onVerifyCompany: (String, Boolean) -> Unit,
  onSetUserStatus: (String, String) -> Unit,
  onResolveReport: (String, String, String) -> Unit,
  onSavePlan: (SubscriptionPlan) -> Unit
) {
  var selectedSection by remember { mutableStateOf("OVERVIEW") }
  var editingPlan by remember { mutableStateOf<SubscriptionPlan?>(null) }

  val pendingJobs = remember(allJobs) { allJobs.filter { it.moderationStatus == "PENDING" } }
  val pendingQuests = remember(allQuests) { allQuests.filter { it.moderationStatus == "PENDING" } }
  val openReports = remember(allReports) { allReports.filter { it.status == "OPEN" } }
  val totalRevenue = remember(transactions) { transactions.filter { it.status == "COMPLETED" }.sumOf { it.amountInr } }

  LazyColumn(
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
    modifier = Modifier.fillMaxSize()
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          if (onBack != null) {
            IconButton(onClick = onBack) {
              Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
          }
          Icon(Icons.Filled.AdminPanelSettings, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
          Spacer(modifier = Modifier.width(8.dp))
          Text("Admin Control Center", style = MaterialTheme.typography.titleLarge)
        }
      }

      Spacer(modifier = Modifier.height(10.dp))
      FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(selected = selectedSection == "OVERVIEW", onClick = { selectedSection = "OVERVIEW" }, label = { Text("Overview") })
        FilterChip(
          selected = selectedSection == "MODERATION",
          onClick = { selectedSection = "MODERATION" },
          label = { Text("Moderation (${pendingJobs.size + pendingQuests.size + openReports.size})") }
        )
        FilterChip(selected = selectedSection == "USERS", onClick = { selectedSection = "USERS" }, label = { Text("Users (${allUsers.size})") })
        FilterChip(selected = selectedSection == "PLANS", onClick = { selectedSection = "PLANS" }, label = { Text("Pricing & Revenue") })
      }
    }

    when (selectedSection) {
      "OVERVIEW" -> {
        item {
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            AdminStatCard("Users", allUsers.size.toString(), Modifier.weight(1f))
            AdminStatCard("Jobs", allJobs.size.toString(), Modifier.weight(1f))
            AdminStatCard("Quests", allQuests.size.toString(), Modifier.weight(1f))
            AdminStatCard("Revenue", formatInr(totalRevenue), Modifier.weight(1.2f))
          }
        }
        item {
          BarMetricChart(
            title = "Platform Health & Moderation",
            bars = listOf(
              Triple("Approved Jobs", allJobs.count { it.moderationStatus == "APPROVED" }, MaterialTheme.colorScheme.tertiary),
              Triple("Pending Jobs", pendingJobs.size, MaterialTheme.colorScheme.secondary),
              Triple("Approved Quests", allQuests.count { it.moderationStatus == "APPROVED" }, MaterialTheme.colorScheme.primary),
              Triple("Open Reports", openReports.size, MaterialTheme.colorScheme.error)
            )
          )
        }
        item {
          Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Text("Marketplace Data & Plan Bootstrap", style = MaterialTheme.typography.titleSmall)
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "Seeds approved sample jobs across Karnataka, Maharashtra, Tamil Nadu, Rajasthan & Delhi NCR, plus Side Quests and 3 configurable Subscription Plans.",
                style = MaterialTheme.typography.bodySmall
              )
              Spacer(modifier = Modifier.height(10.dp))
              Button(
                onClick = onSeedMarketplace,
                enabled = !isBusy,
                modifier = Modifier.fillMaxWidth().testTag("admin_seed_button")
              ) {
                Icon(Icons.Filled.Dataset, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (isBusy) "Seeding..." else "Seed Pan-India Sample Data")
              }
            }
          }
        }
      }

      "MODERATION" -> {
        if (pendingJobs.isEmpty() && pendingQuests.isEmpty() && openReports.isEmpty()) {
          item {
            EmptyStateCard(
              title = "Moderation queue is clear",
              subtitle = "All jobs, Side Quests, and safety reports have been reviewed."
            )
          }
        }
        if (pendingJobs.isNotEmpty()) {
          item { Text("Pending Jobs (${pendingJobs.size})", style = MaterialTheme.typography.titleMedium) }
          items(pendingJobs, key = { "mod_job_${it.id}" }) { job ->
            ModerationItemCard(
              title = job.title,
              subtitle = "${job.companyName} · ${job.city}, ${job.state} · ₹0 Fee",
              onApprove = { onModerateJob(job.id, "APPROVED") },
              onReject = { onModerateJob(job.id, "REJECTED") }
            )
          }
        }
        if (pendingQuests.isNotEmpty()) {
          item { Text("Pending Side Quests (${pendingQuests.size})", style = MaterialTheme.typography.titleMedium) }
          items(pendingQuests, key = { "mod_sq_${it.id}" }) { q ->
            ModerationItemCard(
              title = q.title,
              subtitle = "${q.posterName} · ${formatInr(q.payoutInr)} · ${q.estimatedMinutes} mins",
              onApprove = { onModerateQuest(q.id, "APPROVED") },
              onReject = { onModerateQuest(q.id, "REJECTED") }
            )
          }
        }
        if (openReports.isNotEmpty()) {
          item { Text("Open Safety Reports (${openReports.size})", style = MaterialTheme.typography.titleMedium) }
          items(openReports, key = { "rep_${it.id}" }) { rep ->
            Card(
              shape = RoundedCornerShape(16.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.45f)),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                Text("${rep.targetType}: ${rep.targetTitle}", style = MaterialTheme.typography.titleSmall)
                Text("Reason: ${rep.reason}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                Spacer(modifier = Modifier.height(4.dp))
                Text(rep.details, style = MaterialTheme.typography.bodySmall)
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  Button(onClick = { onResolveReport(rep.id, "RESOLVED", "Action taken by JOBY Admin") }) {
                    Text("Resolve")
                  }
                  OutlinedButton(onClick = { onResolveReport(rep.id, "DISMISSED", "No policy violation found") }) {
                    Text("Dismiss")
                  }
                }
              }
            }
          }
        }
      }

      "USERS" -> {
        items(allUsers, key = { "usr_${it.userId}" }) { u ->
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(u.displayName, style = MaterialTheme.typography.titleSmall)
                  Text("${u.role} · ${u.city}, ${u.state} · Age ${u.age}", style = MaterialTheme.typography.bodySmall)
                  if (u.companyName.isNotBlank()) {
                    Text("Company: ${u.companyName}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                  }
                }
                StatusPill(
                  text = u.accountStatus,
                  containerColor = if (u.accountStatus == "ACTIVE") MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.errorContainer,
                  contentColor = if (u.accountStatus == "ACTIVE") MaterialTheme.colorScheme.onTertiaryContainer else MaterialTheme.colorScheme.onErrorContainer
                )
              }
              Spacer(modifier = Modifier.height(8.dp))
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (u.role == "EMPLOYER") {
                  OutlinedButton(onClick = { onVerifyCompany(u.userId, !u.companyVerified) }) {
                    Text(if (u.companyVerified) "Unverify Company" else "Verify Company")
                  }
                }
                val nextStatus = if (u.accountStatus == "ACTIVE") "SUSPENDED" else "ACTIVE"
                TextButton(onClick = { onSetUserStatus(u.userId, nextStatus) }) {
                  Text(if (nextStatus == "SUSPENDED") "Suspend" else "Activate", color = MaterialTheme.colorScheme.error)
                }
              }
            }
          }
        }
      }

      "PLANS" -> {
        item {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("Dynamic Subscription Pricing", style = MaterialTheme.typography.titleMedium)
            if (plans.isEmpty()) {
              TextButton(onClick = onSeedMarketplace) { Text("Initialize Default Plans") }
            }
          }
        }
        items(plans, key = { it.code }) { plan ->
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.fillMaxWidth().padding(14.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text("${plan.name} (${plan.code})", style = MaterialTheme.typography.titleSmall)
                Text(
                  text = "${formatInr(plan.priceInr)} / ${plan.billingCycle} · ${plan.maxActiveJobs} jobs",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.primary
                )
              }
              IconButton(onClick = { editingPlan = plan }) {
                Icon(Icons.Filled.Edit, contentDescription = "Edit Plan Price")
              }
            }
          }
        }

        item {
          Spacer(modifier = Modifier.height(6.dp))
          Text("Recent Transactions (${transactions.size})", style = MaterialTheme.typography.titleMedium)
        }
        items(transactions.take(10), key = { "adm_txn_${it.id}" }) { txn ->
          Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.fillMaxWidth().padding(12.dp),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(txn.title, style = MaterialTheme.typography.labelMedium)
                Text("${txn.userName} · ${txn.invoiceNumber}", style = MaterialTheme.typography.labelSmall)
              }
              Text(formatInr(txn.amountInr), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }
  }

  if (editingPlan != null) {
    val plan = editingPlan!!
    var name by remember(plan) { mutableStateOf(plan.name) }
    var price by remember(plan) { mutableStateOf(plan.priceInr.toString()) }
    var maxJobs by remember(plan) { mutableStateOf(plan.maxActiveJobs.toString()) }

    AlertDialog(
      onDismissRequest = { editingPlan = null },
      title = { Text("Edit ${plan.code} Pricing") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Plan Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
          OutlinedTextField(
            value = price,
            onValueChange = { price = it.filter { c -> c.isDigit() } },
            label = { Text("Price (INR)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = maxJobs,
            onValueChange = { maxJobs = it.filter { c -> c.isDigit() } },
            label = { Text("Max Active Jobs") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(onClick = {
          onSavePlan(
            plan.copy(
              name = name.trim().ifBlank { plan.name },
              priceInr = price.toLongOrNull() ?: plan.priceInr,
              maxActiveJobs = (maxJobs.toLongOrNull() ?: plan.maxActiveJobs).coerceAtLeast(1L)
            )
          )
          editingPlan = null
        }) { Text("Save") }
      },
      dismissButton = { TextButton(onClick = { editingPlan = null }) { Text("Cancel") } }
    )
  }
}

@Composable
private fun AdminStatCard(label: String, value: String, modifier: Modifier = Modifier) {
  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    modifier = modifier
  ) {
    Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
      Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
      Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
  }
}

@Composable
private fun ModerationItemCard(
  title: String,
  subtitle: String,
  onApprove: () -> Unit,
  onReject: () -> Unit
) {
  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Text(title, style = MaterialTheme.typography.titleSmall)
      Spacer(modifier = Modifier.height(2.dp))
      Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
      Spacer(modifier = Modifier.height(10.dp))
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(
          onClick = onApprove,
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary)
        ) {
          Icon(Icons.Filled.Check, contentDescription = null)
          Spacer(modifier = Modifier.width(4.dp))
          Text("Approve")
        }
        OutlinedButton(onClick = onReject) {
          Icon(Icons.Filled.Close, contentDescription = null)
          Spacer(modifier = Modifier.width(4.dp))
          Text("Reject")
        }
      }
    }
  }
}
