package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.AetherTheme
import com.example.ui.theme.InterFamily

@Composable
fun TactileKey(
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  backgroundColor: Color = AetherTheme.colors.surface,
  pressedColor: Color = AetherTheme.colors.surfaceElevated,
  borderColor: Color = AetherTheme.colors.borderSubtle,
  shape: Shape = RoundedCornerShape(16.dp),
  hapticsEnabled: Boolean = true,
  testTag: String? = null,
  content: @Composable () -> Unit,
) {
  val interactionSource = remember { MutableInteractionSource() }
  val isPressed by interactionSource.collectIsPressedAsState()
  val haptics = LocalHapticFeedback.current

  val scale by
    animateFloatAsState(
      targetValue = if (isPressed) 0.955f else 1f,
      animationSpec =
        if (isPressed) snap() else tween(durationMillis = 55, easing = FastOutSlowInEasing),
      label = "key_scale",
    )

  val tagModifier = if (testTag != null) Modifier.testTag(testTag) else Modifier

  Box(
    contentAlignment = Alignment.Center,
    modifier =
      modifier
        .then(tagModifier)
        .minimumInteractiveComponentSize()
        .graphicsLayer {
          scaleX = scale
          scaleY = scale
        }
        .clip(shape)
        .drawBehind {
          drawRect(color = if (isPressed) pressedColor else backgroundColor)
        }
        .border(width = 1.dp, color = borderColor, shape = shape)
        .clickable(
          interactionSource = interactionSource,
          indication = ripple(bounded = true),
          onClick = {
            if (hapticsEnabled) {
              haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            }
            onClick()
          },
        ),
  ) {
    content()
  }
}

@Composable
fun AetherCard(
  modifier: Modifier = Modifier,
  backgroundColor: Color = AetherTheme.colors.surface,
  borderColor: Color = AetherTheme.colors.borderSubtle,
  contentPadding: PaddingValues = PaddingValues(16.dp),
  content: @Composable ColumnScope.() -> Unit,
) {
  Surface(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(16.dp),
    color = backgroundColor,
    border = BorderStroke(1.dp, borderColor),
    tonalElevation = 0.dp,
    shadowElevation = 0.dp,
  ) {
    Column(modifier = Modifier.padding(contentPadding), content = content)
  }
}

@Composable
fun AetherFilterChip(
  label: String,
  selected: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  hapticsEnabled: Boolean = true,
) {
  val colors = AetherTheme.colors
  val haptics = LocalHapticFeedback.current
  val bg = if (selected) colors.accent else colors.surfaceElevated
  val textColor = if (selected) Color(0xFFF1F0F5) else colors.textSecondary
  val border = if (selected) colors.accent else colors.borderSubtle

  Box(
    contentAlignment = Alignment.Center,
    modifier =
      modifier
        .heightIn(min = 36.dp)
        .clip(CircleShape)
        .background(bg, CircleShape)
        .border(1.dp, border, CircleShape)
        .clickable {
          if (hapticsEnabled) haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
          onClick()
        }
        .padding(horizontal = 14.dp, vertical = 8.dp),
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.labelMedium,
      color = textColor,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
    )
  }
}

@Composable
fun AetherNumberField(
  value: String,
  onValueChange: (String) -> Unit,
  label: String,
  modifier: Modifier = Modifier,
  placeholder: String = "0",
  allowNegative: Boolean = false,
  allowDecimal: Boolean = true,
  isListInput: Boolean = false,
) {
  val colors = AetherTheme.colors
  OutlinedTextField(
    value = value,
    onValueChange = { raw ->
      if (isListInput) {
        onValueChange(raw.filter { it.isDigit() || it == '.' || it == '-' || it == ',' || it == ' ' })
      } else {
        val filtered =
          raw.filter { ch ->
            ch.isDigit() || (allowDecimal && ch == '.') || (allowNegative && ch == '-')
          }
        onValueChange(filtered)
      }
    },
    label = { Text(label, style = MaterialTheme.typography.labelMedium) },
    placeholder = { Text(placeholder, color = colors.textSecondary) },
    singleLine = true,
    keyboardOptions =
      KeyboardOptions(
        keyboardType =
          if (isListInput) KeyboardType.Text
          else if (allowDecimal) KeyboardType.Decimal
          else KeyboardType.Number
      ),
    textStyle =
      TextStyle(
        fontFamily = InterFamily,
        fontSize = 16.sp,
        fontWeight = FontWeight.Medium,
        color = colors.textPrimary,
        fontFeatureSettings = "tnum",
      ),
    shape = RoundedCornerShape(16.dp),
    colors =
      OutlinedTextFieldDefaults.colors(
        focusedContainerColor = colors.surface,
        unfocusedContainerColor = colors.surface,
        focusedBorderColor = colors.accent,
        unfocusedBorderColor = colors.borderSubtle,
        focusedLabelColor = colors.lavender,
        unfocusedLabelColor = colors.textSecondary,
        cursorColor = colors.accent,
      ),
    modifier = modifier.fillMaxWidth().heightIn(min = 56.dp),
  )
}

@Composable
fun AetherResultRow(
  label: String,
  value: String,
  onCopy: (() -> Unit)? = null,
  highlight: Boolean = false,
  modifier: Modifier = Modifier,
) {
  val colors = AetherTheme.colors
  Row(
    modifier = modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.bodyMedium,
      color = colors.textSecondary,
      modifier = Modifier.weight(1f),
    )
    Spacer(modifier = Modifier.width(12.dp))
    Row(verticalAlignment = Alignment.CenterVertically) {
      Text(
        text = value,
        style =
          TextStyle(
            fontFamily = InterFamily,
            fontWeight = if (highlight) FontWeight.Bold else FontWeight.SemiBold,
            fontSize = if (highlight) 20.sp else 16.sp,
            color = if (highlight) colors.lavender else colors.textPrimary,
            fontFeatureSettings = "tnum",
          ),
      )
      if (onCopy != null) {
        IconButton(
          onClick = onCopy,
          modifier = Modifier.size(40.dp),
        ) {
          Icon(
            imageVector = Icons.Outlined.ContentCopy,
            contentDescription = stringResource(R.string.cd_copy_result),
            tint = colors.textSecondary,
            modifier = Modifier.size(18.dp),
          )
        }
      }
    }
  }
}
