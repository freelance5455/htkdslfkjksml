package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import com.example.audio.AudioSpectrumData
import com.example.model.VisualizerCategory
import com.example.model.VisualizerItem
import com.example.model.VisualizerRegistry
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun VisualizerCanvas(
    visualizerId: Int,
    spectrumData: AudioSpectrumData,
    modifier: Modifier = Modifier
) {
    val visualizerItem = remember(visualizerId) {
        VisualizerRegistry.ALL_150_VISUALIZERS.getOrNull(visualizerId - 1)
            ?: VisualizerRegistry.ALL_150_VISUALIZERS.first()
    }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .testTag("visualizer_canvas")
    ) {
        val width = size.width
        val height = size.height
        if (width <= 0 || height <= 0) return@Canvas

        val theme = visualizerItem.defaultTheme
        val primary = theme.primary
        val secondary = theme.secondary
        val glow = theme.glow

        val variantIndex = (visualizerItem.id - 1) % 15

        when (visualizerItem.category) {
            VisualizerCategory.SPECTRUM_BARS -> {
                drawSpectrumBars(variantIndex, spectrumData, primary, secondary, glow)
            }
            VisualizerCategory.OSCILLOSCOPES -> {
                drawOscilloscopes(variantIndex, spectrumData, primary, secondary, glow)
            }
            VisualizerCategory.CIRCULAR_RADIAL -> {
                drawCircularRadial(variantIndex, spectrumData, primary, secondary, glow)
            }
            VisualizerCategory.PARTICLE_VORTEX -> {
                drawParticleVortex(variantIndex, spectrumData, primary, secondary, glow)
            }
            VisualizerCategory.GEOMETRIC_KALEIDO -> {
                drawGeometricKaleido(variantIndex, spectrumData, primary, secondary, glow)
            }
            VisualizerCategory.AMBIENT_ATMOSPHERE -> {
                drawAmbientAtmosphere(variantIndex, spectrumData, primary, secondary, glow)
            }
            VisualizerCategory.RETRO_SYNTHWAVE -> {
                drawRetroSynthwave(variantIndex, spectrumData, primary, secondary, glow)
            }
            VisualizerCategory.CYBERPUNK_HUD -> {
                drawCyberpunkHud(variantIndex, spectrumData, primary, secondary, glow)
            }
            VisualizerCategory.ENERGY_PLASMA -> {
                drawEnergyPlasma(variantIndex, spectrumData, primary, secondary, glow)
            }
            VisualizerCategory.ORGANIC_FRACTAL -> {
                drawOrganicFractal(variantIndex, spectrumData, primary, secondary, glow)
            }
        }
    }
}

// 1: Spectrum Bars (15 variants)
private fun DrawScope.drawSpectrumBars(
    variant: Int,
    data: AudioSpectrumData,
    primary: Color,
    secondary: Color,
    glow: Color
) {
    val w = size.width
    val h = size.height
    val count = 28
    val barWidth = (w / count) * 0.72f
    val spacing = (w / count) * 0.28f

    when (variant) {
        1 -> { // Mirrored Top/Bottom
            for (i in 0 until count) {
                val amp = data.spectrum32[i % data.spectrum32.size] * (h * 0.42f)
                val x = i * (barWidth + spacing) + spacing * 0.5f
                val cy = h / 2f
                drawRoundRect(
                    brush = Brush.verticalGradient(listOf(primary, secondary), cy - amp, cy + amp),
                    topLeft = Offset(x, cy - amp),
                    size = Size(barWidth, amp * 2f),
                    cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f)
                )
            }
        }
        2 -> { // Segmented LEDs
            val segmentHeight = 8f
            val segSpacing = 3f
            for (i in 0 until count) {
                val amp = data.spectrum32[i % data.spectrum32.size] * h * 0.85f
                val x = i * (barWidth + spacing)
                var y = h - 10f
                var currentH = 0f
                while (currentH < amp && y > 10f) {
                    val color = if (y < h * 0.35f) Color(0xFFFF3333) else if (y < h * 0.65f) Color(0xFFFFCC00) else primary
                    drawRect(color, Offset(x, y - segmentHeight), Size(barWidth, segmentHeight))
                    y -= (segmentHeight + segSpacing)
                    currentH += (segmentHeight + segSpacing)
                }
            }
        }
        4 -> { // Floating Peaks
            for (i in 0 until count) {
                val amp = data.spectrum32[i % data.spectrum32.size] * h * 0.8f
                val x = i * (barWidth + spacing)
                val barTop = h - amp
                drawRect(
                    brush = Brush.verticalGradient(listOf(primary.copy(alpha = 0.8f), secondary), barTop, h),
                    topLeft = Offset(x, barTop),
                    size = Size(barWidth, amp)
                )
                // Floating peak dot
                val peakY = (barTop - 12f - data.bassImpact * 8f).coerceAtLeast(4f)
                drawCircle(glow, radius = barWidth * 0.5f, center = Offset(x + barWidth / 2f, peakY))
            }
        }
        else -> { // Classic Bars & Other variations
            for (i in 0 until count) {
                val specVal = data.spectrum32[i % data.spectrum32.size]
                val amp = (specVal * h * (if (variant == 10) 0.95f else 0.82f)).coerceIn(4f, h)
                val x = i * (barWidth + spacing) + spacing * 0.5f
                val y = h - amp
                val c1 = if (variant == 3) secondary else primary
                val c2 = if (variant == 3) primary else secondary
                drawRoundRect(
                    brush = Brush.verticalGradient(listOf(c1, c2), y, h),
                    topLeft = Offset(x, y),
                    size = Size(barWidth, amp),
                    cornerRadius = CornerRadius(if (variant == 6) barWidth / 2f else 3f, if (variant == 6) barWidth / 2f else 3f)
                )
            }
        }
    }
}

// 2: Waveforms & Oscilloscopes (15 variants)
private fun DrawScope.drawOscilloscopes(
    variant: Int,
    data: AudioSpectrumData,
    primary: Color,
    secondary: Color,
    glow: Color
) {
    val w = size.width
    val h = size.height
    val cy = h / 2f
    val path = Path()
    val points = data.waveform64

    for (i in points.indices) {
        val x = (i.toFloat() / (points.size - 1)) * w
        val y = cy + points[i] * (h * 0.38f) * (1f + data.bassImpact * 0.4f)
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }

    when (variant) {
        0, 1 -> { // Phosphor CRT / Laser
            // Outer glow line
            drawPath(path, glow.copy(alpha = 0.35f), style = Stroke(width = 9f, cap = StrokeCap.Round))
            drawPath(path, primary, style = Stroke(width = 3.5f, cap = StrokeCap.Round))
        }
        4 -> { // Liquid Ribbon
            val fillPath = Path()
            fillPath.addPath(path)
            fillPath.lineTo(w, h)
            fillPath.lineTo(0f, h)
            fillPath.close()
            drawPath(fillPath, brush = Brush.verticalGradient(listOf(primary.copy(alpha = 0.3f), Color.Transparent), cy, h))
            drawPath(path, primary, style = Stroke(width = 4f, cap = StrokeCap.Round))
        }
        else -> { // Multi-harmonic / Dual waves
            val path2 = Path()
            for (i in points.indices) {
                val x = (i.toFloat() / (points.size - 1)) * w
                val y = cy - points[i] * (h * 0.32f) * (1f + data.trebleSparkle * 0.3f)
                if (i == 0) path2.moveTo(x, y) else path2.lineTo(x, y)
            }
            drawPath(path, primary, style = Stroke(width = 3.5f, cap = StrokeCap.Round))
            drawPath(path2, secondary.copy(alpha = 0.85f), style = Stroke(width = 2.5f, cap = StrokeCap.Round))
        }
    }
}

// 3: Circular & Radial (15 variants)
private fun DrawScope.drawCircularRadial(
    variant: Int,
    data: AudioSpectrumData,
    primary: Color,
    secondary: Color,
    glow: Color
) {
    val cx = size.width / 2f
    val cy = size.height / 2f
    val baseRadius = (minOf(size.width, size.height) * 0.22f) * (1f + data.bassImpact * 0.25f)
    val rayCount = 48

    // Center pulsating orb
    drawCircle(
        brush = Brush.radialGradient(listOf(glow.copy(alpha = 0.7f), primary.copy(alpha = 0.2f), Color.Transparent), center = Offset(cx, cy), radius = baseRadius * 1.5f),
        radius = baseRadius * 1.5f,
        center = Offset(cx, cy)
    )

    when (variant) {
        2 -> { // Concentric Breathing Halos
            for (r in 1..4) {
                val ringRad = baseRadius * (r * 0.65f) * (1f + data.bassImpact * (0.1f * r))
                drawCircle(
                    color = if (r % 2 == 0) primary else secondary,
                    radius = ringRad,
                    center = Offset(cx, cy),
                    style = Stroke(width = 3f)
                )
            }
        }
        3 -> { // Galaxy Spiral Arms
            val arms = 3
            for (a in 0 until arms) {
                val armAngle = (a.toFloat() / arms) * (2f * PI.toFloat()) + data.phase
                for (step in 1..30) {
                    val angle = armAngle + step * 0.2f
                    val dist = baseRadius * 0.4f + step * 5f * (1f + data.bassImpact * 0.4f)
                    val px = cx + cos(angle) * dist
                    val py = cy + sin(angle) * dist
                    drawCircle(if (step % 2 == 0) primary else secondary, radius = (step * 0.2f + 1f), center = Offset(px, py))
                }
            }
        }
        else -> { // Radial Bars & Sunburst
            for (i in 0 until rayCount) {
                val angle = (i.toFloat() / rayCount) * (2f * PI.toFloat()) + data.phase * 0.5f
                val spec = data.spectrum32[i % data.spectrum32.size]
                val rayLen = baseRadius + spec * (size.height * 0.25f)
                val x1 = cx + cos(angle) * baseRadius
                val y1 = cy + sin(angle) * baseRadius
                val x2 = cx + cos(angle) * rayLen
                val y2 = cy + sin(angle) * rayLen

                drawLine(
                    color = if (i % 2 == 0) primary else secondary,
                    start = Offset(x1, y1),
                    end = Offset(x2, y2),
                    strokeWidth = 4f,
                    cap = StrokeCap.Round
                )
            }
        }
    }
}

// 4: Particle Vortex (15 variants)
private fun DrawScope.drawParticleVortex(
    variant: Int,
    data: AudioSpectrumData,
    primary: Color,
    secondary: Color,
    glow: Color
) {
    val cx = size.width / 2f
    val cy = size.height / 2f
    val particleCount = 65

    for (i in 0 until particleCount) {
        val seed = i * 137.5f // Golden angle distribution
        val speed = 1f + (i % 5) * 0.3f
        val angle = (seed * PI.toFloat() / 180f) + (data.phase * speed)
        val maxDist = minOf(size.width, size.height) * 0.45f
        val dist = (((seed + data.phase * 50f) % maxDist) + 15f) * (1f + data.bassImpact * 0.3f)

        val px = cx + cos(angle) * dist
        val py = cy + sin(angle) * dist
        val radius = ((i % 4) + 2f) * (1f + data.trebleSparkle * 0.5f)

        val col = when (i % 3) {
            0 -> primary
            1 -> secondary
            else -> glow
        }
        drawCircle(col.copy(alpha = (1f - dist / maxDist).coerceIn(0.2f, 1f)), radius = radius, center = Offset(px, py))
    }
}

// 5: Geometric & Kaleidoscopic (15 variants)
private fun DrawScope.drawGeometricKaleido(
    variant: Int,
    data: AudioSpectrumData,
    primary: Color,
    secondary: Color,
    glow: Color
) {
    val cx = size.width / 2f
    val cy = size.height / 2f
    val sides = 6
    val levels = 5

    for (lvl in 1..levels) {
        val rad = (lvl * 32f) * (1f + data.bassImpact * 0.35f)
        val rot = data.phase * (if (lvl % 2 == 0) 1f else -1f) + lvl * 0.3f
        val path = Path()

        for (s in 0 until sides) {
            val angle = (s.toFloat() / sides) * (2f * PI.toFloat()) + rot
            val x = cx + cos(angle) * rad
            val y = cy + sin(angle) * rad
            if (s == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        drawPath(path, color = if (lvl % 2 == 0) primary else secondary, style = Stroke(width = 3.5f))
    }
}

// 6: Ambient & Atmosphere (15 variants)
private fun DrawScope.drawAmbientAtmosphere(
    variant: Int,
    data: AudioSpectrumData,
    primary: Color,
    secondary: Color,
    glow: Color
) {
    val w = size.width
    val h = size.height

    // Flowing undulating atmospheric curtains
    for (layer in 0..2) {
        val path = Path()
        val yBase = h * (0.35f + layer * 0.2f)
        path.moveTo(0f, h)
        path.lineTo(0f, yBase)

        val steps = 24
        for (i in 0..steps) {
            val x = (i.toFloat() / steps) * w
            val wave = sin(data.phase * 2f + i * 0.4f + layer * 1.5f) * (h * 0.12f) * (1f + data.bassImpact * 0.4f)
            path.lineTo(x, yBase + wave)
        }
        path.lineTo(w, h)
        path.close()

        val c = if (layer == 0) primary else if (layer == 1) secondary else glow
        drawPath(path, brush = Brush.verticalGradient(listOf(c.copy(alpha = 0.45f), Color.Transparent), yBase - 40f, h))
    }
}

// 7: Retro Synthwave (15 variants)
private fun DrawScope.drawRetroSynthwave(
    variant: Int,
    data: AudioSpectrumData,
    primary: Color,
    secondary: Color,
    glow: Color
) {
    val w = size.width
    val h = size.height
    val horizonY = h * 0.48f

    // Retro Sun
    val sunRadius = (minOf(w, h) * 0.22f) * (1f + data.bassImpact * 0.15f)
    drawCircle(
        brush = Brush.verticalGradient(listOf(secondary, primary), horizonY - sunRadius, horizonY),
        radius = sunRadius,
        center = Offset(w / 2f, horizonY - 10f)
    )

    // Sun horizontal stripes
    for (s in 1..4) {
        val y = horizonY - sunRadius * 0.8f + (s * 14f)
        drawLine(Color(0xFF090A10), Offset(w / 2f - sunRadius, y), Offset(w / 2f + sunRadius, y), strokeWidth = 3f)
    }

    // Perspective wireframe grid ground
    for (line in 0..8) {
        val xProgress = line.toFloat() / 8f
        val xBottom = xProgress * w
        drawLine(primary.copy(alpha = 0.7f), Offset(w / 2f, horizonY), Offset(xBottom, h), strokeWidth = 2.5f)
    }

    // Horizontal grid lines
    var curY = horizonY + 8f
    var step = 8f
    while (curY < h) {
        drawLine(primary.copy(alpha = 0.5f), Offset(0f, curY), Offset(w, curY), strokeWidth = 2f)
        step *= 1.35f
        curY += step
    }
}

// 8: Cyberpunk HUD (15 variants)
private fun DrawScope.drawCyberpunkHud(
    variant: Int,
    data: AudioSpectrumData,
    primary: Color,
    secondary: Color,
    glow: Color
) {
    val w = size.width
    val h = size.height
    val cx = w / 2f
    val cy = h / 2f

    // Target reticle crosshairs
    val reticleRadius = (minOf(w, h) * 0.26f) * (1f + data.beatEnergy * 0.2f)
    drawCircle(primary.copy(alpha = 0.6f), radius = reticleRadius, center = Offset(cx, cy), style = Stroke(width = 2.5f))
    drawCircle(secondary.copy(alpha = 0.4f), radius = reticleRadius * 0.6f, center = Offset(cx, cy), style = Stroke(width = 1.5f))

    // Cross lines
    drawLine(primary, Offset(cx - reticleRadius - 20f, cy), Offset(cx - reticleRadius + 15f, cy), strokeWidth = 3f)
    drawLine(primary, Offset(cx + reticleRadius - 15f, cy), Offset(cx + reticleRadius + 20f, cy), strokeWidth = 3f)
    drawLine(primary, Offset(cx, cy - reticleRadius - 20f), Offset(cx, cy - reticleRadius + 15f), strokeWidth = 3f)
    drawLine(primary, Offset(cx, cy + reticleRadius - 15f), Offset(cx, cy + reticleRadius + 20f), strokeWidth = 3f)

    // Corner brackets
    val bracketSize = 24f
    val pad = 20f
    // Top-left
    drawLine(secondary, Offset(pad, pad), Offset(pad + bracketSize, pad), strokeWidth = 3f)
    drawLine(secondary, Offset(pad, pad), Offset(pad, pad + bracketSize), strokeWidth = 3f)
    // Top-right
    drawLine(secondary, Offset(w - pad, pad), Offset(w - pad - bracketSize, pad), strokeWidth = 3f)
    drawLine(secondary, Offset(w - pad, pad), Offset(w - pad, pad + bracketSize), strokeWidth = 3f)
    // Bottom-left
    drawLine(secondary, Offset(pad, h - pad), Offset(pad + bracketSize, h - pad), strokeWidth = 3f)
    drawLine(secondary, Offset(pad, h - pad), Offset(pad, h - pad - bracketSize), strokeWidth = 3f)
    // Bottom-right
    drawLine(secondary, Offset(w - pad, h - pad), Offset(w - pad - bracketSize, h - pad), strokeWidth = 3f)
    drawLine(secondary, Offset(w - pad, h - pad), Offset(w - pad, h - pad - bracketSize), strokeWidth = 3f)
}

// 9: Energy & Plasma (15 variants)
private fun DrawScope.drawEnergyPlasma(
    variant: Int,
    data: AudioSpectrumData,
    primary: Color,
    secondary: Color,
    glow: Color
) {
    val cx = size.width / 2f
    val cy = size.height / 2f

    // Branching lightning bolts
    val boltCount = 6
    for (b in 0 until boltCount) {
        val baseAngle = (b.toFloat() / boltCount) * (2f * PI.toFloat()) + data.phase
        var curX = cx
        var curY = cy
        val segments = 8
        val boltPath = Path()
        boltPath.moveTo(curX, curY)

        for (s in 1..segments) {
            val dist = s * 18f * (1f + data.bassImpact * 0.5f)
            val jitter = (sin(data.phase * 10f + b * 3f + s * 2f)) * 14f
            val px = cx + cos(baseAngle) * dist + sin(baseAngle) * jitter
            val py = cy + sin(baseAngle) * dist - cos(baseAngle) * jitter
            boltPath.lineTo(px, py)
        }
        drawPath(boltPath, glow.copy(alpha = 0.4f), style = Stroke(width = 6f, cap = StrokeCap.Round))
        drawPath(boltPath, primary, style = Stroke(width = 2.5f, cap = StrokeCap.Round))
    }
}

// 10: Organic & Fractals (15 variants)
private fun DrawScope.drawOrganicFractal(
    variant: Int,
    data: AudioSpectrumData,
    primary: Color,
    secondary: Color,
    glow: Color
) {
    val cx = size.width / 2f
    val cy = size.height / 2f
    val petals = 12

    for (p in 0 until petals) {
        val angle = (p.toFloat() / petals) * (2f * PI.toFloat()) + data.phase * 0.3f
        val petalLength = (minOf(size.width, size.height) * 0.28f) * (1f + data.bassImpact * 0.3f)
        val xTip = cx + cos(angle) * petalLength
        val yTip = cy + sin(angle) * petalLength

        val pPath = Path()
        pPath.moveTo(cx, cy)
        val ctrl1X = cx + cos(angle - 0.25f) * (petalLength * 0.6f)
        val ctrl1Y = cy + sin(angle - 0.25f) * (petalLength * 0.6f)
        val ctrl2X = cx + cos(angle + 0.25f) * (petalLength * 0.6f)
        val ctrl2Y = cy + sin(angle + 0.25f) * (petalLength * 0.6f)

        pPath.quadraticTo(ctrl1X, ctrl1Y, xTip, yTip)
        pPath.quadraticTo(ctrl2X, ctrl2Y, cx, cy)
        pPath.close()

        val petalColor = if (p % 2 == 0) primary else secondary
        drawPath(pPath, petalColor.copy(alpha = 0.35f))
        drawPath(pPath, petalColor, style = Stroke(width = 2f))
    }
}
