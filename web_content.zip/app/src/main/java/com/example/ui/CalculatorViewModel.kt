package com.example.ui

import android.app.Application
import androidx.compose.ui.geometry.Offset
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AlienSoundManager
import com.example.audio.SoundType
import com.example.calculator.CalculatorEngine
import com.example.data.AppDatabase
import com.example.data.CalcHistoryEntity
import com.example.data.HistoryRepository
import com.example.model.Alien
import com.example.model.AlienRoster
import com.example.model.CalculatorState
import com.example.ui.animation.ParticleManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.random.Random

class CalculatorViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = HistoryRepository(db.calcHistoryDao())
    val soundManager = AlienSoundManager(application)
    val particleManager = ParticleManager()

    val historyList: StateFlow<List<CalcHistoryEntity>> = repository.allHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _uiState = MutableStateFlow(CalculatorState())
    val uiState: StateFlow<CalculatorState> = _uiState.asStateFlow()

    private val _evolutionBannerVisible = MutableStateFlow(false)
    val evolutionBannerVisible: StateFlow<Boolean> = _evolutionBannerVisible.asStateFlow()

    private var bannerJob: Job? = null

    fun onNumberClick(digit: String, touchOffset: Offset? = null) {
        val current = _uiState.value
        val newExpr = if (current.expression == "0" || current.expression == "Error") {
            digit
        } else {
            current.expression + digit
        }

        // Rotate Omnitrix dial on each number press!
        val newAngle = (current.omnitrixRotation + 36f) % 360f

        // Boost alien power meter
        val newPower = (current.powerMeterPercent + 0.08f).let { if (it > 1f) 0.35f else it }

        // Spawn animations!
        touchOffset?.let {
            particleManager.spawnBurst(it, current.isUltimateMode, intensity = 1.0f)
        }

        soundManager.playSoundAndHaptic(
            SoundType.DIGIT_CLICK,
            current.soundEnabled,
            current.hapticsEnabled
        )

        val alienName = if (current.isUltimateMode) current.selectedAlien.ultimateName else current.selectedAlien.name
        val reactions = listOf(
            "$alienName: Energy Pulse +$digit!",
            "Galvanic Cell: Overcharging ($digit)",
            "DNA Matrix: Synthesizing input $digit",
            "$alienName: Power surging!"
        )

        _uiState.value = current.copy(
            expression = newExpr,
            liveResult = computeLiveResult(newExpr, current.isRadMode),
            lastAction = "KEY: $digit | DIAL: ${newAngle.toInt()}°",
            reactionMessage = reactions.random(),
            omnitrixRotation = newAngle,
            dialPulseTrigger = System.currentTimeMillis(),
            powerMeterPercent = newPower,
            errorMessage = null
        )
    }

    fun onOperatorClick(op: String, touchOffset: Offset? = null) {
        val current = _uiState.value
        if (current.expression == "Error") return

        val lastChar = current.expression.lastOrNull()
        val newExpr = if (lastChar != null && lastChar in "+-×÷%^") {
            current.expression.dropLast(1) + op
        } else {
            current.expression + op
        }

        // Dial quick twitch
        val newAngle = (current.omnitrixRotation + 18f) % 360f

        touchOffset?.let {
            particleManager.spawnBurst(it, current.isUltimateMode, intensity = 1.2f)
        }

        soundManager.playSoundAndHaptic(
            SoundType.OPERATOR_CLICK,
            current.soundEnabled,
            current.hapticsEnabled
        )

        _uiState.value = current.copy(
            expression = newExpr,
            liveResult = computeLiveResult(newExpr, current.isRadMode),
            lastAction = "OP: $op",
            omnitrixRotation = newAngle,
            dialPulseTrigger = System.currentTimeMillis(),
            errorMessage = null
        )
    }

    fun onDecimalClick(touchOffset: Offset? = null) {
        val current = _uiState.value
        val tokens = current.expression.split(Regex("[+\\-×÷%^()]"))
        val lastToken = tokens.lastOrNull() ?: ""

        if (!lastToken.contains(".")) {
            val newExpr = if (lastToken.isEmpty()) current.expression + "0." else current.expression + "."
            touchOffset?.let {
                particleManager.spawnBurst(it, current.isUltimateMode, intensity = 0.8f)
            }
            soundManager.playSoundAndHaptic(
                SoundType.DIGIT_CLICK,
                current.soundEnabled,
                current.hapticsEnabled
            )
            _uiState.value = current.copy(
                expression = newExpr,
                lastAction = "DECIMAL POINT",
                errorMessage = null
            )
        }
    }

    fun onEqualsClick(touchOffset: Offset? = null) {
        val current = _uiState.value
        val expr = current.expression
        if (expr == "Error" || expr.isBlank()) return

        val evalResult = CalculatorEngine.evaluate(expr, current.isRadMode)

        // Spin dial full 360 loop + particle eruption!
        val newAngle = current.omnitrixRotation + 360f

        touchOffset?.let {
            particleManager.spawnBurst(it, current.isUltimateMode, intensity = 2.5f)
        }

        evalResult.fold(
            onSuccess = { resValue ->
                val formatted = CalculatorEngine.formatResult(resValue)
                soundManager.playSoundAndHaptic(
                    SoundType.EQUALS_HERO_TIME,
                    current.soundEnabled,
                    current.hapticsEnabled
                )

                // Save to Room DB
                viewModelScope.launch {
                    repository.insert(
                        CalcHistoryEntity(
                            expression = expr,
                            result = formatted,
                            alienName = if (current.isUltimateMode) current.selectedAlien.ultimateName else current.selectedAlien.name,
                            isUltimate = current.isUltimateMode
                        )
                    )
                }

                _uiState.value = current.copy(
                    expression = formatted,
                    liveResult = "",
                    lastAction = "IT'S HERO TIME! = $formatted",
                    reactionMessage = if (current.isUltimateMode) current.selectedAlien.ultimateQuote else current.selectedAlien.quote,
                    omnitrixRotation = newAngle,
                    dialPulseTrigger = System.currentTimeMillis(),
                    powerMeterPercent = 1f,
                    errorMessage = null
                )
            },
            onFailure = { err ->
                soundManager.playSoundAndHaptic(
                    SoundType.ERROR_BUZZ,
                    current.soundEnabled,
                    current.hapticsEnabled
                )
                _uiState.value = current.copy(
                    lastAction = "SYNTAX FAILURE",
                    errorMessage = "DNA GLITCH: ${err.localizedMessage ?: "Invalid Expression"}"
                )
            }
        )
    }

    fun onClearClick() {
        val current = _uiState.value
        soundManager.playSoundAndHaptic(
            SoundType.CLEAR_RESET,
            current.soundEnabled,
            current.hapticsEnabled
        )

        _uiState.value = current.copy(
            expression = "0",
            liveResult = "",
            lastAction = "OMNITRIX RESET",
            reactionMessage = "System recalibrated. Ready for coordinates.",
            omnitrixRotation = 0f,
            dialPulseTrigger = System.currentTimeMillis(),
            powerMeterPercent = 0.4f,
            errorMessage = null
        )
    }

    fun onBackspaceClick() {
        val current = _uiState.value
        val expr = current.expression
        if (expr == "0" || expr == "Error") return

        val newExpr = if (expr.length <= 1) "0" else expr.dropLast(1)
        soundManager.playSoundAndHaptic(
            SoundType.DIGIT_CLICK,
            current.soundEnabled,
            current.hapticsEnabled
        )

        _uiState.value = current.copy(
            expression = newExpr,
            liveResult = computeLiveResult(newExpr, current.isRadMode),
            lastAction = "DEL DIGIT",
            errorMessage = null
        )
    }

    fun onScientificFunctionClick(fn: String, touchOffset: Offset? = null) {
        val current = _uiState.value
        val newExpr = when (fn) {
            "sqrt" -> if (current.expression == "0") "√(" else current.expression + "√("
            "sin" -> if (current.expression == "0") "sin(" else current.expression + "sin("
            "cos" -> if (current.expression == "0") "cos(" else current.expression + "cos("
            "tan" -> if (current.expression == "0") "tan(" else current.expression + "tan("
            "log" -> if (current.expression == "0") "log(" else current.expression + "log("
            "ln" -> if (current.expression == "0") "ln(" else current.expression + "ln("
            "pi" -> if (current.expression == "0") "π" else current.expression + "π"
            "e" -> if (current.expression == "0") "e" else current.expression + "e"
            "^" -> current.expression + "^"
            "!" -> current.expression + "!"
            "(" -> if (current.expression == "0") "(" else current.expression + "("
            ")" -> current.expression + ")"
            else -> current.expression
        }

        touchOffset?.let {
            particleManager.spawnBurst(it, current.isUltimateMode, intensity = 1.3f)
        }

        soundManager.playSoundAndHaptic(
            SoundType.OPERATOR_CLICK,
            current.soundEnabled,
            current.hapticsEnabled
        )

        _uiState.value = current.copy(
            expression = newExpr,
            liveResult = computeLiveResult(newExpr, current.isRadMode),
            lastAction = "FN: $fn",
            dialPulseTrigger = System.currentTimeMillis(),
            errorMessage = null
        )
    }

    fun toggleUltimateMode(touchOffset: Offset? = null) {
        val current = _uiState.value
        val willBeUltimate = !current.isUltimateMode

        soundManager.playSoundAndHaptic(
            SoundType.ULTIMATE_EVOLVE,
            current.soundEnabled,
            current.hapticsEnabled
        )

        touchOffset?.let {
            particleManager.spawnBurst(it, willBeUltimate, intensity = 3.0f)
        }

        val alien = current.selectedAlien
        _uiState.value = current.copy(
            isUltimateMode = willBeUltimate,
            reactionMessage = if (willBeUltimate) alien.ultimateQuote else alien.quote,
            lastAction = if (willBeUltimate) "ULTIMATE MODE ON!" else "STANDARD MODE",
            omnitrixRotation = current.omnitrixRotation + 180f,
            dialPulseTrigger = System.currentTimeMillis(),
            powerMeterPercent = if (willBeUltimate) 0.95f else 0.5f
        )

        // Show banner for 2.5s
        bannerJob?.cancel()
        bannerJob = viewModelScope.launch {
            _evolutionBannerVisible.value = true
            delay(2800)
            _evolutionBannerVisible.value = false
        }
    }

    fun onSelectAlien(alien: Alien) {
        val current = _uiState.value
        soundManager.playSoundAndHaptic(
            SoundType.DIAL_SPIN,
            current.soundEnabled,
            current.hapticsEnabled
        )

        _uiState.value = current.copy(
            selectedAlien = alien,
            reactionMessage = if (current.isUltimateMode) alien.ultimateQuote else alien.quote,
            lastAction = "MORPH: ${alien.name.uppercase()}",
            omnitrixRotation = current.omnitrixRotation + 72f,
            dialPulseTrigger = System.currentTimeMillis()
        )
    }

    fun toggleScientificPad() {
        val current = _uiState.value
        _uiState.value = current.copy(isScientificOpen = !current.isScientificOpen)
    }

    fun toggleRadMode() {
        val current = _uiState.value
        val newRad = !current.isRadMode
        _uiState.value = current.copy(
            isRadMode = newRad,
            lastAction = if (newRad) "RAD MODE" else "DEG MODE",
            liveResult = computeLiveResult(current.expression, newRad)
        )
    }

    fun toggleSound() {
        val current = _uiState.value
        _uiState.value = current.copy(soundEnabled = !current.soundEnabled)
    }

    fun recallHistory(result: String) {
        val current = _uiState.value
        _uiState.value = current.copy(
            expression = result,
            liveResult = "",
            lastAction = "RECALLED: $result",
            errorMessage = null
        )
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAll()
        }
    }

    private fun computeLiveResult(expr: String, isRad: Boolean): String {
        if (expr.isBlank() || expr == "0" || expr == "Error") return ""
        val last = expr.last()
        if (last in "+-×÷%^(") return ""
        return CalculatorEngine.evaluate(expr, isRad).getOrNull()?.let {
            CalculatorEngine.formatResult(it)
        } ?: ""
    }
}
