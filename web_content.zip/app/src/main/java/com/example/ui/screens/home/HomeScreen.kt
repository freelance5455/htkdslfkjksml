package com.example.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Airport
import com.example.data.model.MetarData
import com.example.data.model.TafData
import com.example.ui.components.*
import com.example.ui.navigation.Screen
import com.example.ui.theme.*
import com.example.ui.viewmodel.UiState
import com.example.ui.viewmodel.WeatherViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
  viewModel: WeatherViewModel,
  onNavigateTo: (Screen) -> Unit,
  modifier: Modifier = Modifier
) {
  val selectedAirport by viewModel.selectedAirport.collectAsState()
  val searchQuery by viewModel.searchQuery.collectAsState()
  val searchResults by viewModel.searchResults.collectAsState()
  val favorites by viewModel.favorites.collectAsState()
  val recents by viewModel.recents.collectAsState()
  val isFav by viewModel.isSelectedFavorite.collectAsState()
  val metarState by viewModel.metarState.collectAsState()
  val tafState by viewModel.tafState.collectAsState()
  val sigmetsState by viewModel.sigmetsState.collectAsState()
  val windState by viewModel.windAloftState.collectAsState()
  val snowtams by viewModel.snowtams.collectAsState()
  val isOffline by viewModel.isOffline.collectAsState()

  var showSearchDialog by remember { mutableStateOf(false) }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp)
      .testTag("home_screen"),
    verticalArrangement = Arrangement.spacedBy(14.dp),
    contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
  ) {
    if (isOffline) {
      item { OfflineNoticeBanner() }
    }

    // Active Airport Overview Card
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier.fillMaxWidth().testTag("active_airport_card")
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = selectedAirport.icao,
                  style = MaterialTheme.typography.headlineMedium,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.primary
                )
                if (selectedAirport.iata.isNotBlank()) {
                  Spacer(modifier = Modifier.width(8.dp))
                  Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.primaryContainer
                  ) {
                    Text(
                      text = selectedAirport.iata,
                      style = MaterialTheme.typography.labelLarge,
                      fontWeight = FontWeight.Bold,
                      color = MaterialTheme.colorScheme.onPrimaryContainer,
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                  }
                }
              }
              Text(
                text = "${selectedAirport.nameFa} (${selectedAirport.nameEn})",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = "${selectedAirport.cityFa}، ${selectedAirport.countryFa} • ارتفاع: ${selectedAirport.elevationFt} پا • منطقه FIR: ${selectedAirport.fir}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }

            IconButton(
              onClick = { viewModel.toggleFavorite(selectedAirport.icao) },
              modifier = Modifier.testTag("btn_toggle_favorite")
            ) {
              Icon(
                imageVector = if (isFav) Icons.Default.Star else Icons.Default.StarBorder,
                contentDescription = "علاقه‌مندی",
                tint = if (isFav) StatusYellow else MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Quick Weather Summary Row for Active Airport
          when (val ms = metarState) {
            is UiState.Success -> {
              val metar = ms.data
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                FlightCategoryBadge(category = metar.flightCategory)

                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.Air, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(
                    text = "${metar.windDirDeg?.let { "$it°" } ?: "VRB"}/${metar.windSpeedKt ?: 0}kt${metar.windGustKt?.let { " G$it" } ?: ""}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                  )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.Thermostat, contentDescription = null, tint = StatusRed, modifier = Modifier.size(18.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(
                    text = "${metar.tempC?.let { "${it.toInt()}°C" } ?: "--"}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                  )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.Speed, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text(
                    text = "${metar.altimeterHpa?.let { "Q${it.toInt()}" } ?: "--"}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                  )
                }
              }

              Spacer(modifier = Modifier.height(10.dp))

              Text(
                text = "وضعیت دید و ابرها: ${if (metar.isCavok) "CAVOK" else "${metar.visibilityMeters?.let { "${it}m" } ?: metar.visibilitySm ?: "--"} • ${metar.cloudsSummary}"}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
            is UiState.Loading -> {
              LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
            is UiState.Error -> {
              Text(
                text = "وضعیت متار: ${ms.message}",
                style = MaterialTheme.typography.bodySmall,
                color = StatusRed
              )
            }
          }
        }
      }
    }

    // Operational Status Shortcuts Grid (4 Cards)
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // METAR card
        StatusShortcutCard(
          titleFa = "گزارش METAR",
          titleEn = "METAR / SPECI",
          statusText = when (val s = metarState) {
            is UiState.Success -> if (s.data.isSpeci) "SPECI فعال" else "در دسترس"
            is UiState.Loading -> "در حال دریافت..."
            is UiState.Error -> "عدم دریافت"
          },
          statusColor = when (val s = metarState) {
            is UiState.Success -> if (s.data.isSpeci) StatusRed else StatusGreen
            is UiState.Loading -> StatusGray
            is UiState.Error -> StatusYellow
          },
          icon = Icons.Default.Cloud,
          onClick = { onNavigateTo(Screen.METAR) },
          modifier = Modifier.weight(1f)
        )

        // TAF card
        StatusShortcutCard(
          titleFa = "پیش‌بینی TAF",
          titleEn = "TAF FORECAST",
          statusText = when (tafState) {
            is UiState.Success -> "معتبر"
            is UiState.Loading -> "در حال دریافت..."
            is UiState.Error -> "عدم دریافت"
          },
          statusColor = when (tafState) {
            is UiState.Success -> StatusGreen
            is UiState.Loading -> StatusGray
            is UiState.Error -> StatusYellow
          },
          icon = Icons.Default.Schedule,
          onClick = { onNavigateTo(Screen.TAF) },
          modifier = Modifier.weight(1f)
        )
      }
    }

    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // SIGMET card
        StatusShortcutCard(
          titleFa = "پدیده‌های SIGMET",
          titleEn = "ACTIVE SIGMET",
          statusText = when (val s = sigmetsState) {
            is UiState.Success -> "${s.data.size} پیام فعال"
            is UiState.Loading -> "بررسی..."
            is UiState.Error -> "عدم دسترسی"
          },
          statusColor = when (val s = sigmetsState) {
            is UiState.Success -> if (s.data.isNotEmpty()) StatusYellow else StatusGreen
            is UiState.Loading -> StatusGray
            is UiState.Error -> StatusRed
          },
          icon = Icons.Default.Warning,
          onClick = { onNavigateTo(Screen.SIGMET) },
          modifier = Modifier.weight(1f)
        )

        // SNOWTAM card
        StatusShortcutCard(
          titleFa = "اسنوتام و باند",
          titleEn = "SNOWTAM / RCR",
          statusText = if (snowtams.isNotEmpty()) {
            val lowest = snowtams.first().lowestRwycc
            if (lowest != null) "RWYCC $lowest" else "ثبت شده"
          } else {
            "نیاز به اتصال منبع"
          },
          statusColor = if (snowtams.isNotEmpty()) StatusGreen else StatusGray,
          icon = Icons.Default.AcUnit,
          onClick = { onNavigateTo(Screen.SNOWTAM) },
          modifier = Modifier.weight(1f)
        )
      }
    }

    // Wind Aloft Quick Shortcut Banner
    item {
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onNavigateTo(Screen.WIND_ALOFT) }
          .testTag("btn_wind_aloft_shortcut")
      ) {
        Row(
          modifier = Modifier.padding(14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = MaterialTheme.colorScheme.primaryContainer,
              modifier = Modifier.size(44.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  Icons.Default.Air,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.primary
                )
              }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text(
                text = "باد و دمای سطوح فوقانی (WIND ALOFT)",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = "پروفایل عمودی باد از سطح زمین تا FL450 برای ${selectedAirport.icao}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
          Icon(Icons.Default.ChevronLeft, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        }
      }
    }

    // Quick Iranian Airports Access
    item {
      Column {
        Text(
          text = "دسترسی سریع به فرودگاه‌های اصلی ایران",
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          val iranianHubs = listOf(
            Triple("OIIE", "IKA", "امام خمینی"),
            Triple("OIII", "THR", "مهرآباد"),
            Triple("OIMM", "MHD", "مشهد"),
            Triple("OISS", "SYZ", "شیراز"),
            Triple("OIFM", "IFN", "اصفهان"),
            Triple("OITT", "TBZ", "تبریز"),
            Triple("OIBK", "KIH", "کیش"),
            Triple("OIAW", "AWZ", "اهواز"),
            Triple("OIKB", "BND", "بندرعباس"),
            Triple("OIZH", "ZAH", "زاهدان"),
            Triple("OIBB", "BUZ", "بوشهر"),
            Triple("OIKK", "KER", "کرمان")
          )
          items(iranianHubs) { (icao, iata, faName) ->
            val isCurrent = selectedAirport.icao == icao
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
              border = CardDefaults.outlinedCardBorder(),
              modifier = Modifier
                .clickable { viewModel.selectAirportByIcao(icao) }
                .testTag("chip_airport_$icao")
            ) {
              Column(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
              ) {
                Text(
                  text = icao,
                  style = MaterialTheme.typography.labelLarge,
                  fontWeight = FontWeight.Bold,
                  color = if (isCurrent) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                )
                Text(
                  text = faName,
                  style = MaterialTheme.typography.labelSmall,
                  fontSize = 10.sp,
                  color = if (isCurrent) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.9f) else MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }
        }
      }
    }

    // Favorite Airports Row
    if (favorites.isNotEmpty()) {
      item {
        Column {
          Text(
            text = "فرودگاه‌های برگزیده (Favorites)",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.height(8.dp))
          LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(favorites) { apt ->
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier.clickable { viewModel.selectAirport(apt) }
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(Icons.Default.Star, contentDescription = null, tint = StatusYellow, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = "${apt.icao} • ${apt.nameFa}",
                    style = MaterialTheme.typography.labelMedium
                  )
                }
              }
            }
          }
        }
      }
    }

    // Operational Disclaimer Card
    item {
      OperationalDisclaimerCard()
    }
  }
}

@Composable
private fun StatusShortcutCard(
  titleFa: String,
  titleEn: String,
  statusText: String,
  statusColor: Color,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    border = CardDefaults.outlinedCardBorder(),
    modifier = modifier.clickable { onClick() }
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
        Box(
          modifier = Modifier
            .size(8.dp)
            .clip(androidx.compose.foundation.shape.CircleShape)
            .background(statusColor)
        )
      }
      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = titleFa,
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold
      )
      Text(
        text = titleEn,
        style = MaterialTheme.typography.labelSmall,
        fontSize = 10.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = statusText,
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Medium,
        color = statusColor
      )
    }
  }
}
