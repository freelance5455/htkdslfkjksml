package com.example.ui.screens.home

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Airport
import com.example.ui.components.*
import com.example.ui.navigation.Screen
import com.example.ui.theme.*
import com.example.ui.viewmodel.UiState
import com.example.ui.viewmodel.WeatherViewModel

enum class AirportFilterTab(val label: String) {
  ALL("All Stations"),
  DOMESTIC("Domestic (Iran)"),
  INTERNATIONAL("International")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
  viewModel: WeatherViewModel,
  onNavigateTo: (Screen) -> Unit,
  modifier: Modifier = Modifier
) {
  val selectedAirport by viewModel.selectedAirport.collectAsState()
  val favorites by viewModel.favorites.collectAsState()
  val isFav by viewModel.isSelectedFavorite.collectAsState()
  val metarState by viewModel.metarState.collectAsState()
  val tafState by viewModel.tafState.collectAsState()
  val sigmetsState by viewModel.sigmetsState.collectAsState()
  val snowtams by viewModel.snowtams.collectAsState()
  val isOffline by viewModel.isOffline.collectAsState()
  val searchResults by viewModel.searchResults.collectAsState()

  val context = LocalContext.current
  var activeFilter by remember { mutableStateOf(AirportFilterTab.ALL) }
  var localSearchText by remember { mutableStateOf("") }

  // Filter airports based on search query and active tab
  val displayedAirports = remember(searchResults, activeFilter, localSearchText) {
    val baseList = searchResults.filter { apt ->
      if (localSearchText.isBlank()) true
      else {
        apt.icao.contains(localSearchText, ignoreCase = true) ||
          apt.iata.contains(localSearchText, ignoreCase = true) ||
          apt.nameEn.contains(localSearchText, ignoreCase = true) ||
          apt.cityEn.contains(localSearchText, ignoreCase = true) ||
          apt.nameFa.contains(localSearchText, ignoreCase = true)
      }
    }
    when (activeFilter) {
      AirportFilterTab.ALL -> baseList
      AirportFilterTab.DOMESTIC -> baseList.filter { it.icao.startsWith("OI") || it.countryEn.equals("Iran", ignoreCase = true) }
      AirportFilterTab.INTERNATIONAL -> baseList.filter { !it.icao.startsWith("OI") && !it.countryEn.equals("Iran", ignoreCase = true) }
    }
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp)
      .testTag("home_screen"),
    verticalArrangement = Arrangement.spacedBy(14.dp),
    contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
  ) {
    if (isOffline) {
      item { OfflineNoticeBanner() }
    }

    // 1. DASHBOARD HEADER & AIRPORT SEARCH CARD (Pale Lilac / یاسی کم رنگ)
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DashboardSearchCardBg),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, DashboardSearchCardBorder),
        modifier = Modifier.fillMaxWidth().testTag("dashboard_search_card")
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.Search,
                contentDescription = null,
                tint = DashboardSearchCardText,
                modifier = Modifier.size(22.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "Airport Search & Selection",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = DashboardSearchCardText
              )
            }
            Text(
              text = "داشبورد فرودگاه‌ها",
              style = MaterialTheme.typography.labelSmall,
              color = DashboardSearchCardText.copy(alpha = 0.8f)
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Filter Tabs: All, Domestic (Iran), International
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            AirportFilterTab.values().forEach { tab ->
              val isSelected = activeFilter == tab
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (isSelected) OceanBlue else Color.White,
                border = androidx.compose.foundation.BorderStroke(
                  1.dp,
                  if (isSelected) OceanBlueDark else DashboardSearchCardBorder
                ),
                modifier = Modifier
                  .weight(1f)
                  .clickable { activeFilter = tab }
              ) {
                Box(
                  modifier = Modifier.padding(vertical = 8.dp),
                  contentAlignment = Alignment.Center
                ) {
                  Text(
                    text = tab.label,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                    color = if (isSelected) Color.White else DashboardSearchCardText,
                    fontSize = 11.sp
                  )
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Search Text Field
          OutlinedTextField(
            value = localSearchText,
            onValueChange = {
              localSearchText = it
              viewModel.onSearchQueryChanged(it)
            },
            placeholder = {
              Text(
                text = "Search ICAO, IATA, City (e.g. OIIE, OMDB, THR)...",
                style = MaterialTheme.typography.bodySmall,
                color = AtcTextMuted
              )
            },
            leadingIcon = {
              Icon(Icons.Default.FlightTakeoff, contentDescription = null, tint = OceanBlue)
            },
            trailingIcon = {
              if (localSearchText.isNotBlank()) {
                IconButton(onClick = {
                  localSearchText = ""
                  viewModel.onSearchQueryChanged("")
                }) {
                  Icon(Icons.Default.Close, contentDescription = "Clear", tint = AtcTextMuted)
                }
              }
            },
            shape = RoundedCornerShape(10.dp),
            colors = OutlinedTextFieldDefaults.colors(
              focusedContainerColor = Color.White.copy(alpha = 0.85f),
              unfocusedContainerColor = Color.White.copy(alpha = 0.65f),
              focusedBorderColor = OceanBlue,
              unfocusedBorderColor = DashboardSearchCardBorder
            ),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("input_dashboard_airport_search")
          )

          Spacer(modifier = Modifier.height(10.dp))

          // Horizontal Quick Selection Carousel
          Text(
            text = "Select Station (${displayedAirports.size} available):",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.SemiBold,
            color = DashboardSearchCardText
          )
          Spacer(modifier = Modifier.height(6.dp))

          LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(horizontal = 2.dp)
          ) {
            items(displayedAirports.take(20)) { apt ->
              val isSelected = apt.icao == selectedAirport.icao
              val isDomestic = apt.icao.startsWith("OI") || apt.countryEn.equals("Iran", ignoreCase = true)

              Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (isSelected) OceanBlue else Color.White.copy(alpha = 0.75f),
                border = androidx.compose.foundation.BorderStroke(
                  1.dp,
                  if (isSelected) OceanBlueDark else DashboardSearchCardBorder
                ),
                modifier = Modifier
                  .clickable { viewModel.selectAirport(apt) }
                  .testTag("chip_station_${apt.icao}")
              ) {
                Column(
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                  horizontalAlignment = Alignment.CenterHorizontally
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                      text = apt.icao,
                      style = MaterialTheme.typography.labelMedium,
                      fontWeight = FontWeight.Bold,
                      color = if (isSelected) Color.White else AtcTextMain
                    )
                    if (apt.iata.isNotBlank()) {
                      Text(
                        text = " / ${apt.iata}",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isSelected) Color(0xFFE0F2FE) else AtcTextMuted,
                        fontSize = 10.sp
                      )
                    }
                  }
                  Text(
                    text = if (isDomestic) "DOMESTIC" else "INTL",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (isSelected) Color(0xFFBAE6FD) else if (isDomestic) Color(0xFF0369A1) else Color(0xFF7C2D12)
                  )
                }
              }
            }
          }
        }
      }
    }

    // 2. ACTIVE AIRPORT WEATHER OVERVIEW CARD (No interpretation, pure operational data)
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFCBD5E1)),
        modifier = Modifier.fillMaxWidth().testTag("active_airport_card")
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = selectedAirport.icao,
                  style = MaterialTheme.typography.headlineMedium,
                  fontWeight = FontWeight.Bold,
                  color = OceanBlue
                )
                if (selectedAirport.iata.isNotBlank()) {
                  Spacer(modifier = Modifier.width(8.dp))
                  Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFFE0F2FE)
                  ) {
                    Text(
                      text = selectedAirport.iata,
                      style = MaterialTheme.typography.labelLarge,
                      fontWeight = FontWeight.Bold,
                      color = OceanBlueDark,
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                  }
                }
                Spacer(modifier = Modifier.width(8.dp))
                val isDom = selectedAirport.icao.startsWith("OI") || selectedAirport.countryEn.equals("Iran", ignoreCase = true)
                Surface(
                  shape = RoundedCornerShape(4.dp),
                  color = if (isDom) Color(0xFFF0FDF4) else Color(0xFFFFF7ED)
                ) {
                  Text(
                    text = if (isDom) "DOMESTIC" else "INTERNATIONAL",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isDom) Color(0xFF15803D) else Color(0xFFC2410C),
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                  )
                }
              }
              Text(
                text = "${selectedAirport.nameEn} • ${selectedAirport.cityEn}, ${selectedAirport.countryEn}",
                style = MaterialTheme.typography.bodyMedium,
                color = AtcTextMain
              )
              Text(
                text = "Elevation: ${selectedAirport.elevationFt} FT • FIR: ${selectedAirport.fir} • Lat/Lon: ${selectedAirport.latitude}, ${selectedAirport.longitude}",
                style = MaterialTheme.typography.labelSmall,
                color = AtcTextMuted
              )
            }

            IconButton(
              onClick = { viewModel.toggleFavorite(selectedAirport.icao) },
              modifier = Modifier.testTag("btn_toggle_favorite")
            ) {
              Icon(
                imageVector = if (isFav) Icons.Default.Star else Icons.Default.StarBorder,
                contentDescription = "Favorite",
                tint = if (isFav) StatusYellow else AtcTextMuted
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          // RAW METAR SNIPPET DIRECTLY (No explanation or interpretation)
          when (val ms = metarState) {
            is UiState.Success -> {
              val metar = ms.data
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = if (metar.isSpeci) "RAW SPECI REPORT" else "RAW METAR REPORT",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (metar.isSpeci) StatusRed else MetarCardText
                  )
                  if (metar.isSpeci) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(shape = RoundedCornerShape(4.dp), color = StatusRed) {
                      Text("SPECI", color = Color.White, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                    }
                  }
                }
                FlightCategoryBadge(category = metar.flightCategory)
              }

              Spacer(modifier = Modifier.height(8.dp))

              // Verbatim Raw METAR Monospace Box
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = MetarCardBg,
                border = androidx.compose.foundation.BorderStroke(1.dp, MetarCardBorder),
                modifier = Modifier.fillMaxWidth()
              ) {
                Column(modifier = Modifier.padding(10.dp)) {
                  Text(
                    text = metar.rawMetar.ifBlank { "NO RAW METAR AVAILABLE" },
                    style = MaterialTheme.typography.bodyMedium.copy(
                      fontFamily = FontFamily.Monospace,
                      lineHeight = 20.sp
                    ),
                    color = MetarCardText
                  )
                  Spacer(modifier = Modifier.height(4.dp))
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                  ) {
                    Text(
                      text = "Obs Time: ${metar.obsTimeUtc}",
                      style = MaterialTheme.typography.labelSmall,
                      fontSize = 10.sp,
                      color = MetarCardText.copy(alpha = 0.8f)
                    )
                    Text(
                      text = "Source: ${metar.source}",
                      style = MaterialTheme.typography.labelSmall,
                      fontSize = 10.sp,
                      color = MetarCardText.copy(alpha = 0.8f)
                    )
                  }
                }
              }
            }
            is UiState.Loading -> {
              LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = OceanBlue)
            }
            is UiState.Error -> {
              Text(
                text = "METAR: ${ms.message}",
                style = MaterialTheme.typography.bodySmall,
                color = StatusRed
              )
            }
          }
        }
      }
    }

    // 3. COLOR-CODED OPERATIONAL CARDS (METAR: Soft Purple, TAF: Soft Green, SIGMET: Soft Orange, SNOWTAM: Soft Blue)
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // METAR CARD: Soft Purple (بنفش ملایم)
        StatusShortcutCard(
          title = "RAW METAR",
          subtitle = "Current Observation",
          statusText = when (val s = metarState) {
            is UiState.Success -> if (s.data.isSpeci) "SPECI ACTIVE" else "AVAILABLE"
            is UiState.Loading -> "LOADING..."
            is UiState.Error -> "UNAVAILABLE"
          },
          statusColor = when (val s = metarState) {
            is UiState.Success -> if (s.data.isSpeci) StatusRed else StatusGreen
            is UiState.Loading -> StatusGray
            is UiState.Error -> StatusYellow
          },
          icon = Icons.Default.Cloud,
          containerColor = MetarCardBg,
          borderColor = MetarCardBorder,
          textColor = MetarCardText,
          iconTint = MetarCardText,
          onClick = { onNavigateTo(Screen.METAR) },
          modifier = Modifier.weight(1f)
        )

        // TAF CARD: Soft Green (سبز ملایم)
        StatusShortcutCard(
          title = "RAW TAF",
          subtitle = "Terminal Forecast",
          statusText = when (tafState) {
            is UiState.Success -> "VALID FORECAST"
            is UiState.Loading -> "LOADING..."
            is UiState.Error -> "UNAVAILABLE"
          },
          statusColor = when (tafState) {
            is UiState.Success -> StatusGreen
            is UiState.Loading -> StatusGray
            is UiState.Error -> StatusYellow
          },
          icon = Icons.Default.Schedule,
          containerColor = TafCardBg,
          borderColor = TafCardBorder,
          textColor = TafCardText,
          iconTint = TafCardText,
          onClick = { onNavigateTo(Screen.TAF) },
          modifier = Modifier.weight(1f)
        )
      }
    }

    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // SIGMET CARD: Soft Orange (نارنجی ملایم)
        StatusShortcutCard(
          title = "RAW SIGMET",
          subtitle = "En-Route Hazards",
          statusText = when (val s = sigmetsState) {
            is UiState.Success -> "${s.data.size} ACTIVE"
            is UiState.Loading -> "CHECKING..."
            is UiState.Error -> "UNAVAILABLE"
          },
          statusColor = when (val s = sigmetsState) {
            is UiState.Success -> if (s.data.isNotEmpty()) StatusYellow else StatusGreen
            is UiState.Loading -> StatusGray
            is UiState.Error -> StatusRed
          },
          icon = Icons.Default.Warning,
          containerColor = SigmetCardBg,
          borderColor = SigmetCardBorder,
          textColor = SigmetCardText,
          iconTint = SigmetCardText,
          onClick = { onNavigateTo(Screen.SIGMET) },
          modifier = Modifier.weight(1f)
        )

        // SNOWTAM CARD: Soft Blue (آبی ملایم)
        StatusShortcutCard(
          title = "SNOWTAM / RCR",
          subtitle = "Runway Surface Condition",
          statusText = if (snowtams.isNotEmpty()) {
            val lowest = snowtams.first().lowestRwycc
            if (lowest != null) "RWYCC $lowest" else "RECORDED"
          } else {
            "OPMET FEED"
          },
          statusColor = if (snowtams.isNotEmpty()) StatusGreen else StatusGray,
          icon = Icons.Default.AcUnit,
          containerColor = SnowtamCardBg,
          borderColor = SnowtamCardBorder,
          textColor = SnowtamCardText,
          iconTint = SnowtamCardText,
          onClick = { onNavigateTo(Screen.SNOWTAM) },
          modifier = Modifier.weight(1f)
        )
      }
    }

    // 4. Dedicated Wind & Temperature Aloft Shortcut Card
    item {
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = WindAloftCardBg),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, WindAloftCardBorder),
        modifier = Modifier
          .fillMaxWidth()
          .clickable { onNavigateTo(Screen.WIND_ALOFT) }
          .testTag("btn_wind_aloft_shortcut")
      ) {
        Row(
          modifier = Modifier.padding(14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = Color.White.copy(alpha = 0.5f),
              modifier = Modifier.size(46.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  Icons.Default.Air,
                  contentDescription = null,
                  tint = WindAloftCardText,
                  modifier = Modifier.size(26.dp)
                )
              }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = "WIND & TEMP ALOFT",
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold,
                  color = WindAloftCardText
                )
                Spacer(modifier = Modifier.width(6.dp))
                Surface(
                  shape = RoundedCornerShape(4.dp),
                  color = OceanBlue
                ) {
                  Text(
                    text = "DEDICATED PAGE",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                  )
                }
              }
              Text(
                text = "Select Region (FIR Sectors) & Altitude (FL050 to FL390)",
                style = MaterialTheme.typography.bodySmall,
                color = WindAloftCardText.copy(alpha = 0.85f)
              )
            }
          }
          Icon(Icons.Default.ChevronRight, contentDescription = "Open Wind Aloft", tint = WindAloftCardText)
        }
      }
    }

    // 5. Favorite Stations
    if (favorites.isNotEmpty()) {
      item {
        Column {
          Text(
            text = "Favorite Stations",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = AtcTextMain
          )
          Spacer(modifier = Modifier.height(8.dp))
          LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(favorites) { apt ->
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color.White,
                border = CardDefaults.outlinedCardBorder(),
                modifier = Modifier.clickable { viewModel.selectAirport(apt) }
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Icon(Icons.Default.Star, contentDescription = null, tint = StatusYellow, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = "${apt.icao} • ${apt.nameEn}",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold
                  )
                }
              }
            }
          }
        }
      }
    }

    // Operational Disclaimer
    item {
      OperationalDisclaimerCard()
    }
  }
}

@Composable
private fun StatusShortcutCard(
  title: String,
  subtitle: String,
  statusText: String,
  statusColor: Color,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  containerColor: Color,
  borderColor: Color,
  textColor: Color,
  iconTint: Color,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = containerColor),
    border = androidx.compose.foundation.BorderStroke(1.5.dp, borderColor),
    modifier = modifier.clickable { onClick() }
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(20.dp))
        Box(
          modifier = Modifier
            .size(8.dp)
            .clip(androidx.compose.foundation.shape.CircleShape)
            .background(statusColor)
        )
      }
      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = title,
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
        color = textColor
      )
      Text(
        text = subtitle,
        style = MaterialTheme.typography.labelSmall,
        fontSize = 10.sp,
        color = textColor.copy(alpha = 0.75f)
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = statusText,
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.SemiBold,
        color = statusColor
      )
    }
  }
}
