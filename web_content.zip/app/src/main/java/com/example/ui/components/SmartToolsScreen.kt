package com.example.ui.components

import android.media.ToneGenerator
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Feedback
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.AppLanguage
import com.example.model.DailyPanchang
import com.example.ui.components.tools.AgeDifferenceDialog
import com.example.ui.components.tools.BmiCalculatorDialog
import com.example.ui.components.tools.CalendarDateAddSubDialog
import com.example.ui.components.tools.CashBookDialog
import com.example.ui.components.tools.CashCounterDialog
import com.example.ui.components.tools.CoinTossDialog
import com.example.ui.components.tools.DishaShoolTool
import com.example.ui.components.tools.EmiCalculatorDialog
import com.example.ui.components.tools.GstCalculatorDialog
import com.example.ui.components.tools.GunMilanTool
import com.example.ui.components.tools.HabitTrackerDialog
import com.example.ui.components.tools.HeightWeightChartDialog
import com.example.ui.components.tools.HinduAgeCalculatorTool
import com.example.ui.components.tools.HoraChakraTool
import com.example.ui.components.tools.IfscSearchDialog
import com.example.ui.components.tools.InterestCalculatorDialog
import com.example.ui.components.tools.JapaMalaCounterTool
import com.example.ui.components.tools.MileageCalculatorDialog
import com.example.ui.components.tools.NotesDialog
import com.example.ui.components.tools.NumberToWordDialog
import com.example.ui.components.tools.PercentageCalculatorDialog
import com.example.ui.components.tools.PriceWeightCalculatorDialog
import com.example.ui.components.tools.RdCalculatorDialog
import com.example.ui.components.tools.SacredSoundItem
import com.example.ui.components.tools.SacredSoundPlayerDialog
import com.example.ui.components.tools.SimpleCalculatorDialog
import com.example.ui.components.tools.SpeechToTextDialog
import com.example.ui.components.tools.SpeedMeterDialog
import com.example.ui.components.tools.StopWatchDialog
import com.example.ui.components.tools.TallyCounterDialog
import com.example.ui.components.tools.TextToSpeechDialog
import com.example.ui.components.tools.UnitConverterDialog
import com.example.ui.components.tools.VastuCompassTool
import com.example.ui.components.tools.WorldClockDialog

data class SmartToolGridItem(
    val id: String,
    val title: String,
    val emoji: String,
    val pastelBg: Color,
    val iconTint: Color = Color.Black
)

@Composable
fun SmartToolsScreen(
    currentPanchang: DailyPanchang,
    language: AppLanguage,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var isSearchOpen by remember { mutableStateOf(false) }

    // Dialog trigger states
    var activeSoundItem by remember { mutableStateOf<SacredSoundItem?>(null) }
    var showCashCounter by remember { mutableStateOf(false) }
    var showSimpleInterest by remember { mutableStateOf(false) }
    var showCompoundInterest by remember { mutableStateOf(false) }
    var showEmiCalculator by remember { mutableStateOf(false) }
    var showGstCalculator by remember { mutableStateOf(false) }
    var showRdCalculator by remember { mutableStateOf(false) }
    var showStopWatch by remember { mutableStateOf(false) }
    var showCoinToss by remember { mutableStateOf(false) }
    var showNumberToWord by remember { mutableStateOf(false) }
    var showBmiCalculator by remember { mutableStateOf(false) }
    var showPriceToWeight by remember { mutableStateOf(false) }
    var showWeightToPrice by remember { mutableStateOf(false) }
    var showTallyCounter by remember { mutableStateOf(false) }
    var showAgeCalculator by remember { mutableStateOf(false) }
    var showAgeDiffDialog by remember { mutableStateOf(false) }
    var showNotesDialog by remember { mutableStateOf(false) }
    var showUnitConverterDialog by remember { mutableStateOf(false) }
    var showCalendarDateDialog by remember { mutableStateOf(false) }
    var showCashBookDialog by remember { mutableStateOf(false) }
    var showIfscDialog by remember { mutableStateOf(false) }
    var showSpeedMeterDialog by remember { mutableStateOf(false) }
    var showMileageDialog by remember { mutableStateOf(false) }
    var showPercentageDialog by remember { mutableStateOf(false) }
    var showHabitTrackerDialog by remember { mutableStateOf(false) }
    var showWorldClockDialog by remember { mutableStateOf(false) }
    var showHeightWeightChartDialog by remember { mutableStateOf(false) }
    var showSimpleCalculatorDialog by remember { mutableStateOf(false) }
    var showTtsDialog by remember { mutableStateOf(false) }
    var showSttDialog by remember { mutableStateOf(false) }
    var showVastuCompass by remember { mutableStateOf(false) }
    var showJapaMala by remember { mutableStateOf(false) }
    var showHoraChakra by remember { mutableStateOf(false) }
    var showGunMilan by remember { mutableStateOf(false) }
    var showDishaShool by remember { mutableStateOf(false) }
    var showFeedbackDialog by remember { mutableStateOf(false) }

    // Complete List of All Tools matching the screenshot exactly
    val allTools = listOf(
        // Row 1
        SmartToolGridItem("age_calc", "आयु की गणना\nकरें", "🎂", Color(0xFFFFE0B2)),
        SmartToolGridItem("age_diff", "आयु में अंतर", "👥", Color(0xFFE8F5E9)),
        SmartToolGridItem("cash_count", "नकद गणना", "👛", Color(0xFFD7CCC8)),
        SmartToolGridItem("stopwatch", "Stop Watch", "⏱️", Color(0xFFFFE0B2)),

        // Row 2
        SmartToolGridItem("bell_sound", "घंटी की आवाज़", "🔔", Color(0xFFE8EAF6)),
        SmartToolGridItem("om_sound", "Om Sound", "ॐ", Color(0xFFFFE0B2)),
        SmartToolGridItem("dhol_sound", "ढोल-नगाड़ों की\nआवाज़", "🥁", Color(0xFFE3F2FD)),
        SmartToolGridItem("shankh_sound", "मंदिर के शंख की\nध्वनि", "🐚", Color(0xFFE3F2FD)),

        // Row 3
        SmartToolGridItem("pooja_bell", "पूजा की घंटी की\nआवाज़", "🔕", Color(0xFFFFEBEE)),
        SmartToolGridItem("temple_bell", "मंदिर की घंटी की\nध्वनि", "🔔", Color(0xFFFFEBEE)),
        SmartToolGridItem("harmonium", "हारमोनियम की\nध्वनि", "🎹", Color(0xFFE0F7FA)),
        SmartToolGridItem("shubh_sound", "शुभ ध्वनि", "🎺", Color(0xFFE8F5E9)),

        // Row 4
        SmartToolGridItem("compass", "Compass", "🧭", Color(0xFFE0F7FA)),
        SmartToolGridItem("notes", "Notes", "📝", Color(0xFFF9FBE7)),
        SmartToolGridItem("simple_interest", "Simple\nInterest", "💸", Color(0xFFFCE4EC)),
        SmartToolGridItem("compound_interest", "Compound\nInterest", "📈", Color(0xFFE0F7FA)),

        // Row 5
        SmartToolGridItem("emi_calc", "EMI\nCalculator", "🏦", Color(0xFFFFE0B2)),
        SmartToolGridItem("gst_calc", "GST\nCalculator", "📊", Color(0xFFE3F2FD)),
        SmartToolGridItem("unit_converter", "Unit\nConverter", "📏", Color(0xFFE0F7FA)),
        SmartToolGridItem("calendar_date", "Calendar\nDate(+/-)", "📅", Color(0xFFFFE0B2)),

        // Row 6
        SmartToolGridItem("coin_toss", "Coin Toss", "🪙", Color(0xFFFFE0B2)),
        SmartToolGridItem("cash_book", "Cash Book", "📖", Color(0xFFFFEBEE)),
        SmartToolGridItem("ifsc", "IFSC", "🏛️", Color(0xFFE0F2F1)),
        SmartToolGridItem("speed_meter", "Internet\nSpeed Meter", "📶", Color(0xFFE0F2F1)),

        // Row 7
        SmartToolGridItem("mileage_calc", "Mileage\nCalculator", "⛽", Color(0xFFFFEBEE)),
        SmartToolGridItem("number_to_word", "Number to\nWord", "🔢", Color(0xFFEDE7F6)),
        SmartToolGridItem("percentage_calc", "Percentage\nCalculator", "🧮", Color(0xFFFCE4EC)),
        SmartToolGridItem("tracker", "Tracker", "📍", Color(0xFFE1F5FE)),

        // Row 8
        SmartToolGridItem("world_clock", "World Clock", "🌐", Color(0xFFFFEBEE)),
        SmartToolGridItem("bmi_calc", "BMI\nCalculator", "⚖️", Color(0xFFFFEBEE)),
        SmartToolGridItem("price_to_weight", "Price To\nWeight", "₹➔⚖️", Color(0xFFE0F2F1)),
        SmartToolGridItem("weight_to_price", "Weight To\nPrice", "⚖️➔₹", Color(0xFFE0F2F1)),

        // Row 9
        SmartToolGridItem("height_weight", "Height_Weight\n_Chart", "📏", Color(0xFFFCE4EC)),
        SmartToolGridItem("counter", "Counter", "🔢", Color(0xFFECEFF1)),
        SmartToolGridItem("simple_calc", "Simple\nCalculator", "🧮", Color(0xFFFFEBEE)),
        SmartToolGridItem("rd_calc", "RD Calculator", "📅", Color(0xFFFCE4EC)),

        // Row 10
        SmartToolGridItem("tts", "Text to\nSpeech", "🗣️", Color(0xFFFFEBEE)),
        SmartToolGridItem("stt", "Speech to\nText", "🎙️", Color(0xFFE0F2F1)),

        // Vedic Sacred Tools
        SmartToolGridItem("japa_mala", "108 जाप\nमाला", "📿", Color(0xFFFFF8E1)),
        SmartToolGridItem("hora_chakra", "दैनिक होरा\nचक्र", "⭐", Color(0xFFEDE7F6)),
        SmartToolGridItem("gun_milan", "36 गुण\nमिलान", "💑", Color(0xFFFCE4EC)),
        SmartToolGridItem("disha_shool", "दिशा शूल\nव परिहार", "⚠️", Color(0xFFFFEBEE))
    )

    val filteredTools = if (searchQuery.isBlank()) allTools else {
        allTools.filter { it.title.contains(searchQuery, ignoreCase = true) || it.id.contains(searchQuery, ignoreCase = true) }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFEDE7F6)) // Authentic purple header tinted background
    ) {
        // App Bar matching user screenshot (Purple header bar)
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Color(0xFF5E35B1), // Deep spiritual purple
            shadowElevation = 4.dp
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onBack, modifier = Modifier.testTag("smart_tools_back_button")) {
                            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "स्मार्ट उपकरण",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 20.sp
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { isSearchOpen = !isSearchOpen }) {
                            Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = Color.White)
                        }
                        IconButton(onClick = {
                            Toast.makeText(context, "स्मार्ट उपकरण: दैनिक जीवन एवं ज्योतिष गणना के 42+ उपयोगी टूल्स", Toast.LENGTH_LONG).show()
                        }) {
                            Icon(imageVector = Icons.Default.HelpOutline, contentDescription = "Info", tint = Color.White)
                        }
                        IconButton(onClick = { showFeedbackDialog = true }) {
                            Icon(imageVector = Icons.Default.Feedback, contentDescription = "Feedback", tint = Color.White)
                        }
                    }
                }

                if (isSearchOpen) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("उपकरण खोजें (उदा. कंपास, ब्याज, EMI...)", fontSize = 12.sp, color = Color.White.copy(alpha = 0.8f)) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color.White,
                            unfocusedBorderColor = Color.White.copy(alpha = 0.6f)
                        ),
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(imageVector = Icons.Default.Close, contentDescription = "Clear", tint = Color.White)
                                }
                            }
                        }
                    )
                }
            }
        }

        // 4-Column Grid Body matching the screenshot exactly
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color(0xFFF3F4F6)
        ) {
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize().testTag("smart_tools_grid")
            ) {
                items(filteredTools, key = { it.id }) { tool ->
                    SmartToolCard(
                        item = tool,
                        onClick = {
                            when (tool.id) {
                                "age_calc" -> showAgeCalculator = true
                                "age_diff" -> showAgeDiffDialog = true
                                "cash_count" -> showCashCounter = true
                                "stopwatch" -> showStopWatch = true

                                "bell_sound" -> activeSoundItem = SacredSoundItem(tool.id, "घंटी की आवाज़", "पूजा व आरती में बजने वाली पावन घंटी ध्वनि", "🔔", ToneGenerator.TONE_DTMF_D, 650, tool.pastelBg)
                                "om_sound" -> activeSoundItem = SacredSoundItem(tool.id, "Om Sound", "ॐ की पवित्र आध्यात्मिक नाद ध्वनि", "ॐ", ToneGenerator.TONE_DTMF_0, 1100, tool.pastelBg)
                                "dhol_sound" -> activeSoundItem = SacredSoundItem(tool.id, "ढोल-नगाड़ों की आवाज़", "उत्सव व मांगलिक कार्यों की नगाड़ा ध्वनि", "🥁", ToneGenerator.TONE_PROP_BEEP2, 500, tool.pastelBg)
                                "shankh_sound" -> activeSoundItem = SacredSoundItem(tool.id, "मंदिर के शंख की ध्वनि", "मंदिर की मंगलकारी शंख ध्वनि", "🐚", ToneGenerator.TONE_DTMF_0, 950, tool.pastelBg)

                                "pooja_bell" -> activeSoundItem = SacredSoundItem(tool.id, "पूजा की घंटी की आवाज़", "दैनिक देव पूजा घंटी नाद", "🔕", ToneGenerator.TONE_DTMF_D, 550, tool.pastelBg)
                                "temple_bell" -> activeSoundItem = SacredSoundItem(tool.id, "मंदिर की घंटी की ध्वनि", "भव्य देवालय घंटानाद", "🔔", ToneGenerator.TONE_DTMF_D, 850, tool.pastelBg)
                                "harmonium" -> activeSoundItem = SacredSoundItem(tool.id, "हारमोनियम की ध्वनि", "भजन व संकीर्तन की मधुर हारमोनियम तान", "🎹", ToneGenerator.TONE_PROP_ACK, 700, tool.pastelBg)
                                "shubh_sound" -> activeSoundItem = SacredSoundItem(tool.id, "शुभ ध्वनि", "शुभ मंगल कार्य शहनाई व वाद्य ध्वनि", "🎺", ToneGenerator.TONE_DTMF_9, 750, tool.pastelBg)

                                "compass" -> showVastuCompass = true
                                "notes" -> showNotesDialog = true
                                "simple_interest" -> showSimpleInterest = true
                                "compound_interest" -> showCompoundInterest = true

                                "emi_calc" -> showEmiCalculator = true
                                "gst_calc" -> showGstCalculator = true
                                "unit_converter" -> showUnitConverterDialog = true
                                "calendar_date" -> showCalendarDateDialog = true

                                "coin_toss" -> showCoinToss = true
                                "cash_book" -> showCashBookDialog = true
                                "ifsc" -> showIfscDialog = true
                                "speed_meter" -> showSpeedMeterDialog = true

                                "mileage_calc" -> showMileageDialog = true
                                "number_to_word" -> showNumberToWord = true
                                "percentage_calc" -> showPercentageDialog = true
                                "tracker" -> showHabitTrackerDialog = true

                                "world_clock" -> showWorldClockDialog = true
                                "bmi_calc" -> showBmiCalculator = true
                                "price_to_weight" -> showPriceToWeight = true
                                "weight_to_price" -> showWeightToPrice = true

                                "height_weight" -> showHeightWeightChartDialog = true
                                "counter" -> showTallyCounter = true
                                "simple_calc" -> showSimpleCalculatorDialog = true
                                "rd_calc" -> showRdCalculator = true

                                "tts" -> showTtsDialog = true
                                "stt" -> showSttDialog = true

                                "japa_mala" -> showJapaMala = true
                                "hora_chakra" -> showHoraChakra = true
                                "gun_milan" -> showGunMilan = true
                                "disha_shool" -> showDishaShool = true
                            }
                        }
                    )
                }
            }
        }
    }

    // Interactive Dialogs
    activeSoundItem?.let { sound ->
        SacredSoundPlayerDialog(soundItem = sound, onDismiss = { activeSoundItem = null })
    }

    if (showCashCounter) CashCounterDialog(onDismiss = { showCashCounter = false })
    if (showSimpleInterest) InterestCalculatorDialog(isCompound = false, onDismiss = { showSimpleInterest = false })
    if (showCompoundInterest) InterestCalculatorDialog(isCompound = true, onDismiss = { showCompoundInterest = false })
    if (showEmiCalculator) EmiCalculatorDialog(onDismiss = { showEmiCalculator = false })
    if (showGstCalculator) GstCalculatorDialog(onDismiss = { showGstCalculator = false })
    if (showRdCalculator) RdCalculatorDialog(onDismiss = { showRdCalculator = false })
    if (showStopWatch) StopWatchDialog(onDismiss = { showStopWatch = false })
    if (showCoinToss) CoinTossDialog(onDismiss = { showCoinToss = false })
    if (showNumberToWord) NumberToWordDialog(onDismiss = { showNumberToWord = false })
    if (showBmiCalculator) BmiCalculatorDialog(onDismiss = { showBmiCalculator = false })
    if (showPriceToWeight) PriceWeightCalculatorDialog(isPriceToWeight = true, onDismiss = { showPriceToWeight = false })
    if (showWeightToPrice) PriceWeightCalculatorDialog(isPriceToWeight = false, onDismiss = { showWeightToPrice = false })
    if (showTallyCounter) TallyCounterDialog(onDismiss = { showTallyCounter = false })
    if (showFeedbackDialog) FeedbackDialog(onDismissRequest = { showFeedbackDialog = false })

    if (showAgeDiffDialog) AgeDifferenceDialog(onDismiss = { showAgeDiffDialog = false })
    if (showNotesDialog) NotesDialog(onDismiss = { showNotesDialog = false })
    if (showUnitConverterDialog) UnitConverterDialog(onDismiss = { showUnitConverterDialog = false })
    if (showCalendarDateDialog) CalendarDateAddSubDialog(onDismiss = { showCalendarDateDialog = false })
    if (showCashBookDialog) CashBookDialog(onDismiss = { showCashBookDialog = false })
    if (showIfscDialog) IfscSearchDialog(onDismiss = { showIfscDialog = false })
    if (showSpeedMeterDialog) SpeedMeterDialog(onDismiss = { showSpeedMeterDialog = false })
    if (showMileageDialog) MileageCalculatorDialog(onDismiss = { showMileageDialog = false })
    if (showPercentageDialog) PercentageCalculatorDialog(onDismiss = { showPercentageDialog = false })
    if (showHabitTrackerDialog) HabitTrackerDialog(onDismiss = { showHabitTrackerDialog = false })
    if (showWorldClockDialog) WorldClockDialog(onDismiss = { showWorldClockDialog = false })
    if (showHeightWeightChartDialog) HeightWeightChartDialog(onDismiss = { showHeightWeightChartDialog = false })
    if (showSimpleCalculatorDialog) SimpleCalculatorDialog(onDismiss = { showSimpleCalculatorDialog = false })
    if (showTtsDialog) TextToSpeechDialog(onDismiss = { showTtsDialog = false })
    if (showSttDialog) SpeechToTextDialog(onDismiss = { showSttDialog = false })

    if (showVastuCompass) {
        Dialog(onDismissRequest = { showVastuCompass = false }) {
            Surface(modifier = Modifier.fillMaxWidth(0.96f).height(640.dp).clip(RoundedCornerShape(20.dp)), color = Color.White) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "🧭 वास्तु कंपास", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                        IconButton(onClick = { showVastuCompass = false }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                        }
                    }
                    VastuCompassTool()
                }
            }
        }
    }

    if (showJapaMala) {
        Dialog(onDismissRequest = { showJapaMala = false }) {
            Surface(modifier = Modifier.fillMaxWidth(0.96f).height(640.dp).clip(RoundedCornerShape(20.dp)), color = Color.White) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "📿 108 जाप माला", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                        IconButton(onClick = { showJapaMala = false }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                        }
                    }
                    JapaMalaCounterTool()
                }
            }
        }
    }

    if (showHoraChakra) {
        Dialog(onDismissRequest = { showHoraChakra = false }) {
            Surface(modifier = Modifier.fillMaxWidth(0.96f).height(640.dp).clip(RoundedCornerShape(20.dp)), color = Color.White) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "⭐ दैनिक होरा चक्र", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                        IconButton(onClick = { showHoraChakra = false }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                        }
                    }
                    HoraChakraTool(currentPanchang = currentPanchang)
                }
            }
        }
    }

    if (showGunMilan) {
        Dialog(onDismissRequest = { showGunMilan = false }) {
            Surface(modifier = Modifier.fillMaxWidth(0.96f).height(640.dp).clip(RoundedCornerShape(20.dp)), color = Color.White) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "💑 36 गुण मिलान", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                        IconButton(onClick = { showGunMilan = false }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                        }
                    }
                    GunMilanTool()
                }
            }
        }
    }

    if (showDishaShool) {
        Dialog(onDismissRequest = { showDishaShool = false }) {
            Surface(modifier = Modifier.fillMaxWidth(0.96f).height(600.dp).clip(RoundedCornerShape(20.dp)), color = Color.White) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "⚠️ दिशा शूल व परिहार", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                        IconButton(onClick = { showDishaShool = false }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                        }
                    }
                    DishaShoolTool(currentPanchang = currentPanchang)
                }
            }
        }
    }

    if (showAgeCalculator) {
        Dialog(onDismissRequest = { showAgeCalculator = false }) {
            Surface(modifier = Modifier.fillMaxWidth(0.96f).height(580.dp).clip(RoundedCornerShape(20.dp)), color = Color.White) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "🎂 आयु की गणना", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                        IconButton(onClick = { showAgeCalculator = false }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                        }
                    }
                    HinduAgeCalculatorTool(currentPanchang = currentPanchang)
                }
            }
        }
    }
}

// 4-Column Card View identical to user screenshot
@Composable
private fun SmartToolCard(
    item: SmartToolGridItem,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(104.dp)
            .clickable(onClick = onClick)
            .testTag("tool_${item.id}"),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
        shape = RoundedCornerShape(14.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 4.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Icon Pill matching the screenshot pastel backgrounds
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(item.pastelBg),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = item.emoji,
                    fontSize = 20.sp,
                    textAlign = TextAlign.Center
                )
            }

            // Title below icon
            Text(
                text = item.title,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF1E293B),
                textAlign = TextAlign.Center,
                lineHeight = 12.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
