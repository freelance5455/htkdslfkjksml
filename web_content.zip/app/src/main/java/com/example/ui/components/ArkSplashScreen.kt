package com.example.ui.components

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.min
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.example.R
import com.example.ui.theme.ArkThemeTokens
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.tan

private val LaunchBg = Color(0xFF030308)
private val LaunchEase = CubicBezierEasing(0.22f, 1f, 0.36f, 1f)
private val LaunchInOut = CubicBezierEasing(0.65f, 0f, 0.35f, 1f)
private val LaunchDriftEase = CubicBezierEasing(0.42f, 0f, 0.58f, 1f)
private const val TOTAL_LAUNCH_DURATION_MS = 3100

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

private fun lerpFloat(start: Float, stop: Float, fraction: Float): Float =
    start + (stop - start) * fraction

@Composable
fun ArkSplashScreen(
    onLaunchComplete: () -> Unit = {}
) {
    val context = LocalContext.current
    val view = LocalView.current
    val density = LocalDensity.current
    val currentOnLaunchComplete by rememberUpdatedState(onLaunchComplete)
    val completed = remember { AtomicBoolean(false) }

    val notifyComplete = remember {
        {
            if (completed.compareAndSet(false, true)) {
                currentOnLaunchComplete()
            }
        }
    }

    val activityWindow = remember(context) { context.findActivity()?.window }
    DisposableEffect(activityWindow, view) {
        val controller = activityWindow?.let { WindowCompat.getInsetsController(it, view) }
        val prevLightStatus = controller?.isAppearanceLightStatusBars
        val prevLightNav = controller?.isAppearanceLightNavigationBars
        controller?.isAppearanceLightStatusBars = false
        controller?.isAppearanceLightNavigationBars = false
        onDispose {
            if (prevLightStatus != null) controller.isAppearanceLightStatusBars = prevLightStatus
            if (prevLightNav != null) controller.isAppearanceLightNavigationBars = prevLightNav
        }
    }

    val elapsedMs = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        elapsedMs.animateTo(
            targetValue = TOTAL_LAUNCH_DURATION_MS.toFloat(),
            animationSpec = tween(
                durationMillis = TOTAL_LAUNCH_DURATION_MS,
                easing = LinearEasing
            )
        )
        notifyComplete()
    }

    val t = elapsedMs.value

    // Ambient fade in (50..1350ms) and fade out (2150..3250ms)
    val ambAlpha = when {
        t < 50f -> 0f
        t < 1350f -> LaunchEase.transform((t - 50f) / 1300f)
        t < 2150f -> 1f
        else -> (1f - LaunchInOut.transform(((t - 2150f) / 1100f).coerceIn(0f, 1f))).coerceIn(0f, 1f)
    }

    // Drift (0..3400ms)
    val driftProgress = LaunchDriftEase.transform((t / 3400f).coerceIn(0f, 1f))

    // Expand halo (2050..3250ms)
    val expandT = ((t - 2050f) / 1200f).coerceIn(0f, 1f)
    val expandScale = lerpFloat(0.35f, 1.1f, LaunchEase.transform(expandT))
    val expandAlpha = when {
        t <= 2050f -> 0f
        expandT < 0.35f -> expandT / 0.35f
        else -> (1f - (expandT - 0.35f) / 0.65f).coerceIn(0f, 1f)
    }

    // Group reveal (250..1600ms) and settle (2050..3100ms)
    val groupAlpha = when {
        t < 250f -> 0f
        t < 1600f -> LaunchEase.transform((t - 250f) / 1350f)
        t < 2050f -> 1f
        else -> (1f - LaunchInOut.transform(((t - 2050f) / 1050f).coerceIn(0f, 1f))).coerceIn(0f, 1f)
    }
    val groupScale = when {
        t < 250f -> 0.9f
        t < 1600f -> lerpFloat(0.9f, 1f, LaunchEase.transform((t - 250f) / 1350f))
        t < 2050f -> 1f
        else -> lerpFloat(1f, 0.9f, LaunchInOut.transform(((t - 2050f) / 1050f).coerceIn(0f, 1f)))
    }

    // Logo halo glow (350..2050ms)
    val glowT = ((t - 350f) / 1700f).coerceIn(0f, 1f)
    val glowScale = lerpFloat(0.85f, 1f, LaunchEase.transform(glowT))
    val glowAlpha = when {
        t <= 350f -> 0f
        glowT < 0.6f -> glowT / 0.6f
        else -> lerpFloat(1f, 0.85f, (glowT - 0.6f) / 0.4f)
    }

    // Tile diagonal light sweep (850..1900ms)
    val sweepT = ((t - 850f) / 1050f).coerceIn(0f, 1f)
    val sweepProgress = LaunchInOut.transform(sweepT)
    val sweepAlpha = when {
        t < 850f || t > 1900f -> 0f
        sweepT < 0.15f -> sweepT / 0.15f
        sweepT <= 0.85f -> 1f
        else -> (1f - (sweepT - 0.85f) / 0.15f).coerceIn(0f, 1f)
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(LaunchBg)
            .testTag("ark_launch_screen")
            .semantics { contentDescription = "ARK" },
        contentAlignment = Alignment.Center
    ) {
        val logoSizeDp = min(
            min(maxWidth * 0.68f, maxHeight * 0.46f),
            320.dp
        )
        val groupGapDp = (maxHeight * 0.045f).coerceIn(18.dp, 34.dp)
        val tagFontSp = (maxWidth.value * 0.031f).coerceIn(11f, 14f).sp
        val tagLetterSpacing = 0.34.em

        // Ambient radial glows + expand wave + vignette
        Canvas(modifier = Modifier.fillMaxSize()) {
            val vmax = max(size.width, size.height)
            val cx = size.width * 0.5f
            val cy = size.height * 0.5f

            if (ambAlpha > 0.001f) {
                // a1: 120vmax purple glow
                val a1Size = vmax * 1.20f
                val a1Scale = lerpFloat(0.92f, 1.06f, driftProgress)
                val a1Radius = (a1Size * 0.5f) * a1Scale
                val a1Center = Offset(
                    x = cx - vmax * 0.15f + a1Size * lerpFloat(-0.04f, 0.04f, driftProgress),
                    y = cy + a1Size * lerpFloat(0.02f, -0.02f, driftProgress)
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        0.0f to Color(0x4D7048FF).copy(alpha = 0.30f * ambAlpha),
                        0.62f to Color.Transparent,
                        1.0f to Color.Transparent,
                        center = a1Center,
                        radius = a1Radius
                    ),
                    radius = a1Radius,
                    center = a1Center
                )

                // a2: 110vmax blue glow (reverse drift)
                val a2Size = vmax * 1.10f
                val a2Scale = lerpFloat(1.06f, 0.92f, driftProgress)
                val a2Radius = (a2Size * 0.5f) * a2Scale
                val a2Center = Offset(
                    x = cx + vmax * 0.20f + a2Size * lerpFloat(0.04f, -0.04f, driftProgress),
                    y = cy + vmax * 0.03f + a2Size * lerpFloat(-0.02f, 0.02f, driftProgress)
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        0.0f to Color(0x422E62FF).copy(alpha = 0.26f * ambAlpha),
                        0.62f to Color.Transparent,
                        1.0f to Color.Transparent,
                        center = a2Center,
                        radius = a2Radius
                    ),
                    radius = a2Radius,
                    center = a2Center
                )
            }

            if (expandAlpha > 0.001f) {
                val expandRadius = (vmax * 0.75f) * expandScale
                drawCircle(
                    brush = Brush.radialGradient(
                        0.0f to Color(0xFF6E50FF).copy(alpha = 0.16f * expandAlpha),
                        0.38f to Color(0xFF3264FF).copy(alpha = 0.07f * expandAlpha),
                        0.62f to Color.Transparent,
                        1.0f to Color.Transparent,
                        center = Offset(cx, cy),
                        radius = expandRadius
                    ),
                    radius = expandRadius,
                    center = Offset(cx, cy)
                )
            }

            // Subtle dark vignette
            val vigRadius = max(size.width, size.height) * 0.72f
            drawRect(
                brush = Brush.radialGradient(
                    0.0f to Color.Transparent,
                    0.45f to Color.Transparent,
                    1.0f to Color(0x8C000000),
                    center = Offset(cx, cy),
                    radius = vigRadius
                )
            )
        }

        // Logo + staggered tagline group
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.graphicsLayer {
                alpha = groupAlpha
                scaleX = groupScale
                scaleY = groupScale
            }
        ) {
            Box(
                modifier = Modifier.size(logoSizeDp),
                contentAlignment = Alignment.Center
            ) {
                // Logo halo ring (.logo::before)
                if (glowAlpha > 0.001f) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                val haloFactor = 1.32f * glowScale
                                scaleX = haloFactor
                                scaleY = haloFactor
                            }
                    ) {
                        val radius = size.minDimension * 0.5f
                        drawCircle(
                            brush = Brush.radialGradient(
                                0.0f to Color.Transparent,
                                0.40f to Color.Transparent,
                                0.55f to Color(0xFF7D55FF).copy(alpha = 0.34f * glowAlpha),
                                0.66f to Color(0xFF3769FF).copy(alpha = 0.12f * glowAlpha),
                                0.76f to Color.Transparent,
                                1.0f to Color.Transparent,
                                center = center,
                                radius = radius
                            ),
                            radius = radius
                        )
                    }
                }

                // Glass logo image + confined light sweep
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            compositingStrategy = CompositingStrategy.Offscreen
                        }
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ark_launch_logo),
                        contentDescription = "ARK Logo",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )

                    if (sweepAlpha > 0.001f) {
                        val tileWidthDp = logoSizeDp * 0.848f
                        val tileHeightDp = logoSizeDp * 0.855f
                        val tileOffsetX = logoSizeDp * 0.076f
                        val tileOffsetY = logoSizeDp * 0.070f

                        Canvas(
                            modifier = Modifier
                                .offset(x = tileOffsetX, y = tileOffsetY)
                                .size(width = tileWidthDp, height = tileHeightDp)
                                .clip(RoundedCornerShape(percent = 20))
                        ) {
                            val beamWidth = size.width * 0.46f
                            val startX = -size.width * 0.60f
                            val travelX = beamWidth * 4.30f * sweepProgress
                            val leftX = startX + travelX
                            val topY = -size.height * 0.20f
                            val bottomY = size.height * 1.20f
                            val skewDx = (bottomY - topY) * tan(Math.toRadians(18.0)).toFloat()

                            val beamPath = Path().apply {
                                moveTo(leftX + skewDx * 0.5f, topY)
                                lineTo(leftX + beamWidth + skewDx * 0.5f, topY)
                                lineTo(leftX + beamWidth - skewDx * 0.5f, bottomY)
                                lineTo(leftX - skewDx * 0.5f, bottomY)
                                close()
                            }

                            withTransform({
                                clipPath(beamPath)
                            }) {
                                drawRect(
                                    brush = Brush.linearGradient(
                                        0.00f to Color.Transparent,
                                        0.18f to Color(0xFF96AAFF).copy(alpha = 0f),
                                        0.46f to Color(0xFFBECDFE).copy(alpha = 0.34f * sweepAlpha),
                                        0.52f to Color.White.copy(alpha = 0.55f * sweepAlpha),
                                        0.60f to Color(0xFFBEAAFF).copy(alpha = 0.28f * sweepAlpha),
                                        0.82f to Color.Transparent,
                                        1.00f to Color.Transparent,
                                        start = Offset(leftX, size.height * 0.5f),
                                        end = Offset(leftX + beamWidth, size.height * 0.5f)
                                    ),
                                    topLeft = Offset(leftX - skewDx, topY),
                                    size = Size(beamWidth + skewDx * 2f, bottomY - topY),
                                    blendMode = BlendMode.Screen
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(groupGapDp))

            // Staggered tagline: "Moments • Squads • Play"
            val risePx = with(density) { 6.dp.toPx() }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(11.dp),
                modifier = Modifier.padding(start = 4.dp)
            ) {
                TagWord(text = "Moments", delayMs = 1150f, t = t, risePx = risePx, fontSize = tagFontSp, letterSpacing = tagLetterSpacing)
                TagDot(delayMs = 1200f, t = t, risePx = risePx)
                TagWord(text = "Squads", delayMs = 1270f, t = t, risePx = risePx, fontSize = tagFontSp, letterSpacing = tagLetterSpacing)
                TagDot(delayMs = 1320f, t = t, risePx = risePx)
                TagWord(text = "Play", delayMs = 1390f, t = t, risePx = risePx, fontSize = tagFontSp, letterSpacing = tagLetterSpacing)
            }
        }
    }
}

@Composable
private fun TagWord(
    text: String,
    delayMs: Float,
    t: Float,
    risePx: Float,
    fontSize: androidx.compose.ui.unit.TextUnit,
    letterSpacing: androidx.compose.ui.unit.TextUnit
) {
    val progress = LaunchEase.transform(((t - delayMs) / 900f).coerceIn(0f, 1f))
    Text(
        text = text,
        color = Color.White.copy(alpha = 0.72f),
        fontSize = fontSize,
        fontWeight = FontWeight.Medium,
        letterSpacing = letterSpacing,
        maxLines = 1,
        modifier = Modifier.graphicsLayer {
            alpha = progress
            translationY = risePx * (1f - progress)
        }
    )
}

@Composable
private fun TagDot(
    delayMs: Float,
    t: Float,
    risePx: Float
) {
    val progress = LaunchEase.transform(((t - delayMs) / 900f).coerceIn(0f, 1f))
    Box(
        modifier = Modifier
            .size(3.dp)
            .graphicsLayer {
                alpha = 0.8f * progress
                translationY = risePx * (1f - progress)
            }
            .clip(CircleShape)
            .background(Color(0xFF968CFF))
    )
}

@Composable
fun ArkPostLaunchLoadingScreen() {
    val context = LocalContext.current
    val view = LocalView.current
    val activityWindow = remember(context) { context.findActivity()?.window }
    DisposableEffect(activityWindow, view) {
        val controller = activityWindow?.let { WindowCompat.getInsetsController(it, view) }
        val prevLightStatus = controller?.isAppearanceLightStatusBars
        val prevLightNav = controller?.isAppearanceLightNavigationBars
        controller?.isAppearanceLightStatusBars = false
        controller?.isAppearanceLightNavigationBars = false
        onDispose {
            if (prevLightStatus != null) controller.isAppearanceLightStatusBars = prevLightStatus
            if (prevLightNav != null) controller.isAppearanceLightNavigationBars = prevLightNav
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(LaunchBg),
        contentAlignment = Alignment.Center
    ) {
        CircularProgressIndicator(
            modifier = Modifier.size(28.dp),
            color = ArkThemeTokens.colors.accent,
            strokeWidth = 2.5.dp
        )
    }
}
