package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.EditNote
import androidx.compose.material.icons.outlined.GraphicEq
import androidx.compose.material.icons.outlined.ImageSearch
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.theme.NexusBackground
import com.example.ui.theme.NexusBorder
import com.example.ui.theme.NexusCyan
import com.example.ui.theme.NexusCyanDark
import com.example.ui.theme.NexusSurface
import com.example.ui.theme.NexusTextPrimary
import com.example.ui.theme.NexusTextSecondary
import com.example.ui.theme.NexusTextTertiary
import com.example.ui.theme.NexusVioletLight
import com.example.ui.theme.SpaceGroteskFontFamily

enum class NexusToolType(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val tag: String
) {
    IMAGE_ANALYSIS(
        title = "Анализ изображений",
        subtitle = "Загрузка фото, распознавание текста, схем и деталей",
        icon = Icons.Outlined.ImageSearch,
        tag = "tool_card_image"
    ),
    DOCUMENTS(
        title = "Работа с документами",
        subtitle = "Анализ PDF, исходного кода, таблиц, видео и аудио",
        icon = Icons.Outlined.Description,
        tag = "tool_card_documents"
    ),
    VOICE(
        title = "Голосовой помощник",
        subtitle = "Отдельный голосовой диалог, профиль Алисы и озвучка текста",
        icon = Icons.Outlined.GraphicEq,
        tag = "tool_card_voice"
    ),
    TEXT_GENERATION(
        title = "Генерация текста",
        subtitle = "Статьи, деловые письма, код, планы и редактура",
        icon = Icons.Outlined.EditNote,
        tag = "tool_card_textgen"
    ),
    OTHER_AI(
        title = "Другие функции ИИ",
        subtitle = "Синтез всех ИИ, выбор версии Gemini и режимы ответа",
        icon = Icons.Outlined.AutoAwesome,
        tag = "tool_card_other"
    )
}

@Composable
fun ToolsScreen(
    viewModel: MainViewModel,
    onNavigateToChat: () -> Unit,
    onNavigateToVoice: () -> Unit,
    onNavigateToSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    var activeTool by rememberSaveable { mutableStateOf<NexusToolType?>(null) }

    BackHandler(enabled = activeTool != null) {
        activeTool = null
    }

    when (activeTool) {
        null -> {
            Column(
                modifier = modifier
                    .fillMaxSize()
                    .background(NexusBackground)
                    .statusBarsPadding()
                    .navigationBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onNavigateToChat,
                        modifier = Modifier
                            .size(44.dp)
                            .testTag("tools_back_to_chat_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Назад в чат",
                            tint = NexusTextPrimary
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Инструменты",
                        fontFamily = SpaceGroteskFontFamily,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NexusTextPrimary
                    )
                }

                HorizontalDivider(thickness = 0.8.dp, color = NexusBorder)

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.TopCenter
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .widthIn(max = 700.dp)
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 18.dp, vertical = 18.dp)
                    ) {
                        Text(
                            text = "РАБОЧИЕ МОДУЛИ",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = NexusTextTertiary,
                            modifier = Modifier.padding(start = 6.dp, bottom = 10.dp)
                        )

                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = NexusSurface,
                            border = BorderStroke(0.8.dp, NexusBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                NexusToolType.values().forEachIndexed { idx, tool ->
                                    ToolHubRow(
                                        tool = tool,
                                        onClick = {
                                            if (tool == NexusToolType.VOICE) {
                                                onNavigateToVoice()
                                            } else {
                                                viewModel.clearToolOutput()
                                                activeTool = tool
                                            }
                                        }
                                    )
                                    if (idx < NexusToolType.values().lastIndex) {
                                        HorizontalDivider(thickness = 0.8.dp, color = NexusBorder)
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(22.dp))

                        Text(
                            text = "ПАРАМЕТРЫ СИСТЕМЫ",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = NexusTextTertiary,
                            modifier = Modifier.padding(start = 6.dp, bottom = 10.dp)
                        )

                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = NexusSurface,
                            border = BorderStroke(0.8.dp, NexusBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onNavigateToSettings() }
                                .testTag("tools_open_settings")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(RoundedCornerShape(11.dp))
                                        .background(NexusCyanDark)
                                        .border(0.8.dp, NexusCyan.copy(alpha = 0.4f), RoundedCornerShape(11.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.Settings,
                                        contentDescription = null,
                                        tint = NexusVioletLight,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(14.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Настройки ИИ и голоса",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = NexusTextPrimary
                                    )
                                    Text(
                                        text = "Модели Gemini, имя ассистента и голосовые профили",
                                        fontSize = 12.sp,
                                        color = NexusTextSecondary
                                    )
                                }
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                                    contentDescription = null,
                                    tint = NexusTextTertiary,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
        NexusToolType.IMAGE_ANALYSIS -> ImageAnalysisToolPage(
            viewModel = viewModel,
            onBack = { activeTool = null },
            onMovedToChat = {
                activeTool = null
                onNavigateToChat()
            },
            modifier = modifier
        )
        NexusToolType.DOCUMENTS -> DocumentWorkToolPage(
            viewModel = viewModel,
            onBack = { activeTool = null },
            onMovedToChat = {
                activeTool = null
                onNavigateToChat()
            },
            modifier = modifier
        )
        NexusToolType.VOICE -> VoiceScreen(
            viewModel = viewModel,
            onNavigateToChat = onNavigateToChat,
            onOpenSettings = onNavigateToSettings,
            modifier = modifier
        )
        NexusToolType.TEXT_GENERATION -> TextGenerationToolPage(
            viewModel = viewModel,
            onBack = { activeTool = null },
            onMovedToChat = {
                activeTool = null
                onNavigateToChat()
            },
            modifier = modifier
        )
        NexusToolType.OTHER_AI -> OtherAiToolPage(
            viewModel = viewModel,
            onBack = { activeTool = null },
            onOpenSettings = {
                activeTool = null
                onNavigateToSettings()
            },
            modifier = modifier
        )
    }
}

@Composable
private fun ToolHubRow(
    tool: NexusToolType,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp)
            .testTag(tool.tag),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(11.dp))
                    .background(NexusCyanDark)
                    .border(0.8.dp, NexusCyan.copy(alpha = 0.4f), RoundedCornerShape(11.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = tool.icon,
                    contentDescription = null,
                    tint = NexusVioletLight,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column {
                Text(
                    text = tool.title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                    color = NexusTextPrimary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = tool.subtitle,
                    fontSize = 12.sp,
                    color = NexusTextSecondary,
                    lineHeight = 16.sp
                )
            }
        }
        Spacer(modifier = Modifier.width(8.dp))
        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
            contentDescription = null,
            tint = NexusTextTertiary,
            modifier = Modifier.size(14.dp)
        )
    }
}
