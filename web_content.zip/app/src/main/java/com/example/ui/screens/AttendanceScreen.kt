package com.example.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.EventBusy
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.AttendanceRecord
import com.example.model.AttendanceStatus
import com.example.model.Student
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.KpiStatTile
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CrimsonContainer
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.GoldSecondary
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.viewmodel.SchoolDashboardData
import com.example.viewmodel.SchoolViewModel
import java.util.Calendar
import java.util.Locale

@Composable
fun AttendanceScreen(
    data: SchoolDashboardData,
    viewModel: SchoolViewModel,
) {
    val activeClass = data.activeClass
    val context = LocalContext.current

    if (activeClass == null || data.students.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) {
            EmptyStateCard(
                icon = Icons.Rounded.EventBusy,
                title = "No Students to Track Attendance",
                subtitle = "Add students in Marks or Customize to start recording daily attendance.",
            )
        }
        return
    }

    val classAttendanceAllDates = data.allAttendance.filter { it.classId == activeClass.id }
    val statusByStudent = data.students.associateWith { stu ->
        AttendanceStatus.fromRaw(data.attendanceForDate[stu.id]?.status ?: AttendanceStatus.PRESENT.name)
    }
    val presentCount = statusByStudent.values.count { it == AttendanceStatus.PRESENT }
    val lateCount = statusByStudent.values.count { it == AttendanceStatus.LATE }
    val absentCount = statusByStudent.values.count { it == AttendanceStatus.ABSENT }
    val excusedCount = statusByStudent.values.count { it == AttendanceStatus.EXCUSED }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        // Date Navigation & KPI Summary Card
        item(key = "attendance_header") {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = "DAILY ATTENDANCE • ${activeClass.name}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        TextButton(onClick = { viewModel.setTodayDate() }) {
                            Text("Today")
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        FilledTonalIconButton(
                            onClick = { viewModel.stepDate(-1) },
                            modifier = Modifier.size(48.dp),
                        ) {
                            Icon(Icons.AutoMirrored.Rounded.KeyboardArrowLeft, contentDescription = "Previous day")
                        }

                        OutlinedButton(
                            onClick = {
                                val parts = data.activeDateKey.split("-")
                                val cal = Calendar.getInstance()
                                val y = parts.getOrNull(0)?.toIntOrNull() ?: cal.get(Calendar.YEAR)
                                val m = (parts.getOrNull(1)?.toIntOrNull()?.minus(1)) ?: cal.get(Calendar.MONTH)
                                val d = parts.getOrNull(2)?.toIntOrNull() ?: cal.get(Calendar.DAY_OF_MONTH)
                                DatePickerDialog(context, { _, year, month, day ->
                                    val formatted = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, day)
                                    viewModel.selectDate(formatted)
                                }, y, m, d).show()
                            },
                            modifier = Modifier.weight(1f).height(48.dp).testTag("attendance_date_button"),
                            shape = RoundedCornerShape(14.dp),
                        ) {
                            Icon(Icons.Rounded.CalendarMonth, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = data.activeDateKey,
                                fontFamily = JetBrainsMonoFamily,
                                style = MaterialTheme.typography.titleSmall,
                            )
                        }

                        FilledTonalIconButton(
                            onClick = { viewModel.stepDate(1) },
                            modifier = Modifier.size(48.dp),
                        ) {
                            Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, contentDescription = "Next day")
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        KpiStatTile("Present", "$presentCount", EmeraldSuccess, EmeraldContainer, Modifier.weight(1f))
                        KpiStatTile("Late", "$lateCount", GoldSecondary, GoldContainer, Modifier.weight(1f))
                        KpiStatTile("Absent", "$absentCount", CrimsonAlert, CrimsonContainer, Modifier.weight(1f))
                        KpiStatTile("Excused", "$excusedCount", MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.primaryContainer, Modifier.weight(1f))
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        FilledTonalButton(
                            onClick = {
                                viewModel.markAllPresent(
                                    classId = activeClass.id,
                                    students = data.students,
                                    existingForDate = data.attendanceForDate,
                                    dateKey = data.activeDateKey,
                                )
                            },
                            modifier = Modifier.weight(1f).height(46.dp).testTag("mark_all_present_button"),
                            shape = RoundedCornerShape(12.dp),
                        ) {
                            Icon(Icons.Rounded.DoneAll, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("All Present", maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }

                        Button(
                            onClick = {
                                viewModel.syncAttendanceToReportCards(
                                    students = data.students,
                                    classAttendance = classAttendanceAllDates,
                                )
                            },
                            modifier = Modifier.weight(1.2f).height(46.dp).testTag("sync_attendance_reports_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        ) {
                            Icon(Icons.Rounded.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Sync to Reports", maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }

        // Student Attendance Rows
        items(data.students, key = { "${data.activeDateKey}_${it.id}" }) { stu ->
            val record = data.attendanceForDate[stu.id]
            val currentStatus = AttendanceStatus.fromRaw(record?.status ?: AttendanceStatus.PRESENT.name)
            val totalLates = classAttendanceAllDates.count { it.studentId == stu.id && it.status == AttendanceStatus.LATE.name }
            val totalAbsences = classAttendanceAllDates.count { it.studentId == stu.id && it.status == AttendanceStatus.ABSENT.name }

            StudentAttendanceCard(
                student = stu,
                record = record,
                currentStatus = currentStatus,
                totalLates = totalLates,
                totalAbsences = totalAbsences,
                onStatusSelected = { newStatus, note ->
                    viewModel.setAttendanceStatus(
                        classId = activeClass.id,
                        studentId = stu.id,
                        dateKey = data.activeDateKey,
                        status = newStatus,
                        note = note,
                    )
                },
            )
        }
    }
}

@Composable
private fun StudentAttendanceCard(
    student: Student,
    record: AttendanceRecord?,
    currentStatus: AttendanceStatus,
    totalLates: Int,
    totalAbsences: Int,
    onStatusSelected: (AttendanceStatus, String) -> Unit,
) {
    var noteDraft by remember(student.id, record?.dateKey, record?.note) {
        mutableStateOf(record?.note.orEmpty())
    }
    var showNoteBox by remember { mutableStateOf(!record?.note.isNullOrBlank()) }

    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = student.name,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = "Term totals: $totalLates Late • $totalAbsences Absent",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }

                TextButton(onClick = { showNoteBox = !showNoteBox }) {
                    Text(if (showNoteBox) "Hide Note" else "+ Note")
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                AttendanceStatus.entries.forEach { st ->
                    val selected = st == currentStatus
                    val (selectedBg, selectedFg) = when (st) {
                        AttendanceStatus.PRESENT -> EmeraldContainer to EmeraldSuccess
                        AttendanceStatus.LATE -> GoldContainer to GoldSecondary
                        AttendanceStatus.ABSENT -> CrimsonContainer to CrimsonAlert
                        AttendanceStatus.EXCUSED -> MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.primary
                    }
                    FilterChip(
                        selected = selected,
                        onClick = { onStatusSelected(st, noteDraft) },
                        label = {
                            Text(
                                text = st.label,
                                style = MaterialTheme.typography.labelSmall,
                                maxLines = 1,
                            )
                        },
                        leadingIcon = if (selected) {
                            { Icon(Icons.Rounded.CheckCircle, contentDescription = null, modifier = Modifier.size(14.dp)) }
                        } else null,
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = selectedBg,
                            selectedLabelColor = selectedFg,
                            selectedLeadingIconColor = selectedFg,
                        ),
                        modifier = Modifier.weight(1f),
                    )
                }
            }

            if (showNoteBox) {
                OutlinedTextField(
                    value = noteDraft,
                    onValueChange = {
                        noteDraft = it
                        onStatusSelected(currentStatus, it)
                    },
                    label = { Text("Reason / Note") },
                    placeholder = { Text("e.g. Medical appointment") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}
