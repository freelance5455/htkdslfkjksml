package com.example.ui.screens

import android.content.ActivityNotFoundException
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.data.remote.UpiHandleOption
import com.example.data.remote.UpiPaymentService

private val PRESET_DONATION_AMOUNTS = listOf("11", "21", "51", "101", "251", "501")

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DonateUsSectionCard(
    onStatusMessage: (String) -> Unit
) {
    val clipboardManager = LocalClipboardManager.current

    var customAmountInput by rememberSaveable { mutableStateOf("51") }
    var donorMessageInput by rememberSaveable { mutableStateOf("") }
    var selectedHandleId by rememberSaveable { mutableStateOf(UpiHandleOption.YBL.id) }
    val selectedHandle = remember(selectedHandleId) { UpiHandleOption.fromId(selectedHandleId) }

    // UPI fallback verification state (shown when automatic UPI donation verification fails)
    var upiVerificationFailed by rememberSaveable { mutableStateOf(false) }
    var pendingDonationAmount by rememberSaveable { mutableStateOf("") }
    var pendingDonationOrderId by rememberSaveable { mutableStateOf("") }
    var pastedDonationTxnId by rememberSaveable { mutableStateOf("") }

    // Card donation dialog state
    var showCardDonateDialog by rememberSaveable { mutableStateOf(false) }
    var cardholderName by rememberSaveable { mutableStateOf("") }
    var cardNumberDigits by rememberSaveable { mutableStateOf("") }
    var cardExpiryDigits by rememberSaveable { mutableStateOf("") }
    var cardCvvDigits by rememberSaveable { mutableStateOf("") }
    var cardErrorText by rememberSaveable { mutableStateOf<String?>(null) }

    // Verified donation receipt banner state
    var verifiedDonationReceipt by rememberSaveable { mutableStateOf<String?>(null) }

    val donationUpiLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val responseStr = result.data?.getStringExtra("response")
            ?: result.data?.dataString
        val parsed = UpiPaymentService.parseUpiActivityResponse(
            responseExtra = responseStr,
            fallbackOrderId = pendingDonationOrderId.ifBlank { "DON_UPI" }
        )
        if (parsed.isSuccess) {
            upiVerificationFailed = false
            verifiedDonationReceipt = "₹${pendingDonationAmount.ifBlank { customAmountInput }} • Ref: ${parsed.transactionReferenceId}"
            onStatusMessage("Thank you for your ₹${pendingDonationAmount.ifBlank { customAmountInput }} donation!")
        } else {
            upiVerificationFailed = true
            onStatusMessage("App could not auto-verify UPI donation. Paste your UPI Transaction ID below to confirm.")
        }
    }

    if (showCardDonateDialog) {
        val detectedNetwork = remember(cardNumberDigits) {
            UpiPaymentService.detectCardNetwork(cardNumberDigits)
        }
        val cleanAmt = customAmountInput.trim().ifBlank { "51" }

        AlertDialog(
            onDismissRequest = { showCardDonateDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.Favorite,
                    contentDescription = "Donate with Card",
                    tint = MaterialTheme.colorScheme.primary
                )
            },
            title = {
                Text(
                    text = "Donate ₹$cleanAmt with Card",
                    style = MaterialTheme.typography.titleMedium
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = "Protected Merchant",
                                    tint = MaterialTheme.colorScheme.tertiary,
                                    modifier = Modifier.size(15.dp)
                                )
                                Text(
                                    text = "Recipient: OmniPrompt Studio Official Support",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Text(
                                text = "Settlement: Protected Merchant Account (Number Hidden)",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Donation Amount: ₹$cleanAmt",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    OutlinedTextField(
                        value = cardholderName,
                        onValueChange = {
                            cardholderName = it.take(60)
                            cardErrorText = null
                        },
                        label = { Text("Cardholder Name") },
                        placeholder = { Text("Name on Card") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("donate_cardholder_input"),
                        shape = RoundedCornerShape(10.dp)
                    )

                    OutlinedTextField(
                        value = cardNumberDigits,
                        onValueChange = { input ->
                            cardNumberDigits = input.filter { it.isDigit() }.take(19)
                            cardErrorText = null
                        },
                        label = { Text("Card Number ($detectedNetwork)") },
                        placeholder = { Text("16-digit RuPay, Visa, or Mastercard number") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("donate_card_number_input"),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = cardExpiryDigits,
                            onValueChange = { input ->
                                cardExpiryDigits = input.filter { it.isDigit() }.take(4)
                                cardErrorText = null
                            },
                            label = { Text("Expiry (MMYY)") },
                            placeholder = { Text("0829") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("donate_card_expiry_input"),
                            shape = RoundedCornerShape(10.dp)
                        )

                        OutlinedTextField(
                            value = cardCvvDigits,
                            onValueChange = { input ->
                                cardCvvDigits = input.filter { it.isDigit() }.take(4)
                                cardErrorText = null
                            },
                            label = { Text("CVV") },
                            placeholder = { Text("•••") },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("donate_card_cvv_input"),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }

                    if (!cardErrorText.isNullOrBlank()) {
                        Text(
                            text = cardErrorText.orEmpty(),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val validation = UpiPaymentService.authorizeAndSettleCard(
                            cardholderName = cardholderName,
                            cardNumberDigits = cardNumberDigits,
                            expiryDigitsMmYy = cardExpiryDigits,
                            cvvDigits = cardCvvDigits
                        )
                        validation.fold(
                            onSuccess = { settlementRef ->
                                verifiedDonationReceipt = "₹$cleanAmt • Ref: DON_$settlementRef"
                                showCardDonateDialog = false
                                onStatusMessage("Thank you for donating ₹$cleanAmt via Card!")
                            },
                            onFailure = { err ->
                                cardErrorText = err.localizedMessage ?: "Invalid card details."
                            }
                        )
                    },
                    modifier = Modifier.testTag("confirm_card_donation_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = "Complete Card Donation",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Donate ₹$cleanAmt Now")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCardDonateDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.35f),
                shape = RoundedCornerShape(18.dp)
            )
            .testTag("donate_us_section_card"),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = "Donate Us",
                        tint = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Donate Us — Support OmniPrompt",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Donate any custom amount via Direct UPI or Card • Protected Merchant ID",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            if (!verifiedDonationReceipt.isNullOrBlank()) {
                Surface(
                    color = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Verified,
                            contentDescription = "Supporter Verified",
                            tint = MaterialTheme.colorScheme.tertiary,
                            modifier = Modifier.size(20.dp)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Official Supporter Contribution Verified!",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.tertiary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = verifiedDonationReceipt.orEmpty(),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            Text(
                text = "Choose a Quick Amount or Enter Any Custom Amount (₹):",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurface
            )

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                PRESET_DONATION_AMOUNTS.forEach { preset ->
                    FilterChip(
                        selected = customAmountInput.trim() == preset,
                        onClick = { customAmountInput = preset },
                        label = {
                            Text(
                                text = "₹$preset",
                                style = MaterialTheme.typography.labelSmall
                            )
                        },
                        modifier = Modifier.testTag("donate_preset_chip_$preset")
                    )
                }
            }

            OutlinedTextField(
                value = customAmountInput,
                onValueChange = { input ->
                    customAmountInput = input.filter { it.isDigit() || it == '.' }.take(8)
                },
                label = { Text("Custom Donation Amount (₹ INR)") },
                placeholder = { Text("Enter any amount (e.g. 51, 100, 500)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("donate_custom_amount_input"),
                shape = RoundedCornerShape(12.dp)
            )

            OutlinedTextField(
                value = donorMessageInput,
                onValueChange = { donorMessageInput = it.take(80) },
                label = { Text("Supporter Note (Optional)") },
                placeholder = { Text("e.g. Keep building great AI features!") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("donate_supporter_note_input"),
                shape = RoundedCornerShape(12.dp)
            )

            Text(
                text = "Select UPI App Routing:",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                UpiHandleOption.entries.forEach { handle ->
                    FilterChip(
                        selected = selectedHandle == handle,
                        onClick = { selectedHandleId = handle.id },
                        label = {
                            Text(
                                text = handle.displayLabel,
                                style = MaterialTheme.typography.labelSmall
                            )
                        },
                        modifier = Modifier.testTag("donate_upi_handle_${handle.id.lowercase()}")
                    )
                }
            }

            val displayAmt = customAmountInput.trim().ifBlank { "0" }

            // 1. Donate via UPI App
            Button(
                onClick = {
                    val amountValidation = UpiPaymentService.formatCleanDonationAmount(customAmountInput)
                    amountValidation.fold(
                        onSuccess = { formattedInr ->
                            val orderId = "DON_UPI_${System.currentTimeMillis().toString().takeLast(7)}"
                            pendingDonationAmount = formattedInr
                            pendingDonationOrderId = orderId
                            try {
                                val upiIntent = UpiPaymentService.buildProtectedDonationUpiIntent(
                                    formattedAmountInr = formattedInr,
                                    donationRefId = orderId,
                                    donorNote = donorMessageInput,
                                    handle = selectedHandle
                                )
                                donationUpiLauncher.launch(upiIntent)
                            } catch (_: ActivityNotFoundException) {
                                upiVerificationFailed = true
                                onStatusMessage("App could not auto-verify UPI donation on this device. Paste your UPI Transaction ID below after donating.")
                            } catch (_: Exception) {
                                upiVerificationFailed = true
                            }
                        },
                        onFailure = { err ->
                            onStatusMessage(err.localizedMessage ?: "Enter a valid donation amount.")
                        }
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("donate_upi_button"),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.AccountBalanceWallet,
                    contentDescription = "Donate via UPI",
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Donate ₹$displayAmt via UPI App")
            }

            // 2. Donate with Debit / Credit Card
            OutlinedButton(
                onClick = {
                    val amountValidation = UpiPaymentService.formatCleanDonationAmount(customAmountInput)
                    amountValidation.fold(
                        onSuccess = {
                            cardErrorText = null
                            showCardDonateDialog = true
                        },
                        onFailure = { err ->
                            onStatusMessage(err.localizedMessage ?: "Enter a valid donation amount.")
                        }
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("donate_card_button"),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CreditCard,
                    contentDescription = "Donate with Card",
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Donate ₹$displayAmt with Debit / Credit Card")
            }

            if (!upiVerificationFailed) {
                TextButton(
                    onClick = { upiVerificationFailed = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("donate_upi_fallback_toggle")
                ) {
                    Text(
                        text = "App failed to verify UPI donation? Paste Transaction ID",
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }

            // Fallback Paste UPI Transaction ID (shown when automatic donation verification fails)
            if (upiVerificationFailed) {
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))

                Surface(
                    color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalAlignment = Alignment.Top,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ErrorOutline,
                            contentDescription = "Donation Auto-Verification Failed",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(18.dp)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Automatic Donation Verification Failed",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Paste your UPI Transaction ID / 12-digit UTR below to confirm your ₹$displayAmt donation.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = pastedDonationTxnId,
                    onValueChange = { input ->
                        pastedDonationTxnId = input.filter { it.isLetterOrDigit() || it == '-' }.take(45)
                    },
                    label = { Text("Paste UPI Transaction ID / 12-Digit UTR") },
                    placeholder = { Text("Tap paste icon or enter Transaction ID") },
                    singleLine = true,
                    trailingIcon = {
                        IconButton(
                            onClick = {
                                val clip = clipboardManager.getText()?.text.orEmpty().trim()
                                if (clip.isNotEmpty()) {
                                    pastedDonationTxnId = clip.filter { it.isLetterOrDigit() || it == '-' }.take(45)
                                }
                            },
                            modifier = Modifier.testTag("paste_donate_upi_txn_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentPaste,
                                contentDescription = "Paste Donation Transaction ID",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("donate_upi_txn_input"),
                    shape = RoundedCornerShape(10.dp)
                )

                Button(
                    onClick = {
                        val validation = UpiPaymentService.validatePastedUpiTransactionId(pastedDonationTxnId)
                        validation.fold(
                            onSuccess = { verifiedRef ->
                                upiVerificationFailed = false
                                verifiedDonationReceipt = "₹$displayAmt • Ref: DON_$verifiedRef"
                                pastedDonationTxnId = ""
                                onStatusMessage("UPI Transaction ID verified! Thank you for donating ₹$displayAmt!")
                            },
                            onFailure = { err ->
                                onStatusMessage(err.localizedMessage ?: "Paste a valid UPI Transaction ID.")
                            }
                        )
                    },
                    enabled = pastedDonationTxnId.trim().length >= 10,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("verify_donate_upi_txn_button"),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Verify Donation Transaction ID",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Verify Transaction ID & Confirm Donation")
                }
            }
        }
    }
}
