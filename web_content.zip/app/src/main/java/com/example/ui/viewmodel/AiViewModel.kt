package com.example.ui.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout

private const val TAG = "AiViewModel"

sealed interface AiUiState {
    data object Idle : AiUiState
    data object Loading : AiUiState
    data class Streaming(val text: String) : AiUiState
    data class Success(val text: String) : AiUiState
    data class Error(val message: String) : AiUiState
}

data class AiQuickPrompt(
    val title: String,
    val subtitle: String,
    val defaultTopic: String,
    val promptTemplate: (topic: String) -> String
)

class AiViewModel(application: Application) : AndroidViewModel(application) {

    // Lazy initialization of Gemini 3.8 Flash to prevent startup crashes before App Check
    private val model by lazy {
        Firebase.ai.generativeModel(modelName = "gemini-3.8-flash")
    }

    private val _uiState = MutableStateFlow<AiUiState>(AiUiState.Idle)
    val uiState: StateFlow<AiUiState> = _uiState.asStateFlow()

    private val _currentPrompt = MutableStateFlow("")
    val currentPrompt: StateFlow<String> = _currentPrompt.asStateFlow()

    private val _selectedCategory = MutableStateFlow("notice")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    fun updatePrompt(newPrompt: String) {
        _currentPrompt.value = newPrompt
    }

    fun selectCategory(category: String) {
        _selectedCategory.value = category
    }

    fun resetState() {
        _uiState.value = AiUiState.Idle
    }

    // Stream generation to minimize Time-to-First-Token (TTFT)
    fun generateContentStream(prompt: String) {
        if (prompt.isBlank()) {
            _uiState.value = AiUiState.Error("অনুগ্রহ করে আপনার প্রম্পট বা বিষয়বস্তু লিখুন।")
            return
        }

        viewModelScope.launch {
            _uiState.value = AiUiState.Loading
            val accumulatedText = StringBuilder()
            try {
                // 60s timeout for model inference
                withTimeout(60_000L) {
                    model.generateContentStream(prompt).collect { chunk ->
                        val chunkText = chunk.text.orEmpty()
                        accumulatedText.append(chunkText)
                        _uiState.value = AiUiState.Streaming(accumulatedText.toString())
                    }
                }
                if (accumulatedText.isNotBlank()) {
                    _uiState.value = AiUiState.Success(accumulatedText.toString())
                } else {
                    _uiState.value = AiUiState.Error("মডেল থেকে কোনো উত্তর পাওয়া যায়নি। আবার চেষ্টা করুন।")
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Streaming timed out", e)
                _uiState.value = AiUiState.Error("সময়সীমা অতিক্রান্ত হয়েছে (Timeout)। নেটওয়ার্ক চেক করে পুনরায় চেষ্টা করুন।")
            } catch (e: CancellationException) {
                // Always rethrow CancellationException to maintain coroutine lifecycle
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Firebase AI generation failed", e)
                _uiState.value = AiUiState.Error(
                    e.localizedMessage ?: "AI প্রসেসিং ব্যর্থ হয়েছে। অনুগ্রহ করে ইন্টারনেট সংযোগ চেক করুন।"
                )
            }
        }
    }

    // Quick templates tailored for Charghat Upazila & Pouro Chhatra League
    fun generateNotice(noticeType: String, topic: String) {
        val fullPrompt = """
            তুমি বাংলাদেশ ছাত্রলীগ, চারঘাট উপজেলা ও পৌর শাখার জন্য একজন দক্ষ প্রেস ও যোগাযোগ সচিব হিসেবে কাজ করছ।
            নিচের বিষয়ের ওপর একটি অত্যন্ত আনুষ্ঠানিক, স্পষ্ট, নির্ভুল ও আকর্ষণীয় প্রেস বিজ্ঞপ্তি বা সাংগঠনিক নোটিশ তৈরি করো:
            
            বিজ্ঞপ্তির ধরণ: $noticeType
            মূল বিষয়বস্তু: $topic
            
            বিজ্ঞপ্তিতে নিম্নলিখিত উপাদানগুলো অন্তর্ভুক্ত থাকতে হবে:
            ১. আকর্ষণীয় শিরোনাম ("প্রেস বিজ্ঞপ্তি" / "জরুরি সাংগঠনিক নোটিশ")
            ২. সংগঠন: বাংলাদেশ ছাত্রলীগ, চারঘাট উপজেলা / চারঘাট পৌর শাখা
            ৩. তারিখ ও স্থান (চারঘাট, রাজশাহী)
            ৪. সুস্পষ্ট ও বলিষ্ঠ ভাষায় মূল বার্তা
            ৫. সাংগঠনিক স্লোগান (শিক্ষা, শান্তি, প্রগতি)
            ৬. প্রচারে: সভাপতি / সাধারণ সম্পাদক, চারঘাট ছাত্রলীগ।
            
            ভাষা: সম্পূর্ণ প্রমিত বাংলা। কোনো অতিরিক্ত ভূমিকা বা ইংরেজি কথা বাদ দিয়ে সরাসরি বিজ্ঞপ্তির খসড়া প্রদান করো।
        """.trimIndent()
        _currentPrompt.value = fullPrompt
        generateContentStream(fullPrompt)
    }

    fun generateSpeechPoints(programName: String, occasion: String) {
        val fullPrompt = """
            তুমি বাংলাদেশ ছাত্রলীগ, চারঘাট শাখার একজন দক্ষ সংগঠক ও সুবক্তা।
            নিচের কর্মসূচিতে চারঘাট ছাত্রলীগের নেতৃবৃন্দের বক্তব্যের জন্য বুলেট পয়েন্ট ও মূল দিকনির্দেশনা তৈরি করো:
            
            কর্মসূচির নাম: $programName
            উপলক্ষ / প্রেক্ষাপট: $occasion
            
            বক্তব্যের পয়েন্টে অন্তর্ভুক্ত করো:
            ১. শুরুতেই শ্রদ্ধাঞ্জলি ও স্বাগত সম্ভাষণ
            ২. ছাত্র সমাজের অধিকার ও পড়াশোনার পাশাপাশি ইতিবাচক নেতৃত্ব
            ৩. চারঘাটের সাধারণ শিক্ষার্থীদের পাশে থাকার বার্তা ও মাদকমুক্ত সমাজ গড়ার প্রত্যয়
            ৪. ইউনিয়ন ও কলেজ শাখার নেতাকর্মীদের ঐক্যবদ্ধ থাকার আহ্বান
            ৫. সমাপনী জয়ধ্বনি।
            
            সহজ, অনুপ্রেরণামূলক ও জোরালো বাংলা ভাষায় পয়েন্ট আকারে দাও।
        """.trimIndent()
        _currentPrompt.value = fullPrompt
        generateContentStream(fullPrompt)
    }

    fun generateGuidelines(unitType: String) {
        val fullPrompt = """
            বাংলাদেশ ছাত্রলীগ চারঘাট উপজেলা ও পৌর শাখার অধীনে $unitType শাখার সুষ্ঠু পরিচালনা ও সাংগঠনিক গতিশীলতা বৃদ্ধির জন্য ৫টি কার্যকর সাংগঠনিক পরামর্শ ও দিকনির্দেশনা পয়েন্ট আকারে সংক্ষেপে বাংলায় প্রদান করো।
        """.trimIndent()
        _currentPrompt.value = fullPrompt
        generateContentStream(fullPrompt)
    }
}
