package com.example.ui.screens

import android.annotation.SuppressLint
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Web
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.R
import com.example.data.model.StudioProject
import com.example.data.model.WebsiteLayoutPreset
import com.example.data.model.WebsiteSectionSpec
import com.example.data.model.WebsiteSpec
import com.example.data.model.WebsiteThemePalette
import com.example.data.repository.ApiHubConfig
import com.example.ui.ProjectsUiState
import com.example.ui.SynthesisState
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.util.ArchiveExportSummary
import com.example.util.CodeComplianceAuditor
import com.example.util.ProjectArchiveExporter
import java.util.Locale

private enum class WebMakerSubTab(val label: String, val tag: String) {
    LIVE_PREVIEW("Live Preview", "web_subtab_preview"),
    WEB_CODE("HTML / CSS / JS", "web_subtab_code"),
    SEO_AUDIT("SEO & Audit", "web_subtab_audit"),
    EXPORT_BUNDLE("Export Zip", "web_subtab_export")
}

private enum class WebFileSelection(val fileName: String, val badge: String) {
    INDEX_HTML("index.html", "HTML5"),
    STYLES_CSS("styles.css", "CSS3"),
    APP_JS("app.js", "ES6 JS"),
    WEBSITE_SPEC("website-spec.json", "JSON")
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WebsiteMakerScreen(
    apiConfig: ApiHubConfig,
    websitePromptInput: String,
    websiteLayoutPreset: WebsiteLayoutPreset,
    websiteThemePalette: WebsiteThemePalette,
    isEnhancingWebsitePrompt: Boolean,
    isRefiningWebsite: Boolean,
    websiteSynthesisState: SynthesisState,
    projectsState: ProjectsUiState,
    activeWebsiteProject: StudioProject?,
    exportBanner: ArchiveExportSummary?,
    onWebsitePromptChange: (String) -> Unit,
    onSelectLayoutPreset: (WebsiteLayoutPreset) -> Unit,
    onSelectThemePalette: (WebsiteThemePalette) -> Unit,
    onEnhanceWebsitePrompt: () -> Unit,
    onSynthesizeWebsite: () -> Unit,
    onSelectWebsiteProject: (StudioProject) -> Unit,
    onRefineWebsite: (String) -> Unit,
    onAddCustomWebsiteSection: (WebsiteSectionSpec) -> Unit,
    onSaveEditedWebsiteSource: (String, String, String, String) -> Unit,
    onExportToUri: (StudioProject, android.net.Uri) -> Unit,
    onExportToWorkspace: (StudioProject) -> Unit,
    onDismissExportBanner: () -> Unit,
    onNavigateBackToStudio: () -> Unit
) {
    BackHandler {
        onNavigateBackToStudio()
    }

    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    var selectedSubTab by rememberSaveable { mutableStateOf(WebMakerSubTab.LIVE_PREVIEW) }
    var useRenderedWebView by rememberSaveable { mutableStateOf(true) }
    var selectedFile by rememberSaveable { mutableStateOf(WebFileSelection.INDEX_HTML) }
    var isEditingCode by rememberSaveable { mutableStateOf(false) }
    var copiedNotice by remember { mutableStateOf<String?>(null) }

    val websiteProjects = remember(projectsState) {
        when (projectsState) {
            is ProjectsUiState.Success -> projectsState.projects.filter { it.isWebsiteProject() }
            else -> emptyList()
        }
    }

    val currentProject = activeWebsiteProject ?: websiteProjects.firstOrNull()

    var draftHtml by remember(currentProject?.id, currentProject?.kotlinCode) {
        mutableStateOf(currentProject?.kotlinCode.orEmpty())
    }
    var draftCss by remember(currentProject?.id, currentProject?.manifestXml) {
        mutableStateOf(currentProject?.manifestXml.orEmpty())
    }
    var draftJs by remember(currentProject?.id, currentProject?.buildGradleKts) {
        mutableStateOf(currentProject?.buildGradleKts.orEmpty())
    }
    var draftSpecJson by remember(currentProject?.id, currentProject?.sandboxSpecJson) {
        mutableStateOf(currentProject?.sandboxSpecJson.orEmpty())
    }

    LaunchedEffect(currentProject) {
        if (currentProject != null) {
            draftHtml = currentProject.kotlinCode
            draftCss = currentProject.manifestXml
            draftJs = currentProject.buildGradleKts
            draftSpecJson = currentProject.sandboxSpecJson
        }
    }

    val createZipLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null && currentProject != null) {
            onExportToUri(currentProject, uri)
        }
    }

    val isSynthesizing = websiteSynthesisState is SynthesisState.Synthesizing

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("website_maker_list"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Website Maker Studio Composer Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        width = 1.dp,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.35f),
                        shape = RoundedCornerShape(18.dp)
                    ),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Language,
                                contentDescription = "AI Website Maker",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "AI Website Maker",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Synthesize semantic HTML5, responsive CSS3, and interactive ES6 JS",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Surface(
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = apiConfig.selectedModel.displayName,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    // Layout Preset Selector
                    Text(
                        text = "Website Architecture Preset",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        WebsiteLayoutPreset.entries.forEach { preset ->
                            val selected = preset == websiteLayoutPreset
                            FilterChip(
                                selected = selected,
                                onClick = { onSelectLayoutPreset(preset) },
                                label = {
                                    Text(
                                        text = preset.label,
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                    selectedLabelColor = MaterialTheme.colorScheme.primary
                                ),
                                modifier = Modifier.testTag("web_preset_${preset.id.lowercase()}")
                            )
                        }
                    }

                    // Theme Palette Selector
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Palette,
                            contentDescription = "Color Palette",
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Color Palette",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        WebsiteThemePalette.entries.forEach { palette ->
                            val selected = palette == websiteThemePalette
                            FilterChip(
                                selected = selected,
                                onClick = { onSelectThemePalette(palette) },
                                label = {
                                    Text(
                                        text = palette.label,
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                },
                                modifier = Modifier.testTag("web_palette_${palette.id.lowercase()}")
                            )
                        }
                    }

                    // Website Prompt Input + Enhance Button
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Website Specification Prompt",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        TextButton(
                            onClick = onEnhanceWebsitePrompt,
                            enabled = !isEnhancingWebsitePrompt && !isSynthesizing,
                            modifier = Modifier.testTag("enhance_website_prompt_button")
                        ) {
                            if (isEnhancingWebsitePrompt) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(14.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Expanding...", style = MaterialTheme.typography.labelSmall)
                            } else {
                                Icon(
                                    imageVector = Icons.Default.AutoFixHigh,
                                    contentDescription = "AI Enhance Website Specification",
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("AI Enhance Spec", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }

                    OutlinedTextField(
                        value = websitePromptInput,
                        onValueChange = onWebsitePromptChange,
                        enabled = !isSynthesizing,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(125.dp)
                            .testTag("website_prompt_input"),
                        placeholder = {
                            Text(
                                text = "Describe the website or web app to build (e.g., 'Cloud GPU cost estimator & infrastructure landing page with live hourly/monthly pricing calculator and SLA comparison')...",
                                style = MaterialTheme.typography.bodySmall
                            )
                        },
                        shape = RoundedCornerShape(14.dp)
                    )

                    if (websiteSynthesisState is SynthesisState.Error) {
                        Surface(
                            color = MaterialTheme.colorScheme.error.copy(alpha = 0.14f),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = websiteSynthesisState.message,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }

                    Button(
                        onClick = onSynthesizeWebsite,
                        enabled = !isSynthesizing,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("build_website_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (isSynthesizing) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Synthesizing Website via ${apiConfig.selectedModel.displayName}...",
                                style = MaterialTheme.typography.labelLarge
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "Build Website",
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Build Responsive Website",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // 2. Saved Websites Strip (if user has generated websites)
        if (websiteProjects.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                    ),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "WORKSPACE WEBSITES (${websiteProjects.size})",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        FlowRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            websiteProjects.forEach { site ->
                                val isSelected = site.id == currentProject?.id
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { onSelectWebsiteProject(site) },
                                    label = {
                                        Text(
                                            text = site.title,
                                            style = MaterialTheme.typography.labelMedium
                                        )
                                    },
                                    modifier = Modifier.testTag("select_website_${site.id}")
                                )
                            }
                        }
                    }
                }
            }
        }

        // 3. Active Website Workspace or Empty State
        if (currentProject == null) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("empty_website_maker_card"),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Web,
                            contentDescription = "No Website Loaded",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(36.dp)
                        )
                        Text(
                            text = stringResource(R.string.empty_website_message),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            val webSpec = WebsiteSpec.fromJsonString(currentProject.sandboxSpecJson, currentProject.title)

            // Active Website Sub-Tab Switcher
            item {
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    WebMakerSubTab.entries.forEach { tab ->
                        val selected = selectedSubTab == tab
                        FilterChip(
                            selected = selected,
                            onClick = { selectedSubTab = tab },
                            label = {
                                Text(
                                    text = tab.label,
                                    style = MaterialTheme.typography.labelLarge
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier.testTag(tab.tag)
                        )
                    }
                }
            }

            when (selectedSubTab) {
                WebMakerSubTab.LIVE_PREVIEW -> {
                    item {
                        LiveWebsitePreviewSection(
                            project = currentProject,
                            webSpec = webSpec,
                            useRenderedWebView = useRenderedWebView,
                            onToggleRenderMode = { useRenderedWebView = it },
                            onAddCustomSection = onAddCustomWebsiteSection
                        )
                    }

                    item {
                        IterativeAiRefinementCard(
                            isRefining = isRefiningWebsite,
                            onRefineSubmit = onRefineWebsite
                        )
                    }
                }

                WebMakerSubTab.WEB_CODE -> {
                    item {
                        WebSourceCodeEditorPanel(
                            selectedFile = selectedFile,
                            onSelectFile = { selectedFile = it },
                            isEditing = isEditingCode,
                            onToggleEditing = { isEditingCode = !isEditingCode },
                            draftHtml = draftHtml,
                            draftCss = draftCss,
                            draftJs = draftJs,
                            draftSpecJson = draftSpecJson,
                            onHtmlChange = { draftHtml = it },
                            onCssChange = { draftCss = it },
                            onJsChange = { draftJs = it },
                            onSpecJsonChange = { draftSpecJson = it },
                            copiedNotice = copiedNotice,
                            onCopyCurrent = { content ->
                                clipboardManager.setText(AnnotatedString(content))
                                copiedNotice = "Copied ${selectedFile.fileName} to clipboard"
                            },
                            onSaveChanges = {
                                onSaveEditedWebsiteSource(draftHtml, draftCss, draftJs, draftSpecJson)
                                isEditingCode = false
                            }
                        )
                    }
                }

                WebMakerSubTab.SEO_AUDIT -> {
                    item {
                        val report = remember(
                            currentProject.kotlinCode,
                            currentProject.manifestXml,
                            currentProject.buildGradleKts,
                            currentProject.sandboxSpecJson
                        ) {
                            CodeComplianceAuditor.auditWebsiteProject(currentProject)
                        }
                        CodeComplianceAuditCard(
                            auditReport = report,
                            isRefining = isRefiningWebsite,
                            onAutoHardenClick = {
                                onRefineWebsite(
                                    "Ensure semantic HTML5 landmarks (<header>, <main>, <section>, <footer>), responsive <meta name=\"viewport\">, SEO meta description, and mobile-first CSS rules with overflow-x: hidden."
                                )
                            }
                        )
                    }
                }

                WebMakerSubTab.EXPORT_BUNDLE -> {
                    item {
                        WebsiteBundleExportCard(
                            project = currentProject,
                            exportBanner = exportBanner,
                            onDismissExportBanner = onDismissExportBanner,
                            onSaveZipToDevice = {
                                createZipLauncher.launch(
                                    ProjectArchiveExporter.suggestedArchiveFileName(currentProject)
                                )
                            },
                            onExportToWorkspace = {
                                onExportToWorkspace(currentProject)
                            },
                            onShareWebsiteCode = {
                                ProjectArchiveExporter.shareProjectBlueprint(context, currentProject)
                            }
                        )
                    }
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun LiveWebsitePreviewSection(
    project: StudioProject,
    webSpec: WebsiteSpec,
    useRenderedWebView: Boolean,
    onToggleRenderMode: (Boolean) -> Unit,
    onAddCustomSection: (WebsiteSectionSpec) -> Unit
) {
    var calcSliderValue by rememberSaveable(project.id) { mutableFloatStateOf(25f) }
    var webViewReloadKey by remember { mutableIntStateOf(0) }
    var showAddSectionForm by rememberSaveable { mutableStateOf(false) }
    var newSectionHeading by rememberSaveable { mutableStateOf("") }
    var newSectionSubheading by rememberSaveable { mutableStateOf("") }
    var newSectionItemsCsv by rememberSaveable { mutableStateOf("") }

    val combinedHtmlDocument = remember(project.kotlinCode, project.manifestXml, project.buildGradleKts, webViewReloadKey) {
        buildSelfContainedHtml(
            rawHtml = project.kotlinCode,
            rawCss = project.manifestXml,
            rawJs = project.buildGradleKts
        )
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = webSpec.siteTitle,
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = webSpec.tagline,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (useRenderedWebView) {
                    TextButton(
                        onClick = { webViewReloadKey++ },
                        modifier = Modifier.testTag("reload_webview_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Reload WebView",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Reload", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }

            // Renderer Mode Toggle (Rendered HTML5 WebView vs Interactive Compose Sections)
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = useRenderedWebView,
                    onClick = { onToggleRenderMode(true) },
                    label = { Text("Rendered HTML5 + JS WebView", style = MaterialTheme.typography.labelMedium) },
                    modifier = Modifier.testTag("mode_rendered_webview")
                )
                FilterChip(
                    selected = !useRenderedWebView,
                    onClick = { onToggleRenderMode(false) },
                    label = { Text("Native Section Composer (${webSpec.sections.size})", style = MaterialTheme.typography.labelMedium) },
                    modifier = Modifier.testTag("mode_native_sections")
                )
            }

            if (useRenderedWebView) {
                // Embedded Responsive WebView Container (Strictly fit within vertical viewport width)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(460.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .border(
                            width = 1.dp,
                            color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f),
                            shape = RoundedCornerShape(14.dp)
                        )
                        .testTag("website_live_webview_box")
                ) {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { ctx ->
                            WebView(ctx).apply {
                                settings.javaScriptEnabled = true
                                settings.domStorageEnabled = true
                                settings.loadWithOverviewMode = true
                                settings.useWideViewPort = true
                                settings.layoutAlgorithm = WebSettings.LayoutAlgorithm.TEXT_AUTOSIZING
                                isHorizontalScrollBarEnabled = false
                                webViewClient = WebViewClient()
                            }
                        },
                        update = { webView ->
                            webView.loadDataWithBaseURL(
                                "https://omniprompt.studio/",
                                combinedHtmlDocument,
                                "text/html",
                                "UTF-8",
                                null
                            )
                        }
                    )
                }
            } else {
                // Native Compose Interactive Section Renderer
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Navigation Links Preview Bar
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        webSpec.navLinks.forEach { link ->
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = link,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    // Hero Banner Card
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = webSpec.heroHeadline,
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = webSpec.heroSubheadline,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // Interactive Web Calculator Preview Card
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = webSpec.calculatorLabel,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                val computedVal = String.format(
                                    Locale.US,
                                    "%.1f %s",
                                    calcSliderValue * webSpec.calculatorMultiplier,
                                    webSpec.calculatorUnit
                                )
                                Text(
                                    text = computedVal,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Slider(
                                value = calcSliderValue,
                                onValueChange = { calcSliderValue = it },
                                valueRange = 1f..250f,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("website_native_calc_slider")
                            )
                        }
                    }

                    // Structured Website Sections
                    webSpec.sections.forEach { sec ->
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = sec.heading,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Surface(
                                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = sec.sectionType,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                if (sec.subheading.isNotBlank()) {
                                    Text(
                                        text = sec.subheading,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                sec.items.forEach { bullet ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.Top
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .padding(top = 6.dp)
                                                .size(6.dp)
                                                .clip(CircleShape)
                                                .background(MaterialTheme.colorScheme.primary)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = bullet,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

            // Add Custom Website Section Composer
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Custom Website Section Builder",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                TextButton(
                    onClick = { showAddSectionForm = !showAddSectionForm },
                    modifier = Modifier.testTag("toggle_add_web_section_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.AddCircleOutline,
                        contentDescription = "Add Website Section",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (showAddSectionForm) "Hide" else "Add Section")
                }
            }

            AnimatedVisibility(visible = showAddSectionForm) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = newSectionHeading,
                        onValueChange = { newSectionHeading = it },
                        label = { Text("Section Heading") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("new_web_section_heading_input")
                    )
                    OutlinedTextField(
                        value = newSectionSubheading,
                        onValueChange = { newSectionSubheading = it },
                        label = { Text("Section Value Proposition / Subtitle") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("new_web_section_subheading_input")
                    )
                    OutlinedTextField(
                        value = newSectionItemsCsv,
                        onValueChange = { newSectionItemsCsv = it },
                        label = { Text("Items / Feature Points (comma-separated)") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("new_web_section_items_input")
                    )
                    Button(
                        onClick = {
                            if (newSectionHeading.isNotBlank()) {
                                val items = newSectionItemsCsv.split(",")
                                    .map { it.trim() }
                                    .filter { it.isNotEmpty() }
                                onAddCustomSection(
                                    WebsiteSectionSpec(
                                        id = "custom_${System.currentTimeMillis()}",
                                        sectionType = "FEATURE_GRID",
                                        heading = newSectionHeading.trim(),
                                        subheading = newSectionSubheading.trim(),
                                        badge = "CUSTOM",
                                        items = items
                                    )
                                )
                                newSectionHeading = ""
                                newSectionSubheading = ""
                                newSectionItemsCsv = ""
                                showAddSectionForm = false
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("confirm_add_web_section_button")
                    ) {
                        Text("Append Section to Website & HTML5")
                    }
                }
            }
        }
    }
}

private fun buildSelfContainedHtml(
    rawHtml: String,
    rawCss: String,
    rawJs: String
): String {
    val viewportRule = """
        html, body { max-width: 100% !important; overflow-x: hidden !important; box-sizing: border-box !important; }
        *, *::before, *::after { box-sizing: border-box !important; max-width: 100%; }
    """.trimIndent()

    val styleBlock = "<style>\n$rawCss\n$viewportRule\n</style>"
    val scriptBlock = "<script>\n$rawJs\n</script>"

    var doc = rawHtml
    if (doc.contains("</head>", ignoreCase = true)) {
        doc = doc.replaceFirst("</head>", "$styleBlock\n</head>", ignoreCase = true)
    } else {
        doc = "$styleBlock\n$doc"
    }

    if (doc.contains("</body>", ignoreCase = true)) {
        doc = doc.replaceFirst("</body>", "$scriptBlock\n</body>", ignoreCase = true)
    } else {
        doc = "$doc\n$scriptBlock"
    }
    return doc
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun WebSourceCodeEditorPanel(
    selectedFile: WebFileSelection,
    onSelectFile: (WebFileSelection) -> Unit,
    isEditing: Boolean,
    onToggleEditing: () -> Unit,
    draftHtml: String,
    draftCss: String,
    draftJs: String,
    draftSpecJson: String,
    onHtmlChange: (String) -> Unit,
    onCssChange: (String) -> Unit,
    onJsChange: (String) -> Unit,
    onSpecJsonChange: (String) -> Unit,
    copiedNotice: String?,
    onCopyCurrent: (String) -> Unit,
    onSaveChanges: () -> Unit
) {
    val activeContent = when (selectedFile) {
        WebFileSelection.INDEX_HTML -> draftHtml
        WebFileSelection.STYLES_CSS -> draftCss
        WebFileSelection.APP_JS -> draftJs
        WebFileSelection.WEBSITE_SPEC -> draftSpecJson
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Code,
                        contentDescription = "Web Source Inspector",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Web Source & Inline Editor",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TextButton(
                        onClick = onToggleEditing,
                        modifier = Modifier.testTag("toggle_web_inline_edit_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Toggle Edit Mode",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isEditing) "Preview" else "Edit")
                    }
                    TextButton(
                        onClick = { onCopyCurrent(activeContent) },
                        modifier = Modifier.testTag("copy_web_source_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy Code",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Copy")
                    }
                }
            }

            if (!copiedNotice.isNullOrBlank()) {
                Text(
                    text = copiedNotice,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.tertiary
                )
            }

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                WebFileSelection.entries.forEach { file ->
                    FilterChip(
                        selected = selectedFile == file,
                        onClick = { onSelectFile(file) },
                        label = {
                            Text("${file.fileName} (${file.badge})", style = MaterialTheme.typography.labelSmall)
                        },
                        modifier = Modifier.testTag("web_file_chip_${file.name.lowercase()}")
                    )
                }
            }

            if (isEditing) {
                OutlinedTextField(
                    value = activeContent,
                    onValueChange = { updated ->
                        when (selectedFile) {
                            WebFileSelection.INDEX_HTML -> onHtmlChange(updated)
                            WebFileSelection.STYLES_CSS -> onCssChange(updated)
                            WebFileSelection.APP_JS -> onJsChange(updated)
                            WebFileSelection.WEBSITE_SPEC -> onSpecJsonChange(updated)
                        }
                    },
                    textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFontFamily),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(320.dp)
                        .testTag("web_inline_code_editor")
                )

                Button(
                    onClick = onSaveChanges,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("save_web_source_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Save,
                        contentDescription = "Save Web Source",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Save Web Source & Sync to Cloud")
                }
            } else {
                Surface(
                    color = Color(0xFF090D14),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = activeContent,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = JetBrainsMonoFontFamily,
                            color = Color(0xFFE2E8F0)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun WebsiteBundleExportCard(
    project: StudioProject,
    exportBanner: ArchiveExportSummary?,
    onDismissExportBanner: () -> Unit,
    onSaveZipToDevice: () -> Unit,
    onExportToWorkspace: () -> Unit,
    onShareWebsiteCode: () -> Unit
) {
    val entries = remember(project) {
        ProjectArchiveExporter.buildArchiveEntries(project, includeFullGradleScaffold = true)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.FolderZip,
                    contentDescription = "Static Website Bundle",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Static Website Archive (.zip)",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Ready for Netlify, Vercel, Firebase Hosting, or GitHub Pages",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (exportBanner != null) {
                Surface(
                    color = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Export Complete",
                                    tint = MaterialTheme.colorScheme.tertiary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = exportBanner.archiveFileName,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.tertiary
                                )
                            }
                            TextButton(onClick = onDismissExportBanner) {
                                Text("Dismiss", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        Text(
                            text = "${exportBanner.totalBytes} bytes • ${exportBanner.destinationDescription}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            entries.forEach { (fileName, content) ->
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = fileName,
                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFontFamily),
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = "${content.toByteArray().size} B",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            Button(
                onClick = onSaveZipToDevice,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("export_website_zip_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Download,
                    contentDescription = "Download Website Zip",
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Save Static Website Archive (.zip)")
            }

            OutlinedButton(
                onClick = onExportToWorkspace,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("package_website_workspace_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.VerifiedUser,
                    contentDescription = "Package to Workspace",
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Package Bundle in Studio Workspace")
            }

            OutlinedButton(
                onClick = onShareWebsiteCode,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("share_website_blueprint_button"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = "Share Website Blueprint",
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Share HTML5 / CSS3 / JS Blueprint")
            }
        }
    }
}
