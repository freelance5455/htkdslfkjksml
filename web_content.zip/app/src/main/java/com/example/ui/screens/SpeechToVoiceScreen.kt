package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.ChatLanguage
import com.example.data.models.VoiceProfile
import com.example.ui.theme.HazimCyan
import com.example.ui.theme.HazimDarkBackground
import com.example.ui.theme.HazimDarkBorder
import com.example.ui.theme.HazimDarkSurface
import com.example.ui.theme.HazimDarkSurfaceVariant
import com.example.ui.theme.HazimEmerald
import com.example.ui.theme.HazimPurple
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import com.example.ui.theme.TextTertiaryDark
import com.example.viewmodel.HazimAiViewModel

@Composable
fun SpeechToVoiceScreen(
    viewModel: HazimAiViewModel,
    onOpenDrawer: () -> Unit
) {
    val context = LocalContext.current
    val stvLanguage by viewModel.stvLanguage.collectAsState()
    val selectedVoice by viewModel.selectedVoice.collectAsState()
    val stvText by viewModel.stvText.collectAsState()
    val stvPitch by viewModel.stvPitch.collectAsState()
    val stvSpeed by viewModel.stvSpeed.collectAsState()
    val stvEmotion by viewModel.stvEmotion.collectAsState()

    val isPlaying by viewModel.ttsEngine.isPlaying.collectAsState()

    // Speech-to-text launcher for STV text input
    val speechRecognizerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spokenText = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!spokenText.isNullOrBlank()) {
                viewModel.setStvText(spokenText)
            }
        }
    }

    val voices = viewModel.ttsEngine.availableVoices.filter {
        when (stvLanguage) {
            ChatLanguage.HINDI, ChatLanguage.HINGLISH -> it.language == ChatLanguage.HINDI
            ChatLanguage.KASHMIRI -> it.language == ChatLanguage.KASHMIRI
            ChatLanguage.ENGLISH -> it.language == ChatLanguage.ENGLISH
        }
    }

    val emotions = listOf("Cheerful", "Calm", "Inspiring", "Neutral")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(HazimDarkBackground)
            .imePadding()
            .navigationBarsPadding()
    ) {
        // Top Bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = HazimDarkBackground
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onOpenDrawer,
                    modifier = Modifier.testTag("stv_open_drawer_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Menu,
                        contentDescription = "Menu",
                        tint = TextPrimaryDark
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Speech to Voice",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(HazimEmerald.copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "STV NEURAL",
                                color = HazimEmerald,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Text(
                        text = "Hindi, English & Kashmiri Voice Synthesis",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondaryDark,
                        fontSize = 11.sp
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Language Selection Chips
            item {
                Column {
                    Text(
                        text = "1. Select Voice Language",
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryDark,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            Triple(ChatLanguage.HINDI, "🇮🇳 Hindi", "आरव, अनन्या"),
                            Triple(ChatLanguage.ENGLISH, "🇬🇧 English", "Rachel, Liam"),
                            Triple(ChatLanguage.KASHMIRI, "🏔️ Kashmiri", "برہان, زون")
                        ).forEach { (lang, label, desc) ->
                            val isSelected = stvLanguage == lang || (stvLanguage == ChatLanguage.HINGLISH && lang == ChatLanguage.HINDI)
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .border(
                                        1.dp,
                                        if (isSelected) HazimEmerald else HazimDarkBorder,
                                        RoundedCornerShape(12.dp)
                                    )
                                    .clickable { viewModel.setStvLanguage(lang) },
                                color = if (isSelected) HazimEmerald.copy(alpha = 0.2f) else HazimDarkSurface
                            ) {
                                Column(
                                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = label,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = if (isSelected) HazimEmerald else TextPrimaryDark
                                    )
                                    Text(
                                        text = desc,
                                        fontSize = 10.sp,
                                        color = TextSecondaryDark
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Voice Profiles Carousel
            item {
                Column {
                    Text(
                        text = "2. Neural Voice Persona",
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryDark,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(voices) { voice ->
                            val isSelected = selectedVoice.id == voice.id
                            Surface(
                                modifier = Modifier
                                    .width(180.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .border(
                                        1.dp,
                                        if (isSelected) HazimEmerald else HazimDarkBorder,
                                        RoundedCornerShape(14.dp)
                                    )
                                    .clickable { viewModel.setSelectedVoice(voice) },
                                color = if (isSelected) HazimEmerald.copy(alpha = 0.15f) else HazimDarkSurface
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = voice.name,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = if (isSelected) HazimEmerald else TextPrimaryDark
                                        )
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(HazimDarkSurfaceVariant)
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = voice.gender,
                                                fontSize = 9.sp,
                                                color = TextSecondaryDark
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = voice.description,
                                        fontSize = 11.sp,
                                        color = TextSecondaryDark,
                                        lineHeight = 15.sp,
                                        maxLines = 2
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Script Text Input
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    color = HazimDarkSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, HazimDarkBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "3. Script / Speech Text",
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryDark,
                                fontSize = 13.sp
                            )

                            // Mic to record/dictate text
                            IconButton(
                                onClick = {
                                    try {
                                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                            putExtra(
                                                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                                                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                                            )
                                            putExtra(RecognizerIntent.EXTRA_PROMPT, "Dictate text...")
                                        }
                                        speechRecognizerLauncher.launch(intent)
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Microphone not available", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.size(30.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = "Dictate Speech",
                                    tint = HazimEmerald,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        OutlinedTextField(
                            value = stvText,
                            onValueChange = { viewModel.setStvText(it) },
                            placeholder = {
                                Text(
                                    text = "Enter text to synthesize into natural voice...",
                                    color = TextTertiaryDark,
                                    fontSize = 13.sp
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("stv_text_input"),
                            shape = RoundedCornerShape(12.dp),
                            minLines = 3,
                            maxLines = 6
                        )
                    }
                }
            }

            // Sliders & Emotion Presets
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    color = HazimDarkSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, HazimDarkBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "4. Voice Controls & Modulation",
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark,
                            fontSize = 13.sp
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Emotion Chips
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            emotions.forEach { emotion ->
                                val isSelected = stvEmotion == emotion
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isSelected) HazimEmerald.copy(alpha = 0.2f) else HazimDarkSurfaceVariant)
                                        .border(
                                            1.dp,
                                            if (isSelected) HazimEmerald else Color.Transparent,
                                            RoundedCornerShape(8.dp)
                                        )
                                        .clickable { viewModel.setStvEmotion(emotion) }
                                        .padding(vertical = 6.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = emotion,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) HazimEmerald else TextSecondaryDark
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Pitch Slider
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Pitch", fontSize = 12.sp, color = TextSecondaryDark)
                            Text(
                                text = "${String.format("%.2f", stvPitch)}x",
                                fontSize = 12.sp,
                                color = HazimEmerald,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Slider(
                            value = stvPitch,
                            onValueChange = { viewModel.setStvPitch(it) },
                            valueRange = 0.6f..1.6f,
                            colors = SliderDefaults.colors(
                                thumbColor = HazimEmerald,
                                activeTrackColor = HazimEmerald,
                                inactiveTrackColor = HazimDarkBorder
                            )
                        )

                        // Speed Slider
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Speech Rate / Speed", fontSize = 12.sp, color = TextSecondaryDark)
                            Text(
                                text = "${String.format("%.2f", stvSpeed)}x",
                                fontSize = 12.sp,
                                color = HazimEmerald,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Slider(
                            value = stvSpeed,
                            onValueChange = { viewModel.setStvSpeed(it) },
                            valueRange = 0.6f..1.6f,
                            colors = SliderDefaults.colors(
                                thumbColor = HazimEmerald,
                                activeTrackColor = HazimEmerald,
                                inactiveTrackColor = HazimDarkBorder
                            )
                        )
                    }
                }
            }

            // Audio Visualizer Card
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    color = HazimDarkSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, HazimDarkBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Neural Waveform Output",
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryDark,
                                fontSize = 13.sp
                            )
                            Text(
                                text = if (isPlaying) "Playing..." else "Ready",
                                fontSize = 11.sp,
                                color = if (isPlaying) HazimEmerald else TextSecondaryDark,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Waveform Visualizer Bars
                        AudioWaveformVisualizer(isPlaying = isPlaying)

                        Spacer(modifier = Modifier.height(16.dp))

                        // Buttons: Play / Stop & Save to Gallery
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = {
                                    if (isPlaying) {
                                        viewModel.stopStvVoice()
                                    } else {
                                        viewModel.playStvVoice()
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("stv_play_stop_button"),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isPlaying) Color(0xFFEF4444) else HazimEmerald,
                                    contentColor = Color.Black
                                )
                            ) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Default.Stop else Icons.Default.PlayArrow,
                                    contentDescription = null,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isPlaying) "Stop Audio" else "Generate & Play",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }

                            Button(
                                onClick = {
                                    viewModel.saveVoiceToGallery()
                                    Toast.makeText(context, "Saved voice note to Gallery!", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("stv_save_gallery_button"),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = HazimDarkSurfaceVariant,
                                    contentColor = TextPrimaryDark
                                )
                            ) {
                                Icon(
                                    imageVector = Icons.Default.BookmarkBorder,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp),
                                    tint = HazimEmerald
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Save to Gallery",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(20.dp)) }
        }
    }
}

@Composable
private fun AudioWaveformVisualizer(isPlaying: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "waveform")

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(HazimDarkSurfaceVariant)
            .padding(horizontal = 14.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        val barCounts = 24
        for (i in 0 until barCounts) {
            val animatedHeight by infiniteTransition.animateFloat(
                initialValue = 0.2f,
                targetValue = if (isPlaying) (0.3f + ((i * 17) % 70) / 100f) else 0.15f,
                animationSpec = infiniteRepeatable(
                    animation = tween(durationMillis = 250 + (i * 20)),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "bar_$i"
            )

            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height((animatedHeight * 40).dp.coerceAtLeast(6.dp))
                    .clip(RoundedCornerShape(2.dp))
                    .background(
                        if (isPlaying) {
                            Brush.verticalGradient(listOf(HazimEmerald, HazimCyan))
                        } else {
                            Brush.verticalGradient(listOf(HazimDarkBorder, HazimDarkBorder))
                        }
                    )
            )
        }
    }
}
