package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CarModel
import com.example.model.PedestrianModel
import com.example.model.PedestrianState
import com.example.model.SignalPhase
import com.example.ui.theme.PedestrianWaitRed
import com.example.ui.theme.PedestrianWalkGreen
import com.example.ui.theme.RoadAsphalt
import com.example.ui.theme.RoadMarking
import com.example.ui.theme.TrafficGreen
import com.example.ui.theme.TrafficRed
import com.example.ui.theme.TrafficYellow

@Composable
fun StreetSimulationView(
    currentPhase: SignalPhase,
    pedestrianState: PedestrianState,
    cars: List<CarModel>,
    pedestrians: List<PedestrianModel>,
    onSpawnCar: () -> Unit,
    modifier: Modifier = Modifier
) {
    val statusText = when (currentPhase) {
        SignalPhase.RED -> if (pedestrianState == PedestrianState.WALK) "السيارات متوقفة - المشاة يعبرون ممر المشاة بأمان" else "السيارات متوقفة عند خط الوقوف الإلزامي"
        SignalPhase.YELLOW, SignalPhase.RED_YELLOW -> "السيارات تخفف السرعة وتستعد للتوقف"
        SignalPhase.GREEN -> "الضوء أخضر - حركة السير تتدفق بحرية وسلاسة"
        SignalPhase.FLASHING_YELLOW -> "وميض تحذيري - السيارات تهدئ السرعة وتتوخى الحذر"
        SignalPhase.FLASHING_RED -> "وميض قف - السيارات تتوقف قبل العبور"
        else -> "التقاطع في وضع المراقبة"
    }

    val statusColor = when (currentPhase) {
        SignalPhase.RED -> TrafficRed
        SignalPhase.YELLOW, SignalPhase.RED_YELLOW, SignalPhase.FLASHING_YELLOW -> TrafficYellow
        SignalPhase.GREEN -> TrafficGreen
        else -> Color.Gray
    }

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = Color(0xFF141923),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF2B3648)),
        shadowElevation = 8.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header with status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(statusColor)
                    )
                    Text(
                        text = "محاكاة التقاطع الواقعي",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Button(
                    onClick = onSpawnCar,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF263345),
                        contentColor = Color.White
                    ),
                    modifier = Modifier.testTag("btn_spawn_car")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "إضافة سيارة",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "إضافة سيارة", fontSize = 12.sp)
                }
            }

            // Realtime dynamic status banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF1A212E))
                    .border(1.dp, Color(0xFF2D384D), RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = statusText,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFFB0BEC5)
                )
            }

            // 2D Canvas Roadway
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .border(2.dp, Color(0xFF384357), RoundedCornerShape(12.dp))
            ) {
                Canvas(
                    modifier = Modifier
                        .matchParentSize()
                        .testTag("simulation_canvas")
                ) {
                    val w = size.width
                    val h = size.height
                    val stopLineX = w * 0.52f
                    val crosswalkStartX = w * 0.54f
                    val crosswalkWidth = w * 0.16f

                    // 1. Asphalt Road Canvas
                    drawRect(color = RoadAsphalt)

                    // 2. Sidewalks (Top and Bottom)
                    val sidewalkHeight = h * 0.18f
                    drawRect(
                        color = Color(0xFF37474F),
                        topLeft = Offset(0f, 0f),
                        size = Size(w, sidewalkHeight)
                    )
                    drawRect(
                        color = Color(0xFF37474F),
                        topLeft = Offset(0f, h - sidewalkHeight),
                        size = Size(w, sidewalkHeight)
                    )

                    // Sidewalk Curb lines
                    drawLine(
                        color = Color(0xFF78909C),
                        start = Offset(0f, sidewalkHeight),
                        end = Offset(w, sidewalkHeight),
                        strokeWidth = 3f
                    )
                    drawLine(
                        color = Color(0xFF78909C),
                        start = Offset(0f, h - sidewalkHeight),
                        end = Offset(w, h - sidewalkHeight),
                        strokeWidth = 3f
                    )

                    // 3. Center Dashed Lane Divider
                    val laneCenterY = h / 2f
                    val dashEffect = PathEffect.dashPathEffect(floatArrayOf(24f, 16f), 0f)
                    drawLine(
                        color = Color(0xFFFFCA28),
                        start = Offset(0f, laneCenterY),
                        end = Offset(w, laneCenterY),
                        strokeWidth = 3.5f,
                        pathEffect = dashEffect
                    )

                    // 4. White Stop Line (خط الوقوف)
                    drawLine(
                        color = RoadMarking,
                        start = Offset(stopLineX, sidewalkHeight),
                        end = Offset(stopLineX, h - sidewalkHeight),
                        strokeWidth = 8f
                    )

                    // 5. Zebra Crosswalk Stripes (ممر المشاة)
                    val stripeCount = 7
                    val stripeGap = (h - 2 * sidewalkHeight) / stripeCount
                    for (i in 0 until stripeCount) {
                        val sy = sidewalkHeight + i * stripeGap + 3f
                        drawRoundRect(
                            color = RoadMarking.copy(alpha = 0.95f),
                            topLeft = Offset(crosswalkStartX, sy),
                            size = Size(crosswalkWidth, stripeGap - 6f),
                            cornerRadius = CornerRadius(2f, 2f)
                        )
                    }

                    // 6. Draw Pedestrians crossing
                    val isCrossing = pedestrianState == PedestrianState.WALK || pedestrianState == PedestrianState.FLASHING_DONT_WALK
                    pedestrians.forEach { ped ->
                        val pedX = crosswalkStartX + crosswalkWidth * 0.5f
                        val pedY = sidewalkHeight + ped.positionY * (h - 2 * sidewalkHeight)

                        // Pedestrian shadow
                        drawCircle(
                            color = Color.Black.copy(alpha = 0.4f),
                            radius = 9f,
                            center = Offset(pedX, pedY + 2f)
                        )

                        // Pedestrian body
                        drawCircle(
                            color = Color(ped.clothesColorHex),
                            radius = 8f,
                            center = Offset(pedX, pedY)
                        )

                        // Pedestrian head
                        drawCircle(
                            color = Color(0xFFFFCC80),
                            radius = 5f,
                            center = Offset(pedX, pedY - 3f)
                        )
                    }

                    // 7. Draw Cars
                    val carLength = w * 0.16f
                    val carHeight = (h - 2 * sidewalkHeight) * 0.38f
                    val carLaneY = laneCenterY - carHeight - 4f // top lane driving right-to-left or left-to-right

                    cars.forEach { car ->
                        val carX = car.positionX * w

                        // Car shadow
                        drawRoundRect(
                            color = Color.Black.copy(alpha = 0.5f),
                            topLeft = Offset(carX + 4f, carLaneY + 4f),
                            size = Size(carLength, carHeight),
                            cornerRadius = CornerRadius(10f, 10f)
                        )

                        // Car body
                        drawRoundRect(
                            color = Color(car.colorHex),
                            topLeft = Offset(carX, carLaneY),
                            size = Size(carLength, carHeight),
                            cornerRadius = CornerRadius(8f, 8f)
                        )

                        // Car cabin / roof
                        val cabinLength = carLength * 0.55f
                        val cabinHeight = carHeight * 0.72f
                        drawRoundRect(
                            color = Color(0xFF1E2530),
                            topLeft = Offset(carX + carLength * 0.2f, carLaneY + (carHeight - cabinHeight) / 2f),
                            size = Size(cabinLength, cabinHeight),
                            cornerRadius = CornerRadius(5f, 5f)
                        )

                        // Windshield
                        drawRoundRect(
                            color = Color(0xFF90CAF9),
                            topLeft = Offset(carX + carLength * 0.55f, carLaneY + carHeight * 0.2f),
                            size = Size(carLength * 0.15f, carHeight * 0.6f),
                            cornerRadius = CornerRadius(3f, 3f)
                        )

                        // Front Headlights (right side of car)
                        drawCircle(
                            color = Color(0xFFFFF9C4),
                            radius = 3.5f,
                            center = Offset(carX + carLength - 1f, carLaneY + 5f)
                        )
                        drawCircle(
                            color = Color(0xFFFFF9C4),
                            radius = 3.5f,
                            center = Offset(carX + carLength - 1f, carLaneY + carHeight - 5f)
                        )

                        // Rear Brake Lights (left side of car)
                        val brakeLightColor = if (car.isBraking || car.isStopped) TrafficRed else Color(0xFF7F0000)
                        drawCircle(
                            color = brakeLightColor,
                            radius = if (car.isBraking) 5f else 3.5f,
                            center = Offset(carX + 1f, carLaneY + 5f)
                        )
                        drawCircle(
                            color = brakeLightColor,
                            radius = if (car.isBraking) 5f else 3.5f,
                            center = Offset(carX + 1f, carLaneY + carHeight - 5f)
                        )

                        // Wheels
                        val wheelWidth = carLength * 0.18f
                        val wheelHeight = 4f
                        // Front top wheel
                        drawRoundRect(
                            color = Color.Black,
                            topLeft = Offset(carX + carLength * 0.68f, carLaneY - 2f),
                            size = Size(wheelWidth, wheelHeight)
                        )
                        // Front bottom wheel
                        drawRoundRect(
                            color = Color.Black,
                            topLeft = Offset(carX + carLength * 0.68f, carLaneY + carHeight - 2f),
                            size = Size(wheelWidth, wheelHeight)
                        )
                        // Rear top wheel
                        drawRoundRect(
                            color = Color.Black,
                            topLeft = Offset(carX + carLength * 0.12f, carLaneY - 2f),
                            size = Size(wheelWidth, wheelHeight)
                        )
                        // Rear bottom wheel
                        drawRoundRect(
                            color = Color.Black,
                            topLeft = Offset(carX + carLength * 0.12f, carLaneY + carHeight - 2f),
                            size = Size(wheelWidth, wheelHeight)
                        )
                    }
                }
            }
        }
    }
}
