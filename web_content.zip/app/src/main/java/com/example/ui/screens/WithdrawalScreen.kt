package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionStatus
import com.example.data.model.TransactionType
import com.example.ui.components.DecimalSliderField
import com.example.ui.components.FinancialInputField
import com.example.ui.components.ProfitLossBadge
import com.example.ui.components.TransactionStatusBadge
import com.example.ui.viewmodel.BusinessViewModel
import com.example.util.DateUtils
import com.example.util.FinancialMath
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WithdrawalScreen(
    viewModel: BusinessViewModel,
    modifier: Modifier = Modifier
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val allTransactions by viewModel.allTransactions.collectAsStateWithLifecycle()
    val withdrawalTransactions = remember(allTransactions) {
        allTransactions.filter { it.type == TransactionType.WITHDRAWAL.name }
    }

    // Consolidated withdrawal summary
    val consolidatedTotals = remember(withdrawalTransactions) {
        var totalAmount = 0.0
        var totalPlatformFees = 0.0
        var totalCommission = 0.0
        var totalTxCharges = 0.0
        var totalOtherCosts = 0.0
        var totalPayouts = 0.0
        var totalGross = 0.0
        var totalNet = 0.0
        withdrawalTransactions.forEach {
            totalAmount += it.amount
            totalPlatformFees += it.platformFeeAmount
            totalCommission += it.commissionAmount
            totalTxCharges += it.transactionCharge
            totalOtherCosts += it.otherCosts
            totalPayouts += it.customerPayoutOrCharge
            totalGross += it.grossProfit
            totalNet += it.netProfit
        }
        ConsolidatedWithdrawalTotals(
            totalAmount = totalAmount,
            totalPlatformFees = totalPlatformFees,
            totalCommission = totalCommission,
            totalTxCharges = totalTxCharges,
            totalOtherCosts = totalOtherCosts,
            totalPayouts = totalPayouts,
            totalGross = totalGross,
            totalNet = totalNet,
            count = withdrawalTransactions.size
        )
    }

    var isCalculatorExpanded by remember { mutableStateOf(true) }

    // Calculator input states
    var amountText by remember { mutableStateOf("10000") }
    var platformFeePercentText by remember(settings) {
        mutableStateOf(String.format(Locale.US, "%.2f", settings.defaultWithdrawalPlatformFeePercent))
    }
    var commissionPercentText by remember(settings) {
        mutableStateOf(String.format(Locale.US, "%.2f", settings.defaultWithdrawalCommissionPercent))
    }
    var transactionChargeText by remember(settings) {
        mutableStateOf(String.format(Locale.US, "%.2f", settings.defaultWithdrawalTransactionCharge))
    }
    var otherCostsText by remember { mutableStateOf("0.00") }
    var txIdText by remember { mutableStateOf("") }
    var notesText by remember { mutableStateOf("") }
    var statusText by remember { mutableStateOf(TransactionStatus.COMPLETED.name) }
    var isStatusExpanded by remember { mutableStateOf(false) }

    // Validation states
    val amountValidation by remember(amountText) {
        derivedStateOf { FinancialMath.validateAmount(amountText, "Withdrawal Amount") }
    }
    val platformFeeValidation by remember(platformFeePercentText) {
        derivedStateOf { FinancialMath.validatePercentage(platformFeePercentText, "Platform Fee %", 0.0, 50.0) }
    }
    val commissionValidation by remember(commissionPercentText) {
        derivedStateOf { FinancialMath.validatePercentage(commissionPercentText, "Commission %", 0.0, 20.0) }
    }
    val txChargeValidation by remember(transactionChargeText) {
        derivedStateOf { FinancialMath.validateCharge(transactionChargeText, "Transaction Charge") }
    }
    val otherCostsValidation by remember(otherCostsText) {
        derivedStateOf { FinancialMath.validateCharge(otherCostsText, "Other Costs") }
    }

    val isFormValid = amountValidation.isValid &&
            platformFeeValidation.isValid &&
            commissionValidation.isValid &&
            txChargeValidation.isValid &&
            otherCostsValidation.isValid

    // Live calculation
    val liveCalculation by remember(
        amountText, platformFeePercentText, commissionPercentText,
        transactionChargeText, otherCostsText, settings.defaultWithdrawalRetainChargeAsIncome
    ) {
        derivedStateOf {
            val amt = FinancialMath.parseDoubleOrNull(amountText) ?: 0.0
            val pFeePct = FinancialMath.parseDoubleOrNull(platformFeePercentText) ?: 0.0
            val commPct = FinancialMath.parseDoubleOrNull(commissionPercentText) ?: 0.0
            val txChg = FinancialMath.parseDoubleOrNull(transactionChargeText) ?: 0.0
            val other = FinancialMath.parseDoubleOrNull(otherCostsText) ?: 0.0

            FinancialMath.calculateWithdrawal(
                amount = amt,
                platformFeePercent = pFeePct,
                commissionPercent = commPct,
                transactionCharge = txChg,
                otherCosts = other,
                retainChargeAsIncome = settings.defaultWithdrawalRetainChargeAsIncome
            )
        }
    }

    // Delete confirmation state
    var transactionToDelete by remember { mutableStateOf<TransactionEntity?>(null) }
    // Edit dialog state
    var transactionToEdit by remember { mutableStateOf<TransactionEntity?>(null) }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(12.dp))

                // Title Banner
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text(
                            text = "Withdrawal Calculator",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Credit card withdrawal & customer payout engine",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    OutlinedButton(
                        onClick = { isCalculatorExpanded = !isCalculatorExpanded },
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(
                            imageVector = if (isCalculatorExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = null
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isCalculatorExpanded) "Collapse" else "Expand")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
            }

            // Interactive Calculator Section
            if (isCalculatorExpanded) {
                item {
                    ElevatedCard(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.elevatedCardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("withdrawal_calculator_card")
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "CALCULATOR INPUTS",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                letterSpacing = 1.sp
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // Withdrawal Amount Input
                            FinancialInputField(
                                value = amountText,
                                onValueChange = { amountText = it },
                                label = "Withdrawal Amount (₹)",
                                placeholder = "10000.00",
                                prefixText = "₹",
                                validationResult = amountValidation,
                                testTag = "withdrawal_amount_input"
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Platform Fee % Slider & Field
                            DecimalSliderField(
                                valueText = platformFeePercentText,
                                onValueChange = { platformFeePercentText = it },
                                label = "Platform Fee",
                                rangeMin = 0.0f,
                                rangeMax = 6.0f,
                                presets = listOf(0.5, 1.0, 1.25, 1.5, 1.75, 2.0),
                                suffix = "%",
                                validationResult = platformFeeValidation,
                                testTag = "platform_fee_slider"
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Commission Received % Slider & Field
                            DecimalSliderField(
                                valueText = commissionPercentText,
                                onValueChange = { commissionPercentText = it },
                                label = "Commission Received",
                                rangeMin = 0.0f,
                                rangeMax = 3.0f,
                                presets = listOf(0.1, 0.2, 0.3, 0.5, 1.0),
                                suffix = "%",
                                validationResult = commissionValidation,
                                testTag = "commission_slider"
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Transaction Charge & Other Costs
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                FinancialInputField(
                                    value = transactionChargeText,
                                    onValueChange = { transactionChargeText = it },
                                    label = "Tx Charge (₹)",
                                    placeholder = "20.00",
                                    prefixText = "₹",
                                    validationResult = txChargeValidation,
                                    modifier = Modifier.weight(1f),
                                    testTag = "tx_charge_input"
                                )

                                FinancialInputField(
                                    value = otherCostsText,
                                    onValueChange = { otherCostsText = it },
                                    label = "Other Costs (₹)",
                                    placeholder = "0.00",
                                    prefixText = "₹",
                                    validationResult = otherCostsValidation,
                                    modifier = Modifier.weight(1f),
                                    testTag = "other_costs_input"
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Transaction ID & Status
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                OutlinedTextField(
                                    value = txIdText,
                                    onValueChange = { txIdText = it },
                                    label = { Text("Tx ID (Optional)") },
                                    placeholder = { Text("Auto-generated") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.weight(1.2f)
                                )

                                ExposedDropdownMenuBox(
                                    expanded = isStatusExpanded,
                                    onExpandedChange = { isStatusExpanded = !isStatusExpanded },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    OutlinedTextField(
                                        value = statusText,
                                        onValueChange = {},
                                        readOnly = true,
                                        label = { Text("Status") },
                                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isStatusExpanded) },
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.menuAnchor()
                                    )
                                    ExposedDropdownMenu(
                                        expanded = isStatusExpanded,
                                        onDismissRequest = { isStatusExpanded = false }
                                    ) {
                                        TransactionStatus.entries.forEach { st ->
                                            DropdownMenuItem(
                                                text = { Text(st.name) },
                                                onClick = {
                                                    statusText = st.name
                                                    isStatusExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = notesText,
                                onValueChange = { notesText = it },
                                label = { Text("Customer Name / Card / Notes") },
                                placeholder = { Text("e.g. HDFC Millennia card, John Doe") },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // Live Calculations Result Card
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text(
                                        text = "LIVE CALCULATION BREAKDOWN",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )

                                    Spacer(modifier = Modifier.height(8.dp))

                                    ResultLine(
                                        label = "Platform Fee (${liveCalculation.platformFeePercent}%)",
                                        value = FinancialMath.formatInr(liveCalculation.platformFeeAmount)
                                    )
                                    ResultLine(
                                        label = "Commission Received (${liveCalculation.commissionPercent}%)",
                                        value = FinancialMath.formatInr(liveCalculation.commissionAmount)
                                    )
                                    ResultLine(
                                        label = "Transaction Charge Deducted",
                                        value = FinancialMath.formatInr(liveCalculation.transactionCharge)
                                    )

                                    HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))

                                    ResultLine(
                                        label = "Amount Payable to Customer",
                                        value = FinancialMath.formatInr(liveCalculation.customerPayout),
                                        isBold = true,
                                        color = MaterialTheme.colorScheme.primary
                                    )

                                    ResultLine(
                                        label = "Estimated Gross Profit",
                                        value = FinancialMath.formatInr(liveCalculation.grossProfit),
                                        isBold = true
                                    )

                                    ResultLine(
                                        label = "Estimated Net Profit",
                                        value = FinancialMath.formatInr(liveCalculation.netProfit),
                                        isBold = true,
                                        color = if (liveCalculation.netProfit >= 0) Color(0xFF0D652D) else Color(0xFFC5221F)
                                    )

                                    Text(
                                        text = "Profit: Commission (${FinancialMath.formatInr(liveCalculation.commissionAmount)}) + Tx Charge (${FinancialMath.formatInr(liveCalculation.transactionCharge)}) = ${FinancialMath.formatInr(liveCalculation.grossProfit)} profit to us. (Platform fee is deducted from customer payout).",
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 11.sp,
                                        modifier = Modifier.padding(top = 4.dp)
                                    )
                                    if (liveCalculation.netProfit < 0) {
                                        Text(
                                            text = "Note: Other costs exceed gross profit, resulting in a net loss of ${FinancialMath.formatInr(Math.abs(liveCalculation.netProfit))}.",
                                            color = MaterialTheme.colorScheme.error,
                                            fontSize = 11.sp,
                                            modifier = Modifier.padding(top = 2.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Add Transaction Button
                            Button(
                                onClick = {
                                    if (isFormValid) {
                                        val amt = FinancialMath.parseDoubleOrNull(amountText) ?: 0.0
                                        val pFee = FinancialMath.parseDoubleOrNull(platformFeePercentText) ?: 1.5
                                        val comm = FinancialMath.parseDoubleOrNull(commissionPercentText) ?: 0.2
                                        val txChg = FinancialMath.parseDoubleOrNull(transactionChargeText) ?: 20.0
                                        val other = FinancialMath.parseDoubleOrNull(otherCostsText) ?: 0.0

                                        viewModel.addWithdrawalTransaction(
                                            amount = amt,
                                            platformFeePercent = pFee,
                                            commissionPercent = comm,
                                            transactionCharge = txChg,
                                            otherCosts = other,
                                            txId = txIdText,
                                            status = statusText,
                                            notes = notesText
                                        )
                                        // Reset fields
                                        txIdText = ""
                                        notesText = ""
                                    }
                                },
                                enabled = isFormValid,
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("save_withdrawal_button")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Save Withdrawal Transaction")
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }
            }

            // Consolidated Totals Banner
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "CONSOLIDATED WITHDRAWAL SUMMARY",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.secondary
                            )
                            Text(
                                text = "${consolidatedTotals.count} Transactions",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text("Total Volume", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(FinancialMath.formatInr(consolidatedTotals.totalAmount), fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text("Customer Payouts", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(FinancialMath.formatInr(consolidatedTotals.totalPayouts), fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text("Platform Fees", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(FinancialMath.formatInr(consolidatedTotals.totalPlatformFees), fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text("Commission Received", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(FinancialMath.formatInr(consolidatedTotals.totalCommission), fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text("Tx Charges", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(FinancialMath.formatInr(consolidatedTotals.totalTxCharges), fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text("Total Net Profit", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                ProfitLossBadge(amount = consolidatedTotals.totalNet, label = "Net")
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Saved Transactions (${withdrawalTransactions.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))
            }

            if (withdrawalTransactions.isEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 16.dp)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CreditCard,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("No withdrawal transactions recorded yet")
                            Text(
                                "Enter amounts in the calculator above and click 'Save Withdrawal Transaction'.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                items(withdrawalTransactions, key = { it.id }) { tx ->
                    WithdrawalTransactionCard(
                        transaction = tx,
                        onDuplicate = { viewModel.duplicateTransaction(tx) },
                        onEdit = { transactionToEdit = tx },
                        onDelete = { transactionToDelete = tx }
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                }
            }

            item {
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }

    // Delete confirmation dialog
    transactionToDelete?.let { tx ->
        AlertDialog(
            onDismissRequest = { transactionToDelete = null },
            title = { Text("Delete Transaction") },
            text = { Text("Are you sure you want to delete transaction ${tx.txId} for ${FinancialMath.formatInr(tx.amount)}? This action cannot be undone.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteTransaction(tx.id)
                        transactionToDelete = null
                    }
                ) {
                    Text("Delete", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { transactionToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Edit Transaction Dialog
    transactionToEdit?.let { tx ->
        EditWithdrawalDialog(
            transaction = tx,
            onDismiss = { transactionToEdit = null },
            onSave = { updatedTx ->
                viewModel.updateTransaction(updatedTx)
                transactionToEdit = null
            }
        )
    }
}

data class ConsolidatedWithdrawalTotals(
    val totalAmount: Double,
    val totalPlatformFees: Double,
    val totalCommission: Double,
    val totalTxCharges: Double,
    val totalOtherCosts: Double,
    val totalPayouts: Double,
    val totalGross: Double,
    val totalNet: Double,
    val count: Int
)

@Composable
fun ResultLine(
    label: String,
    value: String,
    isBold: Boolean = false,
    color: Color = Color.Unspecified
) {
    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = if (isBold) FontWeight.SemiBold else FontWeight.Normal,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
            color = if (color != Color.Unspecified) color else MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun WithdrawalTransactionCard(
    transaction: TransactionEntity,
    onDuplicate: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
        ),
        modifier = modifier
            .fillMaxWidth()
            .testTag("tx_card_${transaction.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(
                        text = transaction.txId,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = DateUtils.formatDateTime(transaction.timestamp),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    TransactionStatusBadge(transaction.status)
                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(onClick = onDuplicate, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Duplicate", modifier = Modifier.size(16.dp))
                    }
                    IconButton(onClick = onEdit, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit", modifier = Modifier.size(16.dp))
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                    }
                }
            }

            if (transaction.notes.isNotBlank()) {
                Text(
                    text = transaction.notes,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))

            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text("Withdrawal", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(FinancialMath.formatInr(transaction.amount), fontWeight = FontWeight.Bold)
                }
                Column {
                    Text("Payable to Customer", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(FinancialMath.formatInr(transaction.customerPayoutOrCharge), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
                Column {
                    Text("Net Profit", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    ProfitLossBadge(amount = transaction.netProfit, label = "Net")
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Breakdown footer
            Text(
                text = "Fee: ${FinancialMath.formatInr(transaction.platformFeeAmount)} (${transaction.platformFeePercent}%) • Comm: ${FinancialMath.formatInr(transaction.commissionAmount)} (${transaction.commissionPercent}%) • Tx Charge: ${FinancialMath.formatInr(transaction.transactionCharge)}",
                style = MaterialTheme.typography.bodySmall,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun EditWithdrawalDialog(
    transaction: TransactionEntity,
    onDismiss: () -> Unit,
    onSave: (TransactionEntity) -> Unit
) {
    var amountText by remember { mutableStateOf(transaction.amount.toString()) }
    var platformFeeText by remember { mutableStateOf(transaction.platformFeePercent.toString()) }
    var commissionText by remember { mutableStateOf(transaction.commissionPercent.toString()) }
    var txChargeText by remember { mutableStateOf(transaction.transactionCharge.toString()) }
    var otherCostsText by remember { mutableStateOf(transaction.otherCosts.toString()) }
    var notesText by remember { mutableStateOf(transaction.notes) }
    var statusText by remember { mutableStateOf(transaction.status) }

    val amountValidation = FinancialMath.validateAmount(amountText, "Withdrawal Amount")
    val pFeeValidation = FinancialMath.validatePercentage(platformFeeText, "Platform Fee %")
    val commValidation = FinancialMath.validatePercentage(commissionText, "Commission %")

    val isValid = amountValidation.isValid && pFeeValidation.isValid && commValidation.isValid

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Transaction: ${transaction.txId}") },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                FinancialInputField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = "Withdrawal Amount",
                    validationResult = amountValidation
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FinancialInputField(
                        value = platformFeeText,
                        onValueChange = { platformFeeText = it },
                        label = "Platform Fee %",
                        prefixText = null,
                        suffixText = "%",
                        validationResult = pFeeValidation,
                        modifier = Modifier.weight(1f)
                    )
                    FinancialInputField(
                        value = commissionText,
                        onValueChange = { commissionText = it },
                        label = "Commission %",
                        prefixText = null,
                        suffixText = "%",
                        validationResult = commValidation,
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FinancialInputField(
                        value = txChargeText,
                        onValueChange = { txChargeText = it },
                        label = "Tx Charge",
                        modifier = Modifier.weight(1f)
                    )
                    FinancialInputField(
                        value = otherCostsText,
                        onValueChange = { otherCostsText = it },
                        label = "Other Costs",
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it },
                    label = { Text("Notes") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (isValid) {
                        val amt = FinancialMath.parseDoubleOrNull(amountText) ?: transaction.amount
                        val pFee = FinancialMath.parseDoubleOrNull(platformFeeText) ?: transaction.platformFeePercent
                        val comm = FinancialMath.parseDoubleOrNull(commissionText) ?: transaction.commissionPercent
                        val chg = FinancialMath.parseDoubleOrNull(txChargeText) ?: transaction.transactionCharge
                        val other = FinancialMath.parseDoubleOrNull(otherCostsText) ?: transaction.otherCosts

                        val calc = FinancialMath.calculateWithdrawal(
                            amount = amt,
                            platformFeePercent = pFee,
                            commissionPercent = comm,
                            transactionCharge = chg,
                            otherCosts = other,
                            retainChargeAsIncome = transaction.isTransactionChargeRetained
                        )

                        val updated = transaction.copy(
                            amount = calc.withdrawalAmount,
                            platformFeePercent = calc.platformFeePercent,
                            platformFeeAmount = calc.platformFeeAmount,
                            commissionPercent = calc.commissionPercent,
                            commissionAmount = calc.commissionAmount,
                            transactionCharge = calc.transactionCharge,
                            otherCosts = calc.otherCosts,
                            customerPayoutOrCharge = calc.customerPayout,
                            grossProfit = calc.grossProfit,
                            netProfit = calc.netProfit,
                            notes = notesText,
                            status = statusText
                        )
                        onSave(updated)
                    }
                },
                enabled = isValid
            ) {
                Text("Save Changes")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
