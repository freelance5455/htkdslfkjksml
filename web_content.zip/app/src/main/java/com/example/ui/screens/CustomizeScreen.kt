package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.auth.signOut
import com.example.model.ObservationRule
import com.example.model.Subject
import com.example.model.defaultReportLabels
import com.example.ui.components.AddStudentDialog
import com.example.ui.components.BulkPasteStudentsDialog
import com.example.ui.components.CreateClassDialog
import com.example.ui.components.SchoolEmblemView
import com.example.viewmodel.SchoolDashboardData
import com.example.viewmodel.SchoolViewModel
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class AdminSection(val label: String) {
    LOGO("Logo & Sign"),
    SCHOOL("School & Labels"),
    SUBJECTS("Subjects"),
    ROSTER("Classes & Roster"),
    STYLING("Style & Rules"),
    BACKUP("Backup & Account"),
}

@Composable
fun CustomizeScreen(
    data: SchoolDashboardData,
    viewModel: SchoolViewModel,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val brandingRev by viewModel.brandingRevision.collectAsStateWithLifecycle()

    var activeSection by remember { mutableStateOf(AdminSection.LOGO) }
    var showAddStudentDialog by remember { mutableStateOf(false) }
    var showBulkPasteDialog by remember { mutableStateOf(false) }
    var showCreateClassDialog by remember { mutableStateOf(false) }
    var showClearStudentsConfirm by remember { mutableStateOf(false) }

    val logoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) viewModel.uploadLogoImage(uri, data.config)
    }

    val sigPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) viewModel.uploadSignatureImage(uri, data.config)
    }

    val exportJsonLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    val json = viewModel.buildBackupJson(data)
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openOutputStream(uri)?.use { out ->
                            out.write(json.toByteArray())
                        }
                    }
                    viewModel.notifyMessage("Exported JSON backup")
                } catch (e: Exception) {
                    viewModel.notifyMessage("Export failed: ${e.localizedMessage}")
                }
            }
        }
    }

    val importJsonLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    val raw = withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
                    }
                    if (raw.isNotBlank()) viewModel.importBackupJson(raw)
                } catch (e: Exception) {
                    viewModel.notifyMessage("Import failed: ${e.localizedMessage}")
                }
            }
        }
    }

    val activeClass = data.activeClass
    val logoBitmap = remember(data.config.logoFileName, brandingRev) {
        viewModel.loadLogoBitmap(data.config.logoFileName)
    }
    val signatureBitmap = remember(data.config.signatureFileName, brandingRev) {
        viewModel.loadSignatureBitmap(data.config.signatureFileName)
    }

    if (showAddStudentDialog && activeClass != null) {
        AddStudentDialog(
            className = activeClass.name,
            onDismiss = { showAddStudentDialog = false },
            onAdd = { name, idNo, conduct -> viewModel.addStudent(activeClass.id, name, idNo, conduct) },
        )
    }

    if (showBulkPasteDialog && activeClass != null) {
        BulkPasteStudentsDialog(
            className = activeClass.name,
            onDismiss = { showBulkPasteDialog = false },
            onConfirm = { raw -> viewModel.bulkAddStudents(activeClass.id, raw) },
        )
    }

    if (showCreateClassDialog) {
        CreateClassDialog(
            activeClassName = activeClass?.name,
            onDismiss = { showCreateClassDialog = false },
            onCreate = { name, copySubs ->
                viewModel.createClass(
                    name = name,
                    sortOrder = data.classes.size.toLong(),
                    copyFromSubjects = if (copySubs) data.subjects else emptyList(),
                )
            },
        )
    }

    if (showClearStudentsConfirm && activeClass != null) {
        AlertDialog(
            onDismissRequest = { showClearStudentsConfirm = false },
            title = { Text("Clear Students in ${activeClass.name}?") },
            text = { Text("This keeps your school logo, settings, and subjects, while removing all ${data.students.size} students in ${activeClass.name}.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearStudentsInClass(data.students.map { it.id })
                        showClearStudentsConfirm = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                ) { Text("Clear All") }
            },
            dismissButton = {
                TextButton(onClick = { showClearStudentsConfirm = false }) { Text("Cancel") }
            },
        )
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Horizontal Admin Section Pills
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            AdminSection.entries.forEach { sec ->
                FilterChip(
                    selected = activeSection == sec,
                    onClick = { activeSection = sec },
                    label = { Text(sec.label, style = MaterialTheme.typography.labelMedium) },
                )
            }
        }

        when (activeSection) {
            AdminSection.LOGO -> {
                var teacherNameDraft by remember(data.config.teacherName) { mutableStateOf(data.config.teacherName) }
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Column {
                                        Text("School Logo / Stamp", style = MaterialTheme.typography.titleMedium)
                                        Text("Pick from gallery or use built-in crest", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Switch(
                                        checked = data.config.showLogo,
                                        onCheckedChange = { viewModel.saveConfig(data.config.copy(showLogo = it)) },
                                    )
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(16.dp),
                                        color = MaterialTheme.colorScheme.surfaceVariant,
                                        modifier = Modifier.size(92.dp),
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            SchoolEmblemView(
                                                logoBitmap = logoBitmap,
                                                schoolName = data.config.schoolName,
                                                size = 76.dp,
                                                circular = data.config.logoCircular,
                                            )
                                        }
                                    }

                                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = {
                                                logoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                            },
                                            modifier = Modifier.fillMaxWidth().testTag("pick_school_logo_button"),
                                            shape = RoundedCornerShape(12.dp),
                                        ) {
                                            Icon(Icons.Rounded.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(Modifier.width(6.dp))
                                            Text("Pick School Logo")
                                        }

                                        OutlinedButton(
                                            onClick = {
                                                viewModel.saveConfig(data.config.copy(logoFileName = ""), "Restored default stamp")
                                            },
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(12.dp),
                                        ) {
                                            Text("Use Default Emblem")
                                        }
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(
                                        checked = data.config.logoCircular,
                                        onCheckedChange = { viewModel.saveConfig(data.config.copy(logoCircular = it)) },
                                    )
                                    Text("Circular Stamp Crop", style = MaterialTheme.typography.bodyMedium)
                                }

                                Text(
                                    text = "Logo Size on Report Card (${data.config.logoSizeDp}dp)",
                                    style = MaterialTheme.typography.labelMedium,
                                )
                                Slider(
                                    value = data.config.logoSizeDp.toFloat(),
                                    onValueChange = {
                                        viewModel.saveConfig(data.config.copy(logoSizeDp = it.toLong()))
                                    },
                                    valueRange = 40f..130f,
                                )
                            }
                        }
                    }

                    item {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("Teacher Signature & Stamp", style = MaterialTheme.typography.titleMedium)
                                OutlinedTextField(
                                    value = teacherNameDraft,
                                    onValueChange = {
                                        teacherNameDraft = it
                                        viewModel.saveConfig(data.config.copy(teacherName = it))
                                    },
                                    label = { Text("Default Teacher Name (on Report Card)") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    FilledTonalButton(
                                        onClick = {
                                            sigPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                        },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(12.dp),
                                    ) {
                                        Text("Pick Signature Image")
                                    }
                                    if (data.config.signatureFileName.isNotBlank()) {
                                        OutlinedButton(
                                            onClick = { viewModel.saveConfig(data.config.copy(signatureFileName = "")) },
                                            shape = RoundedCornerShape(12.dp),
                                        ) {
                                            Text("Clear")
                                        }
                                    }
                                }
                                if (signatureBitmap != null) {
                                    Image(
                                        bitmap = signatureBitmap.asImageBitmap(),
                                        contentDescription = "Signature preview",
                                        modifier = Modifier.height(52.dp),
                                        contentScale = ContentScale.Fit,
                                    )
                                }
                            }
                        }
                    }
                }
            }

            AdminSection.SCHOOL -> {
                var cfgDraft by remember(data.config) { mutableStateOf(data.config) }
                val labelKeys = remember {
                    listOf(
                        "schoolPrefix" to "School Prefix",
                        "poBoxPrefix" to "P.O. Box Prefix",
                        "telPrefix" to "Tel Prefix",
                        "studentName" to "Student Name Label",
                        "className" to "Class Label",
                        "idNo" to "ID No. Label",
                        "numStudents" to "N. Students Label",
                        "conduct" to "Conduct Label",
                        "subjects" to "Subjects Header",
                        "test" to "TEST Header",
                        "exam" to "EXAM Header",
                        "tot" to "TOT Header",
                        "rank" to "Rank Header",
                        "totalRow" to "Total Row Label",
                        "average" to "Average Label",
                        "position" to "Position Label",
                        "lates" to "Lates Label",
                        "absences" to "Absences Label",
                        "observations" to "Observations Header",
                        "teacherSignature" to "Teacher Signature Header",
                        "parentSignature" to "Parent Signature Header",
                    )
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("School Header & Term Details", style = MaterialTheme.typography.titleMedium)
                                OutlinedTextField(value = cfgDraft.schoolName, onValueChange = { cfgDraft = cfgDraft.copy(schoolName = it) }, label = { Text("School Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                OutlinedTextField(value = cfgDraft.country, onValueChange = { cfgDraft = cfgDraft.copy(country = it) }, label = { Text("Country / Top Left") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                OutlinedTextField(value = cfgDraft.ministry, onValueChange = { cfgDraft = cfgDraft.copy(ministry = it) }, label = { Text("Ministry / Top Right") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(value = cfgDraft.academicYear, onValueChange = { cfgDraft = cfgDraft.copy(academicYear = it) }, label = { Text("Academic Year") }, singleLine = true, modifier = Modifier.weight(1f))
                                    OutlinedTextField(value = cfgDraft.term, onValueChange = { cfgDraft = cfgDraft.copy(term = it) }, label = { Text("Term") }, singleLine = true, modifier = Modifier.weight(1f))
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(value = cfgDraft.poBox, onValueChange = { cfgDraft = cfgDraft.copy(poBox = it) }, label = { Text("P.O. Box / Email") }, singleLine = true, modifier = Modifier.weight(1f))
                                    OutlinedTextField(value = cfgDraft.tel, onValueChange = { cfgDraft = cfgDraft.copy(tel = it) }, label = { Text("Telephone") }, singleLine = true, modifier = Modifier.weight(1f))
                                }
                                OutlinedTextField(value = cfgDraft.reportTitle, onValueChange = { cfgDraft = cfgDraft.copy(reportTitle = it) }, label = { Text("Report Banner Title") }, singleLine = true, modifier = Modifier.fillMaxWidth())

                                Button(
                                    onClick = { viewModel.saveConfig(cfgDraft, "School info & labels saved") },
                                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("save_school_info_button"),
                                    shape = RoundedCornerShape(12.dp),
                                ) {
                                    Text("Save School Details & Labels")
                                }
                            }
                        }
                    }

                    item {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Customize Report Card Labels", style = MaterialTheme.typography.titleMedium)
                                Text("Rename or translate any heading on the report card", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                val currentLabels = defaultReportLabels() + cfgDraft.labels
                                labelKeys.forEach { (key, title) ->
                                    OutlinedTextField(
                                        value = currentLabels[key].orEmpty(),
                                        onValueChange = { newVal ->
                                            val updated = currentLabels.toMutableMap().apply { put(key, newVal) }
                                            cfgDraft = cfgDraft.copy(labels = updated)
                                        },
                                        label = { Text(title) },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth(),
                                    )
                                }
                                Button(
                                    onClick = { viewModel.saveConfig(cfgDraft, "Saved custom labels") },
                                    modifier = Modifier.fillMaxWidth().height(48.dp),
                                    shape = RoundedCornerShape(12.dp),
                                ) {
                                    Text("Save Labels")
                                }
                            }
                        }
                    }
                }
            }

            AdminSection.SUBJECTS -> {
                if (activeClass == null) return
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Column {
                                        Text("Subjects (${activeClass.name})", style = MaterialTheme.typography.titleMedium)
                                        Text("Set Max Exam = 0 for Test-only mode", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Button(
                                        onClick = {
                                            viewModel.upsertSubject(
                                                Subject(
                                                    classId = activeClass.id,
                                                    name = "NEW SUBJECT",
                                                    maxTest = 100L,
                                                    maxExam = 0L,
                                                    sortOrder = data.subjects.size.toLong(),
                                                )
                                            )
                                        },
                                        shape = RoundedCornerShape(12.dp),
                                    ) {
                                        Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("Subject")
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    FilledTonalButton(onClick = { viewModel.applySubjectWeightsPreset(data.subjects, 100L, 0L) }) {
                                        Text("Test Only (100/-)")
                                    }
                                    FilledTonalButton(onClick = { viewModel.applySubjectWeightsPreset(data.subjects, 50L, 50L) }) {
                                        Text("50 Test + 50 Exam")
                                    }
                                    FilledTonalButton(onClick = { viewModel.applySubjectWeightsPreset(data.subjects, 40L, 60L) }) {
                                        Text("40 Test + 60 Exam")
                                    }
                                }
                            }
                        }
                    }

                    itemsIndexed(data.subjects, key = { _, sub -> sub.id }) { idx, sub ->
                        var nameDraft by remember(sub.id, sub.name) { mutableStateOf(sub.name) }
                        var testDraft by remember(sub.id, sub.maxTest) { mutableStateOf(sub.maxTest.toString()) }
                        var examDraft by remember(sub.id, sub.maxExam) { mutableStateOf(sub.maxExam.toString()) }

                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    OutlinedTextField(
                                        value = nameDraft,
                                        onValueChange = {
                                            nameDraft = it
                                            if (it.isNotBlank()) viewModel.upsertSubject(sub.copy(name = it))
                                        },
                                        label = { Text("Subject #${idx + 1}") },
                                        singleLine = true,
                                        modifier = Modifier.weight(1f),
                                    )
                                    IconButton(onClick = { viewModel.moveSubject(data.subjects, idx, -1) }, enabled = idx > 0) {
                                        Icon(Icons.Rounded.ArrowUpward, contentDescription = "Move up")
                                    }
                                    IconButton(onClick = { viewModel.moveSubject(data.subjects, idx, 1) }, enabled = idx < data.subjects.lastIndex) {
                                        Icon(Icons.Rounded.ArrowDownward, contentDescription = "Move down")
                                    }
                                    IconButton(
                                        onClick = { viewModel.deleteSubject(sub.id) },
                                        enabled = data.subjects.size > 1,
                                    ) {
                                        Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete subject", tint = MaterialTheme.colorScheme.error)
                                    }
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    OutlinedTextField(
                                        value = testDraft,
                                        onValueChange = { raw ->
                                            val clean = raw.filter { it.isDigit() }
                                            testDraft = clean
                                            viewModel.upsertSubject(sub.copy(maxTest = (clean.toLongOrNull() ?: 0L).coerceIn(0L, 1000L)))
                                        },
                                        label = { Text("Max TEST") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        singleLine = true,
                                        modifier = Modifier.weight(1f),
                                    )
                                    OutlinedTextField(
                                        value = examDraft,
                                        onValueChange = { raw ->
                                            val clean = raw.filter { it.isDigit() }
                                            examDraft = clean
                                            viewModel.upsertSubject(sub.copy(maxExam = (clean.toLongOrNull() ?: 0L).coerceIn(0L, 1000L)))
                                        },
                                        label = { Text("Max EXAM") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        singleLine = true,
                                        modifier = Modifier.weight(1f),
                                    )
                                    Surface(
                                        color = MaterialTheme.colorScheme.primaryContainer,
                                        shape = RoundedCornerShape(10.dp),
                                    ) {
                                        Text(
                                            text = "TOT\n${(testDraft.toLongOrNull() ?: 0L) + (examDraft.toLongOrNull() ?: 0L)}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            AdminSection.ROSTER -> {
                if (activeClass == null) return
                var classNameDraft by remember(activeClass.id, activeClass.name) { mutableStateOf(activeClass.name) }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Text("Class Management", style = MaterialTheme.typography.titleMedium)
                                    Button(onClick = { showCreateClassDialog = true }, shape = RoundedCornerShape(12.dp)) {
                                        Text("+ New Class")
                                    }
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    OutlinedTextField(
                                        value = classNameDraft,
                                        onValueChange = { classNameDraft = it },
                                        label = { Text("Active Class Name") },
                                        singleLine = true,
                                        modifier = Modifier.weight(1f),
                                    )
                                    Button(
                                        onClick = { viewModel.renameClass(activeClass.id, classNameDraft) },
                                        shape = RoundedCornerShape(12.dp),
                                    ) { Text("Rename") }
                                    if (data.classes.size > 1) {
                                        IconButton(
                                            onClick = {
                                                viewModel.deleteClass(
                                                    activeClass.id,
                                                    data.subjects.map { it.id },
                                                    data.students.map { it.id },
                                                )
                                            },
                                        ) {
                                            Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete class", tint = MaterialTheme.colorScheme.error)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("Students in ${activeClass.name} (${data.students.size})", style = MaterialTheme.typography.titleMedium)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = { showAddStudentDialog = true },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(12.dp),
                                    ) { Text("+ Add Student") }
                                    FilledTonalButton(
                                        onClick = { showBulkPasteDialog = true },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(12.dp),
                                    ) { Text("Bulk Paste") }
                                }
                                if (data.students.isNotEmpty()) {
                                    OutlinedButton(
                                        onClick = { showClearStudentsConfirm = true },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp),
                                    ) { Text("Clear Students in ${activeClass.name}") }
                                }
                            }
                        }
                    }

                    itemsIndexed(data.students, key = { _, stu -> stu.id }) { idx, stu ->
                        var stuNameDraft by remember(stu.id, stu.name) { mutableStateOf(stu.name) }
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                Text("${idx + 1}.", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                OutlinedTextField(
                                    value = stuNameDraft,
                                    onValueChange = {
                                        stuNameDraft = it
                                        if (it.isNotBlank()) viewModel.updateStudent(stu.copy(name = it))
                                    },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f),
                                )
                                IconButton(onClick = { viewModel.deleteStudent(stu.id) }) {
                                    Icon(Icons.Rounded.DeleteOutline, contentDescription = "Remove student", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }

            AdminSection.STYLING -> {
                var cfg by remember(data.config) { mutableStateOf(data.config) }
                val colorPresets = listOf(
                    "Classic Charcoal" to ("#1F2937" to "#F8FAFC"),
                    "Royal Navy" to ("#1E3A8A" to "#EFF6FF"),
                    "Emerald" to ("#065F46" to "#ECFDF5"),
                    "Burgundy" to ("#7F1D1D" to "#FEF2F2"),
                )

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("Report Styling & Calculation Rules", style = MaterialTheme.typography.titleMedium)

                                Text("Table Color Theme", style = MaterialTheme.typography.labelMedium)
                                Row(
                                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                ) {
                                    colorPresets.forEach { (title, pair) ->
                                        val selected = cfg.borderColorHex.equals(pair.first, ignoreCase = true)
                                        Surface(
                                            shape = RoundedCornerShape(12.dp),
                                            color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                                            border = BorderStroke(if (selected) 2.dp else 1.dp, Color(android.graphics.Color.parseColor(pair.first))),
                                            modifier = Modifier.clickable {
                                                cfg = cfg.copy(borderColorHex = pair.first, headerBgHex = pair.second)
                                                viewModel.saveConfig(cfg, "Applied $title palette")
                                            },
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(14.dp)
                                                        .clip(CircleShape)
                                                        .background(Color(android.graphics.Color.parseColor(pair.first))),
                                                )
                                                Text(title, style = MaterialTheme.typography.labelSmall)
                                            }
                                        }
                                    }
                                }

                                Text("Report Typography", style = MaterialTheme.typography.labelMedium)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    FilterChip(
                                        selected = cfg.reportFont == "serif",
                                        onClick = {
                                            cfg = cfg.copy(reportFont = "serif")
                                            viewModel.saveConfig(cfg)
                                        },
                                        label = { Text("Classic Academic Serif") },
                                    )
                                    FilterChip(
                                        selected = cfg.reportFont == "sans",
                                        onClick = {
                                            cfg = cfg.copy(reportFont = "sans")
                                            viewModel.saveConfig(cfg)
                                        },
                                        label = { Text("Modern Clean Sans") },
                                    )
                                }

                                Text("Position Display & Decimals", style = MaterialTheme.typography.labelMedium)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    FilterChip(
                                        selected = cfg.positionFormat == "number_only",
                                        onClick = {
                                            cfg = cfg.copy(positionFormat = "number_only")
                                            viewModel.saveConfig(cfg)
                                        },
                                        label = { Text("Rank Only (5)") },
                                    )
                                    FilterChip(
                                        selected = cfg.positionFormat == "fraction",
                                        onClick = {
                                            cfg = cfg.copy(positionFormat = "fraction")
                                            viewModel.saveConfig(cfg)
                                        },
                                        label = { Text("Fraction (5 / 10)") },
                                    )
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf(0L, 1L, 2L).forEach { dec ->
                                        FilterChip(
                                            selected = cfg.decimalPlaces == dec,
                                            onClick = {
                                                cfg = cfg.copy(decimalPlaces = dec)
                                                viewModel.saveConfig(cfg)
                                            },
                                            label = { Text("$dec Decimal${if (dec == 1L) "" else "s"}") },
                                        )
                                    }
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(
                                        value = cfg.conductMax,
                                        onValueChange = {
                                            cfg = cfg.copy(conductMax = it)
                                            viewModel.saveConfig(cfg)
                                        },
                                        label = { Text("Conduct Max") },
                                        placeholder = { Text("e.g. 40") },
                                        singleLine = true,
                                        modifier = Modifier.weight(1f),
                                    )
                                    OutlinedTextField(
                                        value = cfg.manualStudentCount,
                                        onValueChange = {
                                            cfg = cfg.copy(manualStudentCount = it)
                                            viewModel.saveConfig(cfg)
                                        },
                                        label = { Text("Manual N. Students") },
                                        placeholder = { Text("Auto") },
                                        singleLine = true,
                                        modifier = Modifier.weight(1f),
                                    )
                                }

                                OutlinedTextField(
                                    value = cfg.passMark.toString(),
                                    onValueChange = { raw ->
                                        val clean = raw.filter { it.isDigit() }
                                        val num = (clean.toLongOrNull() ?: 50L).coerceIn(0L, 100L)
                                        cfg = cfg.copy(passMark = num)
                                        viewModel.saveConfig(cfg)
                                    },
                                    label = { Text("Pass Mark Threshold (%)") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                )
                            }
                        }
                    }

                    // Auto-Observation Rules
                    item {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Text("Auto-Observation Rules", style = MaterialTheme.typography.titleMedium)
                                    Button(
                                        onClick = {
                                            viewModel.upsertObservationRule(ObservationRule(minPct = 65L, commentText = "Good progress."))
                                        },
                                        shape = RoundedCornerShape(10.dp),
                                    ) { Text("+ Rule") }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Text("Auto-update live when editing marks", style = MaterialTheme.typography.bodySmall)
                                    Switch(
                                        checked = cfg.autoApplyObservations,
                                        onCheckedChange = {
                                            cfg = cfg.copy(autoApplyObservations = it)
                                            viewModel.saveConfig(cfg)
                                        },
                                    )
                                }

                                data.observationRules.forEach { rule ->
                                    var minDraft by remember(rule.id, rule.minPct) { mutableStateOf(rule.minPct.toString()) }
                                    var textDraft by remember(rule.id, rule.commentText) { mutableStateOf(rule.commentText) }
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    ) {
                                        OutlinedTextField(
                                            value = minDraft,
                                            onValueChange = { raw ->
                                                val clean = raw.filter { it.isDigit() }
                                                minDraft = clean
                                                val pct = (clean.toLongOrNull() ?: 0L).coerceIn(0L, 100L)
                                                viewModel.upsertObservationRule(rule.copy(minPct = pct))
                                            },
                                            label = { Text("Min%") },
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                            singleLine = true,
                                            modifier = Modifier.width(76.dp),
                                        )
                                        OutlinedTextField(
                                            value = textDraft,
                                            onValueChange = {
                                                textDraft = it
                                                if (it.isNotBlank()) viewModel.upsertObservationRule(rule.copy(commentText = it))
                                            },
                                            label = { Text("Comment") },
                                            singleLine = true,
                                            modifier = Modifier.weight(1f),
                                        )
                                        IconButton(onClick = { viewModel.deleteObservationRule(rule.id) }) {
                                            Icon(Icons.Rounded.DeleteOutline, contentDescription = "Delete rule", tint = MaterialTheme.colorScheme.error)
                                        }
                                    }
                                }

                                Button(
                                    onClick = { viewModel.applyObservationRulesToAll(data.analytics, data.observationRules) },
                                    modifier = Modifier.fillMaxWidth().height(46.dp),
                                    shape = RoundedCornerShape(12.dp),
                                ) {
                                    Icon(Icons.Rounded.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Apply Rules to All Students Now")
                                }
                            }
                        }
                    }
                }
            }

            AdminSection.BACKUP -> {
                val currentUser = Firebase.auth.currentUser
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("JSON Data Backup & Restore", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    text = "Export your entire school setup, classes, subjects, student marks, and teacher assignments to a portable JSON file.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = {
                                            val stamp = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                                            exportJsonLauncher.launch("Trizzie_School_Backup_$stamp.json")
                                        },
                                        modifier = Modifier.weight(1f).height(46.dp),
                                        shape = RoundedCornerShape(12.dp),
                                    ) {
                                        Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("Export JSON")
                                    }
                                    FilledTonalButton(
                                        onClick = { importJsonLauncher.launch(arrayOf("application/json", "*/*")) },
                                        modifier = Modifier.weight(1f).height(46.dp),
                                        shape = RoundedCornerShape(12.dp),
                                    ) {
                                        Icon(Icons.Rounded.UploadFile, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("Import JSON")
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("Cloud Account", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    text = "Signed in as ${currentUser?.displayName ?: "Educator"} (${currentUser?.email ?: ""})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                OutlinedButton(
                                    onClick = {
                                        signOut(credentialManager = credentialManager, scope = scope)
                                    },
                                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("sign_out_button"),
                                    shape = RoundedCornerShape(12.dp),
                                ) {
                                    Icon(Icons.AutoMirrored.Rounded.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text("Sign Out")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
