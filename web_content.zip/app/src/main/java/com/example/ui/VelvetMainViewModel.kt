package com.example.ui

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import android.view.View
import android.view.inputmethod.InputMethodManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.AiResult
import com.example.ai.AiWriteTone
import com.example.ai.CustomTtsSpeaker
import com.example.ai.CustomVoiceRecorder
import com.example.ai.VelvetAiEngine
import com.example.ai.VelvetVoiceEngine
import com.example.data.CustomThemePreset
import com.example.data.DarkModeOption
import com.example.data.HapticProfile
import com.example.data.KeyboardFontId
import com.example.data.KeyboardLanguage
import com.example.data.ThemeMediaStorage
import com.example.data.UnicodeOutputFont
import com.example.data.VelvetSettings
import com.example.data.VelvetSettingsRepository
import com.example.ime.VelvetKeyboardService
import com.example.keyboard.ClipboardHistoryManager
import com.example.keyboard.HapticCue
import com.example.keyboard.HapticFeedbackEngine
import com.example.keyboard.ui.KeyboardSessionController
import com.example.keyboard.ui.TextTargetAdapter
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ImeStatus(
    val isEnabled: Boolean = false,
    val isSelected: Boolean = false
)

sealed interface AiPolishUiState {
    data object Idle : AiPolishUiState
    data object Loading : AiPolishUiState
    data class Success(val message: String) : AiPolishUiState
    data class Error(val message: String) : AiPolishUiState
}

class VelvetMainViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = VelvetSettingsRepository.getInstance(application)
    private val haptics = HapticFeedbackEngine(application)
    private val aiEngine = VelvetAiEngine()
    private val wavRecorder = CustomVoiceRecorder(application)
    private val voiceEngine = VelvetVoiceEngine(application, wavRecorder)
    private val ttsSpeaker = CustomTtsSpeaker(application, aiEngine)

    val isTtsSpeaking: StateFlow<Boolean> = ttsSpeaker.isSpeaking
    val isTtsSynthesizing: StateFlow<Boolean> = ttsSpeaker.isSynthesizing
    private val clipboardManager = ClipboardHistoryManager(application, repo, viewModelScope).apply {
        startListening()
    }

    val settings: StateFlow<VelvetSettings> = repo.settingsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = VelvetSettings()
    )

    private val _imeStatus = MutableStateFlow(ImeStatus())
    val imeStatus: StateFlow<ImeStatus> = _imeStatus.asStateFlow()

    private val _hasMicPermission = MutableStateFlow(false)
    val hasMicPermission: StateFlow<Boolean> = _hasMicPermission.asStateFlow()

    private val _playgroundText = MutableStateFlow(
        "um ngl i lowkey think we should grab coffee later wait what time works for you"
    )
    val playgroundText: StateFlow<String> = _playgroundText.asStateFlow()

    private val _aiPolishState = MutableStateFlow<AiPolishUiState>(AiPolishUiState.Idle)
    val aiPolishState: StateFlow<AiPolishUiState> = _aiPolishState.asStateFlow()

    var requestMicPermissionCallback: (() -> Unit)? = null
    var navigateToTabCallback: ((String) -> Unit)? = null

    private val playgroundAdapter = object : TextTargetAdapter {
        override fun commitText(text: String) {
            _playgroundText.value = _playgroundText.value + text
        }

        override fun deleteBeforeCursor(count: Int) {
            val current = _playgroundText.value
            if (current.isEmpty() || count <= 0) return
            val dropCount = count.coerceAtMost(current.length)
            _playgroundText.value = current.dropLast(dropCount)
        }

        override fun getTextBeforeCursor(maxChars: Int): String {
            return _playgroundText.value.takeLast(maxChars)
        }

        override fun replaceAllText(newText: String) {
            _playgroundText.value = newText
        }

        override fun performAction(): Boolean {
            _playgroundText.value = _playgroundText.value + "\n"
            return true
        }
    }

    val playgroundController = KeyboardSessionController(
        scope = viewModelScope,
        settingsRepo = repo,
        haptics = haptics,
        aiEngine = aiEngine,
        voiceEngine = voiceEngine,
        ttsSpeaker = ttsSpeaker,
        clipboardManager = clipboardManager,
        textTarget = playgroundAdapter,
        onSwitchIme = null,
        onOpenSettings = { navigateToTabCallback?.invoke("settings") },
        onRequestMicPermission = { requestMicPermissionCallback?.invoke() }
    )

    init {
        refreshSystemStatus()
    }

    fun refreshSystemStatus() {
        val ctx = getApplication<Application>()
        val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        val targetComponent = ComponentName(ctx, VelvetKeyboardService::class.java)
        val flattenedShort = targetComponent.flattenToShortString()
        val flattenedFull = targetComponent.flattenToString()

        val enabled = imm?.enabledInputMethodList?.any { info ->
            info.packageName == ctx.packageName &&
                (info.id == flattenedShort || info.id == flattenedFull || info.serviceName == VelvetKeyboardService::class.java.name)
        } == true

        val defaultIme = Settings.Secure.getString(
            ctx.contentResolver,
            Settings.Secure.DEFAULT_INPUT_METHOD
        ).orEmpty()
        val selected = defaultIme == flattenedShort || defaultIme == flattenedFull

        _imeStatus.value = ImeStatus(isEnabled = enabled, isSelected = selected)
        _hasMicPermission.value = ContextCompat.checkSelfPermission(
            ctx,
            android.Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        clipboardManager.syncCurrentPrimaryClip()
    }

    fun updatePlaygroundText(newText: String) {
        _playgroundText.value = newText
        playgroundController.refreshPredictions(settings.value)
    }

    fun clearPlaygroundText() {
        _playgroundText.value = ""
        _aiPolishState.value = AiPolishUiState.Idle
        playgroundController.refreshPredictions(settings.value)
    }

    fun copyPlaygroundToClipboard() {
        val text = _playgroundText.value
        if (text.isNotBlank()) {
            clipboardManager.copyToSystemClipboard(text)
            _aiPolishState.value = AiPolishUiState.Success("Copied to VelvetKey Clipboard")
        }
    }

    fun speakPlaygroundText() {
        if (ttsSpeaker.isSpeaking.value || ttsSpeaker.isSynthesizing.value) {
            ttsSpeaker.stop()
            return
        }
        val text = _playgroundText.value.trim()
        if (text.isEmpty()) {
            _aiPolishState.value = AiPolishUiState.Error("Type or dictate some text to read aloud.")
            return
        }
        ttsSpeaker.speak(
            scope = viewModelScope,
            text = text,
            language = settings.value.activeLanguage,
            onError = { err ->
                _aiPolishState.value = AiPolishUiState.Error(err)
            }
        )
    }

    fun polishPlaygroundTextWithAi(tone: AiWriteTone = AiWriteTone.NATURAL) {
        val raw = _playgroundText.value
        val currentSettings = settings.value
        if (raw.isBlank()) {
            _aiPolishState.value = AiPolishUiState.Error("Enter or dictate some text first.")
            return
        }
        viewModelScope.launch {
            _aiPolishState.value = AiPolishUiState.Loading
            when (
                val res = aiEngine.polishText(
                    rawText = raw,
                    language = currentSettings.activeLanguage,
                    removeStarters = currentSettings.aiRemoveStartersEnabled,
                    autoPunctuate = currentSettings.aiAutoPunctuationEnabled,
                    preserveSlang = currentSettings.adaptToSlangEnabled,
                    tone = tone
                )
            ) {
                is AiResult.Success -> {
                    _playgroundText.value = res.value
                    haptics.trigger(currentSettings.hapticProfile, HapticCue.AI_SUCCESS)
                    _aiPolishState.value = AiPolishUiState.Success("Improved (${tone.label}) — grammar & ?/! polished")
                    playgroundController.refreshPredictions(currentSettings)
                }
                is AiResult.Error -> {
                    _aiPolishState.value = AiPolishUiState.Error(res.message)
                }
            }
        }
    }

    fun fixPlaygroundGrammar() {
        val raw = _playgroundText.value
        val currentSettings = settings.value
        if (raw.isBlank()) {
            _aiPolishState.value = AiPolishUiState.Error("Enter some text first to check grammar.")
            return
        }
        viewModelScope.launch {
            _aiPolishState.value = AiPolishUiState.Loading
            when (
                val res = aiEngine.fixGrammarAndClarity(
                    rawText = raw,
                    language = currentSettings.activeLanguage,
                    preserveSlang = currentSettings.adaptToSlangEnabled
                )
            ) {
                is AiResult.Success -> {
                    _playgroundText.value = res.value
                    haptics.trigger(currentSettings.hapticProfile, HapticCue.AI_SUCCESS)
                    _aiPolishState.value = AiPolishUiState.Success("Grammar, spelling & punctuation fixed")
                    playgroundController.refreshPredictions(currentSettings)
                }
                is AiResult.Error -> {
                    _aiPolishState.value = AiPolishUiState.Error(res.message)
                }
            }
        }
    }

    fun autoWriteInPlayground(prompt: String, tone: AiWriteTone = AiWriteTone.NATURAL) {
        val seed = prompt.trim().ifBlank { _playgroundText.value.trim() }
        val currentSettings = settings.value
        if (seed.isEmpty()) {
            _aiPolishState.value = AiPolishUiState.Error("Describe what you want Velvet AI to write.")
            return
        }
        viewModelScope.launch {
            _aiPolishState.value = AiPolishUiState.Loading
            try {
                var receivedAny = false
                aiEngine.streamAutoGenerateText(
                    promptOrDraft = seed,
                    language = currentSettings.activeLanguage,
                    tone = tone
                ).collect { partial ->
                    receivedAny = true
                    _playgroundText.value = partial
                }
                if (receivedAny) {
                    haptics.trigger(currentSettings.hapticProfile, HapticCue.AI_SUCCESS)
                    _aiPolishState.value = AiPolishUiState.Success("Generated by Velvet AI (${tone.label})")
                    playgroundController.refreshPredictions(currentSettings)
                } else {
                    _aiPolishState.value = AiPolishUiState.Error("Velvet AI returned no text.")
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                _aiPolishState.value = AiPolishUiState.Error(
                    e.localizedMessage ?: "Velvet AI writer failed. Please try again."
                )
            }
        }
    }

    fun setActiveThemeId(themeId: String) {
        viewModelScope.launch { repo.setActiveThemeId(themeId) }
    }

    fun saveCustomTheme(preset: CustomThemePreset) {
        viewModelScope.launch { repo.saveCustomTheme(preset, setAsActive = true) }
    }

    fun deleteCustomTheme(themeId: String) {
        viewModelScope.launch { repo.deleteCustomTheme(themeId) }
    }

    suspend fun importThemeMedia(uri: Uri) =
        ThemeMediaStorage.copyPickedMediaToAppStorage(getApplication(), uri)

    fun setDarkMode(option: DarkModeOption) {
        viewModelScope.launch { repo.setDarkMode(option) }
    }

    fun setFont(fontId: KeyboardFontId) {
        viewModelScope.launch { repo.setFont(fontId) }
    }

    fun setUnicodeOutputFont(font: UnicodeOutputFont) {
        viewModelScope.launch { repo.setUnicodeOutputFont(font) }
    }

    fun setHapticProfile(profile: HapticProfile, view: View? = null) {
        viewModelScope.launch {
            repo.setHapticProfile(profile)
            haptics.trigger(profile, HapticCue.MODIFIER_TAP, view, settings.value.keySoundEnabled)
        }
    }

    fun setKeySoundEnabled(enabled: Boolean) {
        viewModelScope.launch { repo.setKeySoundEnabled(enabled) }
    }

    fun testCurrentHaptic(view: View? = null) {
        haptics.trigger(settings.value.hapticProfile, HapticCue.AI_SUCCESS, view, settings.value.keySoundEnabled)
    }

    fun setActiveLanguage(language: KeyboardLanguage) {
        viewModelScope.launch { repo.setActiveLanguage(language) }
    }

    fun toggleLanguageEnabled(language: KeyboardLanguage) {
        viewModelScope.launch { repo.toggleLanguageEnabled(language) }
    }

    fun setSwipeTypingEnabled(enabled: Boolean) {
        viewModelScope.launch { repo.setSwipeTypingEnabled(enabled) }
    }

    fun setPredictionsEnabled(enabled: Boolean) {
        viewModelScope.launch { repo.setPredictionsEnabled(enabled) }
    }

    fun setAdaptToSlangEnabled(enabled: Boolean) {
        viewModelScope.launch { repo.setAdaptToSlangEnabled(enabled) }
    }

    fun clearLearnedSlang() {
        viewModelScope.launch { repo.clearLearnedSlang() }
    }

    fun setAliveMotionEnabled(enabled: Boolean) {
        viewModelScope.launch { repo.setAliveMotionEnabled(enabled) }
    }

    fun setAiRemoveStartersEnabled(enabled: Boolean) {
        viewModelScope.launch { repo.setAiRemoveStartersEnabled(enabled) }
    }

    fun setAiAutoPunctuationEnabled(enabled: Boolean) {
        viewModelScope.launch { repo.setAiAutoPunctuationEnabled(enabled) }
    }

    fun setAiSmartPredictEnabled(enabled: Boolean) {
        viewModelScope.launch { repo.setAiSmartPredictEnabled(enabled) }
    }

    fun setPureAiVoiceEnabled(enabled: Boolean) {
        viewModelScope.launch { repo.setPureAiVoiceEnabled(enabled) }
    }

    fun setKeyPopupEnabled(enabled: Boolean) {
        viewModelScope.launch { repo.setKeyPopupEnabled(enabled) }
    }

    fun setAutoCapitalizeEnabled(enabled: Boolean) {
        viewModelScope.launch { repo.setAutoCapitalizeEnabled(enabled) }
    }

    fun setDoubleSpacePeriodEnabled(enabled: Boolean) {
        viewModelScope.launch { repo.setDoubleSpacePeriodEnabled(enabled) }
    }

    fun setClipboardHistoryEnabled(enabled: Boolean) {
        viewModelScope.launch { repo.setClipboardHistoryEnabled(enabled) }
    }

    fun clearUnpinnedClipboard() {
        viewModelScope.launch { repo.clearUnpinnedClipboard() }
    }

    fun setKeyHeightScale(scale: Float) {
        viewModelScope.launch { repo.setKeyHeightScale(scale) }
    }

    fun addCustomEmoji(symbol: String, label: String) {
        viewModelScope.launch { repo.addCustomEmoji(symbol, label) }
    }

    fun removeCustomEmoji(symbol: String) {
        viewModelScope.launch { repo.removeCustomEmoji(symbol) }
    }

    override fun onCleared() {
        super.onCleared()
        clipboardManager.stopListening()
        voiceEngine.cancel()
        ttsSpeaker.shutdown()
    }
}
