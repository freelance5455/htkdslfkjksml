package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ZingBlack
import com.example.ui.theme.ZingBorder
import com.example.ui.theme.ZingCardSurface
import com.example.ui.theme.ZingCyan
import com.example.ui.theme.ZingDarkSurface
import com.example.ui.theme.ZingEmerald
import com.example.ui.theme.ZingGold
import com.example.ui.theme.ZingNeonPink
import com.example.ui.theme.ZingTextMuted
import com.example.ui.theme.ZingTextPrimary
import com.example.ui.theme.ZingTextSecondary

data class StudioPreset(
    val title: String,
    val bgStart: Long,
    val bgEnd: Long,
    val sound: String,
    val posterRes: String = ""
)

val studioPresets = listOf(
    StudioPreset("Neon Cyber", 0xFF1F0638, 0xFF4A0E4E, "Neon Bass Drop - Zing Audio", "reel_bg_dance"),
    StudioPreset("Midnight City", 0xFF0D1B2A, 0xFF1B263B, "Lo-Fi Night Drive - Synthwave"),
    StudioPreset("Golden Sunset", 0xFF351400, 0xFF632B00, "Acoustic Sunset Beats - Chill"),
    StudioPreset("Electric Cyan", 0xFF032530, 0xFF064C60, "Future Bass - Electro Pulse")
)

val popularHashtags = listOf("#trending", "#viral", "#dance", "#tech", "#comedy", "#foodie", "#lifestyle")

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun UploadScreen(
    onBack: () -> Unit,
    onPublish: (String, String, String, String, String, String, Long, Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    var selectedVideoUri by remember { mutableStateOf<Uri?>(null) }
    var selectedPreset by remember { mutableStateOf(studioPresets[0]) }
    var caption by remember { mutableStateOf("") }
    var soundTitle by remember { mutableStateOf("Trending Sound - Original Audio") }
    var category by remember { mutableStateOf("Entertainment") }
    var enableAdRevenue by remember { mutableStateOf(true) }
    var enableGifts by remember { mutableStateOf(true) }

    // Native Android Photo/Video Picker
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedVideoUri = uri
            Toast.makeText(context, "Video selected from phone storage!", Toast.LENGTH_SHORT).show()
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ZingBlack)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 24.dp)
    ) {
        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = ZingTextPrimary
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = "Create & Upload Reel",
                    color = ZingTextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Share with millions on Zing",
                    color = ZingTextSecondary,
                    fontSize = 12.sp
                )
            }
        }

        // --- Video Selection / Generator Card ---
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = ZingCardSurface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
                .border(1.dp, ZingBorder, RoundedCornerShape(20.dp))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Video Preview Canvas
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color(selectedPreset.bgStart),
                                    Color(selectedPreset.bgEnd)
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = if (selectedVideoUri != null) Icons.Default.CheckCircle else Icons.Default.CloudUpload,
                            contentDescription = null,
                            tint = if (selectedVideoUri != null) ZingEmerald else ZingCyan,
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (selectedVideoUri != null) "Video Loaded from Device" else "Ready to Publish",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        if (selectedVideoUri != null) {
                            Text(
                                text = selectedVideoUri.toString().takeLast(30),
                                color = ZingEmerald,
                                fontSize = 11.sp
                            )
                        } else {
                            Text(
                                text = "Using ${selectedPreset.title} theme",
                                color = ZingTextSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Upload from Phone Button
                Button(
                    onClick = {
                        videoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                        )
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ZingDarkSurface,
                        contentColor = ZingCyan
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, ZingCyan.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .testTag("pick_video_from_phone_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.VideoLibrary,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (selectedVideoUri == null) "Select Short Video from Phone" else "Change Selected Video",
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Preset Theme Selector
                Text(
                    text = "Or choose a dynamic visual theme:",
                    color = ZingTextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.align(Alignment.Start)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    studioPresets.forEach { preset ->
                        val isSelected = selectedPreset.title == preset.title
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(preset.bgStart))
                                .border(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) ZingNeonPink else ZingBorder,
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable {
                                    selectedPreset = preset
                                    soundTitle = preset.sound
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = preset.title,
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // --- Video Details Input Card ---
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = ZingCardSurface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .border(1.dp, ZingBorder, RoundedCornerShape(20.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Caption
                OutlinedTextField(
                    value = caption,
                    onValueChange = { if (it.length <= 300) caption = it },
                    label = { Text("Write a catchy caption & tags...", color = ZingTextSecondary) },
                    placeholder = { Text("What's happening in this vibe? Drop emojis! 🔥✨", color = ZingTextMuted) },
                    minLines = 3,
                    maxLines = 5,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ZingTextPrimary,
                        unfocusedTextColor = ZingTextPrimary,
                        focusedBorderColor = ZingNeonPink,
                        unfocusedBorderColor = ZingBorder
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("upload_caption_field")
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.End
                ) {
                    Text(
                        text = "${caption.length}/300",
                        color = ZingTextMuted,
                        fontSize = 11.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Hashtags helper chips
                Text(text = "Trending Hashtags:", color = ZingTextSecondary, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(6.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    popularHashtags.forEach { tag ->
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = ZingDarkSurface,
                            modifier = Modifier.clickable {
                                if (!caption.contains(tag)) {
                                    caption = if (caption.isBlank()) tag else "$caption $tag"
                                }
                            }
                        ) {
                            Text(
                                text = tag,
                                color = ZingCyan,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Sound Title input
                OutlinedTextField(
                    value = soundTitle,
                    onValueChange = { soundTitle = it },
                    label = { Text("Audio Track", color = ZingTextSecondary) },
                    leadingIcon = {
                        Icon(Icons.Default.MusicNote, contentDescription = null, tint = ZingGold)
                    },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ZingTextPrimary,
                        unfocusedTextColor = ZingTextPrimary,
                        focusedBorderColor = ZingGold,
                        unfocusedBorderColor = ZingBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // --- Monetization Settings Section (शुरू से दिखे) ---
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = ZingCardSurface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .border(1.dp, ZingBorder, RoundedCornerShape(20.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = ZingGold,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Monetization Settings",
                        color = ZingTextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Ad Revenue share toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Tv, contentDescription = null, tint = ZingEmerald, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("In-Feed Ad Revenue Share", color = ZingTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Text("Earn 55% ad revenue on views", color = ZingTextMuted, fontSize = 11.sp)
                        }
                    }
                    Switch(
                        checked = enableAdRevenue,
                        onCheckedChange = { enableAdRevenue = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = ZingEmerald
                        )
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Virtual gifts toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CardGiftcard, contentDescription = null, tint = ZingNeonPink, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text("Virtual Gifts & Coins", color = ZingTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Text("Allow viewers to send tips & gifts", color = ZingTextMuted, fontSize = 11.sp)
                        }
                    }
                    Switch(
                        checked = enableGifts,
                        onCheckedChange = { enableGifts = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = ZingNeonPink
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Big Publish Button
        Button(
            onClick = {
                val finalCaption = caption.ifBlank { "Check out my new video on Sinji Shorts! 🚀 #viral #sinjishorts" }
                onPublish(
                    finalCaption,
                    soundTitle,
                    "#trending,#viral",
                    category,
                    selectedVideoUri?.toString() ?: "",
                    selectedPreset.posterRes,
                    selectedPreset.bgStart,
                    selectedPreset.bgEnd
                )
                Toast.makeText(context, "Reel published to Sinji Shorts feed! 🎉", Toast.LENGTH_SHORT).show()
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .padding(horizontal = 16.dp)
                .testTag("publish_video_button"),
            colors = ButtonDefaults.buttonColors(
                containerColor = ZingNeonPink,
                contentColor = Color.White
            ),
            shape = RoundedCornerShape(26.dp)
        ) {
            Text(
                text = "Post Reel to Sinji Shorts",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 16.sp
            )
        }
    }
}
