package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SecurityLabData
import com.example.model.AppLanguage
import com.example.ui.components.CyberCard
import com.example.ui.components.SafeLabDisclaimer
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SourceAndSetupScreen(
    currentLanguage: AppLanguage,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()
    var selectedFileIndex by remember { mutableIntStateOf(0) }

    val singleFileHtml = remember {
        runCatching {
            context.assets.open("web/index.html").bufferedReader().use { it.readText() }
        }.getOrElse { SecurityLabData.webHtmlCode }
    }

    val saveHtmlLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/html")
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(singleFileHtml.toByteArray(Charsets.UTF_8))
                }
                Toast.makeText(
                    context,
                    if (currentLanguage == AppLanguage.EN)
                        "Saved tk-link-security-lab.html! Tap it in Files to open in Chrome."
                    else
                        "সেভ হয়েছে! ফাইল ম্যানেজার থেকে Chrome দিয়ে ওপেন করুন।",
                    Toast.LENGTH_LONG
                ).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Save failed: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val fileNames = listOf("Single HTML", "Mobile Guide")
    val fileContents = listOf(
        singleFileHtml,
        SecurityLabData.localDeploymentGuide
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBackground)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        SafeLabDisclaimer(currentLanguage = currentLanguage)

        // Mobile-First Single HTML Export Card
        CyberCard(borderColor = NeonGreen.copy(alpha = 0.55f)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.PhoneAndroid,
                    contentDescription = "Mobile Ready",
                    tint = NeonGreen,
                    modifier = Modifier.size(22.dp)
                )
                Text(
                    text = if (currentLanguage == AppLanguage.EN)
                        "MOBILE-READY SINGLE HTML FILE (NO PC NEEDED)"
                    else
                        "মোবাইল-রেডি সিঙ্গেল HTML ফাইল (PC লাগবে না)",
                    color = NeonGreen,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = if (currentLanguage == AppLanguage.EN)
                    "All HTML, CSS, JavaScript, Bengali/English support, and all 4 security labs are combined into ONE self-contained file. Save it to your phone and open directly with Chrome or any mobile browser!"
                else
                    "সমস্ত HTML, CSS, JavaScript, বাংলা/ইংরেজি ভাষা ও ৪টি সিকিউরিটি ল্যাব একটি মাত্র ফাইলের ভেতরে রাখা হয়েছে। ফোনে সেভ করে সরাসরি Chrome দিয়ে চালু করুন—কোনো কম্পিউটার বা সার্ভার লাগবে না!",
                color = TextSecondary,
                fontSize = 12.sp,
                lineHeight = 17.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = { saveHtmlLauncher.launch("tk-link-security-lab.html") },
                colors = ButtonDefaults.buttonColors(containerColor = NeonGreen),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("save_single_html_button")
            ) {
                Icon(
                    imageVector = Icons.Default.FileDownload,
                    contentDescription = "Download Single HTML",
                    tint = Color.Black,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (currentLanguage == AppLanguage.EN)
                        "Save tk-link-security-lab.html to Phone"
                    else
                        "ফোনে tk-link-security-lab.html সেভ করুন",
                    color = Color.Black,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 13.sp
                )
            }
        }

        // Step-by-step Mobile Guide Card
        CyberCard(borderColor = NeonCyan.copy(alpha = 0.4f)) {
            Text(
                text = if (currentLanguage == AppLanguage.EN)
                    "📱 How to Run on Mobile (3 Easy Steps)"
                else
                    "📱 মোবাইলে চালানোর ৩টি সহজ ধাপ",
                color = NeonCyan,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = if (currentLanguage == AppLanguage.EN)
                    "1. Tap the green 'Save tk-link-security-lab.html to Phone' button above.\n" +
                    "2. Open your phone's Files app (Downloads) and tap the saved .html file.\n" +
                    "3. Select Chrome (or HTML Viewer) — all 4 interactive labs will work 100% offline!"
                else
                    "১. উপরের সবুজ 'ফোনে tk-link-security-lab.html সেভ করুন' বাটনে চাপ দিন।\n" +
                    "২. ফোনের File Manager বা Downloads থেকে সেভ করা .html ফাইলটিতে ট্যাপ করুন।\n" +
                    "৩. 'Open with Chrome' বা 'HTML Viewer' নির্বাচন করুন — অফলাইনেই পুরো ওয়েব অ্যাপ চলবে!",
                color = TextPrimary,
                fontSize = 12.sp,
                lineHeight = 18.sp
            )
        }

        // File Selector Tabs
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            fileNames.forEachIndexed { index, name ->
                val isSelected = selectedFileIndex == index
                Surface(
                    color = if (isSelected) NeonPurple.copy(alpha = 0.22f) else CyberSurfaceElevated,
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isSelected) NeonPurple else Color.Transparent
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { selectedFileIndex = index }
                ) {
                    Box(
                        modifier = Modifier.padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = name,
                            color = if (isSelected) NeonPurple else TextSecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                    }
                }
            }
        }

        // Code Viewer with Copy Button
        CyberCard(borderColor = NeonAmber.copy(alpha = 0.35f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = if (selectedFileIndex == 0) "tk-link-security-lab.html" else "MOBILE_GUIDE.md",
                    color = NeonAmber,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp
                )

                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText(fileNames[selectedFileIndex], fileContents[selectedFileIndex])
                        clipboard.setPrimaryClip(clip)
                        Toast.makeText(
                            context,
                            if (currentLanguage == AppLanguage.EN) "Complete HTML copied to clipboard!" else "সম্পূর্ণ HTML কোড কপি হয়েছে!",
                            Toast.LENGTH_SHORT
                        ).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E2A48)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NeonAmber),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.testTag("copy_code_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy",
                        tint = NeonAmber,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (currentLanguage == AppLanguage.EN) "Copy HTML" else "HTML কপি",
                        color = NeonAmber,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            val codeScrollState = rememberScrollState()

            Surface(
                color = Color(0xFF05080E),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF162036)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(360.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(10.dp)
                        .verticalScroll(rememberScrollState())
                        .horizontalScroll(codeScrollState)
                ) {
                    Text(
                        text = fileContents[selectedFileIndex],
                        color = Color(0xFF93C5FD),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.5.sp,
                        lineHeight = 15.sp
                    )
                }
            }
        }
    }
}
