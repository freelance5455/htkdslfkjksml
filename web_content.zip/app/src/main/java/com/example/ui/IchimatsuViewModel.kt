package com.example.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.IchimatsuAiRepository
import com.example.data.CompanionRepository
import com.example.data.LearnedMoveDoc
import com.example.data.StageBackground
import com.example.data.UserCompanionPrefs
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

private const val TAG = "IchimatsuViewModel"
private const val STOP_TIMEOUT_MILLIS = 5000L

sealed interface UiState {
    data object Idle : UiState
    data object Loading : UiState
    data class Streaming(val text: String) : UiState
    data class Success(val text: String) : UiState
    data class Error(val message: String) : UiState
}

data class StageUiState(
    val currentMove: String = "idle",
    val background: StageBackground = StageBackground.SAKURA_SHRINE,
    val dressColor: String = "orig",
    val jpMode: Boolean = true,
    val learnedMoves: List<String> = emptyList(),
    val isMoveStudioOpen: Boolean = false,
    val moveStudioInitialTab: Int = 0,
    val isFullscreen: Boolean = false,
    val isWebModelReady: Boolean = false,
    val lastFailedPrompt: String? = null
)

class IchimatsuViewModel(
    private val currentUserId: String,
    private val displayName: String,
    private val companionRepository: CompanionRepository? = null,
    private val isGuest: Boolean = false,
    private val aiRepository: IchimatsuAiRepository = IchimatsuAiRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow<UiState>(UiState.Idle)
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    private val _stageState = MutableStateFlow(StageUiState())
    val stageState: StateFlow<StageUiState> = _stageState.asStateFlow()

    private val _jsCommands = MutableSharedFlow<String>(extraBufferCapacity = 32)
    val jsCommands: SharedFlow<String> = _jsCommands.asSharedFlow()

    private var activeAiJob: Job? = null
    private var cloudSyncApplied = false

    val cloudPrefs: StateFlow<UserCompanionPrefs?> = if (!isGuest && companionRepository != null) {
        companionRepository.observeUserPrefs(currentUserId)
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing user prefs", rootError)
                _uiState.value = UiState.Error(rootError.localizedMessage ?: "Failed to sync profile")
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = null
            )
    } else {
        MutableStateFlow(null)
    }

    val cloudLearnedMoves: StateFlow<List<LearnedMoveDoc>> = if (!isGuest && companionRepository != null) {
        companionRepository.observeLearnedMoves(currentUserId)
            .map { list -> list.sortedBy { it.name } }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing learned moves", rootError)
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = emptyList()
            )
    } else {
        MutableStateFlow(emptyList())
    }

    init {
        if (!isGuest && companionRepository != null) {
            viewModelScope.launch {
                companionRepository.ensureUserProfile(currentUserId, displayName)
            }
            viewModelScope.launch {
                cloudPrefs.collect { prefs ->
                    if (prefs != null) {
                        val bg = StageBackground.fromId(prefs.backgroundId)
                        _stageState.update {
                            it.copy(
                                background = bg,
                                dressColor = prefs.dressColor.ifBlank { "orig" },
                                jpMode = prefs.jpMode
                            )
                        }
                        if (_stageState.value.isWebModelReady && !cloudSyncApplied) {
                            cloudSyncApplied = true
                            applyCloudStateToWeb(prefs.dressColor, prefs.jpMode, cloudLearnedMoves.value)
                        }
                    }
                }
            }
            viewModelScope.launch {
                cloudLearnedMoves.collect { moves ->
                    if (moves.isNotEmpty()) {
                        _stageState.update { state ->
                            val merged = (state.learnedMoves + moves.map { it.name }).distinct()
                            state.copy(learnedMoves = merged)
                        }
                        if (_stageState.value.isWebModelReady) {
                            pushLearnedMovesToWeb(moves)
                        }
                    }
                }
            }
        }
    }

    fun openMoveStudio(initialTab: Int = 0) {
        _stageState.update { it.copy(isMoveStudioOpen = true, moveStudioInitialTab = initialTab) }
    }

    fun closeMoveStudio() {
        _stageState.update { it.copy(isMoveStudioOpen = false) }
    }

    fun setFullscreen(fullscreen: Boolean) {
        _stageState.update { it.copy(isFullscreen = fullscreen) }
    }

    fun dismissError() {
        if (_uiState.value is UiState.Error) {
            _uiState.value = UiState.Idle
        }
    }

    fun selectBackground(background: StageBackground) {
        _stageState.update { it.copy(background = background) }
        val repo = companionRepository
        if (!isGuest && repo != null) {
            viewModelScope.launch {
                repo.updatePreferences(
                    userId = currentUserId,
                    displayName = displayName,
                    backgroundId = background.id
                ).onFailure { err ->
                    _uiState.value = UiState.Error(err.localizedMessage ?: "Failed to save stage background.")
                }
            }
        }
    }

    fun onWebModelLoaded() {
        _stageState.update { it.copy(isWebModelReady = true) }
        if (isGuest || companionRepository == null) return
        val prefs = cloudPrefs.value
        val moves = cloudLearnedMoves.value
        if (prefs != null && !cloudSyncApplied) {
            cloudSyncApplied = true
            applyCloudStateToWeb(prefs.dressColor, prefs.jpMode, moves)
        } else if (moves.isNotEmpty()) {
            pushLearnedMovesToWeb(moves)
        }
    }

    private fun applyCloudStateToWeb(
        dressColor: String,
        jpMode: Boolean,
        moves: List<LearnedMoveDoc>
    ) {
        if (dressColor.isNotBlank() && dressColor != "orig") {
            dispatchJs("window.__ichimatsuApi && window.__ichimatsuApi.setDress(${JSONObject.quote(dressColor)}, true);")
        }
        dispatchJs("window.__ichimatsuApi && window.__ichimatsuApi.setJpMode(${jpMode});")
        if (moves.isNotEmpty()) {
            pushLearnedMovesToWeb(moves)
        }
    }

    private fun pushLearnedMovesToWeb(moves: List<LearnedMoveDoc>) {
        val sb = StringBuilder("if(window.__ichimatsuApi && window.__ichimatsuApi.registerLearned){")
        for (m in moves) {
            val stepsArr = JSONArray(m.steps).toString()
            sb.append("window.__ichimatsuApi.registerLearned(${JSONObject.quote(m.name)}, $stepsArr);")
        }
        sb.append("}")
        dispatchJs(sb.toString())
    }

    fun onDressChangedFromWeb(dressColor: String) {
        val clean = dressColor.ifBlank { "orig" }
        _stageState.update { it.copy(dressColor = clean) }
        val repo = companionRepository
        if (!isGuest && repo != null) {
            viewModelScope.launch {
                repo.updatePreferences(
                    userId = currentUserId,
                    displayName = displayName,
                    dressColor = clean
                )
            }
        }
    }

    fun onJpModeChangedFromWeb(jpMode: Boolean) {
        _stageState.update { it.copy(jpMode = jpMode) }
        val repo = companionRepository
        if (!isGuest && repo != null) {
            viewModelScope.launch {
                repo.updatePreferences(
                    userId = currentUserId,
                    displayName = displayName,
                    jpMode = jpMode
                )
            }
        }
    }

    fun onMoveLearnedFromWeb(moveName: String, stepsJson: String) {
        val steps = try {
            val arr = JSONArray(stepsJson)
            List(arr.length()) { idx -> arr.optString(idx) }.filter { it.isNotBlank() }
        } catch (_: Exception) {
            emptyList()
        }
        if (moveName.isBlank() || steps.isEmpty()) return
        val repo = companionRepository
        if (!isGuest && repo != null) {
            viewModelScope.launch {
                repo.saveLearnedMove(currentUserId, moveName, steps)
            }
        }
    }

    fun updateStageFromWeb(currentMove: String, learnedJson: String) {
        val parsedLearned = try {
            val arr = JSONArray(learnedJson)
            List(arr.length()) { idx -> arr.optString(idx) }.filter { it.isNotBlank() }
        } catch (_: Exception) {
            _stageState.value.learnedMoves
        }
        _stageState.update {
            it.copy(
                currentMove = currentMove.ifBlank { "idle" },
                learnedMoves = parsedLearned
            )
        }
    }

    fun playMoves(moves: List<String>) {
        if (moves.isEmpty()) return
        val jsonArray = JSONArray(moves).toString()
        dispatchJs("window.__ichimatsuApi && window.__ichimatsuApi.play($jsonArray);")
    }

    fun applyCustomPose(spec: String, mood: String? = null) {
        val quotedSpec = JSONObject.quote(spec)
        val faceCall = if (!mood.isNullOrBlank()) {
            "window.__ichimatsuApi.setFace(${JSONObject.quote(mood)});"
        } else ""
        dispatchJs(
            "if(window.__ichimatsuApi){window.__ichimatsuApi.setCustom($quotedSpec);window.__ichimatsuApi.play(['custom']);$faceCall}"
        )
    }

    fun stopMotion() {
        dispatchJs("window.__ichimatsuApi && window.__ichimatsuApi.stop();")
    }

    fun askCharacter(prompt: String) {
        val trimmed = prompt.trim()
        if (trimmed.isEmpty()) return
        _stageState.update { it.copy(lastFailedPrompt = trimmed, isMoveStudioOpen = false) }
        val quoted = JSONObject.quote(trimmed)
        dispatchJs("window.__ichimatsuApi && window.__ichimatsuApi.ask($quoted);")
    }

    fun retryLastPrompt() {
        val last = _stageState.value.lastFailedPrompt ?: return
        dismissError()
        askCharacter(last)
    }

    fun setDressColor(color: String) {
        dispatchJs("window.__ichimatsuApi && window.__ichimatsuApi.setDress(${JSONObject.quote(color)});")
    }

    fun generateForBridge(
        reqId: String,
        messagesJson: String,
        imageBase64: String?,
        onChunk: (String) -> Unit,
        onSuccess: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        activeAiJob?.cancel()
        activeAiJob = viewModelScope.launch {
            _uiState.value = UiState.Loading
            var finalText = ""
            try {
                val turns = withContext(Dispatchers.Default) {
                    aiRepository.parseMessagesJson(messagesJson)
                }
                if (turns.isEmpty()) {
                    throw IllegalArgumentException("Cannot send an empty conversation.")
                }
                val latestUserPrompt = turns.lastOrNull { it.role == "user" }?.text
                if (!latestUserPrompt.isNullOrBlank()) {
                    _stageState.update { it.copy(lastFailedPrompt = latestUserPrompt) }
                }

                val bitmap = withContext(Dispatchers.Default) {
                    decodeScaledBitmap(imageBase64)
                }

                aiRepository.streamReply(turns, bitmap).collect { accumulated ->
                    finalText = accumulated
                    _uiState.value = UiState.Streaming(accumulated)
                    onChunk(accumulated)
                }

                if (finalText.isNotBlank()) {
                    _uiState.value = UiState.Success(finalText)
                    onSuccess(finalText)
                } else {
                    val emptyMsg = "Gemini returned an empty response. Please try again."
                    _uiState.value = UiState.Error(emptyMsg)
                    onError(emptyMsg)
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Firebase AI generation timed out", e)
                val msg = "Generation timed out after 60 seconds. Check your connection and retry."
                _uiState.value = UiState.Error(msg)
                onError(msg)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Firebase AI generation failed", e)
                val msg = e.localizedMessage?.takeIf { it.isNotBlank() }
                    ?: "Failed to reach Gemini AI. Please check network or App Check setup."
                _uiState.value = UiState.Error(msg)
                onError(msg)
            }
        }
    }

    private fun dispatchJs(script: String) {
        _jsCommands.tryEmit(script)
    }

    private fun decodeScaledBitmap(base64Str: String?): Bitmap? {
        if (base64Str.isNullOrBlank()) return null
        return try {
            val bytes = Base64.decode(base64Str, Base64.DEFAULT)
            val raw = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
            val maxDim = 512
            if (raw.width <= maxDim && raw.height <= maxDim) {
                raw
            } else {
                val scale = maxDim.toFloat() / maxOf(raw.width, raw.height)
                val w = (raw.width * scale).toInt().coerceAtLeast(1)
                val h = (raw.height * scale).toInt().coerceAtLeast(1)
                Bitmap.createScaledBitmap(raw, w, h, true).also {
                    if (it !== raw) raw.recycle()
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to decode camera snapshot bitmap", e)
            null
        }
    }

    override fun onCleared() {
        super.onCleared()
        activeAiJob?.cancel()
    }
}
