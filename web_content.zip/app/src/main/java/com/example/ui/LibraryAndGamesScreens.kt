package com.example.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.BookEntity
import com.example.data.ImportedGameEntity

@Composable
fun LibraryScreen(
    books: List<BookEntity>,
    onImportPdfUri: (Uri) -> Unit,
    onGenerateSampleBook: (isLarge: Boolean) -> Unit,
    onOpenBook: (BookEntity) -> Unit,
    onDeleteBook: (BookEntity) -> Unit,
    onNavigateSection: (AppSection) -> Unit,
    onOpenExportZipDialog: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val pdfPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            onImportPdfUri(uri)
        }
    }

    Box(
        contentAlignment = Alignment.TopCenter,
        modifier = modifier
            .fillMaxSize()
            .testTag("library_screen")
    ) {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 640.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.AutoMirrored.Filled.MenuBook,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(26.dp)
                            )
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "MoonChess Offline PDF Library",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                Text(
                                    text = "Open any chess PDF book from your phone. Double-tap diagrams to scan onto the docked chessboard.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                                )
                            }
                        }

                        Button(
                            onClick = { pdfPickerLauncher.launch(arrayOf("application/pdf")) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("open_pdf_document_button")
                        ) {
                            Icon(Icons.Default.FileOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(stringResource(R.string.import_pdf), fontWeight = FontWeight.SemiBold)
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            OutlinedButton(
                                onClick = { onGenerateSampleBook(false) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("create_small_sample_pdf_button")
                            ) {
                                Text("Sample Primer (12p)", fontSize = 12.sp, maxLines = 1)
                            }
                            OutlinedButton(
                                onClick = { onGenerateSampleBook(true) },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("create_large_sample_pdf_button")
                            ) {
                                Text("GM Anthology (60p)", fontSize = 12.sp, maxLines = 1)
                            }
                        }

                        OutlinedButton(
                            onClick = onOpenExportZipDialog,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("export_android_project_zip_button")
                        ) {
                            Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Download / Export Android Project (.ZIP)", fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }

            // Quick navigation shortcuts for Study Hub sections
            item {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedButton(
                        onClick = { onNavigateSection(AppSection.NOTES) },
                        modifier = Modifier.weight(1f).testTag("shortcut_notes_button")
                    ) {
                        Text("My Notes", fontSize = 12.sp)
                    }
                    OutlinedButton(
                        onClick = { onNavigateSection(AppSection.PRINCIPLES) },
                        modifier = Modifier.weight(1f).testTag("shortcut_principles_button")
                    ) {
                        Text("Principles", fontSize = 12.sp)
                    }
                    OutlinedButton(
                        onClick = { onNavigateSection(AppSection.GAMES) },
                        modifier = Modifier.weight(1f).testTag("shortcut_games_button")
                    ) {
                        Text("Import Games", fontSize = 12.sp)
                    }
                }
            }

            item {
                Text(
                    text = "Saved Books (${books.size})",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            if (books.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp)
                        ) {
                            Text(
                                "Your offline book shelf is empty",
                                fontWeight = FontWeight.SemiBold,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                "Tap 'Open PDF Book' above to pick a chess PDF from your phone, or generate the offline Botvinnik Study Primer to test scanning right away.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                items(books, key = { it.id }) { book ->
                    val progress = (book.lastReadPage.toFloat() / book.totalPages.coerceAtLeast(1).toFloat())
                        .coerceIn(0f, 1f)
                    Card(
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenBook(book) }
                            .testTag("book_card_${book.id}")
                    ) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(14.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = book.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "Page ${book.lastReadPage} of ${book.totalPages} • ${(book.fileSize / 1024).coerceAtLeast(1)} KB",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                IconButton(
                                    onClick = { onDeleteBook(book) },
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Delete,
                                        contentDescription = "Remove ${book.title}",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                            LinearProgressIndicator(
                                progress = { progress },
                                modifier = Modifier.fillMaxWidth().height(5.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GameImportScreen(
    importedGames: List<ImportedGameEntity>,
    isFetchingOnline: Boolean,
    onFetchLichess: (String) -> Unit,
    onFetchChessCom: (String) -> Unit,
    onImportRawPgn: (String) -> Unit,
    onOpenGameOnBoard: (ImportedGameEntity) -> Unit,
    onDeleteGame: (String) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onBack)

    var lichessUser by remember { mutableStateOf("") }
    var chessComUser by remember { mutableStateOf("") }
    var pgnText by remember { mutableStateOf("") }

    Box(
        contentAlignment = Alignment.TopCenter,
        modifier = modifier
            .fillMaxSize()
            .testTag("game_import_screen")
    ) {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 640.dp)
        ) {
            item {
                Text(
                    "Import Games (Lichess • Chess.com • PGN)",
                    style = MaterialTheme.typography.headlineSmall
                )
                Text(
                    "Load any game onto the docked MoonChess board to analyze with the engine and write move-by-move comments.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Lichess & Chess.com Username Fetch Card
            item {
                Card(
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.padding(14.dp)
                    ) {
                        Text("Import by Public Username", fontWeight = FontWeight.SemiBold)

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = lichessUser,
                                onValueChange = { lichessUser = it },
                                label = { Text("Lichess Username") },
                                singleLine = true,
                                modifier = Modifier.weight(1f).testTag("lichess_username_input")
                            )
                            Button(
                                onClick = { if (lichessUser.isNotBlank()) onFetchLichess(lichessUser) },
                                enabled = !isFetchingOnline && lichessUser.isNotBlank(),
                                modifier = Modifier.height(50.dp).testTag("fetch_lichess_button")
                            ) {
                                Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Lichess")
                            }
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = chessComUser,
                                onValueChange = { chessComUser = it },
                                label = { Text("Chess.com Username") },
                                singleLine = true,
                                modifier = Modifier.weight(1f).testTag("chesscom_username_input")
                            )
                            Button(
                                onClick = { if (chessComUser.isNotBlank()) onFetchChessCom(chessComUser) },
                                enabled = !isFetchingOnline && chessComUser.isNotBlank(),
                                modifier = Modifier.height(50.dp).testTag("fetch_chesscom_button")
                            ) {
                                Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Chess.com")
                            }
                        }

                        if (isFetchingOnline) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                CircularProgressIndicator(strokeWidth = 2.dp, modifier = Modifier.size(18.dp))
                                Text("Downloading recent games...", style = MaterialTheme.typography.labelLarge)
                            }
                        }
                    }
                }
            }

            // Offline PGN Paste Card
            item {
                Card(
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(14.dp)
                    ) {
                        Text("Offline PGN Import", fontWeight = FontWeight.SemiBold)
                        OutlinedTextField(
                            value = pgnText,
                            onValueChange = { pgnText = it },
                            placeholder = { Text("1. e4 c5 2. Nf3 d6 {Najdorf preparation} ...") },
                            minLines = 3,
                            maxLines = 6,
                            modifier = Modifier.fillMaxWidth().testTag("offline_pgn_import_input")
                        )
                        Button(
                            onClick = {
                                if (pgnText.isNotBlank()) {
                                    onImportRawPgn(pgnText)
                                    pgnText = ""
                                }
                            },
                            enabled = pgnText.isNotBlank(),
                            modifier = Modifier.fillMaxWidth().testTag("offline_pgn_import_button")
                        ) {
                            Text("Load PGN on Analysis Board & Save")
                        }
                    }
                }
            }

            item {
                HorizontalDivider()
                Spacer(Modifier.height(4.dp))
                Text(
                    "Saved & Imported Games (${importedGames.size})",
                    style = MaterialTheme.typography.titleMedium
                )
            }

            if (importedGames.isEmpty()) {
                item {
                    Text(
                        "No games imported yet. Fetch games from Lichess or Chess.com above, or paste any PGN offline.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                items(importedGames, key = { it.id }) { game ->
                    Card(
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenGameOnBoard(game) }
                            .testTag("imported_game_card_${game.id}")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(12.dp)
                        ) {
                            Surface(
                                color = MaterialTheme.colorScheme.primaryContainer,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = game.platform.uppercase(),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                )
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${game.white} vs ${game.black} (${game.result})",
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                val sub = buildString {
                                    if (game.openingName.isNotBlank()) append(game.openingName).append(" • ")
                                    if (game.datePlayed.isNotBlank()) append(game.datePlayed)
                                }.trimEnd(' ', '•')
                                if (sub.isNotBlank()) {
                                    Text(
                                        text = sub,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            IconButton(onClick = { onOpenGameOnBoard(game) }) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Analyze on board", tint = MaterialTheme.colorScheme.primary)
                            }
                            IconButton(onClick = { onDeleteGame(game.id) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete game", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }
    }
}
