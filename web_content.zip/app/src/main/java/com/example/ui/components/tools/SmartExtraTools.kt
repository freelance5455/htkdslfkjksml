package com.example.ui.components.tools

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

// 1. AGE DIFFERENCE CALCULATOR DIALOG (आयु में अंतर)
@Composable
fun AgeDifferenceDialog(onDismiss: () -> Unit) {
    var p1Year by remember { mutableIntStateOf(1992) }
    var p1Month by remember { mutableIntStateOf(5) }
    var p1Day by remember { mutableIntStateOf(10) }

    var p2Year by remember { mutableIntStateOf(1996) }
    var p2Month by remember { mutableIntStateOf(8) }
    var p2Day by remember { mutableIntStateOf(20) }

    val yearsList = (1940..2026).toList()

    val (diffText, isP1Older) = remember(p1Year, p1Month, p1Day, p2Year, p2Month, p2Day) {
        val cal1 = Calendar.getInstance().apply { set(p1Year, p1Month - 1, p1Day) }
        val cal2 = Calendar.getInstance().apply { set(p2Year, p2Month - 1, p2Day) }

        val olderCal = if (cal1.before(cal2)) cal1 else cal2
        val youngerCal = if (cal1.before(cal2)) cal2 else cal1
        val p1Older = cal1.before(cal2)

        var y = youngerCal.get(Calendar.YEAR) - olderCal.get(Calendar.YEAR)
        var m = youngerCal.get(Calendar.MONTH) - olderCal.get(Calendar.MONTH)
        var d = youngerCal.get(Calendar.DAY_OF_MONTH) - olderCal.get(Calendar.DAY_OF_MONTH)

        if (d < 0) {
            m--
            d += 30
        }
        if (m < 0) {
            y--
            m += 12
        }

        val totalDays = (youngerCal.timeInMillis - olderCal.timeInMillis) / (1000 * 60 * 60 * 24)
        Triple("$y वर्ष, $m माह, $d दिन ($totalDays दिन)", p1Older, y)
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(modifier = Modifier.fillMaxWidth(0.94f).clip(RoundedCornerShape(20.dp)), color = Color.White, shadowElevation = 8.dp) {
            Column(modifier = Modifier.padding(18.dp).verticalScroll(rememberScrollState())) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "👥 आयु में अंतर (Age Difference)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(text = "प्रथम व्यक्ति का जन्म (Person 1):", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1565C0))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(value = "$p1Day", onValueChange = { p1Day = it.toIntOrNull() ?: 1 }, label = { Text("दिन", fontSize = 10.sp) }, modifier = Modifier.weight(1f), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(value = "$p1Month", onValueChange = { p1Month = it.toIntOrNull() ?: 1 }, label = { Text("माह", fontSize = 10.sp) }, modifier = Modifier.weight(1f), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(value = "$p1Year", onValueChange = { p1Year = it.toIntOrNull() ?: 1990 }, label = { Text("वर्ष", fontSize = 10.sp) }, modifier = Modifier.weight(1.2f), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(text = "द्वितीय व्यक्ति का जन्म (Person 2):", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFFC2185B))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(value = "$p2Day", onValueChange = { p2Day = it.toIntOrNull() ?: 1 }, label = { Text("दिन", fontSize = 10.sp) }, modifier = Modifier.weight(1f), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(value = "$p2Month", onValueChange = { p2Month = it.toIntOrNull() ?: 1 }, label = { Text("माह", fontSize = 10.sp) }, modifier = Modifier.weight(1f), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(value = "$p2Year", onValueChange = { p2Year = it.toIntOrNull() ?: 1990 }, label = { Text("वर्ष", fontSize = 10.sp) }, modifier = Modifier.weight(1.2f), singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                }

                Spacer(modifier = Modifier.height(14.dp))

                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)), shape = RoundedCornerShape(12.dp)) {
                    Column(modifier = Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = if (isP1Older) "व्यक्ति 1, व्यक्ति 2 से बड़ा है:" else "व्यक्ति 2, व्यक्ति 1 से बड़ा है:", fontSize = 12.sp, color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = diffText, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF1B5E20), textAlign = TextAlign.Center)
                    }
                }
            }
        }
    }
}

// 2. DAILY NOTES DIALOG (दैनिक नोट्स)
data class NoteEntry(val id: Long, val text: String, val dateStr: String)

@Composable
fun NotesDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    var newNoteText by remember { mutableStateOf("") }
    val notesList = remember {
        mutableStateListOf(
            NoteEntry(1, "सोमवार को रुद्राभिषेक पूजन सामग्री लाना है।", "03 Oct 2026"),
            NoteEntry(2, "एकादशी व्रत का संकल्प व फलहारी व्यवस्था।", "02 Oct 2026")
        )
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(modifier = Modifier.fillMaxWidth(0.94f).clip(RoundedCornerShape(20.dp)), color = Color.White, shadowElevation = 8.dp) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "📝 दैनिक नोट्स (Notes & Diary)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = newNoteText,
                        onValueChange = { newNoteText = it },
                        placeholder = { Text("नया नोट लिखें...", fontSize = 12.sp) },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Button(
                        onClick = {
                            if (newNoteText.isNotBlank()) {
                                val d = SimpleDateFormat("dd MMM yyyy", Locale.US).format(Date())
                                notesList.add(0, NoteEntry(System.currentTimeMillis(), newNoteText, d))
                                newNoteText = ""
                                Toast.makeText(context, "नोट सुरक्षित हो गया!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Black)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Add")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(modifier = Modifier.weight(1f, fill = false).height(280.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(notesList) { note ->
                        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFFF9FBE7)), border = BorderStroke(1.dp, Color(0xFFE6EE9C)), shape = RoundedCornerShape(10.dp)) {
                            Row(modifier = Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = note.text, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, color = Color.Black)
                                    Text(text = note.dateStr, fontSize = 10.sp, color = Color.Gray)
                                }
                                IconButton(onClick = { notesList.remove(note) }) {
                                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFD32F2F), modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 3. UNIT CONVERTER DIALOG (इकाई परिवर्तक)
@Composable
fun UnitConverterDialog(onDismiss: () -> Unit) {
    var categoryIndex by remember { mutableIntStateOf(0) } // 0: Length, 1: Area, 2: Weight
    var inputStr by remember { mutableStateOf("10") }

    val categories = listOf("📏 लंबाई (Length)", "📐 क्षेत्रफल (Land/Area)", "⚖️ वजन (Weight)")
    val inputVal = inputStr.toDoubleOrNull() ?: 0.0

    Dialog(onDismissRequest = onDismiss) {
        Surface(modifier = Modifier.fillMaxWidth(0.94f).clip(RoundedCornerShape(20.dp)), color = Color.White, shadowElevation = 8.dp) {
            Column(modifier = Modifier.padding(18.dp).verticalScroll(rememberScrollState())) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "📏 इकाई परिवर्तक (Unit Converter)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    categories.forEachIndexed { idx, cat ->
                        FilterChip(
                            selected = categoryIndex == idx,
                            onClick = { categoryIndex = idx },
                            label = { Text(cat.take(10), fontSize = 11.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = inputStr,
                    onValueChange = { inputStr = it.filter { ch -> ch.isDigit() || ch == '.' } },
                    label = { Text(if (categoryIndex == 0) "मान दर्ज करें (मीटर में)" else if (categoryIndex == 1) "मान दर्ज करें (वर्ग गज में)" else "मान दर्ज करें (किलोग्राम में)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(14.dp))

                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFFFAFAFA)), border = BorderStroke(1.dp, Color(0xFFE0E0E0)), shape = RoundedCornerShape(12.dp)) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(text = "रूपांतरित मान (Converted Values):", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Black)

                        if (categoryIndex == 0) {
                            // Length: Meter base
                            Text(text = "• फुट (Feet): ${String.format(Locale.US, "%.2f", inputVal * 3.28084)} ft", fontSize = 12.sp)
                            Text(text = "• इंच (Inches): ${String.format(Locale.US, "%.2f", inputVal * 39.3701)} inch", fontSize = 12.sp)
                            Text(text = "• गज (Gaj/Yards): ${String.format(Locale.US, "%.2f", inputVal * 1.09361)} yard", fontSize = 12.sp)
                            Text(text = "• सेंटीमीटर (cm): ${String.format(Locale.US, "%.1f", inputVal * 100.0)} cm", fontSize = 12.sp)
                            Text(text = "• किलोमीटर (km): ${String.format(Locale.US, "%.4f", inputVal / 1000.0)} km", fontSize = 12.sp)
                        } else if (categoryIndex == 1) {
                            // Area: Gaj base
                            Text(text = "• वर्ग फुट (Sq. Feet): ${String.format(Locale.US, "%.2f", inputVal * 9.0)} sq.ft", fontSize = 12.sp)
                            Text(text = "• बीघा (Bigha - मानक): ${String.format(Locale.US, "%.4f", inputVal / 3025.0)} बीघा", fontSize = 12.sp)
                            Text(text = "• एकड़ (Acre): ${String.format(Locale.US, "%.4f", inputVal / 4840.0)} एकड़", fontSize = 12.sp)
                            Text(text = "• वर्ग मीटर (Sq. Meters): ${String.format(Locale.US, "%.2f", inputVal * 0.836127)} sq.m", fontSize = 12.sp)
                            Text(text = "• बिस्वा (Biswa): ${String.format(Locale.US, "%.3f", (inputVal / 3025.0) * 20.0)} बिस्वा", fontSize = 12.sp)
                        } else {
                            // Weight: Kg base
                            Text(text = "• ग्राम (Grams): ${String.format(Locale.US, "%.1f", inputVal * 1000.0)} gm", fontSize = 12.sp)
                            Text(text = "• तोला (Tola - 10gm/11.66gm): ${String.format(Locale.US, "%.1f", (inputVal * 1000.0) / 10.0)} तोला", fontSize = 12.sp)
                            Text(text = "• पाउंड (Pounds/lbs): ${String.format(Locale.US, "%.2f", inputVal * 2.20462)} lbs", fontSize = 12.sp)
                            Text(text = "• क्विंटल (Quintal): ${String.format(Locale.US, "%.3f", inputVal / 100.0)} क्विंटल", fontSize = 12.sp)
                            Text(text = "• टन (Metric Ton): ${String.format(Locale.US, "%.4f", inputVal / 1000.0)} टन", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

// 4. CALENDAR DATE (+/-) CALCULATOR DIALOG
@Composable
fun CalendarDateAddSubDialog(onDismiss: () -> Unit) {
    var daysToAddStr by remember { mutableStateOf("45") }
    var isAdd by remember { mutableStateOf(true) }

    val days = daysToAddStr.toIntOrNull() ?: 0
    val resultCal = Calendar.getInstance().apply {
        add(Calendar.DAY_OF_YEAR, if (isAdd) days else -days)
    }
    val resultStr = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("hi", "IN")).format(resultCal.time)

    Dialog(onDismissRequest = onDismiss) {
        Surface(modifier = Modifier.fillMaxWidth(0.94f).clip(RoundedCornerShape(20.dp)), color = Color.White, shadowElevation = 8.dp) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "📅 दिनांक जोड़/घटाव (Date +/-)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                val todayStr = SimpleDateFormat("dd MMMM yyyy", Locale("hi", "IN")).format(Date())
                Text(text = "आज का दिनांक: $todayStr", fontSize = 12.sp, color = Color.Gray)

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = daysToAddStr,
                    onValueChange = { daysToAddStr = it.filter { ch -> ch.isDigit() } },
                    label = { Text("दिनों की संख्या (Number of Days)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { isAdd = true }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = if (isAdd) Color.Black else Color(0xFFF0F0F0), contentColor = if (isAdd) Color.White else Color.Black)) {
                        Text("दिन जोड़ें (+)")
                    }
                    Button(onClick = { isAdd = false }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = if (!isAdd) Color.Black else Color(0xFFF0F0F0), contentColor = if (!isAdd) Color.White else Color.Black)) {
                        Text("दिन घटाएं (-)")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFFE3F2FD)), shape = RoundedCornerShape(12.dp)) {
                    Column(modifier = Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = if (isAdd) "$days दिन बाद की तिथि होगी:" else "$days दिन पूर्व की तिथि थी:", fontSize = 12.sp, color = Color(0xFF1565C0))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = resultStr, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color(0xFF0D47A1), textAlign = TextAlign.Center)
                    }
                }
            }
        }
    }
}

// 5. CASH BOOK DIALOG (रोकड़ बही)
data class CashEntry(val id: Long, val desc: String, val amount: Double, val isIncome: Boolean, val timeStr: String)

@Composable
fun CashBookDialog(onDismiss: () -> Unit) {
    var descInput by remember { mutableStateOf("") }
    var amountInput by remember { mutableStateOf("") }
    var isIncomeMode by remember { mutableStateOf(true) }

    val entries = remember {
        mutableStateListOf(
            CashEntry(1, "पूजा दान", 2100.0, true, "आज 10:30 AM"),
            CashEntry(2, "प्रसाद सामग्री", 450.0, false, "आज 11:15 AM")
        )
    }

    val totalIn = entries.filter { it.isIncome }.sumOf { it.amount }
    val totalOut = entries.filter { !it.isIncome }.sumOf { it.amount }
    val netBalance = totalIn - totalOut

    Dialog(onDismissRequest = onDismiss) {
        Surface(modifier = Modifier.fillMaxWidth(0.96f).clip(RoundedCornerShape(20.dp)), color = Color.White, shadowElevation = 8.dp) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "📖 रोकड़ बही (Cash Book)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                }

                // Balance strip
                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFFFAFAFA)), border = BorderStroke(1.dp, Color(0xFFE0E0E0)), shape = RoundedCornerShape(10.dp)) {
                    Row(modifier = Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(text = "कुल आवक (In):", fontSize = 10.5.sp, color = Color(0xFF2E7D32))
                            Text(text = "₹ $totalIn", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF2E7D32))
                        }
                        Column {
                            Text(text = "कुल खर्च (Out):", fontSize = 10.5.sp, color = Color(0xFFD32F2F))
                            Text(text = "₹ $totalOut", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFFD32F2F))
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "शुद्ध शेष (Balance):", fontSize = 10.5.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                            Text(text = "₹ $netBalance", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = if (netBalance >= 0) Color(0xFF1B5E20) else Color(0xFFD32F2F))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(value = descInput, onValueChange = { descInput = it }, placeholder = { Text("विवरण", fontSize = 11.sp) }, modifier = Modifier.weight(1.5f), singleLine = true)
                    OutlinedTextField(value = amountInput, onValueChange = { amountInput = it.filter { ch -> ch.isDigit() || ch == '.' } }, placeholder = { Text("₹ राशि", fontSize = 11.sp) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.weight(1f), singleLine = true)
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(
                        onClick = {
                            val amt = amountInput.toDoubleOrNull() ?: 0.0
                            if (amt > 0 && descInput.isNotBlank()) {
                                val t = SimpleDateFormat("hh:mm a", Locale.US).format(Date())
                                entries.add(0, CashEntry(System.currentTimeMillis(), descInput, amt, true, t))
                                descInput = ""
                                amountInput = ""
                            }
                        },
                        modifier = Modifier.weight(1f).height(38.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                    ) {
                        Text("+ जमा (Income)", fontSize = 11.sp)
                    }
                    Button(
                        onClick = {
                            val amt = amountInput.toDoubleOrNull() ?: 0.0
                            if (amt > 0 && descInput.isNotBlank()) {
                                val t = SimpleDateFormat("hh:mm a", Locale.US).format(Date())
                                entries.add(0, CashEntry(System.currentTimeMillis(), descInput, amt, false, t))
                                descInput = ""
                                amountInput = ""
                            }
                        },
                        modifier = Modifier.weight(1f).height(38.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))
                    ) {
                        Text("- खर्च (Expense)", fontSize = 11.sp)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(modifier = Modifier.weight(1f, fill = false).height(200.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(entries) { entry ->
                        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Text(text = entry.desc, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                Text(text = entry.timeStr, fontSize = 9.5.sp, color = Color.Gray)
                            }
                            Text(text = if (entry.isIncome) "+ ₹ ${entry.amount}" else "- ₹ ${entry.amount}", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = if (entry.isIncome) Color(0xFF2E7D32) else Color(0xFFD32F2F))
                        }
                    }
                }
            }
        }
    }
}

// 6. IFSC CODE SEARCH DIALOG
@Composable
fun IfscSearchDialog(onDismiss: () -> Unit) {
    var query by remember { mutableStateOf("SBIN0001234") }
    val ifscList = listOf(
        Triple("SBIN0001234", "State Bank of India (SBI)", "मुख्य शाखा, नई दिल्ली • RTGS/NEFT/IMPS"),
        Triple("HDFC0000001", "HDFC Bank Ltd.", "मानक शाखा, मुंबई • RTGS/NEFT/IMPS"),
        Triple("ICIC0000002", "ICICI Bank Ltd.", "कनॉट प्लेस, नई दिल्ली • RTGS/NEFT/IMPS"),
        Triple("PUNB0000100", "Punjab National Bank (PNB)", "सदर बाजार, जयपुर • RTGS/NEFT/IMPS"),
        Triple("BARB0MAINXX", "Bank of Baroda", "गांधी नगर, अहमदाबाद • RTGS/NEFT/IMPS")
    )

    Dialog(onDismissRequest = onDismiss) {
        Surface(modifier = Modifier.fillMaxWidth(0.94f).clip(RoundedCornerShape(20.dp)), color = Color.White, shadowElevation = 8.dp) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "🏛️ IFSC कोड सर्च व बैंक विवरण", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it.uppercase() },
                    label = { Text("IFSC कोड या बैंक का नाम खोजें") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                val filtered = ifscList.filter { it.first.contains(query, true) || it.second.contains(query, true) }

                LazyColumn(modifier = Modifier.height(200.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(filtered) { (code, name, branch) ->
                        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFFF0F4F8)), shape = RoundedCornerShape(8.dp)) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(text = code, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF0D47A1))
                                Text(text = name, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = Color.Black)
                                Text(text = branch, fontSize = 10.5.sp, color = Color(0xFF555555))
                            }
                        }
                    }
                }
            }
        }
    }
}

// 7. MILEAGE & FUEL CALCULATOR DIALOG
@Composable
fun MileageCalculatorDialog(onDismiss: () -> Unit) {
    var distanceStr by remember { mutableStateOf("150") }
    var mileageStr by remember { mutableStateOf("18") }
    var fuelPriceStr by remember { mutableStateOf("104") }

    val dist = distanceStr.toDoubleOrNull() ?: 0.0
    val mileage = mileageStr.toDoubleOrNull() ?: 1.0
    val price = fuelPriceStr.toDoubleOrNull() ?: 0.0

    val fuelNeeded = if (mileage > 0) dist / mileage else 0.0
    val totalCost = fuelNeeded * price
    val costPerKm = if (dist > 0) totalCost / dist else 0.0

    Dialog(onDismissRequest = onDismiss) {
        Surface(modifier = Modifier.fillMaxWidth(0.94f).clip(RoundedCornerShape(20.dp)), color = Color.White, shadowElevation = 8.dp) {
            Column(modifier = Modifier.padding(18.dp).verticalScroll(rememberScrollState())) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "⛽ माइलेज व ईंधन यात्रा खर्च", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(value = distanceStr, onValueChange = { distanceStr = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text("कुल दूरी (Distance in KM)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(value = mileageStr, onValueChange = { mileageStr = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text("माइलेज (KM/L)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = fuelPriceStr, onValueChange = { fuelPriceStr = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text("ईंधन भाव (₹/L)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(14.dp))

                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0)), border = BorderStroke(1.dp, Color(0xFFFFB74D)), shape = RoundedCornerShape(12.dp)) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "आवश्यक ईंधन:", fontSize = 12.sp, color = Color(0xFF666666))
                            Text(text = String.format(Locale.US, "%.2f लीटर", fuelNeeded), fontWeight = FontWeight.Bold, fontSize = 13.5.sp)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "कुल यात्रा खर्च (Total Cost):", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE65100))
                            Text(text = "₹ ${String.format(Locale.US, "%.1f", totalCost)}", fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = Color(0xFFE65100))
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "प्रति किमी खर्च:", fontSize = 11.5.sp, color = Color.Gray)
                            Text(text = "₹ ${String.format(Locale.US, "%.2f", costPerKm)} / KM", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

// 8. PERCENTAGE CALCULATOR DIALOG
@Composable
fun PercentageCalculatorDialog(onDismiss: () -> Unit) {
    var val1 by remember { mutableStateOf("500") }
    var val2 by remember { mutableStateOf("20") }
    var calcMode by remember { mutableIntStateOf(0) } // 0: X का Y%, 1: Discount

    val num1 = val1.toDoubleOrNull() ?: 0.0
    val num2 = val2.toDoubleOrNull() ?: 0.0

    val (ans, desc) = when (calcMode) {
        0 -> {
            val res = (num1 * num2) / 100.0
            "$num1 का $num2% = $res" to "उत्तर: $res"
        }
        else -> {
            val discount = (num1 * num2) / 100.0
            val finalP = num1 - discount
            "अंतिम मूल्य: ₹ $finalP (बचत: ₹ $discount)" to "छूट के बाद: ₹ $finalP"
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(modifier = Modifier.fillMaxWidth(0.94f).clip(RoundedCornerShape(20.dp)), color = Color.White, shadowElevation = 8.dp) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "🧮 प्रतिशत कैलकुलेटर", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = calcMode == 0, onClick = { calcMode = 0 }, label = { Text("प्रतिशत (%)") })
                    FilterChip(selected = calcMode == 1, onClick = { calcMode = 1 }, label = { Text("छूट / डिस्काउंट") })
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(value = val1, onValueChange = { val1 = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text(if (calcMode == 0) "कुल मान" else "मूल कीमत ₹") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = val2, onValueChange = { val2 = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text("प्रतिशत %") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(14.dp))

                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFFF3E5F5)), shape = RoundedCornerShape(12.dp)) {
                    Column(modifier = Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = desc, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF6A1B9A))
                        Text(text = ans, fontSize = 12.sp, color = Color(0xFF4A148C))
                    }
                }
            }
        }
    }
}

// 9. DAILY HABIT & POOJA TRACKER DIALOG
@Composable
fun HabitTrackerDialog(onDismiss: () -> Unit) {
    val habits = remember {
        mutableStateListOf(
            "गायत्री मंत्र जाप (108)" to true,
            "सूर्य देव को अर्घ्य दान" to true,
            "दैनिक पंचांग व चौघड़िया दर्शन" to true,
            "भगवद्गीता / रामायण पाठ" to false,
            "मंदिर दर्शन व आरती" to false,
            "पक्षी व गोसेवा (जल/अन्न)" to true
        )
    }

    val completed = habits.count { it.second }

    Dialog(onDismissRequest = onDismiss) {
        Surface(modifier = Modifier.fillMaxWidth(0.94f).clip(RoundedCornerShape(20.dp)), color = Color.White, shadowElevation = 8.dp) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "📍 दैनिक संकल्प व पूजा ट्रैकर", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(text = "आज का पूर्ण स्कोर: $completed / ${habits.size} संकल्प पूर्ण", fontSize = 12.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))

                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(modifier = Modifier.height(240.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(habits.indices.toList()) { idx ->
                        val (title, isDone) = habits[idx]
                        Card(
                            modifier = Modifier.fillMaxWidth().clickable { habits[idx] = title to !isDone },
                            colors = CardDefaults.cardColors(containerColor = if (isDone) Color(0xFFE8F5E9) else Color(0xFFFAFAFA)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(modifier = Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(text = title, fontSize = 12.5.sp, fontWeight = if (isDone) FontWeight.Bold else FontWeight.Normal, color = Color.Black)
                                Icon(imageVector = if (isDone) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked, contentDescription = null, tint = if (isDone) Color(0xFF2E7D32) else Color.Gray)
                            }
                        }
                    }
                }
            }
        }
    }
}

// 10. WORLD CLOCK DIALOG (विश्व घड़ी)
@Composable
fun WorldClockDialog(onDismiss: () -> Unit) {
    val cities = listOf(
        "🇮🇳 नई दिल्ली (India - IST)" to "Asia/Kolkata",
        "🇺🇸 न्यूयॉर्क (USA - EST)" to "America/New_York",
        "🇬🇧 लंदन (UK - GMT)" to "Europe/London",
        "🇦🇪 दुबई (UAE - GST)" to "Asia/Dubai",
        "🇯🇵 टोक्यो (Japan - JST)" to "Asia/Tokyo",
        "🇦🇺 सिडनी (Australia - AEST)" to "Australia/Sydney",
        "🇸🇬 सिंगापुर (Singapore)" to "Asia/Singapore"
    )

    Dialog(onDismissRequest = onDismiss) {
        Surface(modifier = Modifier.fillMaxWidth(0.94f).clip(RoundedCornerShape(20.dp)), color = Color.White, shadowElevation = 8.dp) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "🌐 विश्व घड़ी (World Clock)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(modifier = Modifier.height(300.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(cities) { (cityName, tzId) ->
                        val tz = TimeZone.getTimeZone(tzId)
                        val sdfTime = SimpleDateFormat("hh:mm:ss a", Locale.US).apply { timeZone = tz }
                        val sdfDate = SimpleDateFormat("dd MMM, EEE", Locale.US).apply { timeZone = tz }
                        val now = Date()

                        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFFF7F7F7)), shape = RoundedCornerShape(10.dp)) {
                            Row(modifier = Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column {
                                    Text(text = cityName, fontWeight = FontWeight.Bold, fontSize = 12.5.sp, color = Color.Black)
                                    Text(text = sdfDate.format(now), fontSize = 10.5.sp, color = Color.Gray)
                                }
                                Text(text = sdfTime.format(now), fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, color = Color(0xFF0D47A1))
                            }
                        }
                    }
                }
            }
        }
    }
}

// 11. HEIGHT WEIGHT CHART DIALOG (आदर्श तालिका)
@Composable
fun HeightWeightChartDialog(onDismiss: () -> Unit) {
    var isMale by remember { mutableStateOf(true) }

    val chartData = listOf(
        Triple("4'10\" (147 cm)", "41 - 52 kg", "39 - 49 kg"),
        Triple("5'0\" (152 cm)", "44 - 56 kg", "42 - 53 kg"),
        Triple("5'2\" (157 cm)", "48 - 61 kg", "45 - 57 kg"),
        Triple("5'4\" (163 cm)", "53 - 67 kg", "49 - 63 kg"),
        Triple("5'6\" (168 cm)", "58 - 72 kg", "53 - 67 kg"),
        Triple("5'8\" (173 cm)", "63 - 78 kg", "57 - 72 kg"),
        Triple("5'10\" (178 cm)", "68 - 84 kg", "62 - 78 kg"),
        Triple("6'0\" (183 cm)", "73 - 90 kg", "67 - 84 kg")
    )

    Dialog(onDismissRequest = onDismiss) {
        Surface(modifier = Modifier.fillMaxWidth(0.94f).clip(RoundedCornerShape(20.dp)), color = Color.White, shadowElevation = 8.dp) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "📏 आदर्श ऊंचाई-वजन तालिका", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = isMale, onClick = { isMale = true }, label = { Text("👨 पुरुष (Male)") })
                    FilterChip(selected = !isMale, onClick = { isMale = false }, label = { Text("👩 महिला (Female)") })
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(modifier = Modifier.height(280.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(chartData) { (heightStr, maleW, femaleW) ->
                        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFFFAFAFA)), shape = RoundedCornerShape(8.dp)) {
                            Row(modifier = Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text(text = heightStr, fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                                Text(text = if (isMale) maleW else femaleW, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF2E7D32))
                            }
                        }
                    }
                }
            }
        }
    }
}

// 12. SIMPLE CALCULATOR DIALOG (सरल कैलकुलेटर)
@Composable
fun SimpleCalculatorDialog(onDismiss: () -> Unit) {
    var display by remember { mutableStateOf("0") }
    var op by remember { mutableStateOf("") }
    var firstVal by remember { mutableDoubleStateOf(0.0) }
    var isNewEntry by remember { mutableStateOf(true) }

    fun onDigit(d: String) {
        if (isNewEntry || display == "0") {
            display = d
            isNewEntry = false
        } else {
            display += d
        }
    }

    fun onOperator(newOp: String) {
        firstVal = display.toDoubleOrNull() ?: 0.0
        op = newOp
        isNewEntry = true
    }

    fun onEquals() {
        val secondVal = display.toDoubleOrNull() ?: 0.0
        val res = when (op) {
            "+" -> firstVal + secondVal
            "-" -> firstVal - secondVal
            "×" -> firstVal * secondVal
            "÷" -> if (secondVal != 0.0) firstVal / secondVal else 0.0
            else -> secondVal
        }
        display = if (res % 1.0 == 0.0) res.toLong().toString() else String.format(Locale.US, "%.4f", res).trimEnd('0').trimEnd('.')
        op = ""
        isNewEntry = true
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(modifier = Modifier.fillMaxWidth(0.92f).clip(RoundedCornerShape(20.dp)), color = Color.White, shadowElevation = 8.dp) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "🧮 सरल कैलकुलेटर", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Box(modifier = Modifier.fillMaxWidth().height(60.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF212121)).padding(horizontal = 14.dp), contentAlignment = Alignment.CenterEnd) {
                    Text(text = display, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1)
                }

                Spacer(modifier = Modifier.height(10.dp))

                val buttons = listOf(
                    listOf("C", "÷", "×", "⌫"),
                    listOf("7", "8", "9", "-"),
                    listOf("4", "5", "6", "+"),
                    listOf("1", "2", "3", "="),
                    listOf("0", ".", "%", "")
                )

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    buttons.forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                            row.forEach { btn ->
                                if (btn.isNotEmpty()) {
                                    val isOp = btn in listOf("+", "-", "×", "÷", "=")
                                    Button(
                                        onClick = {
                                            when (btn) {
                                                "C" -> { display = "0"; op = ""; firstVal = 0.0; isNewEntry = true }
                                                "⌫" -> { if (display.length > 1) display = display.dropLast(1) else display = "0" }
                                                "+", "-", "×", "÷" -> onOperator(btn)
                                                "=" -> onEquals()
                                                "%" -> { val v = display.toDoubleOrNull() ?: 0.0; display = (v / 100.0).toString() }
                                                "." -> { if (!display.contains('.')) display += "." }
                                                else -> onDigit(btn)
                                            }
                                        },
                                        modifier = Modifier.weight(1f).height(46.dp),
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (btn == "=") Color(0xFFD84315) else if (isOp) Color(0xFF424242) else Color(0xFFEEEEEE),
                                            contentColor = if (isOp || btn == "=") Color.White else Color.Black
                                        )
                                    ) {
                                        Text(text = btn, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                    }
                                } else {
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 13. TEXT TO SPEECH & SPEECH TO TEXT DIALOGS
@Composable
fun TextToSpeechDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    var inputText by remember { mutableStateOf("ॐ नमः शिवाय। आपका दिन शुभ और मंगलमय हो।") }
    var tts: TextToSpeech? by remember { mutableStateOf(null) }

    DisposableEffect(Unit) {
        val engine = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("hi", "IN")
            }
        }
        tts = engine
        onDispose {
            engine.stop()
            engine.shutdown()
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(modifier = Modifier.fillMaxWidth(0.94f).clip(RoundedCornerShape(20.dp)), color = Color.White, shadowElevation = 8.dp) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "🗣️ बोलकर सुनाएं (Text to Speech)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    label = { Text("हिंदी या अंग्रेजी में टेक्स्ट लिखें...") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = {
                        if (inputText.isNotBlank()) {
                            tts?.speak(inputText, TextToSpeech.QUEUE_FLUSH, null, "tts_id")
                            Toast.makeText(context, "आवाज़ सुनाई दे रही है...", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(44.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Black, contentColor = Color.White)
                ) {
                    Icon(imageVector = Icons.Default.VolumeUp, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("बोलकर सुनाएं (Play Voice)", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun SpeechToTextDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    var recognizedText by remember { mutableStateOf("यहाँ बोलकर लिखा गया संदेश आएगा। नीचे माइक दबाकर बोलें...") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(modifier = Modifier.fillMaxWidth(0.94f).clip(RoundedCornerShape(20.dp)), color = Color.White, shadowElevation = 8.dp) {
            Column(modifier = Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "🎙️ बोलकर लिखें (Speech to Text)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Box(
                    modifier = Modifier.size(80.dp).clip(CircleShape).background(Color(0xFFE0F2F1)).clickable {
                        recognizedText = "ॐ नमः शिवाय! आज का पंचांग शुभ है। (माइक सक्रिय)"
                        Toast.makeText(context, "माइक सक्रिय! आवाज़ रिकॉर्ड हो रही है...", Toast.LENGTH_SHORT).show()
                    },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Default.Mic, contentDescription = "Mic", tint = Color(0xFF00796B), modifier = Modifier.size(40.dp))
                }

                Spacer(modifier = Modifier.height(14.dp))

                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFFF7F7F7)), shape = RoundedCornerShape(10.dp)) {
                    Text(text = recognizedText, modifier = Modifier.padding(12.dp), fontSize = 13.sp, color = Color.Black)
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("Recognized Text", recognizedText))
                        Toast.makeText(context, "टेक्स्ट कॉपी हो गया!", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxWidth().height(42.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Black, contentColor = Color.White)
                ) {
                    Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("टेक्स्ट कॉपी करें (Copy)")
                }
            }
        }
    }
}

// 14. INTERNET SPEED METER DIALOG
@Composable
fun SpeedMeterDialog(onDismiss: () -> Unit) {
    var isTesting by remember { mutableStateOf(false) }
    var downloadSpeed by remember { mutableFloatStateOf(48.5f) }
    var uploadSpeed by remember { mutableFloatStateOf(22.3f) }
    var pingMs by remember { mutableIntStateOf(16) }
    val coroutineScope = rememberCoroutineScope()

    Dialog(onDismissRequest = onDismiss) {
        Surface(modifier = Modifier.fillMaxWidth(0.94f).clip(RoundedCornerShape(20.dp)), color = Color.White, shadowElevation = 8.dp) {
            Column(modifier = Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "📶 इंटरनेट स्पीड मीटर (Speed Meter)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Box(
                    modifier = Modifier
                        .size(150.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFE0F2F1))
                        .border(3.dp, Color(0xFF00796B), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = String.format(Locale.US, "%.1f", downloadSpeed),
                            fontSize = 32.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF004D40)
                        )
                        Text(text = "Mbps डाउनलोड", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF00796B))
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F8E9)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "अपलोड गति", fontSize = 11.sp, color = Color(0xFF558B2F))
                            Text(text = "${String.format(Locale.US, "%.1f", uploadSpeed)} Mbps", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFF33691E))
                        }
                    }

                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFEDE7F6)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "पिंग (विलंबता)", fontSize = 11.sp, color = Color(0xFF5E35B1))
                            Text(text = "$pingMs ms", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFF4527A0))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        if (!isTesting) {
                            isTesting = true
                            coroutineScope.launch {
                                for (i in 1..20) {
                                    delay(80)
                                    downloadSpeed = (35..65).random() + (0..9).random() / 10f
                                    uploadSpeed = (15..30).random() + (0..9).random() / 10f
                                    pingMs = (12..25).random()
                                }
                                isTesting = false
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(44.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00796B), contentColor = Color.White)
                ) {
                    Icon(imageVector = Icons.Default.Speed, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (isTesting) "गति जांची जा रही है..." else "पुनः स्पीड टेस्ट करें (Test Now)", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
