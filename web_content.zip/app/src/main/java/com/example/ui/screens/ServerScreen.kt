package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ServerState
import com.example.ui.ChaufalandViewModel
import com.example.ui.components.MinecraftButton
import com.example.ui.components.MinecraftCard
import com.example.ui.components.PlayerAvatar
import com.example.ui.components.ServerStateBadge
import com.example.ui.theme.MinecraftBorder
import com.example.ui.theme.MinecraftDiamond
import com.example.ui.theme.MinecraftEmerald
import com.example.ui.theme.MinecraftGold
import com.example.ui.theme.MinecraftGrass
import com.example.ui.theme.MinecraftRedstone
import com.example.ui.theme.MinecraftSurfaceVariant
import com.example.ui.theme.MinecraftText
import com.example.ui.theme.MinecraftTextDim

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ServerScreen(viewModel: ChaufalandViewModel, modifier: Modifier = Modifier) {
  val serverStatus by viewModel.serverStatus.collectAsState()
  val isRefreshing by viewModel.isRefreshingServer.collectAsState()
  val consoleLogs by viewModel.consoleLogs.collectAsState()
  val adminConfig by viewModel.adminConfig.collectAsState()
  var commandText by remember { mutableStateOf("") }
  val consoleListState = rememberLazyListState()

  LaunchedEffect(consoleLogs.size) {
    if (consoleLogs.isNotEmpty()) {
      consoleListState.animateScrollToItem(consoleLogs.size - 1)
    }
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(12.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // 1. TARJETA DE ESTADO PRINCIPAL
    item {
      MinecraftCard {
        Column(modifier = Modifier.fillMaxWidth()) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = "⚡ ESTADO DE CHAUFALAND",
                color = MinecraftGold,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
              )
              Text(
                text = "Tipo: ${serverStatus.serverType.uppercase()} • ${serverStatus.serverHost.ifBlank { "Configurado en Admin" }}",
                color = MinecraftTextDim,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
              )
            }
            ServerStateBadge(state = serverStatus.state)
          }

          Spacer(modifier = Modifier.height(12.dp))

          // Métricas en cuadrícula (TPS, RAM, CPU, JUGADORES)
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            StatMetricBox(
              label = "TPS",
              value = String.format("%.1f", serverStatus.tps),
              valueColor = if (serverStatus.tps >= 18.0) MinecraftEmerald else MinecraftRedstone,
              modifier = Modifier.weight(1f)
            )
            StatMetricBox(
              label = "RAM",
              value = "${serverStatus.ramUsedMb} MB",
              valueColor = MinecraftDiamond,
              modifier = Modifier.weight(1f)
            )
            StatMetricBox(
              label = "CPU",
              value = "${serverStatus.cpuPercent}%",
              valueColor = MinecraftGold,
              modifier = Modifier.weight(1f)
            )
            StatMetricBox(
              label = "ONLINE",
              value = "${serverStatus.onlinePlayers}/${serverStatus.maxPlayers}",
              valueColor = if (serverStatus.onlinePlayers > 0) MinecraftEmerald else MinecraftTextDim,
              modifier = Modifier.weight(1f)
            )
          }

          if (serverStatus.motd.isNotBlank()) {
            Spacer(modifier = Modifier.height(10.dp))
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .background(MinecraftSurfaceVariant, RoundedCornerShape(2.dp))
                .padding(8.dp)
            ) {
              Text(
                text = "MOTD: ${serverStatus.motd}",
                color = MinecraftText,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
              )
            }
          }
        }
      }
    }

    // 2. BOTONES DE ACCIÓN DE CONTROL
    item {
      MinecraftCard {
        Column(modifier = Modifier.fillMaxWidth()) {
          Text(
            text = "🎮 ACCIONES DE CONTROL",
            color = MinecraftGold,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
          )
          Spacer(modifier = Modifier.height(10.dp))

          FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            MinecraftButton(
              text = "▶ INICIAR",
              containerColor = MinecraftEmerald,
              onClick = { viewModel.executeExarotonAction("start") },
              testTag = "btn_server_start"
            )
            MinecraftButton(
              text = "🔄 REINICIAR",
              containerColor = MinecraftGold,
              contentColor = Color.Black,
              onClick = { viewModel.executeExarotonAction("restart") },
              testTag = "btn_server_restart"
            )
            MinecraftButton(
              text = "⏹ DETENER",
              containerColor = MinecraftRedstone,
              onClick = { viewModel.executeExarotonAction("stop") },
              testTag = "btn_server_stop"
            )
            MinecraftButton(
              text = if (isRefreshing) "↻ ..." else "⟳ ACTUALIZAR",
              containerColor = Color(0xFF4A3B30),
              onClick = { viewModel.refreshServerStatus() },
              testTag = "btn_server_refresh"
            )
          }
        }
      }
    }

    // 3. JUGADORES CONECTADOS REALES
    item {
      MinecraftCard {
        Column(modifier = Modifier.fillMaxWidth()) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "👥 JUGADORES EN LÍNEA (${serverStatus.onlinePlayers})",
              color = MinecraftDiamond,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
              fontFamily = FontFamily.Monospace
            )
          }
          Spacer(modifier = Modifier.height(10.dp))

          if (serverStatus.playerNames.isEmpty()) {
            Text(
              text = "Ningún jugador conectado actualmente al servidor.",
              color = MinecraftTextDim,
              fontSize = 12.sp,
              fontFamily = FontFamily.Monospace
            )
          } else {
            FlowRow(
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              serverStatus.playerNames.forEach { playerName ->
                Row(
                  modifier = Modifier
                    .background(MinecraftSurfaceVariant, RoundedCornerShape(2.dp))
                    .border(1.dp, MinecraftBorder, RoundedCornerShape(2.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  PlayerAvatar(gamerTag = playerName, size = 24.dp)
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = playerName,
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                  )
                }
              }
            }
          }
        }
      }
    }

    // 4. CONSOLA EN VIVO Y ENTRADA DE COMANDOS
    item {
      MinecraftCard {
        Column(modifier = Modifier.fillMaxWidth()) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "> CONSOLA DEL SERVIDOR",
              color = MinecraftEmerald,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
              fontFamily = FontFamily.Monospace
            )
            MinecraftButton(
              text = "LIMPIAR",
              containerColor = Color(0xFF3B2F25),
              onClick = { viewModel.clearConsoleLogs() },
              modifier = Modifier.height(28.dp)
            )
          }

          Spacer(modifier = Modifier.height(8.dp))

          // Terminal Box
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .height(160.dp)
              .background(Color(0xFF0C0907), RoundedCornerShape(2.dp))
              .border(1.dp, Color(0xFF2E2218), RoundedCornerShape(2.dp))
              .padding(8.dp)
          ) {
            LazyColumn(state = consoleListState) {
              items(consoleLogs) { line ->
                Text(
                  text = line,
                  color = if (line.startsWith("[ERROR")) MinecraftRedstone
                  else if (line.startsWith(">")) MinecraftGold
                  else Color(0xFF75E083),
                  fontSize = 11.sp,
                  fontFamily = FontFamily.Monospace,
                  lineHeight = 15.sp
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          // Entrada de comando
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            OutlinedTextField(
              value = commandText,
              onValueChange = { commandText = it },
              placeholder = {
                Text(
                  text = "Ej: say ¡Bienvenidos! o time set day",
                  color = MinecraftTextDim,
                  fontSize = 12.sp
                )
              },
              singleLine = true,
              colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color(0xFF140F0C),
                unfocusedContainerColor = Color(0xFF140F0C),
                focusedBorderColor = MinecraftGold,
                unfocusedBorderColor = MinecraftBorder,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
              ),
              modifier = Modifier.weight(1f)
            )

            MinecraftButton(
              text = "ENVIAR",
              containerColor = MinecraftGrass,
              onClick = {
                if (commandText.isNotBlank()) {
                  viewModel.sendConsoleCommand(commandText)
                  commandText = ""
                }
              },
              testTag = "btn_send_console_command"
            )
          }
        }
      }
    }
  }
}

@Composable
private fun StatMetricBox(
  label: String,
  value: String,
  valueColor: Color,
  modifier: Modifier = Modifier
) {
  Box(
    modifier = modifier
      .background(MinecraftSurfaceVariant, RoundedCornerShape(2.dp))
      .border(1.dp, MinecraftBorder, RoundedCornerShape(2.dp))
      .padding(vertical = 8.dp, horizontal = 4.dp),
    contentAlignment = Alignment.Center
  ) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Text(
        text = label,
        color = MinecraftTextDim,
        fontSize = 10.sp,
        fontWeight = FontWeight.Bold,
        fontFamily = FontFamily.Monospace
      )
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = value,
        color = valueColor,
        fontSize = 13.sp,
        fontWeight = FontWeight.ExtraBold,
        fontFamily = FontFamily.Monospace
      )
    }
  }
}
