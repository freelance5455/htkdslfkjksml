package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.HistoryEdu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Nightlight
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.Podcasts
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.TheaterComedy
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import com.example.tts.model.NarrationArchetype
import com.example.tts.model.NarrationVoiceModel
import com.example.tts.model.NarrationVoiceModels
import com.example.tts.model.VoiceGender
import com.example.tts.model.VoiceInfo
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.StudioAmber
import com.example.ui.theme.StudioAmberLight
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioCyanDark

enum class PreviewSampleType(val label: String) {
    SHOWCASE("Model Showcase"),
    SCRIPT("My Script Excerpt"),
    DOCUMENTARY("Documentary Line"),
    AUDIOBOOK("Audiobook Line")
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun VoiceModelSelectorSheet(
    selectedModel: NarrationVoiceModel?,
    selectedVoice: VoiceInfo?,
    availableVoices: List<VoiceInfo>,
    isVoicePreviewPlaying: Boolean,
    previewingVoiceId: String?,
    scriptExcerpt: String,
    onSelectModel: (NarrationVoiceModel) -> Unit,
    onSelectRawVoice: (VoiceInfo) -> Unit,
    onPreviewModel: (NarrationVoiceModel, String?) -> Unit,
    onPreviewRawVoice: (VoiceInfo, String?) -> Unit,
    onStopPreview: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Narration Models, 1 = System Voices
    var searchQuery by remember { mutableStateOf("") }
    var selectedArchetypeFilter by remember { mutableStateOf<NarrationArchetype?>(null) }
    var selectedGenderFilter by remember { mutableStateOf<VoiceGender?>(null) }
    var sampleType by remember { mutableStateOf(PreviewSampleType.SHOWCASE) }

    val documentaryLine = "Deep beneath the western Pacific, the abyss remains shrouded in perpetual silence and immense pressure."
    val audiobookLine = "The cobblestone streets of Prague glistened in the evening twilight as Master Mikuláš turned the ancient key."

    fun getSampleForModel(model: NarrationVoiceModel): String {
        return when (sampleType) {
            PreviewSampleType.SHOWCASE -> model.showcaseSample
            PreviewSampleType.SCRIPT -> scriptExcerpt.take(120).ifBlank { model.showcaseSample }
            PreviewSampleType.DOCUMENTARY -> documentaryLine
            PreviewSampleType.AUDIOBOOK -> audiobookLine
        }
    }

    fun getSampleForRawVoice(voice: VoiceInfo): String {
        return when (sampleType) {
            PreviewSampleType.SHOWCASE -> "This is an audition sample for ${voice.displayName}. Clean studio enunciation for high fidelity narration."
            PreviewSampleType.SCRIPT -> scriptExcerpt.take(120).ifBlank { "OmniVoice speech synthesis audition." }
            PreviewSampleType.DOCUMENTARY -> documentaryLine
            PreviewSampleType.AUDIOBOOK -> audiobookLine
        }
    }

    val filteredModels = remember(searchQuery, selectedArchetypeFilter, selectedGenderFilter) {
        NarrationVoiceModels.models.filter { model ->
            val matchesQuery = searchQuery.isBlank() ||
                    model.name.contains(searchQuery, ignoreCase = true) ||
                    model.persona.contains(searchQuery, ignoreCase = true) ||
                    model.timbre.contains(searchQuery, ignoreCase = true) ||
                    model.tags.any { it.contains(searchQuery, ignoreCase = true) }

            val matchesArchetype = selectedArchetypeFilter == null || model.archetype == selectedArchetypeFilter
            val matchesGender = selectedGenderFilter == null || model.gender == selectedGenderFilter

            matchesQuery && matchesArchetype && matchesGender
        }
    }

    val filteredSystemVoices = remember(availableVoices, searchQuery, selectedGenderFilter) {
        availableVoices.filter { voice ->
            val matchesQuery = searchQuery.isBlank() ||
                    voice.displayName.contains(searchQuery, ignoreCase = true) ||
                    voice.languageDisplayName.contains(searchQuery, ignoreCase = true) ||
                    voice.localeTag.contains(searchQuery, ignoreCase = true)

            val matchesGender = selectedGenderFilter == null || voice.gender == selectedGenderFilter

            matchesQuery && matchesGender
        }
    }

    BasicAlertDialog(
        onDismissRequest = {
            onStopPreview()
            onDismiss()
        },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                StudioCyan.copy(alpha = 0.35f)
            ),
            modifier = modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.92f)
                .padding(vertical = 12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Top Header with Title, Active Model and Close
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(StudioCyan, StudioCyanDark)
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.RecordVoiceOver,
                                contentDescription = "Voice Models",
                                tint = Color.Black,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Synthetic Voice Studio",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                ),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Audition & select synthetic narration models",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    IconButton(
                        onClick = {
                            onStopPreview()
                            onDismiss()
                        },
                        modifier = Modifier.testTag("close_voice_model_selector_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Primary Tabs: Curated Narration Models vs All System Voices
                PrimaryTabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                    contentColor = StudioCyan,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp),
                                    tint = if (selectedTab == 0) StudioCyan else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Narration Models (${NarrationVoiceModels.models.size})",
                                    fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.GraphicEq,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp),
                                    tint = if (selectedTab == 1) StudioCyan else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "System Voices (${availableVoices.size})",
                                    fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Search Bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = {
                        Text(
                            if (selectedTab == 0) "Search models by persona, timbre, or genre..."
                            else "Search voices by language or country..."
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Clear search",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = StudioCyan,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Sample Phrase Audition Selector Pills
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Audition Phrase: ",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(PreviewSampleType.values()) { type ->
                            val isSelected = sampleType == type
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        if (isSelected) StudioCyan.copy(alpha = 0.2f)
                                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                    )
                                    .border(
                                        1.dp,
                                        if (isSelected) StudioCyan else Color.Transparent,
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable { sampleType = type }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = type.label,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    ),
                                    color = if (isSelected) StudioCyan else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Archetype & Gender Filter Chips
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // All Chip
                    item {
                        FilterChip(
                            selected = selectedArchetypeFilter == null && selectedGenderFilter == null,
                            onClick = {
                                selectedArchetypeFilter = null
                                selectedGenderFilter = null
                            },
                            label = { Text("All Filters") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StudioCyan,
                                selectedLabelColor = Color.Black
                            )
                        )
                    }

                    // Gender filters
                    item {
                        FilterChip(
                            selected = selectedGenderFilter == VoiceGender.FEMALE,
                            onClick = {
                                selectedGenderFilter = if (selectedGenderFilter == VoiceGender.FEMALE) null else VoiceGender.FEMALE
                            },
                            label = { Text("Female") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StudioCyan,
                                selectedLabelColor = Color.Black
                            )
                        )
                    }
                    item {
                        FilterChip(
                            selected = selectedGenderFilter == VoiceGender.MALE,
                            onClick = {
                                selectedGenderFilter = if (selectedGenderFilter == VoiceGender.MALE) null else VoiceGender.MALE
                            },
                            label = { Text("Male") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = StudioCyan,
                                selectedLabelColor = Color.Black
                            )
                        )
                    }

                    if (selectedTab == 0) {
                        items(NarrationArchetype.values()) { archetype ->
                            FilterChip(
                                selected = selectedArchetypeFilter == archetype,
                                onClick = {
                                    selectedArchetypeFilter = if (selectedArchetypeFilter == archetype) null else archetype
                                },
                                label = { Text(archetype.displayName) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = StudioCyan,
                                    selectedLabelColor = Color.Black
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Model / Voice List
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    if (selectedTab == 0) {
                        // Narration Models Tab
                        if (filteredModels.isEmpty()) {
                            Box(
                                modifier = Modifier.fillMaxWidth().padding(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "No synthetic models match your filter",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        } else {
                            LazyColumn(
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(filteredModels) { model ->
                                    val isSelected = model.id == selectedModel?.id
                                    val isPreviewing = isVoicePreviewPlaying && previewingVoiceId == model.id

                                    NarrationModelCard(
                                        model = model,
                                        isSelected = isSelected,
                                        isPreviewing = isPreviewing,
                                        onSelect = {
                                            onSelectModel(model)
                                        },
                                        onTogglePreview = {
                                            if (isPreviewing) {
                                                onStopPreview()
                                            } else {
                                                onPreviewModel(model, getSampleForModel(model))
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    } else {
                        // System Voices Tab
                        if (filteredSystemVoices.isEmpty()) {
                            Box(
                                modifier = Modifier.fillMaxWidth().padding(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "No system voices match your search",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        } else {
                            LazyColumn(
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(filteredSystemVoices) { voice ->
                                    val isSelected = voice.id == selectedVoice?.id
                                    val isPreviewing = isVoicePreviewPlaying && previewingVoiceId == voice.id

                                    SystemVoiceCard(
                                        voice = voice,
                                        isSelected = isSelected,
                                        isPreviewing = isPreviewing,
                                        onSelect = {
                                            onSelectRawVoice(voice)
                                        },
                                        onTogglePreview = {
                                            if (isPreviewing) {
                                                onStopPreview()
                                            } else {
                                                onPreviewRawVoice(voice, getSampleForRawVoice(voice))
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Bottom Floating Control Bar with Current Active Model
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(StudioCyan),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.RecordVoiceOver,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = selectedModel?.name ?: selectedVoice?.displayName ?: "No Model Selected",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = selectedModel?.timbre ?: selectedVoice?.localeTag ?: "",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StudioCyan,
                                    maxLines = 1
                                )
                            }
                        }

                        Button(
                            onClick = {
                                onStopPreview()
                                onDismiss()
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = StudioCyan,
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("apply_voice_model_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Apply & Use", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun NarrationModelCard(
    model: NarrationVoiceModel,
    isSelected: Boolean,
    isPreviewing: Boolean,
    onSelect: () -> Unit,
    onTogglePreview: () -> Unit,
    modifier: Modifier = Modifier
) {
    val borderColor by animateColorAsState(
        targetValue = if (isSelected) StudioCyan else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f),
        label = "border_color"
    )

    val containerColor = if (isSelected) {
        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
    } else {
        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
    }

    val iconVector = when (model.archetype) {
        NarrationArchetype.DOCUMENTARY -> Icons.Default.HistoryEdu
        NarrationArchetype.AUDIOBOOK -> Icons.Default.AutoStories
        NarrationArchetype.EXPLAINER -> Icons.Default.OndemandVideo
        NarrationArchetype.BROADCAST -> Icons.Default.Podcasts
        NarrationArchetype.ATMOSPHERIC -> Icons.Default.Nightlight
        NarrationArchetype.CONVERSATIONAL -> Icons.Default.Hearing
        NarrationArchetype.ACADEMIC -> Icons.Default.School
        NarrationArchetype.DRAMATIC -> Icons.Default.TheaterComedy
    }

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = containerColor,
        border = androidx.compose.foundation.BorderStroke(if (isSelected) 1.5.dp else 1.dp, borderColor),
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onSelect() }
            .testTag("voice_model_card_${model.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Header Row: Avatar, Name, Archetype Tag, Preview Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    // Model Avatar with audio pulse animation
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(
                                if (isSelected) StudioCyan.copy(alpha = 0.2f)
                                else MaterialTheme.colorScheme.surfaceVariant
                            )
                            .border(
                                1.5.dp,
                                if (isSelected) StudioCyan else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = iconVector,
                            contentDescription = model.archetype.displayName,
                            tint = if (isSelected) StudioCyan else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = model.name,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            VoicePill(
                                text = model.archetype.displayName,
                                color = if (isSelected) StudioCyan else MaterialTheme.colorScheme.secondary
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = model.persona,
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Audition Preview Button
                OutlinedButton(
                    onClick = onTogglePreview,
                    shape = RoundedCornerShape(20.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (isPreviewing) MaterialTheme.colorScheme.error.copy(alpha = 0.15f) else Color.Transparent,
                        contentColor = if (isPreviewing) MaterialTheme.colorScheme.error else StudioCyan
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isPreviewing) MaterialTheme.colorScheme.error else StudioCyan
                    ),
                    modifier = Modifier.testTag("preview_model_button_${model.id}")
                ) {
                    if (isPreviewing) {
                        VoiceAudioPulsar()
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Stop", fontWeight = FontWeight.Bold)
                    } else {
                        Icon(
                            imageVector = Icons.Default.Hearing,
                            contentDescription = "Preview",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Audition")
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Timbre & Description
            Text(
                text = model.description,
                style = MaterialTheme.typography.bodySmall.copy(lineHeight = 18.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Acoustic Specs Bar: Timbre, Baseline Speed, Pitch, Pauses
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.6f))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = null,
                        tint = StudioCyan,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = model.timbre,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${model.defaultSpeed}x speed",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text("•", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = "${model.defaultPauseMs}ms pause",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Tags and Selection Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    model.tags.forEach { tag ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = tag,
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                if (isSelected) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Selected",
                            tint = StudioCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Active Model",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = StudioCyan
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SystemVoiceCard(
    voice: VoiceInfo,
    isSelected: Boolean,
    isPreviewing: Boolean,
    onSelect: () -> Unit,
    onTogglePreview: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable { onSelect() }
            .testTag("system_voice_${voice.id}"),
        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(
            if (isSelected) 1.5.dp else 1.dp,
            if (isSelected) StudioCyan else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = voice.displayName,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (isSelected) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Selected",
                            tint = StudioCyan,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val genderLabel = when (voice.gender) {
                        VoiceGender.FEMALE -> "Female"
                        VoiceGender.MALE -> "Male"
                        else -> "Neutral"
                    }
                    VoicePill(genderLabel, MaterialTheme.colorScheme.secondary)
                    VoicePill(voice.quality, MaterialTheme.colorScheme.primary)
                    VoicePill(voice.localeTag, MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            IconButton(
                onClick = onTogglePreview,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = if (isPreviewing) Icons.Default.Stop else Icons.Default.Hearing,
                    contentDescription = "Audition Voice",
                    tint = if (isPreviewing) MaterialTheme.colorScheme.error else StudioCyan,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun VoiceAudioPulsar(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "pulsar")
    val h1 by transition.animateFloat(
        initialValue = 4f,
        targetValue = 16f,
        animationSpec = infiniteRepeatable(
            animation = tween(350, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "p1"
    )
    val h2 by transition.animateFloat(
        initialValue = 14f,
        targetValue = 6f,
        animationSpec = infiniteRepeatable(
            animation = tween(400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "p2"
    )
    val h3 by transition.animateFloat(
        initialValue = 8f,
        targetValue = 18f,
        animationSpec = infiniteRepeatable(
            animation = tween(300, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "p3"
    )

    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        listOf(h1, h2, h3).forEach { height ->
            Box(
                modifier = Modifier
                    .width(2.5.dp)
                    .height(height.dp)
                    .clip(RoundedCornerShape(1.dp))
                    .background(MaterialTheme.colorScheme.error)
            )
        }
    }
}
