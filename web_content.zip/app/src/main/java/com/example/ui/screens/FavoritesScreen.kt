package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AvailableTools
import com.example.ui.components.AppTopBar
import com.example.ui.components.BannerAdView
import com.example.ui.components.ToolCard
import com.example.ui.localization.AppStrings
import com.example.ui.theme.SoftViolet
import com.example.ui.viewmodel.MainUiState
import com.example.ui.viewmodel.ScreenDestination

@Composable
fun FavoritesScreen(
    uiState: MainUiState,
    onNavigate: (ScreenDestination) -> Unit,
    onFavoriteToggle: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val language = uiState.language

    val favoriteTools = remember(uiState.favoriteToolIds) {
        AvailableTools.allTools.filter { uiState.favoriteToolIds.contains(it.id) }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        AppTopBar(
            title = AppStrings.get("favorites_title", language)
        )

        if (favoriteTools.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(SoftViolet.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.FavoriteBorder,
                            contentDescription = null,
                            tint = SoftViolet,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = AppStrings.get("favorites_empty", language),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = AppStrings.get("favorites_empty_hint", language),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(favoriteTools, key = { it.id }) { tool ->
                    ToolCard(
                        title = AppStrings.get(tool.titleKey, language),
                        description = AppStrings.get(tool.descKey, language),
                        icon = tool.icon,
                        isFavorite = true,
                        testTag = "fav_card_${tool.id}",
                        onFavoriteToggle = { onFavoriteToggle(tool.id) },
                        onClick = {
                            when (tool.id) {
                                "standard_calc" -> onNavigate(ScreenDestination.StandardCalc)
                                "scientific_calc" -> onNavigate(ScreenDestination.ScientificCalc)
                                "age_calc" -> onNavigate(ScreenDestination.AgeCalc)
                                "gst_calc" -> onNavigate(ScreenDestination.GstCalc)
                                "bmi_calc" -> onNavigate(ScreenDestination.BmiCalc)
                                "unit_converter" -> onNavigate(ScreenDestination.UnitConverter)
                                "currency_converter" -> onNavigate(ScreenDestination.CurrencyConverter)
                                "discount_calc" -> onNavigate(ScreenDestination.DiscountCalc)
                                "emi_calc" -> onNavigate(ScreenDestination.EmiCalc)
                                "tip_calc" -> onNavigate(ScreenDestination.TipCalc)
                            }
                        }
                    )
                }
            }
        }

        BannerAdView()
    }
}
