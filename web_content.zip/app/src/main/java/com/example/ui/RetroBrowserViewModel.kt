package com.example.ui

import androidx.lifecycle.ViewModel
import com.example.model.BrowserMode
import com.example.model.BrowserTab
import com.example.model.UserAgentType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.UUID

data class RetroBrowserUiState(
    val browserMode: BrowserMode = BrowserMode.WINDOWS_XP_IE6,
    val tabs: List<BrowserTab> = listOf(
        BrowserTab(
            id = "default_tab",
            title = "MSN.com - Welcome to Internet Explorer 6",
            url = "file:///android_asset/msn_start_2001.html",
            isSecure = false
        )
    ),
    val activeTabId: String = "default_tab",
    val userAgentType: UserAgentType = UserAgentType.IE6_XP,
    val crtFilterActive: Boolean = false,
    val showFlashSettings: Boolean = false,
    val showWaybackDialog: Boolean = false,
    val showEraSitesDialog: Boolean = false,
    val showUserAgentDialog: Boolean = false,
    val showSourceCodeDialog: Boolean = false,
    val showAboutDialog: Boolean = false,
    val pageSourceCode: String = "",
    val isWidescreen16x9: Boolean = true,
    val displayResolution: DisplayResolution = DisplayResolution.RES_1080P_FHD,
    val showResolutionDialog: Boolean = false
) {
    val activeTab: BrowserTab
        get() = tabs.find { it.id == activeTabId } ?: tabs.firstOrNull() ?: BrowserTab(
            id = "fallback",
            title = "MSN.com",
            url = "file:///android_asset/msn_start_2001.html"
        )
}

class RetroBrowserViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(RetroBrowserUiState())
    val uiState: StateFlow<RetroBrowserUiState> = _uiState.asStateFlow()

    fun toggleBrowserMode() {
        _uiState.update { current ->
            val nextMode = if (current.browserMode == BrowserMode.WINDOWS_XP_IE6) {
                BrowserMode.GOOGLE_CHROME
            } else {
                BrowserMode.WINDOWS_XP_IE6
            }
            current.copy(browserMode = nextMode)
        }
    }

    fun setBrowserMode(mode: BrowserMode) {
        _uiState.update { it.copy(browserMode = mode) }
    }

    fun setUserAgent(type: UserAgentType) {
        _uiState.update { it.copy(userAgentType = type) }
    }

    fun toggleCrtFilter() {
        _uiState.update { it.copy(crtFilterActive = !it.crtFilterActive) }
    }

    fun setShowFlashSettings(show: Boolean) {
        _uiState.update { it.copy(showFlashSettings = show) }
    }

    fun setShowWaybackDialog(show: Boolean) {
        _uiState.update { it.copy(showWaybackDialog = show) }
    }

    fun setShowEraSitesDialog(show: Boolean) {
        _uiState.update { it.copy(showEraSitesDialog = show) }
    }

    fun setShowUserAgentDialog(show: Boolean) {
        _uiState.update { it.copy(showUserAgentDialog = show) }
    }

    fun setShowSourceCodeDialog(show: Boolean) {
        _uiState.update { it.copy(showSourceCodeDialog = show) }
    }

    fun setShowAboutDialog(show: Boolean) {
        _uiState.update { it.copy(showAboutDialog = show) }
    }

    fun setPageSourceCode(code: String) {
        _uiState.update { it.copy(pageSourceCode = code) }
    }

    fun toggleWidescreen16x9() {
        _uiState.update { 
            val next16x9 = !it.isWidescreen16x9
            val nextRes = if (next16x9) DisplayResolution.RES_1080P_FHD else DisplayResolution.RES_NATIVE_AUTO
            it.copy(isWidescreen16x9 = next16x9, displayResolution = nextRes) 
        }
    }

    fun setDisplayResolution(resolution: DisplayResolution) {
        _uiState.update { 
            it.copy(
                displayResolution = resolution,
                isWidescreen16x9 = resolution != DisplayResolution.RES_NATIVE_AUTO
            ) 
        }
    }

    fun setShowResolutionDialog(show: Boolean) {
        _uiState.update { it.copy(showResolutionDialog = show) }
    }

    fun newTab(initialUrl: String = "file:///android_asset/msn_start_2001.html") {
        val newId = UUID.randomUUID().toString()
        val newTab = BrowserTab(
            id = newId,
            title = "MSN.com",
            url = initialUrl
        )
        _uiState.update { current ->
            current.copy(
                tabs = current.tabs + newTab,
                activeTabId = newId
            )
        }
    }

    fun closeTab(tabId: String) {
        _uiState.update { current ->
            if (current.tabs.size <= 1) return@update current
            val updatedTabs = current.tabs.filterNot { it.id == tabId }
            val nextActiveId = if (current.activeTabId == tabId) {
                updatedTabs.last().id
            } else {
                current.activeTabId
            }
            current.copy(tabs = updatedTabs, activeTabId = nextActiveId)
        }
    }

    fun selectTab(tabId: String) {
        _uiState.update { it.copy(activeTabId = tabId) }
    }

    fun navigateTo(rawInput: String) {
        val targetUrl = normalizeUrl(rawInput.trim())
        updateActiveTabUrl(targetUrl)
    }

    private fun normalizeUrl(input: String): String {
        if (input.isBlank()) return "file:///android_asset/msn_start_2001.html"
        if (input.startsWith("file://") || input.startsWith("http://") || input.startsWith("https://")) {
            return input
        }
        // Check if looks like a domain name (e.g. apple.com, google.com)
        if (input.contains(".") && !input.contains(" ")) {
            return "https://$input"
        }
        // Search query -> redirect to retro search (Wiby or Google)
        return "https://wiby.me/?q=" + java.net.URLEncoder.encode(input, "UTF-8")
    }

    fun updateActiveTabUrl(url: String) {
        _uiState.update { current ->
            val updatedTabs = current.tabs.map { tab ->
                if (tab.id == current.activeTabId) {
                    tab.copy(url = url, isLoading = true)
                } else tab
            }
            current.copy(tabs = updatedTabs)
        }
    }

    fun updateTabState(
        tabId: String,
        title: String? = null,
        url: String? = null,
        canGoBack: Boolean? = null,
        canGoForward: Boolean? = null,
        isLoading: Boolean? = null,
        progress: Int? = null,
        isSecure: Boolean? = null
    ) {
        _uiState.update { current ->
            val updatedTabs = current.tabs.map { tab ->
                if (tab.id == tabId) {
                    tab.copy(
                        title = title ?: tab.title,
                        url = url ?: tab.url,
                        canGoBack = canGoBack ?: tab.canGoBack,
                        canGoForward = canGoForward ?: tab.canGoForward,
                        isLoading = isLoading ?: tab.isLoading,
                        progress = progress ?: tab.progress,
                        isSecure = isSecure ?: tab.isSecure
                    )
                } else tab
            }
            current.copy(tabs = updatedTabs)
        }
    }
}
