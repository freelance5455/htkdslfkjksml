package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.unit.dp
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.LaserGlow

@Composable
fun ScannerOverlay(
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "scanner_laser")
    val laserProgress by infiniteTransition.animateFloat(
        initialValue = 0.05f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laser_y"
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        val canvasWidth = size.width
        val canvasHeight = size.height

        // Sizing the scan box responsively (e.g. 70% of min dimension, capped at 320dp equivalent)
        val boxSize = (canvasWidth.coerceAtMost(canvasHeight) * 0.72f).coerceIn(240.dp.toPx(), 340.dp.toPx())
        val left = (canvasWidth - boxSize) / 2f
        val top = (canvasHeight - boxSize) / 2.3f
        val right = left + boxSize
        val bottom = top + boxSize
        val cornerRadius = 24.dp.toPx()

        val scanBoxRect = Rect(left, top, right, bottom)
        val scanBoxPath = Path().apply {
            addRoundRect(
                RoundRect(
                    left = left,
                    top = top,
                    right = right,
                    bottom = bottom,
                    cornerRadius = CornerRadius(cornerRadius, cornerRadius)
                )
            )
        }

        // 1. Draw dark translucent scrim everywhere outside the scan box
        clipPath(scanBoxPath, clipOp = ClipOp.Difference) {
            drawRect(color = Color(0x9E080C14))
        }

        // 2. Draw subtle border around the scanning viewport
        drawRoundRect(
            color = Color(0x3300E5FF),
            topLeft = Offset(left, top),
            size = Size(boxSize, boxSize),
            cornerRadius = CornerRadius(cornerRadius, cornerRadius),
            style = Stroke(width = 1.5.dp.toPx())
        )

        // 3. Draw bold high-tech glowing corner brackets
        val cornerLength = 32.dp.toPx()
        val cornerStroke = 4.dp.toPx()
        val bracketColor = CyanPrimary

        // Top-Left
        drawLine(
            color = bracketColor,
            start = Offset(left, top + cornerLength),
            end = Offset(left, top + cornerRadius / 2),
            strokeWidth = cornerStroke,
            cap = StrokeCap.Round
        )
        drawLine(
            color = bracketColor,
            start = Offset(left + cornerRadius / 2, top),
            end = Offset(left + cornerLength, top),
            strokeWidth = cornerStroke,
            cap = StrokeCap.Round
        )

        // Top-Right
        drawLine(
            color = bracketColor,
            start = Offset(right - cornerLength, top),
            end = Offset(right - cornerRadius / 2, top),
            strokeWidth = cornerStroke,
            cap = StrokeCap.Round
        )
        drawLine(
            color = bracketColor,
            start = Offset(right, top + cornerRadius / 2),
            end = Offset(right, top + cornerLength),
            strokeWidth = cornerStroke,
            cap = StrokeCap.Round
        )

        // Bottom-Left
        drawLine(
            color = bracketColor,
            start = Offset(left, bottom - cornerLength),
            end = Offset(left, bottom - cornerRadius / 2),
            strokeWidth = cornerStroke,
            cap = StrokeCap.Round
        )
        drawLine(
            color = bracketColor,
            start = Offset(left + cornerRadius / 2, bottom),
            end = Offset(left + cornerLength, bottom),
            strokeWidth = cornerStroke,
            cap = StrokeCap.Round
        )

        // Bottom-Right
        drawLine(
            color = bracketColor,
            start = Offset(right - cornerLength, bottom),
            end = Offset(right - cornerRadius / 2, bottom),
            strokeWidth = cornerStroke,
            cap = StrokeCap.Round
        )
        drawLine(
            color = bracketColor,
            start = Offset(right, bottom - cornerRadius / 2),
            end = Offset(right, bottom - cornerLength),
            strokeWidth = cornerStroke,
            cap = StrokeCap.Round
        )

        // 4. Draw animated laser scanning beam inside the scan box
        val laserY = top + (boxSize * laserProgress)
        val beamHeight = 40.dp.toPx()

        // Gradient glow above and below the laser
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color.Transparent,
                    LaserGlow.copy(alpha = 0.22f),
                    LaserGlow.copy(alpha = 0.55f),
                    LaserGlow.copy(alpha = 0.22f),
                    Color.Transparent
                ),
                startY = laserY - beamHeight / 2,
                endY = laserY + beamHeight / 2
            ),
            topLeft = Offset(left + 8.dp.toPx(), laserY - beamHeight / 2),
            size = Size(boxSize - 16.dp.toPx(), beamHeight)
        )

        // Sharp bright central laser line
        drawLine(
            brush = Brush.horizontalGradient(
                colors = listOf(
                    Color.Transparent,
                    LaserGlow,
                    Color.White,
                    LaserGlow,
                    Color.Transparent
                ),
                startX = left,
                endX = right
            ),
            start = Offset(left + 6.dp.toPx(), laserY),
            end = Offset(right - 6.dp.toPx(), laserY),
            strokeWidth = 2.5.dp.toPx(),
            cap = StrokeCap.Round
        )
    }
}
