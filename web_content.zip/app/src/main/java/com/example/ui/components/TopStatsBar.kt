package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Leaderboard
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.GameAmber
import com.example.ui.theme.GameAmberBright
import com.example.ui.theme.GameDarkBackground
import com.example.ui.theme.GameEmerald
import com.example.ui.theme.GameOrange
import com.example.ui.theme.GameRose
import com.example.ui.theme.GameSurfaceDark
import com.example.ui.theme.GameViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun TopStatsBar(
    score: Int,
    coins: Int,
    streak: Int,
    currentLevel: Int,
    dailyStreak: Int,
    dailyMultiplierLabel: String,
    unclaimedTasksCount: Int = 0,
    avatar: String = "🎮",
    playerName: String = "Player",
    profileTheme: String = "Amber",
    onOpenProfile: () -> Unit = {},
    onOpenLevels: () -> Unit,
    onOpenDaily: () -> Unit,
    onOpenTasks: () -> Unit,
    onOpenLeaderboard: () -> Unit,
    modifier: Modifier = Modifier
) {
    val themeAccent = when (profileTheme) {
        "Emerald" -> GameEmerald
        "Violet" -> GameViolet
        "Cyan" -> Color(0xFF06B6D4)
        "Rose" -> GameRose
        else -> GameAmber
    }

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = GameDarkBackground,
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1B2438)),
        shape = RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 10.dp)
        ) {
            // Main Top Row: Profile & Levels Icon, Score & Coins, Daily & Leaderboard Icons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left group: Profile button & Levels button
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Profile button
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onOpenProfile() }
                            .testTag("nav_profile_button"),
                        shape = RoundedCornerShape(12.dp),
                        color = GameSurfaceDark,
                        border = androidx.compose.foundation.BorderStroke(1.dp, themeAccent.copy(alpha = 0.55f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = avatar,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = playerName.take(8),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }

                    // Levels button
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onOpenLevels() }
                            .testTag("nav_levels_button"),
                        shape = RoundedCornerShape(12.dp),
                        color = GameSurfaceDark,
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF26334D))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.GridView,
                                contentDescription = "Levels",
                                tint = GameAmber,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "L$currentLevel",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                        }
                    }
                }

                // Middle Stats (Score & Coins)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Score
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Stars,
                            contentDescription = "Score",
                            tint = GameAmberBright,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "$score",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                    }

                    // Coins
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.MonetizationOn,
                            contentDescription = "Coins",
                            tint = GameAmber,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "$coins",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            color = GameAmberBright
                        )
                    }

                    // Streak Fire
                    if (streak > 0) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.LocalFireDepartment,
                                contentDescription = "Streak",
                                tint = GameOrange,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = "$streak",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                color = GameOrange
                            )
                        }
                    }
                }

                // Right Buttons: Daily Challenge & Leaderboard
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Daily Challenge button
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onOpenDaily() }
                            .testTag("nav_daily_button"),
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF281838),
                        border = androidx.compose.foundation.BorderStroke(1.dp, GameViolet.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.CalendarToday,
                                contentDescription = "Daily",
                                tint = Color(0xFFE879F9),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (dailyStreak > 0) "${dailyStreak}d ($dailyMultiplierLabel)" else "Daily",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = Color(0xFFF5D0FE)
                            )
                        }
                    }

                    // Tasks button with unclaimed rewards badge
                    IconButton(
                        onClick = onOpenTasks,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("nav_tasks_button")
                    ) {
                        if (unclaimedTasksCount > 0) {
                            BadgedBox(
                                badge = {
                                    Badge(
                                        containerColor = GameEmerald,
                                        contentColor = Color.Black
                                    ) {
                                        Text(
                                            text = "$unclaimedTasksCount",
                                            fontWeight = FontWeight.Black,
                                            fontSize = 9.sp
                                        )
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Assignment,
                                    contentDescription = "Tasks & Quests",
                                    tint = GameAmber,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        } else {
                            Icon(
                                imageVector = Icons.Default.Assignment,
                                contentDescription = "Tasks & Quests",
                                tint = GameAmber,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    // Leaderboard Icon
                    IconButton(
                        onClick = onOpenLeaderboard,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("nav_leaderboard_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Leaderboard,
                            contentDescription = "Leaderboard",
                            tint = GameAmber,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}
