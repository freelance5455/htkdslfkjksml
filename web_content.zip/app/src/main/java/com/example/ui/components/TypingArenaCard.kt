package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.ShortText
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.EngineState
import com.example.data.model.SlotItem
import com.example.data.model.TargetFieldType

@Composable
fun TypingArenaCard(
    targetField: TargetFieldType,
    onSelectTargetField: (TargetFieldType) -> Unit,
    singleLineText: String,
    multiLineText: String,
    slotItems: List<SlotItem>,
    activeSlotIndex: Int,
    engineState: EngineState,
    onSlotClick: (Int) -> Unit,
    onResetSlots: () -> Unit,
    onClearTarget: () -> Unit,
    onCopyTarget: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "cursor")
    val cursorAlpha by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(500),
            repeatMode = RepeatMode.Reverse
        ),
        label = "cursorAlpha"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("typing_arena_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.verticalGradient(
                listOf(
                    MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                    MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                )
            )
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header: Title + Target indicator badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF06B6D4))
                    )
                    Text(
                        text = "الخانة المحددة من طرفك للكتابة",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(
                        onClick = onCopyTarget,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("copy_target_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "نسخ المحتوى",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = onClearTarget,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("clear_target_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "مسح الخانة",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // Target Field Selector Tabs
            TabRow(
                selectedTabIndex = targetField.ordinal,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp)),
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                contentColor = MaterialTheme.colorScheme.primary
            ) {
                TargetFieldType.entries.forEach { type ->
                    val selected = targetField == type
                    Tab(
                        selected = selected,
                        onClick = { onSelectTargetField(type) },
                        text = {
                            Text(
                                text = type.titleAr,
                                fontSize = 12.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        icon = {
                            Icon(
                                imageVector = when (type) {
                                    TargetFieldType.SINGLE_LINE -> Icons.Default.ShortText
                                    TargetFieldType.MULTI_LINE -> Icons.Default.EditNote
                                    TargetFieldType.LETTER_SLOTS -> Icons.Default.GridOn
                                },
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    )
                }
            }

            // Target Content Display
            AnimatedContent(
                targetState = targetField,
                label = "target_content_anim"
            ) { currentField ->
                when (currentField) {
                    TargetFieldType.SINGLE_LINE -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 64.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                                .border(
                                    width = 1.dp,
                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.3f),
                                    shape = RoundedCornerShape(14.dp)
                                )
                                .padding(horizontal = 14.dp, vertical = 14.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            if (singleLineText.isEmpty()) {
                                Text(
                                    text = "حقل الإدخال السريع جاهز... اضغط (بدء الكتابة) لملء الكلمات تلقائياً",
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                )
                            } else {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = singleLineText,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    if (engineState == EngineState.TYPING) {
                                        Text(
                                            text = "|",
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = MaterialTheme.colorScheme.primary.copy(alpha = cursorAlpha)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    TargetFieldType.MULTI_LINE -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 120.dp, max = 200.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                                .border(
                                    width = 1.dp,
                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.3f),
                                    shape = RoundedCornerShape(14.dp)
                                )
                                .verticalScroll(rememberScrollState())
                                .padding(14.dp)
                        ) {
                            if (multiLineText.isEmpty()) {
                                Text(
                                    text = "محرر النصوص والمستندات... ستتدفق الكلمات المحددة تلقائياً هنا مع مسافات وفواصل منتظمة.",
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                )
                            } else {
                                Row(modifier = Modifier.fillMaxWidth()) {
                                    Text(
                                        text = multiLineText,
                                        fontSize = 15.sp,
                                        lineHeight = 22.sp,
                                        fontWeight = FontWeight.Normal,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    if (engineState == EngineState.TYPING) {
                                        Text(
                                            text = "|",
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            color = MaterialTheme.colorScheme.primary.copy(alpha = cursorAlpha)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    TargetFieldType.LETTER_SLOTS -> {
                        LetterSlotGrid(
                            slots = slotItems,
                            activeSlotIndex = activeSlotIndex,
                            onSlotClick = onSlotClick,
                            onResetSlots = onResetSlots
                        )
                    }
                }
            }

            // Bottom Info Row: Character & Word Stats in active field
            val activeText = when (targetField) {
                TargetFieldType.SINGLE_LINE -> singleLineText
                TargetFieldType.MULTI_LINE -> multiLineText
                TargetFieldType.LETTER_SLOTS -> slotItems.mapNotNull { it.charValue }.joinToString("")
            }

            val wordsInField = if (activeText.isBlank()) 0 else activeText.trim().split(Regex("\\s+")).size
            val charsInField = activeText.length

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "الحروف: $charsInField  |  الكلمات: $wordsInField",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Text(
                    text = if (engineState == EngineState.TYPING) "الكتابة جارية في هذه الخانة..." else "الخانة في وضع الاستعداد",
                    fontSize = 11.sp,
                    color = if (engineState == EngineState.TYPING) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                )
            }
        }
    }
}
