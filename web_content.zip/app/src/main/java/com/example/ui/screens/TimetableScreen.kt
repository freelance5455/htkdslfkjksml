package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.LessonEntity
import com.example.data.model.AppConstants
import com.example.data.model.LessonMode
import com.example.data.model.TimetableFilter
import com.example.ui.MainUiState
import com.example.ui.theme.BrandIndigo
import com.example.ui.theme.EmeraldSuccess
import com.example.util.DateTimeUtils

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TimetableScreen(
    uiState: MainUiState,
    columnCount: Int,
    onFilterChange: (TimetableFilter) -> Unit,
    onSearchChange: (String) -> Unit,
    onResetWeeklyAttendance: () -> Unit,
    onAddLessonForDay: (String) -> Unit,
    onEditLesson: (LessonEntity) -> Unit,
    onToggleAttended: (LessonEntity) -> Unit,
    onDeleteLesson: (LessonEntity) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Filter & Search bar
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(
                        selected = uiState.timetableFilter == TimetableFilter.ALL,
                        onClick = { onFilterChange(TimetableFilter.ALL) },
                        label = { Text("كل الأسبوع") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BrandIndigo,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("filter_timetable_all")
                    )
                    FilterChip(
                        selected = uiState.timetableFilter == TimetableFilter.TODAY,
                        onClick = { onFilterChange(TimetableFilter.TODAY) },
                        label = { Text("اليوم فقط") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = BrandIndigo,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("filter_timetable_today")
                    )
                    AssistChip(
                        onClick = onResetWeeklyAttendance,
                        label = { Text("أسبوع جديد") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Filled.Refresh,
                                contentDescription = "تصفير الحضور",
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = EmeraldSuccess.copy(alpha = 0.14f),
                            labelColor = EmeraldSuccess,
                            leadingIconContentColor = EmeraldSuccess
                        ),
                        modifier = Modifier.testTag("reset_weekly_attendance_button")
                    )
                }

                OutlinedTextField(
                    value = uiState.timetableSearch,
                    onValueChange = onSearchChange,
                    placeholder = { Text("ابحث عن مادة، مدرس، أو مكان...") },
                    leadingIcon = {
                        Icon(Icons.Filled.Search, contentDescription = "بحث")
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("timetable_search_input")
                )
            }
        }

        val daysToRender = if (uiState.timetableFilter == TimetableFilter.TODAY) {
            listOf(uiState.todayDayName)
        } else {
            AppConstants.DAYS_OF_WEEK
        }

        val effectiveColumns = if (uiState.timetableFilter == TimetableFilter.TODAY) 1 else columnCount.coerceAtLeast(1)
        val rows = daysToRender.chunked(effectiveColumns)
        val query = uiState.timetableSearch.trim().lowercase()

        rows.forEach { rowDays ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                rowDays.forEach { day ->
                    val dayLessons = uiState.lessons
                        .filter { lesson ->
                            lesson.day == day && (
                                query.isEmpty() ||
                                    lesson.subject.lowercase().contains(query) ||
                                    lesson.teacher.lowercase().contains(query) ||
                                    lesson.location.lowercase().contains(query)
                                )
                        }
                        .sortedBy { DateTimeUtils.parseTo24h(it.time).ifEmpty { "99:99" } }

                    DayScheduleCard(
                        day = day,
                        isToday = day == uiState.todayDayName,
                        lessons = dayLessons,
                        onAddForDay = { onAddLessonForDay(day) },
                        onToggleAttended = onToggleAttended,
                        onEditLesson = onEditLesson,
                        onDeleteLesson = onDeleteLesson,
                        modifier = Modifier.weight(1f)
                    )
                }
                repeat(effectiveColumns - rowDays.size) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun DayScheduleCard(
    day: String,
    isToday: Boolean,
    lessons: List<LessonEntity>,
    onAddForDay: () -> Unit,
    onToggleAttended: (LessonEntity) -> Unit,
    onEditLesson: (LessonEntity) -> Unit,
    onDeleteLesson: (LessonEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(
            width = if (isToday) 2.dp else 1.dp,
            color = if (isToday) BrandIndigo else MaterialTheme.colorScheme.outlineVariant
        ),
        modifier = modifier.testTag("day_card_$day")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = day,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Black
                    )
                    if (isToday) {
                        Surface(
                            color = BrandIndigo,
                            shape = CircleShape
                        ) {
                            Text(
                                text = "اليوم",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = CircleShape
                    ) {
                        Text(
                            text = lessons.size.toString(),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                    IconButton(
                        onClick = onAddForDay,
                        modifier = Modifier.size(36.dp).testTag("add_lesson_day_$day")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Add,
                            contentDescription = "إضافة درس في $day",
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            HorizontalDivider(
                modifier = Modifier.padding(vertical = 10.dp),
                color = MaterialTheme.colorScheme.outlineVariant
            )

            if (lessons.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
                        .padding(vertical = 24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "لا توجد دروس",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    lessons.forEach { lesson ->
                        LessonItemCard(
                            lesson = lesson,
                            onToggleAttended = { onToggleAttended(lesson) },
                            onEdit = { onEditLesson(lesson) },
                            onDelete = { onDeleteLesson(lesson) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LessonItemCard(
    lesson: LessonEntity,
    onToggleAttended: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val cardColor = AppConstants.parseHexColor(lesson.colorHex)
    val modeBadge = LessonMode.fromKey(lesson.mode).shortBadge
    val formattedTime = DateTimeUtils.formatTime12h(lesson.time)

    Surface(
        color = cardColor,
        shape = RoundedCornerShape(16.dp),
        border = if (lesson.attended) BorderStroke(2.dp, Color(0xFF34D399)) else null,
        modifier = Modifier
            .fillMaxWidth()
            .alpha(if (lesson.attended) 0.78f else 1f)
            .testTag("lesson_card_${lesson.id}")
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = lesson.subject,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White,
                        textDecoration = if (lesson.attended) TextDecoration.LineThrough else TextDecoration.None,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Surface(
                        color = Color.Black.copy(alpha = 0.22f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = modeBadge,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Surface(
                        onClick = onToggleAttended,
                        color = if (lesson.attended) Color(0xFF34D399) else Color.White.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.size(32.dp).testTag("toggle_attended_${lesson.id}")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Filled.Check,
                                contentDescription = "تم الحضور",
                                tint = if (lesson.attended) Color(0xFF0F172A) else Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    Surface(
                        onClick = onEdit,
                        color = Color.White.copy(alpha = 0.14f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.size(32.dp).testTag("edit_lesson_${lesson.id}")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Filled.Edit,
                                contentDescription = "تعديل الدرس",
                                tint = Color.White,
                                modifier = Modifier.size(15.dp)
                            )
                        }
                    }
                    Surface(
                        onClick = onDelete,
                        color = Color.White.copy(alpha = 0.14f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.size(32.dp).testTag("delete_lesson_${lesson.id}")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Filled.DeleteOutline,
                                contentDescription = "حذف الدرس",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            if (lesson.teacher.isNotBlank()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Person,
                        contentDescription = null,
                        tint = Color.White.copy(alpha = 0.9f),
                        modifier = Modifier.size(13.dp)
                    )
                    Text(
                        text = lesson.teacher,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.92f)
                    )
                }
            }

            if (formattedTime.isNotBlank() || lesson.location.isNotBlank()) {
                Spacer(modifier = Modifier.height(2.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (formattedTime.isNotBlank()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.AccessTime,
                                contentDescription = null,
                                tint = Color.White.copy(alpha = 0.9f),
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = formattedTime,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.92f)
                            )
                        }
                    }
                    if (lesson.location.isNotBlank()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.LocationOn,
                                contentDescription = null,
                                tint = Color.White.copy(alpha = 0.9f),
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = lesson.location,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.92f)
                            )
                        }
                    }
                }
            }
        }
    }
}
