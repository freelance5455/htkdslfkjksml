package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Book
import com.example.ui.theme.CoverCrimsonBg
import com.example.ui.theme.CoverCrimsonBorder
import com.example.ui.theme.CoverEmeraldBg
import com.example.ui.theme.CoverEmeraldBorder
import com.example.ui.theme.CoverMidnightBg
import com.example.ui.theme.CoverMidnightBorder
import com.example.ui.theme.CoverObsidianBg
import com.example.ui.theme.CoverObsidianBorder
import com.example.ui.theme.CoverParchmentBg
import com.example.ui.theme.CoverParchmentBorder
import com.example.ui.theme.LoraFontFamily
import com.example.ui.theme.PlayfairDisplayFontFamily

data class CoverColors(
    val backgroundTop: Color,
    val backgroundBottom: Color,
    val accentBorder: Color,
    val textPrimary: Color,
    val textSecondary: Color
)

fun resolveCoverColors(themeId: String): CoverColors {
    return when (themeId) {
        "midnight" -> CoverColors(
            backgroundTop = CoverMidnightBg,
            backgroundBottom = Color(0xFF0E1722),
            accentBorder = CoverMidnightBorder,
            textPrimary = Color(0xFFFDF8EE),
            textSecondary = Color(0xFFE0C580)
        )
        "emerald" -> CoverColors(
            backgroundTop = CoverEmeraldBg,
            backgroundBottom = Color(0xFF0C231A),
            accentBorder = CoverEmeraldBorder,
            textPrimary = Color(0xFFF7F4EB),
            textSecondary = Color(0xFFD8C287)
        )
        "parchment" -> CoverColors(
            backgroundTop = CoverParchmentBg,
            backgroundBottom = Color(0xFFE2D4BC),
            accentBorder = CoverParchmentBorder,
            textPrimary = Color(0xFF2B1D12),
            textSecondary = Color(0xFF6E472B)
        )
        "obsidian" -> CoverColors(
            backgroundTop = CoverObsidianBg,
            backgroundBottom = Color(0xFF101014),
            accentBorder = CoverObsidianBorder,
            textPrimary = Color(0xFFF5F2EB),
            textSecondary = Color(0xFFC5A059)
        )
        else -> CoverColors(
            backgroundTop = CoverCrimsonBg,
            backgroundBottom = Color(0xFF3A0D12),
            accentBorder = CoverCrimsonBorder,
            textPrimary = Color(0xFFFFF8F0),
            textSecondary = Color(0xFFE0B46A)
        )
    }
}

/**
 * Heirloom Editorial Typographic Book Cover (No AI image generation; pure classic bookbinding aesthetics).
 */
@Composable
fun TypographicBookCover(
    title: String,
    subtitle: String,
    genre: String,
    coverTheme: String,
    isAiCreated: Boolean,
    modifier: Modifier = Modifier,
    width: Dp = 116.dp,
    height: Dp = 168.dp,
    compact: Boolean = false
) {
    val palette = resolveCoverColors(coverTheme)

    Box(
        modifier = modifier
            .width(width)
            .height(height)
            .clip(RoundedCornerShape(topStart = 4.dp, bottomStart = 4.dp, topEnd = 12.dp, bottomEnd = 12.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(palette.backgroundTop, palette.backgroundBottom)
                )
            )
            .border(
                width = 1.dp,
                color = palette.accentBorder.copy(alpha = 0.5f),
                shape = RoundedCornerShape(topStart = 4.dp, bottomStart = 4.dp, topEnd = 12.dp, bottomEnd = 12.dp)
            )
    ) {
        // Book spine crease effect on the left
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .width(8.dp)
                .background(Color.Black.copy(alpha = 0.28f))
        )

        // Inner ornamental foil frame
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(start = 13.dp, end = 8.dp, top = 8.dp, bottom = 8.dp)
                .border(
                    width = 1.dp,
                    color = palette.accentBorder.copy(alpha = 0.7f),
                    shape = RoundedCornerShape(6.dp)
                )
                .padding(if (compact) 6.dp else 10.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = genre.uppercase(),
                    fontFamily = LoraFontFamily,
                    fontSize = if (compact) 8.sp else 9.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = palette.textSecondary,
                    letterSpacing = 1.2.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(vertical = 2.dp)
                ) {
                    HorizontalDivider(
                        modifier = Modifier
                            .width(24.dp)
                            .padding(bottom = 4.dp),
                        thickness = 1.dp,
                        color = palette.accentBorder.copy(alpha = 0.65f)
                    )
                    Text(
                        text = title.ifBlank { "İsimsiz Kitap" },
                        fontFamily = PlayfairDisplayFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = if (compact) 12.sp else 14.sp,
                        lineHeight = if (compact) 15.sp else 18.sp,
                        color = palette.textPrimary,
                        textAlign = TextAlign.Center,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (subtitle.isNotBlank() && !compact) {
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = subtitle,
                            fontFamily = LoraFontFamily,
                            fontSize = 9.sp,
                            lineHeight = 12.sp,
                            color = palette.textSecondary,
                            textAlign = TextAlign.Center,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    HorizontalDivider(
                        modifier = Modifier
                            .width(24.dp)
                            .padding(top = 4.dp),
                        thickness = 1.dp,
                        color = palette.accentBorder.copy(alpha = 0.65f)
                    )
                }

                Text(
                    text = if (isAiCreated) "✦ AI ESERİ ✦" else "✦ EL YAZMASI ✦",
                    fontFamily = LoraFontFamily,
                    fontSize = 7.sp,
                    color = palette.textSecondary.copy(alpha = 0.9f),
                    letterSpacing = 0.8.sp
                )
            }
        }
    }
}

@Composable
fun BookLibraryItemCard(
    book: Book,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TypographicBookCover(
                title = book.title,
                subtitle = book.subtitle,
                genre = book.genre,
                coverTheme = book.coverTheme,
                isAiCreated = book.isAiCreated,
                width = 92.dp,
                height = 136.dp,
                compact = true
            )

            Spacer(modifier = Modifier.width(16.dp))

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = if (book.isAiCreated) {
                            MaterialTheme.colorScheme.primaryContainer
                        } else {
                            MaterialTheme.colorScheme.secondaryContainer
                        },
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (book.isAiCreated) Icons.Default.AutoAwesome else Icons.Default.EditNote,
                                contentDescription = null,
                                modifier = Modifier.size(13.dp),
                                tint = if (book.isAiCreated) {
                                    MaterialTheme.colorScheme.onPrimaryContainer
                                } else {
                                    MaterialTheme.colorScheme.onSecondaryContainer
                                }
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (book.isAiCreated) "AI ile Oluşturuldu" else "Kendin Yazdın",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (book.isAiCreated) {
                                    MaterialTheme.colorScheme.onPrimaryContainer
                                } else {
                                    MaterialTheme.colorScheme.onSecondaryContainer
                                }
                            )
                        }
                    }

                    Text(
                        text = book.genre,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Text(
                    text = book.title,
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                if (book.subtitle.isNotBlank()) {
                    Text(
                        text = book.subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.secondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                if (book.synopsis.isNotBlank()) {
                    Text(
                        text = book.synopsis,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.height(2.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "${book.chapterCount} Bölüm",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "•",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "${book.totalWordCount} Kelime",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
