package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Mosque
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.DividerDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.theme.IslamicEmerald
import com.example.ui.theme.IslamicGold
import com.example.ui.theme.IslamicGoldLight
import com.example.ui.theme.IslamicGreenDark
import com.example.ui.theme.IslamicGreenPrimary
import com.example.ui.theme.TextPrimary

enum class AppDestination(
    val title: String,
    val icon: ImageVector,
    val tag: String
) {
    DASHBOARD("ড্যাশবোর্ড", Icons.Default.Home, "menu_dashboard"),
    INCOME("আয়", Icons.Default.AccountBalanceWallet, "menu_income"),
    EXPENSE("খরচ", Icons.Default.ShoppingCart, "menu_expense"),
    DEPOSIT("জমা", Icons.Default.Savings, "menu_deposit"),
    LOAN("ঋণ ব্যবস্থাপনা", Icons.Default.Handshake, "menu_loan"),
    SALARY("বেতন ব্যবস্থাপনা", Icons.Default.Mosque, "menu_salary"),
    QUICK_ADD("দ্রুত যোগ", Icons.Default.FlashOn, "menu_quick_add"),
    REPORT("রিপোর্ট", Icons.Default.Assessment, "menu_report"),
    SETTINGS("সেটিংস", Icons.Default.Settings, "menu_settings")
}

@Composable
fun IslamicDrawerContent(
    currentDestination: AppDestination,
    profileUri: String?,
    onDestinationSelected: (AppDestination) -> Unit,
    onProfileClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .width(300.dp)
            .fillMaxHeight(),
        color = Color(0xFFF9FCFA)
    ) {
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .verticalScroll(rememberScrollState())
        ) {
            // Drawer Header with Islamic Gradient & Profile
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                IslamicGreenDark,
                                IslamicGreenPrimary
                            )
                        )
                    )
                    .padding(20.dp)
            ) {
                Column {
                    Text(
                        text = "بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ",
                        color = IslamicGold,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.2f))
                                .clickable(onClick = onProfileClick)
                                .testTag("drawer_profile_icon"),
                            contentAlignment = Alignment.Center
                        ) {
                            if (!profileUri.isNullOrBlank()) {
                                AsyncImage(
                                    model = profileUri,
                                    contentDescription = "প্রোফাইল ছবি",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(54.dp)
                                        .clip(CircleShape)
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = "ডিফল্ট ছবি",
                                    tint = IslamicGold,
                                    modifier = Modifier.size(34.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column {
                            Text(
                                text = "নিজের হিসাব",
                                color = Color.White,
                                fontSize = 19.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "ব্যক্তিগত আর্থিক খতিয়ান",
                                color = IslamicGoldLight,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Menu Items List
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                AppDestination.values().forEach { destination ->
                    val isSelected = currentDestination == destination

                    val itemBackground = if (isSelected) {
                        IslamicGreenPrimary
                    } else {
                        Color.Transparent
                    }

                    val contentColor = if (isSelected) {
                        Color.White
                    } else {
                        TextPrimary
                    }

                    val iconTint = if (isSelected) {
                        IslamicGold
                    } else {
                        IslamicGreenPrimary
                    }

                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                            .shadow(
                                elevation = if (isSelected) 3.dp else 0.dp,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onDestinationSelected(destination) }
                            .testTag(destination.tag),
                        color = itemBackground,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        if (isSelected) Color.White.copy(alpha = 0.15f)
                                        else Color(0xFFE8F5EE)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = destination.icon,
                                    contentDescription = destination.title,
                                    tint = iconTint,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(14.dp))

                            Text(
                                text = destination.title,
                                color = contentColor,
                                fontSize = 15.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }

                    if (destination == AppDestination.REPORT) {
                        HorizontalDivider(
                            modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp),
                            color = Color(0xFFE5EBE7)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
