package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.EngineState
import com.example.ui.components.AppSettingsSheet
import com.example.ui.components.InAppFloatingPopup
import com.example.ui.components.TelemetryBanner
import com.example.ui.components.TypingArenaCard
import com.example.ui.components.TypingControlsCard
import com.example.ui.components.WordBankSheet
import com.example.ui.viewmodel.AutoWriterViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AutoWriterMainScreen(
    viewModel: AutoWriterViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val words by viewModel.words.collectAsStateWithLifecycle()
    val config by viewModel.config.collectAsStateWithLifecycle()
    val engineState by viewModel.engineState.collectAsStateWithLifecycle()
    val telemetry by viewModel.telemetry.collectAsStateWithLifecycle()
    val singleLineText by viewModel.singleLineText.collectAsStateWithLifecycle()
    val multiLineText by viewModel.multiLineText.collectAsStateWithLifecycle()
    val slotItems by viewModel.slotItems.collectAsStateWithLifecycle()
    val activeSlotIndex by viewModel.activeSlotIndex.collectAsStateWithLifecycle()
    val isFloatingPopupVisible by viewModel.inAppFloatingDialogVisible.collectAsStateWithLifecycle()
    val feedbackMessage by viewModel.userFeedbackMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    var isWordBankOpen by remember { mutableStateOf(false) }
    var isSettingsOpen by remember { mutableStateOf(false) }

    LaunchedEffect(feedbackMessage) {
        feedbackMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearFeedbackMessage()
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF67E8F9))
                        )
                        Text(
                            text = "AutoWriter • الكاتب الذكي",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 17.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                actions = {
                    // Floating Popup Toggle Button
                    IconButton(
                        onClick = { viewModel.toggleInAppFloatingDialog(!isFloatingPopupVisible) },
                        modifier = Modifier.testTag("toggle_floating_window_button")
                    ) {
                        BadgedBox(
                            badge = {
                                if (isFloatingPopupVisible) {
                                    Badge(containerColor = MaterialTheme.colorScheme.primary)
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Widgets,
                                contentDescription = "الشاشة المنبثقة",
                                tint = if (isFloatingPopupVisible) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    // Word Bank Button
                    IconButton(
                        onClick = { isWordBankOpen = true },
                        modifier = Modifier.testTag("open_word_bank_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = "بنك الكلمات",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Settings Button
                    IconButton(
                        onClick = { isSettingsOpen = true },
                        modifier = Modifier.testTag("open_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "الإعدادات والتحسينات",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    when (engineState) {
                        EngineState.TYPING -> viewModel.pauseTyping()
                        EngineState.PAUSED -> viewModel.resumeTyping()
                        EngineState.COMPLETED -> viewModel.manualRepeat()
                        EngineState.IDLE -> viewModel.startTyping()
                    }
                },
                icon = {
                    Icon(
                        imageVector = when (engineState) {
                            EngineState.TYPING -> Icons.Default.Stop
                            EngineState.COMPLETED -> Icons.Default.Replay
                            else -> Icons.Default.PlayArrow
                        },
                        contentDescription = null
                    )
                },
                text = {
                    Text(
                        text = when (engineState) {
                            EngineState.TYPING -> "إيقاف مؤقت"
                            EngineState.PAUSED -> "استئناف الكتابة"
                            EngineState.COMPLETED -> "إعادة التكرار"
                            EngineState.IDLE -> "بدء الكتابة التلقائية"
                        },
                        fontWeight = FontWeight.Bold
                    )
                },
                containerColor = when (engineState) {
                    EngineState.TYPING -> Color(0xFFF59E0B)
                    EngineState.COMPLETED -> Color(0xFF0284C7)
                    else -> MaterialTheme.colorScheme.primary
                },
                contentColor = Color.White,
                modifier = Modifier.testTag("main_action_fab")
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                contentPadding = PaddingValues(top = 10.dp, bottom = 90.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Box(modifier = Modifier.widthIn(max = 680.dp)) {
                        // Hero Visual Banner
                        HeroBannerCard(
                            onOpenWordBank = { isWordBankOpen = true },
                            onToggleFloating = { viewModel.toggleInAppFloatingDialog(true) }
                        )
                    }
                }

                item {
                    Box(modifier = Modifier.widthIn(max = 680.dp)) {
                        TelemetryBanner(
                            telemetry = telemetry,
                            engineState = engineState,
                            config = config
                        )
                    }
                }

                item {
                    Box(modifier = Modifier.widthIn(max = 680.dp)) {
                        TypingArenaCard(
                            targetField = config.targetField,
                            onSelectTargetField = { viewModel.setTargetField(it) },
                            singleLineText = singleLineText,
                            multiLineText = multiLineText,
                            slotItems = slotItems,
                            activeSlotIndex = activeSlotIndex,
                            engineState = engineState,
                            onSlotClick = { viewModel.selectSlot(it) },
                            onResetSlots = { viewModel.clearTarget() },
                            onClearTarget = { viewModel.clearTarget() },
                            onCopyTarget = { viewModel.copyTargetToClipboard(context) }
                        )
                    }
                }

                item {
                    Box(modifier = Modifier.widthIn(max = 680.dp)) {
                        TypingControlsCard(
                            config = config,
                            engineState = engineState,
                            onStart = { viewModel.startTyping() },
                            onPause = { viewModel.pauseTyping() },
                            onStop = { viewModel.stopTyping() },
                            onManualRepeat = { viewModel.manualRepeat() },
                            onToggleAutoRepeat = { viewModel.toggleAutoRepeat(it) },
                            onSpeedChange = { viewModel.updateCharSpeed(it) },
                            onRandomCountChange = { viewModel.updateRandomWordCount(it) },
                            onToggleRandomMode = { viewModel.updateRandomMode(it) }
                        )
                    }
                }
            }

            // In-App Draggable Floating Popup Overlay
            InAppFloatingPopup(
                isVisible = isFloatingPopupVisible,
                telemetry = telemetry,
                engineState = engineState,
                config = config,
                onStart = { viewModel.startTyping() },
                onPause = { viewModel.pauseTyping() },
                onStop = { viewModel.stopTyping() },
                onManualRepeat = { viewModel.manualRepeat() },
                onToggleAutoRepeat = { viewModel.toggleAutoRepeat(it) },
                onClose = { viewModel.toggleInAppFloatingDialog(false) },
                onCopyCurrentWord = {
                    val word = telemetry.currentWordText
                    if (word.isNotEmpty()) {
                        viewModel.copyTargetToClipboard(context)
                        Toast.makeText(context, "تم نسخ: $word", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 70.dp)
            )
        }
    }

    // Word Bank Sheet
    if (isWordBankOpen) {
        WordBankSheet(
            words = words,
            onAddWord = { text, cat -> viewModel.addCustomWord(text, cat) },
            onBulkAddWords = { text, cat -> viewModel.bulkAddWords(text, cat) },
            onToggleWord = { viewModel.toggleWord(it) },
            onDeleteWord = { viewModel.deleteWord(it) },
            onSelectAll = { viewModel.selectAllWords(it) },
            onResetDefaults = { viewModel.resetWordsToDefaults() },
            onDismiss = { isWordBankOpen = false }
        )
    }

    // App Settings Sheet
    if (isSettingsOpen) {
        AppSettingsSheet(
            config = config,
            onToggleSound = { viewModel.toggleSound(it) },
            onToggleHaptics = { viewModel.toggleHaptics(it) },
            onToggleHumanJitter = { viewModel.toggleHumanJitter(it) },
            onWordDelayChange = { viewModel.updateWordDelay(it) },
            onDismiss = { isSettingsOpen = false }
        )
    }
}

@Composable
private fun HeroBannerCard(
    onOpenWordBank: () -> Unit,
    onToggleFloating: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("hero_banner_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            Image(
                painter = painterResource(id = R.drawable.banner_autowriter_1793928695476),
                contentDescription = "AutoWriter Studio Banner",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp),
                contentScale = ContentScale.Crop
            )

            // Gradient overlay
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color.Transparent,
                                Color(0xFF0F172A).copy(alpha = 0.85f)
                            )
                        )
                    )
            )

            // Text on banner
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(14.dp)
            ) {
                Text(
                    text = "منظومة الكتابة الذكية والأتمتة",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White
                )
                Text(
                    text = "تعبئة الخانات المحددة بالكلمات المخصصة، تحكم بالسرعة والشاشة المنبثقة",
                    fontSize = 11.sp,
                    color = Color(0xFF67E8F9)
                )
            }
        }
    }
}
