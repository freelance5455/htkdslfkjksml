package com.example.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Subject
import com.example.ui.DojoUiState
import com.example.ui.theme.ChakraCyan
import com.example.ui.theme.NarutoFlame
import com.example.ui.theme.NarutoGold
import com.example.ui.theme.NarutoOrange
import com.example.ui.theme.NarutoOrangeDark

@Composable
fun TimerScreen(
  uiState: DojoUiState,
  onSelectSubject: (Subject) -> Unit,
  onSetPresetMinutes: (Int) -> Unit,
  onStartTimer: () -> Unit,
  onPauseTimer: () -> Unit,
  onResumeTimer: () -> Unit,
  onResetTimer: () -> Unit,
  onDismissDialog: () -> Unit,
  modifier: Modifier = Modifier
) {
  var showCustomMinutesDialog by remember { mutableStateOf(false) }

  val progress = if (uiState.timerTotalSeconds > 0) {
    uiState.timerRemainingSeconds.toFloat() / uiState.timerTotalSeconds.toFloat()
  } else 0f
  val animatedProgress by animateFloatAsState(targetValue = progress, label = "chakra_progress")

  val minutes = uiState.timerRemainingSeconds / 60
  val seconds = uiState.timerRemainingSeconds % 60
  val timeDisplay = String.format("%02d:%02d", minutes, seconds)

  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    // Subject Selection Row
    item {
      Text(
        text = "Select Training Subject",
        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onBackground,
        modifier = Modifier.fillMaxWidth()
      )
      Spacer(modifier = Modifier.height(8.dp))

      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        items(Subject.entries) { sub ->
          val isSelected = uiState.timerSubject == sub
          FilterChip(
            selected = isSelected,
            onClick = { onSelectSubject(sub) },
            label = { Text(sub.displayName) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = sub.color,
              selectedLabelColor = Color.White
            ),
            modifier = Modifier.testTag("timer_subject_${sub.name.lowercase()}")
          )
        }
      }
    }

    item { Spacer(modifier = Modifier.height(20.dp)) }

    // Preset Durations
    item {
      Row(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        listOf(25 to "25m (Burst)", 45 to "45m (Session)", 60 to "60m (Deep)").forEach { (mins, label) ->
          val isCurrentPreset = (uiState.timerTotalSeconds == mins * 60)
          OutlinedButton(
            onClick = { onSetPresetMinutes(mins) },
            modifier = Modifier
              .weight(1f)
              .testTag("timer_preset_${mins}"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.outlinedButtonColors(
              containerColor = if (isCurrentPreset) NarutoOrange.copy(alpha = 0.15f) else Color.Transparent,
              contentColor = if (isCurrentPreset) NarutoOrange else MaterialTheme.colorScheme.onSurface
            ),
            border = ButtonDefaults.outlinedButtonBorder.copy(
              brush = Brush.linearGradient(
                colors = if (isCurrentPreset) listOf(NarutoOrange, NarutoFlame)
                else listOf(MaterialTheme.colorScheme.outline, MaterialTheme.colorScheme.outline)
              )
            )
          ) {
            Text(text = label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      TextButton(
        onClick = { showCustomMinutesDialog = true },
        modifier = Modifier.testTag("timer_custom_minutes_button")
      ) {
        Icon(Icons.Default.Timer, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("Custom Minutes", color = ChakraCyan, fontSize = 13.sp)
      }
    }

    item { Spacer(modifier = Modifier.height(16.dp)) }

    // Giant Chakra Energy Ring & Timer Display
    item {
      Box(
        modifier = Modifier
          .size(260.dp)
          .padding(8.dp),
        contentAlignment = Alignment.Center
      ) {
        val activeColor = uiState.timerSubject.color
        val flameColor = NarutoOrange

        Canvas(modifier = Modifier.fillMaxSize()) {
          val strokeWidth = 16.dp.toPx()
          val radius = (size.minDimension - strokeWidth) / 2f
          val arcCenter = this.center

          // Background track
          drawCircle(
            color = Color.Gray.copy(alpha = 0.2f),
            radius = radius,
            center = arcCenter,
            style = Stroke(width = strokeWidth)
          )

          // Glowing Chakra arc
          drawArc(
            brush = Brush.sweepGradient(
              colors = listOf(flameColor, activeColor, ChakraCyan, flameColor)
            ),
            startAngle = -90f,
            sweepAngle = 360f * animatedProgress,
            useCenter = false,
            topLeft = androidx.compose.ui.geometry.Offset(strokeWidth / 2f, strokeWidth / 2f),
            size = androidx.compose.ui.geometry.Size(size.width - strokeWidth, size.height - strokeWidth),
            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
          )
        }

        // Inner Timer Content
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.Center
        ) {
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = uiState.timerSubject.color.copy(alpha = 0.15f)
          ) {
            Text(
              text = uiState.timerSubject.displayName.uppercase(),
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Black),
              color = uiState.timerSubject.color,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
            )
          }

          Spacer(modifier = Modifier.height(8.dp))

          Text(
            text = timeDisplay,
            style = MaterialTheme.typography.displayMedium.copy(
              fontWeight = FontWeight.Black,
              fontFamily = FontFamily.Monospace,
              letterSpacing = 1.sp
            ),
            color = MaterialTheme.colorScheme.onSurface
          )

          Spacer(modifier = Modifier.height(4.dp))

          Text(
            text = when {
              !uiState.isTimerRunning -> "Ready for Training"
              uiState.isTimerPaused -> "Paused (Chakra Stored)"
              else -> "🔥 Focused Shinobi Mode"
            },
            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
            color = if (uiState.isTimerRunning) NarutoOrange else MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }

    item { Spacer(modifier = Modifier.height(24.dp)) }

    // Controls Row (Start / Pause / Resume / Reset)
    item {
      Row(
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Reset Button
        OutlinedButton(
          onClick = onResetTimer,
          shape = CircleShape,
          modifier = Modifier
            .size(56.dp)
            .testTag("timer_reset_button")
        ) {
          Icon(
            imageVector = Icons.Default.Refresh,
            contentDescription = "Reset Timer",
            tint = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        // Main Action Button (Play / Pause / Resume)
        Button(
          onClick = {
            when {
              !uiState.isTimerRunning -> onStartTimer()
              uiState.isTimerPaused -> onResumeTimer()
              else -> onPauseTimer()
            }
          },
          shape = RoundedCornerShape(24.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = if (uiState.isTimerRunning && !uiState.isTimerPaused)
              NarutoFlame else NarutoOrange
          ),
          modifier = Modifier
            .height(56.dp)
            .width(160.dp)
            .testTag("timer_action_button")
        ) {
          Icon(
            imageVector = when {
              !uiState.isTimerRunning -> Icons.Default.PlayArrow
              uiState.isTimerPaused -> Icons.Default.PlayArrow
              else -> Icons.Default.Pause
            },
            contentDescription = null,
            modifier = Modifier.size(24.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = when {
              !uiState.isTimerRunning -> "START"
              uiState.isTimerPaused -> "RESUME"
              else -> "PAUSE"
            },
            fontWeight = FontWeight.Black,
            fontSize = 16.sp
          )
        }
      }
    }

    item { Spacer(modifier = Modifier.height(32.dp)) }

    // Stats Summary: Today's Total, Weekly Total
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        // Today
        Card(
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Text(
              text = "Today's Focus",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "${uiState.todayStudyMinutes}m",
              style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Black,
                color = NarutoOrange
              )
            )
            Text(
              text = "Target: 120m",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        // Weekly
        Card(
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Text(
              text = "Weekly Focus",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            val hours = uiState.weeklyStudyMinutes / 60
            val remMin = uiState.weeklyStudyMinutes % 60
            Text(
              text = "${hours}h ${remMin}m",
              style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Black,
                color = ChakraCyan
              )
            )
            Text(
              text = "${uiState.studySessions.size} Sessions",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    }

    item { Spacer(modifier = Modifier.height(24.dp)) }

    // Per-Subject Study Distribution Bar Chart
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "Subject Study Distribution (Minutes)",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface
          )
          Spacer(modifier = Modifier.height(16.dp))

          val map = uiState.subjectMinutesMap
          val maxMinutes = (map.values.maxOrNull() ?: 1).coerceAtLeast(60)

          Row(
            modifier = Modifier
              .fillMaxWidth()
              .height(140.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.Bottom
          ) {
            Subject.entries.forEach { sub ->
              val minutesStudied = map[sub] ?: 0
              val barRatio = (minutesStudied.toFloat() / maxMinutes.toFloat()).coerceIn(0.08f, 1f)

              Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Bottom,
                modifier = Modifier.weight(1f)
              ) {
                Text(
                  text = "${minutesStudied}m",
                  style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                  fontSize = 11.sp,
                  color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))

                Box(
                  modifier = Modifier
                    .width(28.dp)
                    .height((barRatio * 90).dp)
                    .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                    .background(
                      Brush.verticalGradient(
                        colors = listOf(sub.color, sub.color.copy(alpha = 0.6f))
                      )
                    )
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                  text = sub.shortCode,
                  style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Black),
                  color = sub.color
                )
              }
            }
          }
        }
      }
    }
  }

  // Custom Minutes Dialog
  if (showCustomMinutesDialog) {
    var customInput by remember { mutableStateOf("30") }
    AlertDialog(
      onDismissRequest = { showCustomMinutesDialog = false },
      title = { Text("Set Custom Timer Minutes") },
      text = {
        OutlinedTextField(
          value = customInput,
          onValueChange = { customInput = it.filter { ch -> ch.isDigit() } },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          label = { Text("Minutes (1 - 180)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )
      },
      confirmButton = {
        Button(
          onClick = {
            val mins = customInput.toIntOrNull()?.coerceIn(1, 180) ?: 25
            onSetPresetMinutes(mins)
            showCustomMinutesDialog = false
          },
          colors = ButtonDefaults.buttonColors(containerColor = NarutoOrange)
        ) {
          Text("Set Timer")
        }
      },
      dismissButton = {
        TextButton(onClick = { showCustomMinutesDialog = false }) {
          Text("Cancel")
        }
      }
    )
  }

  // Timer Completed Alert Celebration Dialog
  if (uiState.timerFinishedDialog) {
    AlertDialog(
      onDismissRequest = onDismissDialog,
      icon = {
        Box(
          modifier = Modifier
            .size(54.dp)
            .clip(CircleShape)
            .background(NarutoOrange),
          contentAlignment = Alignment.Center
        ) {
          Icon(Icons.Default.Celebration, contentDescription = null, tint = Color.White)
        }
      },
      title = {
        Text(
          text = "Training Complete! ⚡",
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black)
        )
      },
      text = {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(
            text = "Great discipline! You studied ${uiState.lastLoggedMinutes} minutes of ${uiState.timerSubject.displayName}.",
            style = MaterialTheme.typography.bodyMedium
          )
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "\"A ninja never wavers on their path! Keep building your Plus Two mastery!\" — Naruto",
            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
            color = NarutoOrangeDark
          )
        }
      },
      confirmButton = {
        Button(
          onClick = onDismissDialog,
          colors = ButtonDefaults.buttonColors(containerColor = NarutoOrange),
          modifier = Modifier.testTag("dismiss_timer_celebration_button")
        ) {
          Text("Log & Continue")
        }
      }
    )
  }
}
