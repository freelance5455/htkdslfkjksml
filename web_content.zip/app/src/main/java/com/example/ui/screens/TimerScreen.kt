package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.audio.AmbientSound
import com.example.data.model.StickerCatalog
import com.example.data.model.StudySession
import com.example.data.model.Subject
import com.example.ui.PomodoroMode
import com.example.ui.SettingsUiState
import com.example.ui.TimerUiState
import com.example.ui.components.AddEditSubjectDialog
import com.example.ui.components.CircularTimerDisplay
import com.example.ui.components.PrivacyPolicyDialog
import com.example.ui.components.SavingsPerksDialog
import com.example.ui.components.StickerBookDialog
import com.example.ui.components.StickerRewardPopupDialog
import com.example.ui.components.SubjectPickerDialog
import com.example.ui.components.VipPaymentDialog
import com.example.ui.theme.AestheticBlack
import com.example.ui.theme.BorderGrey
import com.example.ui.theme.CardGrey
import com.example.ui.theme.DeepPink
import com.example.ui.theme.KawaiiPink
import com.example.ui.theme.MutedGrey
import com.example.ui.theme.PastelPinkBg
import com.example.ui.theme.PastelPinkContainer
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoseTint
import com.example.ui.theme.TextGrey
import java.util.Calendar

@Composable
fun TimerScreen(
    timerState: TimerUiState,
    settings: SettingsUiState,
    subjects: List<Subject>,
    sessions: List<StudySession>,
    onStartTimer: () -> Unit,
    onPauseTimer: () -> Unit,
    onResetTimer: () -> Unit,
    onSelectMode: (PomodoroMode) -> Unit,
    onAdjustTime: (Int) -> Unit,
    onSelectSubject: (Subject) -> Unit,
    onAddSubject: (String, String, String, Int) -> Unit,
    onSetAmbientSound: (AmbientSound) -> Unit,
    onCompleteEarly: () -> Unit,
    onDismissRewardSticker: () -> Unit,
    onSelectActiveSticker: (String) -> Unit,
    onActivateVip: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var showSubjectPicker by remember { mutableStateOf(false) }
    var showNewSubjectDialog by remember { mutableStateOf(false) }
    var showStickerBook by remember { mutableStateOf(false) }
    var showVipDialog by remember { mutableStateOf(false) }
    var showSavingsDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }

    // Calculate today's study minutes
    val calendar = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }
    val startOfDay = calendar.timeInMillis
    val todaySessions = sessions.filter { it.timestamp >= startOfDay && it.sessionType == "FOCUS" }
    val todayFocusMinutes = todaySessions.sumOf { it.durationSeconds } / 60
    val totalFocusMinutes = sessions.filter { it.sessionType == "FOCUS" }.sumOf { it.durationSeconds } / 60
    val dailyGoal = settings.dailyGoalMinutes

    val activeSticker = StickerCatalog.allStickers.find { it.id == timerState.activeStickerId }
        ?: StickerCatalog.allStickers.first()

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(PastelPinkBg)
            .verticalScroll(scrollState)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top Header Info Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "🌸 Study Timer",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = (-0.5).sp
                    ),
                    color = AestheticBlack
                )
                Text(
                    text = "Pastel Pomodoro & Stationery Stickers",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextGrey
                )
            }

            // Daily Progress Pill
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = PastelPinkContainer,
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderGrey)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "✨ ${todayFocusMinutes}m / ${dailyGoal}m",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = DeepPink
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Attractive Quick Action Strip: VIP Deal, Savings Jar, Stickers
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // VIP Pass Button
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = if (settings.isVipActive) PureWhite else PastelPinkContainer,
                border = androidx.compose.foundation.BorderStroke(1.dp, if (settings.isVipActive) DeepPink else KawaiiPink),
                shadowElevation = 1.dp,
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { showVipDialog = true }
                    .testTag("open_vip_dialog_btn")
            ) {
                Row(
                    modifier = Modifier.padding(vertical = 7.dp, horizontal = 6.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = if (settings.isVipActive) "👑 VIP Active" else "👑 VIP ₹199", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = DeepPink)
                }
            }

            // Savings Jar Button
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = PureWhite,
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderGrey),
                shadowElevation = 1.dp,
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { showSavingsDialog = true }
                    .testTag("open_savings_dialog_btn")
            ) {
                Row(
                    modifier = Modifier.padding(vertical = 7.dp, horizontal = 6.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "💰 Savings", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AestheticBlack)
                }
            }

            // Sticker Board Button
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = PureWhite,
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderGrey),
                shadowElevation = 1.dp,
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { showStickerBook = true }
                    .testTag("sticker_book_btn")
            ) {
                Row(
                    modifier = Modifier.padding(vertical = 7.dp, horizontal = 6.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "🎀 Stickers", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AestheticBlack)
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Cute Kawaii Hero Artwork Card (Stationery Stickers)
        Card(
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            border = androidx.compose.foundation.BorderStroke(2.dp, PureWhite),
            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(115.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_kawaii_study),
                        contentDescription = "Cute stationery stickers illustration",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }

                // Quote strip below image
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(PureWhite)
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "\"${timerState.motivationalQuote}\"",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontWeight = FontWeight.SemiBold
                        ),
                        color = AestheticBlack,
                        textAlign = TextAlign.Center,
                        maxLines = 1
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Mode Switcher Tabs
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = PureWhite,
            border = androidx.compose.foundation.BorderStroke(1.dp, BorderGrey),
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                PomodoroMode.values().forEach { mode ->
                    val isSelected = timerState.mode == mode

                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = if (isSelected) PastelPinkContainer else Color.Transparent,
                        border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, DeepPink.copy(alpha = 0.5f)) else null,
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(20.dp))
                            .clickable { onSelectMode(mode) }
                            .testTag("mode_tab_${mode.name.lowercase()}")
                    ) {
                        Row(
                            modifier = Modifier.padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = mode.emoji, fontSize = 13.sp)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = mode.title,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                ),
                                color = if (isSelected) DeepPink else TextGrey
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Main Circular Timer
        CircularTimerDisplay(
            mode = timerState.mode,
            isRunning = timerState.isRunning,
            totalSeconds = timerState.totalSeconds,
            secondsRemaining = timerState.secondsRemaining,
            selectedSubject = timerState.selectedSubject,
            completedCycles = timerState.completedCycles,
            activeSticker = activeSticker,
            onSubjectClick = { showSubjectPicker = true },
            onStickerClick = { showStickerBook = true }
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Quick Adjust Time Buttons (+5m, -5m, +15m)
        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FilledTonalButton(
                onClick = { onAdjustTime(-5) },
                colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = PureWhite,
                    contentColor = TextGrey
                ),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderGrey),
                modifier = Modifier.height(34.dp)
            ) {
                Text("-5 min", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold))
            }

            FilledTonalButton(
                onClick = { onAdjustTime(5) },
                colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = PureWhite,
                    contentColor = DeepPink
                ),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderGrey),
                modifier = Modifier.height(34.dp)
            ) {
                Text("+5 min", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold))
            }

            FilledTonalButton(
                onClick = { onAdjustTime(15) },
                colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = PureWhite,
                    contentColor = AestheticBlack
                ),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderGrey),
                modifier = Modifier.height(34.dp)
            ) {
                Text("+15 min", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold))
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Primary Timer Controls Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Reset Button
            IconButton(
                onClick = onResetTimer,
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(PureWhite)
                    .border(1.dp, BorderGrey, CircleShape)
                    .testTag("reset_timer_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Reset Timer",
                    tint = TextGrey,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(24.dp))

            // Main Play/Pause Button (Aesthetic Black with White Icon)
            Surface(
                shape = CircleShape,
                color = AestheticBlack,
                shadowElevation = 6.dp,
                modifier = Modifier
                    .size(76.dp)
                    .clip(CircleShape)
                    .clickable {
                        if (timerState.isRunning) onPauseTimer() else onStartTimer()
                    }
                    .testTag("play_pause_timer_btn")
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = if (timerState.isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (timerState.isRunning) "Pause" else "Start",
                        tint = PureWhite,
                        modifier = Modifier.size(38.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(24.dp))

            // Complete Session Early or Skip
            val canCompleteEarly = (timerState.totalSeconds - timerState.secondsRemaining) >= 60 &&
                    timerState.mode == PomodoroMode.FOCUS

            IconButton(
                onClick = {
                    if (canCompleteEarly) onCompleteEarly() else onResetTimer()
                },
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(PureWhite)
                    .border(1.dp, if (canCompleteEarly) DeepPink else BorderGrey, CircleShape)
                    .testTag("skip_complete_timer_btn")
            ) {
                Icon(
                    imageVector = if (canCompleteEarly) Icons.Outlined.CheckCircle else Icons.Default.SkipNext,
                    contentDescription = if (canCompleteEarly) "Complete session now" else "Next mode",
                    tint = if (canCompleteEarly) DeepPink else TextGrey,
                    modifier = Modifier.size(22.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Ambient Background Focus Sounds
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = PureWhite),
            border = androidx.compose.foundation.BorderStroke(1.dp, BorderGrey),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "🎧 Ambient Focus Audio",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = AestheticBlack
                    )
                    if (timerState.ambientSound != AmbientSound.NONE) {
                        Text(
                            text = if (timerState.isRunning) "Playing" else "Ready",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = DeepPink
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AmbientSound.values().forEach { sound ->
                        val isSelected = timerState.ambientSound == sound
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) PastelPinkContainer else CardGrey,
                            border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, DeepPink) else null,
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { onSetAmbientSound(sound) }
                                .testTag("ambient_sound_${sound.name.lowercase()}")
                        ) {
                            Column(
                                modifier = Modifier.padding(vertical = 8.dp, horizontal = 4.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(sound.icon, fontSize = 16.sp)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = sound.label,
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                    color = if (isSelected) DeepPink else TextGrey,
                                    textAlign = TextAlign.Center,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Attractive VIP Upgrade Banner at Bottom
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = if (settings.isVipActive) PureWhite else PastelPinkContainer),
            border = androidx.compose.foundation.BorderStroke(1.dp, DeepPink.copy(alpha = 0.5f)),
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .clickable { showVipDialog = true }
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("👑", fontSize = 22.sp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = if (settings.isVipActive) "VIP Member • All Features Unlocked" else "Study VIP: ₹199 for 2 Months",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            color = AestheticBlack
                        )
                        Text(
                            text = if (settings.isVipActive) "Active for 60 days • Tap to view benefits" else "Scan QR to activate • Save 60% with StudyCoins",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                            color = DeepPink
                        )
                    }
                }
                Text("View →", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = AestheticBlack)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Privacy Footer Link
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .clickable { showPrivacyDialog = true }
                .padding(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Security, contentDescription = null, tint = TextGrey, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Privacy Disclaimers & Offline Guarantee", style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp), color = TextGrey)
        }

        Spacer(modifier = Modifier.height(16.dp))
    }

    // Dialogs
    if (showSubjectPicker) {
        SubjectPickerDialog(
            subjects = subjects,
            selectedSubject = timerState.selectedSubject,
            onSubjectSelected = onSelectSubject,
            onAddNewSubject = { showNewSubjectDialog = true },
            onDismiss = { showSubjectPicker = false }
        )
    }

    if (showNewSubjectDialog) {
        AddEditSubjectDialog(
            initialSubject = null,
            onSave = { name, icon, color, goal ->
                onAddSubject(name, icon, color, goal)
            },
            onDismiss = { showNewSubjectDialog = false }
        )
    }

    // Sticker Reward Pop-up Dialog
    if (timerState.newUnlockedSticker != null) {
        StickerRewardPopupDialog(
            sticker = timerState.newUnlockedSticker,
            onDismiss = onDismissRewardSticker
        )
    }

    // Sticker Book Dialog
    if (showStickerBook) {
        StickerBookDialog(
            totalFocusMinutes = totalFocusMinutes,
            activeStickerId = timerState.activeStickerId,
            onSelectActiveSticker = { id ->
                onSelectActiveSticker(id)
            },
            onDismiss = { showStickerBook = false }
        )
    }

    // VIP Payment Dialog
    if (showVipDialog) {
        VipPaymentDialog(
            isVipActive = settings.isVipActive,
            onActivateVip = {
                onActivateVip()
                showVipDialog = false
            },
            onOpenPrivacy = {
                showVipDialog = false
                showPrivacyDialog = true
            },
            onDismiss = { showVipDialog = false }
        )
    }

    // Savings Perks Dialog
    if (showSavingsDialog) {
        SavingsPerksDialog(
            totalFocusMinutes = totalFocusMinutes,
            onOpenVipPayment = {
                showSavingsDialog = false
                showVipDialog = true
            },
            onDismiss = { showSavingsDialog = false }
        )
    }

    // Privacy Disclaimers Dialog
    if (showPrivacyDialog) {
        PrivacyPolicyDialog(
            onDismiss = { showPrivacyDialog = false }
        )
    }
}
