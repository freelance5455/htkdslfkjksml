package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DeviceStatus
import com.example.data.model.VoiceLanguage
import com.example.ui.theme.XtraAlertRed
import com.example.ui.theme.XtraCardBorder
import com.example.ui.theme.XtraCardDark
import com.example.ui.theme.XtraCyanGlow
import com.example.ui.theme.XtraCyanPrimary
import com.example.ui.theme.XtraNeonGreen
import com.example.ui.theme.XtraTextHigh
import com.example.ui.theme.XtraTextMed

@Composable
fun TelemetryHudBar(
    deviceStatus: DeviceStatus,
    isSpeaking: Boolean,
    language: VoiceLanguage,
    onStopSpeaking: () -> Unit,
    onLanguageClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(XtraCardDark.copy(alpha = 0.85f))
            .border(1.dp, XtraCardBorder, RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .testTag("telemetry_hud_bar")
    ) {
        // Left: Assistant Architecture badge
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(XtraCyanPrimary)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "XTRA OS",
                color = XtraCyanGlow,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )
        }

        // Center: Interrupt button if speaking, or active language chip
        if (isSpeaking) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(XtraAlertRed.copy(alpha = 0.2f))
                    .border(1.dp, XtraAlertRed.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
                    .clickable(onClick = onStopSpeaking)
                    .padding(horizontal = 10.dp, vertical = 3.dp)
                    .testTag("interrupt_speech_button")
            ) {
                Icon(
                    imageVector = Icons.Default.StopCircle,
                    contentDescription = "Interrupt Voice",
                    tint = XtraAlertRed,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "INTERRUPT",
                    color = XtraAlertRed,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        } else {
            // Language selector button
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(XtraCardBorder)
                    .clickable(onClick = onLanguageClick)
                    .padding(horizontal = 8.dp, vertical = 3.dp)
                    .testTag("language_toggle_chip")
            ) {
                Text(
                    text = language.name,
                    color = XtraTextHigh,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Right: Telemetry (Battery & Network)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = if (deviceStatus.isWifiConnected) Icons.Default.Wifi else Icons.Default.WifiOff,
                contentDescription = "Network",
                tint = if (deviceStatus.isNetworkAvailable) XtraCyanPrimary else XtraTextMed,
                modifier = Modifier.size(15.dp)
            )

            Spacer(modifier = Modifier.width(8.dp))

            Icon(
                imageVector = if (deviceStatus.isCharging) Icons.Default.BatteryChargingFull else Icons.Default.BatteryFull,
                contentDescription = "Battery",
                tint = if (deviceStatus.batteryPercent < 20) XtraAlertRed else XtraNeonGreen,
                modifier = Modifier.size(15.dp)
            )

            Spacer(modifier = Modifier.width(4.dp))

            Text(
                text = "${deviceStatus.batteryPercent}%",
                color = XtraTextHigh,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
