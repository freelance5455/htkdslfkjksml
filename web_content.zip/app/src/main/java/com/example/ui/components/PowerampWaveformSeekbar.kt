package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.ObsidianBg
import kotlin.math.roundToInt

/**
 * Authentic Poweramp Pro-Style Waveform Seekbar.
 * Renders high-density audio waveform peaks with zero-latency responsive scrubbing,
 * electric neon gradient played regions, dynamic playhead needle, and scrub time tooltip.
 */
@Composable
fun PowerampWaveformSeekbar(
    waveformPeaks: List<Float>,
    currentPositionSec: Float,
    durationSec: Int,
    isPlaying: Boolean,
    onSeek: (Float) -> Unit,
    modifier: Modifier = Modifier,
    rmsPulse: Float = 0.5f
) {
    val maxDuration = durationSec.coerceAtLeast(1)
    val rawProgress = (currentPositionSec / maxDuration.toFloat()).coerceIn(0f, 1f)

    var isScrubbing by remember { mutableStateOf(false) }
    var scrubProgress by remember { mutableFloatStateOf(rawProgress) }
    var scrubPixelX by remember { mutableFloatStateOf(0f) }

    val effectiveProgress = if (isScrubbing) scrubProgress else rawProgress

    val peaks = remember(waveformPeaks) {
        if (waveformPeaks.isNotEmpty()) waveformPeaks
        else List(70) { 0.5f }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(60.dp)
            .testTag("poweramp_waveform_seekbar")
    ) {
        Canvas(
            modifier = Modifier
                .matchParentSize()
                .pointerInput(maxDuration) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val canvasW = size.width.toFloat().coerceAtLeast(1f)
                        val touchX = down.position.x.coerceIn(0f, canvasW)
                        isScrubbing = true
                        scrubPixelX = touchX
                        val prog = (touchX / canvasW).coerceIn(0f, 1f)
                        scrubProgress = prog
                        onSeek(prog * maxDuration.toFloat())

                        while (true) {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull() ?: break
                            if (!change.pressed) {
                                isScrubbing = false
                                val finalSec = scrubProgress * maxDuration.toFloat()
                                onSeek(finalSec)
                                break
                            } else {
                                change.consume()
                                val moveX = change.position.x.coerceIn(0f, canvasW)
                                scrubPixelX = moveX
                                val p = (moveX / canvasW).coerceIn(0f, 1f)
                                scrubProgress = p
                                onSeek(p * maxDuration.toFloat())
                            }
                        }
                    }
                }
        ) {
            val canvasW = size.width
            val canvasH = size.height
            val centerY = canvasH / 2f
            val count = peaks.size
            val barSpacing = canvasW / count
            val barWidth = (barSpacing * 0.68f).coerceAtLeast(2.5f)
            val corner = CornerRadius(2.dp.toPx(), 2.dp.toPx())

            val playheadX = (effectiveProgress * canvasW).coerceIn(0f, canvasW)

            // Render all vertical waveform peak bars
            for (i in 0 until count) {
                val barCenterX = i * barSpacing + barSpacing / 2f
                val rawPeak = peaks[i]

                // Dynamic pulse if active and playing
                val isNearbyPlayhead = kotlin.math.abs(barCenterX - playheadX) < 45f
                val pulseMod = if (isPlaying && isNearbyPlayhead) 1.0f + rmsPulse * 0.28f else 1.0f

                val barHeight = ((rawPeak * pulseMod) * (canvasH - 8.dp.toPx())).coerceIn(5.dp.toPx(), canvasH - 4.dp.toPx())
                val topY = centerY - barHeight / 2f

                val isPlayed = barCenterX <= playheadX

                if (isPlayed) {
                    // Played region: Poweramp Pro Electric Neon Gradient
                    drawRoundRect(
                        brush = Brush.verticalGradient(
                            listOf(
                                NeonCyan,
                                NeonPurple,
                                Color(0xFF00E5FF)
                            ),
                            startY = topY,
                            endY = topY + barHeight
                        ),
                        topLeft = Offset(barCenterX - barWidth / 2f, topY),
                        size = Size(barWidth, barHeight),
                        cornerRadius = corner
                    )
                } else {
                    // Unplayed region: Sleek Metallic Obsidian
                    drawRoundRect(
                        brush = Brush.verticalGradient(
                            listOf(
                                Color(0xFF3A4050),
                                Color(0xFF202530)
                            ),
                            startY = topY,
                            endY = topY + barHeight
                        ),
                        topLeft = Offset(barCenterX - barWidth / 2f, topY),
                        size = Size(barWidth, barHeight),
                        cornerRadius = corner
                    )
                }
            }

            // Playhead Subtle Halo Glow
            if (isPlaying) {
                drawCircle(
                    color = NeonCyan.copy(alpha = 0.25f),
                    radius = 12.dp.toPx(),
                    center = Offset(playheadX, centerY)
                )
            }

            // Poweramp Playhead Needle
            drawLine(
                brush = Brush.verticalGradient(listOf(Color.White, NeonCyan, Color.White)),
                start = Offset(playheadX, 0f),
                end = Offset(playheadX, canvasH),
                strokeWidth = 2.5.dp.toPx()
            )

            // Playhead Glowing Pip on Top
            drawCircle(
                color = NeonCyan,
                radius = 4.5.dp.toPx(),
                center = Offset(playheadX, 4.dp.toPx())
            )
            drawCircle(
                color = Color.White,
                radius = 2.dp.toPx(),
                center = Offset(playheadX, 4.dp.toPx())
            )

            // Playhead Glowing Pip on Bottom
            drawCircle(
                color = NeonCyan,
                radius = 4.5.dp.toPx(),
                center = Offset(playheadX, canvasH - 4.dp.toPx())
            )
            drawCircle(
                color = Color.White,
                radius = 2.dp.toPx(),
                center = Offset(playheadX, canvasH - 4.dp.toPx())
            )
        }

        // Floating scrub tooltip
        if (isScrubbing) {
            val scrubSec = (scrubProgress * maxDuration).roundToInt()
            val scrubMin = scrubSec / 60
            val scrubS = scrubSec % 60
            val formatted = "%d:%02d".format(scrubMin, scrubS)

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = ObsidianBg.copy(alpha = 0.95f),
                shadowElevation = 8.dp,
                border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan.copy(alpha = 0.7f)),
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .offset {
                        IntOffset(
                            x = (scrubPixelX - 24.dp.toPx()).roundToInt().coerceIn(0, 1000),
                            y = (-30.dp.toPx()).roundToInt()
                        )
                    }
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(
                    text = formatted,
                    color = NeonCyan,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }
        }
    }
}
