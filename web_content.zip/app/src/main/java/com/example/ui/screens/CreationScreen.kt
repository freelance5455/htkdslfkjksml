package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Photo
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.local.CreationItem
import com.example.ui.AppScreen
import com.example.ui.CreationTab
import com.example.ui.MainViewModel
import com.example.ui.components.SuesaHeader
import com.example.ui.theme.AccentError
import com.example.ui.theme.AccentSuccess
import com.example.ui.theme.PurpleDark
import com.example.ui.theme.PurpleLight
import com.example.ui.theme.PurplePrimary
import com.example.ui.theme.SuesaBackground
import com.example.ui.theme.SuesaCardBorder
import com.example.ui.theme.SuesaSurface
import com.example.ui.theme.SuesaSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.util.FileUtils

@Composable
fun CreationScreen(
    viewModel: MainViewModel,
    onOpenDrawer: () -> Unit,
    onBackToChat: () -> Unit
) {
    BackHandler {
        onBackToChat()
    }

    val context = LocalContext.current
    val currentTab by viewModel.creationTab.collectAsStateWithLifecycle()
    val isCreating by viewModel.isCreatingMedia.collectAsStateWithLifecycle()
    val statusText by viewModel.creationStatusText.collectAsStateWithLifecycle()
    val errorMessage by viewModel.creationErrorMessage.collectAsStateWithLifecycle()
    val latestCreation by viewModel.latestCreation.collectAsStateWithLifecycle()
    val allCreations by viewModel.allCreations.collectAsStateWithLifecycle()

    // Image Tab States
    val imagePrompt by viewModel.imagePrompt.collectAsStateWithLifecycle()
    val imageInputUri by viewModel.imageInputUri.collectAsStateWithLifecycle()
    val imageAspectRatio by viewModel.imageAspectRatio.collectAsStateWithLifecycle()
    val imageStyle by viewModel.imageStyle.collectAsStateWithLifecycle()

    // Video Tab States
    val videoPrompt by viewModel.videoPrompt.collectAsStateWithLifecycle()
    val videoInputUri by viewModel.videoInputUri.collectAsStateWithLifecycle()
    val videoAspectRatio by viewModel.videoAspectRatio.collectAsStateWithLifecycle()

    // Image Picker for Image Input
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            viewModel.imageInputUri.value = uri
        }
    }

    // Image Picker for Video Input
    val videoImagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            viewModel.videoInputUri.value = uri
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SuesaBackground)
            .statusBarsPadding()
    ) {
        // Header
        SuesaHeader(
            title = "Oluştur",
            onMenuClick = onOpenDrawer
        )

        // Tab Selector [ 🖼️ Görsel ] [ 🎬 Video ]
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(SuesaSurface)
                .border(1.dp, SuesaCardBorder, RoundedCornerShape(16.dp))
                .padding(4.dp)
        ) {
            // Görsel Tab
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (currentTab == CreationTab.IMAGE) {
                            Brush.linearGradient(listOf(PurpleDark, PurplePrimary))
                        } else {
                            SolidColor(Color.Transparent)
                        }
                    )
                    .clickable { viewModel.creationTab.value = CreationTab.IMAGE }
                    .padding(vertical = 10.dp)
                    .testTag("tab_image_button"),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Photo,
                        contentDescription = "Görsel",
                        tint = if (currentTab == CreationTab.IMAGE) Color.White else TextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Görsel",
                        color = if (currentTab == CreationTab.IMAGE) Color.White else TextSecondary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // Video Tab
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (currentTab == CreationTab.VIDEO) {
                            Brush.linearGradient(listOf(PurpleDark, PurplePrimary))
                        } else {
                            SolidColor(Color.Transparent)
                        }
                    )
                    .clickable { viewModel.creationTab.value = CreationTab.VIDEO }
                    .padding(vertical = 10.dp)
                    .testTag("tab_video_button"),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Movie,
                        contentDescription = "Video",
                        tint = if (currentTab == CreationTab.VIDEO) Color.White else TextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Video",
                        color = if (currentTab == CreationTab.VIDEO) Color.White else TextSecondary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // Error message if any
        AnimatedVisibility(
            visible = errorMessage != null,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            if (errorMessage != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF2A1515))
                        .border(1.dp, AccentError.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.ErrorOutline,
                        contentDescription = "Hata",
                        tint = AccentError,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = errorMessage ?: "",
                        color = Color(0xFFFFD4D4),
                        fontSize = 13.sp,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = { viewModel.creationErrorMessage.value = null },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Kapat",
                            tint = AccentError,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        // Scrollable content
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (currentTab == CreationTab.IMAGE) {
                // ==================== IMAGE CREATION SECTION ====================
                Text(
                    text = "Yapay Zekâ ile Görsel Oluştur",
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                // Prompt Input
                OutlinedTextField(
                    value = imagePrompt,
                    onValueChange = { viewModel.imagePrompt.value = it },
                    placeholder = {
                        Text(
                            text = "Örnek: Anime tarzında, gece vakti neon ışıklı bir şehirde yürüyen beyaz saçlı bir karakter...",
                            color = TextMuted,
                            fontSize = 14.sp
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(SuesaSurface)
                        .testTag("image_prompt_input"),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = SuesaSurface,
                        unfocusedContainerColor = SuesaSurface,
                        focusedIndicatorColor = PurplePrimary,
                        unfocusedIndicatorColor = SuesaCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    shape = RoundedCornerShape(14.dp)
                )

                // Optional Input Image (Image-to-Image / Transformation)
                Text(
                    text = "Fotoğraf Yükle ve Dönüştür (İsteğe Bağlı)",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )

                if (imageInputUri == null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(SuesaSurface)
                            .border(1.dp, SuesaCardBorder, RoundedCornerShape(14.dp))
                            .clickable {
                                imagePickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            }
                            .padding(16.dp)
                            .testTag("upload_image_to_modify_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AddPhotoAlternate,
                                contentDescription = "Fotoğraf Seç",
                                tint = PurpleLight,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Bir fotoğraf seçip düzenle",
                                color = TextPrimary,
                                fontSize = 14.sp
                            )
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(SuesaSurface)
                            .border(1.dp, SuesaCardBorder, RoundedCornerShape(14.dp))
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(
                            model = imageInputUri,
                            contentDescription = "Düzenlenecek Görsel",
                            modifier = Modifier
                                .size(60.dp)
                                .clip(RoundedCornerShape(8.dp)),
                            contentScale = ContentScale.Crop
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Referans fotoğraf yüklendi",
                                color = TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "İsteminize göre bu fotoğraf dönüştürülecektir.",
                                color = TextMuted,
                                fontSize = 11.sp
                            )
                        }
                        IconButton(
                            onClick = { viewModel.imageInputUri.value = null },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Kaldır",
                                tint = AccentError,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                // Style Presets
                Text(
                    text = "Tarz Seçimi",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )

                val styles = listOf("Varsayılan", "Anime", "Gerçekçi", "Cyberpunk", "3D Render", "Yağlı Boya", "Piksel Sanatı")
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    for (style in styles) {
                        val isSelected = imageStyle == style
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) PurpleDark else SuesaSurface)
                                .border(
                                    1.dp,
                                    if (isSelected) PurplePrimary else SuesaCardBorder,
                                    RoundedCornerShape(10.dp)
                                )
                                .clickable { viewModel.imageStyle.value = style }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = style,
                                color = if (isSelected) Color.White else TextSecondary,
                                fontSize = 13.sp,
                                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                            )
                        }
                    }
                }

                // Aspect Ratio Selector
                Text(
                    text = "En Boy Oranı",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )

                val ratios = listOf("1:1", "16:9", "9:16", "4:3")
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    for (ratio in ratios) {
                        val isSelected = imageAspectRatio == ratio
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) PurpleDark else SuesaSurface)
                                .border(
                                    1.dp,
                                    if (isSelected) PurplePrimary else SuesaCardBorder,
                                    RoundedCornerShape(10.dp)
                                )
                                .clickable { viewModel.imageAspectRatio.value = ratio }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = ratio,
                                color = if (isSelected) Color.White else TextSecondary,
                                fontSize = 13.sp,
                                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                            )
                        }
                    }
                }

                // Generate Button
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            if (!isCreating) {
                                Brush.linearGradient(listOf(PurpleDark, PurplePrimary))
                            } else {
                                Brush.linearGradient(listOf(Color(0xFF333333), Color(0xFF222222)))
                            }
                        )
                        .clickable(enabled = !isCreating) {
                            viewModel.generateImage()
                        }
                        .padding(vertical = 14.dp)
                        .testTag("submit_generate_image_button"),
                    contentAlignment = Alignment.Center
                ) {
                    if (isCreating) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = PurpleLight,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Görsel Hazırlanıyor...",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "Görsel Oluştur",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Görsel Oluştur",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

            } else {
                // ==================== VIDEO CREATION SECTION ====================
                Text(
                    text = "Yapay Zekâ ile Video Oluştur",
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                // Video Prompt Input
                OutlinedTextField(
                    value = videoPrompt,
                    onValueChange = { viewModel.videoPrompt.value = it },
                    placeholder = {
                        Text(
                            text = "Örnek: Bu karakter kameraya doğru yürüsün, saçları rüzgârda hareket etsin ve arka planda şehir ışıkları olsun...",
                            color = TextMuted,
                            fontSize = 14.sp
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(SuesaSurface)
                        .testTag("video_prompt_input"),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = SuesaSurface,
                        unfocusedContainerColor = SuesaSurface,
                        focusedIndicatorColor = PurplePrimary,
                        unfocusedIndicatorColor = SuesaCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    shape = RoundedCornerShape(14.dp)
                )

                // Görselden Video için Referans Görsel
                Text(
                    text = "Görselden Video: Başlangıç Görseli Ekle (İsteğe Bağlı)",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )

                if (videoInputUri == null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(SuesaSurface)
                            .border(1.dp, SuesaCardBorder, RoundedCornerShape(14.dp))
                            .clickable {
                                videoImagePickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            }
                            .padding(16.dp)
                            .testTag("upload_video_source_image_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AddPhotoAlternate,
                                contentDescription = "Fotoğraf Seç",
                                tint = PurpleLight,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Videoya dönüştürülecek bir görsel yükle",
                                color = TextPrimary,
                                fontSize = 14.sp
                            )
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(SuesaSurface)
                            .border(1.dp, SuesaCardBorder, RoundedCornerShape(14.dp))
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(
                            model = videoInputUri,
                            contentDescription = "Video Görseli",
                            modifier = Modifier
                                .size(60.dp)
                                .clip(RoundedCornerShape(8.dp)),
                            contentScale = ContentScale.Crop
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Başlangıç karesi seçildi",
                                color = TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Yapay zekâ bu görseli canlandıracaktır.",
                                color = TextMuted,
                                fontSize = 11.sp
                            )
                        }
                        IconButton(
                            onClick = { viewModel.videoInputUri.value = null },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Kaldır",
                                tint = AccentError,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }

                // Video Aspect Ratio
                Text(
                    text = "Video Oranı",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )

                val videoRatios = listOf("16:9", "9:16", "1:1")
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    for (ratio in videoRatios) {
                        val isSelected = videoAspectRatio == ratio
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) PurpleDark else SuesaSurface)
                                .border(
                                    1.dp,
                                    if (isSelected) PurplePrimary else SuesaCardBorder,
                                    RoundedCornerShape(10.dp)
                                )
                                .clickable { viewModel.videoAspectRatio.value = ratio }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = ratio,
                                color = if (isSelected) Color.White else TextSecondary,
                                fontSize = 13.sp,
                                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                            )
                        }
                    }
                }

                // Generate Video Button
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            if (!isCreating) {
                                Brush.linearGradient(listOf(PurpleDark, PurplePrimary))
                            } else {
                                Brush.linearGradient(listOf(Color(0xFF333333), Color(0xFF222222)))
                            }
                        )
                        .clickable(enabled = !isCreating) {
                            viewModel.generateVideo()
                        }
                        .padding(vertical = 14.dp)
                        .testTag("submit_generate_video_button"),
                    contentAlignment = Alignment.Center
                ) {
                    if (isCreating) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(24.dp),
                                color = PurpleLight,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = statusText.ifEmpty { "Video hazırlanıyor, bu işlem biraz zaman alabilir..." },
                                color = Color.White,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 16.dp)
                            )
                        }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Movie,
                                contentDescription = "Video Oluştur",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Video Oluştur",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // ==================== LATEST CREATED RESULT PREVIEW ====================
            if (latestCreation != null) {
                val item = latestCreation!!
                Text(
                    text = "Oluşturulan Son İçerik",
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(SuesaSurface)
                        .border(1.dp, SuesaCardBorder, RoundedCornerShape(16.dp))
                        .padding(12.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        // Media container
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.Black),
                            contentAlignment = Alignment.Center
                        ) {
                            AsyncImage(
                                model = item.mediaUri,
                                contentDescription = "Oluşturulan Medya",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Fit
                            )

                            if (item.type == "video") {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(CircleShape)
                                        .background(Color(0x88000000)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PlayArrow,
                                        contentDescription = "Oynat",
                                        tint = Color.White,
                                        modifier = Modifier.size(32.dp)
                                    )
                                }
                            }
                        }

                        Text(
                            text = item.prompt,
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 2
                        )

                        // Action Buttons: Save to Device, Share, New
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Save Button
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(SuesaSurfaceVariant)
                                    .border(1.dp, SuesaCardBorder, RoundedCornerShape(10.dp))
                                    .clickable {
                                        viewModel.saveCreationToGallery(item) { success, msg ->
                                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                    .padding(vertical = 10.dp)
                                    .testTag("save_creation_button"),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Download,
                                        contentDescription = "Kaydet",
                                        tint = PurpleLight,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Kaydet",
                                        color = TextPrimary,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            // Share Button
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(SuesaSurfaceVariant)
                                    .border(1.dp, SuesaCardBorder, RoundedCornerShape(10.dp))
                                    .clickable {
                                        try {
                                            val uri = Uri.parse(item.mediaUri)
                                            FileUtils.shareImage(context, uri)
                                        } catch (e: Exception) {
                                            Toast.makeText(context, "Paylaşılamadı: ${e.message}", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                    .padding(vertical = 10.dp)
                                    .testTag("share_creation_button"),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Share,
                                        contentDescription = "Paylaş",
                                        tint = PurpleLight,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Paylaş",
                                        color = TextPrimary,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // ==================== OLUŞTURMA GEÇMİŞİ (HISTORY GALLERY) ====================
            if (allCreations.isNotEmpty()) {
                Text(
                    text = "Oluşturma Geçmişi",
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(allCreations, key = { it.id }) { item ->
                        CreationHistoryCard(
                            item = item,
                            onClick = {
                                viewModel.latestCreation.value = item
                            },
                            onDelete = {
                                viewModel.deleteCreation(item.id)
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
fun CreationHistoryCard(
    item: CreationItem,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    Box(
        modifier = Modifier
            .width(130.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(SuesaSurface)
            .border(1.dp, SuesaCardBorder, RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(8.dp)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = item.mediaUri,
                    contentDescription = item.prompt,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )

                if (item.type == "video") {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Video",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = item.prompt,
                color = TextSecondary,
                fontSize = 11.sp,
                maxLines = 1
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (item.type == "video") "🎬 Video" else "🖼️ Görsel",
                    color = PurpleLight,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.size(22.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Sil",
                        tint = TextMuted,
                        modifier = Modifier.size(13.dp)
                    )
                }
            }
        }
    }
}
