package com.example.ui.theme

import androidx.annotation.DrawableRes
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.AppSettingsEntity

data class ThemeDefinition(
    val key: String,
    val displayName: String,
    val description: String,
    @DrawableRes val motifResId: Int,
    val isDark: Boolean,
    val colorScheme: ColorScheme,
    val fontFamily: FontFamily = FontFamily.Default,
    val cardShape: RoundedCornerShape = RoundedCornerShape(16.dp),
    val previewHighlight: Color,
    val previewBadgeBg: Color
) {
    val typography: Typography
        get() = if (fontFamily == FontFamily.Serif) {
            createSerifTypography()
        } else {
            Typography
        }
}

private fun createSerifTypography(): Typography {
    return Typography(
        displayLarge = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Normal, fontSize = 57.sp, lineHeight = 64.sp),
        displayMedium = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Normal, fontSize = 45.sp, lineHeight = 52.sp),
        displaySmall = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Normal, fontSize = 36.sp, lineHeight = 44.sp),
        headlineLarge = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Normal, fontSize = 32.sp, lineHeight = 40.sp),
        headlineMedium = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Normal, fontSize = 28.sp, lineHeight = 36.sp),
        headlineSmall = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Normal, fontSize = 24.sp, lineHeight = 32.sp),
        titleLarge = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold, fontSize = 22.sp, lineHeight = 28.sp),
        titleMedium = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 24.sp),
        titleSmall = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 20.sp),
        bodyLarge = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 24.sp, letterSpacing = 0.5.sp),
        bodyMedium = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 20.sp, letterSpacing = 0.25.sp),
        bodySmall = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 16.sp, letterSpacing = 0.4.sp),
        labelLarge = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 20.sp),
        labelMedium = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 16.sp),
        labelSmall = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 16.sp)
    )
}

// 1. Normal (Default Light)
private val NormalScheme = lightColorScheme(
    primary = Color(0xFF2563EB),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFDBEAFE),
    onPrimaryContainer = Color(0xFF1E3A8A),
    secondary = Color(0xFF0D9488),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFCCFBF1),
    onSecondaryContainer = Color(0xFF134E4A),
    background = Color(0xFFF8FAFC),
    onBackground = Color(0xFF0F172A),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = Color(0xFF475569),
    outline = Color(0xFFCBD5E1),
    error = Color(0xFFDC2626),
    errorContainer = Color(0xFFFEE2E2)
)

// 2. Dark
private val DarkScheme = darkColorScheme(
    primary = Color(0xFF60A5FA),
    onPrimary = Color(0xFF0B1B3A),
    primaryContainer = Color(0xFF1D4ED8),
    onPrimaryContainer = Color(0xFFEFF6FF),
    secondary = Color(0xFF2DD4BF),
    onSecondary = Color(0xFF042F2E),
    secondaryContainer = Color(0xFF0F766E),
    onSecondaryContainer = Color(0xFFF0FDFA),
    background = Color(0xFF0B0F19),
    onBackground = Color(0xFFF1F5F9),
    surface = Color(0xFF131B2E),
    onSurface = Color(0xFFF1F5F9),
    surfaceVariant = Color(0xFF1E293B),
    onSurfaceVariant = Color(0xFF94A3B8),
    outline = Color(0xFF334155),
    error = Color(0xFFDC2626),
    errorContainer = Color(0xFF7F1D1D)
)

// 3. Book: paper-like warm tones, serif accents
private val BookScheme = lightColorScheme(
    primary = Color(0xFF78350F),           // Warm vintage leather amber
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFFEF3C7),  // Warm cream parchment
    onPrimaryContainer = Color(0xFF451A03),
    secondary = Color(0xFFB45309),         // Warm ochre bookmark
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFFDE68A),
    onSecondaryContainer = Color(0xFF78350F),
    background = Color(0xFFFBF7EE),        // Real book paper ivory
    onBackground = Color(0xFF292524),      // Deep sepia charcoal (high contrast)
    surface = Color(0xFFF5EEDB),           // Soft pressed parchment
    onSurface = Color(0xFF292524),
    surfaceVariant = Color(0xFFEADFC9),    // Warm paper shadow
    onSurfaceVariant = Color(0xFF57534E),
    outline = Color(0xFFD6C5A0),
    error = Color(0xFFB91C1C),
    errorContainer = Color(0xFFFEE2E2)
)

// 4. School Bag: playful colours, backpack and stationery motifs
private val SchoolBagScheme = lightColorScheme(
    primary = Color(0xFFEA580C),           // Backpack orange
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFFFEDD5),
    onPrimaryContainer = Color(0xFF7C2D12),
    secondary = Color(0xFF0284C7),         // Notebook ruler cyan
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFE0F2FE),
    onSecondaryContainer = Color(0xFF0369A1),
    background = Color(0xFFFFFBEB),        // Playful stationery light yellow
    onBackground = Color(0xFF1E293B),      // Slate pencil text
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1E293B),
    surfaceVariant = Color(0xFFFEF3C7),
    onSurfaceVariant = Color(0xFF475569),
    outline = Color(0xFFFCD34D),
    error = Color(0xFFDC2626),
    errorContainer = Color(0xFFFEE2E2)
)

// 5. Flowers: soft pastel palette, floral accents
private val FlowersScheme = lightColorScheme(
    primary = Color(0xFFDB2777),           // Petal blossom rose
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFFCE7F3),
    onPrimaryContainer = Color(0xFF831843),
    secondary = Color(0xFF059669),         // Botanical garden emerald
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFD1FAE5),
    onSecondaryContainer = Color(0xFF065F46),
    background = Color(0xFFFDF8F9),        // Soft pastel ivory
    onBackground = Color(0xFF1F2937),      // Deep charcoal (crisp readability)
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1F2937),
    surfaceVariant = Color(0xFFFCE7F3),
    onSurfaceVariant = Color(0xFF4B5563),
    outline = Color(0xFFFBCFE8),
    error = Color(0xFFDC2626),
    errorContainer = Color(0xFFFEE2E2)
)

// 6. Naruto: original artwork inspired by the orange and blue style (NO official characters, logos, or licensed assets)
private val NarutoScheme = lightColorScheme(
    primary = Color(0xFFF97316),           // Vibrant fiery orange
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFFFEDD5),
    onPrimaryContainer = Color(0xFF9A3412),
    secondary = Color(0xFF2563EB),         // Dynamic chakra blue
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFDBEAFE),
    onSecondaryContainer = Color(0xFF1E40AF),
    background = Color(0xFFFFF7ED),        // Sunburst warm canvas
    onBackground = Color(0xFF1C1917),      // Deep stone ink
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1C1917),
    surfaceVariant = Color(0xFFFED7AA),
    onSurfaceVariant = Color(0xFF431407),
    outline = Color(0xFFFB923C),
    error = Color(0xFFDC2626),
    errorContainer = Color(0xFFFEE2E2)
)

// 7. Jujutsu Kaisen: original artwork inspired by a dark, cursed-energy look with navy and black, electric blue, and violet accents (NO official characters, logos, or licensed assets)
private val JujutsuKaisenScheme = darkColorScheme(
    primary = Color(0xFF06B6D4),           // Electric cyan cursed energy flare
    onPrimary = Color(0xFF082F49),
    primaryContainer = Color(0xFF083344),
    onPrimaryContainer = Color(0xFFA5F3FC),
    secondary = Color(0xFFA855F7),         // Mystical talisman violet
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFF3B0764),
    onSecondaryContainer = Color(0xFFE9D5FF),
    background = Color(0xFF070A12),        // Deep cursed void black/navy
    onBackground = Color(0xFFF8FAFC),      // Brilliant high-contrast text
    surface = Color(0xFF0E1424),           // Navy shadow surface
    onSurface = Color(0xFFF8FAFC),
    surfaceVariant = Color(0xFF172038),
    onSurfaceVariant = Color(0xFF94A3B8),
    outline = Color(0xFF38BDF8),
    error = Color(0xFFEF4444),
    errorContainer = Color(0xFF7F1D1D)
)

// 8. Forest: greens and earthy tones
private val ForestScheme = lightColorScheme(
    primary = Color(0xFF15803D),           // Evergreen canopy pine
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFDCFCE7),
    onPrimaryContainer = Color(0xFF14532D),
    secondary = Color(0xFFB45309),         // Earthy wood amber
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFFEF3C7),
    onSecondaryContainer = Color(0xFF78350F),
    background = Color(0xFFF4F7F4),        // Soft woodland moss
    onBackground = Color(0xFF14291B),      // Deep forest black-green
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF14291B),
    surfaceVariant = Color(0xFFE2ECE3),
    onSurfaceVariant = Color(0xFF2D4A35),
    outline = Color(0xFF86EFAC),
    error = Color(0xFFDC2626),
    errorContainer = Color(0xFFFEE2E2)
)

object AppThemes {
    val allThemes: List<ThemeDefinition> = listOf(
        ThemeDefinition(
            key = AppSettingsEntity.THEME_NORMAL,
            displayName = "Normal (Default)",
            description = "Clean, focused academic indigo & neutral palette for daytime study",
            motifResId = R.drawable.ic_motif_normal,
            isDark = false,
            colorScheme = NormalScheme,
            fontFamily = FontFamily.Default,
            cardShape = RoundedCornerShape(16.dp),
            previewHighlight = Color(0xFF2563EB),
            previewBadgeBg = Color(0xFFDBEAFE)
        ),
        ThemeDefinition(
            key = AppSettingsEntity.THEME_DARK,
            displayName = "Dark",
            description = "Midnight obsidian palette with high-contrast text for night study",
            motifResId = R.drawable.ic_motif_dark,
            isDark = true,
            colorScheme = DarkScheme,
            fontFamily = FontFamily.Default,
            cardShape = RoundedCornerShape(16.dp),
            previewHighlight = Color(0xFF60A5FA),
            previewBadgeBg = Color(0xFF1D4ED8)
        ),
        ThemeDefinition(
            key = AppSettingsEntity.THEME_BOOK,
            displayName = "Book",
            description = "Warm paper-like parchment tones with elegant serif typography accents",
            motifResId = R.drawable.ic_motif_book,
            isDark = false,
            colorScheme = BookScheme,
            fontFamily = FontFamily.Serif,
            cardShape = RoundedCornerShape(10.dp), // Book-like sharper corners
            previewHighlight = Color(0xFF78350F),
            previewBadgeBg = Color(0xFFFEF3C7)
        ),
        ThemeDefinition(
            key = AppSettingsEntity.THEME_SCHOOL_BAG,
            displayName = "School Bag",
            description = "Playful colours, backpack orange & ruler blue stationery accents",
            motifResId = R.drawable.ic_motif_schoolbag,
            isDark = false,
            colorScheme = SchoolBagScheme,
            fontFamily = FontFamily.Default,
            cardShape = RoundedCornerShape(20.dp), // Playful rounded corners
            previewHighlight = Color(0xFFEA580C),
            previewBadgeBg = Color(0xFFFFEDD5)
        ),
        ThemeDefinition(
            key = AppSettingsEntity.THEME_FLOWERS,
            displayName = "Flowers",
            description = "Soft pastel rose & garden emerald palette with botanical accents",
            motifResId = R.drawable.ic_motif_flowers,
            isDark = false,
            colorScheme = FlowersScheme,
            fontFamily = FontFamily.Default,
            cardShape = RoundedCornerShape(18.dp),
            previewHighlight = Color(0xFFDB2777),
            previewBadgeBg = Color(0xFFFCE7F3)
        ),
        ThemeDefinition(
            key = AppSettingsEntity.THEME_NARUTO,
            displayName = "Shinobi (Orange & Blue)",
            description = "High-energy flame orange & cobalt blue original anime-inspired artwork",
            motifResId = R.drawable.ic_motif_naruto,
            isDark = false,
            colorScheme = NarutoScheme,
            fontFamily = FontFamily.Default,
            cardShape = RoundedCornerShape(12.dp),
            previewHighlight = Color(0xFFF97316),
            previewBadgeBg = Color(0xFFFFEDD5)
        ),
        ThemeDefinition(
            key = AppSettingsEntity.THEME_JUJUTSU_KAISEN,
            displayName = "Cursed Energy (Navy & Cyan)",
            description = "Dark mystical void with electric cyan aura & violet energy accents",
            motifResId = R.drawable.ic_motif_cursed,
            isDark = true,
            colorScheme = JujutsuKaisenScheme,
            fontFamily = FontFamily.Default,
            cardShape = RoundedCornerShape(14.dp),
            previewHighlight = Color(0xFF06B6D4),
            previewBadgeBg = Color(0xFF083344)
        ),
        ThemeDefinition(
            key = AppSettingsEntity.THEME_FOREST,
            displayName = "Forest",
            description = "Tranquil evergreen pine, earthy wood amber & woodland moss tones",
            motifResId = R.drawable.ic_motif_forest,
            isDark = false,
            colorScheme = ForestScheme,
            fontFamily = FontFamily.Default,
            cardShape = RoundedCornerShape(16.dp),
            previewHighlight = Color(0xFF15803D),
            previewBadgeBg = Color(0xFFDCFCE7)
        )
    )

    fun getTheme(key: String): ThemeDefinition {
        return allThemes.find { it.key == key } ?: allThemes.first()
    }
}
