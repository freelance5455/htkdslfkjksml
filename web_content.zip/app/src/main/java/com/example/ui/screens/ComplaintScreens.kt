@file:OptIn(ExperimentalMaterial3Api::class)
package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Complaint
import com.example.data.repository.CollegeRepository
import com.example.ui.theme.*
import com.example.ui.viewmodel.CollegeViewModel
import com.example.ui.viewmodel.Screen

// --------------------------------------------------------------------------------
// SECTION 5: COMPLAINT REGISTRATION
// --------------------------------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ComplaintRegistrationScreen(viewModel: CollegeViewModel) {
    val context = LocalContext.current
    var studentName by remember { mutableStateOf("") }
    var mobileNumber by remember { mutableStateOf("") }
    var selectedBatch by remember { mutableStateOf(CollegeRepository.BATCHES[1]) }
    var description by remember { mutableStateOf("") }
    var isSubmitting by remember { mutableStateOf(false) }

    var generatedTrackingCode by remember { mutableStateOf<String?>(null) }
    var showSuccessDialog by remember { mutableStateOf(false) }

    var batchExpanded by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFEF3C7)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.ReportProblem,
                                contentDescription = null,
                                tint = Color(0xFFD97706)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Student Grievance Cell (शिकायत निवारण)",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "GNMTC SGNR Proctorial Board",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )
                            )
                        }
                    }

                    HorizontalDivider()

                    // Student Name
                    OutlinedTextField(
                        value = studentName,
                        onValueChange = { studentName = it },
                        label = { Text("Student Full Name *") },
                        placeholder = { Text("e.g. Amanpreet Kaur") },
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Mobile Number
                    OutlinedTextField(
                        value = mobileNumber,
                        onValueChange = { mobileNumber = it },
                        label = { Text("Contact Mobile Number *") },
                        placeholder = { Text("e.g. 9828111223") },
                        leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Batch Dropdown Selection
                    ExposedDropdownMenuBox(
                        expanded = batchExpanded,
                        onExpandedChange = { batchExpanded = !batchExpanded }
                    ) {
                        OutlinedTextField(
                            value = selectedBatch,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Batch Selection *") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = batchExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = batchExpanded,
                            onDismissRequest = { batchExpanded = false }
                        ) {
                            CollegeRepository.BATCHES.forEach { batchItem ->
                                DropdownMenuItem(
                                    text = { Text(batchItem) },
                                    onClick = {
                                        selectedBatch = batchItem
                                        batchExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Complaint Description
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("Grievance Description *") },
                        placeholder = { Text("Describe the academic, hostel, clinical, or administrative issue in detail...") },
                        minLines = 4,
                        maxLines = 8,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text(
                        text = "Note: Upon submission, a confidential 4-digit code will be generated to track resolution progress.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )

                    Button(
                        onClick = {
                            if (studentName.isNotBlank() && mobileNumber.isNotBlank() && description.isNotBlank()) {
                                isSubmitting = true
                                viewModel.submitComplaint(
                                    studentName = studentName,
                                    mobileNumber = mobileNumber,
                                    batch = selectedBatch,
                                    description = description,
                                    onSuccess = { code ->
                                        isSubmitting = false
                                        generatedTrackingCode = code
                                        showSuccessDialog = true
                                    },
                                    onError = {
                                        isSubmitting = false
                                        Toast.makeText(context, "Error: $it", Toast.LENGTH_SHORT).show()
                                    }
                                )
                            }
                        },
                        enabled = !isSubmitting && studentName.isNotBlank() && mobileNumber.isNotBlank() && description.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = NursingGreenPrimary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                    ) {
                        if (isSubmitting) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Default.Send, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Submit Grievance (शिकायत दर्ज करें)")
                        }
                    }
                }
            }
        }
    }

    // Success Confirmation Dialog with 4-Digit Code
    if (showSuccessDialog && generatedTrackingCode != null) {
        AlertDialog(
            onDismissRequest = {
                showSuccessDialog = false
                viewModel.navigateTo(Screen.ComplaintStatus)
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = NursingGreenPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Grievance Registered", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Your grievance has been successfully recorded in the GNMTC SGNR Proctorial database.",
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "YOUR 4-DIGIT TRACKING CODE",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = NursingGreenContainer,
                        modifier = Modifier.padding(vertical = 4.dp)
                    ) {
                        Text(
                            text = generatedTrackingCode ?: "",
                            style = MaterialTheme.typography.displaySmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = NursingGreenPrimary,
                                letterSpacing = 8.sp
                            ),
                            modifier = Modifier.padding(horizontal = 24.dp, vertical = 10.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("GNMTC Complaint Code", generatedTrackingCode)
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, "Code copied to clipboard!", Toast.LENGTH_SHORT).show()
                        }
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Copy Tracking Code")
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSuccessDialog = false
                        viewModel.lookupComplaint(generatedTrackingCode ?: "")
                        viewModel.navigateTo(Screen.ComplaintStatus)
                    }
                ) {
                    Text("Track Status Now")
                }
            }
        )
    }
}

// --------------------------------------------------------------------------------
// SECTION 6: COMPLAINT STATUS LOOKUP
// --------------------------------------------------------------------------------
@Composable
fun ComplaintStatusScreen(viewModel: CollegeViewModel) {
    var codeInput by remember { mutableStateOf("") }
    val trackedComplaint by viewModel.trackedComplaint.collectAsState()
    val isLookingUp by viewModel.isLookingUpComplaint.collectAsState()
    val lookupError by viewModel.complaintLookupError.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Search Input Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Text(
                        text = "Check Grievance Status (स्थिति जांचें)",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Enter your confidential 4-digit code provided during registration.",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = codeInput,
                            onValueChange = {
                                if (it.length <= 4) codeInput = it
                            },
                            label = { Text("4-Digit Code (e.g. 1024)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Button(
                            onClick = { viewModel.lookupComplaint(codeInput) },
                            enabled = codeInput.length == 4 && !isLookingUp,
                            colors = ButtonDefaults.buttonColors(containerColor = ClinicalBlueSecondary),
                            modifier = Modifier.height(54.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            if (isLookingUp) {
                                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                            } else {
                                Icon(Icons.Default.Search, contentDescription = null)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Check")
                            }
                        }
                    }

                    lookupError?.let { err ->
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = err,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        }

        // Result Status Card
        trackedComplaint?.let { complaint ->
            item {
                StatusDetailsCard(complaint)
            }
        }

        // Quick tip info
        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Grievance Resolution Lifecycle:",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "1. Received -> 2. Under Review -> 3. In Progress -> 4. Resolved / Rejected",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)),
                        modifier = Modifier.padding(top = 2.dp)
                    )
                    Text(
                        text = "Sensitive student identities and bank numbers are never displayed in public tracking searches.",
                        style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)),
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun StatusDetailsCard(complaint: Complaint) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Complaint Ref #${complaint.trackingCode}",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Batch: ${complaint.batch}",
                        style = MaterialTheme.typography.bodySmall.copy(color = ClinicalBlueSecondary)
                    )
                }

                // Current Status Badge
                val (badgeBg, badgeFg) = when (complaint.status) {
                    "Received" -> Pair(Color(0xFFDBEAFE), StatusReceivedColor)
                    "Under Review" -> Pair(Color(0xFFFEF3C7), StatusUnderReviewColor)
                    "In Progress" -> Pair(Color(0xFFEDE9FE), StatusInProgressColor)
                    "Resolved" -> Pair(NursingGreenContainer, StatusResolvedColor)
                    else -> Pair(Color(0xFFFFE4E6), StatusRejectedColor)
                }
                Badge(containerColor = badgeBg, contentColor = badgeFg) {
                    Text(
                        text = complaint.status,
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                }
            }

            HorizontalDivider()

            // Timeline Steps
            StatusTimeline(currentStatus = complaint.status)

            HorizontalDivider()

            Text(
                text = "Grievance Description (Summary):",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
            )
            Text(
                text = complaint.description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
            )

            if (complaint.resolutionNote.isNotBlank()) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = NursingGreenContainer.copy(alpha = 0.7f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "Official Action / Resolution Note:",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = NursingGreenPrimary
                            )
                        )
                        Text(
                            text = complaint.resolutionNote,
                            style = MaterialTheme.typography.bodySmall.copy(color = NursingGreenOnContainer),
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Submitted: ${complaint.createdAtDate}",
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.5.sp),
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
                Text(
                    text = "Updated: ${complaint.updatedAtDate}",
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.5.sp),
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
            }
        }
    }
}

@Composable
fun StatusTimeline(currentStatus: String) {
    val statuses = listOf("Received", "Under Review", "In Progress", "Resolved")
    val currentIndex = when (currentStatus) {
        "Received" -> 0
        "Under Review" -> 1
        "In Progress" -> 2
        "Resolved" -> 3
        else -> 3
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        statuses.forEachIndexed { index, step ->
            val isDone = index <= currentIndex
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(if (isDone) NursingGreenPrimary else MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    if (isDone) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                    } else {
                        Text("${index + 1}", style = MaterialTheme.typography.labelSmall)
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = step,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 10.sp,
                        fontWeight = if (isDone) FontWeight.Bold else FontWeight.Normal,
                        color = if (isDone) NursingGreenPrimary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                )
            }
        }
    }
}
