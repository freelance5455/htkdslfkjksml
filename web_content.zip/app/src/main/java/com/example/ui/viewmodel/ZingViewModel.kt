package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.CommentEntity
import com.example.data.local.NotificationEntity
import com.example.data.local.PayoutEntity
import com.example.data.local.ReportEntity
import com.example.data.local.UserEntity
import com.example.data.local.VideoEntity
import com.example.data.local.ZingDatabase
import com.example.data.local.ZingRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class ZingNavTab {
    FEED,
    DISCOVER,
    UPLOAD,
    NOTIFICATIONS,
    PROFILE,
    CREATOR_STUDIO,
    ADMIN,
    WEB_FRONTEND
}

class ZingViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ZingRepository
    init {
        val db = ZingDatabase.getDatabase(application)
        repository = ZingRepository(db.zingDao())
    }

    // Active Navigation
    private val _currentNavTab = MutableStateFlow(ZingNavTab.FEED)
    val currentNavTab: StateFlow<ZingNavTab> = _currentNavTab.asStateFlow()

    fun setNavTab(tab: ZingNavTab) {
        _currentNavTab.value = tab
    }

    // Users and Current Logged In User
    val allUsers: StateFlow<List<UserEntity>> = repository.allUsers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentUserId = MutableStateFlow("u_current")
    val currentUserId: StateFlow<String> = _currentUserId.asStateFlow()

    val currentUser: StateFlow<UserEntity?> = combine(allUsers, _currentUserId) { users, id ->
        users.find { it.id == id } ?: users.firstOrNull()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Feed videos excluding blocked users
    val feedVideos: StateFlow<List<VideoEntity>> = combine(repository.allVideos, allUsers) { videos, users ->
        val blockedUserIds = users.filter { it.isBlocked }.map { it.id }.toSet()
        videos.filter { it.creatorId !in blockedUserIds }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allVideosAdmin: StateFlow<List<VideoEntity>> = repository.allVideosAdmin
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val likedVideos: StateFlow<List<VideoEntity>> = repository.likedVideos
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<NotificationEntity>> = repository.allNotifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val payouts: StateFlow<List<PayoutEntity>> = repository.allPayouts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val reports: StateFlow<List<ReportEntity>> = repository.allReports
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Search
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    val searchVideoResults: StateFlow<List<VideoEntity>> = _searchQuery.flatMapLatest { query ->
        if (query.isBlank()) repository.allVideos
        else repository.searchVideos(query)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active sheets and dialogs
    val activeCommentVideoId = MutableStateFlow<String?>(null)
    val activeShareVideo = MutableStateFlow<VideoEntity?>(null)
    val activeGiftVideo = MutableStateFlow<VideoEntity?>(null)
    val activeReportVideo = MutableStateFlow<VideoEntity?>(null)
    val viewingProfileUserId = MutableStateFlow<String?>(null)
    val showAuthDialog = MutableStateFlow(false)

    @OptIn(ExperimentalCoroutinesApi::class)
    val activeComments: StateFlow<List<CommentEntity>> = activeCommentVideoId.flatMapLatest { vid ->
        if (vid == null) flowOf(emptyList())
        else repository.getComments(vid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Actions
    fun toggleLike(video: VideoEntity) {
        viewModelScope.launch {
            repository.toggleLike(video)
        }
    }

    fun postComment(videoId: String, text: String) {
        val user = currentUser.value ?: return
        if (text.isBlank()) return
        viewModelScope.launch {
            repository.addComment(videoId, user, text)
        }
    }

    fun toggleCommentLike(comment: CommentEntity) {
        viewModelScope.launch {
            repository.toggleCommentLike(comment)
        }
    }

    fun sendGift(videoId: String, giftName: String, coins: Int) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            repository.sendGift(videoId, user.id, coins, giftName)
        }
    }

    fun toggleFollow(creatorId: String, currentStatus: Boolean) {
        viewModelScope.launch {
            repository.toggleFollow(creatorId, currentStatus)
        }
    }

    fun blockUser(userId: String) {
        viewModelScope.launch {
            repository.blockUser(userId, true)
        }
    }

    fun unblockUser(userId: String) {
        viewModelScope.launch {
            repository.blockUser(userId, false)
        }
    }

    fun submitReport(video: VideoEntity, reason: String) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            repository.reportContent(
                reporterId = user.id,
                videoId = video.id,
                userId = video.creatorId,
                caption = video.caption,
                reason = reason
            )
        }
    }

    fun publishVideo(
        caption: String,
        soundTitle: String,
        tags: String,
        category: String,
        videoUri: String,
        posterResName: String,
        bgGradientStart: Long,
        bgGradientEnd: Long
    ) {
        val user = currentUser.value ?: return
        val newVideo = VideoEntity(
            id = "v_${System.currentTimeMillis()}",
            creatorId = user.id,
            creatorName = user.displayName,
            creatorHandle = user.username,
            creatorAvatar = user.avatarUrl,
            caption = caption,
            soundTitle = if (soundTitle.isBlank()) "Original Sound - ${user.displayName}" else soundTitle,
            videoUri = videoUri,
            posterResName = posterResName,
            bgGradientStart = bgGradientStart,
            bgGradientEnd = bgGradientEnd,
            likesCount = 0,
            commentsCount = 0,
            sharesCount = 0,
            viewsCount = 1,
            isLiked = false,
            timestamp = System.currentTimeMillis(),
            tags = tags,
            category = category,
            adRevenue = 0.0,
            giftCoins = 0
        )
        viewModelScope.launch {
            repository.insertVideo(newVideo)
            _currentNavTab.value = ZingNavTab.FEED
        }
    }

    fun requestPayout(amount: Double, method: String, accountDetails: String) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            repository.requestPayout(user.id, amount, method, accountDetails)
        }
    }

    fun switchUser(userId: String) {
        _currentUserId.value = userId
    }

    fun registerOrLogin(username: String, displayName: String, bio: String) {
        viewModelScope.launch {
            val newUser = UserEntity(
                id = "u_${System.currentTimeMillis()}",
                username = username.lowercase().replace(" ", "_"),
                displayName = displayName,
                avatarUrl = "avatar_aarav",
                bio = bio.ifBlank { "Excited to share vibes on Zing! ✨" },
                isVerified = false,
                followersCount = 0,
                followingCount = 0,
                totalLikes = 0,
                isBlocked = false,
                isFollowing = false,
                role = "creator",
                walletBalance = 1000.0, // Initial welcome creator reward
                coinBalance = 250
            )
            repository.updateUser(newUser)
            _currentUserId.value = newUser.id
            showAuthDialog.value = false
        }
    }

    fun updateProfile(displayName: String, bio: String) {
        val current = currentUser.value ?: return
        viewModelScope.launch {
            repository.updateUser(current.copy(displayName = displayName, bio = bio))
        }
    }

    fun markAllNotificationsRead() {
        viewModelScope.launch {
            repository.markAllNotificationsRead()
        }
    }

    // Admin Operations
    fun adminResolveReport(reportId: String, takeDownVideo: Boolean, videoId: String?) {
        viewModelScope.launch {
            repository.resolveReport(reportId, if (takeDownVideo) "RESOLVED_TAKEDOWN" else "DISMISSED")
            if (takeDownVideo && videoId != null) {
                repository.setVideoTakeDown(videoId, true)
            }
        }
    }

    fun adminToggleTakeDown(videoId: String, isTakenDown: Boolean) {
        viewModelScope.launch {
            repository.setVideoTakeDown(videoId, isTakenDown)
        }
    }

    fun adminUpdatePayoutStatus(payoutId: String, status: String) {
        viewModelScope.launch {
            repository.updatePayoutStatus(payoutId, status)
        }
    }
}
