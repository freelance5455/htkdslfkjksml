package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.StudySession
import com.example.data.model.Subject
import com.example.ui.theme.AestheticBlack
import com.example.ui.theme.BorderGrey
import com.example.ui.theme.CardGrey
import com.example.ui.theme.DeepPink
import com.example.ui.theme.KawaiiPink
import com.example.ui.theme.PaletteSubjectColors
import com.example.ui.theme.PastelPinkBg
import com.example.ui.theme.PastelPinkContainer
import com.example.ui.theme.PureWhite
import com.example.ui.theme.TextGrey
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SubjectPickerDialog(
    subjects: List<Subject>,
    selectedSubject: Subject?,
    onSubjectSelected: (Subject) -> Unit,
    onAddNewSubject: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.testTag("subject_picker_dialog"),
        containerColor = PureWhite,
        shape = RoundedCornerShape(26.dp),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Select Study Subject 📚",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = AestheticBlack
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = TextGrey)
                }
            }
        },
        text = {
            Column {
                if (subjects.isEmpty()) {
                    Text(
                        text = "No subjects added yet. Tap below to create your first subject!",
                        color = TextGrey,
                        style = MaterialTheme.typography.bodyMedium
                    )
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(subjects) { subject ->
                            val isSelected = subject.id == selectedSubject?.id
                            val subjectColor = try {
                                Color(android.graphics.Color.parseColor(subject.colorHex))
                            } catch (_: Exception) {
                                KawaiiPink
                            }

                            Card(
                                onClick = {
                                    onSubjectSelected(subject)
                                    onDismiss()
                                },
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) PastelPinkContainer else PureWhite
                                ),
                                border = androidx.compose.foundation.BorderStroke(
                                    if (isSelected) 1.5.dp else 1.dp,
                                    if (isSelected) DeepPink else BorderGrey
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("subject_item_${subject.id}")
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(38.dp)
                                                .clip(CircleShape)
                                                .background(PastelPinkBg)
                                                .border(1.dp, BorderGrey, CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(text = subject.icon, fontSize = 18.sp)
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(
                                                text = subject.name,
                                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                                                color = AestheticBlack
                                            )
                                            Text(
                                                text = "Daily Goal: ${subject.dailyGoalMinutes}m",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = TextGrey
                                            )
                                        }
                                    }

                                    if (isSelected) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "Selected",
                                            tint = DeepPink
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedButton(
                    onClick = {
                        onDismiss()
                        onAddNewSubject()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("create_subject_btn"),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = AestheticBlack),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, AestheticBlack)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("New Subject", fontWeight = FontWeight.Bold)
                }
            }
        },
        confirmButton = {}
    )
}

@Composable
fun AddEditSubjectDialog(
    initialSubject: Subject? = null,
    onSave: (name: String, icon: String, colorHex: String, goalMinutes: Int) -> Unit,
    onDelete: (() -> Unit)? = null,
    onDismiss: () -> Unit
) {
    val commonEmojis = listOf("🐰", "🧮", "🧼", "✂️", "📏", "📎", "🖌️", "📌", "🌸", "⭐", "💻", "📖")

    var name by remember { mutableStateOf(initialSubject?.name ?: "") }
    var selectedIcon by remember { mutableStateOf(initialSubject?.icon ?: "🐰") }
    var selectedColor by remember { mutableStateOf(initialSubject?.colorHex ?: PaletteSubjectColors[0]) }
    var goalMinutes by remember { mutableFloatStateOf((initialSubject?.dailyGoalMinutes ?: 60).toFloat()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = PureWhite,
        shape = RoundedCornerShape(26.dp),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (initialSubject == null) "New Subject 🌸" else "Edit Subject",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = AestheticBlack
                )
                if (initialSubject != null && onDelete != null) {
                    IconButton(onClick = {
                        onDelete()
                        onDismiss()
                    }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete subject", tint = DeepPink)
                    }
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                // Name
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Subject Name") },
                    placeholder = { Text("e.g. Mathematics, Creative Writing") },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("subject_name_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = DeepPink,
                        unfocusedBorderColor = BorderGrey,
                        focusedLabelColor = DeepPink,
                        unfocusedLabelColor = TextGrey,
                        focusedTextColor = AestheticBlack,
                        unfocusedTextColor = AestheticBlack
                    )
                )

                // Emoji Picker
                Column {
                    Text(
                        text = "Choose Cute Sticker Icon",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextGrey
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(commonEmojis) { emoji ->
                            val isSelected = emoji == selectedIcon
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(if (isSelected) PastelPinkContainer else PureWhite)
                                    .border(
                                        if (isSelected) 2.dp else 1.dp,
                                        if (isSelected) DeepPink else BorderGrey,
                                        CircleShape
                                    )
                                    .clickable { selectedIcon = emoji },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(text = emoji, fontSize = 20.sp)
                            }
                        }
                    }
                }

                // Color Picker
                Column {
                    Text(
                        text = "Aesthetic Color Tag",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextGrey
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(PaletteSubjectColors) { hex ->
                            val color = try {
                                Color(android.graphics.Color.parseColor(hex))
                            } catch (_: Exception) {
                                KawaiiPink
                            }
                            val isSelected = hex.equals(selectedColor, ignoreCase = true)
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(color)
                                    .border(
                                        if (isSelected) 2.5.dp else 1.dp,
                                        if (isSelected) AestheticBlack else BorderGrey,
                                        CircleShape
                                    )
                                    .clickable { selectedColor = hex },
                                contentAlignment = Alignment.Center
                            ) {
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        tint = if (hex == "#18181B") PureWhite else AestheticBlack,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // Daily Target Goal Slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Daily Target Goal",
                            style = MaterialTheme.typography.labelMedium,
                            color = TextGrey
                        )
                        Text(
                            text = "${goalMinutes.toInt()} minutes",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = DeepPink
                        )
                    }
                    Slider(
                        value = goalMinutes,
                        onValueChange = { goalMinutes = it },
                        valueRange = 15f..240f,
                        steps = 14,
                        colors = SliderDefaults.colors(
                            thumbColor = DeepPink,
                            activeTrackColor = KawaiiPink,
                            inactiveTrackColor = CardGrey
                        )
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onSave(name.trim(), selectedIcon, selectedColor, goalMinutes.toInt())
                        onDismiss()
                    }
                },
                enabled = name.isNotBlank(),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AestheticBlack,
                    contentColor = PureWhite
                ),
                modifier = Modifier.testTag("save_subject_button")
            ) {
                Text("Save Subject", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextGrey)
            }
        }
    )
}

@Composable
fun AddManualSessionDialog(
    subjects: List<Subject>,
    onSave: (Subject, Int, String) -> Unit,
    onDismiss: () -> Unit
) {
    if (subjects.isEmpty()) return

    var selectedSubject by remember { mutableStateOf(subjects.first()) }
    var durationMinutes by remember { mutableFloatStateOf(30f) }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = PureWhite,
        shape = RoundedCornerShape(26.dp),
        title = {
            Text(
                text = "Log Study Session 📝",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = AestheticBlack
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                // Subject selection
                Column {
                    Text("Subject", style = MaterialTheme.typography.labelMedium, color = TextGrey)
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(subjects) { subject ->
                            val isSelected = subject.id == selectedSubject.id
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = if (isSelected) PastelPinkContainer else PureWhite,
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isSelected) DeepPink else BorderGrey
                                ),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .clickable { selectedSubject = subject }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(subject.icon, fontSize = 14.sp)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        subject.name,
                                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                        color = AestheticBlack
                                    )
                                }
                            }
                        }
                    }
                }

                // Duration Slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Duration", style = MaterialTheme.typography.labelMedium, color = TextGrey)
                        Text(
                            "${durationMinutes.toInt()} min",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = DeepPink
                        )
                    }
                    Slider(
                        value = durationMinutes,
                        onValueChange = { durationMinutes = it },
                        valueRange = 5f..180f,
                        steps = 34,
                        colors = SliderDefaults.colors(
                            thumbColor = DeepPink,
                            activeTrackColor = KawaiiPink,
                            inactiveTrackColor = CardGrey
                        )
                    )
                }

                // Notes
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Topic or Accomplishment") },
                    placeholder = { Text("e.g. Completed 10 practice problems") },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = DeepPink,
                        unfocusedBorderColor = BorderGrey,
                        focusedLabelColor = DeepPink,
                        unfocusedLabelColor = TextGrey,
                        focusedTextColor = AestheticBlack,
                        unfocusedTextColor = AestheticBlack
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(selectedSubject, durationMinutes.toInt(), notes)
                    onDismiss()
                },
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AestheticBlack,
                    contentColor = PureWhite
                )
            ) {
                Text("Save Entry", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextGrey)
            }
        }
    )
}

@Composable
fun SessionDetailDialog(
    session: StudySession,
    onDelete: (Long) -> Unit,
    onDismiss: () -> Unit
) {
    val dateFormat = SimpleDateFormat("EEEE, MMM d, yyyy • h:mm a", Locale.getDefault())
    val formattedDate = dateFormat.format(Date(session.timestamp))
    val minutes = session.durationSeconds / 60
    val seconds = session.durationSeconds % 60

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = PureWhite,
        shape = RoundedCornerShape(26.dp),
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = session.subjectIcon, fontSize = 22.sp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = session.subjectName,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = AestheticBlack
                    )
                }
                IconButton(onClick = {
                    onDelete(session.id)
                    onDismiss()
                }) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete Session", tint = DeepPink)
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = formattedDate,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextGrey
                )

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = PastelPinkBg,
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderGrey),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Focus Time:", color = TextGrey, style = MaterialTheme.typography.bodyMedium)
                            Text(
                                if (seconds > 0) "${minutes}m ${seconds}s" else "${minutes}m",
                                color = DeepPink,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Type:", color = TextGrey, style = MaterialTheme.typography.bodyMedium)
                            Text(session.sessionType, color = AestheticBlack, fontWeight = FontWeight.Medium)
                        }
                    }
                }

                if (session.notes.isNotBlank()) {
                    Text(
                        text = "Notes & Accomplishments:",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextGrey
                    )
                    Text(
                        text = session.notes,
                        style = MaterialTheme.typography.bodyMedium,
                        color = AestheticBlack
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = AestheticBlack, fontWeight = FontWeight.Bold)
            }
        }
    )
}
