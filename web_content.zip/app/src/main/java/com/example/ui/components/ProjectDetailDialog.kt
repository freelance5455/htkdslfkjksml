package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.ProjectEntity
import com.example.ui.theme.BrandPrimary
import com.example.ui.theme.BrandSecondary
import com.example.ui.theme.DangerRed
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber

@Composable
fun ProjectDetailDialog(
    project: ProjectEntity,
    isArabic: Boolean,
    onDismiss: () -> Unit,
    onOpenAiReport: (ProjectEntity) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.88f)
                .testTag("project_detail_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = if (isArabic) "مركز تصحيح وفحص الحزمة" else "Package Inspector & Debugger",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = project.name,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_inspector_button")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Tabs: 0: Overview & Stats, 1: Manifest & DEX, 2: Signatures, 3: Live Logs
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    contentColor = BrandPrimary
                ) {
                    val tabs = if (isArabic) {
                        listOf("الإحصائيات", "الـ Manifest", "التوقيع والأمان", "سجل التصحيح")
                    } else {
                        listOf("Stats", "Manifest", "Security", "Logs")
                    }

                    tabs.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            text = {
                                Text(
                                    text = title,
                                    fontSize = 12.sp,
                                    fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Tab Content Body
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    when (selectedTab) {
                        0 -> StatsOverviewTab(project, isArabic)
                        1 -> ManifestViewerTab(project, isArabic)
                        2 -> SecuritySignaturesTab(project, isArabic)
                        3 -> DebugLogsTab(project, isArabic)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Action Buttons Footer
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(if (isArabic) "إغلاق" else "Close")
                    }

                    Button(
                        onClick = { onOpenAiReport(project) },
                        colors = ButtonDefaults.buttonColors(containerColor = BrandPrimary),
                        modifier = Modifier.weight(1.5f)
                    ) {
                        Text(if (isArabic) "تقرير الذكاء الاصطناعي ✨" else "AI Report ✨")
                    }
                }
            }
        }
    }
}

@Composable
private fun StatsOverviewTab(project: ProjectEntity, isArabic: Boolean) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // High level numbers row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            StatBox(
                label = if (isArabic) "الحجم الأصلي" else "Original Size",
                value = "${project.sourceFileSize / (1024 * 1024)} MB",
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f)
            )
            StatBox(
                label = if (isArabic) "الحجم بعد التحويل" else "Converted Size",
                value = "${project.outputFileSize / (1024 * 1024)} MB",
                color = SuccessGreen,
                modifier = Modifier.weight(1f)
            )
            StatBox(
                label = if (isArabic) "نسبة التوفير" else "Compression",
                value = "${"%.1f".format(project.compressionRatio)}%",
                color = WarningAmber,
                modifier = Modifier.weight(1f)
            )
        }

        // Details List
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            DetailItem(if (isArabic) "اسم الحزمة (Package)" else "Package Name", project.packageName)
            DetailItem(if (isArabic) "رقم الإصدار (Version)" else "Version", project.versionName)
            DetailItem(if (isArabic) "مستوى Target SDK" else "Target SDK", "${project.targetSdk} (Android 14+)")
            DetailItem(if (isArabic) "ملفات الكود التنفيذي (DEX)" else "DEX Count", "${project.dexCount} ملفات DEX")
            DetailItem(if (isArabic) "دعم معمارية 64-bit" else "64-bit Support", if (project.has64BitSupport) "نعم (arm64-v8a)" else "غير متوفر")
            DetailItem(if (isArabic) "محاذاة Zipalign" else "Zipalign", "4-byte boundary محاذاة نشطة")
            DetailItem(if (isArabic) "حالة المزامنة السحابية" else "Cloud Sync", if (project.isCloudSynced) "تم الحفظ بالسحابة" else "محلي (غير متزامن)")
        }

        // Notes if any
        if (project.notes.isNotBlank()) {
            Text(
                text = if (isArabic) "ملاحظات وتوصيات:" else "Notes & Recommendations:",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = project.notes,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ManifestViewerTab(project: ProjectEntity, isArabic: Boolean) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = if (isArabic) "هيكل AndroidManifest.xml المستخرج والمعتمد:" else "Extracted AndroidManifest.xml Structure:",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF090E17))
                .border(1.dp, Color(0xFF1E2B45), RoundedCornerShape(10.dp))
                .padding(12.dp)
        ) {
            val manifestFormatted = """
                <?xml version="1.0" encoding="utf-8"?>
                <manifest xmlns:android="http://schemas.android.com/apk/res/android"
                    package="${project.packageName}"
                    android:versionCode="1"
                    android:versionName="${project.versionName}">

                    <!-- Permissions -->
                    <uses-permission android:name="android.permission.INTERNET" />
                    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

                    <application
                        android:allowBackup="true"
                        android:icon="@mipmap/ic_launcher"
                        android:label="${project.name}"
                        android:roundIcon="@mipmap/ic_launcher_round"
                        android:supportsRtl="true"
                        android:debuggable="false">

                        <activity
                            android:name=".MainActivity"
                            android:exported="true">
                            <intent-filter>
                                <action android:name="android.intent.action.MAIN" />
                                <category android:name="android.intent.category.LAUNCHER" />
                            </intent-filter>
                        </activity>
                    </application>
                </manifest>
            """.trimIndent()

            Text(
                text = manifestFormatted,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                color = Color(0xFF90CAF9),
                lineHeight = 16.sp
            )
        }
    }
}

@Composable
private fun SecuritySignaturesTab(project: ProjectEntity, isArabic: Boolean) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = if (isArabic) "بيانات التوقيع الرقمي والشهادات (v1 / v2 / v3):" else "Digital Signatures & Certificate Details:",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onSurface
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            DetailItem(if (isArabic) "مفتاح التوقيع المستخدم" else "Signing Key Alias", project.signingKeyAlias)
            DetailItem(if (isArabic) "مخطط التوقيع (Signing Scheme)" else "Scheme", "JAR v1 (SHA256withRSA) + v2 Verified")
            DetailItem(if (isArabic) "حالة الحماية" else "Security Status", "معتمد ومحمي بشهادة صالحة 25 سنة")
            DetailItem(
                if (isArabic) "بصمة SHA-256" else "SHA-256 Fingerprint",
                "8A:1B:77:43:5D:89:33:41:2F:90:88:CE:54:12:F6:A3:DE:44:B1:C0:78:E9:51:7A:B4:63:71:0D:33:9A:FF:28"
            )
        }
    }
}

@Composable
private fun DebugLogsTab(project: ProjectEntity, isArabic: Boolean) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = if (isArabic) "سجل العمليات والتصحيح المباشر (Terminal Console):" else "Live Build & Conversion Logs:",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF070B12))
                .border(1.dp, Color(0xFF19253B), RoundedCornerShape(10.dp))
                .padding(12.dp)
        ) {
            val logsText = if (project.logMessages.isNotBlank()) {
                project.logMessages
            } else {
                "[INFO] تم فحص الحزمة بنجاح\n[SUCCESS] تم التوقيع الرقمي والمحاذاة Zipalign\n[COMPLETED] الحزمة جاهزة للرفع إلى المتجر"
            }

            Text(
                text = logsText,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                color = SuccessGreen,
                lineHeight = 17.sp
            )
        }
    }
}

@Composable
private fun StatBox(
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
            .padding(10.dp)
    ) {
        Column {
            Text(
                text = label,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = color
            )
        }
    }
}

@Composable
private fun DetailItem(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            fontWeight = FontWeight.SemiBold,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
