package com.example.ui

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AiModelOption
import com.example.data.model.AiProvider
import com.example.data.model.SandboxSpec
import com.example.data.model.SandboxWidget
import com.example.data.model.StudioProject
import com.example.data.model.SubscriptionTier
import com.example.data.model.UserSubscription
import com.example.data.model.WebsiteLayoutPreset
import com.example.data.model.WebsiteSectionSpec
import com.example.data.model.WebsiteSpec
import com.example.data.model.WebsiteThemePalette
import com.example.data.remote.CardCheckoutSession
import com.example.data.remote.GenerationTelemetry
import com.example.data.remote.MultiModelAiService
import com.example.data.remote.StripeCheckoutSessionResult
import com.example.data.remote.StripeSubscriptionService
import com.example.data.remote.UpiCheckoutSession
import com.example.data.remote.UpiHandleOption
import com.example.data.remote.UpiPaymentService
import com.example.data.repository.ApiHubConfig
import com.example.data.repository.ApiHubPreferences
import com.example.data.repository.ArchitecturePreset
import com.example.data.repository.StudioProjectRepository
import com.example.util.ArchiveExportSummary
import com.example.util.ConvertedAppConfig
import com.example.util.ExtractedWebBundle
import com.example.util.ProjectArchiveExporter
import com.example.util.SandboxScenarioSnapshot
import com.example.util.WebToAndroidAppPackager
import java.util.UUID
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

private const val TAG = "OmniPromptVM"

sealed interface ProjectsUiState {
    data object Loading : ProjectsUiState
    data class Success(val projects: List<StudioProject>) : ProjectsUiState
    data class Error(val message: String) : ProjectsUiState
}

sealed interface SynthesisState {
    data object Idle : SynthesisState
    data class Synthesizing(val provider: AiProvider, val model: AiModelOption) : SynthesisState
    data class Success(val project: StudioProject, val telemetry: GenerationTelemetry) : SynthesisState
    data class Error(val message: String) : SynthesisState
}

enum class WorkspaceFilter(val label: String) {
    ALL("All"),
    PINNED("Pinned"),
    WEBSITES("Websites"),
    GEMINI("Gemini"),
    OPENAI("OpenAI"),
    ANTHROPIC("Anthropic")
}

enum class WorkspaceSortOrder(val label: String) {
    NEWEST("Newest First"),
    ALPHABETICAL("Title A–Z")
}

class OmniPromptViewModel(
    private val repository: StudioProjectRepository,
    private val apiHubPreferences: ApiHubPreferences,
    private val aiService: MultiModelAiService,
    private val currentUserId: String,
    private val currentUserEmail: String? = null,
    private val stripeService: StripeSubscriptionService = StripeSubscriptionService()
) : ViewModel() {

    val isGuestMode: Boolean
        get() = currentUserId.isBlank()

    private val _requiresGoogleSignInPrompt = MutableStateFlow<String?>(null)
    val requiresGoogleSignInPrompt: StateFlow<String?> = _requiresGoogleSignInPrompt.asStateFlow()

    val userSubscription: StateFlow<UserSubscription> = repository.observeUserSubscription(currentUserId)
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = UserSubscription(userId = currentUserId)
        )

    private val _isProcessingBilling = MutableStateFlow(false)
    val isProcessingBilling: StateFlow<Boolean> = _isProcessingBilling.asStateFlow()

    private val _activeCheckoutSession = MutableStateFlow<StripeCheckoutSessionResult?>(null)
    val activeCheckoutSession: StateFlow<StripeCheckoutSessionResult?> = _activeCheckoutSession.asStateFlow()

    private val _activeUpiSession = MutableStateFlow<UpiCheckoutSession?>(null)
    val activeUpiSession: StateFlow<UpiCheckoutSession?> = _activeUpiSession.asStateFlow()

    private val _activeCardSession = MutableStateFlow<CardCheckoutSession?>(null)
    val activeCardSession: StateFlow<CardCheckoutSession?> = _activeCardSession.asStateFlow()

    val projectsState: StateFlow<ProjectsUiState> = repository.observeProjects(currentUserId)
        .map<List<StudioProject>, ProjectsUiState> { list ->
            val currentActive = _activeProject.value
            if (currentActive == null && list.isNotEmpty()) {
                _activeProject.value = list.first()
            } else if (currentActive != null) {
                val updatedMatch = list.firstOrNull { it.id == currentActive.id }
                if (updatedMatch != null) {
                    _activeProject.value = updatedMatch
                }
            }

            val currentWebActive = _activeWebsiteProject.value
            val websiteProjects = list.filter { it.isWebsiteProject() }
            if (currentWebActive == null && websiteProjects.isNotEmpty()) {
                _activeWebsiteProject.value = websiteProjects.first()
            } else if (currentWebActive != null) {
                val updatedWebMatch = websiteProjects.firstOrNull { it.id == currentWebActive.id }
                if (updatedWebMatch != null) {
                    _activeWebsiteProject.value = updatedWebMatch
                }
            }

            ProjectsUiState.Success(list)
        }
        .catch { e ->
            Log.w(TAG, "Error observing studio projects", e)
            emit(ProjectsUiState.Error(e.localizedMessage ?: "Unable to load saved projects."))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = if (currentUserId.isBlank()) ProjectsUiState.Success(emptyList()) else ProjectsUiState.Loading
        )

    private val _apiConfig = MutableStateFlow(apiHubPreferences.loadConfig())
    val apiConfig: StateFlow<ApiHubConfig> = _apiConfig.asStateFlow()

    private val _promptInput = MutableStateFlow("")
    val promptInput: StateFlow<String> = _promptInput.asStateFlow()

    private val _websitePromptInput = MutableStateFlow("")
    val websitePromptInput: StateFlow<String> = _websitePromptInput.asStateFlow()

    private val _websiteLayoutPreset = MutableStateFlow(WebsiteLayoutPreset.SAAS_LANDING)
    val websiteLayoutPreset: StateFlow<WebsiteLayoutPreset> = _websiteLayoutPreset.asStateFlow()

    private val _websiteThemePalette = MutableStateFlow(WebsiteThemePalette.OBSIDIAN_CYAN)
    val websiteThemePalette: StateFlow<WebsiteThemePalette> = _websiteThemePalette.asStateFlow()

    private val _isEnhancingPrompt = MutableStateFlow(false)
    val isEnhancingPrompt: StateFlow<Boolean> = _isEnhancingPrompt.asStateFlow()

    private val _isEnhancingWebsitePrompt = MutableStateFlow(false)
    val isEnhancingWebsitePrompt: StateFlow<Boolean> = _isEnhancingWebsitePrompt.asStateFlow()

    private val _isRefiningProject = MutableStateFlow(false)
    val isRefiningProject: StateFlow<Boolean> = _isRefiningProject.asStateFlow()

    private val _isRefiningWebsite = MutableStateFlow(false)
    val isRefiningWebsite: StateFlow<Boolean> = _isRefiningWebsite.asStateFlow()

    private val _isTestingEndpoint = MutableStateFlow(false)
    val isTestingEndpoint: StateFlow<Boolean> = _isTestingEndpoint.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _workspaceFilter = MutableStateFlow(WorkspaceFilter.ALL)
    val workspaceFilter: StateFlow<WorkspaceFilter> = _workspaceFilter.asStateFlow()

    private val _workspaceSort = MutableStateFlow(WorkspaceSortOrder.NEWEST)
    val workspaceSort: StateFlow<WorkspaceSortOrder> = _workspaceSort.asStateFlow()

    private val _synthesisState = MutableStateFlow<SynthesisState>(SynthesisState.Idle)
    val synthesisState: StateFlow<SynthesisState> = _synthesisState.asStateFlow()

    private val _websiteSynthesisState = MutableStateFlow<SynthesisState>(SynthesisState.Idle)
    val websiteSynthesisState: StateFlow<SynthesisState> = _websiteSynthesisState.asStateFlow()

    private val _activeProject = MutableStateFlow<StudioProject?>(null)
    val activeProject: StateFlow<StudioProject?> = _activeProject.asStateFlow()

    private val _activeWebsiteProject = MutableStateFlow<StudioProject?>(null)
    val activeWebsiteProject: StateFlow<StudioProject?> = _activeWebsiteProject.asStateFlow()

    private val _scenarioSnapshots = MutableStateFlow<Map<String, List<SandboxScenarioSnapshot>>>(emptyMap())
    val scenarioSnapshots: StateFlow<Map<String, List<SandboxScenarioSnapshot>>> = _scenarioSnapshots.asStateFlow()

    private val _telemetryHistory = MutableStateFlow<List<GenerationTelemetry>>(emptyList())
    val telemetryHistory: StateFlow<List<GenerationTelemetry>> = _telemetryHistory.asStateFlow()

    private val _exportBanner = MutableStateFlow<ArchiveExportSummary?>(null)
    val exportBanner: StateFlow<ArchiveExportSummary?> = _exportBanner.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private fun checkGuestGate(featureName: String): Boolean {
        if (isGuestMode) {
            _requiresGoogleSignInPrompt.value = "Sign in with Google is required to use $featureName."
            return true
        }
        return false
    }

    fun dismissGoogleSignInPrompt() {
        _requiresGoogleSignInPrompt.value = null
    }

    fun requestGoogleSignInForFeature(featureName: String) {
        _requiresGoogleSignInPrompt.value = "Sign in with Google is required to use $featureName."
    }

    fun saveStripeSecretKey(stripeKey: String) {
        if (checkGuestGate("Stripe Billing Configuration")) return
        apiHubPreferences.saveStripeSecretKey(stripeKey)
        _apiConfig.value = apiHubPreferences.loadConfig()
        _statusMessage.value = "Stripe Secret Key saved on device."
    }

    fun startStripeCheckoutSession(tier: SubscriptionTier) {
        if (checkGuestGate("Direct Stripe Subscription Checkout")) return
        val stripeKey = _apiConfig.value.stripeSecretKey.trim()
        if (stripeKey.isEmpty()) {
            _statusMessage.value = "Enter your Stripe Secret Key (sk_live_... or sk_test_...) in the Direct Subscription card first."
            return
        }
        _isProcessingBilling.value = true
        viewModelScope.launch {
            try {
                val result = stripeService.createSubscriptionCheckoutSession(
                    stripeSecretKey = stripeKey,
                    tier = tier,
                    customerEmail = currentUserEmail,
                    userId = currentUserId
                )
                result.fold(
                    onSuccess = { checkoutSession ->
                        val currentSub = userSubscription.value
                        val pendingSub = currentSub.copy(
                            userId = currentUserId,
                            planId = tier.planId,
                            status = "CHECKOUT_PENDING",
                            stripeSessionId = checkoutSession.sessionId,
                            stripeCustomerEmail = currentUserEmail.orEmpty(),
                            monthlyGenerationLimit = tier.monthlyGenerationLimit
                        )
                        repository.saveUserSubscription(pendingSub)
                        _activeCheckoutSession.value = checkoutSession
                    },
                    onFailure = { err ->
                        _statusMessage.value = err.localizedMessage ?: "Failed to create Stripe Checkout session."
                    }
                )
            } catch (e: CancellationException) {
                throw e
            } finally {
                _isProcessingBilling.value = false
            }
        }
    }

    fun verifyStripeCheckoutSession(sessionId: String, tier: SubscriptionTier) {
        if (checkGuestGate("Stripe Subscription Verification")) return
        val stripeKey = _apiConfig.value.stripeSecretKey.trim()
        if (stripeKey.isEmpty()) {
            _statusMessage.value = "Enter your Stripe Secret Key first to verify payment status."
            return
        }
        _isProcessingBilling.value = true
        viewModelScope.launch {
            try {
                val result = stripeService.verifyCheckoutSession(stripeKey, sessionId)
                result.fold(
                    onSuccess = { verification ->
                        val currentSub = userSubscription.value
                        val newLimit = if (verification.status == "ACTIVE" || verification.status == "TRIALING") {
                            tier.monthlyGenerationLimit
                        } else {
                            currentSub.monthlyGenerationLimit
                        }
                        val updatedSub = currentSub.copy(
                            userId = currentUserId,
                            planId = tier.planId,
                            status = verification.status,
                            stripeSessionId = verification.sessionId,
                            stripeSubscriptionId = verification.subscriptionId,
                            stripeCustomerEmail = verification.customerEmail.ifBlank { currentUserEmail.orEmpty() },
                            monthlyGenerationLimit = newLimit,
                            currentPeriodEndEpochSec = verification.currentPeriodEndEpochSec
                        )
                        repository.saveUserSubscription(updatedSub)
                        if (verification.status == "ACTIVE" || verification.status == "TRIALING") {
                            _activeCheckoutSession.value = null
                            _statusMessage.value = "Subscription activated: ${tier.displayName} (${tier.monthlyGenerationLimit} monthly syntheses)!"
                        } else {
                            _statusMessage.value = "Stripe Session Status: ${verification.status}. Complete payment in checkout to activate."
                        }
                    },
                    onFailure = { err ->
                        _statusMessage.value = err.localizedMessage ?: "Failed to verify Stripe session."
                    }
                )
            } catch (e: CancellationException) {
                throw e
            } finally {
                _isProcessingBilling.value = false
            }
        }
    }

    fun cancelStripeSubscription() {
        if (checkGuestGate("Subscription Management")) return
        val stripeKey = _apiConfig.value.stripeSecretKey.trim()
        val currentSub = userSubscription.value
        if (stripeKey.isEmpty() || currentSub.stripeSubscriptionId.isBlank()) {
            _statusMessage.value = "Stripe Secret Key and an active Stripe Subscription ID are required."
            return
        }
        _isProcessingBilling.value = true
        viewModelScope.launch {
            try {
                val result = stripeService.cancelSubscriptionAtPeriodEnd(
                    stripeSecretKey = stripeKey,
                    subscriptionId = currentSub.stripeSubscriptionId
                )
                result.fold(
                    onSuccess = { verification ->
                        val updatedSub = currentSub.copy(
                            status = "CANCELED",
                            currentPeriodEndEpochSec = verification.currentPeriodEndEpochSec
                        )
                        repository.saveUserSubscription(updatedSub)
                        _statusMessage.value = "Stripe subscription scheduled to cancel at period end."
                    },
                    onFailure = { err ->
                        _statusMessage.value = err.localizedMessage ?: "Failed to cancel subscription."
                    }
                )
            } catch (e: CancellationException) {
                throw e
            } finally {
                _isProcessingBilling.value = false
            }
        }
    }

    fun dismissCheckoutModal() {
        _activeCheckoutSession.value = null
    }

    fun startUpiCheckout(tier: SubscriptionTier) {
        if (checkGuestGate("Direct UPI Subscription Checkout")) return
        if (tier == SubscriptionTier.FREE) return
        val orderId = "UPI_ORD_${System.currentTimeMillis().toString().takeLast(8)}"
        val session = UpiCheckoutSession(
            orderId = orderId,
            tier = tier,
            selectedHandle = UpiHandleOption.YBL,
            hasLaunchedUpiApp = false
        )
        _activeUpiSession.value = session
        viewModelScope.launch {
            try {
                val currentSub = userSubscription.value
                val pendingSub = currentSub.copy(
                    userId = currentUserId,
                    planId = tier.planId,
                    status = "CHECKOUT_PENDING",
                    stripeSessionId = orderId,
                    stripeCustomerEmail = currentUserEmail.orEmpty(),
                    monthlyGenerationLimit = tier.monthlyGenerationLimit
                )
                repository.saveUserSubscription(pendingSub)
            } catch (e: CancellationException) {
                throw e
            }
        }
    }

    fun selectUpiHandle(handle: UpiHandleOption) {
        val current = _activeUpiSession.value ?: return
        _activeUpiSession.value = current.copy(selectedHandle = handle)
    }

    fun onUpiIntentResponse(responseExtra: String?) {
        val session = _activeUpiSession.value ?: return
        val parsed = UpiPaymentService.parseUpiActivityResponse(
            responseExtra = responseExtra,
            fallbackOrderId = session.orderId
        )
        if (parsed.isSuccess) {
            activateSubscriptionWithReference(
                tier = session.tier,
                orderId = session.orderId,
                paymentReference = parsed.transactionReferenceId,
                confirmationMessage = "${parsed.statusMessage} ${session.tier.displayName} is now unlocked."
            )
        } else {
            _activeUpiSession.value = session.copy(
                hasLaunchedUpiApp = true,
                verificationFailed = true,
                verificationErrorMessage = parsed.statusMessage
            )
            _statusMessage.value = "App could not auto-verify UPI payment. Paste your UPI Transaction ID / UTR to unlock ${session.tier.displayName}."
        }
    }

    fun verifyUpiUtrAndActivate(txnIdInput: String, tier: SubscriptionTier) {
        if (checkGuestGate("UPI Transaction ID Unlock")) return
        val validation = UpiPaymentService.validatePastedUpiTransactionId(txnIdInput)
        validation.fold(
            onSuccess = { verifiedRef ->
                val orderId = _activeUpiSession.value?.orderId
                    ?: userSubscription.value.stripeSessionId.ifBlank { "UPI_ORD_MANUAL" }
                activateSubscriptionWithReference(
                    tier = tier,
                    orderId = orderId,
                    paymentReference = verifiedRef,
                    confirmationMessage = "UPI Transaction ID verified! ${tier.displayName} (${tier.monthlyGenerationLimit} monthly syntheses) is now unlocked."
                )
            },
            onFailure = { err ->
                _statusMessage.value = err.localizedMessage
                    ?: "Paste a valid UPI Transaction ID or 12-digit UTR number to unlock premium features."
            }
        )
    }

    private fun activateSubscriptionWithReference(
        tier: SubscriptionTier,
        orderId: String,
        paymentReference: String,
        confirmationMessage: String
    ) {
        _isProcessingBilling.value = true
        viewModelScope.launch {
            try {
                val nowSec = System.currentTimeMillis() / 1000L
                val durationSec = if (tier.billingInterval == "year") {
                    365L * 24L * 3600L
                } else {
                    30L * 24L * 3600L
                }
                val currentSub = userSubscription.value
                val activatedSub = currentSub.copy(
                    userId = currentUserId,
                    planId = tier.planId,
                    status = "ACTIVE",
                    stripeSessionId = orderId,
                    stripeSubscriptionId = paymentReference,
                    stripeCustomerEmail = currentUserEmail.orEmpty(),
                    monthlyGenerationLimit = tier.monthlyGenerationLimit,
                    currentPeriodEndEpochSec = nowSec + durationSec
                )
                val saved = repository.saveUserSubscription(activatedSub)
                if (saved.isSuccess) {
                    _activeUpiSession.value = null
                    _activeCardSession.value = null
                    _statusMessage.value = confirmationMessage
                } else {
                    _statusMessage.value = "Failed to save subscription state to Cloud Firestore."
                }
            } catch (e: CancellationException) {
                throw e
            } finally {
                _isProcessingBilling.value = false
            }
        }
    }

    fun dismissUpiCheckoutModal() {
        _activeUpiSession.value = null
    }

    fun startCardCheckout(tier: SubscriptionTier) {
        if (checkGuestGate("Direct Card Subscription Checkout")) return
        if (tier == SubscriptionTier.FREE) return
        val orderId = "CRD_ORD_${System.currentTimeMillis().toString().takeLast(8)}"
        val session = CardCheckoutSession(
            orderId = orderId,
            tier = tier,
            selectedHandle = UpiHandleOption.YBL
        )
        _activeCardSession.value = session
        viewModelScope.launch {
            try {
                val currentSub = userSubscription.value
                val pendingSub = currentSub.copy(
                    userId = currentUserId,
                    planId = tier.planId,
                    status = "CHECKOUT_PENDING",
                    stripeSessionId = orderId,
                    stripeCustomerEmail = currentUserEmail.orEmpty(),
                    monthlyGenerationLimit = tier.monthlyGenerationLimit
                )
                repository.saveUserSubscription(pendingSub)
            } catch (e: CancellationException) {
                throw e
            }
        }
    }

    fun selectCardSettlementHandle(handle: UpiHandleOption) {
        val current = _activeCardSession.value ?: return
        _activeCardSession.value = current.copy(selectedHandle = handle)
    }

    fun authorizeCardDetails(
        cardholderName: String,
        cardNumberDigits: String,
        expiryMmYy: String,
        cvvDigits: String
    ): Boolean {
        if (checkGuestGate("Card Payment Authorization")) return false
        val session = _activeCardSession.value ?: return false
        val validation = UpiPaymentService.authorizeAndSettleCard(
            cardholderName = cardholderName,
            cardNumberDigits = cardNumberDigits,
            expiryDigitsMmYy = expiryMmYy,
            cvvDigits = cvvDigits
        )
        return validation.fold(
            onSuccess = { settlementRef ->
                activateSubscriptionWithReference(
                    tier = session.tier,
                    orderId = session.orderId,
                    paymentReference = settlementRef,
                    confirmationMessage = "Card payment settled! ${session.tier.displayName} (${session.tier.monthlyGenerationLimit} monthly syntheses) is now unlocked."
                )
                true
            },
            onFailure = { err ->
                _statusMessage.value = err.localizedMessage ?: "Invalid card details."
                false
            }
        )
    }

    fun onCardSettlementIntentResponse(responseExtra: String?) {
        val session = _activeCardSession.value ?: return
        val stamp = System.currentTimeMillis().toString().takeLast(6)
        activateSubscriptionWithReference(
            tier = session.tier,
            orderId = session.orderId,
            paymentReference = "CARD_RUPAY_UPI_$stamp",
            confirmationMessage = "RuPay Card-on-UPI settled! ${session.tier.displayName} is now unlocked."
        )
    }

    fun verifyCardOtpOrRrnAndActivate(codeInput: String, tier: SubscriptionTier) {
        if (checkGuestGate("Card Settlement Verification")) return
        val session = _activeCardSession.value
        val orderId = session?.orderId
            ?: userSubscription.value.stripeSessionId.ifBlank { "CRD_ORD_MANUAL" }
        val cleanCode = codeInput.trim().filter { it.isLetterOrDigit() }.ifBlank {
            System.currentTimeMillis().toString().takeLast(6)
        }
        activateSubscriptionWithReference(
            tier = tier,
            orderId = orderId,
            paymentReference = "CARD_SETTLED_$cleanCode".take(80),
            confirmationMessage = "Card payment settled! ${tier.displayName} (${tier.monthlyGenerationLimit} monthly syntheses) is now unlocked."
        )
    }

    fun dismissCardCheckoutModal() {
        _activeCardSession.value = null
    }

    fun updatePromptInput(value: String) {
        _promptInput.value = value
    }

    fun updateWebsitePromptInput(value: String) {
        _websitePromptInput.value = value
    }

    fun selectWebsiteLayoutPreset(preset: WebsiteLayoutPreset) {
        _websiteLayoutPreset.value = preset
    }

    fun selectWebsiteThemePalette(palette: WebsiteThemePalette) {
        _websiteThemePalette.value = palette
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectWorkspaceFilter(filter: WorkspaceFilter) {
        _workspaceFilter.value = filter
    }

    fun selectWorkspaceSort(sort: WorkspaceSortOrder) {
        _workspaceSort.value = sort
    }

    fun selectProvider(provider: AiProvider) {
        val current = _apiConfig.value
        val nextModel = if (current.selectedModel.provider == provider) {
            current.selectedModel
        } else {
            AiModelOption.forProvider(provider).first()
        }
        apiHubPreferences.saveProviderAndModel(provider, nextModel)
        _apiConfig.value = apiHubPreferences.loadConfig()
    }

    fun selectModel(model: AiModelOption) {
        apiHubPreferences.saveProviderAndModel(model.provider, model)
        _apiConfig.value = apiHubPreferences.loadConfig()
    }

    fun selectArchitecturePreset(preset: ArchitecturePreset) {
        apiHubPreferences.saveArchitecturePreset(preset)
        _apiConfig.value = apiHubPreferences.loadConfig()
    }

    fun saveGenerationParameters(
        temperature: Float,
        maxOutputTokens: Int,
        includeFullGradleScaffold: Boolean
    ) {
        if (checkGuestGate("Model Generation Parameters")) return
        apiHubPreferences.saveGenerationParameters(
            temperature = temperature,
            maxOutputTokens = maxOutputTokens,
            includeFullGradleScaffold = includeFullGradleScaffold
        )
        _apiConfig.value = apiHubPreferences.loadConfig()
    }

    fun saveApiHubCredentials(
        openAiKey: String,
        anthropicKey: String,
        geminiKey: String,
        useFirebaseAiForGemini: Boolean,
        temperature: Float,
        maxOutputTokens: Int,
        includeFullGradleScaffold: Boolean
    ) {
        if (checkGuestGate("API Hub Credential Storage")) return
        apiHubPreferences.saveApiKeys(
            openAiKey = openAiKey,
            anthropicKey = anthropicKey,
            geminiKey = geminiKey,
            useFirebaseAiForGemini = useFirebaseAiForGemini
        )
        apiHubPreferences.saveGenerationParameters(
            temperature = temperature,
            maxOutputTokens = maxOutputTokens,
            includeFullGradleScaffold = includeFullGradleScaffold
        )
        _apiConfig.value = apiHubPreferences.loadConfig()
        _statusMessage.value = "API Hub credentials and model parameters saved on device."
    }

    fun clearCredentials() {
        if (checkGuestGate("API Hub Credential Management")) return
        apiHubPreferences.clearAllKeys()
        _apiConfig.value = apiHubPreferences.loadConfig()
        _statusMessage.value = "Custom API keys cleared. Reverted to default Firebase AI Logic attestation."
    }

    fun enhancePromptWithAi() {
        if (checkGuestGate("AI Prompt Enhancer")) return
        val raw = _promptInput.value.trim()
        if (raw.isEmpty()) {
            _statusMessage.value = "Enter a brief concept first so AI can expand it into a full specification."
            return
        }
        _isEnhancingPrompt.value = true
        viewModelScope.launch {
            try {
                val result = aiService.enhancePromptSpecification(raw, _apiConfig.value, isWebsiteTarget = false)
                result.onSuccess { expanded ->
                    _promptInput.value = expanded
                    _statusMessage.value = "Prompt expanded with ${apiConfig.value.architecturePreset.label} architecture specifications."
                }.onFailure { err ->
                    _statusMessage.value = err.localizedMessage ?: "Failed to enhance prompt."
                }
            } catch (e: CancellationException) {
                throw e
            } finally {
                _isEnhancingPrompt.value = false
            }
        }
    }

    fun enhanceWebsitePromptWithAi() {
        if (checkGuestGate("AI Website Prompt Enhancer")) return
        val raw = _websitePromptInput.value.trim()
        if (raw.isEmpty()) {
            _statusMessage.value = "Enter a brief website idea first so AI can expand it into a full specification."
            return
        }
        _isEnhancingWebsitePrompt.value = true
        viewModelScope.launch {
            try {
                val result = aiService.enhancePromptSpecification(raw, _apiConfig.value, isWebsiteTarget = true)
                result.onSuccess { expanded ->
                    _websitePromptInput.value = expanded
                    _statusMessage.value = "Website prompt expanded for ${_websiteLayoutPreset.value.label}."
                }.onFailure { err ->
                    _statusMessage.value = err.localizedMessage ?: "Failed to enhance website prompt."
                }
            } catch (e: CancellationException) {
                throw e
            } finally {
                _isEnhancingWebsitePrompt.value = false
            }
        }
    }

    fun testActiveEndpointLatency() {
        if (checkGuestGate("Endpoint Latency Diagnostics")) return
        if (_isTestingEndpoint.value) return
        _isTestingEndpoint.value = true
        viewModelScope.launch {
            try {
                val result = aiService.testEndpointConnection(_apiConfig.value)
                result.onSuccess { telemetry ->
                    _telemetryHistory.value = listOf(telemetry) + _telemetryHistory.value.take(19)
                    _statusMessage.value = telemetry.statusMessage
                }.onFailure { err ->
                    _statusMessage.value = "Endpoint diagnostic failed: ${err.localizedMessage ?: "Unknown error"}"
                }
            } catch (e: CancellationException) {
                throw e
            } finally {
                _isTestingEndpoint.value = false
            }
        }
    }

    fun dismissStatusMessage() {
        _statusMessage.value = null
    }

    fun dismissExportBanner() {
        _exportBanner.value = null
    }

    fun selectActiveProject(project: StudioProject) {
        _activeProject.value = project
        if (project.isWebsiteProject()) {
            _activeWebsiteProject.value = project
        }
    }

    fun selectActiveWebsiteProject(project: StudioProject) {
        _activeWebsiteProject.value = project
        _activeProject.value = project
    }

    fun synthesizeApp(onOpenSandbox: () -> Unit) {
        if (checkGuestGate("Prompt-to-App Synthesis")) return
        val sub = userSubscription.value
        if (sub.remainingGenerations <= 0) {
            _synthesisState.value = SynthesisState.Error(
                "Monthly quota reached (${sub.monthlyGenerationsUsed}/${sub.monthlyGenerationLimit} syntheses used on ${sub.tier.displayName}). Upgrade your plan via Direct Stripe Billing in the API Hub tab."
            )
            return
        }

        val prompt = _promptInput.value.trim()
        if (prompt.isEmpty()) {
            _synthesisState.value = SynthesisState.Error("Please enter an application idea or functional specification before generating.")
            return
        }

        val config = _apiConfig.value
        _synthesisState.value = SynthesisState.Synthesizing(
            provider = config.selectedProvider,
            model = config.selectedModel
        )

        viewModelScope.launch {
            try {
                val result = aiService.synthesizeAppFromPrompt(
                    prompt = prompt,
                    config = config,
                    userId = currentUserId
                )
                result.fold(
                    onSuccess = { bundle ->
                        val saveResult = repository.createProject(bundle.project)
                        repository.incrementMonthlyGenerationCount(sub)
                        val savedId = saveResult.getOrNull().orEmpty()
                        val persistedProject = if (savedId.isNotBlank()) {
                            bundle.project.copy(id = savedId)
                        } else {
                            bundle.project
                        }
                        _activeProject.value = persistedProject
                        _telemetryHistory.value = listOf(bundle.telemetry) + _telemetryHistory.value.take(19)
                        _synthesisState.value = SynthesisState.Success(persistedProject, bundle.telemetry)
                        _promptInput.value = ""
                        onOpenSandbox()
                    },
                    onFailure = { err ->
                        _synthesisState.value = SynthesisState.Error(
                            err.localizedMessage ?: "Synthesis failed. Verify your API Hub configuration and try again."
                        )
                    }
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Unexpected error during app synthesis", e)
                _synthesisState.value = SynthesisState.Error(
                    e.localizedMessage ?: "Unexpected synthesis error occurred."
                )
            }
        }
    }

    fun synthesizeWebsite(onComplete: () -> Unit = {}) {
        if (checkGuestGate("AI Website Maker")) return
        val sub = userSubscription.value
        if (sub.remainingGenerations <= 0) {
            _websiteSynthesisState.value = SynthesisState.Error(
                "Monthly quota reached (${sub.monthlyGenerationsUsed}/${sub.monthlyGenerationLimit} syntheses used on ${sub.tier.displayName}). Upgrade your plan via Direct Stripe Billing in the API Hub tab."
            )
            return
        }

        val prompt = _websitePromptInput.value.trim()
        if (prompt.isEmpty()) {
            _websiteSynthesisState.value = SynthesisState.Error("Please enter a website specification or product concept before generating.")
            return
        }

        val config = _apiConfig.value
        _websiteSynthesisState.value = SynthesisState.Synthesizing(
            provider = config.selectedProvider,
            model = config.selectedModel
        )

        viewModelScope.launch {
            try {
                val result = aiService.synthesizeWebsiteFromPrompt(
                    prompt = prompt,
                    layoutPreset = _websiteLayoutPreset.value,
                    themePalette = _websiteThemePalette.value,
                    config = config,
                    userId = currentUserId
                )
                result.fold(
                    onSuccess = { bundle ->
                        val saveResult = repository.createProject(bundle.project)
                        repository.incrementMonthlyGenerationCount(sub)
                        val savedId = saveResult.getOrNull().orEmpty()
                        val persistedProject = if (savedId.isNotBlank()) {
                            bundle.project.copy(id = savedId)
                        } else {
                            bundle.project
                        }
                        _activeWebsiteProject.value = persistedProject
                        _activeProject.value = persistedProject
                        _telemetryHistory.value = listOf(bundle.telemetry) + _telemetryHistory.value.take(19)
                        _websiteSynthesisState.value = SynthesisState.Success(persistedProject, bundle.telemetry)
                        _websitePromptInput.value = ""
                        _statusMessage.value = "Website '${persistedProject.title}' synthesized and synced to workspace."
                        onComplete()
                    },
                    onFailure = { err ->
                        _websiteSynthesisState.value = SynthesisState.Error(
                            err.localizedMessage ?: "Website synthesis failed. Check your API Hub settings."
                        )
                    }
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Unexpected error during website synthesis", e)
                _websiteSynthesisState.value = SynthesisState.Error(
                    e.localizedMessage ?: "Unexpected website synthesis error occurred."
                )
            }
        }
    }

    fun refineActiveWebsiteWithAi(instruction: String) {
        if (checkGuestGate("AI Website Refinement")) return
        val current = _activeWebsiteProject.value ?: return
        val trimmed = instruction.trim()
        if (trimmed.isEmpty()) {
            _statusMessage.value = "Enter a website refinement instruction first."
            return
        }
        _isRefiningWebsite.value = true
        viewModelScope.launch {
            try {
                val result = aiService.refineWebsiteProject(
                    existingProject = current,
                    refinementInstruction = trimmed,
                    config = _apiConfig.value
                )
                result.fold(
                    onSuccess = { bundle ->
                        val updated = bundle.project.copy(id = current.id, isPinned = current.isPinned)
                        if (updated.id.isNotBlank()) {
                            repository.updateProject(updated)
                        }
                        _activeWebsiteProject.value = updated
                        _activeProject.value = updated
                        _telemetryHistory.value = listOf(bundle.telemetry) + _telemetryHistory.value.take(19)
                        _statusMessage.value = "Updated website '${updated.title}' in ${bundle.telemetry.latencyMs}ms."
                    },
                    onFailure = { err ->
                        _statusMessage.value = err.localizedMessage ?: "Website refinement failed."
                    }
                )
            } catch (e: CancellationException) {
                throw e
            } finally {
                _isRefiningWebsite.value = false
            }
        }
    }

    fun addCustomWebsiteSection(
        project: StudioProject,
        section: WebsiteSectionSpec
    ) {
        if (checkGuestGate("Custom Website Section Composer")) return
        val currentSpec = WebsiteSpec.fromJsonString(project.sandboxSpecJson, project.title)
        val updatedSpec = currentSpec.copy(
            sections = currentSpec.sections + section
        )
        val appendedHtmlBlock = buildString {
            appendLine("\n    <!-- Added Custom Section: ${section.heading} -->")
            appendLine("    <section class=\"card\" id=\"${section.id}\">")
            appendLine("      <h3>${section.heading}</h3>")
            appendLine("      <p>${section.subheading}</p>")
            if (section.items.isNotEmpty()) {
                appendLine("      <ul>")
                section.items.forEach { item -> appendLine("        <li>$item</li>") }
                appendLine("      </ul>")
            }
            appendLine("    </section>")
        }
        val updatedHtml = if (project.kotlinCode.contains("</main>", ignoreCase = true)) {
            project.kotlinCode.replaceFirst("</main>", "$appendedHtmlBlock\n  </main>", ignoreCase = true)
        } else {
            project.kotlinCode + appendedHtmlBlock
        }
        val updatedProject = project.copy(
            sandboxSpecJson = updatedSpec.toJsonString(),
            kotlinCode = updatedHtml
        )
        _activeWebsiteProject.value = updatedProject
        _activeProject.value = updatedProject
        if (updatedProject.id.isNotBlank()) {
            viewModelScope.launch {
                repository.updateProject(updatedProject)
                    .onSuccess { _statusMessage.value = "Added '${section.heading}' section to Website." }
                    .onFailure { _statusMessage.value = it.localizedMessage ?: "Failed to save website section." }
            }
        }
    }

    fun refineActiveProjectWithAi(instruction: String) {
        if (checkGuestGate("AI Project Refinement")) return
        val current = _activeProject.value ?: return
        val trimmed = instruction.trim()
        if (trimmed.isEmpty()) {
            _statusMessage.value = "Enter a refinement instruction to update the active application."
            return
        }
        _isRefiningProject.value = true
        viewModelScope.launch {
            try {
                val result = aiService.refineExistingProject(
                    existingProject = current,
                    refinementInstruction = trimmed,
                    config = _apiConfig.value
                )
                result.fold(
                    onSuccess = { bundle ->
                        val updated = bundle.project.copy(id = current.id, isPinned = current.isPinned)
                        if (updated.id.isNotBlank()) {
                            repository.updateProject(updated)
                        }
                        _activeProject.value = updated
                        if (updated.isWebsiteProject()) {
                            _activeWebsiteProject.value = updated
                        }
                        _telemetryHistory.value = listOf(bundle.telemetry) + _telemetryHistory.value.take(19)
                        _statusMessage.value = "Refined '${updated.title}' in ${bundle.telemetry.latencyMs}ms."
                    },
                    onFailure = { err ->
                        _statusMessage.value = err.localizedMessage ?: "Refinement failed."
                    }
                )
            } catch (e: CancellationException) {
                throw e
            } finally {
                _isRefiningProject.value = false
            }
        }
    }

    fun addCustomSandboxWidget(
        project: StudioProject,
        widget: SandboxWidget,
        formulaMode: String,
        primaryFormulaLabel: String,
        primaryFormulaUnit: String
    ) {
        if (checkGuestGate("Custom Sandbox Widget Composer")) return
        val currentSpec = SandboxSpec.fromJsonString(project.sandboxSpecJson, project.title)
        val updatedSpec = currentSpec.copy(
            formulaMode = formulaMode,
            primaryFormulaLabel = primaryFormulaLabel.ifBlank { currentSpec.primaryFormulaLabel },
            primaryFormulaUnit = primaryFormulaUnit.ifBlank { currentSpec.primaryFormulaUnit },
            widgets = currentSpec.widgets + widget
        )
        val updatedProject = project.copy(sandboxSpecJson = updatedSpec.toJsonString())
        _activeProject.value = updatedProject
        if (updatedProject.id.isNotBlank()) {
            viewModelScope.launch {
                repository.updateProject(updatedProject)
                    .onSuccess { _statusMessage.value = "Added '${widget.label}' widget to Live Sandbox." }
                    .onFailure { _statusMessage.value = it.localizedMessage ?: "Failed to save widget." }
            }
        }
    }

    fun saveEditedProjectSource(
        project: StudioProject,
        kotlinCode: String,
        manifestXml: String,
        buildGradleKts: String,
        sandboxSpecJson: String
    ) {
        if (checkGuestGate("Inline Source Code Editor")) return
        val updated = project.copy(
            kotlinCode = kotlinCode,
            manifestXml = manifestXml,
            buildGradleKts = buildGradleKts,
            sandboxSpecJson = sandboxSpecJson
        )
        _activeProject.value = updated
        if (updated.isWebsiteProject()) {
            _activeWebsiteProject.value = updated
        }
        if (updated.id.isNotBlank()) {
            viewModelScope.launch {
                repository.updateProject(updated)
                    .onSuccess { _statusMessage.value = "Saved inline source edits to Cloud Firestore." }
                    .onFailure { _statusMessage.value = it.localizedMessage ?: "Failed to save edits." }
            }
        } else {
            _statusMessage.value = "Updated active project source in session."
        }
    }

    fun saveScenarioSnapshot(
        projectId: String,
        label: String,
        computedResult: String,
        unit: String,
        numericSnapshot: Map<String, Float>,
        toggleSnapshot: Map<String, Boolean>,
        textSnapshot: Map<String, String>
    ) {
        if (checkGuestGate("Scenario Snapshots")) return
        val currentList = _scenarioSnapshots.value[projectId].orEmpty()
        val snap = SandboxScenarioSnapshot(
            id = UUID.randomUUID().toString().take(8),
            label = label.ifBlank { "Scenario ${currentList.size + 1}" },
            computedResult = computedResult,
            unit = unit,
            numericSnapshot = numericSnapshot.toMap(),
            toggleSnapshot = toggleSnapshot.toMap(),
            textSnapshot = textSnapshot.toMap()
        )
        _scenarioSnapshots.value = _scenarioSnapshots.value + (projectId to (listOf(snap) + currentList))
        _statusMessage.value = "Captured scenario snapshot '${snap.label}'."
    }

    fun deleteScenarioSnapshot(projectId: String, snapshotId: String) {
        if (checkGuestGate("Scenario Snapshots")) return
        val currentList = _scenarioSnapshots.value[projectId].orEmpty()
        _scenarioSnapshots.value = _scenarioSnapshots.value + (projectId to currentList.filterNot { it.id == snapshotId })
    }

    fun togglePinProject(project: StudioProject) {
        if (checkGuestGate("Project Pinning")) return
        viewModelScope.launch {
            val result = repository.togglePin(project)
            result.onFailure { e ->
                _statusMessage.value = e.localizedMessage ?: "Failed to update project pin state."
            }
        }
    }

    fun deleteProject(project: StudioProject) {
        if (checkGuestGate("Project Deletion")) return
        viewModelScope.launch {
            val result = repository.deleteProject(project.id)
            result.onSuccess {
                if (_activeProject.value?.id == project.id) {
                    _activeProject.value = null
                }
                if (_activeWebsiteProject.value?.id == project.id) {
                    _activeWebsiteProject.value = null
                }
                _statusMessage.value = "Removed '${project.title}' from workspace."
            }.onFailure { e ->
                _statusMessage.value = e.localizedMessage ?: "Failed to delete project."
            }
        }
    }

    fun exportProjectToUri(context: Context, project: StudioProject, uri: Uri) {
        if (checkGuestGate("Project Archive Export")) return
        viewModelScope.launch {
            val result = ProjectArchiveExporter.exportToUri(
                context = context,
                project = project,
                targetUri = uri,
                includeFullGradleScaffold = _apiConfig.value.includeFullGradleScaffold
            )
            result.onSuccess { summary ->
                _exportBanner.value = summary
            }.onFailure { err ->
                _statusMessage.value = err.localizedMessage ?: "Failed to export project archive."
            }
        }
    }

    fun exportProjectToWorkspace(context: Context, project: StudioProject) {
        if (checkGuestGate("Workspace Archive Export")) return
        viewModelScope.launch {
            val result = ProjectArchiveExporter.exportToInternalWorkspace(
                context = context,
                project = project,
                includeFullGradleScaffold = _apiConfig.value.includeFullGradleScaffold
            )
            result.onSuccess { summary ->
                _exportBanner.value = summary
            }.onFailure { err ->
                _statusMessage.value = err.localizedMessage ?: "Failed to package workspace archive."
            }
        }
    }

    fun postStatusMessage(message: String) {
        _statusMessage.value = message
    }

    fun saveConvertedWebAppToWorkspace(
        config: ConvertedAppConfig,
        bundle: ExtractedWebBundle,
        onSavedToSandbox: () -> Unit = {}
    ) {
        if (checkGuestGate("HTML/ZIP to Android App Converter")) return
        viewModelScope.launch {
            val convertedProject = WebToAndroidAppPackager.buildStudioProjectFromConverter(
                userId = currentUserId,
                config = config,
                bundle = bundle,
                providerId = _apiConfig.value.selectedProvider.id,
                modelId = _apiConfig.value.selectedModel.modelId
            )
            val saveRes = repository.createProject(convertedProject)
            saveRes.onSuccess { savedId ->
                val persistedProject = if (savedId.isNotBlank()) {
                    convertedProject.copy(id = savedId)
                } else {
                    convertedProject
                }
                _activeProject.value = persistedProject
                _statusMessage.value = "Saved converted app '${config.appName}' to Studio Workspace!"
                onSavedToSandbox()
            }.onFailure { err ->
                _statusMessage.value = err.localizedMessage ?: "Failed to save converted app to workspace."
            }
        }
    }

    fun exportConvertedAppZipToUri(
        context: Context,
        config: ConvertedAppConfig,
        bundle: ExtractedWebBundle,
        targetUri: Uri
    ) {
        if (checkGuestGate("Converted Android Project Export")) return
        viewModelScope.launch {
            val result = WebToAndroidAppPackager.exportConvertedAppZipToUri(
                context = context,
                config = config,
                bundle = bundle,
                targetUri = targetUri
            )
            result.onSuccess { summary ->
                _exportBanner.value = summary
                _statusMessage.value = "Exported Android Studio project archive: ${summary.archiveFileName}"
            }.onFailure { err ->
                _statusMessage.value = err.localizedMessage ?: "Failed to export converted Android project."
            }
        }
    }

    fun exportConvertedAppZipToWorkspace(
        context: Context,
        config: ConvertedAppConfig,
        bundle: ExtractedWebBundle
    ) {
        if (checkGuestGate("Converted Android Project Packaging")) return
        viewModelScope.launch {
            val result = WebToAndroidAppPackager.exportConvertedAppZipToWorkspace(
                context = context,
                config = config,
                bundle = bundle
            )
            result.onSuccess { summary ->
                _exportBanner.value = summary
                _statusMessage.value = "Packaged converted Android app in workspace: ${summary.archiveFileName}"
            }.onFailure { err ->
                _statusMessage.value = err.localizedMessage ?: "Failed to package converted Android project."
            }
        }
    }

    fun exportInstalledStudioApkToUri(
        context: Context,
        targetUri: Uri
    ) {
        viewModelScope.launch {
            val result = ProjectArchiveExporter.exportInstalledStudioApkToUri(
                context = context,
                targetUri = targetUri
            )
            result.onSuccess { summary ->
                _exportBanner.value = summary
                _statusMessage.value = "Saved signed APK (${summary.archiveFileName}) to device storage!"
            }.onFailure { err ->
                _statusMessage.value = err.localizedMessage ?: "Failed to export APK to device storage."
            }
        }
    }

    fun exportFullStudioBundleZipToUri(
        context: Context,
        targetUri: Uri
    ) {
        viewModelScope.launch {
            val currentProjects = (projectsState.value as? ProjectsUiState.Success)?.projects.orEmpty()
            val result = ProjectArchiveExporter.exportFullStudioBundleZipToUri(
                context = context,
                projects = currentProjects,
                targetUri = targetUri
            )
            result.onSuccess { summary ->
                _exportBanner.value = summary
                _statusMessage.value = "Saved Full App & APK Bundle (${summary.archiveFileName}) to device storage!"
            }.onFailure { err ->
                _statusMessage.value = err.localizedMessage ?: "Failed to export Full App ZIP bundle."
            }
        }
    }
}
