package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.ArkChallenge
import com.example.data.model.ChallengeProgress
import com.example.data.model.FriendEdge
import com.example.data.model.UserProfile
import com.example.ui.components.ArkAvatarBadge
import com.example.ui.components.EmptyStateGlassCard
import com.example.ui.components.GlowingPillButton
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.UserBadgeChip
import com.example.ui.theme.ArkThemeTokens

@Composable
fun ChallengesScreen(
    challenges: List<ArkChallenge>,
    progressMap: Map<String, ChallengeProgress>,
    onBack: () -> Unit,
    onCompleteChallenge: (ArkChallenge, String) -> Unit,
    onSkipChallenge: (String) -> Unit,
    onShareChallengeResult: (ArkChallenge, String) -> Unit = { _, _ -> }
) {
    BackHandler(onBack = onBack)

    val colors = ArkThemeTokens.colors
    var selectedCategory by remember { mutableStateOf("All") }
    var selectedTab by remember { mutableIntStateOf(0) }
    var completingTarget by remember { mutableStateOf<ArkChallenge?>(null) }
    var reflectionNote by remember { mutableStateOf("") }
    var shareToFeedAfterComplete by remember { mutableStateOf(true) }

    val categories = listOf("All", "Friendship", "Creativity", "Knowledge", "Teamwork", "School-Friendly", "Brain", "Fun")
    val activeList = challenges.filter {
        val status = progressMap[it.id]?.status
        val catOk = selectedCategory == "All" || it.category == selectedCategory
        status == null && catOk
    }
    val historyList = challenges.filter { progressMap[it.id] != null }

    Column(modifier = Modifier.fillMaxSize()) {
        Surface(color = colors.glassSurfaceElevated) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                }
                Column {
                    Text("Real-Life Challenges", style = MaterialTheme.typography.titleLarge, color = colors.textPrimary)
                    Text("Safe, voluntary & school-friendly missions", style = MaterialTheme.typography.bodySmall, color = colors.emerald)
                }
            }
        }

        TabRow(selectedTabIndex = selectedTab, containerColor = colors.glassSurface) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Active (${activeList.size})") })
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("History (${historyList.size})") })
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                        .clip(RoundedCornerShape(22.dp))
                ) {
                    AsyncImage(
                        model = R.drawable.img_challenges_banner,
                        contentDescription = "Real-life challenges artwork",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    Column(
                        modifier = Modifier.fillMaxSize().padding(14.dp),
                        verticalArrangement = Arrangement.Bottom
                    ) {
                        Text("Earn Fair Points Offline & IRL", style = MaterialTheme.typography.titleMedium, color = colors.textPrimary)
                        Text("Never requires photos or unsafe stunts — skip anytime", style = MaterialTheme.typography.bodySmall, color = colors.emerald)
                    }
                }
            }

            if (selectedTab == 0) {
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(categories) { cat ->
                            FilterChip(
                                selected = selectedCategory == cat,
                                onClick = { selectedCategory = cat },
                                label = { Text(cat) }
                            )
                        }
                    }
                }

                if (activeList.isEmpty()) {
                    item {
                        EmptyStateGlassCard(
                            icon = Icons.Default.CheckCircle,
                            title = "All Challenges Cleared!",
                            subtitle = "Check back tomorrow for fresh daily missions or switch categories."
                        )
                    }
                } else {
                    items(activeList, key = { it.id }) { ch ->
                        LiquidGlassCard(modifier = Modifier.fillMaxWidth(), accentColor = colors.emerald) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                UserBadgeChip(label = "${ch.frequency} • ${ch.category}", accent = colors.cyan)
                                UserBadgeChip(label = "+${ch.rewardPoints} PTS", accent = colors.gold)
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(ch.title, style = MaterialTheme.typography.titleMedium, color = colors.textPrimary)
                            Spacer(Modifier.height(4.dp))
                            Text(ch.description, style = MaterialTheme.typography.bodyMedium, color = colors.textSecondary)
                            Spacer(Modifier.height(6.dp))
                            Text("${ch.difficulty} • ${ch.expiresLabel}", style = MaterialTheme.typography.labelSmall, color = colors.textSecondary)
                            Spacer(Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                                GlowingPillButton(
                                    text = "Complete",
                                    icon = Icons.Default.CheckCircle,
                                    accent = colors.emerald,
                                    onClick = { completingTarget = ch },
                                    modifier = Modifier.weight(1f).testTag("complete_challenge_${ch.id}")
                                )
                                OutlinedButton(
                                    onClick = { onSkipChallenge(ch.id) },
                                    modifier = Modifier.height(50.dp),
                                    shape = RoundedCornerShape(25.dp)
                                ) {
                                    Icon(Icons.Default.SkipNext, contentDescription = "Skip challenge")
                                    Spacer(Modifier.width(4.dp))
                                    Text("Skip")
                                }
                            }
                        }
                    }
                }
            } else {
                if (historyList.isEmpty()) {
                    item {
                        EmptyStateGlassCard(
                            icon = Icons.Default.EmojiEvents,
                            title = "No Challenge History Yet",
                            subtitle = "Complete your first safe real-life challenge to earn badges and points!"
                        )
                    }
                } else {
                    items(historyList, key = { it.id }) { ch ->
                        val prog = progressMap[ch.id]
                        LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(ch.title, style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                                    if (!prog?.reflectionNote.isNullOrBlank()) {
                                        Text("Note: ${prog?.reflectionNote}", style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
                                    }
                                }
                                UserBadgeChip(
                                    label = if (prog?.status == "completed") "+${prog.pointsAwarded} PTS" else "Skipped",
                                    accent = if (prog?.status == "completed") colors.emerald else colors.textSecondary
                                )
                                if (prog?.status == "completed") {
                                    IconButton(
                                        onClick = { onShareChallengeResult(ch, prog.reflectionNote.orEmpty()) }
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = "Share challenge to feed", tint = colors.cyan)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (completingTarget != null) {
        val ch = completingTarget!!
        AlertDialog(
            onDismissRequest = { completingTarget = null },
            title = { Text("Complete '${ch.title}'") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Add an optional short reflection note (no photos or private info required):",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = reflectionNote,
                        onValueChange = { reflectionNote = it.take(240) },
                        label = { Text("Optional reflection") },
                        maxLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = shareToFeedAfterComplete,
                            onCheckedChange = { shareToFeedAfterComplete = it }
                        )
                        Text("Share milestone post to ARK Feed", style = MaterialTheme.typography.bodySmall)
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onCompleteChallenge(ch, reflectionNote)
                        if (shareToFeedAfterComplete) {
                            onShareChallengeResult(ch, reflectionNote)
                        }
                        reflectionNote = ""
                        completingTarget = null
                    }
                ) { Text("Claim +${ch.rewardPoints} PTS") }
            },
            dismissButton = {
                TextButton(onClick = { completingTarget = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun LeaderboardScreen(
    currentUser: UserProfile,
    globalLeaderboard: List<UserProfile>,
    friends: List<FriendEdge>,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    val colors = ArkThemeTokens.colors
    var selectedTab by remember { mutableIntStateOf(0) }
    val friendUids = remember(friends, currentUser.userId) {
        friends.map { it.friendUid }.toSet() + currentUser.userId
    }
    val displayed = when (selectedTab) {
        0 -> globalLeaderboard.filter { friendUids.contains(it.userId) }
        else -> globalLeaderboard
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Surface(color = colors.glassSurfaceElevated) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = colors.textPrimary)
                }
                Column {
                    Text("ARK Leaderboards", style = MaterialTheme.typography.titleLarge, color = colors.textPrimary)
                    Text("Fair play rankings • Usernames only • Opt-out supported", style = MaterialTheme.typography.bodySmall, color = colors.gold)
                }
            }
        }

        TabRow(selectedTabIndex = selectedTab, containerColor = colors.glassSurface) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Friends") })
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Weekly / Global") })
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (currentUser.optOutLeaderboard) {
                item {
                    LiquidGlassCard(modifier = Modifier.fillMaxWidth(), accentColor = colors.violet) {
                        Text(
                            "You have opted out of public rankings in Privacy Settings. Only your friends see your progress.",
                            style = MaterialTheme.typography.bodySmall,
                            color = colors.textSecondary
                        )
                    }
                }
            }

            if (displayed.isEmpty()) {
                item {
                    EmptyStateGlassCard(
                        icon = Icons.Default.EmojiEvents,
                        title = "No Rankings Yet",
                        subtitle = "Play multiplayer games or complete safe challenges to climb the leaderboard."
                    )
                }
            } else {
                items(displayed, key = { it.userId }) { player ->
                    val rank = displayed.indexOf(player) + 1
                    val isMe = player.userId == currentUser.userId
                    LiquidGlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        accentColor = if (rank <= 3) colors.gold else if (isMe) colors.cyan else null
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "#$rank",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = if (rank <= 3) colors.gold else colors.textSecondary,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.width(36.dp)
                                )
                                ArkAvatarBadge(
                                    avatarPreset = player.avatarPreset,
                                    username = player.username,
                                    size = 42.dp
                                )
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = if (isMe) "@${player.username} (You)" else "@${player.username}",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = colors.textPrimary
                                    )
                                    Text(
                                        text = "LVL ${player.level} • ${player.badges.firstOrNull() ?: "Player"}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = colors.textSecondary
                                    )
                                }
                            }
                            Text(
                                text = "${player.points} PTS",
                                style = MaterialTheme.typography.labelLarge,
                                color = colors.cyan
                            )
                        }
                    }
                }
            }
        }
    }
}
