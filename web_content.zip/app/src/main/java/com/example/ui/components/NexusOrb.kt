package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.NexusCyan
import com.example.ui.theme.NexusCyanDim
import com.example.ui.theme.NexusViolet
import com.example.ui.theme.NexusVioletLight
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

enum class OrbState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING
}

@Composable
fun NexusOrb(
    state: OrbState,
    audioAmplitude: Float = 0f,
    modifier: Modifier = Modifier,
    size: Dp = 240.dp,
    onClick: () -> Unit = {}
) {
    val infiniteTransition = rememberInfiniteTransition(label = "aurora_orb")

    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 5200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "orb_phase"
    )

    val breath by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "orb_breath"
    )

    val animatedAmp = remember { Animatable(0f) }
    LaunchedEffect(audioAmplitude) {
        animatedAmp.animateTo(
            targetValue = audioAmplitude,
            animationSpec = tween(durationMillis = 75, easing = LinearEasing)
        )
    }

    val corePrimary = when (state) {
        OrbState.IDLE -> NexusCyan
        OrbState.LISTENING -> NexusVioletLight
        OrbState.THINKING -> NexusViolet
        OrbState.SPEAKING -> NexusCyan
    }

    val coreSecondary = when (state) {
        OrbState.IDLE -> NexusCyanDim
        OrbState.LISTENING -> NexusCyan
        OrbState.THINKING -> Color(0xFF4C1D95)
        OrbState.SPEAKING -> NexusVioletLight
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(size)
            .testTag("nexus_orb")
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) { onClick() }
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val baseRadius = this.size.minDimension / 2f * 0.56f

            val dynamicAmp = when (state) {
                OrbState.IDLE -> 0.025f
                OrbState.LISTENING -> 0.06f + animatedAmp.value * 0.22f
                OrbState.THINKING -> 0.08f
                OrbState.SPEAKING -> 0.09f + 0.05f * sin(phase * 2.5f)
            }

            val radius = baseRadius * when (state) {
                OrbState.IDLE -> breath
                OrbState.LISTENING -> 1.02f + animatedAmp.value * 0.24f
                OrbState.THINKING -> breath * 1.03f
                OrbState.SPEAKING -> 1.03f + (breath - 1f) * 1.4f
            }

            // 1. Soft radial obsidian-violet aura
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        corePrimary.copy(alpha = 0.28f),
                        coreSecondary.copy(alpha = 0.12f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = radius * 1.78f
                ),
                radius = radius * 1.78f,
                center = center
            )

            // 2. Organic fluid outer wave contour (ChatGPT Voice style)
            val outerWave = buildOrganicBlobPath(
                center = center,
                radius = radius * 1.12f,
                wobble = radius * dynamicAmp,
                phase = phase,
                lobes = 5
            )
            drawPath(
                path = outerWave,
                color = NexusVioletLight.copy(alpha = 0.28f),
                style = Stroke(width = 1.5.dp.toPx())
            )

            // 3. Secondary counter-flowing fluid contour
            val midWave = buildOrganicBlobPath(
                center = center,
                radius = radius * 1.04f,
                wobble = radius * (dynamicAmp * 0.85f),
                phase = -phase * 1.3f,
                lobes = 4
            )
            drawPath(
                path = midWave,
                brush = Brush.sweepGradient(
                    colors = listOf(
                        corePrimary.copy(alpha = 0.55f),
                        coreSecondary.copy(alpha = 0.25f),
                        NexusVioletLight.copy(alpha = 0.6f),
                        corePrimary.copy(alpha = 0.55f)
                    ),
                    center = center
                ),
                style = Stroke(width = 2.dp.toPx())
            )

            // 4. Smooth fluid sphere fill
            val coreBlob = buildOrganicBlobPath(
                center = center,
                radius = radius,
                wobble = radius * (dynamicAmp * 0.65f),
                phase = phase * 0.9f,
                lobes = 3
            )
            drawPath(
                path = coreBlob,
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFFF5F3FF).copy(alpha = 0.92f),
                        NexusVioletLight.copy(alpha = 0.88f),
                        corePrimary.copy(alpha = 0.85f),
                        coreSecondary.copy(alpha = 0.92f),
                        Color(0xFF160B2E)
                    ),
                    center = Offset(
                        center.x - radius * 0.18f,
                        center.y - radius * 0.22f
                    ),
                    radius = radius * 1.25f
                )
            )
        }
    }
}

private fun buildOrganicBlobPath(
    center: Offset,
    radius: Float,
    wobble: Float,
    phase: Float,
    lobes: Int
): Path {
    val path = Path()
    val steps = 72
    for (i in 0..steps) {
        val t = (i.toFloat() / steps) * (2f * PI.toFloat())
        val modulation = sin(t * lobes + phase) * 0.6f + cos(t * (lobes - 1) - phase * 0.8f) * 0.4f
        val r = radius + wobble * modulation
        val x = center.x + r * cos(t)
        val y = center.y + r * sin(t)
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    return path
}
