package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.NexusCyan
import com.example.ui.theme.NexusCyanDim
import com.example.ui.theme.NexusEmerald
import com.example.ui.theme.NexusViolet
import com.example.ui.theme.NexusVioletLight
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

enum class OrbState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING
}

@Composable
fun NexusOrb(
    state: OrbState,
    audioAmplitude: Float = 0f,
    modifier: Modifier = Modifier,
    size: Dp = 240.dp,
    onClick: () -> Unit = {}
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb_infinite")

    // Rotation angle for futuristic cybernetic rings
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    // Counter rotation for secondary ring
    val counterRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "counter_rotation"
    )

    // Breathing pulse for idle & thinking
    val idlePulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "idle_pulse"
    )

    // Fast pulse for thinking state
    val thinkingGlow by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 650, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "thinking_glow"
    )

    val animatedAmp = remember { Animatable(0f) }
    LaunchedEffect(audioAmplitude) {
        animatedAmp.animateTo(
            targetValue = audioAmplitude,
            animationSpec = tween(durationMillis = 80, easing = LinearEasing)
        )
    }

    val primaryColor = when (state) {
        OrbState.IDLE -> NexusCyan
        OrbState.LISTENING -> NexusEmerald
        OrbState.THINKING -> NexusVioletLight
        OrbState.SPEAKING -> NexusCyan
    }

    val secondaryColor = when (state) {
        OrbState.IDLE -> NexusViolet
        OrbState.LISTENING -> NexusCyan
        OrbState.THINKING -> NexusCyan
        OrbState.SPEAKING -> NexusViolet
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(size)
            .testTag("nexus_orb")
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) { onClick() }
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val baseRadius = this.size.minDimension / 2f * 0.65f

            // Dynamic scale factor based on state and microphone/speech amplitude
            val scale = when (state) {
                OrbState.IDLE -> idlePulse
                OrbState.LISTENING -> 1.0f + animatedAmp.value * 0.35f
                OrbState.THINKING -> idlePulse * 1.02f
                OrbState.SPEAKING -> 1.0f + (sin(rotationAngle * 0.1f) * 0.05f) + (idlePulse - 1f) * 2f
            }

            val currentRadius = baseRadius * scale

            // 1. Ambient outer glow halo
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        primaryColor.copy(alpha = if (state == OrbState.THINKING) 0.35f * thinkingGlow else 0.25f),
                        secondaryColor.copy(alpha = 0.08f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = currentRadius * 1.6f
                ),
                radius = currentRadius * 1.6f,
                center = center
            )

            // 2. Outer cybernetic segmented ring
            drawCyberRing(
                center = center,
                radius = currentRadius * 1.25f,
                angleOffset = rotationAngle,
                color = primaryColor.copy(alpha = 0.5f),
                segments = 8,
                strokeWidth = 2.5.dp.toPx()
            )

            // 3. Middle reverse-rotating dotted ring
            drawDottedRing(
                center = center,
                radius = currentRadius * 1.1f,
                angleOffset = counterRotation,
                color = secondaryColor.copy(alpha = 0.65f),
                dots = 16,
                dotRadius = 2.dp.toPx()
            )

            // 4. Central Core: Multilayered vibrant glowing neural sphere
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.9f),
                        primaryColor.copy(alpha = 0.85f),
                        secondaryColor.copy(alpha = 0.7f),
                        NexusCyanDim.copy(alpha = 0.4f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = currentRadius
                ),
                radius = currentRadius,
                center = center
            )

            // 5. Internal holographic lattice / crosshairs
            val innerCoreRadius = currentRadius * 0.45f
            drawCircle(
                color = Color.White.copy(alpha = 0.4f),
                radius = innerCoreRadius,
                center = center,
                style = Stroke(width = 1.5.dp.toPx())
            )

            // Micro nodes at 4 compass directions
            val compassPoints = listOf(0f, 90f, 180f, 270f)
            for (p in compassPoints) {
                val rad = (p + rotationAngle) * PI / 180f
                val dotX = center.x + (innerCoreRadius * cos(rad)).toFloat()
                val dotY = center.y + (innerCoreRadius * sin(rad)).toFloat()
                drawCircle(
                    color = Color.White,
                    radius = 3.dp.toPx(),
                    center = Offset(dotX, dotY)
                )
            }
        }
    }
}

private fun DrawScope.drawCyberRing(
    center: Offset,
    radius: Float,
    angleOffset: Float,
    color: Color,
    segments: Int,
    strokeWidth: Float
) {
    val sweepAngle = 360f / segments
    val gapAngle = 14f
    val segmentSweep = sweepAngle - gapAngle

    for (i in 0 until segments) {
        val startAngle = (i * sweepAngle) + angleOffset
        drawArc(
            color = color,
            startAngle = startAngle,
            sweepAngle = segmentSweep,
            useCenter = false,
            topLeft = Offset(center.x - radius, center.y - radius),
            size = androidx.compose.ui.geometry.Size(radius * 2, radius * 2),
            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
        )
    }
}

private fun DrawScope.drawDottedRing(
    center: Offset,
    radius: Float,
    angleOffset: Float,
    color: Color,
    dots: Int,
    dotRadius: Float
) {
    val step = 360f / dots
    for (i in 0 until dots) {
        val angleDeg = (i * step) + angleOffset
        val angleRad = angleDeg * PI / 180f
        val x = center.x + (radius * cos(angleRad)).toFloat()
        val y = center.y + (radius * sin(angleRad)).toFloat()
        drawCircle(
            color = color,
            radius = dotRadius,
            center = Offset(x, y)
        )
    }
}
