package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BedrockPlayer
import com.example.ui.ChaufalandViewModel
import com.example.ui.components.DimensionBadge
import com.example.ui.components.MinecraftCard
import com.example.ui.components.PlayerAvatar
import com.example.ui.theme.MinecraftBorder
import com.example.ui.theme.MinecraftDiamond
import com.example.ui.theme.MinecraftEmerald
import com.example.ui.theme.MinecraftGold
import com.example.ui.theme.MinecraftRedstone
import com.example.ui.theme.MinecraftSurfaceVariant
import com.example.ui.theme.MinecraftText
import com.example.ui.theme.MinecraftTextDim

@Composable
fun RadarScreen(viewModel: ChaufalandViewModel, modifier: Modifier = Modifier) {
  val bedrockPlayers by viewModel.bedrockPlayers.collectAsState()
  val adminConfig by viewModel.adminConfig.collectAsState()

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(12.dp)
  ) {
    MinecraftCard {
      Column(modifier = Modifier.fillMaxWidth()) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "🧭 RADAR BEDROCK EN VIVO",
            color = MinecraftGold,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
          )
          Box(
            modifier = Modifier
              .background(MinecraftEmerald, RoundedCornerShape(2.dp))
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text(
              text = "PUENTE BEDROCK",
              color = Color.White,
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              fontFamily = FontFamily.Monospace
            )
          }
        }

        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = "Receptando datos de Script API (@minecraft/server y @minecraft/server-net):",
          color = MinecraftTextDim,
          fontSize = 11.sp,
          fontFamily = FontFamily.Monospace
        )
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    if (bedrockPlayers.isEmpty()) {
      MinecraftCard {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Text(text = "🛰️", fontSize = 36.sp)
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "Esperando telemetría del Addon Bedrock...",
            color = MinecraftGold,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
          )
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "Instala 'scripts/main.js' en la carpeta behavior_packs de tu servidor Bedrock para ver coordenadas y dimensiones aquí.",
            color = MinecraftTextDim,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            lineHeight = 16.sp
          )
        }
      }
    } else {
      LazyColumn(
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.weight(1f)
      ) {
        items(bedrockPlayers) { player ->
          BedrockPlayerCard(player = player)
        }
      }
    }
  }
}

@Composable
private fun BedrockPlayerCard(player: BedrockPlayer) {
  MinecraftCard {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically
    ) {
      PlayerAvatar(gamerTag = player.gamerTag, size = 42.dp)
      Spacer(modifier = Modifier.width(10.dp))

      Column(modifier = Modifier.weight(1f)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = player.gamerTag,
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
          )
          DimensionBadge(dimension = player.dimension)
        }

        Spacer(modifier = Modifier.height(4.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = "X: ${player.x}  Y: ${player.y}  Z: ${player.z}",
            color = MinecraftDiamond,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = FontFamily.Monospace
          )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(text = "❤️", fontSize = 11.sp)
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "Vida: ${player.health}/20",
            color = MinecraftRedstone,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace
          )
        }
      }
    }
  }
}
