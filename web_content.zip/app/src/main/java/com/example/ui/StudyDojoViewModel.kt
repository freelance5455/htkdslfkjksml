package com.example.ui

import android.app.Application
import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.CombinedVibration
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.Chapter
import com.example.data.ChatMessage
import com.example.data.DefaultData
import com.example.data.NinjaRank
import com.example.data.PreferencesManager
import com.example.data.QuizQuestion
import com.example.data.QuizResult
import com.example.data.SenseiCharacter
import com.example.data.StudySession
import com.example.data.Subject
import com.example.data.WrongAnswerDetail
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Calendar

enum class DojoTab(val label: String) {
  SYLLABUS("Syllabus"),
  TIMER("Ninja Timer"),
  QUIZ("Quiz Dojo"),
  SENSEI_CHAT("Sensei Chat"),
  STATS("Shinobi Profile")
}

enum class ChapterFilter {
  ALL, COMPLETED, PENDING
}

enum class QuizMode {
  SELECTION, PLAYING, RESULT, REVIEW_WRONG, HISTORY
}

data class DojoUiState(
  val currentTab: DojoTab = DojoTab.SYLLABUS,
  val isDarkMode: Boolean = true,

  // Syllabus
  val chapters: List<Chapter> = emptyList(),
  val selectedSubjectFilter: Subject? = null,
  val chapterFilter: ChapterFilter = ChapterFilter.ALL,
  val syllabusSearchQuery: String = "",

  // Timer
  val timerSubject: Subject = Subject.COMPUTER_SCIENCE,
  val timerTotalSeconds: Int = 25 * 60,
  val timerRemainingSeconds: Int = 25 * 60,
  val isTimerRunning: Boolean = false,
  val isTimerPaused: Boolean = false,
  val timerFinishedDialog: Boolean = false,
  val lastLoggedMinutes: Int = 0,

  // Sessions / Stats
  val studySessions: List<StudySession> = emptyList(),

  // Quiz
  val quizMode: QuizMode = QuizMode.SELECTION,
  val quizSelectedSubject: Subject = Subject.COMPUTER_SCIENCE,
  val quizQuestions: List<QuizQuestion> = emptyList(),
  val currentQuizQuestionIndex: Int = 0,
  val selectedOptionIndex: Int? = null,
  val isAnswerRevealed: Boolean = false,
  val currentQuizScore: Int = 0,
  val quizResults: List<QuizResult> = emptyList(),
  val activeQuizResult: QuizResult? = null,

  // Doubt Chat
  val activeSensei: SenseiCharacter = SenseiCharacter.NARUTO,
  val chatMessages: List<ChatMessage> = emptyList(),
  val chatInputText: String = "",
  val isSenseiTyping: Boolean = false
) {
  val overallProgressPercent: Int
    get() {
      if (chapters.isEmpty()) return 0
      val done = chapters.count { it.isCompleted }
      return (done * 100) / chapters.size
    }

  val ninjaRank: NinjaRank
    get() = NinjaRank.calculateRank(overallProgressPercent)

  fun getSubjectProgress(subject: Subject): Int {
    val subjectChapters = chapters.filter { it.subject == subject }
    if (subjectChapters.isEmpty()) return 0
    val done = subjectChapters.count { it.isCompleted }
    return (done * 100) / subjectChapters.size
  }

  val todayStudyMinutes: Int
    get() {
      val cal = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
      }
      val startOfDay = cal.timeInMillis
      return studySessions.filter { it.timestamp >= startOfDay }.sumOf { it.durationMinutes }
    }

  val weeklyStudyMinutes: Int
    get() {
      val cal = Calendar.getInstance().apply {
        add(Calendar.DAY_OF_YEAR, -7)
      }
      val sevenDaysAgo = cal.timeInMillis
      return studySessions.filter { it.timestamp >= sevenDaysAgo }.sumOf { it.durationMinutes }
    }

  val subjectMinutesMap: Map<Subject, Int>
    get() {
      val map = mutableMapOf<Subject, Int>()
      Subject.entries.forEach { sub ->
        map[sub] = studySessions.filter { it.subject == sub }.sumOf { it.durationMinutes }
      }
      return map
    }
}

class StudyDojoViewModel(application: Application) : AndroidViewModel(application) {
  private val prefsManager = PreferencesManager(application)

  private val _uiState = MutableStateFlow(DojoUiState())
  val uiState: StateFlow<DojoUiState> = _uiState.asStateFlow()

  private var timerJob: Job? = null

  init {
    loadInitialData()
  }

  private fun loadInitialData() {
    val isDark = prefsManager.isDarkMode()
    val chapters = prefsManager.loadChapters()
    val sessions = prefsManager.loadStudySessions()
    val quizzes = prefsManager.loadQuizResults()
    val messages = prefsManager.loadChatMessages()

    _uiState.update {
      it.copy(
        isDarkMode = isDark,
        chapters = chapters,
        studySessions = sessions,
        quizResults = quizzes,
        chatMessages = messages
      )
    }
  }

  fun switchTab(tab: DojoTab) {
    _uiState.update { it.copy(currentTab = tab) }
  }

  fun toggleDarkMode() {
    val newMode = !_uiState.value.isDarkMode
    prefsManager.setDarkMode(newMode)
    _uiState.update { it.copy(isDarkMode = newMode) }
  }

  // --- Syllabus Logic ---
  fun filterBySubject(subject: Subject?) {
    _uiState.update { it.copy(selectedSubjectFilter = subject) }
  }

  fun setChapterStatusFilter(filter: ChapterFilter) {
    _uiState.update { it.copy(chapterFilter = filter) }
  }

  fun updateSyllabusSearch(query: String) {
    _uiState.update { it.copy(syllabusSearchQuery = query) }
  }

  fun toggleChapter(chapterId: String) {
    val updated = _uiState.value.chapters.map {
      if (it.id == chapterId) it.copy(isCompleted = !it.isCompleted) else it
    }
    prefsManager.saveChapters(updated)
    _uiState.update { it.copy(chapters = updated) }
  }

  fun addCustomChapter(subject: Subject, title: String) {
    if (title.isBlank()) return
    val newChapter = Chapter(
      id = "custom_${System.currentTimeMillis()}",
      subject = subject,
      title = title.trim(),
      isCompleted = false,
      isCustom = true
    )
    val updated = _uiState.value.chapters + newChapter
    prefsManager.saveChapters(updated)
    _uiState.update { it.copy(chapters = updated) }
  }

  fun renameChapter(chapterId: String, newTitle: String) {
    if (newTitle.isBlank()) return
    val updated = _uiState.value.chapters.map {
      if (it.id == chapterId) it.copy(title = newTitle.trim()) else it
    }
    prefsManager.saveChapters(updated)
    _uiState.update { it.copy(chapters = updated) }
  }

  fun deleteChapter(chapterId: String) {
    val updated = _uiState.value.chapters.filterNot { it.id == chapterId }
    prefsManager.saveChapters(updated)
    _uiState.update { it.copy(chapters = updated) }
  }

  // --- Study Timer Logic ---
  fun setTimerSubject(subject: Subject) {
    _uiState.update { it.copy(timerSubject = subject) }
  }

  fun setTimerPresetMinutes(minutes: Int) {
    timerJob?.cancel()
    val seconds = minutes * 60
    _uiState.update {
      it.copy(
        timerTotalSeconds = seconds,
        timerRemainingSeconds = seconds,
        isTimerRunning = false,
        isTimerPaused = false
      )
    }
  }

  fun startTimer() {
    if (_uiState.value.isTimerRunning && !_uiState.value.isTimerPaused) return

    _uiState.update { it.copy(isTimerRunning = true, isTimerPaused = false) }

    timerJob?.cancel()
    timerJob = viewModelScope.launch {
      while (isActive && _uiState.value.timerRemainingSeconds > 0) {
        delay(1000L)
        val remaining = _uiState.value.timerRemainingSeconds - 1
        _uiState.update { it.copy(timerRemainingSeconds = remaining) }
      }

      if (_uiState.value.timerRemainingSeconds <= 0) {
        onTimerComplete()
      }
    }
  }

  fun pauseTimer() {
    timerJob?.cancel()
    _uiState.update { it.copy(isTimerPaused = true) }
  }

  fun resumeTimer() {
    startTimer()
  }

  fun resetTimer() {
    timerJob?.cancel()
    _uiState.update {
      it.copy(
        timerRemainingSeconds = it.timerTotalSeconds,
        isTimerRunning = false,
        isTimerPaused = false
      )
    }
  }

  private fun onTimerComplete() {
    val durationMin = _uiState.value.timerTotalSeconds / 60
    val savedSession = prefsManager.addStudySession(_uiState.value.timerSubject, durationMin)
    val updatedSessions = prefsManager.loadStudySessions()

    playBeepAndVibrate()

    _uiState.update {
      it.copy(
        isTimerRunning = false,
        isTimerPaused = false,
        timerRemainingSeconds = it.timerTotalSeconds,
        timerFinishedDialog = true,
        lastLoggedMinutes = durationMin,
        studySessions = updatedSessions
      )
    }
  }

  fun dismissTimerDialog() {
    _uiState.update { it.copy(timerFinishedDialog = false) }
  }

  private fun playBeepAndVibrate() {
    try {
      val toneGen = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100)
      toneGen.startTone(ToneGenerator.TONE_PROP_BEEP2, 1200)
    } catch (_: Exception) {}

    try {
      val context = getApplication<Application>()
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        val vibrator = vibratorManager?.defaultVibrator
        vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 300, 200, 400), -1))
      } else {
        @Suppress("DEPRECATION")
        val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
          vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 300, 200, 400), -1))
        } else {
          @Suppress("DEPRECATION")
          vibrator?.vibrate(longArrayOf(0, 300, 200, 400), -1)
        }
      }
    } catch (_: Exception) {}
  }

  // --- Quiz Engine Logic ---
  fun setQuizSubject(subject: Subject) {
    _uiState.update { it.copy(quizSelectedSubject = subject) }
  }

  fun startQuiz(subject: Subject) {
    val allQuestions = DefaultData.getQuestionBank().filter { it.subject == subject }
    val selected = allQuestions.shuffled().take(10)

    _uiState.update {
      it.copy(
        quizSelectedSubject = subject,
        quizQuestions = selected,
        currentQuizQuestionIndex = 0,
        selectedOptionIndex = null,
        isAnswerRevealed = false,
        currentQuizScore = 0,
        quizMode = QuizMode.PLAYING
      )
    }
  }

  fun selectQuizOption(index: Int) {
    val currentQ = _uiState.value.quizQuestions.getOrNull(_uiState.value.currentQuizQuestionIndex) ?: return
    if (_uiState.value.isAnswerRevealed) return

    val isCorrect = (index == currentQ.correctIndex)
    val newScore = if (isCorrect) _uiState.value.currentQuizScore + 1 else _uiState.value.currentQuizScore

    _uiState.update {
      it.copy(
        selectedOptionIndex = index,
        isAnswerRevealed = true,
        currentQuizScore = newScore
      )
    }
  }

  fun nextQuizQuestion() {
    val state = _uiState.value
    if (state.currentQuizQuestionIndex + 1 < state.quizQuestions.size) {
      _uiState.update {
        it.copy(
          currentQuizQuestionIndex = it.currentQuizQuestionIndex + 1,
          selectedOptionIndex = null,
          isAnswerRevealed = false
        )
      }
    } else {
      finishQuiz()
    }
  }

  private fun finishQuiz() {
    val state = _uiState.value
    val wrongDetails = mutableListOf<WrongAnswerDetail>()

    // Record wrong answer details
    state.quizQuestions.forEachIndexed { i, q ->
      // If we don't have recorded per-question choices, we can check or collect them
    }

    val finalResult = prefsManager.addQuizResult(
      subject = state.quizSelectedSubject,
      chapterTitle = "DHSE Class 12 Master Drill",
      score = state.currentQuizScore,
      total = state.quizQuestions.size,
      wrongAnswers = wrongDetails
    )

    val updatedResults = prefsManager.loadQuizResults()

    _uiState.update {
      it.copy(
        quizMode = QuizMode.RESULT,
        quizResults = updatedResults,
        activeQuizResult = finalResult
      )
    }
  }

  fun viewQuizHistory() {
    _uiState.update { it.copy(quizMode = QuizMode.HISTORY) }
  }

  fun backToQuizSelection() {
    _uiState.update { it.copy(quizMode = QuizMode.SELECTION) }
  }

  // --- Doubt Chat Logic ---
  fun switchSensei(character: SenseiCharacter) {
    _uiState.update { it.copy(activeSensei = character) }
  }

  fun updateChatInput(text: String) {
    _uiState.update { it.copy(chatInputText = text) }
  }

  fun sendChatMessage(presetQuery: String? = null) {
    val textToSend = (presetQuery ?: _uiState.value.chatInputText).trim()
    if (textToSend.isBlank()) return

    val now = System.currentTimeMillis()
    val userMsg = ChatMessage(
      id = "user_${now}",
      senderName = "You",
      text = textToSend,
      timestamp = now,
      isUser = true
    )

    val currentSensei = _uiState.value.activeSensei
    val newMessages = _uiState.value.chatMessages + userMsg

    _uiState.update {
      it.copy(
        chatMessages = newMessages,
        chatInputText = "",
        isSenseiTyping = true
      )
    }

    viewModelScope.launch {
      delay(700L) // natural thinking pause for Sensei
      val answer = DefaultData.generateSenseiResponse(currentSensei, textToSend)
      val senseiMsg = ChatMessage(
        id = "sensei_${System.currentTimeMillis()}",
        senderName = currentSensei.charName,
        text = answer,
        timestamp = System.currentTimeMillis(),
        isUser = false,
        character = currentSensei
      )

      val allUpdated = newMessages + senseiMsg
      prefsManager.saveChatMessages(allUpdated)

      _uiState.update {
        it.copy(
          chatMessages = allUpdated,
          isSenseiTyping = false
        )
      }
    }
  }

  fun clearChatHistory() {
    prefsManager.saveChatMessages(emptyList())
    _uiState.update { it.copy(chatMessages = emptyList()) }
  }

  // --- Backup & Restore ---
  fun getBackupJson(): String = prefsManager.getBackupJson()

  fun restoreFromBackup(json: String): Boolean {
    val success = prefsManager.restoreFromBackup(json)
    if (success) {
      loadInitialData()
    }
    return success
  }
}
