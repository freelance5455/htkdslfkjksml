package com.example.ui.settings

import android.graphics.Color as AndroidColor
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DetectionRegion
import com.example.model.TriggerType
import com.example.ui.theme.ChromaGreen
import com.example.ui.theme.ChromaPrimary
import com.example.ui.theme.ChromaRed
import com.example.ui.theme.ChromaYellow
import com.example.ui.viewmodel.CameraViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TriggerSettingsSheet(
    viewModel: CameraViewModel,
    onDismiss: () -> Unit
) {
    val triggers by viewModel.triggers.collectAsState()
    val cooldownSeconds by viewModel.cooldownSeconds.collectAsState()
    val sensitivityPercent by viewModel.sensitivityPercent.collectAsState()
    val detectionRegion by viewModel.detectionRegion.collectAsState()
    val soundEnabled by viewModel.soundEnabled.collectAsState()
    val vibrationEnabled by viewModel.vibrationEnabled.collectAsState()

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    // Custom Color Creator state
    var showColorCreator by remember { mutableStateOf(false) }
    var customHue by remember { mutableFloatStateOf(180f) }
    var customSat by remember { mutableFloatStateOf(0.85f) }
    var customVal by remember { mutableFloatStateOf(0.9f) }

    val previewArgb = remember(customHue, customSat, customVal) {
        AndroidColor.HSVToColor(floatArrayOf(customHue, customSat, customVal))
    }
    val previewComposeColor = remember(previewArgb) { Color(previewArgb) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(20.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = null,
                        tint = ChromaPrimary
                    )
                    Text(
                        text = "إعدادات الألوان والتصوير التلقائي",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("close_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "إغلاق",
                        tint = Color.White.copy(alpha = 0.7f)
                    )
                }
            }

            Text(
                text = "حدد الألوان والرموز التي تؤدي إلى التقاط الصور تلقائياً فور ظهورها أمام الكاميرا",
                fontSize = 12.sp,
                color = Color.White.copy(alpha = 0.65f),
                modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
            )

            HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
            Spacer(modifier = Modifier.height(14.dp))

            // Section 1: Active Triggers List
            Text(
                text = "الألوان المستهدفة للتصوير (Triggers)",
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp,
                color = ChromaPrimary,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            triggers.forEach { trigger ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (trigger.isEnabled) {
                            trigger.color.copy(alpha = 0.15f)
                        } else {
                            Color.White.copy(alpha = 0.05f)
                        }
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(trigger.color)
                                    .border(1.5.dp, Color.White.copy(alpha = 0.8f), CircleShape)
                            )
                            Column {
                                Text(
                                    text = trigger.nameAr,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = Color.White
                                )
                                Text(
                                    text = trigger.nameEn,
                                    fontSize = 11.sp,
                                    color = Color.White.copy(alpha = 0.6f)
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (trigger.type == TriggerType.CUSTOM) {
                                IconButton(
                                    onClick = { viewModel.removeTrigger(trigger.id) },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "حذف اللون المخصص",
                                        tint = ChromaRed,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            Switch(
                                checked = trigger.isEnabled,
                                onCheckedChange = { viewModel.toggleTrigger(trigger.id) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = trigger.color,
                                    checkedTrackColor = trigger.color.copy(alpha = 0.4f)
                                ),
                                modifier = Modifier.testTag("switch_trigger_${trigger.type.name}")
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Add Custom Color Button / Expander
            Button(
                onClick = { showColorCreator = !showColorCreator },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("add_custom_color_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White.copy(alpha = 0.12f),
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = if (showColorCreator) Icons.Default.Close else Icons.Default.Add,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = if (showColorCreator) "إلغاء إضافة لون جديد" else "إضافة لون مستهدف جديد (Custom Color)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // Custom Color Creator Panel
            if (showColorCreator) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = Color.White.copy(alpha = 0.08f)
                    ),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "معاينة اللون الجديد:",
                                fontSize = 13.sp,
                                color = Color.White
                            )
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(previewComposeColor)
                                    .border(2.dp, Color.White, RoundedCornerShape(8.dp))
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Hue slider
                        Text(
                            text = "درجة اللون (Hue): ${customHue.toInt()}°",
                            fontSize = 12.sp,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                        Slider(
                            value = customHue,
                            onValueChange = { customHue = it },
                            valueRange = 0f..360f,
                            colors = SliderDefaults.colors(
                                thumbColor = previewComposeColor,
                                activeTrackColor = previewComposeColor
                            )
                        )

                        // Saturation slider
                        Text(
                            text = "التشبع (Saturation): ${(customSat * 100).toInt()}%",
                            fontSize = 12.sp,
                            color = Color.White.copy(alpha = 0.8f)
                        )
                        Slider(
                            value = customSat,
                            onValueChange = { customSat = it },
                            valueRange = 0.2f..1f,
                            colors = SliderDefaults.colors(
                                thumbColor = previewComposeColor,
                                activeTrackColor = previewComposeColor
                            )
                        )

                        Button(
                            onClick = {
                                viewModel.addCustomColorTrigger(previewComposeColor)
                                showColorCreator = false
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 6.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ChromaPrimary,
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = "حفظ وإضافة هذا اللون كهدف للتصوير",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
            HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
            Spacer(modifier = Modifier.height(14.dp))

            // Section 2: Camera & Shooting Parameters
            Text(
                text = "خصائص التصوير التلقائي المستمر",
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp,
                color = ChromaPrimary,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            // Cooldown Slider
            Column(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "التأخير بين اللقطات المتتالية:",
                        fontSize = 13.sp,
                        color = Color.White
                    )
                    Text(
                        text = String.format("%.1f ثانية", cooldownSeconds),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = ChromaYellow
                    )
                }
                Slider(
                    value = cooldownSeconds,
                    onValueChange = { viewModel.setCooldown(it) },
                    valueRange = 0.5f..5.0f,
                    steps = 8,
                    colors = SliderDefaults.colors(
                        thumbColor = ChromaYellow,
                        activeTrackColor = ChromaYellow
                    ),
                    modifier = Modifier.testTag("cooldown_slider")
                )
                Text(
                    text = "يحدد الفاصل الزمني بين كل صورة والأخرى أثناء استمرار ظهور اللون المستهدف",
                    fontSize = 11.sp,
                    color = Color.White.copy(alpha = 0.55f)
                )
            }

            // Sensitivity Slider
            Column(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "حساسية الرصد (نسبة ظهور اللون):",
                        fontSize = 13.sp,
                        color = Color.White
                    )
                    Text(
                        text = "${sensitivityPercent.toInt()}%",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = ChromaGreen
                    )
                }
                Slider(
                    value = sensitivityPercent,
                    onValueChange = { viewModel.setSensitivity(it) },
                    valueRange = 3f..35f,
                    steps = 10,
                    colors = SliderDefaults.colors(
                        thumbColor = ChromaGreen,
                        activeTrackColor = ChromaGreen
                    ),
                    modifier = Modifier.testTag("sensitivity_slider")
                )
                Text(
                    text = "الحد الأدنى لمساحة اللون المطلوبة داخل إطار الكاميرا لإطلاق اللقطة التلقائية",
                    fontSize = 11.sp,
                    color = Color.White.copy(alpha = 0.55f)
                )
            }

            // Detection Region Mode
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "منطقة الفحص",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = if (detectionRegion == DetectionRegion.CENTER_RETICLE) {
                            "المربع الأوسط (تركيز دقيق)"
                        } else {
                            "كامل شاشة الكاميرا"
                        },
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.6f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = detectionRegion == DetectionRegion.CENTER_RETICLE,
                        onClick = { viewModel.setDetectionRegion(DetectionRegion.CENTER_RETICLE) },
                        label = { Text("المربع الأوسط", fontSize = 11.sp) },
                        leadingIcon = {
                            Icon(Icons.Default.CenterFocusStrong, contentDescription = null, modifier = Modifier.size(14.dp))
                        }
                    )
                    FilterChip(
                        selected = detectionRegion == DetectionRegion.FULL_FRAME,
                        onClick = { viewModel.setDetectionRegion(DetectionRegion.FULL_FRAME) },
                        label = { Text("كامل الشاشة", fontSize = 11.sp) },
                        leadingIcon = {
                            Icon(Icons.Default.CropFree, contentDescription = null, modifier = Modifier.size(14.dp))
                        }
                    )
                }
            }

            // Audio & Vibration toggles
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "صوت التقاط الكاميرا (Shutter Sound)",
                    fontSize = 13.sp,
                    color = Color.White
                )
                Switch(
                    checked = soundEnabled,
                    onCheckedChange = { viewModel.toggleSound() }
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "الاهتزاز اللمسي (Haptic Feedback)",
                    fontSize = 13.sp,
                    color = Color.White
                )
                Switch(
                    checked = vibrationEnabled,
                    onCheckedChange = { viewModel.toggleVibration() }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
