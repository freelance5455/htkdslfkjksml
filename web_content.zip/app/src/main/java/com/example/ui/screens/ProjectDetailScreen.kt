package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.example.data.model.MilestoneEntity
import com.example.data.model.ProjectCategory
import com.example.data.model.ProjectEntity
import com.example.data.model.ProjectStatus
import com.example.data.model.ProjectWithStats
import com.example.data.model.TaskEntity
import com.example.data.model.TaskPriority
import com.example.data.model.TaskStatus
import com.example.data.model.TaskWithMeta
import com.example.ui.components.CompletionRing
import com.example.ui.components.TaskCard
import com.example.ui.components.projectAccentColor
import com.example.ui.theme.StatusDoneColor
import com.example.util.formatDurationPersian
import com.example.util.formatRelativeDateFa
import com.example.util.toPersianDigits

@Composable
fun ProjectDetailScreen(
    projectWithStats: ProjectWithStats?,
    tasks: List<TaskWithMeta>,
    milestones: List<MilestoneEntity>,
    onBack: () -> Unit,
    onEditProject: (ProjectEntity) -> Unit,
    onDeleteProject: (Long) -> Unit,
    onTogglePin: (ProjectEntity) -> Unit,
    onChangeProjectStatus: (ProjectEntity, ProjectStatus) -> Unit,
    onUpdateProjectNotes: (ProjectEntity, String) -> Unit,
    onExportProjectMarkdown: (Long) -> Unit,
    onShareProjectSummary: (Long) -> Unit,
    onAddTask: (TaskStatus) -> Unit,
    onTaskClick: (TaskWithMeta) -> Unit,
    onToggleTaskDone: (TaskEntity) -> Unit,
    onAdvanceTaskStatus: (TaskEntity) -> Unit,
    onToggleBookmarkTask: (TaskEntity) -> Unit,
    onAddMilestone: (String) -> Unit,
    onToggleMilestone: (MilestoneEntity) -> Unit,
    onDeleteMilestone: (MilestoneEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    if (projectWithStats == null) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("پروژه یافت نشد", style = MaterialTheme.typography.titleMedium)
                Button(onClick = onBack) { Text("بازگشت") }
            }
        }
        return
    }

    val project = projectWithStats.project
    val accent = projectAccentColor(project.colorIndex)
    val category = ProjectCategory.fromName(project.category)
    val currentStatus = ProjectStatus.fromName(project.status)

    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Tasks, 1 = Milestones, 2 = Notes & Export
    var taskStatusFilter by remember { mutableStateOf<TaskStatus?>(null) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var newMilestoneTitle by remember { mutableStateOf("") }
    var editableNotes by remember(project.id, project.notes) { mutableStateOf(project.notes) }

    val filteredTasks = remember(tasks, taskStatusFilter) {
        tasks.filter { taskStatusFilter == null || it.task.status == taskStatusFilter?.name }
            .sortedWith(
                compareByDescending<TaskWithMeta> { it.task.bookmarked }
                    .thenByDescending { TaskPriority.fromName(it.task.priority).weight }
            )
    }

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 880.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Colored Hero Header
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(26.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(accent.copy(alpha = 0.94f), accent.copy(alpha = 0.65f))
                            )
                        )
                        .padding(18.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = onBack,
                                modifier = Modifier.testTag("project_detail_back_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                    contentDescription = "بازگشت",
                                    tint = Color.White
                                )
                            }

                            Row {
                                IconButton(onClick = { onTogglePin(project) }) {
                                    Icon(
                                        imageVector = if (project.isPinned) Icons.Rounded.PushPin else Icons.Outlined.PushPin,
                                        contentDescription = "سنجاق",
                                        tint = Color.White
                                    )
                                }
                                IconButton(
                                    onClick = { onEditProject(project) },
                                    modifier = Modifier.testTag("edit_project_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Edit,
                                        contentDescription = "ویرایش پروژه",
                                        tint = Color.White
                                    )
                                }
                                IconButton(
                                    onClick = { showDeleteConfirm = true },
                                    modifier = Modifier.testTag("delete_project_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.DeleteOutline,
                                        contentDescription = "حذف پروژه",
                                        tint = Color.White
                                    )
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Surface(
                                    color = Color(0x33FFFFFF),
                                    shape = RoundedCornerShape(50)
                                ) {
                                    Text(
                                        text = "${category.labelFa}  •  ${formatRelativeDateFa(project.targetDateMillis)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                                Text(
                                    text = project.title,
                                    style = MaterialTheme.typography.headlineSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                if (project.description.isNotBlank()) {
                                    Text(
                                        text = project.description,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = Color(0xEEFFFFFF)
                                    )
                                }
                                if (project.budgetLabel.isNotBlank()) {
                                    Text(
                                        text = "هدف / بودجه: ${project.budgetLabel}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = Color.White,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            Spacer(Modifier.width(12.dp))

                            Surface(
                                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f),
                                shape = RoundedCornerShape(22.dp)
                            ) {
                                Box(modifier = Modifier.padding(10.dp)) {
                                    CompletionRing(
                                        progress = projectWithStats.progress,
                                        ringSize = 72.dp,
                                        strokeWidth = 7.dp,
                                        accentColor = accent
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Status Switcher
            item {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "وضعیت:",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    ProjectStatus.entries.forEach { st ->
                        FilterChip(
                            selected = currentStatus == st,
                            onClick = { onChangeProjectStatus(project, st) },
                            label = { Text(st.labelFa) }
                        )
                    }
                }
            }

            // 3-Tab Switcher
            item {
                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    SegmentedButton(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        shape = SegmentedButtonDefaults.itemShape(0, 3)
                    ) {
                        Text("تسک‌ها (${tasks.size.toPersianDigits()})", maxLines = 1)
                    }
                    SegmentedButton(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        shape = SegmentedButtonDefaults.itemShape(1, 3)
                    ) {
                        Text("نقاط عطف (${milestones.size.toPersianDigits()})", maxLines = 1)
                    }
                    SegmentedButton(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        shape = SegmentedButtonDefaults.itemShape(2, 3)
                    ) {
                        Text("یادداشت و فایل", maxLines = 1)
                    }
                }
            }

            when (selectedTab) {
                0 -> {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier
                                    .weight(1f)
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                FilterChip(
                                    selected = taskStatusFilter == null,
                                    onClick = { taskStatusFilter = null },
                                    label = { Text("همه") }
                                )
                                TaskStatus.entries.forEach { st ->
                                    FilterChip(
                                        selected = taskStatusFilter == st,
                                        onClick = { taskStatusFilter = if (taskStatusFilter == st) null else st },
                                        label = { Text(st.labelFa) }
                                    )
                                }
                            }
                            Spacer(Modifier.width(8.dp))
                            Button(
                                onClick = { onAddTask(taskStatusFilter ?: TaskStatus.TODO) },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.testTag("project_detail_add_task_button")
                            ) {
                                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("تسک")
                            }
                        }
                    }

                    if (filteredTasks.isEmpty()) {
                        item {
                            Card(
                                shape = MaterialTheme.shapes.medium,
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "هنوز تسکی در این بخش نیست. روی «+ تسک» بزنید!",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(24.dp)
                                )
                            }
                        }
                    } else {
                        items(items = filteredTasks, key = { it.task.id }) { meta ->
                            TaskCard(
                                item = meta,
                                showProjectBadge = false,
                                onClick = { onTaskClick(meta) },
                                onToggleDone = { onToggleTaskDone(meta.task) },
                                onAdvanceStatus = { onAdvanceTaskStatus(meta.task) },
                                onToggleBookmark = { onToggleBookmarkTask(meta.task) }
                            )
                        }
                    }
                }

                1 -> {
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = newMilestoneTitle,
                                onValueChange = { newMilestoneTitle = it },
                                placeholder = { Text("افزودن نقطه عطف (فاز پروژه)...") },
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("milestone_input")
                            )
                            Surface(
                                onClick = {
                                    if (newMilestoneTitle.isNotBlank()) {
                                        onAddMilestone(newMilestoneTitle)
                                        newMilestoneTitle = ""
                                    }
                                },
                                color = accent,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .size(54.dp)
                                    .testTag("add_milestone_button")
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Rounded.Add, contentDescription = "افزودن نقطه عطف", tint = Color.White)
                                }
                            }
                        }
                    }

                    if (milestones.isEmpty()) {
                        item {
                            Card(
                                shape = MaterialTheme.shapes.medium,
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(20.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Icon(Icons.Rounded.Flag, contentDescription = null, tint = accent)
                                    Text(
                                        text = "نقاط عطف کلیدی پروژه را اینجا ثبت کنید تا مسیر پیشرفت مشخص باشد.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    } else {
                        items(items = milestones, key = { it.id }) { milestone ->
                            Surface(
                                color = MaterialTheme.colorScheme.surface,
                                shape = MaterialTheme.shapes.medium,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onToggleMilestone(milestone) }
                                        .padding(horizontal = 14.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(
                                        imageVector = if (milestone.isCompleted) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                                        contentDescription = "وضعیت نقطه عطف",
                                        tint = if (milestone.isCompleted) StatusDoneColor else accent
                                    )
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = milestone.title,
                                            style = MaterialTheme.typography.titleSmall,
                                            textDecoration = if (milestone.isCompleted) TextDecoration.LineThrough else TextDecoration.None
                                        )
                                        if (milestone.targetDateMillis != null) {
                                            Text(
                                                text = formatRelativeDateFa(milestone.targetDateMillis),
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    IconButton(
                                        onClick = { onDeleteMilestone(milestone) },
                                        modifier = Modifier.minimumInteractiveComponentSize()
                                    ) {
                                        Icon(Icons.Rounded.Close, contentDescription = "حذف نقطه عطف", modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }

                else -> {
                    // Project Notes, Stats & File Export
                    item {
                        Card(
                            shape = MaterialTheme.shapes.large,
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    text = "آمار تخمین و زمان تمرکز",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text("تخمین کل", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(formatDurationPersian(projectWithStats.totalEstimatedMinutes), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                    }
                                    Column {
                                        Text("تمرکز ثبت‌شده", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(formatDurationPersian(projectWithStats.totalFocusMinutes), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                                    }
                                    Column {
                                        Text("امتیاز اسپرینت", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("${projectWithStats.doneStoryPoints.toPersianDigits()}/${projectWithStats.totalStoryPoints.toPersianDigits()}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Card(
                            shape = MaterialTheme.shapes.large,
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    text = "یادداشت‌ها و مستندات پروژه",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                OutlinedTextField(
                                    value = editableNotes,
                                    onValueChange = { editableNotes = it },
                                    placeholder = { Text("ایده‌ها، لینک‌ها و نکات مهم این پروژه را بنویسید...") },
                                    minLines = 4,
                                    maxLines = 8,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Button(
                                    onClick = { onUpdateProjectNotes(project, editableNotes) },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Rounded.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("ذخیره یادداشت")
                                }
                            }
                        }
                    }

                    item {
                        Card(
                            shape = MaterialTheme.shapes.large,
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    text = "دانلود فایل گزارش و اشتراک‌گذاری",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Button(
                                    onClick = { onExportProjectMarkdown(project.id) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("project_export_md_button")
                                ) {
                                    Icon(Icons.Rounded.Download, contentDescription = null)
                                    Spacer(Modifier.width(8.dp))
                                    Text("دانلود فایل گزارش پروژه (.md)")
                                }
                                OutlinedButton(
                                    onClick = { onShareProjectSummary(project.id) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("project_share_button")
                                ) {
                                    Icon(Icons.Rounded.Share, contentDescription = null)
                                    Spacer(Modifier.width(8.dp))
                                    Text("اشتراک‌گذاری گزارش")
                                }
                            }
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(72.dp)) }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("حذف پروژه") },
            text = { Text("آیا مطمئن هستید که می‌خواهید پروژه «${project.title}» و تمام تسک‌های آن را حذف کنید؟") },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteConfirm = false
                        onDeleteProject(project.id)
                        onBack()
                    }
                ) {
                    Text("حذف", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("انصراف")
                }
            }
        )
    }
}
