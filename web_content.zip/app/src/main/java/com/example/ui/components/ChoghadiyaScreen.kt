package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAlert
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.ChoghadiyaItem
import com.example.model.ChoghadiyaQuality
import com.example.model.DailyPanchang
import com.example.ui.theme.AuspiciousGold
import com.example.ui.theme.EkadashiGreen

@Composable
fun ChoghadiyaScreen(
    panchang: DailyPanchang,
    language: AppLanguage,
    onSetChoghadiyaReminder: (ChoghadiyaItem) -> Unit,
    modifier: Modifier = Modifier
) {
    var isDayTab by remember { mutableStateOf(true) }

    val list = if (isDayTab) panchang.choghadiya.dayChoghadiya else panchang.choghadiya.nightChoghadiya

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            // Hero Status Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = Color.White
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE0E0E0)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFE65100)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isDayTab) Icons.Default.WbSunny else Icons.Default.Bedtime,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(26.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = "${panchang.dayOfWeek} • दैनिक चौघड़िया मुहूर्त",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                        Text(
                            text = "शुभ, लाभ, अमृत वेला में किए कार्य सिद्ध होते हैं",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF333333)
                        )
                    }
                }
            }
        }

        // Day / Night Selector Tabs
        item {
            TabRow(
                selectedTabIndex = if (isDayTab) 0 else 1,
                containerColor = Color.White,
                contentColor = Color.Black,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, Color(0xFFE0E0E0), RoundedCornerShape(12.dp))
            ) {
                Tab(
                    selected = isDayTab,
                    onClick = { isDayTab = true },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.WbSunny, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color(0xFFFFA000))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("दिन का चौघड़िया (Day)", fontWeight = FontWeight.Bold)
                        }
                    },
                    modifier = Modifier.testTag("tab_day_choghadiya")
                )
                Tab(
                    selected = !isDayTab,
                    onClick = { isDayTab = false },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Bedtime, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color(0xFF5C6BC0))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("रात का चौघड़िया (Night)", fontWeight = FontWeight.Bold)
                        }
                    },
                    modifier = Modifier.testTag("tab_night_choghadiya")
                )
            }
        }

        // Choghadiya items
        items(list) { choghadiya ->
            ChoghadiyaCard(
                item = choghadiya,
                onSetReminder = { onSetChoghadiyaReminder(choghadiya) }
            )
        }

        // Guidelines card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE0E0E0)),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "चौघड़िया मुहूर्त का महत्व:",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                    }
                    Text(text = "• अमृत, शुभ, लाभ: नया कार्य, व्यापार, पूजा, गृह प्रवेश, वाहन व स्वर्ण क्रय हेतु सर्वोत्तम।", style = MaterialTheme.typography.bodySmall, color = Color(0xFF222222))
                    Text(text = "• चर: यात्रा, वाहन परिचालन, स्थानांतरण के लिए मध्यम फलदायी।", style = MaterialTheme.typography.bodySmall, color = Color(0xFF222222))
                    Text(text = "• रोग, काल, उद्वेग: अशुभ चौघड़िया। इनमें नवीन व मांगलिक कार्य आरंभ करने से बचें।", style = MaterialTheme.typography.bodySmall, color = Color(0xFF222222))
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun ChoghadiyaCard(
    item: ChoghadiyaItem,
    onSetReminder: () -> Unit
) {
    val (badgeBg, textColor) = when (item.quality) {
        ChoghadiyaQuality.SHUBH_AMRIT_LAABH -> Color(0xFF2E7D32) to Color.White
        ChoghadiyaQuality.CHAR -> Color(0xFF1976D2) to Color.White
        ChoghadiyaQuality.ASHUBH -> Color(0xFFC62828) to Color.White
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = when (item.quality) {
                ChoghadiyaQuality.SHUBH_AMRIT_LAABH -> Color(0xFFE8F5E9)
                ChoghadiyaQuality.CHAR -> Color(0xFFE3F2FD)
                ChoghadiyaQuality.ASHUBH -> Color(0xFFFFEBEE)
            }
        ),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, badgeBg.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(badgeBg),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = item.name,
                            color = textColor,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "${item.startTime} - ${item.endTime}",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF111111)
                        )
                    }
                    Text(
                        text = "फल: ${item.nature} • स्वामी: ${item.rulerPlanet}",
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = badgeBg
                    )
                    Text(
                        text = item.recommendedActivities,
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 10.5.sp,
                        color = Color(0xFF444444),
                        maxLines = 1
                    )
                }
            }

            if (item.quality == ChoghadiyaQuality.SHUBH_AMRIT_LAABH || item.quality == ChoghadiyaQuality.CHAR) {
                Button(
                    onClick = onSetReminder,
                    colors = ButtonDefaults.buttonColors(containerColor = badgeBg),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("choghadiya_remind_${item.name}")
                ) {
                    Icon(imageVector = Icons.Default.AddAlert, contentDescription = null, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("अलर्ट", style = MaterialTheme.typography.labelSmall, fontSize = 10.sp)
                }
            }
        }
    }
}
