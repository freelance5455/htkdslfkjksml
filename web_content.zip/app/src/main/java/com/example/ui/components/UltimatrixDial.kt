package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun UltimatrixDial(
    rotationAngle: Float,
    isUltimateMode: Boolean,
    powerPercent: Float,
    pulseTrigger: Long,
    onDialClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Rotation spring animation
    val animatedRotation by animateFloatAsState(
        targetValue = rotationAngle,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "dialRotation"
    )

    // Pulse scale animation on each click
    val pulseAnim = remember { Animatable(1f) }
    LaunchedEffect(pulseTrigger) {
        if (pulseTrigger > 0L) {
            pulseAnim.animateTo(
                targetValue = 1.15f,
                animationSpec = tween(70, easing = LinearOutSlowInEasing)
            )
            pulseAnim.animateTo(
                targetValue = 1f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioHighBouncy,
                    stiffness = Spring.StiffnessMedium
                )
            )
        }
    }

    // Continuous idle breathing glow
    val infiniteTransition = rememberInfiniteTransition(label = "breathing")
    val idleGlowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowPulse"
    )

    val coreColor by animateColorAsState(
        targetValue = if (isUltimateMode) UltimateRedBright else OmnitrixGreenBright,
        animationSpec = tween(350),
        label = "coreColor"
    )

    val glowColor by animateColorAsState(
        targetValue = if (isUltimateMode) UltimateRedGlow else OmnitrixGreenGlow,
        animationSpec = tween(350),
        label = "glowColor"
    )

    Box(
        modifier = modifier
            .size(116.dp)
            .scale(pulseAnim.value)
            .clip(CircleShape)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onDialClick
            )
            .testTag("ultimatrix_core_dial"),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val radius = size.minDimension / 2f

            // 1. Outer Dark Titanium Ring
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(GalvanSurfaceLight, GalvanDark, GalvanBlack),
                    center = center,
                    radius = radius
                ),
                radius = radius,
                center = center
            )

            // Outer Bezel Rim
            drawCircle(
                color = GalvanBorder,
                radius = radius - 2f,
                center = center,
                style = Stroke(width = 3.5f)
            )

            // 2. Screws / Tech Rivets on bezel (8 studs around circle)
            for (i in 0 until 8) {
                val angle = (i * 45f) * (Math.PI / 180f)
                val rivetX = center.x + cos(angle).toFloat() * (radius - 8f)
                val rivetY = center.y + sin(angle).toFloat() * (radius - 8f)
                drawCircle(
                    color = GalvanHighlight,
                    radius = 2.5f,
                    center = Offset(rivetX, rivetY)
                )
            }

            // 3. Glowing Power Track Ring
            drawCircle(
                color = coreColor.copy(alpha = 0.25f),
                radius = radius - 16f,
                center = center,
                style = Stroke(width = 4f)
            )

            // Dynamic Power arc
            val sweep = powerPercent.coerceIn(0.1f, 1f) * 360f
            drawArc(
                color = coreColor.copy(alpha = idleGlowAlpha),
                startAngle = -90f,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = Offset(center.x - (radius - 16f), center.y - (radius - 16f)),
                size = androidx.compose.ui.geometry.Size((radius - 16f) * 2f, (radius - 16f) * 2f),
                style = Stroke(width = 4f)
            )

            // 4. Inner Dial Core Cavity (Deep metallic sunken chamber)
            val innerRadius = radius - 24f
            drawCircle(
                color = GalvanBlack,
                radius = innerRadius,
                center = center
            )

            // Ambient Core Aura
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        coreColor.copy(alpha = idleGlowAlpha * 0.85f),
                        glowColor.copy(alpha = idleGlowAlpha * 0.4f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = innerRadius
                ),
                radius = innerRadius,
                center = center
            )
        }

        // 5. Rotating Omnitrix Center Hourglass Emblem
        Box(
            modifier = Modifier
                .size(62.dp)
                .rotate(animatedRotation),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val halfSize = size.minDimension / 2f

                // Draw the iconic Omnitrix / Ultimatrix Hourglass
                // Top Interlocking Green / Red Triangle
                val topPath = Path().apply {
                    moveTo(center.x - halfSize * 0.82f, center.y - halfSize * 0.82f)
                    lineTo(center.x + halfSize * 0.82f, center.y - halfSize * 0.82f)
                    lineTo(center.x, center.y)
                    close()
                }
                drawPath(path = topPath, color = coreColor)

                // Bottom Interlocking Triangle
                val bottomPath = Path().apply {
                    moveTo(center.x - halfSize * 0.82f, center.y + halfSize * 0.82f)
                    lineTo(center.x + halfSize * 0.82f, center.y + halfSize * 0.82f)
                    lineTo(center.x, center.y)
                    close()
                }
                drawPath(path = bottomPath, color = coreColor)

                // Left Black Notch
                val leftPath = Path().apply {
                    moveTo(center.x - halfSize * 0.82f, center.y - halfSize * 0.82f)
                    lineTo(center.x - halfSize * 0.82f, center.y + halfSize * 0.82f)
                    lineTo(center.x, center.y)
                    close()
                }
                drawPath(path = leftPath, color = GalvanBlack)

                // Right Black Notch
                val rightPath = Path().apply {
                    moveTo(center.x + halfSize * 0.82f, center.y - halfSize * 0.82f)
                    lineTo(center.x + halfSize * 0.82f, center.y + halfSize * 0.82f)
                    lineTo(center.x, center.y)
                    close()
                }
                drawPath(path = rightPath, color = GalvanBlack)

                // Glowing border around the Hourglass
                drawCircle(
                    color = coreColor,
                    radius = halfSize * 0.88f,
                    center = center,
                    style = Stroke(width = 2.5f)
                )
            }
        }

        // Mode label under dial
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .offset(y = (-4).dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = if (isUltimateMode) "ULTIMATE" else "ACTIVE",
                color = if (isUltimateMode) UltimateRedBright else OmnitrixGreenBright,
                fontSize = 8.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp
            )
        }
    }
}
