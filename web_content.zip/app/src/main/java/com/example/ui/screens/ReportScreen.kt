package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Pool
import androidx.compose.material3.Icon
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.entity.TransactionEntity
import com.example.data.entity.TransactionTypes
import com.example.ui.components.DatePickerHelper
import com.example.ui.components.Elevated3DCard
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.DepositBlue
import com.example.ui.theme.DepositBlueLight
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.ExpenseRedLight
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.IncomeGreenLight
import com.example.ui.theme.IslamicEmerald
import com.example.ui.theme.IslamicGold
import com.example.ui.theme.IslamicGoldLight
import com.example.ui.theme.IslamicGreenDark
import com.example.ui.theme.IslamicGreenPrimary
import com.example.ui.theme.LoanOrange
import com.example.ui.theme.LoanOrangeLight
import com.example.ui.theme.RepaidPurple
import com.example.ui.theme.RepaidPurpleLight
import com.example.ui.theme.TextPrimary
import com.example.ui.util.BanglaHelper
import com.example.ui.viewmodel.FinanceViewModel

@Composable
fun ReportScreen(
    viewModel: FinanceViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val transactions by viewModel.allTransactions.collectAsStateWithLifecycle()
    val loans by viewModel.allLoans.collectAsStateWithLifecycle()
    val repayments by viewModel.allRepayments.collectAsStateWithLifecycle()

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val tabs = listOf("মাসভিত্তিক রিপোর্ট", "পুকুর থেকে বেতন", "তারিখ অনুযায়ী রিপোর্ট")

    // Filter states
    var selectedMonthIndex by remember { mutableIntStateOf(BanglaHelper.getCurrentMonthIndex()) }
    var selectedYear by remember { mutableIntStateOf(BanglaHelper.getCurrentYear()) }
    var selectedSingleDate by remember { mutableStateOf(BanglaHelper.getTodayIso()) }

    Column(
        modifier = modifier.fillMaxSize()
    ) {
        ScrollableTabRow(
            selectedTabIndex = selectedTabIndex,
            containerColor = Color.Transparent,
            contentColor = IslamicGreenPrimary,
            edgePadding = 16.dp,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                    color = IslamicGreenPrimary,
                    height = 3.dp
                )
            }
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTabIndex == index,
                    onClick = { selectedTabIndex = index },
                    text = {
                        Text(
                            text = title,
                            fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 14.sp
                        )
                    },
                    modifier = Modifier.testTag("report_tab_$index")
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        when (selectedTabIndex) {
            0 -> {
                // মাসভিত্তিক রিপোর্ট
                MonthlyDetailedReportView(
                    transactions = transactions,
                    loans = loans,
                    repayments = repayments,
                    selectedMonth = selectedMonthIndex,
                    selectedYear = selectedYear,
                    onMonthChange = { selectedMonthIndex = it },
                    onYearChange = { selectedYear = it }
                )
            }
            1 -> {
                // পুকুর থেকে বেতনের বিশেষ রিপোর্ট
                PondSalaryReportView(transactions = transactions)
            }
            2 -> {
                // তারিখ অনুযায়ী রিপোর্ট
                DateSpecificReportView(
                    transactions = transactions,
                    loans = loans,
                    repayments = repayments,
                    selectedDate = selectedSingleDate,
                    onDateClick = {
                        DatePickerHelper.showDatePicker(context, selectedSingleDate) { newDate ->
                            selectedSingleDate = newDate
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun MonthlyDetailedReportView(
    transactions: List<TransactionEntity>,
    loans: List<com.example.data.entity.LoanEntity>,
    repayments: List<com.example.data.entity.LoanRepaymentEntity>,
    selectedMonth: Int,
    selectedYear: Int,
    onMonthChange: (Int) -> Unit,
    onYearChange: (Int) -> Unit
) {
    val monthPrefix = String.format("%04d-%02d", selectedYear, selectedMonth)
    val monthName = BanglaHelper.BANGLA_MONTHS[selectedMonth - 1]

    val monthIncome = transactions.filter {
        it.date.startsWith(monthPrefix) &&
                (it.type == TransactionTypes.INCOME ||
                        it.type == TransactionTypes.POND_INCOME ||
                        it.type == TransactionTypes.MADRASAH_SALARY_INCOME ||
                        it.type == TransactionTypes.MOSQUE_SALARY_INCOME)
    }.sumOf { it.amount }

    val monthExpense = transactions.filter {
        it.date.startsWith(monthPrefix) &&
                (it.type == TransactionTypes.EXPENSE ||
                        it.type == TransactionTypes.POND_FEED_EXPENSE)
    }.sumOf { it.amount }

    val monthDeposit = transactions.filter {
        it.date.startsWith(monthPrefix) && it.type == TransactionTypes.DEPOSIT
    }.sumOf { it.amount }

    val monthLoan = loans.filter { it.date.startsWith(monthPrefix) }.sumOf { it.amount }
    val monthRepaid = repayments.filter { it.date.startsWith(monthPrefix) }.sumOf { it.amount }

    val balance = monthIncome - monthExpense
    val isSurplus = balance >= 0

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Month & Year Picker Pills
        item {
            Elevated3DCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(text = "মাস নির্বাচন করুন", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                    // Month chips horizontal row
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(12) { i ->
                            val mIndex = i + 1
                            val isSel = selectedMonth == mIndex
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSel) IslamicGreenPrimary else Color(0xFFF3F4F6),
                                modifier = Modifier.clickable { onMonthChange(mIndex) }
                            ) {
                                Text(
                                    text = BanglaHelper.BANGLA_MONTHS[i],
                                    color = if (isSel) Color.White else TextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Summary Card
        item {
            Elevated3DCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("monthly_report_card"),
                elevation = 4f
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "$monthName, ${BanglaHelper.toBanglaDigits(selectedYear)} খতিয়ান",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSurplus) Color(0xFFDCFCE7) else Color(0xFFFEE2E2)
                        ) {
                            Text(
                                text = if (isSurplus) "উদ্বৃত্ত" else "ঘাটতি",
                                color = if (isSurplus) Color(0xFF15803D) else Color(0xFFB91C1C),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(Color(0xFFE5EBE7))
                    )

                    ReportRow(label = "নির্দিষ্ট মাসের মোট আয়", value = BanglaHelper.formatCurrency(monthIncome), color = IncomeGreen)
                    ReportRow(label = "নির্দিষ্ট মাসের মোট খরচ", value = BanglaHelper.formatCurrency(monthExpense), color = ExpenseRed)
                    ReportRow(label = "নির্দিষ্ট মাসের মোট জমা", value = BanglaHelper.formatCurrency(monthDeposit), color = DepositBlue)
                    ReportRow(label = "নির্দিষ্ট মাসের মোট ঋণ গ্রহণ", value = BanglaHelper.formatCurrency(monthLoan), color = LoanOrange)
                    ReportRow(label = "নির্দিষ্ট মাসের ঋণ পরিশোধ", value = BanglaHelper.formatCurrency(monthRepaid), color = RepaidPurple)

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(Color(0xFFE5EBE7))
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isSurplus) "মাসের শেষে মোট উদ্বৃত্ত" else "মাসের শেষে মোট ঘাটতি",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = TextPrimary
                        )
                        Text(
                            text = BanglaHelper.formatCurrency(kotlin.math.abs(balance)),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (isSurplus) IncomeGreen else ExpenseRed
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PondSalaryReportView(transactions: List<TransactionEntity>) {
    val pondSalaries = remember(transactions) {
        transactions.filter { it.type == TransactionTypes.POND_INCOME }
    }

    val totalPondSalary = remember(pondSalaries) {
        pondSalaries.sumOf { it.amount }
    }

    // Month-wise grouping
    val monthlyPondGroups = remember(pondSalaries) {
        pondSalaries.groupBy {
            if (it.date.length >= 7) it.date.substring(0, 7) else "অন্যান্য"
        }.toList().sortedByDescending { it.first }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Banner for Total Pond Salary
        item {
            Elevated3DCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("pond_report_total_card"),
                backgroundColor = Color(0xFFEFF6FF),
                borderColor = DepositBlue.copy(alpha = 0.3f),
                elevation = 3f
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "পুকুর থেকে মোট বেতন",
                            fontSize = 14.sp,
                            color = DepositBlue,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = BanglaHelper.formatCurrency(totalPondSalary),
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = DepositBlue
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "এই টাকা স্বয়ংক্রিয়ভাবে মোট আয়ে যুক্ত হয়েছে",
                            fontSize = 11.sp,
                            color = Color(0xFF1E40AF)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(DepositBlue),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Pool,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }
            }
        }

        // মাসভিত্তিক পুকুরের বেতন
        item {
            Text(
                text = "মাসভিত্তিক পুকুরের বেতন",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        if (monthlyPondGroups.isEmpty()) {
            item {
                Elevated3DCard(modifier = Modifier.fillMaxWidth()) {
                    Box(modifier = Modifier.fillMaxWidth().padding(20.dp), contentAlignment = Alignment.Center) {
                        Text("এখনো কোনো পুকুরের বেতন যোগ করা হয়নি", color = Color(0xFF6B7280))
                    }
                }
            }
        } else {
            items(monthlyPondGroups) { (monthKey, items) ->
                val monthTotal = items.sumOf { it.amount }
                val monthName = BanglaHelper.getMonthNameFromIso("$monthKey-01")
                val year = if (monthKey.length >= 4) monthKey.substring(0, 4) else ""

                Elevated3DCard(
                    modifier = Modifier.fillMaxWidth(),
                    elevation = 2f
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "$monthName ${BanglaHelper.toBanglaDigits(year)}",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "লেনদেন: ${BanglaHelper.toBanglaDigits(items.size)} বার",
                                fontSize = 12.sp,
                                color = Color(0xFF6B7280)
                            )
                        }
                        Text(
                            text = BanglaHelper.formatCurrency(monthTotal),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = DepositBlue
                        )
                    }
                }
            }
        }

        // তারিখভিত্তিক পুকুরের বেতন তালিকা
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "তারিখভিত্তিক পুকুরের বেতন তালিকা",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        if (pondSalaries.isNotEmpty()) {
            items(pondSalaries, key = { it.id }) { item ->
                Elevated3DCard(
                    modifier = Modifier.fillMaxWidth(),
                    elevation = 1f
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = item.description.ifBlank { "পুকুর থেকে বেতন" },
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                            Text(
                                text = BanglaHelper.formatBanglaDate(item.date),
                                fontSize = 12.sp,
                                color = Color(0xFF6B7280)
                            )
                        }
                        Text(
                            text = "+ " + BanglaHelper.formatCurrency(item.amount),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = DepositBlue
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DateSpecificReportView(
    transactions: List<TransactionEntity>,
    loans: List<com.example.data.entity.LoanEntity>,
    repayments: List<com.example.data.entity.LoanRepaymentEntity>,
    selectedDate: String,
    onDateClick: () -> Unit
) {
    val dayIncome = transactions.filter {
        it.date == selectedDate &&
                (it.type == TransactionTypes.INCOME ||
                        it.type == TransactionTypes.POND_INCOME ||
                        it.type == TransactionTypes.MADRASAH_SALARY_INCOME ||
                        it.type == TransactionTypes.MOSQUE_SALARY_INCOME)
    }.sumOf { it.amount }

    val dayExpense = transactions.filter {
        it.date == selectedDate &&
                (it.type == TransactionTypes.EXPENSE ||
                        it.type == TransactionTypes.POND_FEED_EXPENSE)
    }.sumOf { it.amount }

    val dayDeposit = transactions.filter {
        it.date == selectedDate && it.type == TransactionTypes.DEPOSIT
    }.sumOf { it.amount }

    val dayLoan = loans.filter { it.date == selectedDate }.sumOf { it.amount }
    val dayRepaid = repayments.filter { it.date == selectedDate }.sumOf { it.amount }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Date Selector Card
        item {
            Elevated3DCard(
                modifier = Modifier.fillMaxWidth(),
                elevation = 2f,
                onClick = onDateClick
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "তারিখ নির্বাচন করুন", fontSize = 12.sp, color = Color(0xFF6B7280))
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = BanglaHelper.formatBanglaDate(selectedDate),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.CalendarMonth,
                        contentDescription = null,
                        tint = IslamicGreenPrimary
                    )
                }
            }
        }

        // Day Summary Card
        item {
            Elevated3DCard(
                modifier = Modifier.fillMaxWidth(),
                elevation = 3f
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "এই দিনের সামগ্রিক হিসাব",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(Color(0xFFE5EBE7))
                    )

                    ReportRow(label = "আয়", value = BanglaHelper.formatCurrency(dayIncome), color = IncomeGreen)
                    ReportRow(label = "খরচ", value = BanglaHelper.formatCurrency(dayExpense), color = ExpenseRed)
                    ReportRow(label = "জমা", value = BanglaHelper.formatCurrency(dayDeposit), color = DepositBlue)
                    ReportRow(label = "ঋণ গ্রহণ", value = BanglaHelper.formatCurrency(dayLoan), color = LoanOrange)
                    ReportRow(label = "ঋণ পরিশোধ", value = BanglaHelper.formatCurrency(dayRepaid), color = RepaidPurple)

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(Color(0xFFE5EBE7))
                    )

                    val dayBalance = dayIncome - dayExpense
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "দিনের নিট স্থিতি",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = BanglaHelper.formatCurrency(dayBalance),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (dayBalance >= 0) IncomeGreen else ExpenseRed
                        )
                    }
                }
            }
        }
    }
}
