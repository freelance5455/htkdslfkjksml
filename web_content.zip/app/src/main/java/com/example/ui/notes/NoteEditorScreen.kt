package com.example.ui.notes

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SubjectEntity
import com.example.data.notes.BlockType
import com.example.data.notes.NoteAlignment
import com.example.data.notes.NoteFontFamily
import com.example.data.notes.RichNoteDocument
import com.example.ui.study.SubjectStylePresets

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteEditorScreen(
    title: String,
    document: RichNoteDocument,
    selectedSubjectId: Long?,
    isPinned: Boolean,
    autosaveStatus: AutosaveStatus,
    canUndo: Boolean,
    canRedo: Boolean,
    subjects: List<SubjectEntity>,
    onBackClick: () -> Unit,
    onTitleChange: (String) -> Unit,
    onDocumentChange: (RichNoteDocument, Boolean) -> Unit,
    onSubjectChange: (Long?) -> Unit,
    onTogglePin: () -> Unit,
    onFontFamilyChange: (String) -> Unit,
    onFontSizeChange: (Int) -> Unit,
    onAlignmentChange: (NoteAlignment) -> Unit,
    onBlockTypeChange: (Int, BlockType) -> Unit,
    onBlockTextChange: (Int, String) -> Unit,
    onToggleChecklist: (String) -> Unit,
    onAddBlock: (Int, BlockType) -> Unit,
    onRemoveBlock: (Int) -> Unit,
    onApplyInlineSpan: (Int, Int, Int, Boolean?, Boolean?, Boolean?, Boolean?, String?, String?) -> Unit,
    onUndoClick: () -> Unit,
    onRedoClick: () -> Unit,
    onSaveClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    // Intercept system back to ensure autosave executes cleanly
    BackHandler {
        onBackClick()
    }

    var showSubjectDropdown by remember { mutableStateOf(false) }
    var focusedBlockIndex by remember { mutableIntStateOf(0) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    // Active formatting states for the currently focused block
    var isBoldActive by remember { mutableStateOf(false) }
    var isItalicActive by remember { mutableStateOf(false) }
    var isUnderlineActive by remember { mutableStateOf(false) }
    var isStrikeActive by remember { mutableStateOf(false) }
    var currentTextColor by remember { mutableStateOf<String?>(null) }
    var currentHighlightColor by remember { mutableStateOf<String?>(null) }

    val activeFont = NoteFontFamily.fromKey(document.fontFamily).toComposeFontFamily()
    val activeAlign = document.alignment.toComposeTextAlign()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Autosave Status Badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    when (autosaveStatus) {
                                        AutosaveStatus.SAVING -> MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f)
                                        AutosaveStatus.SAVED -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                                        AutosaveStatus.IDLE -> Color.Transparent
                                    }
                                )
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = when (autosaveStatus) {
                                    AutosaveStatus.SAVING -> "Saving..."
                                    AutosaveStatus.SAVED -> "Saved"
                                    AutosaveStatus.IDLE -> ""
                                },
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBackClick,
                        modifier = Modifier.testTag("note_editor_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Save and go back"
                        )
                    }
                },
                actions = {
                    // Pin Note Button
                    IconButton(
                        onClick = onTogglePin,
                        modifier = Modifier.testTag("note_editor_pin_button")
                    ) {
                        Icon(
                            imageVector = if (isPinned) Icons.Default.PushPin else Icons.Outlined.PushPin,
                            contentDescription = if (isPinned) "Unpin Note" else "Pin Note",
                            tint = if (isPinned) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Explicit Save Button (PRD section 6.1)
                    IconButton(
                        onClick = onSaveClick,
                        modifier = Modifier.testTag("note_editor_save_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Save,
                            contentDescription = "Save Note",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }

                    // Delete Note Button
                    IconButton(
                        onClick = { showDeleteConfirm = true },
                        modifier = Modifier.testTag("note_editor_delete_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete Note",
                            tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            // Note Title Input
            BasicTextField(
                value = title,
                onValueChange = onTitleChange,
                textStyle = TextStyle(
                    fontFamily = activeFont,
                    fontWeight = FontWeight.Bold,
                    fontSize = 24.sp,
                    color = MaterialTheme.colorScheme.onSurface
                ),
                cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                decorationBox = { innerTextField ->
                    Box(modifier = Modifier.fillMaxWidth()) {
                        if (title.isEmpty()) {
                            Text(
                                text = "Note Title",
                                style = TextStyle(
                                    fontFamily = activeFont,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 24.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                                )
                            )
                        }
                        innerTextField()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .testTag("note_title_input")
            )

            // Optional Subject Linking Selector
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 8.dp)
            ) {
                val selectedSubject = subjects.firstOrNull { it.id == selectedSubjectId }

                Box {
                    Surface(
                        onClick = { showSubjectDropdown = true },
                        shape = RoundedCornerShape(8.dp),
                        color = selectedSubject?.let {
                            SubjectStylePresets.getColor(it.colorHex).copy(alpha = 0.15f)
                        } ?: MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.testTag("note_subject_picker_chip")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = selectedSubject?.name ?: "+ Link to Subject",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = selectedSubject?.let {
                                    SubjectStylePresets.getColor(it.colorHex)
                                } ?: MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (selectedSubject != null) {
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Remove subject",
                                    modifier = Modifier
                                        .size(14.dp)
                                        .clickable { onSubjectChange(null) }
                                )
                            }
                        }
                    }

                    DropdownMenu(
                        expanded = showSubjectDropdown,
                        onDismissRequest = { showSubjectDropdown = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("None") },
                            onClick = {
                                onSubjectChange(null)
                                showSubjectDropdown = false
                            }
                        )
                        subjects.forEach { sub ->
                            DropdownMenuItem(
                                leadingIcon = {
                                    Box(
                                        modifier = Modifier
                                            .size(12.dp)
                                            .clip(CircleShape)
                                            .background(SubjectStylePresets.getColor(sub.colorHex))
                                    )
                                },
                                text = { Text(sub.name) },
                                onClick = {
                                    onSubjectChange(sub.id)
                                    showSubjectDropdown = false
                                }
                            )
                        }
                    }
                }
            }

            // Rich-Text Formatting Toolbar (PRD section 6.2)
            val currentBlock = document.blocks.getOrNull(focusedBlockIndex) ?: document.blocks.firstOrNull()
            val activeType = currentBlock?.type ?: BlockType.PARAGRAPH

            NoteFormattingToolbar(
                currentFontFamily = document.fontFamily,
                currentFontSize = document.fontSize,
                currentAlignment = document.alignment,
                activeBlockType = activeType,
                isBoldActive = isBoldActive,
                isItalicActive = isItalicActive,
                isUnderlineActive = isUnderlineActive,
                isStrikeActive = isStrikeActive,
                currentTextColor = currentTextColor,
                currentHighlightColor = currentHighlightColor,
                canUndo = canUndo,
                canRedo = canRedo,
                onFontFamilySelected = onFontFamilyChange,
                onFontSizeChange = onFontSizeChange,
                onAlignmentSelected = onAlignmentChange,
                onBlockTypeSelected = { type ->
                    onBlockTypeChange(focusedBlockIndex, type)
                },
                onToggleBold = {
                    isBoldActive = !isBoldActive
                    applyActiveStyleToFocusedBlock(
                        blockIndex = focusedBlockIndex,
                        currentBlock = currentBlock,
                        isBold = isBoldActive,
                        isItalic = isItalicActive,
                        isUnderline = isUnderlineActive,
                        isStrike = isStrikeActive,
                        textColor = currentTextColor,
                        highlightColor = currentHighlightColor,
                        onApplySpan = onApplyInlineSpan
                    )
                },
                onToggleItalic = {
                    isItalicActive = !isItalicActive
                    applyActiveStyleToFocusedBlock(
                        blockIndex = focusedBlockIndex,
                        currentBlock = currentBlock,
                        isBold = isBoldActive,
                        isItalic = isItalicActive,
                        isUnderline = isUnderlineActive,
                        isStrike = isStrikeActive,
                        textColor = currentTextColor,
                        highlightColor = currentHighlightColor,
                        onApplySpan = onApplyInlineSpan
                    )
                },
                onToggleUnderline = {
                    isUnderlineActive = !isUnderlineActive
                    applyActiveStyleToFocusedBlock(
                        blockIndex = focusedBlockIndex,
                        currentBlock = currentBlock,
                        isBold = isBoldActive,
                        isItalic = isItalicActive,
                        isUnderline = isUnderlineActive,
                        isStrike = isStrikeActive,
                        textColor = currentTextColor,
                        highlightColor = currentHighlightColor,
                        onApplySpan = onApplyInlineSpan
                    )
                },
                onToggleStrike = {
                    isStrikeActive = !isStrikeActive
                    applyActiveStyleToFocusedBlock(
                        blockIndex = focusedBlockIndex,
                        currentBlock = currentBlock,
                        isBold = isBoldActive,
                        isItalic = isItalicActive,
                        isUnderline = isUnderlineActive,
                        isStrike = isStrikeActive,
                        textColor = currentTextColor,
                        highlightColor = currentHighlightColor,
                        onApplySpan = onApplyInlineSpan
                    )
                },
                onTextColorSelected = { hex ->
                    currentTextColor = hex
                    applyActiveStyleToFocusedBlock(
                        blockIndex = focusedBlockIndex,
                        currentBlock = currentBlock,
                        isBold = isBoldActive,
                        isItalic = isItalicActive,
                        isUnderline = isUnderlineActive,
                        isStrike = isStrikeActive,
                        textColor = hex,
                        highlightColor = currentHighlightColor,
                        onApplySpan = onApplyInlineSpan
                    )
                },
                onHighlightColorSelected = { hex ->
                    currentHighlightColor = hex
                    applyActiveStyleToFocusedBlock(
                        blockIndex = focusedBlockIndex,
                        currentBlock = currentBlock,
                        isBold = isBoldActive,
                        isItalic = isItalicActive,
                        isUnderline = isUnderlineActive,
                        isStrike = isStrikeActive,
                        textColor = currentTextColor,
                        highlightColor = hex,
                        onApplySpan = onApplyInlineSpan
                    )
                },
                onUndoClick = onUndoClick,
                onRedoClick = onRedoClick
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Content Area with Interactive Blocks & Checklists (PRD section 6.2)
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(document.blocks, key = { _, item -> item.id }) { index, block ->
                    BlockRowItem(
                        block = block,
                        index = index,
                        baseFontSizeSp = document.fontSize,
                        fontFamily = activeFont,
                        alignment = activeAlign,
                        isFocused = focusedBlockIndex == index,
                        onFocus = { focusedBlockIndex = index },
                        onTextChange = { onBlockTextChange(index, it) },
                        onToggleChecklist = { onToggleChecklist(block.id) },
                        onEnterPressed = {
                            val nextType = if (block.type == BlockType.CHECKLIST) BlockType.CHECKLIST else if (block.type == BlockType.BULLET) BlockType.BULLET else BlockType.PARAGRAPH
                            onAddBlock(index, nextType)
                            focusedBlockIndex = index + 1
                        },
                        onDeleteBlock = {
                            if (document.blocks.size > 1) {
                                onRemoveBlock(index)
                                focusedBlockIndex = (index - 1).coerceAtLeast(0)
                            }
                        }
                    )
                }

                // Add Next Item Button
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Button(
                            onClick = {
                                val lastIndex = document.blocks.size - 1
                                onAddBlock(lastIndex, BlockType.PARAGRAPH)
                                focusedBlockIndex = lastIndex + 1
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("add_note_block_button")
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Add Line / Paragraph")
                        }
                    }
                }
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete Note?") },
            text = { Text("Are you sure you want to delete this note? This action cannot be undone.") },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirm = false
                        onDeleteClick()
                    },
                    modifier = Modifier.testTag("confirm_delete_note_button")
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

private fun applyActiveStyleToFocusedBlock(
    blockIndex: Int,
    currentBlock: com.example.data.notes.LineBlock?,
    isBold: Boolean,
    isItalic: Boolean,
    isUnderline: Boolean,
    isStrike: Boolean,
    textColor: String?,
    highlightColor: String?,
    onApplySpan: (Int, Int, Int, Boolean?, Boolean?, Boolean?, Boolean?, String?, String?) -> Unit
) {
    if (currentBlock != null && currentBlock.text.isNotEmpty()) {
        onApplySpan(
            blockIndex,
            0,
            currentBlock.text.length,
            isBold,
            isItalic,
            isUnderline,
            isStrike,
            textColor,
            highlightColor
        )
    }
}

@Composable
private fun BlockRowItem(
    block: com.example.data.notes.LineBlock,
    index: Int,
    baseFontSizeSp: Int,
    fontFamily: androidx.compose.ui.text.font.FontFamily,
    alignment: androidx.compose.ui.text.style.TextAlign,
    isFocused: Boolean,
    onFocus: () -> Unit,
    onTextChange: (String) -> Unit,
    onToggleChecklist: () -> Unit,
    onEnterPressed: () -> Unit,
    onDeleteBlock: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onFocus() }
            .testTag("note_block_$index")
    ) {
        // Leading prefix icon/indicator
        when (block.type) {
            BlockType.CHECKLIST -> {
                Checkbox(
                    checked = block.isChecked,
                    onCheckedChange = { onToggleChecklist() },
                    colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.primary),
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("checklist_checkbox_$index")
                )
                Spacer(modifier = Modifier.width(4.dp))
            }
            BlockType.BULLET -> {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .padding(start = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
            }
            BlockType.NUMBERED -> {
                Text(
                    text = "${index + 1}.",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 4.dp, end = 6.dp)
                )
            }
            BlockType.HEADING_1 -> {
                Text(
                    text = "H1",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(end = 6.dp)
                )
            }
            BlockType.HEADING_2 -> {
                Text(
                    text = "H2",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.padding(end = 6.dp)
                )
            }
            BlockType.HEADING_3 -> {
                Text(
                    text = "H3",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.tertiary,
                    modifier = Modifier.padding(end = 6.dp)
                )
            }
            BlockType.PARAGRAPH -> {}
        }

        val textStyle = when (block.type) {
            BlockType.HEADING_1 -> TextStyle(
                fontFamily = fontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = (baseFontSizeSp * 1.5).coerceIn(16.0, 42.0).sp,
                textAlign = alignment,
                color = MaterialTheme.colorScheme.onSurface
            )
            BlockType.HEADING_2 -> TextStyle(
                fontFamily = fontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = (baseFontSizeSp * 1.3).coerceIn(14.0, 38.0).sp,
                textAlign = alignment,
                color = MaterialTheme.colorScheme.onSurface
            )
            BlockType.HEADING_3 -> TextStyle(
                fontFamily = fontFamily,
                fontWeight = FontWeight.SemiBold,
                fontSize = (baseFontSizeSp * 1.15).coerceIn(12.0, 36.0).sp,
                textAlign = alignment,
                color = MaterialTheme.colorScheme.onSurface
            )
            BlockType.CHECKLIST -> TextStyle(
                fontFamily = fontFamily,
                fontSize = baseFontSizeSp.sp,
                textAlign = alignment,
                textDecoration = if (block.isChecked) TextDecoration.LineThrough else TextDecoration.None,
                color = if (block.isChecked) MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f) else MaterialTheme.colorScheme.onSurface
            )
            else -> TextStyle(
                fontFamily = fontFamily,
                fontSize = baseFontSizeSp.sp,
                textAlign = alignment,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        BasicTextField(
            value = block.text,
            onValueChange = { onTextChange(it) },
            textStyle = textStyle,
            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
            keyboardActions = KeyboardActions(onNext = { onEnterPressed() }),
            decorationBox = { innerTextField ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    if (block.text.isEmpty()) {
                        Text(
                            text = when (block.type) {
                                BlockType.CHECKLIST -> "Checklist task..."
                                BlockType.HEADING_1 -> "Heading 1..."
                                BlockType.HEADING_2 -> "Heading 2..."
                                BlockType.HEADING_3 -> "Heading 3..."
                                BlockType.BULLET -> "List item..."
                                BlockType.NUMBERED -> "Numbered item..."
                                else -> "Type something..."
                            },
                            style = textStyle.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f)
                            )
                        )
                    }
                    innerTextField()
                }
            },
            modifier = Modifier
                .weight(1f)
                .clickable { onFocus() }
                .testTag("block_text_field_$index")
        )

        // Quick delete line button if focused and text is empty
        if (isFocused && block.text.isEmpty()) {
            IconButton(
                onClick = onDeleteBlock,
                modifier = Modifier.size(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Delete empty block",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}
