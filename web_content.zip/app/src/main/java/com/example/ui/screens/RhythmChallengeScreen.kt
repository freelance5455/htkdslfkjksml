package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.db.GameStatsState
import com.example.data.db.SrsWordEntity
import com.example.data.model.BadgeItem
import com.example.data.model.DailyChallenge
import com.example.data.model.QuizDirection
import com.example.data.model.QuizQuestion
import com.example.data.model.RhythmResult
import com.example.ui.LexicoViewModel
import com.example.ui.Screen
import com.example.ui.theme.HighlightGold
import com.example.ui.theme.HighlightGoldContainer
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SuccessGreenContainer
import com.example.ui.theme.WarningRed
import com.example.ui.theme.WarningRedContainer
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RhythmChallengeScreen(
    viewModel: LexicoViewModel,
    srsWords: List<SrsWordEntity>,
    gameStats: GameStatsState,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Desafío de Ritmo, 1: Desafíos y Medallas
    var selectedDirection by remember { mutableStateOf<QuizDirection?>(null) } // null = Alternado / Ambos
    var currentQuestionIndex by remember { mutableIntStateOf(0) }

    // Generate dynamic questions based on available words
    val questions = remember(srsWords, selectedDirection) {
        generateQuizQuestions(srsWords, selectedDirection)
    }

    val currentQuestion = questions.getOrNull(currentQuestionIndex % questions.size.coerceAtLeast(1))

    // Rhythm timer state
    var questionStartTime by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var elapsedTimeMs by remember { mutableLongStateOf(0L) }
    var selectedOptionIndex by remember { mutableStateOf<Int?>(null) }
    var isAnswerSubmitted by remember { mutableStateOf(false) }
    var lastRhythmFeedback by remember { mutableStateOf<String?>(null) }
    var lastPointsEarned by remember { mutableIntStateOf(0) }

    // Timer coroutine that tracks live rhythm bar
    LaunchedEffect(currentQuestionIndex, isAnswerSubmitted) {
        if (!isAnswerSubmitted && currentQuestion != null) {
            questionStartTime = System.currentTimeMillis()
            while (!isAnswerSubmitted) {
                elapsedTimeMs = System.currentTimeMillis() - questionStartTime
                delay(80L)
            }
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Desafío con Ritmo",
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = HighlightGoldContainer
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.EmojiEvents,
                                    contentDescription = null,
                                    tint = HighlightGold,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${gameStats.totalScore} pts",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 12.sp,
                                    color = Color(0xFF78350F)
                                )
                            }
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateTo(Screen.Flashcards) }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                },
                actions = {
                    // Flame Streak
                    if (gameStats.currentStreak > 0) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = WarningRedContainer,
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.LocalFireDepartment,
                                    contentDescription = null,
                                    tint = WarningRed,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(2.dp))
                                Text(
                                    text = "x${gameStats.comboMultiplier} (${gameStats.currentStreak})",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    color = WarningRed
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Tabs: 0 -> Juego con Ritmo, 1 -> Desafíos & Medallas
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Desafío con Ritmo 🎵") }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Logros & Desafíos 🏆") }
                )
            }

            if (selectedTab == 0) {
                // GAMEPLAY TAB
                if (questions.isEmpty()) {
                    // Empty state: need words first
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Psychology,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(64.dp)
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "Aún no hay palabras registradas",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Escanea un PDF o un texto de muestra primero y marca las palabras que no conozcas para jugar.",
                                style = MaterialTheme.typography.bodyMedium,
                                textAlign = TextAlign.Center,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                            )
                            Spacer(modifier = Modifier.height(20.dp))
                            Button(
                                onClick = { viewModel.navigateTo(Screen.Home) },
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Ir a escanear material")
                            }
                        }
                    }
                } else if (currentQuestion != null) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 18.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Direction Selector (Directo vs Al Revés vs Alternado)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                selected = selectedDirection == null,
                                onClick = {
                                    selectedDirection = null
                                    isAnswerSubmitted = false
                                    selectedOptionIndex = null
                                },
                                label = { Text("Al Derecho y Al Revés 🔁", fontSize = 11.sp) }
                            )
                            FilterChip(
                                selected = selectedDirection == QuizDirection.MEANING_TO_WORD,
                                onClick = {
                                    selectedDirection = QuizDirection.MEANING_TO_WORD
                                    isAnswerSubmitted = false
                                    selectedOptionIndex = null
                                },
                                label = { Text("Solo Al Revés 🔀", fontSize = 11.sp) }
                            )
                            FilterChip(
                                selected = selectedDirection == QuizDirection.WORD_TO_MEANING,
                                onClick = {
                                    selectedDirection = QuizDirection.WORD_TO_MEANING
                                    isAnswerSubmitted = false
                                    selectedOptionIndex = null
                                },
                                label = { Text("Solo Directo ➡️", fontSize = 11.sp) }
                            )
                        }

                        // LIVE RHYTHM INDICATOR BAR
                        RhythmBarView(elapsedTimeMs = elapsedTimeMs, isSubmitted = isAnswerSubmitted)

                        // QUESTION CARD (Handles both WORD -> MEANING and MEANING -> WORD)
                        QuestionCardView(
                            question = currentQuestion,
                            onSpeak = { viewModel.speakText(currentQuestion.displayWord) }
                        )

                        // 4 MULTIPLE-CHOICE OPTIONS
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            currentQuestion.options.forEachIndexed { index, optionText ->
                                val isSelected = selectedOptionIndex == index
                                val isCorrectOption = index == currentQuestion.correctIndex

                                val buttonColor = when {
                                    !isAnswerSubmitted -> MaterialTheme.colorScheme.surface
                                    isCorrectOption -> SuccessGreenContainer
                                    isSelected -> WarningRedContainer
                                    else -> MaterialTheme.colorScheme.surface
                                }

                                val textColor = when {
                                    !isAnswerSubmitted -> MaterialTheme.colorScheme.onSurface
                                    isCorrectOption -> SuccessGreen
                                    isSelected -> WarningRed
                                    else -> MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                }

                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable(enabled = !isAnswerSubmitted) {
                                            selectedOptionIndex = index
                                            isAnswerSubmitted = true
                                            val isCorrect = (index == currentQuestion.correctIndex)
                                            val (points, rhythm) = viewModel.recordQuizAnswer(
                                                isCorrect = isCorrect,
                                                direction = currentQuestion.direction,
                                                elapsedTimeMs = elapsedTimeMs
                                            )
                                            lastPointsEarned = points
                                            lastRhythmFeedback = rhythm?.message
                                            if (isCorrect) {
                                                viewModel.speakText(currentQuestion.displayWord)
                                            }
                                        }
                                        .testTag("quiz_option_$index"),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = CardDefaults.cardColors(containerColor = buttonColor),
                                    border = androidx.compose.foundation.BorderStroke(
                                        width = if (isSelected || (isAnswerSubmitted && isCorrectOption)) 2.dp else 1.dp,
                                        color = when {
                                            isAnswerSubmitted && isCorrectOption -> SuccessGreen
                                            isAnswerSubmitted && isSelected -> WarningRed
                                            else -> MaterialTheme.colorScheme.outlineVariant
                                        }
                                    )
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(28.dp)
                                                .clip(CircleShape)
                                                .background(MaterialTheme.colorScheme.surfaceVariant),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = ('A'.code + index).toChar().toString(),
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Text(
                                            text = optionText,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = if (isSelected || (isAnswerSubmitted && isCorrectOption)) FontWeight.Bold else FontWeight.Normal,
                                            color = textColor,
                                            modifier = Modifier.weight(1f)
                                        )
                                        if (isAnswerSubmitted) {
                                            if (isCorrectOption) {
                                                Icon(Icons.Default.Check, contentDescription = null, tint = SuccessGreen)
                                            } else if (isSelected) {
                                                Icon(Icons.Default.Close, contentDescription = null, tint = WarningRed)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // FEEDBACK BANNER & NEXT BUTTON
                        if (isAnswerSubmitted) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (selectedOptionIndex == currentQuestion.correctIndex) SuccessGreenContainer else WarningRedContainer
                                )
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    val isCorrect = selectedOptionIndex == currentQuestion.correctIndex
                                    Text(
                                        text = if (isCorrect) "¡CORRECTO! 🎯" else "¡Ups, no pasa nada! 💡",
                                        fontWeight = FontWeight.Black,
                                        fontSize = 16.sp,
                                        color = if (isCorrect) SuccessGreen else WarningRed
                                    )
                                    if (isCorrect) {
                                        Text(
                                            text = "+$lastPointsEarned pts • ${lastRhythmFeedback ?: "¡Bien hecho!"}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp,
                                            color = SuccessGreen
                                        )
                                    } else {
                                        Text(
                                            text = "La respuesta correcta era: \"${currentQuestion.displayWord}\"",
                                            fontSize = 13.sp,
                                            color = WarningRed
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Button(
                                        onClick = {
                                            currentQuestionIndex++
                                            isAnswerSubmitted = false
                                            selectedOptionIndex = null
                                            lastRhythmFeedback = null
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text("Siguiente pregunta ⏩", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                // LOGROS & DESAFÍOS TAB
                ChallengesAndRewardsView(gameStats = gameStats)
            }
        }
    }
}

@Composable
private fun RhythmBarView(
    elapsedTimeMs: Long,
    isSubmitted: Boolean
) {
    val seconds = elapsedTimeMs / 1000f
    // Perfect rhythm zone: 2s to 6s
    val isInRhythm = seconds in 2.0f..6.0f
    val isTooFast = seconds < 2.0f
    val isTooSlow = seconds > 6.0f

    val barProgress = (seconds / 8.0f).coerceIn(0f, 1f)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isInRhythm) HighlightGoldContainer.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.MusicNote,
                        contentDescription = null,
                        tint = if (isInRhythm) HighlightGold else MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = when {
                            isInRhythm -> "¡ZONA DE RITMO PERFECTO! (x2 Combo)"
                            isTooFast -> "Cargando ritmo..."
                            else -> "Ritmo estándar"
                        },
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (isInRhythm) Color(0xFF78350F) else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Text(
                    text = String.format("%.1fs", seconds),
                    fontWeight = FontWeight.Black,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Rhythm progress meter
            LinearProgressIndicator(
                progress = { barProgress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(CircleShape),
                color = when {
                    isInRhythm -> HighlightGold
                    isTooFast -> MaterialTheme.colorScheme.primary
                    else -> WarningRed
                },
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
        }
    }
}

@Composable
private fun QuestionCardView(
    question: QuizQuestion,
    onSpeak: () -> Unit
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 3.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            // Mode Banner
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (question.direction == QuizDirection.MEANING_TO_WORD) HighlightGoldContainer else MaterialTheme.colorScheme.primaryContainer
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.SwapHoriz,
                        contentDescription = null,
                        tint = if (question.direction == QuizDirection.MEANING_TO_WORD) HighlightGold else MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (question.direction == QuizDirection.MEANING_TO_WORD)
                            "MODO INVERSO (AL REVÉS) 🔀"
                        else
                            "MODO DIRECTO ➡️",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Black,
                        color = if (question.direction == QuizDirection.MEANING_TO_WORD) Color(0xFF78350F) else MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (question.direction == QuizDirection.MEANING_TO_WORD) {
                // AL REVÉS: Displays Meaning + Image + Sentence with blank -> Guess the Word!
                Text(
                    text = "¿A qué palabra se refiere este significado?",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Colloquial Definition Box
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "💬 Definición coloquial:",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = question.colloquialMeaning,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            lineHeight = 20.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "👉 En una sola palabra: \"${question.simpleSynonym}\"",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = HighlightGold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Image
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    AsyncImage(
                        model = ImageRequest.Builder(LocalContext.current)
                            .data(question.imageUrl)
                            .crossfade(true)
                            .build(),
                        contentDescription = "Pista visual",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Sentence context with Blank
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ) {
                    Text(
                        text = "📄 En el PDF: \"${question.sentenceWithBlank}\"",
                        modifier = Modifier.padding(10.dp),
                        style = MaterialTheme.typography.bodySmall,
                        fontStyle = FontStyle.Italic,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                // DIRECTO: Word -> Select Meaning!
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "¿Cuál es el significado coloquial de:",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                        Text(
                            text = question.displayWord,
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    IconButton(onClick = onSpeak) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = "Pronunciar",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Context sentence
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ) {
                    Text(
                        text = "📄 Contexto original: \"${question.originalSentence}\"",
                        modifier = Modifier.padding(10.dp),
                        style = MaterialTheme.typography.bodySmall,
                        fontStyle = FontStyle.Italic,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun ChallengesAndRewardsView(
    gameStats: GameStatsState
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Level & Points Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "NIVEL ${gameStats.level}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = gameStats.levelTitle,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Black,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }

                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "👑",
                                fontSize = 24.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    val levelProgress = (gameStats.totalScore.toFloat() / gameStats.nextLevelScore.toFloat()).coerceIn(0f, 1f)
                    LinearProgressIndicator(
                        progress = { levelProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(CircleShape),
                        color = MaterialTheme.colorScheme.primary
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "${gameStats.totalScore} / ${gameStats.nextLevelScore} puntos para el siguiente nivel",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                    )
                }
            }
        }

        // Daily Challenges
        item {
            Text(
                text = "Desafíos de Estudio",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        items(gameStats.challenges) { challenge ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (challenge.isCompleted) SuccessGreenContainer else MaterialTheme.colorScheme.surfaceVariant
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (challenge.isCompleted) "✅" else "🎯",
                            fontSize = 20.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = challenge.title,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = challenge.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { challenge.currentCount.toFloat() / challenge.targetCount.toFloat() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(CircleShape),
                            color = if (challenge.isCompleted) SuccessGreen else MaterialTheme.colorScheme.primary
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = HighlightGoldContainer
                    ) {
                        Text(
                            text = "+${challenge.rewardPoints} pts",
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF78350F)
                        )
                    }
                }
            }
        }

        // Badges / Medals
        item {
            Text(
                text = "Medallas Desbloqueadas",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        items(gameStats.badges) { badge ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (badge.isUnlocked) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (badge.isUnlocked) badge.iconEmoji else "🔒",
                        fontSize = 28.sp
                    )
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = badge.title,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (badge.isUnlocked) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                        )
                        Text(
                            text = badge.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (badge.isUnlocked) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f) else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                        )
                    }
                    if (badge.isUnlocked) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = SuccessGreenContainer
                        ) {
                            Text(
                                text = "¡Conseguida!",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = SuccessGreen
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun generateQuizQuestions(
    words: List<SrsWordEntity>,
    fixedDirection: QuizDirection?
): List<QuizQuestion> {
    if (words.isEmpty()) return emptyList()

    val result = mutableListOf<QuizQuestion>()

    for ((index, word) in words.withIndex()) {
        val direction = fixedDirection ?: if (index % 2 == 0) QuizDirection.WORD_TO_MEANING else QuizDirection.MEANING_TO_WORD

        // Sentence with blank
        val target = word.displayWord
        val sentenceWithBlank = if (word.originalSentence.contains(target, ignoreCase = true)) {
            val idx = word.originalSentence.indexOf(target, ignoreCase = true)
            word.originalSentence.substring(0, idx) + "[  _______  ]" + word.originalSentence.substring(idx + target.length)
        } else {
            "...[  _______  ]..."
        }

        // Generate options (1 correct + up to 3 distractors)
        val options: List<String>
        val correctIndex: Int

        if (direction == QuizDirection.MEANING_TO_WORD) {
            // Options are WORDS
            val correctOption = word.displayWord
            val otherWords = words.filter { it.id != word.id }.map { it.displayWord }.shuffled().take(3)
            val combined = (listOf(correctOption) + otherWords).shuffled()
            options = combined
            correctIndex = combined.indexOf(correctOption)
        } else {
            // Options are COLLOQUIAL MEANINGS / SYNONYMS
            val correctOption = "${word.simpleSynonym}: ${word.colloquialMeaning}"
            val otherMeanings = words.filter { it.id != word.id }.map { "${it.simpleSynonym}: ${it.colloquialMeaning}" }.shuffled().take(3)
            val combined = (listOf(correctOption) + otherMeanings).shuffled()
            options = combined
            correctIndex = combined.indexOf(correctOption)
        }

        result.add(
            QuizQuestion(
                id = "${word.id}_$index",
                direction = direction,
                targetWord = word.word,
                displayWord = word.displayWord,
                simpleSynonym = word.simpleSynonym,
                colloquialMeaning = word.colloquialMeaning,
                imageUrl = word.imageUrl,
                originalSentence = word.originalSentence,
                sentenceWithBlank = sentenceWithBlank,
                options = options,
                correctIndex = correctIndex
            )
        )
    }

    return result
}
