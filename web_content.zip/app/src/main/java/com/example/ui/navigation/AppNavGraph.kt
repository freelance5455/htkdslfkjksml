package com.example.ui.navigation

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.AirportSearchDialog
import com.example.ui.components.AtcDrawer
import com.example.ui.components.AtcTopBar
import com.example.ui.screens.about.AboutScreen
import com.example.ui.screens.airport.AirportWeatherScreen
import com.example.ui.screens.board.AtcBoardScreen
import com.example.ui.screens.guide.IcaoGuideScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.map.WeatherMapScreen
import com.example.ui.screens.metar.MetarScreen
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.sigmet.SigmetScreen
import com.example.ui.screens.snowtam.SnowtamScreen
import com.example.ui.screens.taf.TafScreen
import com.example.ui.screens.windaloft.WindAloftScreen
import com.example.ui.viewmodel.WeatherViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppNavGraph(
  viewModel: WeatherViewModel = viewModel(),
  modifier: Modifier = Modifier
) {
  var currentScreen by remember { mutableStateOf(Screen.HOME) }
  var showSearchDialog by remember { mutableStateOf(false) }

  val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
  val scope = rememberCoroutineScope()
  val selectedAirport by viewModel.selectedAirport.collectAsState()

  // Handle back button: if on secondary screen, go back to HOME
  if (currentScreen != Screen.HOME) {
    BackHandler {
      currentScreen = Screen.HOME
    }
  }

  // Force RTL Layout Direction for Persian operational interface
  CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
    ModalNavigationDrawer(
      drawerState = drawerState,
      gesturesEnabled = true,
      drawerContent = {
        AtcDrawer(
          currentScreen = currentScreen,
          selectedAirport = selectedAirport,
          onNavigateTo = { screen ->
            currentScreen = screen
          },
          onCloseDrawer = {
            scope.launch { drawerState.close() }
          }
        )
      }
    ) {
      Scaffold(
        topBar = {
          AtcTopBar(
            currentScreen = currentScreen,
            selectedAirport = selectedAirport,
            onOpenDrawer = {
              scope.launch { drawerState.open() }
            },
            onOpenSearch = {
              showSearchDialog = true
            },
            onRefresh = {
              viewModel.refreshAll()
            }
          )
        },
        modifier = modifier.fillMaxSize()
      ) { innerPadding ->
        Box(
          modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
        ) {
          when (currentScreen) {
            Screen.HOME -> HomeScreen(
              viewModel = viewModel,
              onNavigateTo = { currentScreen = it }
            )
            Screen.AIRPORT_WEATHER -> AirportWeatherScreen(
              viewModel = viewModel,
              onNavigateTo = { currentScreen = it }
            )
            Screen.METAR -> MetarScreen(
              viewModel = viewModel
            )
            Screen.TAF -> TafScreen(
              viewModel = viewModel
            )
            Screen.SIGMET -> SigmetScreen(
              viewModel = viewModel
            )
            Screen.WIND_ALOFT -> WindAloftScreen(
              viewModel = viewModel
            )
            Screen.SNOWTAM -> SnowtamScreen(
              viewModel = viewModel,
              onNavigateTo = { currentScreen = it }
            )
            Screen.WEATHER_MAP -> WeatherMapScreen(
              viewModel = viewModel,
              onNavigateTo = { currentScreen = it }
            )
            Screen.ATC_BOARD -> AtcBoardScreen(
              viewModel = viewModel,
              onNavigateTo = { currentScreen = it }
            )
            Screen.ICAO_GUIDE -> IcaoGuideScreen()
            Screen.SETTINGS -> SettingsScreen(
              viewModel = viewModel,
              onNavigateTo = { currentScreen = it }
            )
            Screen.ABOUT -> AboutScreen(
              viewModel = viewModel
            )
          }
        }
      }
    }

    if (showSearchDialog) {
      AirportSearchDialog(
        viewModel = viewModel,
        onDismiss = { showSearchDialog = false },
        onAirportSelected = {
          showSearchDialog = false
          currentScreen = Screen.AIRPORT_WEATHER
        }
      )
    }
  }
}
