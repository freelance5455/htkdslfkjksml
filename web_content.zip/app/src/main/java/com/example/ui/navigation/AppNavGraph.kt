package com.example.ui.navigation

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.LayoutDirection
import com.example.ui.theme.OceanBlue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.AirportSearchDialog
import com.example.ui.components.AtcDrawer
import com.example.ui.components.AtcTopBar
import com.example.ui.screens.about.AboutScreen
import com.example.ui.screens.airport.AirportWeatherScreen
import com.example.ui.screens.board.AtcBoardScreen
import com.example.ui.screens.guide.IcaoGuideScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.map.WeatherMapScreen
import com.example.ui.screens.metar.MetarScreen
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.sigmet.SigmetScreen
import com.example.ui.screens.snowtam.SnowtamScreen
import com.example.ui.screens.taf.TafScreen
import com.example.ui.screens.windaloft.WindAloftScreen
import com.example.ui.viewmodel.WeatherViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppNavGraph(
  viewModel: WeatherViewModel = viewModel(),
  modifier: Modifier = Modifier
) {
  var currentScreen by remember { mutableStateOf(Screen.HOME) }
  var showSearchDialog by remember { mutableStateOf(false) }

  val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
  val scope = rememberCoroutineScope()
  val selectedAirport by viewModel.selectedAirport.collectAsState()

  // Handle back button: if on secondary screen, go back to HOME
  if (currentScreen != Screen.HOME) {
    BackHandler {
      currentScreen = Screen.HOME
    }
  }

  // Standard LTR Layout Direction for English Aviation Operational Interface
  CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
    ModalNavigationDrawer(
      drawerState = drawerState,
      gesturesEnabled = true,
      drawerContent = {
        AtcDrawer(
          currentScreen = currentScreen,
          selectedAirport = selectedAirport,
          onNavigateTo = { screen ->
            currentScreen = screen
          },
          onCloseDrawer = {
            scope.launch { drawerState.close() }
          }
        )
      }
    ) {
      Scaffold(
        topBar = {
          AtcTopBar(
            currentScreen = currentScreen,
            selectedAirport = selectedAirport,
            onOpenDrawer = {
              scope.launch { drawerState.open() }
            },
            onOpenSearch = {
              showSearchDialog = true
            },
            onRefresh = {
              viewModel.refreshAll()
            }
          )
        },
        bottomBar = {
          val bottomNavItems = listOf(
            Triple(Screen.HOME, "داشبورد", Icons.Default.Dashboard),
            Triple(Screen.METAR, "METAR", Icons.Default.Cloud),
            Triple(Screen.TAF, "TAF", Icons.Default.Schedule),
            Triple(Screen.SIGMET, "SIGMET", Icons.Default.Warning),
            Triple(Screen.WIND_ALOFT, "WIND ALOFT", Icons.Default.Air),
            Triple(Screen.SNOWTAM, "SNOWTAM", Icons.Default.AcUnit)
          )

          NavigationBar(
            containerColor = OceanBlue,
            tonalElevation = 8.dp,
            modifier = Modifier.testTag("atc_bottom_navigation")
          ) {
            bottomNavItems.forEach { (screen, label, icon) ->
              val isSelected = currentScreen == screen
              NavigationBarItem(
                selected = isSelected,
                onClick = { currentScreen = screen },
                icon = {
                  Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = if (isSelected) Color.White else Color(0xFFBAE6FD)
                  )
                },
                label = {
                  Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                    color = if (isSelected) Color.White else Color(0xFFBAE6FD)
                  )
                },
                colors = NavigationBarItemDefaults.colors(
                  selectedIconColor = Color.White,
                  selectedTextColor = Color.White,
                  unselectedIconColor = Color(0xFFBAE6FD),
                  unselectedTextColor = Color(0xFFBAE6FD),
                  indicatorColor = Color.White.copy(alpha = 0.22f)
                )
              )
            }
          }
        },
        modifier = modifier.fillMaxSize()
      ) { innerPadding ->
        Box(
          modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
        ) {
          when (currentScreen) {
            Screen.HOME -> HomeScreen(
              viewModel = viewModel,
              onNavigateTo = { currentScreen = it }
            )
            Screen.AIRPORT_WEATHER -> AirportWeatherScreen(
              viewModel = viewModel,
              onNavigateTo = { currentScreen = it }
            )
            Screen.METAR -> MetarScreen(
              viewModel = viewModel
            )
            Screen.TAF -> TafScreen(
              viewModel = viewModel
            )
            Screen.SIGMET -> SigmetScreen(
              viewModel = viewModel
            )
            Screen.WIND_ALOFT -> WindAloftScreen(
              viewModel = viewModel
            )
            Screen.SNOWTAM -> SnowtamScreen(
              viewModel = viewModel,
              onNavigateTo = { currentScreen = it }
            )
            Screen.WEATHER_MAP -> WeatherMapScreen(
              viewModel = viewModel,
              onNavigateTo = { currentScreen = it }
            )
            Screen.ATC_BOARD -> AtcBoardScreen(
              viewModel = viewModel,
              onNavigateTo = { currentScreen = it }
            )
            Screen.ICAO_GUIDE -> IcaoGuideScreen()
            Screen.SETTINGS -> SettingsScreen(
              viewModel = viewModel,
              onNavigateTo = { currentScreen = it }
            )
            Screen.ABOUT -> AboutScreen(
              viewModel = viewModel
            )
          }
        }
      }
    }

    if (showSearchDialog) {
      AirportSearchDialog(
        viewModel = viewModel,
        onDismiss = { showSearchDialog = false },
        onAirportSelected = {
          showSearchDialog = false
          currentScreen = Screen.AIRPORT_WEATHER
        }
      )
    }
  }
}
