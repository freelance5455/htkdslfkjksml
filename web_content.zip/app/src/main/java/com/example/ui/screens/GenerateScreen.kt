package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.generator.QrColorTheme
import com.example.generator.QrGenerator
import com.example.model.QrCategory
import com.example.ui.theme.CyanPrimary
import com.example.viewmodel.ScannerViewModel
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GenerateScreen(
    viewModel: ScannerViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val selectedCategory by viewModel.generatorCategory.collectAsState()
    val input1 by viewModel.generatorInput1.collectAsState()
    val input2 by viewModel.generatorInput2.collectAsState()
    val input3 by viewModel.generatorInput3.collectAsState()
    val selectedTheme by viewModel.selectedTheme.collectAsState()
    val generatedBitmap by viewModel.generatedBitmap.collectAsState()

    LaunchedEffect(Unit) {
        viewModel.rebuildGeneratedQr()
    }

    val categories = listOf(
        QrCategory.URL to Icons.Default.Language,
        QrCategory.TEXT to Icons.Default.TextFields,
        QrCategory.WIFI to Icons.Default.Wifi,
        QrCategory.CONTACT to Icons.Default.Person,
        QrCategory.PHONE to Icons.Default.Call,
        QrCategory.EMAIL to Icons.Default.Email,
        QrCategory.SMS to Icons.Default.Sms
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .padding(horizontal = 20.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Spacer(modifier = Modifier.height(6.dp))

        // Title Header
        Text(
            text = "Generate QR Code",
            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.ExtraBold)
        )
        Text(
            text = "Create custom styled QR codes for links, Wi-Fi, contacts & more.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        // Category Selection Pills
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            categories.forEach { (cat, icon) ->
                val isSelected = selectedCategory == cat
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            if (isSelected) CyanPrimary else MaterialTheme.colorScheme.surfaceVariant
                        )
                        .clickable { viewModel.setGeneratorCategory(cat) }
                        .padding(horizontal = 14.dp, vertical = 9.dp)
                        .testTag("gen_type_${cat.name.lowercase()}"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = cat.displayName,
                        tint = if (isSelected) Color(0xFF00363D) else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = cat.displayName,
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Color(0xFF00363D) else MaterialTheme.colorScheme.onSurface
                        )
                    )
                }
            }
        }

        // Input Fields Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                when (selectedCategory) {
                    QrCategory.URL -> {
                        OutlinedTextField(
                            value = input1,
                            onValueChange = { viewModel.setGeneratorInput1(it) },
                            label = { Text("Website URL") },
                            placeholder = { Text("https://example.com") },
                            modifier = Modifier.fillMaxWidth().testTag("input_url"),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                    QrCategory.TEXT -> {
                        OutlinedTextField(
                            value = input1,
                            onValueChange = { viewModel.setGeneratorInput1(it) },
                            label = { Text("Enter Any Text") },
                            placeholder = { Text("Notes, instructions, or codes...") },
                            modifier = Modifier.fillMaxWidth().height(110.dp).testTag("input_text"),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                    QrCategory.WIFI -> {
                        OutlinedTextField(
                            value = input1,
                            onValueChange = { viewModel.setGeneratorInput1(it) },
                            label = { Text("Wi-Fi Network Name (SSID)") },
                            modifier = Modifier.fillMaxWidth().testTag("input_wifi_ssid"),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )
                        OutlinedTextField(
                            value = input2,
                            onValueChange = { viewModel.setGeneratorInput2(it) },
                            label = { Text("Password") },
                            modifier = Modifier.fillMaxWidth().testTag("input_wifi_pass"),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )
                        // Security Selector
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Security:", style = MaterialTheme.typography.bodySmall)
                            listOf("WPA", "WEP", "nopass").forEach { sec ->
                                val sel = (input3 == sec) || (input3.isBlank() && sec == "WPA")
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (sel) CyanPrimary else MaterialTheme.colorScheme.surface)
                                        .clickable { viewModel.setGeneratorInput3(sec) }
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = if (sec == "nopass") "Open" else sec,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = if (sel) Color(0xFF00363D) else MaterialTheme.colorScheme.onSurface
                                        )
                                    )
                                }
                            }
                        }
                    }
                    QrCategory.CONTACT -> {
                        OutlinedTextField(
                            value = input1,
                            onValueChange = { viewModel.setGeneratorInput1(it) },
                            label = { Text("Full Name") },
                            modifier = Modifier.fillMaxWidth().testTag("input_contact_name"),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )
                        OutlinedTextField(
                            value = input2,
                            onValueChange = { viewModel.setGeneratorInput2(it) },
                            label = { Text("Phone Number") },
                            modifier = Modifier.fillMaxWidth().testTag("input_contact_phone"),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )
                        OutlinedTextField(
                            value = input3,
                            onValueChange = { viewModel.setGeneratorInput3(it) },
                            label = { Text("Email Address") },
                            modifier = Modifier.fillMaxWidth().testTag("input_contact_email"),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                    QrCategory.PHONE -> {
                        OutlinedTextField(
                            value = input1,
                            onValueChange = { viewModel.setGeneratorInput1(it) },
                            label = { Text("Phone Number") },
                            placeholder = { Text("+1 (555) 000-0000") },
                            modifier = Modifier.fillMaxWidth().testTag("input_phone"),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                    QrCategory.EMAIL -> {
                        OutlinedTextField(
                            value = input1,
                            onValueChange = { viewModel.setGeneratorInput1(it) },
                            label = { Text("Recipient Email") },
                            modifier = Modifier.fillMaxWidth().testTag("input_email_to"),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )
                        OutlinedTextField(
                            value = input2,
                            onValueChange = { viewModel.setGeneratorInput2(it) },
                            label = { Text("Subject") },
                            modifier = Modifier.fillMaxWidth().testTag("input_email_sub"),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )
                        OutlinedTextField(
                            value = input3,
                            onValueChange = { viewModel.setGeneratorInput3(it) },
                            label = { Text("Message Body") },
                            modifier = Modifier.fillMaxWidth().height(80.dp).testTag("input_email_body"),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                    QrCategory.SMS -> {
                        OutlinedTextField(
                            value = input1,
                            onValueChange = { viewModel.setGeneratorInput1(it) },
                            label = { Text("Recipient Phone") },
                            modifier = Modifier.fillMaxWidth().testTag("input_sms_to"),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )
                        OutlinedTextField(
                            value = input2,
                            onValueChange = { viewModel.setGeneratorInput2(it) },
                            label = { Text("SMS Message") },
                            modifier = Modifier.fillMaxWidth().height(80.dp).testTag("input_sms_msg"),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                    else -> {}
                }
            }
        }

        // Color Themes
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "Styling Theme",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QrGenerator.THEMES.forEach { theme ->
                    val isSelected = selectedTheme.id == theme.id
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) CyanPrimary else Color.Transparent,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable { viewModel.setGeneratorTheme(theme) }
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .clip(CircleShape)
                                .background(Color(theme.foregroundColor))
                                .border(1.dp, Color.White.copy(alpha = 0.3f), CircleShape)
                        )
                        Text(
                            text = theme.name,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        )
                    }
                }
            }
        }

        // QR Code Preview Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Color(selectedTheme.backgroundColor))
                .border(1.dp, Color(selectedTheme.foregroundColor).copy(alpha = 0.3f), RoundedCornerShape(24.dp))
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            if (generatedBitmap != null) {
                Image(
                    bitmap = generatedBitmap!!.asImageBitmap(),
                    contentDescription = "Generated QR Code",
                    modifier = Modifier.size(240.dp)
                )
            } else {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(vertical = 40.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.QrCode,
                        contentDescription = null,
                        tint = Color.Gray,
                        modifier = Modifier.size(48.dp)
                    )
                    Text(
                        text = "Enter details above to render QR code",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.Gray
                    )
                }
            }
        }

        // Actions: Save to History & Favorites, Share, Copy
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { viewModel.saveGeneratedQrToHistory() },
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
                    .testTag("save_generated_qr_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary, contentColor = Color(0xFF00363D))
            ) {
                Icon(imageVector = Icons.Default.BookmarkAdd, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Save QR", fontWeight = FontWeight.Bold)
            }

            FilledTonalButton(
                onClick = {
                    generatedBitmap?.let { bmp ->
                        shareBitmap(context, bmp)
                    } ?: Toast.makeText(context, "Nothing to share", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
                    .testTag("share_generated_qr_button"),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(imageVector = Icons.Default.Share, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Share", fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(110.dp))
    }
}

private fun shareBitmap(context: Context, bitmap: Bitmap) {
    try {
        val cachePath = File(context.cacheDir, "images")
        cachePath.mkdirs()
        val file = File(cachePath, "scanova_qr_${System.currentTimeMillis()}.png")
        val stream = FileOutputStream(file)
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
        stream.close()

        val contentUri: Uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, contentUri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(intent, "Share QR Code Image")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    } catch (_: Exception) {
        // Fallback: share as intent
        Toast.makeText(context, "QR saved to cache for sharing", Toast.LENGTH_SHORT).show()
    }
}
