package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.localization.LocalAppStrings
import com.example.model.JobApplication
import com.example.model.SideQuest
import com.example.model.UserProfile
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.SideQuestCard
import com.example.ui.components.StatusPill
import com.example.ui.components.formatInr

@Composable
fun SideQuestsScreen(
  profile: UserProfile,
  quests: List<SideQuest>,
  onClaimQuest: (SideQuest) -> Unit,
  onSubmitProof: (SideQuest, String) -> Unit
) {
  val strings = LocalAppStrings.current
  var selectedTab by remember { mutableStateOf("AVAILABLE") }
  var proofTargetQuest by remember { mutableStateOf<SideQuest?>(null) }
  var proofInput by remember { mutableStateOf("") }

  val filteredQuests = remember(quests, selectedTab, profile.userId) {
    when (selectedTab) {
      "MY_ACTIVE" -> quests.filter {
        it.assignedSeekerId == profile.userId && it.questStatus in listOf("ASSIGNED", "COMPLETION_SUBMITTED")
      }
      "PAID" -> quests.filter {
        it.assignedSeekerId == profile.userId && it.questStatus == "PAID"
      }
      else -> quests.filter { it.questStatus == "OPEN" }
    }
  }

  LazyColumn(
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
    modifier = Modifier.fillMaxSize()
  ) {
    item {
      Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column {
          Image(
            painter = painterResource(id = R.drawable.img_sidequest_banner),
            contentDescription = "JOBY Side Quests illustration",
            contentScale = ContentScale.Crop,
            modifier = Modifier
              .fillMaxWidth()
              .height(125.dp)
              .clip(RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp))
          )
          Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Filled.Bolt, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "JOBY Side Quests",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSecondaryContainer
              )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "Legitimate, short-term micro-tasks with guaranteed INR payouts upon completion verification.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.85f)
            )
          }
        }
      }
    }

    item {
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        FilterChip(
          selected = selectedTab == "AVAILABLE",
          onClick = { selectedTab = "AVAILABLE" },
          label = { Text("Open Quests") }
        )
        FilterChip(
          selected = selectedTab == "MY_ACTIVE",
          onClick = { selectedTab = "MY_ACTIVE" },
          label = { Text("My Active") }
        )
        FilterChip(
          selected = selectedTab == "PAID",
          onClick = { selectedTab = "PAID" },
          label = { Text("Paid") }
        )
      }
    }

    if (filteredQuests.isEmpty()) {
      item {
        EmptyStateCard(
          icon = Icons.Filled.Bolt,
          title = "No Side Quests in this view",
          subtitle = "Check Open Quests or ask an Employer to post verified micro-tasks."
        )
      }
    } else {
      items(filteredQuests, key = { it.id }) { quest ->
        val isOwner = quest.employerId == profile.userId
        val ageBlocked = profile.age < quest.minAge || (quest.isHazardousOrRestricted && profile.age < 18L)
        Column {
          SideQuestCard(quest = quest, onClick = {})
          Spacer(modifier = Modifier.height(6.dp))
          Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Text(
                text = "Deliverable: ${quest.deliverableSpec}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface
              )
              if (quest.paymentReference.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = "Paid Ref: ${quest.paymentReference}",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.tertiary,
                  fontWeight = FontWeight.Bold
                )
              }
              Spacer(modifier = Modifier.height(8.dp))
              when {
                quest.questStatus == "OPEN" && !isOwner -> {
                  Button(
                    onClick = { onClaimQuest(quest) },
                    enabled = !ageBlocked,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("claim_quest_${quest.id}")
                  ) {
                    Text(if (ageBlocked) "18+ Restricted" else "${strings.claimQuest} (${formatInr(quest.payoutInr)})")
                  }
                }
                quest.questStatus == "ASSIGNED" && quest.assignedSeekerId == profile.userId -> {
                  Button(
                    onClick = {
                      proofInput = ""
                      proofTargetQuest = quest
                    },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("submit_proof_${quest.id}")
                  ) {
                    Text(strings.submitProof)
                  }
                }
                quest.questStatus == "COMPLETION_SUBMITTED" -> {
                  StatusPill(
                    text = "Completion Submitted · Awaiting Employer Verification",
                    containerColor = MaterialTheme.colorScheme.secondaryContainer,
                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                  )
                }
                quest.questStatus == "PAID" -> {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                      text = "Payout Verified & Paid (${formatInr(quest.payoutInr)})",
                      style = MaterialTheme.typography.labelMedium,
                      color = MaterialTheme.colorScheme.tertiary
                    )
                  }
                }
                isOwner -> {
                  Text(
                    text = "Posted by you · Manage in Employer Postings",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                  )
                }
              }
            }
          }
        }
      }
    }
  }

  if (proofTargetQuest != null) {
    AlertDialog(
      onDismissRequest = { proofTargetQuest = null },
      title = { Text("Submit Completion Proof") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(
            text = "Deliverable: ${proofTargetQuest!!.deliverableSpec}",
            style = MaterialTheme.typography.bodySmall
          )
          OutlinedTextField(
            value = proofInput,
            onValueChange = { proofInput = it.take(500) },
            label = { Text("Proof Summary / Notes *") },
            minLines = 3,
            modifier = Modifier.fillMaxWidth().testTag("proof_note_input")
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (proofInput.trim().length >= 5) {
              onSubmitProof(proofTargetQuest!!, proofInput)
              proofTargetQuest = null
            }
          }
        ) { Text("Send Proof") }
      },
      dismissButton = {
        TextButton(onClick = { proofTargetQuest = null }) { Text("Cancel") }
      }
    )
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SeekerApplicationsScreen(
  applications: List<JobApplication>,
  onWithdraw: (JobApplication) -> Unit,
  onMessageEmployer: (JobApplication) -> Unit
) {
  var statusFilter by remember { mutableStateOf("ALL") }
  val filtered = remember(applications, statusFilter) {
    when (statusFilter) {
      "ACTIVE" -> applications.filter { it.status in listOf("APPLIED", "VIEWED", "SHORTLISTED", "INTERVIEW") }
      "SELECTED" -> applications.filter { it.status == "SELECTED" }
      else -> applications
    }
  }

  LazyColumn(
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
    modifier = Modifier.fillMaxSize()
  ) {
    item {
      Text("My Applications", style = MaterialTheme.typography.headlineSmall)
      Spacer(modifier = Modifier.height(8.dp))
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(selected = statusFilter == "ALL", onClick = { statusFilter = "ALL" }, label = { Text("All (${applications.size})") })
        FilterChip(selected = statusFilter == "ACTIVE", onClick = { statusFilter = "ACTIVE" }, label = { Text("In Progress") })
        FilterChip(selected = statusFilter == "SELECTED", onClick = { statusFilter = "SELECTED" }, label = { Text("Selected") })
      }
    }

    if (filtered.isEmpty()) {
      item {
        EmptyStateCard(
          icon = Icons.Filled.Assignment,
          title = "No applications yet",
          subtitle = "Apply to any verified role with ₹0 application fees and track progress live here."
        )
      }
    } else {
      items(filtered, key = { it.id }) { app ->
        Card(
          shape = RoundedCornerShape(18.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(app.companyName, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                Text(app.jobTitle, style = MaterialTheme.typography.titleMedium)
              }
              val pillColors = when (app.status) {
                "SELECTED" -> MaterialTheme.colorScheme.tertiaryContainer to MaterialTheme.colorScheme.onTertiaryContainer
                "SHORTLISTED", "INTERVIEW" -> MaterialTheme.colorScheme.secondaryContainer to MaterialTheme.colorScheme.onSecondaryContainer
                "REJECTED", "WITHDRAWN" -> MaterialTheme.colorScheme.errorContainer to MaterialTheme.colorScheme.onErrorContainer
                else -> MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.onPrimaryContainer
              }
              StatusPill(text = app.status, containerColor = pillColors.first, contentColor = pillColors.second)
            }

            if (app.interviewNote.isNotBlank()) {
              Spacer(modifier = Modifier.height(8.dp))
              Surface(
                color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
              ) {
                Text(
                  text = "Employer Note: ${app.interviewNote}",
                  style = MaterialTheme.typography.bodySmall,
                  modifier = Modifier.padding(10.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(10.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              OutlinedButton(onClick = { onMessageEmployer(app) }) {
                Icon(Icons.Filled.Chat, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Chat")
              }
              if (app.status !in listOf("WITHDRAWN", "REJECTED", "SELECTED")) {
                TextButton(onClick = { onWithdraw(app) }) {
                  Text("Withdraw", color = MaterialTheme.colorScheme.error)
                }
              }
            }
          }
        }
      }
    }
  }
}
