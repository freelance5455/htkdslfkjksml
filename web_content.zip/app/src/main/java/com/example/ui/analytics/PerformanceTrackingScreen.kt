package com.example.ui.analytics

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.QueryBuilder
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TrendingFlat
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.analytics.PerformanceCalculator
import com.example.data.analytics.PerformanceMetrics
import com.example.data.analytics.PerformancePeriod
import com.example.data.model.StudySessionEntity
import com.example.data.model.SubjectEntity
import com.example.data.model.SubjectWithStats
import com.example.ui.study.SubjectStylePresets
import java.time.LocalDate
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PerformanceTrackingScreen(
    sessions: List<StudySessionEntity>,
    activeSubjects: List<SubjectWithStats>,
    subjectsMap: Map<Long, SubjectEntity>,
    onOpenDrawer: () -> Unit
) {
    var selectedPeriod by remember { mutableStateOf(PerformancePeriod.WEEKLY) }
    var weekOffset by remember { mutableIntStateOf(0) }
    var monthOffset by remember { mutableIntStateOf(0) }
    var yearOffset by remember { mutableIntStateOf(0) }

    val subjectNames = remember(subjectsMap) {
        subjectsMap.mapValues { it.value.name }
    }
    val subjectColors = remember(subjectsMap) {
        subjectsMap.mapValues { SubjectStylePresets.getColor(it.value.colorHex) }
    }

    // Compute metrics dynamically based on active tab and offset
    val metrics: PerformanceMetrics = remember(selectedPeriod, weekOffset, monthOffset, yearOffset, sessions, subjectNames) {
        when (selectedPeriod) {
            PerformancePeriod.WEEKLY -> PerformanceCalculator.calculateWeeklyPerformance(sessions, LocalDate.now(), weekOffset, subjectNames)
            PerformancePeriod.MONTHLY -> PerformanceCalculator.calculateMonthlyPerformance(sessions, LocalDate.now(), monthOffset, subjectNames)
            PerformancePeriod.YEARLY -> PerformanceCalculator.calculateYearlyPerformance(sessions, LocalDate.now(), yearOffset, subjectNames)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Performance Tracking",
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onOpenDrawer,
                        modifier = Modifier.testTag("perf_menu_drawer_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Menu,
                            contentDescription = "Open left navigation drawer"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Three Tabs: Weekly, Monthly, Yearly (PRD Section 5.4)
            PrimaryTabRow(
                selectedTabIndex = selectedPeriod.ordinal,
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .testTag("performance_tab_row")
            ) {
                Tab(
                    selected = selectedPeriod == PerformancePeriod.WEEKLY,
                    onClick = { selectedPeriod = PerformancePeriod.WEEKLY; weekOffset = 0 },
                    text = { Text("Weekly", fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("perf_tab_weekly")
                )
                Tab(
                    selected = selectedPeriod == PerformancePeriod.MONTHLY,
                    onClick = { selectedPeriod = PerformancePeriod.MONTHLY; monthOffset = 0 },
                    text = { Text("Monthly", fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("perf_tab_monthly")
                )
                Tab(
                    selected = selectedPeriod == PerformancePeriod.YEARLY,
                    onClick = { selectedPeriod = PerformancePeriod.YEARLY; yearOffset = 0 },
                    text = { Text("Yearly", fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("perf_tab_yearly")
                )
            }

            // Period Navigation Bar with Previous/Next Arrows (PRD: "User can move back to previous periods using arrows")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        when (selectedPeriod) {
                            PerformancePeriod.WEEKLY -> weekOffset--
                            PerformancePeriod.MONTHLY -> monthOffset--
                            PerformancePeriod.YEARLY -> yearOffset--
                        }
                    },
                    modifier = Modifier.testTag("perf_nav_prev_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Previous Period",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }

                Text(
                    text = metrics.range.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                val canGoForward = when (selectedPeriod) {
                    PerformancePeriod.WEEKLY -> weekOffset < 0
                    PerformancePeriod.MONTHLY -> monthOffset < 0
                    PerformancePeriod.YEARLY -> yearOffset < 0
                }

                IconButton(
                    onClick = {
                        when (selectedPeriod) {
                            PerformancePeriod.WEEKLY -> if (weekOffset < 0) weekOffset++
                            PerformancePeriod.MONTHLY -> if (monthOffset < 0) monthOffset++
                            PerformancePeriod.YEARLY -> if (yearOffset < 0) yearOffset++
                        }
                    },
                    enabled = canGoForward,
                    modifier = Modifier.testTag("perf_nav_next_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Next Period",
                        tint = if (canGoForward) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f)
                    )
                }
            }

            // 1. Chart Component (Compose Canvas-backed Bar Chart with per-subject color segments)
            StudyBarChart(
                bars = metrics.chartBars,
                subjectColors = subjectColors,
                subjectNames = subjectNames
            )

            // Short Text Summary under each chart (PRD section 5.4 requirement)
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = metrics.textSummary,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            // 2. Metrics Summary Grid (total hours, avg per day, best day, subjects most/least, sessions, % change)
            Text(
                text = "Performance Metrics",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Total Hours & Change
                MetricCard(
                    title = "Total Time",
                    value = "${String.format(Locale.US, "%.1f", metrics.totalHours)}h",
                    subtitle = metrics.percentageChange?.let {
                        val sign = if (it > 0) "+" else ""
                        "$sign${String.format(Locale.US, "%.0f", it)}% vs previous"
                    } ?: "vs ${metrics.range.prevTitle}",
                    icon = Icons.Default.QueryBuilder,
                    isPositive = metrics.percentageChange?.let { it >= 0 },
                    modifier = Modifier.weight(1f)
                )

                // Average per day
                MetricCard(
                    title = "Avg / Day",
                    value = "${String.format(Locale.US, "%.1f", metrics.averageHoursPerDay)}h",
                    subtitle = "${metrics.sessionCount} sessions total",
                    icon = Icons.Default.CalendarMonth,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Best Day
                val bestDayLabel = metrics.bestDayDate?.let {
                    "${it.dayOfWeek.name.take(3)} (${String.format(Locale.US, "%.1f", metrics.bestDayMinutes / 60.0)}h)"
                } ?: "None yet"

                MetricCard(
                    title = "Best Day",
                    value = bestDayLabel,
                    subtitle = "Highest duration",
                    icon = Icons.Default.Star,
                    modifier = Modifier.weight(1f)
                )

                // Top Subject Focus
                val topSubject = metrics.mostStudiedSubjectId?.let { subjectsMap[it]?.name } ?: "None"
                val topHrs = String.format(Locale.US, "%.1f", metrics.mostStudiedMinutes / 60.0)

                MetricCard(
                    title = "Top Subject",
                    value = topSubject,
                    subtitle = if (metrics.mostStudiedMinutes > 0) "$topHrs hrs studied" else "No sessions",
                    icon = Icons.Default.Bookmark,
                    modifier = Modifier.weight(1f)
                )
            }

            // 3. Subject-wise Split Breakdown
            if (metrics.subjectMinutes.isNotEmpty()) {
                Text(
                    text = "Subject Breakdown",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                ElevatedCard(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.elevatedCardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        metrics.subjectMinutes.entries.sortedByDescending { it.value }.forEach { (subId, mins) ->
                            val subName = subjectsMap[subId]?.name ?: "Subject #$subId"
                            val color = subjectColors[subId] ?: MaterialTheme.colorScheme.primary
                            val ratio = (mins.toFloat() / metrics.totalMinutes.coerceAtLeast(1)).coerceIn(0f, 1f)
                            val hrs = mins / 60
                            val m = mins % 60
                            val timeStr = if (hrs > 0) "${hrs}h ${m}m" else "${m}m"

                            Column(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(10.dp)
                                                .clip(CircleShape)
                                                .background(color)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = subName,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                    Text(
                                        text = "$timeStr (${(ratio * 100).toInt()}%)",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                LinearProgressIndicator(
                                    progress = { ratio },
                                    color = color,
                                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(6.dp)
                                        .clip(RoundedCornerShape(3.dp))
                                )
                            }
                        }
                    }
                }
            }

            // 4. Weekly Targets Progress (PRD: "If a weekly target is set, show progress toward it")
            val targetSubjects = activeSubjects.filter { it.subject.weeklyTargetHours != null && it.subject.weeklyTargetHours > 0 }
            if (targetSubjects.isNotEmpty() && selectedPeriod == PerformancePeriod.WEEKLY) {
                Text(
                    text = "Weekly Targets Progress",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                ElevatedCard(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.elevatedCardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        targetSubjects.forEach { item ->
                            val sub = item.subject
                            val target = sub.weeklyTargetHours ?: 0f
                            val actual = item.thisWeekMinutesStudied / 60f
                            val progress = (actual / target).coerceIn(0f, 1f)
                            val percent = (progress * 100).toInt()
                            val color = SubjectStylePresets.getColor(sub.colorHex)

                            Column(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = sub.name,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "${String.format(Locale.US, "%.1f", actual)} / ${String.format(Locale.US, "%.1f", target)} hrs ($percent%)",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (progress >= 1f) Color(0xFF16A34A) else MaterialTheme.colorScheme.primary
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                LinearProgressIndicator(
                                    progress = { progress },
                                    color = if (progress >= 1f) Color(0xFF16A34A) else color,
                                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(8.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isPositive: Boolean? = null,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(2.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                if (isPositive != null) {
                    val trendIcon = if (isPositive) Icons.AutoMirrored.Filled.TrendingUp else Icons.AutoMirrored.Filled.TrendingDown
                    val trendColor = if (isPositive) Color(0xFF16A34A) else Color(0xFFDC2626)
                    Icon(
                        imageVector = trendIcon,
                        contentDescription = null,
                        tint = trendColor,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                }
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
