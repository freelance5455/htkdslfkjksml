package com.example.ui.screens

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddComment
import androidx.compose.material.icons.rounded.ArrowDropDown
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CloudDone
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.FolderZip
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Wallpaper
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.VerticalDivider
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import coil.compose.rememberAsyncImagePainter
import com.example.R
import com.example.core.AppearanceSettings
import com.example.core.DesignSystem
import com.example.core.ExportFormat
import com.example.core.FlamiL10n
import com.example.core.FlamiStrings
import com.example.core.ThemePreferencesStore
import com.example.core.TtsManager
import com.example.core.VoiceAssistantManager
import com.example.core.signOutFromFlami
import com.example.data.ai.FlamiAiService
import com.example.data.model.ChatMessage
import com.example.data.repository.FlamiRepository
import com.example.data.repository.LocalGuestStore
import com.example.ui.components.ChatHistoryPanel
import com.example.ui.components.MarkdownMessageContent
import com.example.ui.components.MediaAttachmentSheet
import com.example.ui.components.MemoryManagerSheet
import com.example.ui.components.MessageComposer
import com.example.ui.components.SettingsSheet
import com.example.ui.components.VoiceAssistantSheet
import com.example.ui.components.createCameraTempUri
import com.example.ui.components.decodeUriToBitmap
import com.example.ui.components.readVideoUnderLimit
import com.example.ui.theme.ChatGptAccentGreen
import com.example.ui.viewmodel.AttachedVideo
import com.example.ui.viewmodel.FlamiViewModel
import com.example.ui.viewmodel.GenerationState
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import java.io.File

private enum class PendingCameraMode { PHOTO, VIDEO }
private enum class WorkspaceSubScreen { CHAT, APPEARANCE, AUTH }

@Composable
fun FlamiWorkspaceScreen(
    isSignedIn: Boolean,
    currentUserId: String,
    initialDisplayName: String
) {
    val context = LocalContext.current
    val viewModel: FlamiViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) as Application
                val repository = if (isSignedIn) {
                    val databaseId = app.getString(R.string.firestore_database_id)
                    val db = FirebaseFirestore.getInstance(databaseId)
                    FlamiRepository(db)
                } else {
                    LocalGuestStore(app)
                }
                FlamiViewModel(
                    repository = repository,
                    aiService = FlamiAiService(),
                    themeStore = ThemePreferencesStore(app),
                    ttsManager = TtsManager(app),
                    voiceAssistantManager = VoiceAssistantManager(app),
                    currentUserId = currentUserId,
                    initialDisplayName = initialDisplayName
                )
            }
        }
    )

    LaunchedEffect(isSignedIn, currentUserId) {
        if (isSignedIn) {
            val databaseId = context.getString(R.string.firestore_database_id)
            val cloudRepo = FlamiRepository(FirebaseFirestore.getInstance(databaseId))
            LocalGuestStore(context).migrateToCloudIfAny(cloudRepo)
        }
    }

    val profile by viewModel.userProfile.collectAsStateWithLifecycle()
    val effectiveLang by viewModel.effectiveLanguageCode.collectAsStateWithLifecycle()
    val strings = remember(effectiveLang) { FlamiL10n.strings(effectiveLang) }

    val appearance by viewModel.appearanceSettings.collectAsStateWithLifecycle()
    val chats by viewModel.chats.collectAsStateWithLifecycle()
    val activeChatId by viewModel.activeChatId.collectAsStateWithLifecycle()
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val memories by viewModel.memories.collectAsStateWithLifecycle()
    val inputText by viewModel.inputText.collectAsStateWithLifecycle()
    val attachedBitmap by viewModel.attachedBitmap.collectAsStateWithLifecycle()
    val attachedVideo by viewModel.attachedVideo.collectAsStateWithLifecycle()
    val generationState by viewModel.generationState.collectAsStateWithLifecycle()
    val searchState by viewModel.searchState.collectAsStateWithLifecycle()
    val speakingMessageId by viewModel.ttsManager.speakingMessageId.collectAsStateWithLifecycle()
    val voiceListeningState by viewModel.voiceAssistantManager.listeningState.collectAsStateWithLifecycle()
    val voiceAutoSpeak by viewModel.voiceAutoSpeak.collectAsStateWithLifecycle()
    val toastEvent by viewModel.toastEvent.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }

    var activeSubScreen by remember { mutableStateOf(WorkspaceSubScreen.CHAT) }
    var showMemorySheet by remember { mutableStateOf(false) }
    var showSettingsSheet by remember { mutableStateOf(false) }
    var showMediaSheet by remember { mutableStateOf(false) }
    var showVoiceSheet by remember { mutableStateOf(false) }

    LaunchedEffect(isSignedIn) {
        if (isSignedIn && activeSubScreen == WorkspaceSubScreen.AUTH) {
            activeSubScreen = WorkspaceSubScreen.CHAT
        }
    }

    // Pending export target (whole chat or specific message)
    var pendingExportFormat by remember { mutableStateOf(ExportFormat.ZIP) }
    var pendingExportMessage by remember { mutableStateOf<ChatMessage?>(null) }

    // Camera capture temp URIs & pending permission action
    var pendingCameraPhotoUri by remember { mutableStateOf<Uri?>(null) }
    var pendingCameraVideoUri by remember { mutableStateOf<Uri?>(null) }
    var pendingCameraMode by remember { mutableStateOf<PendingCameraMode?>(null) }

    val exportDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.exportCurrentChat(
                context = context,
                uri = uri,
                format = pendingExportFormat,
                singleMessage = pendingExportMessage,
                successMessage = strings.exportSuccess
            )
        }
        pendingExportMessage = null
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val bitmap = decodeUriToBitmap(context, uri)
            if (bitmap != null) {
                viewModel.attachBitmap(bitmap)
            } else {
                viewModel.showToast("Failed to load image")
            }
        }
    }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val res = readVideoUnderLimit(context, uri, strings.videoAttachedLabel)
                res.onSuccess { viewModel.attachVideo(it) }
                    .onFailure { err ->
                        val msg = if (err.message == "TOO_LARGE") {
                            strings.videoTooLargeError
                        } else {
                            err.localizedMessage ?: "Failed to load video"
                        }
                        viewModel.showToast(msg)
                    }
            }
        }
    }

    val takePictureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        val uri = pendingCameraPhotoUri
        if (success && uri != null) {
            val bitmap = decodeUriToBitmap(context, uri)
            if (bitmap != null) {
                viewModel.attachBitmap(bitmap)
            } else {
                viewModel.showToast("Failed to capture photo")
            }
        }
    }

    val captureVideoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CaptureVideo()
    ) { success ->
        val uri = pendingCameraVideoUri
        if (success && uri != null) {
            scope.launch {
                val res = readVideoUnderLimit(context, uri, strings.videoAttachedLabel)
                res.onSuccess { viewModel.attachVideo(it) }
                    .onFailure { err ->
                        val msg = if (err.message == "TOO_LARGE") {
                            strings.videoTooLargeError
                        } else {
                            err.localizedMessage ?: "Failed to capture video"
                        }
                        viewModel.showToast(msg)
                    }
            }
        }
    }

    val launchCameraCapture: (PendingCameraMode) -> Unit = { mode ->
        when (mode) {
            PendingCameraMode.PHOTO -> {
                val uri = createCameraTempUri(context, isVideo = false)
                pendingCameraPhotoUri = uri
                takePictureLauncher.launch(uri)
            }
            PendingCameraMode.VIDEO -> {
                val uri = createCameraTempUri(context, isVideo = true)
                pendingCameraVideoUri = uri
                captureVideoLauncher.launch(uri)
            }
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        val mode = pendingCameraMode
        pendingCameraMode = null
        if (granted && mode != null) {
            launchCameraCapture(mode)
        } else if (!granted) {
            viewModel.showToast(strings.cameraPermissionNeeded)
        }
    }

    val requestCameraWithPermission: (PendingCameraMode) -> Unit = { mode ->
        val hasCamera = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED
        if (hasCamera) {
            launchCameraCapture(mode)
        } else {
            pendingCameraMode = mode
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    LaunchedEffect(toastEvent) {
        val msg = toastEvent
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearToast()
        }
    }

    val launchExport: (ExportFormat, ChatMessage?) -> Unit = { format, singleMsg ->
        pendingExportFormat = format
        pendingExportMessage = singleMsg
        val ext = format.extension
        val fileName = "flami_export_${System.currentTimeMillis()}.$ext"
        exportDocumentLauncher.launch(fileName)
    }

    AnimatedContent(
        targetState = activeSubScreen,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "workspace_subscreen_switch"
    ) { screen ->
        when (screen) {
            WorkspaceSubScreen.APPEARANCE -> {
                AppearanceScreen(
                    strings = strings,
                    appearance = appearance,
                    onSelectDesignSystem = viewModel::setDesignSystem,
                    onSelectAnimeBgIndex = viewModel::setAnimeBackgroundIndex,
                    onPickCustomAnimeBg = viewModel::setCustomAnimeBackground,
                    onSelectClassicMode = viewModel::setClassicThemeMode,
                    onBack = { activeSubScreen = WorkspaceSubScreen.CHAT }
                )
            }
            WorkspaceSubScreen.AUTH -> {
                AuthScreen(
                    initialLanguageCode = effectiveLang,
                    onAuthSuccess = { activeSubScreen = WorkspaceSubScreen.CHAT },
                    onCloseToChat = { activeSubScreen = WorkspaceSubScreen.CHAT }
                )
            }
            WorkspaceSubScreen.CHAT -> {
            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                val isWideScreen = maxWidth >= 840.dp
                val drawerState = rememberDrawerState(DrawerValue.Closed)

                BackHandler(enabled = !isWideScreen && drawerState.isOpen) {
                    scope.launch { drawerState.close() }
                }

                val activeMemoryCount = remember(memories) { memories.count { it.isActive } }

                val historyPanel: @Composable (Modifier) -> Unit = { panelModifier ->
                    ChatHistoryPanel(
                        strings = strings,
                        chats = chats,
                        activeChatId = activeChatId,
                        hasExportableMessages = messages.isNotEmpty(),
                        searchState = searchState,
                        activeMemoryCount = activeMemoryCount,
                        isSignedIn = isSignedIn,
                        userDisplayName = profile.displayName.ifBlank { initialDisplayName },
                        onSearchQueryChange = viewModel::searchHistory,
                        onSelectChat = { id ->
                            viewModel.selectChat(id)
                            if (!isWideScreen) {
                                scope.launch { drawerState.close() }
                            }
                        },
                        onNewChat = {
                            viewModel.startNewChat()
                            if (!isWideScreen) {
                                scope.launch { drawerState.close() }
                            }
                        },
                        onRenameChat = viewModel::renameChat,
                        onTogglePin = viewModel::togglePinChat,
                        onDeleteChat = viewModel::deleteChat,
                        onOpenMemory = {
                            if (!isWideScreen) scope.launch { drawerState.close() }
                            showMemorySheet = true
                        },
                        onOpenAppearance = {
                            if (!isWideScreen) scope.launch { drawerState.close() }
                            activeSubScreen = WorkspaceSubScreen.APPEARANCE
                        },
                        onOpenVoiceAssistant = {
                            if (!isWideScreen) scope.launch { drawerState.close() }
                            showVoiceSheet = true
                        },
                        onExportChat = { format ->
                            if (!isWideScreen) scope.launch { drawerState.close() }
                            launchExport(format, null)
                        },
                        onOpenAuth = {
                            if (!isWideScreen) scope.launch { drawerState.close() }
                            activeSubScreen = WorkspaceSubScreen.AUTH
                        },
                        onOpenSettings = {
                            if (!isWideScreen) scope.launch { drawerState.close() }
                            showSettingsSheet = true
                        },
                        modifier = panelModifier
                    )
                }

                val mainChatScaffold: @Composable () -> Unit = {
                    MainChatArea(
                        strings = strings,
                        appearance = appearance,
                        activeChatTitle = chats.firstOrNull { it.id == activeChatId }?.title ?: strings.newChat,
                        modelMode = profile.modelMode,
                        messages = messages,
                        generationState = generationState,
                        inputText = inputText,
                        attachedBitmap = attachedBitmap,
                        attachedVideo = attachedVideo,
                        ttsEnabled = profile.ttsEnabled,
                        speakingMessageId = speakingMessageId,
                        activeMemoryCount = activeMemoryCount,
                        showMenuButton = !isWideScreen,
                        snackbarHostState = snackbarHostState,
                        onOpenDrawer = { scope.launch { drawerState.open() } },
                        onNewChat = viewModel::startNewChat,
                        onSelectModelMode = viewModel::updateModelMode,
                        onOpenMemory = { showMemorySheet = true },
                        onOpenAppearance = { activeSubScreen = WorkspaceSubScreen.APPEARANCE },
                        onCycleAnimeWallpaper = {
                            val nextIdx = if (appearance.animeBgIndex < 0) 0 else (appearance.animeBgIndex + 1) % 3
                            viewModel.setAnimeBackgroundIndex(nextIdx)
                        },
                        onOpenSettings = { showSettingsSheet = true },
                        onInputChange = viewModel::updateInputText,
                        onOpenMediaPicker = { showMediaSheet = true },
                        onOpenVoiceAssistant = { showVoiceSheet = true },
                        onRemoveImage = { viewModel.attachBitmap(null) },
                        onRemoveVideo = { viewModel.attachVideo(null) },
                        onSend = { viewModel.sendMessage() },
                        onQuickPrompt = { prompt -> viewModel.sendMessage(overridePrompt = prompt) },
                        onCancelGeneration = viewModel::cancelGeneration,
                        onRetry = viewModel::retryLastUserMessage,
                        onToggleSpeak = { msg ->
                            viewModel.ttsManager.toggleSpeak(
                                messageId = msg.id,
                                rawText = msg.text,
                                languageCode = effectiveLang,
                                speechRate = profile.ttsRate.toFloat()
                            )
                        },
                        onCopyText = { text, clipboard ->
                            clipboard.setText(AnnotatedString(text))
                            viewModel.showToast(strings.copiedToast)
                        },
                        onExport = launchExport
                    )
                }

                if (isWideScreen) {
                    Row(modifier = Modifier.fillMaxSize()) {
                        historyPanel(Modifier.width(310.dp))
                        VerticalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
                        Box(modifier = Modifier.weight(1f)) {
                            mainChatScaffold()
                        }
                    }
                } else {
                    ModalNavigationDrawer(
                        drawerState = drawerState,
                        drawerContent = {
                            ModalDrawerSheet(
                                drawerContainerColor = if (appearance.designSystem == DesignSystem.ANIME_WORLD) {
                                    MaterialTheme.colorScheme.surface.copy(alpha = 0.90f)
                                } else {
                                    MaterialTheme.colorScheme.surface
                                },
                                modifier = Modifier.widthIn(max = 330.dp)
                            ) {
                                historyPanel(Modifier.fillMaxWidth())
                            }
                        }
                    ) {
                        mainChatScaffold()
                    }
                }
            }
            }
        }
    }

    if (showMediaSheet) {
        MediaAttachmentSheet(
            strings = strings,
            onTakeCameraPhoto = { requestCameraWithPermission(PendingCameraMode.PHOTO) },
            onRecordCameraVideo = { requestCameraWithPermission(PendingCameraMode.VIDEO) },
            onPickGalleryPhoto = {
                photoPickerLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                )
            },
            onPickGalleryVideo = {
                videoPickerLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                )
            },
            onDismiss = { showMediaSheet = false }
        )
    }

    if (showVoiceSheet) {
        VoiceAssistantSheet(
            strings = strings,
            listeningState = voiceListeningState,
            isGenerating = generationState.isGenerating,
            isSpeaking = speakingMessageId != null,
            voiceAutoSpeak = voiceAutoSpeak,
            effectiveLanguage = effectiveLang,
            onToggleAutoSpeak = viewModel::setVoiceAutoSpeak,
            onStartListening = {
                viewModel.voiceAssistantManager.startListening(effectiveLang) { spokenText ->
                    viewModel.sendMessage(
                        overridePrompt = spokenText,
                        speakResponseAloud = voiceAutoSpeak
                    )
                }
            },
            onStopListening = viewModel.voiceAssistantManager::stopListening,
            onStopSpeaking = viewModel.ttsManager::stop,
            onPermissionDenied = { viewModel.showToast(strings.micPermissionNeeded) },
            onDismiss = { showVoiceSheet = false }
        )
    }

    if (showMemorySheet) {
        MemoryManagerSheet(
            strings = strings,
            memories = memories,
            memoryEnabled = profile.memoryEnabled,
            onToggleMemoryEnabled = viewModel::updateMemoryEnabled,
            onAddMemory = viewModel::addMemory,
            onToggleMemoryItem = viewModel::toggleMemoryActive,
            onDeleteMemory = viewModel::deleteMemory,
            onDismiss = { showMemorySheet = false }
        )
    }

    if (showSettingsSheet) {
        SettingsSheet(
            strings = strings,
            profile = profile,
            isSignedIn = isSignedIn,
            onSelectLanguage = viewModel::updateLanguage,
            onSelectModelMode = viewModel::updateModelMode,
            onToggleTts = viewModel::updateTtsEnabled,
            onChangeTtsRate = viewModel::updateTtsRate,
            onOpenAuth = { activeSubScreen = WorkspaceSubScreen.AUTH },
            onSignOut = {
                signOutFromFlami(
                    credentialManager = credentialManager,
                    scope = scope
                )
            },
            onDismiss = { showSettingsSheet = false }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainChatArea(
    strings: FlamiStrings,
    appearance: AppearanceSettings,
    activeChatTitle: String,
    modelMode: String,
    messages: List<ChatMessage>,
    generationState: GenerationState,
    inputText: String,
    attachedBitmap: Bitmap?,
    attachedVideo: AttachedVideo?,
    ttsEnabled: Boolean,
    speakingMessageId: String?,
    activeMemoryCount: Int,
    showMenuButton: Boolean,
    snackbarHostState: SnackbarHostState,
    onOpenDrawer: () -> Unit,
    onNewChat: () -> Unit,
    onSelectModelMode: (String) -> Unit,
    onOpenMemory: () -> Unit,
    onOpenAppearance: () -> Unit,
    onCycleAnimeWallpaper: () -> Unit,
    onOpenSettings: () -> Unit,
    onInputChange: (String) -> Unit,
    onOpenMediaPicker: () -> Unit,
    onOpenVoiceAssistant: () -> Unit,
    onRemoveImage: () -> Unit,
    onRemoveVideo: () -> Unit,
    onSend: () -> Unit,
    onQuickPrompt: (String) -> Unit,
    onCancelGeneration: () -> Unit,
    onRetry: () -> Unit,
    onToggleSpeak: (ChatMessage) -> Unit,
    onCopyText: (String, androidx.compose.ui.platform.ClipboardManager) -> Unit,
    onExport: (ExportFormat, ChatMessage?) -> Unit
) {
    val designSystem = appearance.designSystem
    val listState = rememberLazyListState()
    val clipboard = LocalClipboardManager.current
    var exportMenuExpanded by remember { mutableStateOf(false) }
    var modelMenuExpanded by remember { mutableStateOf(false) }

    LaunchedEffect(messages.size, generationState.streamingText.length) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    val backdropModifier: Modifier = when (designSystem) {
        DesignSystem.FLAMI_ORIGINAL -> Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0A0614),
                        Color(0xFF1F0C3E),
                        Color(0xFF0C0719)
                    )
                )
            )
            .drawBehind {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0x557C3AED), Color.Transparent),
                        center = Offset(size.width * 0.88f, size.height * 0.14f),
                        radius = size.maxDimension * 0.58f
                    )
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0x40581C87), Color.Transparent),
                        center = Offset(size.width * 0.12f, size.height * 0.86f),
                        radius = size.maxDimension * 0.54f
                    )
                )
            }
        DesignSystem.ANIME_WORLD -> Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
        DesignSystem.CLASSIC_AI -> Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    }

    Box(modifier = backdropModifier) {
        if (designSystem == DesignSystem.ANIME_WORLD) {
            AnimeWorldWallpaperLayer(appearance = appearance)
        }

        Scaffold(
            containerColor = Color.Transparent,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            topBar = {
                Column {
                    val topBarBg = when (designSystem) {
                        DesignSystem.ANIME_WORLD -> MaterialTheme.colorScheme.surface.copy(alpha = 0.52f)
                        DesignSystem.FLAMI_ORIGINAL -> Color(0xFF0A0614).copy(alpha = 0.78f)
                        DesignSystem.CLASSIC_AI -> MaterialTheme.colorScheme.background
                    }

                    CenterAlignedTopAppBar(
                        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                            containerColor = topBarBg
                        ),
                        navigationIcon = {
                            if (showMenuButton) {
                                IconButton(
                                    onClick = onOpenDrawer,
                                    modifier = Modifier.testTag("open_drawer_button")
                                ) {
                                    Icon(Icons.Rounded.Menu, contentDescription = strings.chatsTitle)
                                }
                            }
                        },
                        title = {
                            Box {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .clickable { modelMenuExpanded = true }
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                        .testTag("topbar_model_selector")
                                ) {
                                    Text(
                                        text = activeChatTitle,
                                        style = MaterialTheme.typography.titleMedium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        if (designSystem != DesignSystem.CLASSIC_AI) {
                                            Icon(
                                                imageVector = Icons.Rounded.CloudDone,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.secondary,
                                                modifier = Modifier.size(12.dp)
                                            )
                                        }
                                        Text(
                                            text = when (modelMode) {
                                                "reasoning" -> strings.modeReasoning
                                                "fast" -> strings.modeFast
                                                else -> strings.modeBalanced
                                            },
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Icon(
                                            imageVector = Icons.Rounded.ArrowDropDown,
                                            contentDescription = strings.modelModeLabel,
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }

                                DropdownMenu(
                                    expanded = modelMenuExpanded,
                                    onDismissRequest = { modelMenuExpanded = false }
                                ) {
                                    listOf(
                                        "balanced" to strings.modeBalanced,
                                        "reasoning" to strings.modeReasoning,
                                        "fast" to strings.modeFast
                                    ).forEach { (modeKey, modeLabel) ->
                                        DropdownMenuItem(
                                            text = { Text(modeLabel) },
                                            trailingIcon = if (modelMode == modeKey) {
                                                {
                                                    Icon(
                                                        imageVector = Icons.Rounded.Check,
                                                        contentDescription = null,
                                                        tint = MaterialTheme.colorScheme.primary
                                                    )
                                                }
                                            } else null,
                                            onClick = {
                                                modelMenuExpanded = false
                                                onSelectModelMode(modeKey)
                                            }
                                        )
                                    }
                                }
                            }
                        },
                        actions = {
                            if (designSystem == DesignSystem.ANIME_WORLD) {
                                IconButton(
                                    onClick = onCycleAnimeWallpaper,
                                    modifier = Modifier.testTag("cycle_anime_wallpaper_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Wallpaper,
                                        contentDescription = strings.animeChangeBg,
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }

                            // FLAMI Original keeps the TopAppBar minimal; extra tools live in sidebar
                            if (designSystem != DesignSystem.FLAMI_ORIGINAL) {
                                IconButton(onClick = onOpenMemory) {
                                    Icon(
                                        imageVector = Icons.Rounded.Memory,
                                        contentDescription = strings.memoryTitle,
                                        tint = if (activeMemoryCount > 0) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Box {
                                    IconButton(
                                        onClick = { exportMenuExpanded = true },
                                        enabled = messages.isNotEmpty(),
                                        modifier = Modifier.testTag("export_menu_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Download,
                                            contentDescription = strings.exportZipAction
                                        )
                                    }
                                    DropdownMenu(
                                        expanded = exportMenuExpanded,
                                        onDismissRequest = { exportMenuExpanded = false }
                                    ) {
                                        DropdownMenuItem(
                                            text = { Text(strings.exportZipAction) },
                                            leadingIcon = { Icon(Icons.Rounded.FolderZip, contentDescription = null) },
                                            onClick = {
                                                exportMenuExpanded = false
                                                onExport(ExportFormat.ZIP, null)
                                            }
                                        )
                                        DropdownMenuItem(
                                            text = { Text(strings.exportHtmlAction) },
                                            onClick = {
                                                exportMenuExpanded = false
                                                onExport(ExportFormat.HTML, null)
                                            }
                                        )
                                        DropdownMenuItem(
                                            text = { Text(strings.exportMdAction) },
                                            onClick = {
                                                exportMenuExpanded = false
                                                onExport(ExportFormat.MARKDOWN, null)
                                            }
                                        )
                                    }
                                }
                            }

                            IconButton(
                                onClick = onOpenAppearance,
                                modifier = Modifier.testTag("topbar_appearance_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Palette,
                                    contentDescription = strings.appearanceTitle,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            IconButton(onClick = onNewChat) {
                                Icon(Icons.Rounded.AddComment, contentDescription = strings.newChat)
                            }
                            if (!showMenuButton) {
                                IconButton(onClick = onOpenSettings) {
                                    Icon(Icons.Rounded.Settings, contentDescription = strings.settingsTitle)
                                }
                            }
                        }
                    )

                    if (designSystem == DesignSystem.CLASSIC_AI) {
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.45f))
                    } else if (designSystem == DesignSystem.FLAMI_ORIGINAL) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(1.dp)
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(
                                            Color.Transparent,
                                            MaterialTheme.colorScheme.primary.copy(alpha = 0.4f),
                                            MaterialTheme.colorScheme.secondary.copy(alpha = 0.4f),
                                            Color.Transparent
                                        )
                                    )
                                )
                        )
                    }
                }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .navigationBarsPadding()
                    .imePadding(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .widthIn(max = 860.dp)
                        .fillMaxWidth()
                ) {
                    if (messages.isEmpty()) {
                        EmptyWelcomeState(
                            strings = strings,
                            designSystem = designSystem,
                            onQuickPrompt = onQuickPrompt
                        )
                    } else {
                        LazyColumn(
                            state = listState,
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(
                                if (designSystem == DesignSystem.FLAMI_ORIGINAL) 18.dp else 14.dp
                            ),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(messages, key = { it.id }) { msg ->
                                val isStreamingThis =
                                    generationState.isGenerating && generationState.streamingMessageId == msg.id
                                val displayText = if (isStreamingThis && generationState.streamingText.isNotBlank()) {
                                    generationState.streamingText
                                } else {
                                    msg.text
                                }

                                ChatMessageBubble(
                                    designSystem = designSystem,
                                    message = msg,
                                    displayText = displayText,
                                    isStreaming = isStreamingThis,
                                    isSpeaking = speakingMessageId == msg.id,
                                    ttsEnabled = ttsEnabled,
                                    strings = strings,
                                    onCopy = { onCopyText(it, clipboard) },
                                    onToggleSpeak = { onToggleSpeak(msg.copy(text = displayText)) },
                                    onExportZip = { onExport(ExportFormat.ZIP, msg.copy(text = displayText)) },
                                    onRetry = onRetry
                                )
                            }
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .widthIn(max = 860.dp)
                        .fillMaxWidth()
                ) {
                    MessageComposer(
                        strings = strings,
                        text = inputText,
                        attachedBitmap = attachedBitmap,
                        attachedVideo = attachedVideo,
                        isGenerating = generationState.isGenerating,
                        designSystem = designSystem,
                        onTextChange = onInputChange,
                        onOpenMediaPicker = onOpenMediaPicker,
                        onOpenVoiceAssistant = onOpenVoiceAssistant,
                        onRemoveImage = onRemoveImage,
                        onRemoveVideo = onRemoveVideo,
                        onSend = onSend,
                        onCancelGeneration = onCancelGeneration
                    )
                }
            }
        }
    }
}

@Composable
private fun AnimeWorldWallpaperLayer(appearance: AppearanceSettings) {
    val bgKey = "${appearance.animeBgIndex}_${appearance.customAnimeBgPath.orEmpty()}"
    Crossfade(targetState = bgKey, label = "animeWallpaperCrossfade") {
        val customFile = appearance.customAnimeBgPath?.let(::File)?.takeIf { it.exists() }
        val painter = if (appearance.animeBgIndex == -1 && customFile != null) {
            rememberAsyncImagePainter(model = customFile)
        } else {
            val resId = when (appearance.animeBgIndex) {
                1 -> R.drawable.img_anime_bg_2
                2 -> R.drawable.img_anime_bg_3
                else -> R.drawable.img_anime_bg_1
            }
            painterResource(id = resId)
        }

        Box(modifier = Modifier.fillMaxSize()) {
            Image(
                painter = painter,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            // Light balanced gradient scrim keeps anime girl artwork bright and unmistakable while keeping UI crisp
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0x14080414),
                                Color(0x28080414),
                                Color(0x70080414)
                            )
                        )
                    )
            )
        }
    }
}

@Composable
private fun EmptyWelcomeState(
    strings: FlamiStrings,
    designSystem: DesignSystem,
    onQuickPrompt: (String) -> Unit
) {
    val prompts = listOf(
        strings.quickPromptCode,
        strings.quickPromptMath,
        strings.quickPromptWebZip,
        strings.quickPromptLearn
    )

    if (designSystem == DesignSystem.ANIME_WORLD) {
        // Leave the upper and center viewport open so the anime girl wallpaper shines clearly
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.Bottom
        ) {
            Surface(
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.62f),
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        Brush.horizontalGradient(
                            listOf(
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
                                MaterialTheme.colorScheme.secondary.copy(alpha = 0.7f)
                            )
                        ),
                        RoundedCornerShape(22.dp)
                    )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = strings.welcomeTitle,
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = strings.welcomeSubtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            prompts.chunked(2).forEach { pair ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    pair.forEach { prompt ->
                        Surface(
                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.64f),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .weight(1f)
                                .border(
                                    1.dp,
                                    MaterialTheme.colorScheme.outline.copy(alpha = 0.55f),
                                    RoundedCornerShape(14.dp)
                                )
                                .clickable { onQuickPrompt(prompt) }
                        ) {
                            Text(
                                text = prompt,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }
        }
        return
    }

    LazyColumn(
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = if (designSystem == DesignSystem.CLASSIC_AI) {
            Arrangement.spacedBy(10.dp, Alignment.CenterVertically)
        } else {
            Arrangement.spacedBy(12.dp)
        },
        modifier = Modifier.fillMaxSize()
    ) {
        when (designSystem) {
            DesignSystem.ANIME_WORLD -> Unit
            DesignSystem.FLAMI_ORIGINAL -> {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(144.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .border(
                                1.dp,
                                Brush.horizontalGradient(
                                    listOf(
                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.45f),
                                        MaterialTheme.colorScheme.secondary.copy(alpha = 0.45f)
                                    )
                                ),
                                RoundedCornerShape(20.dp)
                            )
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_flami_hero),
                            contentDescription = strings.appTitle,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(Color(0x330A0614), Color(0xE00A0614))
                                    )
                                )
                        )
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(16.dp)
                        ) {
                            Text(
                                text = strings.welcomeTitle,
                                style = MaterialTheme.typography.headlineSmall,
                                color = Color.White
                            )
                            Text(
                                text = strings.welcomeSubtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.82f),
                                maxLines = 2
                            )
                        }
                    }
                }
            }
            DesignSystem.CLASSIC_AI -> {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 24.dp, bottom = 14.dp, start = 8.dp, end = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.AutoAwesome,
                                contentDescription = strings.appTitle,
                                tint = ChatGptAccentGreen,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = strings.welcomeTitle,
                            style = MaterialTheme.typography.headlineSmall,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = strings.welcomeSubtitle,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        items(prompts) { prompt ->
            val cardBg = when (designSystem) {
                DesignSystem.ANIME_WORLD -> MaterialTheme.colorScheme.surface.copy(alpha = 0.65f)
                DesignSystem.FLAMI_ORIGINAL -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.58f)
                DesignSystem.CLASSIC_AI -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.72f)
            }
            Surface(
                color = cardBg,
                shape = RoundedCornerShape(if (designSystem == DesignSystem.CLASSIC_AI) 14.dp else 16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.outline.copy(
                            alpha = if (designSystem == DesignSystem.ANIME_WORLD) 0.55f else 0.42f
                        ),
                        RoundedCornerShape(if (designSystem == DesignSystem.CLASSIC_AI) 14.dp else 16.dp)
                    )
                    .clickable { onQuickPrompt(prompt) }
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.AutoAwesome,
                        contentDescription = null,
                        tint = if (designSystem == DesignSystem.CLASSIC_AI) ChatGptAccentGreen else MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = prompt,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
private fun ChatMessageBubble(
    designSystem: DesignSystem,
    message: ChatMessage,
    displayText: String,
    isStreaming: Boolean,
    isSpeaking: Boolean,
    ttsEnabled: Boolean,
    strings: FlamiStrings,
    onCopy: (String) -> Unit,
    onToggleSpeak: () -> Unit,
    onExportZip: () -> Unit,
    onRetry: () -> Unit
) {
    val isUser = message.role == "user"

    // 1. FLAMI ORIGINAL uses an ultra-clean editorial layout for AI messages + sleek obsidian-plum pill for user
    if (designSystem == DesignSystem.FLAMI_ORIGINAL && !isUser) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(IntrinsicSize.Min)
                .animateContentSize()
        ) {
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .fillMaxHeight()
                    .padding(vertical = 4.dp)
                    .background(
                        brush = if (message.isError) {
                            Brush.verticalGradient(listOf(MaterialTheme.colorScheme.error, MaterialTheme.colorScheme.error))
                        } else {
                            Brush.verticalGradient(
                                listOf(
                                    MaterialTheme.colorScheme.primary,
                                    MaterialTheme.colorScheme.secondary
                                )
                            )
                        },
                        shape = RoundedCornerShape(2.dp)
                    )
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                MessageBodyAndActions(
                    designSystem = designSystem,
                    message = message,
                    displayText = displayText,
                    isUser = false,
                    isStreaming = isStreaming,
                    isSpeaking = isSpeaking,
                    ttsEnabled = ttsEnabled,
                    strings = strings,
                    onCopy = onCopy,
                    onToggleSpeak = onToggleSpeak,
                    onExportZip = onExportZip,
                    onRetry = onRetry
                )
            }
        }
        return
    }

    // 2. CLASSIC AI uses authentic ChatGPT layout: right-aligned rounded pill for user, clean flat stream for AI
    if (designSystem == DesignSystem.CLASSIC_AI) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
        ) {
            if (isUser) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(22.dp),
                    modifier = Modifier.widthIn(max = 640.dp)
                ) {
                    Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                        MessageBodyAndActions(
                            designSystem = designSystem,
                            message = message,
                            displayText = displayText,
                            isUser = true,
                            isStreaming = isStreaming,
                            isSpeaking = isSpeaking,
                            ttsEnabled = ttsEnabled,
                            strings = strings,
                            onCopy = onCopy,
                            onToggleSpeak = onToggleSpeak,
                            onExportZip = onExportZip,
                            onRetry = onRetry
                        )
                    }
                }
            } else {
                Row(modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .padding(top = 2.dp, end = 10.dp)
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.AutoAwesome,
                            contentDescription = strings.appTitle,
                            tint = ChatGptAccentGreen,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        MessageBodyAndActions(
                            designSystem = designSystem,
                            message = message,
                            displayText = displayText,
                            isUser = false,
                            isStreaming = isStreaming,
                            isSpeaking = isSpeaking,
                            ttsEnabled = ttsEnabled,
                            strings = strings,
                            onCopy = onCopy,
                            onToggleSpeak = onToggleSpeak,
                            onExportZip = onExportZip,
                            onRetry = onRetry
                        )
                    }
                }
            }
        }
        return
    }

    // 3. ANIME WORLD (translucent frosted glass bubbles with smooth animation) & FLAMI Original user bubble
    val bubbleShape = RoundedCornerShape(
        topStart = 20.dp,
        topEnd = 20.dp,
        bottomStart = if (isUser) 20.dp else 6.dp,
        bottomEnd = if (isUser) 6.dp else 20.dp
    )

    val bubbleColor = when {
        message.isError -> MaterialTheme.colorScheme.error.copy(alpha = 0.22f)
        designSystem == DesignSystem.ANIME_WORLD && isUser -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.72f)
        designSystem == DesignSystem.ANIME_WORLD -> MaterialTheme.colorScheme.surface.copy(alpha = 0.68f)
        isUser -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.90f)
        else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.60f)
    }

    val bubbleBorderColor = when {
        message.isError -> MaterialTheme.colorScheme.error.copy(alpha = 0.5f)
        designSystem == DesignSystem.ANIME_WORLD && isUser -> MaterialTheme.colorScheme.primary.copy(alpha = 0.65f)
        designSystem == DesignSystem.ANIME_WORLD -> MaterialTheme.colorScheme.secondary.copy(alpha = 0.50f)
        else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.48f)
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        if (!isUser) {
            Box(
                modifier = Modifier
                    .padding(top = 4.dp, end = 8.dp)
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.AutoAwesome,
                    contentDescription = strings.appTitle,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        Surface(
            color = bubbleColor,
            shape = bubbleShape,
            modifier = Modifier
                .widthIn(max = 680.dp)
                .border(1.dp, bubbleBorderColor, bubbleShape)
        ) {
            Box(modifier = Modifier.padding(14.dp)) {
                MessageBodyAndActions(
                    designSystem = designSystem,
                    message = message,
                    displayText = displayText,
                    isUser = isUser,
                    isStreaming = isStreaming,
                    isSpeaking = isSpeaking,
                    ttsEnabled = ttsEnabled,
                    strings = strings,
                    onCopy = onCopy,
                    onToggleSpeak = onToggleSpeak,
                    onExportZip = onExportZip,
                    onRetry = onRetry
                )
            }
        }
    }
}

@Composable
private fun MessageBodyAndActions(
    designSystem: DesignSystem,
    message: ChatMessage,
    displayText: String,
    isUser: Boolean,
    isStreaming: Boolean,
    isSpeaking: Boolean,
    ttsEnabled: Boolean,
    strings: FlamiStrings,
    onCopy: (String) -> Unit,
    onToggleSpeak: () -> Unit,
    onExportZip: () -> Unit,
    onRetry: () -> Unit
) {

    Column {
        if (message.hasImage) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 6.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Image,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = message.imageNote ?: strings.imageAttachedLabel,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        }

        if (displayText.isBlank() && isStreaming) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(16.dp),
                    strokeWidth = 2.dp
                )
                Text(
                    text = strings.generatingLabel,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else if (isUser) {
            Text(
                text = displayText,
                style = MaterialTheme.typography.bodyLarge,
                color = if (designSystem == DesignSystem.CLASSIC_AI) {
                    MaterialTheme.colorScheme.onSurface
                } else {
                    MaterialTheme.colorScheme.onPrimaryContainer
                }
            )
        } else {
            MarkdownMessageContent(
                markdown = displayText,
                textColor = MaterialTheme.colorScheme.onSurface,
                copyLabel = strings.copyAction,
                exportZipLabel = strings.exportZipAction,
                onCopyCode = onCopy,
                onExportZip = onExportZip
            )
        }

        if (!isUser && !isStreaming && displayText.isNotBlank()) {
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = { onCopy(displayText) },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.ContentCopy,
                        contentDescription = strings.copyAction,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(strings.copyAction, style = MaterialTheme.typography.labelMedium)
                }

                if (ttsEnabled) {
                    TextButton(
                        onClick = onToggleSpeak,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = if (isSpeaking) Icons.Rounded.Stop else Icons.Rounded.VolumeUp,
                            contentDescription = if (isSpeaking) strings.stopSpeakAction else strings.speakAction,
                            modifier = Modifier.size(15.dp),
                            tint = if (isSpeaking) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            if (isSpeaking) strings.stopSpeakAction else strings.speakAction,
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }

                TextButton(
                    onClick = onExportZip,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.FolderZip,
                        contentDescription = strings.exportZipAction,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ZIP", style = MaterialTheme.typography.labelMedium)
                }

                if (message.isError) {
                    TextButton(
                        onClick = onRetry,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("retry_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Refresh,
                            contentDescription = strings.retry,
                            modifier = Modifier.size(15.dp),
                            tint = MaterialTheme.colorScheme.error
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            strings.retry,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        }
    }
}
