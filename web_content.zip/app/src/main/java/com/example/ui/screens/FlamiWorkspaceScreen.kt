package com.example.ui.screens

import android.app.Application
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddComment
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.CloudDone
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.FolderZip
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.VerticalDivider
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.R
import com.example.core.ExportFormat
import com.example.core.FlamiL10n
import com.example.core.FlamiStrings
import com.example.core.TtsManager
import com.example.core.signOutFromFlami
import com.example.data.ai.FlamiAiService
import com.example.data.model.ChatMessage
import com.example.data.repository.FlamiRepository
import com.example.ui.components.ChatHistoryPanel
import com.example.ui.components.MarkdownMessageContent
import com.example.ui.components.MemoryManagerSheet
import com.example.ui.components.MessageComposer
import com.example.ui.components.SettingsSheet
import com.example.ui.viewmodel.FlamiViewModel
import com.example.ui.viewmodel.GenerationState
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch

@Composable
fun FlamiWorkspaceScreen(
    currentUserId: String,
    initialDisplayName: String
) {
    val context = LocalContext.current
    val viewModel: FlamiViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) as Application
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                FlamiViewModel(
                    repository = FlamiRepository(db),
                    aiService = FlamiAiService(),
                    ttsManager = TtsManager(app),
                    currentUserId = currentUserId,
                    initialDisplayName = initialDisplayName
                )
            }
        }
    )

    val profile by viewModel.userProfile.collectAsStateWithLifecycle()
    val effectiveLang by viewModel.effectiveLanguageCode.collectAsStateWithLifecycle()
    val strings = remember(effectiveLang) { FlamiL10n.strings(effectiveLang) }

    val chats by viewModel.chats.collectAsStateWithLifecycle()
    val activeChatId by viewModel.activeChatId.collectAsStateWithLifecycle()
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val memories by viewModel.memories.collectAsStateWithLifecycle()
    val inputText by viewModel.inputText.collectAsStateWithLifecycle()
    val attachedBitmap by viewModel.attachedBitmap.collectAsStateWithLifecycle()
    val generationState by viewModel.generationState.collectAsStateWithLifecycle()
    val searchState by viewModel.searchState.collectAsStateWithLifecycle()
    val speakingMessageId by viewModel.ttsManager.speakingMessageId.collectAsStateWithLifecycle()
    val toastEvent by viewModel.toastEvent.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }

    var showMemorySheet by remember { mutableStateOf(false) }
    var showSettingsSheet by remember { mutableStateOf(false) }

    // Pending export target (whole chat or specific message)
    var pendingExportFormat by remember { mutableStateOf(ExportFormat.ZIP) }
    var pendingExportMessage by remember { mutableStateOf<ChatMessage?>(null) }

    val exportDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.exportCurrentChat(
                context = context,
                uri = uri,
                format = pendingExportFormat,
                singleMessage = pendingExportMessage,
                successMessage = strings.exportSuccess
            )
        }
        pendingExportMessage = null
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                @Suppress("DEPRECATION")
                val bitmap = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    val source = ImageDecoder.createSource(context.contentResolver, uri)
                    ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                        decoder.isMutableRequired = false
                        decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                    }
                } else {
                    MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
                }
                viewModel.attachBitmap(bitmap)
            }.onFailure { err ->
                viewModel.showToast(err.localizedMessage ?: "Failed to load image")
            }
        }
    }

    LaunchedEffect(toastEvent) {
        val msg = toastEvent
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearToast()
        }
    }

    val launchExport: (ExportFormat, ChatMessage?) -> Unit = { format, singleMsg ->
        pendingExportFormat = format
        pendingExportMessage = singleMsg
        val ext = format.extension
        val fileName = "flami_export_${System.currentTimeMillis()}.$ext"
        exportDocumentLauncher.launch(fileName)
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWideScreen = maxWidth >= 840.dp
        val drawerState = rememberDrawerState(DrawerValue.Closed)

        BackHandler(enabled = !isWideScreen && drawerState.isOpen) {
            scope.launch { drawerState.close() }
        }

        val activeMemoryCount = remember(memories) { memories.count { it.isActive } }

        val historyPanel: @Composable (Modifier) -> Unit = { panelModifier ->
            ChatHistoryPanel(
                strings = strings,
                chats = chats,
                activeChatId = activeChatId,
                searchState = searchState,
                activeMemoryCount = activeMemoryCount,
                userDisplayName = profile.displayName.ifBlank { initialDisplayName },
                onSearchQueryChange = viewModel::searchHistory,
                onSelectChat = { id ->
                    viewModel.selectChat(id)
                    if (!isWideScreen) {
                        scope.launch { drawerState.close() }
                    }
                },
                onNewChat = {
                    viewModel.startNewChat()
                    if (!isWideScreen) {
                        scope.launch { drawerState.close() }
                    }
                },
                onRenameChat = viewModel::renameChat,
                onTogglePin = viewModel::togglePinChat,
                onDeleteChat = viewModel::deleteChat,
                onOpenMemory = { showMemorySheet = true },
                onOpenSettings = { showSettingsSheet = true },
                modifier = panelModifier
            )
        }

        val mainChatScaffold: @Composable () -> Unit = {
            MainChatArea(
                strings = strings,
                activeChatTitle = chats.firstOrNull { it.id == activeChatId }?.title ?: strings.newChat,
                modelMode = profile.modelMode,
                messages = messages,
                generationState = generationState,
                inputText = inputText,
                attachedBitmap = attachedBitmap,
                ttsEnabled = profile.ttsEnabled,
                ttsRate = profile.ttsRate.toFloat(),
                speakingMessageId = speakingMessageId,
                activeMemoryCount = activeMemoryCount,
                showMenuButton = !isWideScreen,
                snackbarHostState = snackbarHostState,
                onOpenDrawer = { scope.launch { drawerState.open() } },
                onNewChat = viewModel::startNewChat,
                onOpenMemory = { showMemorySheet = true },
                onOpenSettings = { showSettingsSheet = true },
                onInputChange = viewModel::updateInputText,
                onPickImage = {
                    photoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                },
                onRemoveImage = { viewModel.attachBitmap(null) },
                onSend = { viewModel.sendMessage() },
                onQuickPrompt = { prompt -> viewModel.sendMessage(overridePrompt = prompt) },
                onCancelGeneration = viewModel::cancelGeneration,
                onRetry = viewModel::retryLastUserMessage,
                onToggleSpeak = { msg ->
                    viewModel.ttsManager.toggleSpeak(
                        messageId = msg.id,
                        rawText = msg.text,
                        languageCode = effectiveLang,
                        speechRate = profile.ttsRate.toFloat()
                    )
                },
                onCopyText = { text, clipboard ->
                    clipboard.setText(AnnotatedString(text))
                    viewModel.showToast(strings.copiedToast)
                },
                onExport = launchExport
            )
        }

        if (isWideScreen) {
            Row(modifier = Modifier.fillMaxSize()) {
                historyPanel(Modifier.width(310.dp))
                VerticalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
                Box(modifier = Modifier.weight(1f)) {
                    mainChatScaffold()
                }
            }
        } else {
            ModalNavigationDrawer(
                drawerState = drawerState,
                drawerContent = {
                    ModalDrawerSheet(modifier = Modifier.widthIn(max = 330.dp)) {
                        historyPanel(Modifier.fillMaxWidth())
                    }
                }
            ) {
                mainChatScaffold()
            }
        }
    }

    if (showMemorySheet) {
        MemoryManagerSheet(
            strings = strings,
            memories = memories,
            memoryEnabled = profile.memoryEnabled,
            onToggleMemoryEnabled = viewModel::updateMemoryEnabled,
            onAddMemory = viewModel::addMemory,
            onToggleMemoryItem = viewModel::toggleMemoryActive,
            onDeleteMemory = viewModel::deleteMemory,
            onDismiss = { showMemorySheet = false }
        )
    }

    if (showSettingsSheet) {
        SettingsSheet(
            strings = strings,
            profile = profile,
            onSelectLanguage = viewModel::updateLanguage,
            onSelectModelMode = viewModel::updateModelMode,
            onToggleTts = viewModel::updateTtsEnabled,
            onChangeTtsRate = viewModel::updateTtsRate,
            onSignOut = {
                signOutFromFlami(
                    credentialManager = credentialManager,
                    scope = scope
                )
            },
            onDismiss = { showSettingsSheet = false }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainChatArea(
    strings: FlamiStrings,
    activeChatTitle: String,
    modelMode: String,
    messages: List<ChatMessage>,
    generationState: GenerationState,
    inputText: String,
    attachedBitmap: android.graphics.Bitmap?,
    ttsEnabled: Boolean,
    ttsRate: Float,
    speakingMessageId: String?,
    activeMemoryCount: Int,
    showMenuButton: Boolean,
    snackbarHostState: SnackbarHostState,
    onOpenDrawer: () -> Unit,
    onNewChat: () -> Unit,
    onOpenMemory: () -> Unit,
    onOpenSettings: () -> Unit,
    onInputChange: (String) -> Unit,
    onPickImage: () -> Unit,
    onRemoveImage: () -> Unit,
    onSend: () -> Unit,
    onQuickPrompt: (String) -> Unit,
    onCancelGeneration: () -> Unit,
    onRetry: () -> Unit,
    onToggleSpeak: (ChatMessage) -> Unit,
    onCopyText: (String, androidx.compose.ui.platform.ClipboardManager) -> Unit,
    onExport: (ExportFormat, ChatMessage?) -> Unit
) {
    val listState = rememberLazyListState()
    val clipboard = LocalClipboardManager.current
    var exportMenuExpanded by remember { mutableStateOf(false) }

    LaunchedEffect(messages.size, generationState.streamingText.length) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            CenterAlignedTopAppBar(
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f)
                ),
                navigationIcon = {
                    if (showMenuButton) {
                        IconButton(
                            onClick = onOpenDrawer,
                            modifier = Modifier.testTag("open_drawer_button")
                        ) {
                            Icon(Icons.Rounded.Menu, contentDescription = strings.chatsTitle)
                        }
                    }
                },
                title = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = activeChatTitle,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.CloudDone,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                text = when (modelMode) {
                                    "reasoning" -> strings.modeReasoning
                                    "fast" -> strings.modeFast
                                    else -> strings.modeBalanced
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = onOpenMemory) {
                        Icon(
                            imageVector = Icons.Rounded.Memory,
                            contentDescription = strings.memoryTitle,
                            tint = if (activeMemoryCount > 0) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Box {
                        IconButton(
                            onClick = { exportMenuExpanded = true },
                            enabled = messages.isNotEmpty(),
                            modifier = Modifier.testTag("export_menu_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Download,
                                contentDescription = strings.exportZipAction
                            )
                        }
                        DropdownMenu(
                            expanded = exportMenuExpanded,
                            onDismissRequest = { exportMenuExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text(strings.exportZipAction) },
                                leadingIcon = { Icon(Icons.Rounded.FolderZip, contentDescription = null) },
                                onClick = {
                                    exportMenuExpanded = false
                                    onExport(ExportFormat.ZIP, null)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(strings.exportHtmlAction) },
                                onClick = {
                                    exportMenuExpanded = false
                                    onExport(ExportFormat.HTML, null)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(strings.exportMdAction) },
                                onClick = {
                                    exportMenuExpanded = false
                                    onExport(ExportFormat.MARKDOWN, null)
                                }
                            )
                        }
                    }
                    IconButton(onClick = onNewChat) {
                        Icon(Icons.Rounded.AddComment, contentDescription = strings.newChat)
                    }
                    if (!showMenuButton) {
                        IconButton(onClick = onOpenSettings) {
                            Icon(Icons.Rounded.Settings, contentDescription = strings.settingsTitle)
                        }
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding()
                .imePadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .widthIn(max = 860.dp)
                    .fillMaxWidth()
            ) {
                if (messages.isEmpty()) {
                    EmptyWelcomeState(
                        strings = strings,
                        onQuickPrompt = onQuickPrompt
                    )
                } else {
                    LazyColumn(
                        state = listState,
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(messages, key = { it.id }) { msg ->
                            val isStreamingThis =
                                generationState.isGenerating && generationState.streamingMessageId == msg.id
                            val displayText = if (isStreamingThis && generationState.streamingText.isNotBlank()) {
                                generationState.streamingText
                            } else {
                                msg.text
                            }

                            ChatMessageBubble(
                                message = msg,
                                displayText = displayText,
                                isStreaming = isStreamingThis,
                                isSpeaking = speakingMessageId == msg.id,
                                ttsEnabled = ttsEnabled,
                                strings = strings,
                                onCopy = { onCopyText(it, clipboard) },
                                onToggleSpeak = { onToggleSpeak(msg.copy(text = displayText)) },
                                onExportZip = { onExport(ExportFormat.ZIP, msg.copy(text = displayText)) },
                                onRetry = onRetry
                            )
                        }
                    }
                }
            }

            Box(
                modifier = Modifier
                    .widthIn(max = 860.dp)
                    .fillMaxWidth()
            ) {
                MessageComposer(
                    strings = strings,
                    text = inputText,
                    attachedBitmap = attachedBitmap,
                    isGenerating = generationState.isGenerating,
                    onTextChange = onInputChange,
                    onPickImage = onPickImage,
                    onRemoveImage = onRemoveImage,
                    onSend = onSend,
                    onCancelGeneration = onCancelGeneration
                )
            }
        }
    }
}

@Composable
private fun EmptyWelcomeState(
    strings: FlamiStrings,
    onQuickPrompt: (String) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.outline.copy(alpha = 0.45f),
                        RoundedCornerShape(22.dp)
                    )
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_flami_hero),
                    contentDescription = strings.appTitle,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color(0xCC090D16))
                            )
                        )
                )
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                ) {
                    Text(
                        text = strings.welcomeTitle,
                        style = MaterialTheme.typography.headlineSmall,
                        color = Color.White
                    )
                    Text(
                        text = strings.welcomeSubtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.85f),
                        maxLines = 2
                    )
                }
            }
        }

        val prompts = listOf(
            strings.quickPromptCode,
            strings.quickPromptMath,
            strings.quickPromptWebZip,
            strings.quickPromptLearn
        )

        items(prompts) { prompt ->
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.outline.copy(alpha = 0.35f),
                        RoundedCornerShape(16.dp)
                    )
                    .clickable { onQuickPrompt(prompt) }
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.AutoAwesome,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = prompt,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
private fun ChatMessageBubble(
    message: ChatMessage,
    displayText: String,
    isStreaming: Boolean,
    isSpeaking: Boolean,
    ttsEnabled: Boolean,
    strings: FlamiStrings,
    onCopy: (String) -> Unit,
    onToggleSpeak: () -> Unit,
    onExportZip: () -> Unit,
    onRetry: () -> Unit
) {
    val isUser = message.role == "user"

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        if (!isUser) {
            Box(
                modifier = Modifier
                    .padding(top = 4.dp, end = 8.dp)
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.AutoAwesome,
                    contentDescription = strings.appTitle,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        Surface(
            color = when {
                message.isError -> MaterialTheme.colorScheme.error.copy(alpha = 0.14f)
                isUser -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.85f)
                else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            },
            shape = RoundedCornerShape(
                topStart = 18.dp,
                topEnd = 18.dp,
                bottomStart = if (isUser) 18.dp else 6.dp,
                bottomEnd = if (isUser) 6.dp else 18.dp
            ),
            modifier = Modifier
                .widthIn(max = 680.dp)
                .border(
                    width = 1.dp,
                    color = if (message.isError) {
                        MaterialTheme.colorScheme.error.copy(alpha = 0.45f)
                    } else {
                        MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
                    },
                    shape = RoundedCornerShape(
                        topStart = 18.dp,
                        topEnd = 18.dp,
                        bottomStart = if (isUser) 18.dp else 6.dp,
                        bottomEnd = if (isUser) 6.dp else 18.dp
                    )
                )
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                if (message.hasImage) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(bottom = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Image,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = message.imageNote ?: strings.imageAttachedLabel,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }

                if (displayText.isBlank() && isStreaming) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp
                        )
                        Text(
                            text = strings.generatingLabel,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else if (isUser) {
                    Text(
                        text = displayText,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                } else {
                    MarkdownMessageContent(
                        markdown = displayText,
                        textColor = MaterialTheme.colorScheme.onSurface,
                        copyLabel = strings.copyAction,
                        exportZipLabel = strings.exportZipAction,
                        onCopyCode = onCopy,
                        onExportZip = onExportZip
                    )
                }

                if (!isUser && !isStreaming && displayText.isNotBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(
                            onClick = { onCopy(displayText) },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ContentCopy,
                                contentDescription = strings.copyAction,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(strings.copyAction, style = MaterialTheme.typography.labelMedium)
                        }

                        if (ttsEnabled) {
                            TextButton(
                                onClick = onToggleSpeak,
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = if (isSpeaking) Icons.Rounded.Stop else Icons.Rounded.VolumeUp,
                                    contentDescription = if (isSpeaking) strings.stopSpeakAction else strings.speakAction,
                                    modifier = Modifier.size(15.dp),
                                    tint = if (isSpeaking) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    if (isSpeaking) strings.stopSpeakAction else strings.speakAction,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }
                        }

                        TextButton(
                            onClick = onExportZip,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.FolderZip,
                                contentDescription = strings.exportZipAction,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("ZIP", style = MaterialTheme.typography.labelMedium)
                        }

                        if (message.isError) {
                            TextButton(
                                onClick = onRetry,
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                modifier = Modifier.testTag("retry_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Refresh,
                                    contentDescription = strings.retry,
                                    modifier = Modifier.size(15.dp),
                                    tint = MaterialTheme.colorScheme.error
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    strings.retry,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
