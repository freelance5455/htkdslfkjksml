package com.example.ui.main

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.EditCalendar
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.model.StudySessionEntity
import com.example.data.model.SubjectEntity
import com.example.ui.exam.NearestExamHighlightBanner
import com.example.ui.study.ArchiveSubjectDialog
import com.example.ui.study.ArchivedSubjectsSheet
import com.example.ui.study.DeleteSessionDialog
import com.example.ui.study.LiveTimerCard
import com.example.ui.study.SessionDialog
import com.example.ui.study.StreakHeatmapCard
import com.example.ui.study.StudySessionItemCard
import com.example.ui.study.StudyUiState
import com.example.ui.study.SubjectDialog
import com.example.ui.study.SubjectItemCard
import com.example.ui.study.TimerState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudyTabScreen(
    state: StudyUiState,
    onOpenDrawer: () -> Unit,
    onNavigateToExams: () -> Unit,
    onNavigateToPerformance: () -> Unit,
    // Timer controls
    onStartTimer: (Long?) -> Unit,
    onPauseTimer: () -> Unit,
    onResumeTimer: () -> Unit,
    onStopTimer: () -> Unit,
    onResetTimer: () -> Unit,
    onSelectTimerSubject: (Long) -> Unit,
    // Subject controls
    onOpenAddSubject: () -> Unit,
    onOpenEditSubject: (SubjectEntity) -> Unit,
    onCloseSubjectDialog: () -> Unit,
    onSubjectNameChange: (String) -> Unit,
    onSubjectColorChange: (String) -> Unit,
    onSubjectIconChange: (String) -> Unit,
    onSubjectTargetHoursChange: (String) -> Unit,
    onSaveSubject: () -> Unit,
    onOpenArchiveConfirm: (SubjectEntity) -> Unit,
    onCloseArchiveConfirm: () -> Unit,
    onConfirmArchiveSubject: () -> Unit,
    onRestoreSubject: (Long) -> Unit,
    onToggleArchivedSection: (Boolean) -> Unit,
    // Session controls
    onOpenAddManualSession: () -> Unit,
    onOpenEditSession: (StudySessionEntity) -> Unit,
    onCloseSessionDialog: () -> Unit,
    onSessionSubjectChange: (Long) -> Unit,
    onSessionDateChange: (String) -> Unit,
    onSessionStartTimeChange: (String) -> Unit,
    onSessionHoursChange: (String) -> Unit,
    onSessionMinutesChange: (String) -> Unit,
    onSessionTopicChange: (String) -> Unit,
    onSessionRemarkChange: (String) -> Unit,
    onSaveSession: () -> Unit,
    onOpenDeleteSessionConfirm: (StudySessionEntity) -> Unit,
    onCloseDeleteSessionConfirm: () -> Unit,
    onConfirmDeleteSession: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Study Tracker",
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onOpenDrawer,
                        modifier = Modifier.testTag("menu_drawer_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Menu,
                            contentDescription = "Open left navigation drawer"
                        )
                    }
                },
                actions = {
                    if (state.archivedSubjects.isNotEmpty()) {
                        IconButton(
                            onClick = { onToggleArchivedSection(true) },
                            modifier = Modifier.testTag("open_archived_subjects_action_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Archive,
                                contentDescription = "View archived subjects",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // 1. Daily Streak & Calendar Heatmap (PRD section 5.3)
            StreakHeatmapCard(
                streakResult = state.streakResult,
                todayMinutes = state.todayStudyMinutes
            )

            // 2. Nearest Exam Countdown Highlight (PRD section 5.5: Highlight nearest exam on Study home screen)
            NearestExamHighlightBanner(
                nearestExam = state.nearestExam,
                subject = state.nearestExam?.subjectId?.let { state.subjectsMap[it] },
                onViewExamsClick = onNavigateToExams,
                onAddExamClick = onNavigateToExams
            )

            // 3. Live Study Timer (PRD section 5.2)
            LiveTimerCard(
                timerState = state.timerState,
                elapsedSeconds = state.timerElapsedSeconds,
                selectedSubjectId = state.timerSubjectId,
                activeSubjects = state.activeSubjects,
                onSelectSubject = onSelectTimerSubject,
                onStartTimer = { onStartTimer(null) },
                onPauseTimer = onPauseTimer,
                onResumeTimer = onResumeTimer,
                onStopTimer = onStopTimer,
                onResetTimer = onResetTimer
            )

            // Performance Tracking Quick Access Card (PRD section 5.4)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { onNavigateToPerformance() }
                    .testTag("quick_performance_card"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.BarChart,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Performance Analytics",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Weekly, Monthly, Yearly trends & target progress",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Open Performance Tracking",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // 3. Subjects Header & Section (PRD section 5.1)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "My Subjects",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "${state.activeSubjects.size} active course subjects",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (state.archivedSubjects.isNotEmpty()) {
                        TextButton(
                            onClick = { onToggleArchivedSection(true) },
                            modifier = Modifier.testTag("view_archived_subjects_button")
                        ) {
                            Text("Archived (${state.archivedSubjects.size})")
                        }
                    }

                    FilledTonalButton(
                        onClick = onOpenAddSubject,
                        modifier = Modifier.testTag("add_subject_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add")
                    }
                }
            }

            // Empty state for subjects (PRD User Flow #1)
            if (state.activeSubjects.isEmpty()) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("empty_subjects_prompt_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.School,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(30.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "Add your first subject",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "Add any subject you are studying (e.g., Accounting, Law, Maths, Physics) to start tracking study sessions.",
                            style = MaterialTheme.typography.bodySmall,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = onOpenAddSubject,
                            modifier = Modifier.testTag("empty_state_add_subject_button")
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Add First Subject")
                        }
                    }
                }
            } else {
                // List of Active Subject Cards
                state.activeSubjects.forEach { item ->
                    SubjectItemCard(
                        item = item,
                        onStartTimer = { onStartTimer(item.subject.id) },
                        onEdit = { onOpenEditSubject(item.subject) },
                        onArchive = { onOpenArchiveConfirm(item.subject) }
                    )
                }
            }

            // 4. Study Sessions Section (PRD section 5.2)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Recent Sessions",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "${state.sessions.size} logged sessions",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                OutlinedButton(
                    onClick = onOpenAddManualSession,
                    enabled = state.activeSubjects.isNotEmpty(),
                    modifier = Modifier.testTag("log_manual_session_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.EditCalendar, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Log Past")
                }
            }

            if (state.sessions.isEmpty()) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("empty_sessions_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No study sessions recorded yet.\nStart the live timer above or log a past session manually.",
                            style = MaterialTheme.typography.bodyMedium,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                // List recent study sessions
                state.sessions.take(15).forEach { session ->
                    val subject = state.subjectsMap[session.subjectId]
                    StudySessionItemCard(
                        session = session,
                        subject = subject,
                        onEdit = { onOpenEditSession(session) },
                        onDelete = { onOpenDeleteSessionConfirm(session) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    // ==========================================
    // DIALOGS & BOTTOM SHEETS
    // ==========================================

    if (state.showSubjectDialog) {
        SubjectDialog(
            isEditing = state.subjectBeingEdited != null,
            name = state.subjectNameInput,
            onNameChange = onSubjectNameChange,
            colorHex = state.subjectColorInput,
            onColorChange = onSubjectColorChange,
            iconName = state.subjectIconInput,
            onIconChange = onSubjectIconChange,
            targetHours = state.subjectTargetHoursInput,
            onTargetHoursChange = onSubjectTargetHoursChange,
            errorMessage = state.subjectError,
            onDismiss = onCloseSubjectDialog,
            onSave = onSaveSubject
        )
    }

    if (state.showArchiveConfirmDialog) {
        ArchiveSubjectDialog(
            subject = state.subjectToArchive,
            onDismiss = onCloseArchiveConfirm,
            onConfirmArchive = onConfirmArchiveSubject
        )
    }

    if (state.showArchivedSection) {
        ArchivedSubjectsSheet(
            archivedSubjects = state.archivedSubjects,
            onRestoreSubject = onRestoreSubject,
            onDismiss = { onToggleArchivedSection(false) }
        )
    }

    if (state.showSessionDialog) {
        SessionDialog(
            isEditing = state.sessionBeingEdited != null,
            activeSubjects = state.activeSubjects,
            selectedSubjectId = state.sessionSubjectId,
            onSubjectSelected = onSessionSubjectChange,
            date = state.sessionDateInput,
            onDateChange = onSessionDateChange,
            startTime = state.sessionStartTimeInput,
            onStartTimeChange = onSessionStartTimeChange,
            hours = state.sessionHoursInput,
            onHoursChange = onSessionHoursChange,
            minutes = state.sessionMinutesInput,
            onMinutesChange = onSessionMinutesChange,
            topic = state.sessionTopicInput,
            onTopicChange = onSessionTopicChange,
            remark = state.sessionRemarkInput,
            onRemarkChange = onSessionRemarkChange,
            errorMessage = state.sessionError,
            onDismiss = onCloseSessionDialog,
            onSave = onSaveSession
        )
    }

    if (state.showDeleteSessionDialog) {
        val subjectName = state.sessionToDelete?.let { state.subjectsMap[it.subjectId]?.name } ?: "this subject"
        DeleteSessionDialog(
            session = state.sessionToDelete,
            subjectName = subjectName,
            onDismiss = onCloseDeleteSessionConfirm,
            onConfirmDelete = onConfirmDeleteSession
        )
    }
}
