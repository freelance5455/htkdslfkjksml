package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.HifzClass
import com.example.data.model.Invite
import com.example.data.model.School
import com.example.data.model.Student
import com.example.export.PdfAndShareHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminPanelScreen(
    school: School,
    classes: List<HifzClass>,
    classPins: Map<String, String>,
    adminPin: String,
    selectedClassId: String,
    students: List<Student>,
    savedDates: List<String>,
    invites: List<Invite>,
    backupJson: String,
    onLoadSecrets: () -> Unit,
    onSaveHeading: (String, String) -> Unit,
    onSelectClass: (String) -> Unit,
    onAddClass: (String) -> Unit,
    onRenameClass: (String, String) -> Unit,
    onUpdateClassPin: (String, String) -> Unit,
    onDeleteClass: (String) -> Unit,
    onAddStudent: (String) -> Unit,
    onRenameStudent: (String, String) -> Unit,
    onMoveStudent: (Int, Int) -> Unit,
    onDeleteStudent: (String) -> Unit,
    onOpenSavedSheet: (String) -> Unit,
    onDeleteSavedSheet: (String) -> Unit,
    onAddInvite: (String, String, String) -> Unit,
    onRemoveInvite: (String) -> Unit,
    onUpdateAdminPin: (String) -> Unit,
    onExportBackup: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    LaunchedEffect(school.id) {
        onLoadSecrets()
    }

    val context = LocalContext.current
    var headingTitle by remember(school.title) { mutableStateOf(school.title) }
    var headingCentre by remember(school.centre) { mutableStateOf(school.centre) }
    var newClassName by remember { mutableStateOf("") }
    var newStudentName by remember { mutableStateOf("") }
    var newAdminPin by remember { mutableStateOf("") }
    var inviteEmail by remember { mutableStateOf("") }
    var inviteRole by remember { mutableStateOf("class") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ایڈمن پینل · Admin Panel") },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("admin_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Close Admin Panel")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // School Connection Info Card
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("مدرسہ کوڈ (اساتذہ کے موبائل کے لیے):", style = MaterialTheme.typography.labelLarge)
                        Text(school.id, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                        if (adminPin.isNotBlank()) {
                            Text("موجودہ ایڈمن PIN: $adminPin", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    IconButton(onClick = {
                        PdfAndShareHelper.copyTextToClipboard(context, "Madrasah Code", school.id)
                        Toast.makeText(context, "کوڈ کاپی ہو گیا ✓", Toast.LENGTH_SHORT).show()
                    }) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy Madrasah Code")
                    }
                }
            }

            // Heading Settings
            AdminSectionCard("Heading (all classes)") {
                OutlinedTextField(
                    value = headingTitle,
                    onValueChange = { headingTitle = it },
                    label = { Text("Heading") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = headingCentre,
                    onValueChange = { headingCentre = it },
                    label = { Text("Centre name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = { onSaveHeading(headingTitle, headingCentre) },
                    modifier = Modifier.testTag("save_heading_button")
                ) {
                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Save heading")
                }
            }

            // Classes & Class PINs
            AdminSectionCard("Classes & Class Login PINs") {
                classes.forEachIndexed { idx, cls ->
                    var cName by remember(cls.id, cls.name) { mutableStateOf(cls.name) }
                    var cPin by remember(cls.id, classPins[cls.id]) { mutableStateOf(classPins[cls.id] ?: "") }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("${idx + 1}.", style = MaterialTheme.typography.labelMedium)
                        OutlinedTextField(
                            value = cName,
                            onValueChange = { cName = it },
                            label = { Text("Name (${cls.id})") },
                            singleLine = true,
                            modifier = Modifier.weight(1.4f)
                        )
                        OutlinedTextField(
                            value = cPin,
                            onValueChange = { cPin = it },
                            label = { Text("PIN") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                            modifier = Modifier.weight(0.8f)
                        )
                        IconButton(onClick = {
                            if (cName.isNotBlank()) onRenameClass(cls.id, cName)
                            if (cPin.isNotBlank()) onUpdateClassPin(cls.id, cPin)
                        }) {
                            Icon(Icons.Default.Save, contentDescription = "Save Class")
                        }
                        if (classes.size > 1) {
                            IconButton(onClick = { onDeleteClass(cls.id) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete Class", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = newClassName,
                        onValueChange = { newClassName = it },
                        label = { Text("New class name") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = {
                            if (newClassName.isNotBlank()) {
                                onAddClass(newClassName)
                                newClassName = ""
                            }
                        }
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Text("Add")
                    }
                }
            }

            // Teacher Gmail Invites (1-Tap Join)
            AdminSectionCard("Teacher Gmail Invites (Optional 1-Tap Join)") {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    classes.forEach { cls ->
                        FilterChip(
                            selected = inviteRole == "class" && selectedClassId == cls.id,
                            onClick = { inviteRole = "class"; onSelectClass(cls.id) },
                            label = { Text(cls.name) }
                        )
                    }
                    FilterChip(
                        selected = inviteRole == "admin",
                        onClick = { inviteRole = "admin" },
                        label = { Text("Admin") }
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = inviteEmail,
                        onValueChange = { inviteEmail = it },
                        label = { Text("Teacher Gmail") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = {
                            if (inviteEmail.isNotBlank()) {
                                onAddInvite(inviteEmail, inviteRole, selectedClassId)
                                inviteEmail = ""
                            }
                        }
                    ) {
                        Text("Invite")
                    }
                }
                invites.forEach { inv ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("${inv.email} (${inv.role}${if (inv.classId.isNotBlank()) ": ${inv.classId}" else ""})", style = MaterialTheme.typography.bodySmall)
                        IconButton(onClick = { onRemoveInvite(inv.email) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Remove Invite", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }

            // Students Management
            AdminSectionCard("Students") {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    classes.forEach { cls ->
                        FilterChip(
                            selected = cls.id == selectedClassId,
                            onClick = { onSelectClass(cls.id) },
                            label = { Text(cls.name) }
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = newStudentName,
                        onValueChange = { newStudentName = it },
                        label = { Text("New student name") },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("admin_new_student_input")
                    )
                    Button(
                        onClick = {
                            if (newStudentName.isNotBlank()) {
                                onAddStudent(newStudentName)
                                newStudentName = ""
                            }
                        },
                        modifier = Modifier.testTag("admin_add_student_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Text("Add")
                    }
                }
                students.forEachIndexed { idx, stu ->
                    var sName by remember(stu.id, stu.name) { mutableStateOf(stu.name) }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("${idx + 1}.", style = MaterialTheme.typography.labelMedium)
                        OutlinedTextField(
                            value = sName,
                            onValueChange = { sName = it },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = { if (sName.isNotBlank()) onRenameStudent(stu.id, sName) }) {
                            Icon(Icons.Default.Save, contentDescription = "Save Student Name")
                        }
                        IconButton(onClick = { onMoveStudent(idx, -1) }, enabled = idx > 0) {
                            Icon(Icons.Default.ArrowUpward, contentDescription = "Move Up")
                        }
                        IconButton(onClick = { onMoveStudent(idx, +1) }, enabled = idx < students.lastIndex) {
                            Icon(Icons.Default.ArrowDownward, contentDescription = "Move Down")
                        }
                        IconButton(onClick = { onDeleteStudent(stu.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Remove Student", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }

            // Saved Sheets
            AdminSectionCard("Saved Sheets ($selectedClassId)") {
                if (savedDates.isEmpty()) {
                    Text("No saved sheets yet.", style = MaterialTheme.typography.bodySmall)
                } else {
                    savedDates.take(30).forEach { d ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(d, style = MaterialTheme.typography.bodyMedium)
                            Row {
                                IconButton(onClick = {
                                    onOpenSavedSheet(d)
                                    onBack()
                                }) {
                                    Icon(Icons.Default.OpenInNew, contentDescription = "Open Sheet")
                                }
                                IconButton(onClick = { onDeleteSavedSheet(d) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete Sheet", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                    }
                }
            }

            // Backup & Admin PIN
            AdminSectionCard("Backup & Admin PIN") {
                OutlinedButton(onClick = onExportBackup, modifier = Modifier.fillMaxWidth()) {
                    Text("Export JSON Backup")
                }
                if (backupJson.isNotBlank()) {
                    OutlinedTextField(
                        value = backupJson,
                        onValueChange = {},
                        readOnly = true,
                        maxLines = 6,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedButton(
                        onClick = {
                            PdfAndShareHelper.copyTextToClipboard(context, "Hifz Backup", backupJson)
                            Toast.makeText(context, "بیک اپ کاپی ہو گیا ✓", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Copy Backup JSON")
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = newAdminPin,
                        onValueChange = { newAdminPin = it },
                        label = { Text("New Admin PIN (4+ digits)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        modifier = Modifier.weight(1f)
                    )
                    Button(
                        onClick = {
                            if (newAdminPin.length >= 4) {
                                onUpdateAdminPin(newAdminPin)
                                newAdminPin = ""
                            }
                        },
                        enabled = newAdminPin.length >= 4
                    ) {
                        Text("Change PIN")
                    }
                }
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun AdminSectionCard(
    title: String,
    content: @Composable () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            content()
        }
    }
}
