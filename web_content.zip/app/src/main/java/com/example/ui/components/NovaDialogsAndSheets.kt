package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.assistant.NovaDeviceController
import com.example.data.model.AnswerLength
import com.example.data.model.ContactItem
import com.example.data.model.DeviceInfoSnapshot
import com.example.data.model.UserMemory
import com.example.data.model.VoiceLanguage
import com.example.ui.theme.NovaDeepViolet
import com.example.ui.theme.NovaElectricBlue

/**
 * 1. Dedicated Voice Assistant & Screen-Off "Hello Nova" Wake-Word Modal Sheet
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun VoiceAssistantSheet(
    isListening: Boolean,
    isSpeaking: Boolean,
    partialTranscript: String,
    voiceError: String?,
    selectedLanguage: VoiceLanguage,
    speechRate: Float,
    isWakeServiceRunning: Boolean,
    wakeServiceStatus: String,
    wakePhrase: String,
    onUpdateWakePhrase: (String) -> Unit,
    onToggleListening: () -> Unit,
    onStopSpeaking: () -> Unit,
    onSelectLanguage: (VoiceLanguage) -> Unit,
    onChangeSpeechRate: (Float) -> Unit,
    onToggleWakeWordService: (Boolean) -> Unit,
    onSendVoicePrompt: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val infiniteTransition = rememberInfiniteTransition(label = "voice_orb")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (isListening || isSpeaking) 1.18f else 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(900),
            repeatMode = RepeatMode.Reverse
        ),
        label = "orb_pulse"
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "AURA Voice & Wake-Word Studio",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close voice assistant")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Animated Neural Voice Orb
            Box(
                modifier = Modifier
                    .size(124.dp)
                    .scale(pulseScale)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = if (isListening) {
                                listOf(NovaElectricBlue, NovaDeepViolet, Color.Transparent)
                            } else if (isSpeaking) {
                                listOf(NovaDeepViolet, NovaElectricBlue, Color.Transparent)
                            } else {
                                listOf(NovaElectricBlue.copy(alpha = 0.35f), NovaDeepViolet.copy(alpha = 0.2f), Color.Transparent)
                            }
                        )
                    )
                    .border(2.dp, NovaElectricBlue, CircleShape)
                    .clickable { onToggleListening() }
                    .testTag("voice_orb_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isListening) Icons.Default.Mic else Icons.Default.MicOff,
                    contentDescription = if (isListening) "Stop listening" else "Start listening",
                    tint = Color.White,
                    modifier = Modifier.size(48.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = when {
                    isListening -> "Listening... Speak naturally in Hindi, Hinglish, or English"
                    isSpeaking -> "AURA AI is speaking..."
                    else -> "Tap the orb to talk to AURA AI"
                },
                style = MaterialTheme.typography.titleSmall,
                color = NovaElectricBlue,
                textAlign = TextAlign.Center
            )

            if (partialTranscript.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "\"$partialTranscript\"",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(14.dp),
                        textAlign = TextAlign.Center
                    )
                }
            }

            if (!voiceError.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = voiceError,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Primary Voice Controls
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = onToggleListening,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isListening) MaterialTheme.colorScheme.error else NovaElectricBlue,
                        contentColor = Color(0xFF001F25)
                    ),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = if (isListening) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = null
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(if (isListening) "Stop Listening" else "Start Listening", fontWeight = FontWeight.Bold)
                }

                if (isSpeaking) {
                    OutlinedButton(
                        onClick = onStopSpeaking,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.VolumeOff, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Interrupt Speech")
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Quick Spoken Command Examples
            Text(
                text = "Try Spoken Commands (Tap to test immediately):",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.align(Alignment.Start)
            )
            Spacer(modifier = Modifier.height(8.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                listOf(
                    "Mere phone ki battery kitni hai?",
                    "Hello Aura, mujhe Python samjhao",
                    "Storage kitni bachi hai?",
                    "Abhi kitna time hua hai?",
                    "Papa ko call lagao"
                ).forEach { sample ->
                    FilterChip(
                        selected = false,
                        onClick = { onSendVoicePrompt(sample) },
                        label = { Text(sample, style = MaterialTheme.typography.bodySmall) }
                    )
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))

            // Voice Language & Speed Settings
            Text(
                text = "Voice Recognition & Speech Language",
                style = MaterialTheme.typography.titleSmall,
                modifier = Modifier.align(Alignment.Start)
            )
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                VoiceLanguage.entries.forEach { lang ->
                    FilterChip(
                        selected = selectedLanguage == lang,
                        onClick = { onSelectLanguage(lang) },
                        label = { Text(lang.label) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Speaking Speed", style = MaterialTheme.typography.bodyMedium)
                Text("${String.format( java.util.Locale.US, "%.2f", speechRate)}x", style = MaterialTheme.typography.labelLarge, color = NovaElectricBlue)
            }
            Slider(
                value = speechRate,
                onValueChange = onChangeSpeechRate,
                valueRange = 0.65f..1.6f
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 14.dp))

            // Screen-Off Wake Word ("Hello Nova") Foreground Service Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Hands-Free \"Hello Aura\" Service",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = wakeServiceStatus,
                                style = MaterialTheme.typography.bodySmall,
                                color = if (isWakeServiceRunning) NovaElectricBlue else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = isWakeServiceRunning,
                            onCheckedChange = onToggleWakeWordService,
                            modifier = Modifier.testTag("wake_word_service_switch")
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = wakePhrase,
                        onValueChange = onUpdateWakePhrase,
                        label = { Text("Configurable Wake Phrase") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Android Platform Note: Runs a transparent Foreground Microphone Service with a persistent notification and partial WakeLock when enabled. On physical devices with the screen off, OEM battery savers may pause standard SpeechRecognizer sessions; disable battery optimization for AURA AI in Android Battery Settings for uninterrupted background listening.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

/**
 * 2. Real-Time Phone Information, Contacts Calling & Android Actions Sheet
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PhoneAssistantSheet(
    deviceController: NovaDeviceController,
    deviceSnapshot: DeviceInfoSnapshot,
    onRefreshSnapshot: () -> Unit,
    onRequestContactsPermission: () -> Unit,
    onRequestCallPermission: () -> Unit,
    onSendDeviceQuestionToChat: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var contactSearchQuery by remember { mutableStateOf("") }
    var matchedContacts by remember { mutableStateOf<List<ContactItem>>(emptyList()) }
    var directDialNumber by remember { mutableStateOf("") }
    var timerSecondsInput by remember { mutableStateOf("60") }
    var mapDestinationInput by remember { mutableStateOf("") }
    var appLaunchInput by remember { mutableStateOf("") }
    var statusBanner by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Android Personal Assistant Hub",
                        style = MaterialTheme.typography.titleLarge
                    )
                    Text(
                        text = "${deviceSnapshot.deviceModel} • Android ${deviceSnapshot.androidVersion}",
                        style = MaterialTheme.typography.bodySmall,
                        color = NovaElectricBlue
                    )
                }
                Row {
                    IconButton(onClick = onRefreshSnapshot) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh device telemetry")
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close device hub")
                    }
                }
            }

            if (!statusBanner.isNullOrBlank()) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = NovaElectricBlue.copy(alpha = 0.15f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = statusBanner!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = NovaElectricBlue,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            // Live Telemetry Grid
            Text(
                text = "Real-Time Phone Telemetry (Live System APIs)",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                TelemetryMetricCard(
                    icon = Icons.Default.BatteryChargingFull,
                    title = "Battery",
                    value = "${deviceSnapshot.batteryPercentage}%",
                    subtitle = if (deviceSnapshot.isCharging) "Charging (${deviceSnapshot.chargingSource})" else "Discharging",
                    modifier = Modifier.weight(1f),
                    onClick = { onSendDeviceQuestionToChat("Mere phone ki battery kitni hai aur kya phone charging par hai?") }
                )
                TelemetryMetricCard(
                    icon = Icons.Default.Storage,
                    title = "Storage Free",
                    value = "${deviceSnapshot.availableStorageGb} GB",
                    subtitle = "of ${deviceSnapshot.totalStorageGb} GB total",
                    modifier = Modifier.weight(1f),
                    onClick = { onSendDeviceQuestionToChat("Mere phone mein kitni storage bachi hai?") }
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                TelemetryMetricCard(
                    icon = Icons.Default.Wifi,
                    title = "Network & Wi-Fi",
                    value = if (deviceSnapshot.isInternetConnected) deviceSnapshot.networkTransport else "Offline",
                    subtitle = "Wi-Fi: ${if (deviceSnapshot.isWifiEnabled) "ON" else "OFF"}",
                    modifier = Modifier.weight(1f),
                    onClick = { onSendDeviceQuestionToChat("Wi-Fi aur internet connected hai kya?") }
                )
                TelemetryMetricCard(
                    icon = Icons.Default.Bluetooth,
                    title = "Bluetooth & Clock",
                    value = if (deviceSnapshot.isBluetoothEnabled) "BT ON" else "BT OFF",
                    subtitle = deviceSnapshot.currentTimeFormatted,
                    modifier = Modifier.weight(1f),
                    onClick = { onSendDeviceQuestionToChat("Abhi kitna time hua hai aur aaj kya date hai?") }
                )
            }

            HorizontalDivider()

            // Calling & Contacts Section
            Text(
                text = "Calling & Contacts Assistant",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = contactSearchQuery,
                    onValueChange = { q ->
                        contactSearchQuery = q
                        if (deviceController.hasContactsPermission()) {
                            matchedContacts = deviceController.searchContacts(q)
                        }
                    },
                    label = { Text("Search saved contact (e.g. Papa, Mummy)") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Button(
                    onClick = {
                        if (!deviceController.hasContactsPermission()) {
                            onRequestContactsPermission()
                        } else {
                            matchedContacts = deviceController.searchContacts(contactSearchQuery)
                            if (matchedContacts.isEmpty()) {
                                statusBanner = "No contacts found matching '$contactSearchQuery'."
                            }
                        }
                    }
                ) {
                    Icon(Icons.Default.Search, contentDescription = "Search contacts")
                }
            }

            if (!deviceController.hasContactsPermission()) {
                OutlinedButton(
                    onClick = onRequestContactsPermission,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Authorize Contacts Access to Search by Name")
                }
            }

            matchedContacts.take(6).forEach { contact ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(contact.displayName, style = MaterialTheme.typography.titleSmall)
                            Text(contact.phoneNumber, style = MaterialTheme.typography.bodySmall, color = NovaElectricBlue)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { deviceController.openDialer(contact.phoneNumber) }
                            ) {
                                Text("Dialer")
                            }
                            Button(
                                onClick = {
                                    if (deviceController.hasCallPhonePermission()) {
                                        deviceController.placeDirectCall(contact.phoneNumber)
                                    } else {
                                        onRequestCallPermission()
                                    }
                                }
                            ) {
                                Icon(Icons.Default.Call, contentDescription = "Call", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Call")
                            }
                        }
                    }
                }
            }

            // Direct Number Dialer
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = directDialNumber,
                    onValueChange = { directDialNumber = it },
                    label = { Text("Phone number to dial") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                OutlinedButton(
                    onClick = { deviceController.openDialer(directDialNumber) }
                ) {
                    Icon(Icons.Default.Phone, contentDescription = "Open Dialer")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Dialer")
                }
            }

            HorizontalDivider()

            // Quick Phone Actions
            Text(
                text = "System Shortcuts & Device Actions",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { deviceController.openSystemSettings() },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Settings, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Settings")
                }
                OutlinedButton(
                    onClick = { deviceController.openWifiSettings() },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Wifi, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Wi-Fi")
                }
                OutlinedButton(
                    onClick = { deviceController.openBluetoothSettings() },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Bluetooth, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Bluetooth")
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { deviceController.openBatterySettings() },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.BatteryChargingFull, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Battery")
                }
                OutlinedButton(
                    onClick = { deviceController.openCameraApp() },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Camera")
                }
                OutlinedButton(
                    onClick = { deviceController.createCalendarEvent("AURA AI Reminder") },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Calendar")
                }
            }

            // Timer & Maps & App Launcher Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = timerSecondsInput,
                    onValueChange = { timerSecondsInput = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Timer (sec)") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Button(
                    onClick = {
                        val secs = timerSecondsInput.toIntOrNull() ?: 60
                        deviceController.setDeviceTimer(secs, "AURA AI Timer")
                    }
                ) {
                    Icon(Icons.Default.Alarm, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Set Timer")
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = mapDestinationInput,
                    onValueChange = { mapDestinationInput = it },
                    label = { Text("Navigate to place / city") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Button(
                    onClick = { deviceController.startMapNavigation(mapDestinationInput) }
                ) {
                    Icon(Icons.Default.Map, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Maps")
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = appLaunchInput,
                    onValueChange = { appLaunchInput = it },
                    label = { Text("Launch installed app (e.g. Chrome, YouTube)") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Button(
                    onClick = {
                        val ok = deviceController.launchAppByName(appLaunchInput)
                        statusBanner = if (ok) "Launched '$appLaunchInput'." else "Could not find installed app matching '$appLaunchInput'."
                    }
                ) {
                    Text("Open App")
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun TelemetryMetricCard(
    icon: ImageVector,
    title: String,
    value: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = NovaElectricBlue, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/**
 * 3. User Account, Preferences & Long-Term Memory Sheet
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AccountAndMemorySheet(
    userEmail: String?,
    userDisplayName: String?,
    isDarkTheme: Boolean,
    answerLength: AnswerLength,
    memories: List<UserMemory>,
    onToggleDarkTheme: (Boolean) -> Unit,
    onSelectAnswerLength: (AnswerLength) -> Unit,
    onAddMemory: (String, String) -> Unit,
    onDeleteMemory: (String) -> Unit,
    onClearAllMemories: () -> Unit,
    onClearAllConversations: () -> Unit,
    onSignOut: () -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var newMemoryFact by remember { mutableStateOf("") }
    var newMemoryCategory by remember { mutableStateOf("Preference") }
    var confirmClearHistory by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Account, Memory & Settings", style = MaterialTheme.typography.titleLarge)
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close settings")
                }
            }

            // Account Profile Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = userDisplayName?.ifBlank { "AURA AI User" } ?: "AURA AI User",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = userEmail ?: "Signed in with Google",
                            style = MaterialTheme.typography.bodySmall,
                            color = NovaElectricBlue
                        )
                    }
                    OutlinedButton(
                        onClick = onSignOut,
                        modifier = Modifier.testTag("sign_out_button")
                    ) {
                        Icon(Icons.Default.Logout, contentDescription = "Sign out", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Sign Out")
                    }
                }
            }

            // Theme & Response Length Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Premium Dark Theme", style = MaterialTheme.typography.titleSmall)
                    Text("Switch between Obsidian Dark and Clean Light theme", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(
                    checked = isDarkTheme,
                    onCheckedChange = onToggleDarkTheme
                )
            }

            Text("Default AI Answer Length", style = MaterialTheme.typography.titleSmall)
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                AnswerLength.entries.forEach { len ->
                    FilterChip(
                        selected = answerLength == len,
                        onClick = { onSelectAnswerLength(len) },
                        label = { Text(len.label) }
                    )
                }
            }

            HorizontalDivider()

            // Long-Term User-Controlled Memory Section
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Memory, contentDescription = null, tint = NovaElectricBlue)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Long-Term Memory (${memories.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
                if (memories.isNotEmpty()) {
                    OutlinedButton(onClick = onClearAllMemories) {
                        Text("Clear All")
                    }
                }
            }

            Text(
                text = "Save facts, language preferences, or project context that AURA AI should remember across all conversations.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = newMemoryFact,
                    onValueChange = { newMemoryFact = it },
                    label = { Text("Add memory (e.g. Prefer Hinglish & Kotlin examples)") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Button(
                    onClick = {
                        if (newMemoryFact.isNotBlank()) {
                            onAddMemory(newMemoryFact, newMemoryCategory)
                            newMemoryFact = ""
                        }
                    }
                ) {
                    Text("Save")
                }
            }

            memories.forEach { mem ->
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(mem.category, style = MaterialTheme.typography.labelSmall, color = NovaElectricBlue)
                            Text(mem.fact, style = MaterialTheme.typography.bodyMedium)
                        }
                        IconButton(onClick = { onDeleteMemory(mem.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete memory", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }

            HorizontalDivider()

            // Data Retention & Conversation Deletion
            Text("Privacy & Data Control", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (!confirmClearHistory) {
                OutlinedButton(
                    onClick = { confirmClearHistory = true },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.DeleteSweep, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Delete All Conversations")
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { confirmClearHistory = false },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Cancel")
                    }
                    Button(
                        onClick = {
                            confirmClearHistory = false
                            onClearAllConversations()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Confirm Delete All")
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

private data class ButtonGuideEntry(
    val icon: ImageVector,
    val title: String,
    val description: String
)

/**
 * 4. Introduction & Button Guide Sheet (Opened from the Three-Line Menu)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IntroductionSheet(
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val guideItems = remember {
        listOf(
            ButtonGuideEntry(
                icon = Icons.Default.AutoAwesome,
                title = "☰ Three-Line Menu (Top-Left)",
                description = "Yahan se aap Introduction (Button Guide) dekh sakte hain, New Chat shuru kar sakte hain, purani chats search kar sakte hain, ya kisi chat ko Rename / Delete kar sakte hain."
            ),
            ButtonGuideEntry(
                icon = Icons.Default.Refresh,
                title = "+ New Chat Button (Top Bar & Menu)",
                description = "Nayi conversation turant start karne ke liye is button ko dabayein."
            ),
            ButtonGuideEntry(
                icon = Icons.Default.VolumeUp,
                title = "Voice Studio Button (Top Bar Wave Icon)",
                description = "AURA AI se Hindi, Hinglish ya English mein baat karne, speaking speed badalne, aur 'Hello Aura' hands-free background listening on/off karne ke liye."
            ),
            ButtonGuideEntry(
                icon = Icons.Default.Phone,
                title = "Phone Assistant Button (Top Bar Phone Icon)",
                description = "Phone ki live Battery %, Free Storage, Wi-Fi, Bluetooth, Time/Date dekhne, Contacts search karke Call lagane, Timer lagane aur System Settings kholne ke liye."
            ),
            ButtonGuideEntry(
                icon = Icons.Default.Settings,
                title = "Account & Memory Button (Top Bar Person Icon)",
                description = "Apna Google Account dekhne, Dark/Light Theme switch karne, AI Answer Length set karne, Long-Term Memory save karne, ya saari history clear karne ke liye."
            ),
            ButtonGuideEntry(
                icon = Icons.Default.Search,
                title = "Mode Chips (General, Coding, Research, Writing, Image Studio)",
                description = "Message box ke upar diye gaye buttons se AURA AI ka mode badlein — normal chat, coding help, web research, writing, ya nayi AI photo banane ke liye."
            ),
            ButtonGuideEntry(
                icon = Icons.Default.CameraAlt,
                title = "Gallery, File & Camera Buttons (Bottom-Left)",
                description = "Photo/Screenshot upload karne (Gallery), PDF/DOCX/Code file bhejne (Attach Icon), ya Camera se live photo kheench kar AURA AI se analyze karwane ke liye."
            ),
            ButtonGuideEntry(
                icon = Icons.Default.Mic,
                title = "Mic Button (Message Box ke paas)",
                description = "Bina type kiye bolkar message likhne ya seedha voice command bhejne ke liye."
            ),
            ButtonGuideEntry(
                icon = Icons.Default.AutoAwesome,
                title = "Send / Stop Button (Bottom-Right)",
                description = "Message bhejne ke liye (aapka message Right side aayega aur AURA AI ka jawab Left side). Jawab aate waqt Stop daba kar beech mein rok sakte hain."
            ),
            ButtonGuideEntry(
                icon = Icons.Default.Memory,
                title = "Message Ke Neeche Buttons (Speaker, Copy, Regenerate, Edit)",
                description = "AURA AI ke jawab ko bolkar sunne (Speaker), copy karne (Copy), dobara naya jawab mangwane (Regenerate), ya apna bheja hua message edit karne ke liye."
            )
        )
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Introduction & Button Guide",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Janein AURA AI ka kaun-sa button kya kaam karta hai",
                        style = MaterialTheme.typography.bodySmall,
                        color = NovaElectricBlue
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close introduction")
                }
            }

            HorizontalDivider()

            guideItems.forEach { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(NovaElectricBlue.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = null,
                                tint = NovaElectricBlue,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.title,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = item.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

