package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.MusicRepository
import com.example.data.model.PlaylistEntity
import com.example.data.model.SongEntity
import com.example.ui.components.ArtworkImage
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkError
import com.example.ui.theme.DarkFavorite
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.OnEmeraldContainer
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.util.TimeUtils

@Composable
fun PlaylistsScreen(
    playlists: List<PlaylistEntity>,
    repository: MusicRepository,
    allSongs: List<SongEntity>,
    favoriteSongs: List<SongEntity>,
    recentlyPlayedSongs: List<SongEntity>,
    onCreatePlaylist: (name: String, desc: String, coverUri: Uri?) -> Unit,
    onUpdatePlaylist: (playlist: PlaylistEntity, name: String, desc: String, coverUri: Uri?, removeCover: Boolean) -> Unit,
    onDeletePlaylist: (PlaylistEntity) -> Unit,
    onPlaySong: (SongEntity, List<SongEntity>) -> Unit,
    onExportPlaylist: (PlaylistEntity, List<SongEntity>, Uri) -> Unit,
    onImportPlaylist: (Uri) -> Unit,
    modifier: Modifier = Modifier
) {
    var activeDetailPlaylist by remember { mutableStateOf<PlaylistEntity?>(null) }
    var showCreateDialog by remember { mutableStateOf(false) }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            onImportPlaylist(uri)
        }
    }

    if (activeDetailPlaylist != null) {
        PlaylistDetailView(
            playlist = activeDetailPlaylist!!,
            repository = repository,
            allSongs = allSongs,
            onBack = { activeDetailPlaylist = null },
            onPlaySong = onPlaySong,
            onUpdatePlaylist = { pl, name, desc, cover, remove ->
                onUpdatePlaylist(pl, name, desc, cover, remove)
                activeDetailPlaylist = pl.copy(name = name, description = desc)
            },
            onDeletePlaylist = {
                onDeletePlaylist(it)
                activeDetailPlaylist = null
            },
            onExportPlaylist = { pl, sList, uri ->
                onExportPlaylist(pl, sList, uri)
            }
        )
    } else {
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .background(DarkBackground)
                .padding(horizontal = 16.dp)
                .testTag("playlists_screen"),
            contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Playlists",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        IconButton(onClick = { importLauncher.launch(arrayOf("application/json")) }) {
                            Icon(
                                imageVector = Icons.Default.FileDownload,
                                contentDescription = "Import Playlist JSON",
                                tint = TextSecondary
                            )
                        }

                        Button(
                            onClick = { showCreateDialog = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = EmeraldPrimary,
                                contentColor = DarkBackground
                            ),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.testTag("new_playlist_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("New")
                        }
                    }
                }
            }

            // Built-in Favorites System Playlist Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            // Open virtual favorites or play
                            if (favoriteSongs.isNotEmpty()) {
                                onPlaySong(favoriteSongs.first(), favoriteSongs)
                            }
                        },
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(DarkFavorite.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Favorite, contentDescription = null, tint = DarkFavorite, modifier = Modifier.size(24.dp))
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Favorites", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text("${favoriteSongs.size} favorite tracks", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                        if (favoriteSongs.isNotEmpty()) {
                            IconButton(onClick = { onPlaySong(favoriteSongs.first(), favoriteSongs) }) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Play Favorites", tint = EmeraldPrimary)
                            }
                        }
                    }
                }
            }

            // User playlists list
            if (playlists.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 24.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.QueueMusic, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(40.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("No custom playlists yet", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                            Text("Tap New above to organize your music into playlists", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        }
                    }
                }
            } else {
                items(playlists, key = { it.id }) { pl ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { activeDetailPlaylist = pl },
                        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            ArtworkImage(
                                artworkPath = pl.customArtworkPath,
                                contentDescription = pl.name,
                                modifier = Modifier.size(54.dp),
                                shape = RoundedCornerShape(8.dp),
                                iconSize = 24.dp
                            )
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = pl.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (pl.description.isNotBlank()) {
                                    Text(
                                        text = pl.description,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            IconButton(onClick = { activeDetailPlaylist = pl }) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "View Playlist", tint = EmeraldPrimary)
                            }
                        }
                    }
                }
            }
        }
    }

    // Create Playlist Dialog
    if (showCreateDialog) {
        var name by remember { mutableStateOf("") }
        var desc by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            containerColor = DarkSurfaceElevated,
            title = { Text("New Playlist", color = TextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Playlist Name") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = DarkSurfaceBorder
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = desc,
                        onValueChange = { desc = it },
                        label = { Text("Description (Optional)") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = DarkSurfaceBorder
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (name.isNotBlank()) {
                            onCreatePlaylist(name.trim(), desc.trim(), null)
                            showCreateDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary, contentColor = DarkBackground)
                ) {
                    Text("Create")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
private fun PlaylistDetailView(
    playlist: PlaylistEntity,
    repository: MusicRepository,
    allSongs: List<SongEntity>,
    onBack: () -> Unit,
    onPlaySong: (SongEntity, List<SongEntity>) -> Unit,
    onUpdatePlaylist: (PlaylistEntity, String, String, Uri?, Boolean) -> Unit,
    onDeletePlaylist: (PlaylistEntity) -> Unit,
    onExportPlaylist: (PlaylistEntity, List<SongEntity>, Uri) -> Unit
) {
    val songsState = repository.getSongsForPlaylist(playlist.id).collectAsState(initial = emptyList())
    val songs = songsState.value

    var showMenu by remember { mutableStateOf(false) }
    var showAddSongsDialog by remember { mutableStateOf(false) }
    var showEditDialog by remember { mutableStateOf(false) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            onExportPlaylist(playlist, songs, uri)
        }
    }

    val coverPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onUpdatePlaylist(playlist, playlist.name, playlist.description, uri, false)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        // Top Navigation
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
            }

            Row {
                IconButton(onClick = { showMenu = true }) {
                    Icon(Icons.Default.MoreVert, contentDescription = "More Options", tint = TextPrimary)
                }

                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false },
                    modifier = Modifier.background(DarkSurfaceElevated)
                ) {
                    DropdownMenuItem(
                        text = { Text("Edit Details", color = TextPrimary) },
                        onClick = { showEditDialog = true; showMenu = false },
                        leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, tint = TextSecondary) }
                    )
                    DropdownMenuItem(
                        text = { Text("Change Cover Artwork", color = TextPrimary) },
                        onClick = {
                            coverPickerLauncher.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            showMenu = false
                        },
                        leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, tint = TextSecondary) }
                    )
                    DropdownMenuItem(
                        text = { Text("Export to JSON", color = TextPrimary) },
                        onClick = {
                            val safeName = playlist.name.replace("[^a-zA-Z0-9_-]".toRegex(), "_")
                            exportLauncher.launch("$safeName.json")
                            showMenu = false
                        },
                        leadingIcon = { Icon(Icons.Default.FileUpload, contentDescription = null, tint = EmeraldPrimary) }
                    )
                    DropdownMenuItem(
                        text = { Text("Delete Playlist", color = DarkError) },
                        onClick = { showDeleteDialog = true; showMenu = false },
                        leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = DarkError) }
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Header Info
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ArtworkImage(
                        artworkPath = playlist.customArtworkPath,
                        contentDescription = playlist.name,
                        modifier = Modifier.size(90.dp),
                        shape = RoundedCornerShape(12.dp),
                        iconSize = 36.dp
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = playlist.name,
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        if (playlist.description.isNotBlank()) {
                            Text(
                                text = playlist.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${songs.size} tracks • ${TimeUtils.formatDuration(songs.sumOf { it.durationMs })}",
                            style = MaterialTheme.typography.labelSmall,
                            color = EmeraldPrimary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Play / Shuffle Buttons Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            if (songs.isNotEmpty()) {
                                onPlaySong(songs.first(), songs)
                            }
                        },
                        enabled = songs.isNotEmpty(),
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary, contentColor = DarkBackground),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Play All")
                    }

                    Button(
                        onClick = {
                            if (songs.isNotEmpty()) {
                                val shuffled = songs.shuffled()
                                onPlaySong(shuffled.first(), shuffled)
                            }
                        },
                        enabled = songs.isNotEmpty(),
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated, contentColor = TextPrimary),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Shuffle, contentDescription = null, tint = EmeraldPrimary)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Shuffle")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = { showAddSongsDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceBorder, contentColor = TextPrimary),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Add Songs to Playlist")
                }

                Spacer(modifier = Modifier.height(12.dp))
            }

            // Songs List
            if (songs.isEmpty()) {
                item {
                    Text(
                        "This playlist is empty. Tap Add Songs to Playlist above.",
                        color = TextSecondary,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(vertical = 32.dp)
                    )
                }
            } else {
                itemsIndexed(songs, key = { _, s -> s.id }) { index, song ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(DarkSurfaceElevated)
                            .clickable { onPlaySong(song, songs) }
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ArtworkImage(
                            artworkPath = song.customArtworkPath,
                            contentDescription = null,
                            modifier = Modifier.size(42.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = song.title,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium,
                                color = TextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${song.artist} • ${TimeUtils.formatDuration(song.durationMs)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        // Reorder move up / down buttons
                        IconButton(
                            onClick = {
                                if (index > 0) {
                                    val mutable = songs.toMutableList()
                                    val item = mutable.removeAt(index)
                                    mutable.add(index - 1, item)
                                    coroutineScope.launch(Dispatchers.IO) {
                                        repository.reorderPlaylist(playlist.id, mutable.map { it.id })
                                    }
                                }
                            },
                            enabled = index > 0,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Default.ArrowUpward, contentDescription = "Move Up", tint = if (index > 0) TextSecondary else Color.DarkGray, modifier = Modifier.size(16.dp))
                        }

                        IconButton(
                            onClick = {
                                if (index < songs.size - 1) {
                                    val mutable = songs.toMutableList()
                                    val item = mutable.removeAt(index)
                                    mutable.add(index + 1, item)
                                    coroutineScope.launch(Dispatchers.IO) {
                                        repository.reorderPlaylist(playlist.id, mutable.map { it.id })
                                    }
                                }
                            },
                            enabled = index < songs.size - 1,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Default.ArrowDownward, contentDescription = "Move Down", tint = if (index < songs.size - 1) TextSecondary else Color.DarkGray, modifier = Modifier.size(16.dp))
                        }

                        IconButton(
                            onClick = {
                                coroutineScope.launch(Dispatchers.IO) {
                                    repository.removeSongFromPlaylist(playlist.id, song.id)
                                }
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Remove from Playlist", tint = DarkError, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }

    // Add Songs from Library to this Playlist Dialog
    if (showAddSongsDialog) {
        val existingSongIds = songs.map { it.id }.toSet()
        val availableSongs = allSongs.filter { it.id !in existingSongIds }

        AlertDialog(
            onDismissRequest = { showAddSongsDialog = false },
            containerColor = DarkSurfaceElevated,
            title = { Text("Add Tracks to \"${playlist.name}\"", color = TextPrimary) },
            text = {
                if (availableSongs.isEmpty()) {
                    Text("All songs in your library are already in this playlist.", color = TextSecondary)
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(260.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(availableSongs, key = { it.id }) { s ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        coroutineScope.launch(Dispatchers.IO) {
                                            repository.addSongToPlaylist(playlist.id, s.id)
                                        }
                                    }
                                    .padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                ArtworkImage(artworkPath = s.customArtworkPath, contentDescription = null, modifier = Modifier.size(36.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(s.title, style = MaterialTheme.typography.bodyMedium, color = TextPrimary, maxLines = 1)
                                    Text(s.artist, style = MaterialTheme.typography.bodySmall, color = TextSecondary, maxLines = 1)
                                }
                                Icon(Icons.Default.Add, contentDescription = "Add", tint = EmeraldPrimary)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showAddSongsDialog = false }, colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary, contentColor = DarkBackground)) {
                    Text("Done")
                }
            }
        )
    }

    // Edit Playlist Dialog
    if (showEditDialog) {
        var newName by remember { mutableStateOf(playlist.name) }
        var newDesc by remember { mutableStateOf(playlist.description) }

        AlertDialog(
            onDismissRequest = { showEditDialog = false },
            containerColor = DarkSurfaceElevated,
            title = { Text("Edit Playlist", color = TextPrimary) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        label = { Text("Name") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = DarkSurfaceBorder
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = newDesc,
                        onValueChange = { newDesc = it },
                        label = { Text("Description") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = DarkSurfaceBorder
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newName.isNotBlank()) {
                            onUpdatePlaylist(playlist, newName.trim(), newDesc.trim(), null, false)
                            showEditDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary, contentColor = DarkBackground)
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }

    // Delete Playlist Dialog
    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            containerColor = DarkSurfaceElevated,
            title = { Text("Delete Playlist?", color = TextPrimary) },
            text = {
                Text("Are you sure you want to delete \"${playlist.name}\"? Songs in this playlist will remain in your library.", color = TextSecondary)
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeletePlaylist(playlist)
                        showDeleteDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DarkError, contentColor = DarkBackground)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            }
        )
    }
}
