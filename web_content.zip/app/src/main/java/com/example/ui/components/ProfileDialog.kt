package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material.icons.filled.TrackChanges
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.UserStats
import com.example.ui.theme.GameAmber
import com.example.ui.theme.GameAmberBright
import com.example.ui.theme.GameDarkBackground
import com.example.ui.theme.GameEmerald
import com.example.ui.theme.GameOrange
import com.example.ui.theme.GameRose
import com.example.ui.theme.GameSurfaceDark
import com.example.ui.theme.GameSurfaceElevated
import com.example.ui.theme.GameViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val AVAILABLE_AVATARS = listOf(
    "🎮", "⚡", "👑", "🚀", "🦊", "🐉",
    "🕵️", "🎯", "👾", "🔥", "🏆", "💎",
    "🦁", "🤖", "🌟", "🎨", "🛸", "🍕"
)

val AVAILABLE_TITLES = listOf(
    "Novice Sleuth",
    "Zoom Detective",
    "Pixel Hunter",
    "Logo Master",
    "Trivia Wizard",
    "Speed Guesser",
    "Grandmaster",
    "Brainiac 3000"
)

val PROFILE_THEMES = listOf(
    "Amber" to Color(0xFFF59E0B),
    "Emerald" to Color(0xFF10B981),
    "Violet" to Color(0xFF8B5CF6),
    "Cyan" to Color(0xFF06B6D4),
    "Rose" to Color(0xFFF43F5E)
)

private val RANDOM_NAMES = listOf(
    "PixelHunter", "NeonRiddle", "CyberSleuth", "ShadowGuesser",
    "VortexSeeker", "LogoLegend", "QuantumGuesser", "AstroMind",
    "TurboSleuth", "MatrixMaster", "EagleEye", "HyperBrain"
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileDialog(
    userStats: UserStats,
    onSaveProfile: (name: String, avatar: String, title: String, theme: String) -> Unit,
    onSaveAllProgress: () -> Unit,
    lastSavedTime: String?,
    onDismiss: () -> Unit
) {
    var editedName by remember(userStats.playerName) { mutableStateOf(userStats.playerName) }
    var selectedAvatar by remember(userStats.avatar) { mutableStateOf(userStats.avatar) }
    var selectedTitle by remember(userStats.playerTitle) { mutableStateOf(userStats.playerTitle) }
    var selectedTheme by remember(userStats.profileTheme) { mutableStateOf(userStats.profileTheme) }
    var isEditingName by remember { mutableStateOf(false) }
    var showSaveMessage by remember { mutableStateOf(false) }

    val focusManager = LocalFocusManager.current
    val scrollState = rememberScrollState()

    val currentThemeColor = PROFILE_THEMES.find { it.first == selectedTheme }?.second ?: GameAmber

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .height(680.dp)
                .testTag("profile_dialog"),
            shape = RoundedCornerShape(24.dp),
            color = GameDarkBackground,
            border = BorderStroke(1.dp, currentThemeColor.copy(alpha = 0.4f))
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(scrollState)
            ) {
                // Header with Close
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = currentThemeColor.copy(alpha = 0.15f),
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Text(
                                text = selectedAvatar,
                                fontSize = 20.sp,
                                modifier = Modifier.padding(6.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "Player Profile",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                color = TextPrimary
                            )
                            Text(
                                text = "Customize Identity & Save Progress",
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("profile_dialog_close")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = TextMuted
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Profile Hero Card with Avatar, Level, XP, Name, Title
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = GameSurfaceDark),
                    border = BorderStroke(1.5.dp, currentThemeColor.copy(alpha = 0.45f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        currentThemeColor.copy(alpha = 0.15f),
                                        GameSurfaceDark
                                    )
                                )
                            )
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Avatar Badge with Glow
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(88.dp)
                                .clip(CircleShape)
                                .background(GameSurfaceElevated)
                                .border(3.dp, currentThemeColor, CircleShape)
                        ) {
                            Text(
                                text = selectedAvatar,
                                fontSize = 46.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Player Name (Editable or Display)
                        if (isEditingName) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth(0.9f)
                            ) {
                                OutlinedTextField(
                                    value = editedName,
                                    onValueChange = { if (it.length <= 16) editedName = it },
                                    singleLine = true,
                                    placeholder = { Text("Enter name", color = TextMuted) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("profile_name_input"),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary,
                                        focusedBorderColor = currentThemeColor,
                                        unfocusedBorderColor = Color(0xFF334155),
                                        focusedContainerColor = GameDarkBackground,
                                        unfocusedContainerColor = GameDarkBackground
                                    ),
                                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                                    keyboardActions = KeyboardActions(onDone = {
                                        if (editedName.isNotBlank()) {
                                            isEditingName = false
                                            focusManager.clearFocus()
                                            onSaveProfile(editedName.trim(), selectedAvatar, selectedTitle, selectedTheme)
                                        }
                                    })
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                IconButton(
                                    onClick = {
                                        editedName = RANDOM_NAMES.random()
                                    },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Shuffle,
                                        contentDescription = "Random name",
                                        tint = currentThemeColor
                                    )
                                }
                                IconButton(
                                    onClick = {
                                        if (editedName.isNotBlank()) {
                                            isEditingName = false
                                            focusManager.clearFocus()
                                            onSaveProfile(editedName.trim(), selectedAvatar, selectedTitle, selectedTheme)
                                        }
                                    },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Confirm name",
                                        tint = GameEmerald
                                    )
                                }
                            }
                        } else {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = editedName.ifBlank { userStats.playerName },
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Black,
                                    color = TextPrimary
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .clickable { isEditingName = true }
                                        .testTag("profile_edit_name_btn"),
                                    color = currentThemeColor.copy(alpha = 0.2f)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "Edit name",
                                        tint = currentThemeColor,
                                        modifier = Modifier
                                            .padding(6.dp)
                                            .size(14.dp)
                                    )
                                }
                            }
                        }

                        // Player Title
                        Text(
                            text = selectedTitle,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = currentThemeColor,
                            modifier = Modifier.padding(top = 2.dp)
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Level & XP Bar Section
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = GameDarkBackground.copy(alpha = 0.8f),
                            border = BorderStroke(1.dp, Color(0xFF1E293B)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.MilitaryTech,
                                            contentDescription = "Level",
                                            tint = currentThemeColor,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "Rank Level ${userStats.playerRankLevel}",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Black,
                                            color = TextPrimary
                                        )
                                    }
                                    Text(
                                        text = "${userStats.totalXp} Total XP",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = currentThemeColor
                                    )
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                // XP Progress bar
                                LinearProgressIndicator(
                                    progress = { userStats.xpProgress },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(10.dp)
                                        .clip(RoundedCornerShape(6.dp)),
                                    color = currentThemeColor,
                                    trackColor = Color(0xFF1E293B)
                                )

                                Spacer(modifier = Modifier.height(4.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${userStats.currentLevelXp} / ${userStats.nextLevelXpRequired} XP to next level",
                                        fontSize = 10.sp,
                                        color = TextMuted
                                    )
                                    Text(
                                        text = "${(userStats.xpProgress * 100).toInt()}%",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // SAVE GAME PROGRESS BUTTON & STATUS (PROMINENT)
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0F1E2E)),
                    border = BorderStroke(1.dp, GameEmerald.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Saved",
                                    tint = GameEmerald,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(
                                        text = "Game Progress Storage",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Color.White
                                    )
                                    Text(
                                        text = if (lastSavedTime != null) "Last saved at $lastSavedTime" else "All levels, XP, & scores auto-saved",
                                        fontSize = 10.sp,
                                        color = GameEmerald
                                    )
                                }
                            }

                            Button(
                                onClick = {
                                    onSaveAllProgress()
                                    showSaveMessage = true
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = GameEmerald,
                                    contentColor = Color.Black
                                ),
                                modifier = Modifier.testTag("save_progress_now_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Save,
                                    contentDescription = "Save Now",
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Save Now",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        AnimatedVisibility(
                            visible = showSaveMessage,
                            enter = fadeIn(),
                            exit = fadeOut()
                        ) {
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 10.dp),
                                shape = RoundedCornerShape(10.dp),
                                color = GameEmerald.copy(alpha = 0.15f),
                                border = BorderStroke(1.dp, GameEmerald.copy(alpha = 0.3f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Success",
                                        tint = GameEmerald,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "All game progress safely synced to persistent storage!",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = GameEmerald
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Stats Overview Grid (Score, Level, Accuracy, Streaks, etc.)
                Text(
                    text = "Player Statistics",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatMetricCard(
                        title = "Game Level",
                        value = "Lvl ${userStats.currentLevel} / ${userStats.unlockedLevels.size}",
                        subValue = "${userStats.solvedIds.size} Puzzles Solved",
                        icon = Icons.Default.Stars,
                        iconColor = currentThemeColor,
                        modifier = Modifier.weight(1f)
                    )
                    StatMetricCard(
                        title = "Total Score",
                        value = "${userStats.score}",
                        subValue = "${userStats.coins} Coins",
                        icon = Icons.Default.MonetizationOn,
                        iconColor = GameAmberBright,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val accuracy = if (userStats.totalGuesses > 0) {
                        (userStats.correctGuesses * 100) / userStats.totalGuesses
                    } else 100

                    StatMetricCard(
                        title = "Accuracy",
                        value = "$accuracy%",
                        subValue = "${userStats.correctGuesses} of ${userStats.totalGuesses} hits",
                        icon = Icons.Default.TrackChanges,
                        iconColor = GameEmerald,
                        modifier = Modifier.weight(1f)
                    )
                    StatMetricCard(
                        title = "Daily Streak",
                        value = "${userStats.dailyStreak} Days",
                        subValue = "Best: ${userStats.highestDailyStreak} days",
                        icon = Icons.Default.LocalFireDepartment,
                        iconColor = GameOrange,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Customize Avatar Section
                Text(
                    text = "Choose Avatar",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(8.dp))

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AVAILABLE_AVATARS.forEach { avatar ->
                        val isSelected = avatar == selectedAvatar
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) currentThemeColor.copy(alpha = 0.25f) else GameSurfaceDark,
                            border = BorderStroke(
                                if (isSelected) 2.dp else 1.dp,
                                if (isSelected) currentThemeColor else Color(0xFF26334D)
                            ),
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .clickable {
                                    selectedAvatar = avatar
                                    onSaveProfile(editedName.trim(), avatar, selectedTitle, selectedTheme)
                                }
                                .testTag("avatar_option_$avatar")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(text = avatar, fontSize = 22.sp)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Customize Title Section
                Text(
                    text = "Select Title",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(8.dp))

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    AVAILABLE_TITLES.forEach { title ->
                        val isSelected = title == selectedTitle
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = if (isSelected) currentThemeColor.copy(alpha = 0.2f) else GameSurfaceDark,
                            border = BorderStroke(
                                1.dp,
                                if (isSelected) currentThemeColor else Color(0xFF26334D)
                            ),
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .clickable {
                                    selectedTitle = title
                                    onSaveProfile(editedName.trim(), selectedAvatar, title, selectedTheme)
                                }
                        ) {
                            Text(
                                text = title,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Black else FontWeight.Normal,
                                color = if (isSelected) currentThemeColor else TextSecondary,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Profile Theme Color Section
                Text(
                    text = "Profile Theme Accent",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    PROFILE_THEMES.forEach { (name, color) ->
                        val isSelected = name == selectedTheme
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = color.copy(alpha = 0.2f),
                            border = BorderStroke(
                                if (isSelected) 2.5.dp else 1.dp,
                                if (isSelected) color else color.copy(alpha = 0.4f)
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .clickable {
                                    selectedTheme = name
                                    onSaveProfile(editedName.trim(), selectedAvatar, selectedTitle, name)
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(12.dp)
                                        .clip(CircleShape)
                                        .background(color)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = name,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Black else FontWeight.Medium,
                                    color = if (isSelected) Color.White else TextMuted
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Google AdMob Monetization & Bank Withdrawal Info
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF0F172A),
                    border = BorderStroke(1.dp, GameAmber.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.MonetizationOn,
                                contentDescription = null,
                                tint = GameAmberBright,
                                modifier = Modifier.size(22.dp)
                            )
                            Column {
                                Text(
                                    text = "Google AdMob Monetization",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                                Text(
                                    text = "Account: hazimqadir7@gmail.com",
                                    fontSize = 11.sp,
                                    color = GameAmberBright,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "• Rewarded Ads: Active for Hint, Reveal Letter, Remove 3 Wrong, and Bonus Coins.\n" +
                                   "• AdMob Status: Configured with official Google Play Services Ads SDK.\n" +
                                   "• Bank Withdrawal: Log in to admob.google.com with hazimqadir7@gmail.com -> Payments -> Add Payment Method (Wire transfer / Direct Bank Deposit) to withdraw your monthly earnings.",
                            fontSize = 11.sp,
                            lineHeight = 16.sp,
                            color = TextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Done Button
                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("profile_done_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = currentThemeColor,
                        contentColor = Color.Black
                    )
                ) {
                    Text(
                        text = "Done & Keep Playing",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }
    }
}

@Composable
fun StatMetricCard(
    title: String,
    value: String,
    subValue: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = GameSurfaceDark,
        border = BorderStroke(1.dp, Color(0xFF26334D)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title,
                    fontSize = 11.sp,
                    color = TextMuted,
                    fontWeight = FontWeight.Medium
                )
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = iconColor,
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                fontSize = 16.sp,
                fontWeight = FontWeight.Black,
                color = TextPrimary
            )
            Text(
                text = subValue,
                fontSize = 10.sp,
                color = TextSecondary
            )
        }
    }
}
