package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.local.DocumentEntity
import com.example.data.local.PaymentEntity
import com.example.data.model.BookingWithDetails
import com.example.data.model.ClientWithBookings
import com.example.data.model.DocumentType
import com.example.data.repository.SaveResult
import com.example.ui.components.AttachDocumentDialog
import com.example.ui.components.ConfirmDeleteDialog
import com.example.ui.components.SdTopAppBar
import com.example.ui.components.SectionHeaderCard
import com.example.ui.components.StatusBadge
import com.example.ui.components.ZoomableImageDialog
import com.example.ui.theme.BackgroundWhite
import com.example.ui.theme.BorderLight
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.GoldSecondary
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.StatusCancelledFg
import com.example.ui.theme.StatusConfirmedFg
import com.example.ui.theme.StatusPendingFg
import com.example.ui.theme.SurfaceLightGray
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainViewModel
import com.example.utils.CurrencyFormatters
import java.io.File

@Composable
fun ClientDetailScreen(
    clientId: Long,
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onAddBookingForClient: (Long) -> Unit,
) {
    val context = LocalContext.current
    val clientWithBookings by viewModel.observeClient(clientId)
        .collectAsStateWithLifecycle(initialValue = null)

    var selectedBookingId by remember { mutableStateOf<Long?>(null) }
    var showEditClient by remember { mutableStateOf(false) }
    var editClientError by remember { mutableStateOf<String?>(null) }
    var showEditBooking by remember { mutableStateOf(false) }
    var showDeleteBookingConfirm by remember { mutableStateOf(false) }
    var editingPayment by remember { mutableStateOf<PaymentEntity?>(null) }
    var showNewPaymentDialog by remember { mutableStateOf(false) }

    var showAttachDialog by remember { mutableStateOf(false) }
    var replacingDocument by remember { mutableStateOf<DocumentEntity?>(null) }
    var pendingDocType by remember { mutableStateOf(DocumentType.PASSPORT) }
    var pendingDocTitle by remember { mutableStateOf("") }
    var activeCameraFile by remember { mutableStateOf<File?>(null) }
    var zoomDocument by remember { mutableStateOf<DocumentEntity?>(null) }

    val activeBooking: BookingWithDetails? = remember(clientWithBookings, selectedBookingId) {
        val list = clientWithBookings?.bookings.orEmpty()
        list.firstOrNull { it.booking.id == selectedBookingId } ?: list.maxByOrNull { it.booking.createdAt }
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val toReplace = replacingDocument
            if (toReplace != null) {
                viewModel.replaceDocumentFromUri(toReplace, uri)
                replacingDocument = null
            } else if (activeBooking != null) {
                viewModel.addDocumentFromUri(activeBooking.booking.id, pendingDocType, pendingDocTitle, uri)
            }
        }
    }

    val takePictureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        val file = activeCameraFile
        if (success && file != null && file.exists()) {
            val toReplace = replacingDocument
            if (toReplace != null) {
                viewModel.replaceDocumentFromFile(toReplace, file)
                replacingDocument = null
            } else if (activeBooking != null) {
                viewModel.addDocumentFromTempFile(activeBooking.booking.id, pendingDocType, pendingDocTitle, file)
            }
        } else {
            file?.delete()
            replacingDocument = null
        }
        activeCameraFile = null
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            val (file, uri) = viewModel.documentStorage.createTempCameraFileAndUri()
            activeCameraFile = file
            takePictureLauncher.launch(uri)
        }
    }

    fun launchCameraFlow() {
        val hasCam = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CAMERA,
        ) == PackageManager.PERMISSION_GRANTED
        if (hasCam) {
            val (file, uri) = viewModel.documentStorage.createTempCameraFileAndUri()
            activeCameraFile = file
            takePictureLauncher.launch(uri)
        } else {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    Scaffold(
        containerColor = SurfaceLightGray,
        topBar = {
            SdTopAppBar(
                title = clientWithBookings?.client?.fullName ?: "ملف العميل",
                subtitle = clientWithBookings?.let { "كود العميل: ${it.client.clientCode}" },
                onBack = onBack,
                actions = {
                    if (clientWithBookings != null) {
                        IconButton(
                            onClick = {
                                viewModel.prepareClientPrint(clientWithBookings!!, activeBooking)
                            },
                            modifier = Modifier.testTag("print_client_button"),
                        ) {
                            Icon(Icons.Default.Print, contentDescription = "طباعة بيانات العميل")
                        }
                        IconButton(
                            onClick = {
                                val summary = buildShareText(clientWithBookings!!, activeBooking)
                                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_SUBJECT, "بيانات حجز العمرة - ${clientWithBookings!!.client.fullName}")
                                    putExtra(Intent.EXTRA_TEXT, summary)
                                }
                                context.startActivity(Intent.createChooser(sendIntent, "مشاركة بيانات الحجز"))
                            },
                            modifier = Modifier.testTag("share_client_button"),
                        ) {
                            Icon(Icons.Default.Share, contentDescription = "مشاركة بيانات الحجز")
                        }
                    }
                },
            )
        },
    ) { innerPadding ->
        val data = clientWithBookings
        if (data == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center,
            ) {
                Text("جاري تحميل ملف العميل...", color = TextSecondary)
            }
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            // 1. Client Info Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = BackgroundWhite),
                    border = BorderStroke(1.dp, BorderLight),
                    shape = RoundedCornerShape(16.dp),
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            SectionHeaderCard(
                                title = "البيانات الشخصية",
                                icon = Icons.Default.Person,
                                modifier = Modifier.weight(1f),
                            )
                            OutlinedButton(
                                onClick = {
                                    editClientError = null
                                    showEditClient = true
                                },
                                modifier = Modifier.testTag("edit_client_button"),
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("تعديل")
                            }
                        }

                        InfoRow("كود العميل", data.client.clientCode)
                        InfoRow("الاسم الكامل", data.client.fullName)
                        InfoRow("رقم الهاتف", data.client.phone.ifBlank { "-" })
                        InfoRow("رقم الواتساب", data.client.whatsapp.ifBlank { "-" })
                        InfoRow("رقم البطاقة", data.client.nationalId.ifBlank { "-" })
                        InfoRow("رقم الجواز", data.client.passportNumber.ifBlank { "-" })
                        InfoRow("تاريخ الميلاد", data.client.birthDate.ifBlank { "-" })
                        if (data.client.notes.isNotBlank()) {
                            InfoRow("ملاحظات", data.client.notes)
                        }
                    }
                }
            }

            // Booking Selector + Add Another Booking
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        data.bookings.forEachIndexed { idx, b ->
                            val isSelected = activeBooking?.booking?.id == b.booking.id
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedBookingId = b.booking.id },
                                label = { Text("حجز ${idx + 1}: ${b.booking.tripDate}") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = NavyPrimary,
                                    selectedLabelColor = GoldSecondary,
                                ),
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedButton(
                        onClick = { onAddBookingForClient(data.client.id) },
                        border = BorderStroke(1.dp, NavyPrimary),
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Text("حجز إضافي")
                    }
                }
            }

            if (activeBooking != null) {
                val b = activeBooking.booking

                // 2. Trip Details Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = BackgroundWhite),
                        border = BorderStroke(1.dp, BorderLight),
                        shape = RoundedCornerShape(16.dp),
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                SectionHeaderCard(
                                    title = "بيانات الرحلة والحجز",
                                    icon = Icons.Default.Flight,
                                    modifier = Modifier.weight(1f),
                                )
                                StatusBadge(status = b.status)
                            }

                            InfoRow("تاريخ الرحلة", b.tripDate)
                            InfoRow("تاريخ العودة", b.returnDate.ifBlank { "-" })
                            val programName = if (b.customTripLabel.isNotBlank()) {
                                "${b.tripType.arabicLabel} (${b.customTripLabel})"
                            } else {
                                b.tripType.arabicLabel
                            }
                            InfoRow("نوع الرحلة", programName)
                            InfoRow("شركة السياحة", b.companyName.ifBlank { "-" })
                            InfoRow("فندق مكة", b.makkahHotel.ifBlank { "-" })
                            InfoRow("فندق المدينة", b.madinahHotel.ifBlank { "-" })
                            if (b.notes.isNotBlank()) {
                                InfoRow("ملاحظات الحجز", b.notes)
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                OutlinedButton(
                                    onClick = { showEditBooking = true },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("edit_booking_button"),
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("تعديل الرحلة")
                                }
                                OutlinedButton(
                                    onClick = { showDeleteBookingConfirm = true },
                                    border = BorderStroke(1.dp, StatusCancelledFg.copy(alpha = 0.6f)),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("delete_booking_button"),
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = null, tint = StatusCancelledFg, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("حذف الحجز", color = StatusCancelledFg)
                                }
                            }
                        }
                    }
                }

                // 3. Financial Summary Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = BackgroundWhite),
                        border = BorderStroke(1.5.dp, GoldSecondary),
                        shape = RoundedCornerShape(16.dp),
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            SectionHeaderCard(
                                title = "الحسابات والملخص المالي",
                                icon = Icons.Default.AccountBalanceWallet,
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                FinancialPill(
                                    label = "سعر الرحلة",
                                    value = CurrencyFormatters.formatMoney(b.totalPrice),
                                    modifier = Modifier.weight(1f),
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                FinancialPill(
                                    label = "الإضافات",
                                    value = CurrencyFormatters.formatMoney(b.extraAmount),
                                    modifier = Modifier.weight(1f),
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                            ) {
                                FinancialPill(
                                    label = "إجمالي المدفوع",
                                    value = CurrencyFormatters.formatMoney(activeBooking.totalPaid),
                                    valueColor = StatusConfirmedFg,
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("detail_total_paid"),
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                FinancialPill(
                                    label = "المبلغ المتبقي",
                                    value = CurrencyFormatters.formatMoney(activeBooking.remainingAmount),
                                    valueColor = if (activeBooking.remainingAmount > 0) StatusPendingFg else StatusConfirmedFg,
                                    highlight = true,
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("detail_remaining_amount"),
                                )
                            }
                        }
                    }
                }

                // 4. Payments Ledger Card
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = BackgroundWhite),
                        border = BorderStroke(1.dp, BorderLight),
                        shape = RoundedCornerShape(16.dp),
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                SectionHeaderCard(
                                    title = "سجل المدفوعات (${activeBooking.payments.size})",
                                    icon = Icons.Default.Payments,
                                    modifier = Modifier.weight(1f),
                                )
                                Button(
                                    onClick = { showNewPaymentDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                                    modifier = Modifier.testTag("add_payment_button"),
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("إضافة دفعة")
                                }
                            }

                            if (activeBooking.payments.isEmpty()) {
                                Text(
                                    text = "لا توجد دفعات مسجلة لهذا الحجز حتى الآن.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary,
                                )
                            } else {
                                activeBooking.payments.forEach { p ->
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = SurfaceLightGray,
                                        border = BorderStroke(1.dp, BorderLight),
                                        modifier = Modifier.fillMaxWidth(),
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(10.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = "${CurrencyFormatters.formatMoney(p.amount)} • ${p.paymentMethod.arabicLabel}${if (p.isDeposit) " (مقدم)" else ""}",
                                                    style = MaterialTheme.typography.titleSmall,
                                                    color = NavyPrimary,
                                                    fontWeight = FontWeight.Bold,
                                                )
                                                Text(
                                                    text = "التاريخ: ${p.paymentDate}${if (p.notes.isNotBlank()) " • ${p.notes}" else ""}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = TextSecondary,
                                                )
                                            }
                                            IconButton(onClick = { editingPayment = p }) {
                                                Icon(Icons.Default.Edit, contentDescription = "تعديل الدفعة", tint = NavyPrimary)
                                            }
                                            IconButton(onClick = { viewModel.deletePayment(p.id) }) {
                                                Icon(Icons.Default.Delete, contentDescription = "حذف الدفعة", tint = StatusCancelledFg)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 5. Documents & Photos Gallery
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = BackgroundWhite),
                        border = BorderStroke(1.dp, BorderLight),
                        shape = RoundedCornerShape(16.dp),
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                SectionHeaderCard(
                                    title = "المستندات والصور (${activeBooking.documents.size})",
                                    icon = Icons.Default.AttachFile,
                                    modifier = Modifier.weight(1f),
                                )
                                Button(
                                    onClick = {
                                        replacingDocument = null
                                        showAttachDialog = true
                                    },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = GoldSecondary,
                                        contentColor = NavyPrimary,
                                    ),
                                    modifier = Modifier.testTag("detail_add_document_button"),
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("إرفاق مستند", fontWeight = FontWeight.Bold)
                                }
                            }

                            if (activeBooking.documents.isEmpty()) {
                                Text(
                                    text = "لم يتم إرفاق صور مستندات بعد. يمكنك إضافة جواز السفر، البطاقة، التأشيرة، التذكرة، أو إيصالات الدفع.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary,
                                )
                            } else {
                                activeBooking.documents.forEach { doc ->
                                    val file = viewModel.documentStorage.resolveFile(doc.relativePath)
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = SurfaceLightGray,
                                        border = BorderStroke(1.dp, BorderLight),
                                        modifier = Modifier.fillMaxWidth(),
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(8.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(72.dp)
                                                    .clip(RoundedCornerShape(10.dp))
                                                    .border(1.dp, BorderLight, RoundedCornerShape(10.dp))
                                                    .clickable { zoomDocument = doc },
                                            ) {
                                                AsyncImage(
                                                    model = file,
                                                    contentDescription = doc.docType.arabicLabel,
                                                    contentScale = ContentScale.Crop,
                                                    modifier = Modifier.fillMaxSize(),
                                                )
                                                Box(
                                                    modifier = Modifier
                                                        .align(Alignment.BottomEnd)
                                                        .padding(4.dp)
                                                        .clip(RoundedCornerShape(6.dp))
                                                        .background(NavyPrimary.copy(alpha = 0.78f))
                                                        .padding(3.dp),
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.ZoomIn,
                                                        contentDescription = "تكبير",
                                                        tint = GoldSecondary,
                                                        modifier = Modifier.size(14.dp),
                                                    )
                                                }
                                            }
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = doc.docType.arabicLabel,
                                                    style = MaterialTheme.typography.titleSmall,
                                                    color = NavyPrimary,
                                                    fontWeight = FontWeight.Bold,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                )
                                                if (doc.title.isNotBlank()) {
                                                    Text(
                                                        text = doc.title,
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = TextSecondary,
                                                    )
                                                }
                                                Text(
                                                    text = "اضغط على الصورة للتكبير",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = TextSecondary,
                                                )
                                            }
                                            IconButton(
                                                onClick = {
                                                    replacingDocument = doc
                                                    showAttachDialog = true
                                                },
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.SwapHoriz,
                                                    contentDescription = "استبدال الصورة",
                                                    tint = NavyPrimary,
                                                )
                                            }
                                            IconButton(
                                                onClick = { viewModel.deleteDocument(doc) },
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Delete,
                                                    contentDescription = "حذف الصورة",
                                                    tint = StatusCancelledFg,
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Export / Print Quick Buttons Footer
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Button(
                            onClick = { viewModel.exportClientPdfForShare(data, activeBooking) },
                            colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp),
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("مشاركة كـ PDF")
                        }
                        OutlinedButton(
                            onClick = { viewModel.prepareClientPrint(data, activeBooking) },
                            border = BorderStroke(1.dp, NavyPrimary),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp),
                        ) {
                            Icon(Icons.Default.Print, contentDescription = null, tint = NavyPrimary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("طباعة الملف", color = NavyPrimary, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Dialogs
    if (showEditClient && clientWithBookings != null) {
        EditClientDialog(
            client = clientWithBookings!!.client,
            errorMessage = editClientError,
            onSave = { updated ->
                viewModel.updateClient(updated) { res ->
                    when (res) {
                        is SaveResult.Success -> {
                            editClientError = null
                            showEditClient = false
                        }
                        is SaveResult.ValidationError -> editClientError = res.message
                    }
                }
            },
            onDismiss = { showEditClient = false },
        )
    }

    if (showEditBooking && activeBooking != null) {
        EditBookingDialog(
            booking = activeBooking.booking,
            onSave = { updated ->
                viewModel.updateBooking(updated)
                showEditBooking = false
            },
            onDismiss = { showEditBooking = false },
        )
    }

    if (showDeleteBookingConfirm && activeBooking != null) {
        val isOnlyBooking = (clientWithBookings?.bookings?.size ?: 0) <= 1
        ConfirmDeleteDialog(
            title = "تأكيد حذف الحجز",
            message = if (isOnlyBooking) {
                "هذا هو الحجز الوحيد للعميل. سيتم حذف الحجز وجميع مدفوعاته وصوره نهائيًا، هل تريد المتابعة؟"
            } else {
                "هل أنت متأكد من حذف هذا الحجز وجميع مدفوعاته ومستنداته؟"
            },
            onConfirm = {
                showDeleteBookingConfirm = false
                if (isOnlyBooking && clientWithBookings != null) {
                    viewModel.deleteClient(clientWithBookings!!.client.id, onDeleted = onBack)
                } else {
                    viewModel.deleteBooking(activeBooking.booking.id)
                }
            },
            onDismiss = { showDeleteBookingConfirm = false },
        )
    }

    if (showNewPaymentDialog && activeBooking != null) {
        PaymentEditorDialog(
            bookingId = activeBooking.booking.id,
            existingPayment = null,
            onSave = { p ->
                viewModel.addPayment(p)
                showNewPaymentDialog = false
            },
            onDismiss = { showNewPaymentDialog = false },
        )
    }

    if (editingPayment != null && activeBooking != null) {
        PaymentEditorDialog(
            bookingId = activeBooking.booking.id,
            existingPayment = editingPayment,
            onSave = { p ->
                viewModel.updatePayment(p)
                editingPayment = null
            },
            onDismiss = { editingPayment = null },
        )
    }

    if (showAttachDialog) {
        AttachDocumentDialog(
            showTypeSelector = replacingDocument == null,
            onPickGallery = { type, title ->
                pendingDocType = type
                pendingDocTitle = title
                showAttachDialog = false
                photoPickerLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                )
            },
            onCaptureCamera = { type, title ->
                pendingDocType = type
                pendingDocTitle = title
                showAttachDialog = false
                launchCameraFlow()
            },
            onDismiss = {
                showAttachDialog = false
                replacingDocument = null
            },
        )
    }

    if (zoomDocument != null) {
        val file = viewModel.documentStorage.resolveFile(zoomDocument!!.relativePath)
        ZoomableImageDialog(
            imageFile = file,
            title = zoomDocument!!.docType.arabicLabel,
            onDismiss = { zoomDocument = null },
        )
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                modifier = Modifier.weight(0.42f),
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium,
                color = TextPrimary,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(0.58f),
            )
        }
        HorizontalDivider(color = BorderLight.copy(alpha = 0.55f))
    }
}

@Composable
private fun FinancialPill(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    valueColor: androidx.compose.ui.graphics.Color = NavyPrimary,
    highlight: Boolean = false,
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        color = if (highlight) GoldContainer else SurfaceLightGray,
        border = BorderStroke(1.dp, if (highlight) GoldSecondary else BorderLight),
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Text(text = label, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                color = valueColor,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

private fun buildShareText(
    clientWithBookings: ClientWithBookings,
    bookingWithDetails: BookingWithDetails?,
): String = buildString {
    val c = clientWithBookings.client
    appendLine("SD TRAVEL - بيانات حجز العمرة")
    appendLine("----------------------------")
    appendLine("كود العميل: ${c.clientCode}")
    appendLine("الاسم: ${c.fullName}")
    appendLine("الهاتف: ${c.phone}")
    if (c.passportNumber.isNotBlank()) appendLine("رقم الجواز: ${c.passportNumber}")
    if (bookingWithDetails != null) {
        val b = bookingWithDetails.booking
        appendLine("تاريخ الرحلة: ${b.tripDate}")
        if (b.returnDate.isNotBlank()) appendLine("تاريخ العودة: ${b.returnDate}")
        appendLine("البرنامج: ${b.tripType.arabicLabel}")
        if (b.companyName.isNotBlank()) appendLine("شركة السياحة: ${b.companyName}")
        if (b.makkahHotel.isNotBlank()) appendLine("فندق مكة: ${b.makkahHotel}")
        if (b.madinahHotel.isNotBlank()) appendLine("فندق المدينة: ${b.madinahHotel}")
        appendLine("الحالة: ${b.status.arabicLabel}")
        appendLine("----------------------------")
        appendLine("إجمالي المستحق: ${CurrencyFormatters.formatMoney(bookingWithDetails.totalDue)}")
        appendLine("إجمالي المدفوع: ${CurrencyFormatters.formatMoney(bookingWithDetails.totalPaid)}")
        appendLine("المبلغ المتبقي: ${CurrencyFormatters.formatMoney(bookingWithDetails.remainingAmount)}")
    }
}
