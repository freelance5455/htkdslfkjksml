package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.OperatingMode
import com.example.model.SignalPhase
import com.example.model.TrafficConfig
import com.example.ui.theme.TrafficGreen
import com.example.ui.theme.TrafficRed
import com.example.ui.theme.TrafficYellow

@Composable
fun TrafficControlPanel(
    currentPhase: SignalPhase,
    secondsRemaining: Int,
    operatingMode: OperatingMode,
    isPaused: Boolean,
    config: TrafficConfig,
    onModeChange: (OperatingMode) -> Unit,
    onTogglePause: () -> Unit,
    onManualPhaseSelect: (SignalPhase) -> Unit,
    onNextPhase: () -> Unit,
    onOpenSettings: () -> Unit,
    onToggleSound: () -> Unit,
    onToggleVibrate: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = Color(0xFF161C26),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF2E394C)),
        shadowElevation = 8.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Mode Selector Tabs (Chips)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "وضع التشغيل:",
                    style = MaterialTheme.typography.titleSmall,
                    color = Color.LightGray,
                    fontWeight = FontWeight.Bold
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    // Sound Quick Toggle
                    IconButton(
                        onClick = onToggleSound,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(if (config.soundEnabled) Color(0xFF263345) else Color(0xFF1A202A))
                            .testTag("btn_toggle_sound")
                    ) {
                        Icon(
                            imageVector = if (config.soundEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeMute,
                            contentDescription = "تبديل الصوت",
                            tint = if (config.soundEnabled) TrafficGreen else Color.Gray,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Vibrate Quick Toggle
                    IconButton(
                        onClick = onToggleVibrate,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(if (config.vibrationEnabled) Color(0xFF263345) else Color(0xFF1A202A))
                            .testTag("btn_toggle_vibrate")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Vibration,
                            contentDescription = "تبديل الاهتزاز",
                            tint = if (config.vibrationEnabled) TrafficGreen else Color.Gray,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Settings Dialog Trigger
                    IconButton(
                        onClick = onOpenSettings,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF263345))
                            .testTag("btn_open_settings")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "إعدادات التوقيت",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // Segmented Mode Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Auto Mode Chip
                FilterChip(
                    selected = operatingMode == OperatingMode.AUTOMATIC,
                    onClick = { onModeChange(OperatingMode.AUTOMATIC) },
                    label = { Text("تلقائي", fontSize = 13.sp) },
                    leadingIcon = {
                        Icon(Icons.Default.HourglassBottom, contentDescription = null, modifier = Modifier.size(16.dp))
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFF1976D2),
                        selectedLabelColor = Color.White,
                        containerColor = Color(0xFF1F2735),
                        labelColor = Color.LightGray
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chip_mode_auto")
                )

                // Manual Mode Chip
                FilterChip(
                    selected = operatingMode == OperatingMode.MANUAL,
                    onClick = { onModeChange(OperatingMode.MANUAL) },
                    label = { Text("يدوي", fontSize = 13.sp) },
                    leadingIcon = {
                        Icon(Icons.Default.TouchApp, contentDescription = null, modifier = Modifier.size(16.dp))
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFF7B1FA2),
                        selectedLabelColor = Color.White,
                        containerColor = Color(0xFF1F2735),
                        labelColor = Color.LightGray
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chip_mode_manual")
                )

                // Night Flash Chip
                FilterChip(
                    selected = operatingMode == OperatingMode.NIGHT_FLASH,
                    onClick = { onModeChange(OperatingMode.NIGHT_FLASH) },
                    label = { Text("وميض", fontSize = 13.sp) },
                    leadingIcon = {
                        Icon(Icons.Default.FlashOn, contentDescription = null, modifier = Modifier.size(16.dp))
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFFE65100),
                        selectedLabelColor = Color.White,
                        containerColor = Color(0xFF1F2735),
                        labelColor = Color.LightGray
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chip_mode_flash")
                )
            }

            // Controls for AUTOMATIC mode
            AnimatedVisibility(visible = operatingMode == OperatingMode.AUTOMATIC) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onTogglePause,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isPaused) Color(0xFF2E7D32) else Color(0xFFC62828),
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_toggle_pause")
                    ) {
                        Icon(
                            imageVector = if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (isPaused) "استئناف التوقيت" else "إيقاف مؤقت")
                    }

                    Button(
                        onClick = onNextPhase,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF283549),
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_auto_next")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipNext,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("الطور التالي")
                    }
                }
            }

            // Controls for MANUAL mode
            AnimatedVisibility(visible = operatingMode == OperatingMode.MANUAL) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "اختر الإشارة المراد إضاءتها فوراً:",
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.Gray
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onManualPhaseSelect(SignalPhase.RED) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (currentPhase == SignalPhase.RED) TrafficRed else Color(0xFF381015),
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_manual_red")
                        ) {
                            Text("أحمر", fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { onManualPhaseSelect(SignalPhase.YELLOW) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (currentPhase == SignalPhase.YELLOW) TrafficYellow else Color(0xFF3B2F08),
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_manual_yellow")
                        ) {
                            Text("أصفر", fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { onManualPhaseSelect(SignalPhase.GREEN) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (currentPhase == SignalPhase.GREEN) TrafficGreen else Color(0xFF093318),
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_manual_green")
                        ) {
                            Text("أخضر", fontWeight = FontWeight.Bold)
                        }
                    }

                    Button(
                        onClick = onNextPhase,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF2A364A),
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("btn_manual_next")
                    ) {
                        Icon(Icons.Default.SkipNext, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("التبديل للمرحلة التالية بالترتيب")
                    }
                }
            }

            // Controls for NIGHT_FLASH mode
            AnimatedVisibility(visible = operatingMode == OperatingMode.NIGHT_FLASH) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { onManualPhaseSelect(SignalPhase.FLASHING_YELLOW) },
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (currentPhase == SignalPhase.FLASHING_YELLOW) Color(0xFF422E06) else Color.Transparent,
                            contentColor = TrafficYellow
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("وميض أصفر (تحذير)", fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = { onManualPhaseSelect(SignalPhase.FLASHING_RED) },
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (currentPhase == SignalPhase.FLASHING_RED) Color(0xFF381015) else Color.Transparent,
                            contentColor = TrafficRed
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("وميض أحمر (قف)", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
