package com.example.ui

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.ImportProgress
import com.example.data.MusicFileManager
import com.example.data.MusicRepository
import com.example.data.PlaylistImportSummary
import com.example.data.PlaylistTransferManager
import com.example.data.StorageStats
import com.example.data.model.PlaylistEntity
import com.example.data.model.SongEntity
import com.example.playback.MusicPlaybackController
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class SortOption {
    TITLE,
    ARTIST,
    ALBUM,
    DATE_ADDED,
    PLAY_COUNT
}

enum class LibraryFilter {
    ALL,
    FAVORITES,
    RECENTLY_ADDED
}

class MusicViewModel(
    private val repository: MusicRepository,
    private val fileManager: MusicFileManager,
    private val playlistTransferManager: PlaylistTransferManager,
    val playbackController: MusicPlaybackController
) : ViewModel() {

    val allSongs = repository.allSongs.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val favoriteSongs = repository.favoriteSongs.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val recentlyPlayedSongs = repository.recentlyPlayedSongs.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val recentlyAddedSongs = repository.recentlyAddedSongs.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val playlists = repository.allPlaylists.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Search and Filtering
    val searchQuery = MutableStateFlow("")
    val sortOption = MutableStateFlow(SortOption.TITLE)
    val sortAscending = MutableStateFlow(true)
    val libraryFilter = MutableStateFlow(LibraryFilter.ALL)

    // Multi-Select
    val isMultiSelectMode = MutableStateFlow(false)
    val selectedSongIds = MutableStateFlow<Set<Long>>(emptySet())

    // Import status
    val isImporting = MutableStateFlow(false)
    val importProgress = MutableStateFlow<ImportProgress?>(null)
    val snackbarMessage = MutableStateFlow<String?>(null)

    // Storage info
    val storageStats = MutableStateFlow<StorageStats?>(null)

    // Filtered & Sorted Library Songs
    val displayedLibrarySongs: StateFlow<List<SongEntity>> = combine(
        allSongs,
        searchQuery,
        sortOption,
        sortAscending,
        libraryFilter
    ) { songs, query, sort, asc, filter ->
        var list = songs

        // Apply tab filter
        list = when (filter) {
            LibraryFilter.ALL -> list
            LibraryFilter.FAVORITES -> list.filter { it.isFavorite }
            LibraryFilter.RECENTLY_ADDED -> list.sortedByDescending { it.dateAddedTimestamp }
        }

        // Apply search query
        if (query.isNotBlank()) {
            val q = query.trim().lowercase()
            list = list.filter {
                it.title.lowercase().contains(q) ||
                it.artist.lowercase().contains(q) ||
                it.album.lowercase().contains(q)
            }
        }

        // Apply sorting
        val comparator: Comparator<SongEntity> = when (sort) {
            SortOption.TITLE -> compareBy(String.CASE_INSENSITIVE_ORDER) { it.title }
            SortOption.ARTIST -> compareBy(String.CASE_INSENSITIVE_ORDER) { it.artist }
            SortOption.ALBUM -> compareBy(String.CASE_INSENSITIVE_ORDER) { it.album }
            SortOption.DATE_ADDED -> compareBy { it.dateAddedTimestamp }
            SortOption.PLAY_COUNT -> compareBy { it.playCount }
        }

        if (asc) list.sortedWith(comparator) else list.sortedWith(comparator.reversed())
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Actions
    fun importAudioFiles(uris: List<Uri>) {
        if (uris.isEmpty()) return
        isImporting.value = true
        viewModelScope.launch {
            val result = fileManager.importAudioFiles(uris) { progress ->
                importProgress.value = progress
            }
            isImporting.value = false
            importProgress.value = null

            val msg = when {
                result.failedCount == 0 && result.duplicateCount == 0 ->
                    "Successfully imported ${result.importedCount} song(s)"
                result.duplicateCount > 0 && result.failedCount == 0 ->
                    "Imported ${result.importedCount} song(s) (${result.duplicateCount} duplicate(s) skipped)"
                else ->
                    "Imported ${result.importedCount} song(s) (${result.duplicateCount} skipped, ${result.failedCount} failed)"
            }
            snackbarMessage.value = msg
            refreshStorageStats()
        }
    }

    fun toggleFavorite(song: SongEntity) {
        viewModelScope.launch {
            val newFav = !song.isFavorite
            repository.toggleFavorite(song.id, newFav)
            val updated = song.copy(isFavorite = newFav)
            playbackController.updateCurrentSongMetadata(updated)
        }
    }

    fun updateSongMetadata(
        songId: Long,
        newTitle: String,
        newArtist: String,
        newAlbum: String,
        newGenre: String,
        newYear: String,
        newArtworkUri: Uri?,
        removeArtwork: Boolean
    ) {
        viewModelScope.launch {
            val existing = repository.getSongById(songId) ?: return@launch
            var artworkPath = existing.customArtworkPath

            if (removeArtwork) {
                fileManager.deleteArtworkFile(artworkPath)
                artworkPath = null
            } else if (newArtworkUri != null) {
                fileManager.deleteArtworkFile(artworkPath)
                artworkPath = fileManager.saveCustomArtwork(newArtworkUri, prefix = "song_$songId")
            }

            val updated = existing.copy(
                title = newTitle.trim().ifEmpty { existing.title },
                artist = newArtist.trim().ifEmpty { existing.artist },
                album = newAlbum.trim().ifEmpty { existing.album },
                genre = newGenre.trim(),
                year = newYear.trim(),
                customArtworkPath = artworkPath
            )
            repository.updateSong(updated)
            playbackController.updateCurrentSongMetadata(updated)
            snackbarMessage.value = "Metadata saved"
        }
    }

    fun removeSongFromLibrary(song: SongEntity) {
        viewModelScope.launch {
            repository.deleteSong(song.id)
            snackbarMessage.value = "Removed \"${song.title}\" from library"
            refreshStorageStats()
        }
    }

    fun removeMultipleSongsFromLibrary(songIds: Set<Long>) {
        viewModelScope.launch {
            repository.deleteSongs(songIds.toList())
            selectedSongIds.value = emptySet()
            isMultiSelectMode.value = false
            snackbarMessage.value = "Removed ${songIds.size} songs from library"
            refreshStorageStats()
        }
    }

    // Playlists
    fun createPlaylist(name: String, description: String = "", customCoverUri: Uri? = null, onCreated: ((Long) -> Unit)? = null) {
        viewModelScope.launch {
            var coverPath: String? = null
            if (customCoverUri != null) {
                coverPath = fileManager.saveCustomArtwork(customCoverUri, prefix = "pl")
            }
            val id = repository.createPlaylist(name, description, coverPath)
            snackbarMessage.value = "Playlist \"$name\" created"
            onCreated?.invoke(id)
        }
    }

    fun updatePlaylist(playlist: PlaylistEntity, newName: String, newDesc: String, newCoverUri: Uri?, removeCover: Boolean) {
        viewModelScope.launch {
            var coverPath = playlist.customArtworkPath
            if (removeCover) {
                fileManager.deleteArtworkFile(coverPath)
                coverPath = null
            } else if (newCoverUri != null) {
                fileManager.deleteArtworkFile(coverPath)
                coverPath = fileManager.saveCustomArtwork(newCoverUri, prefix = "pl_${playlist.id}")
            }
            val updated = playlist.copy(
                name = newName.trim().ifEmpty { playlist.name },
                description = newDesc.trim(),
                customArtworkPath = coverPath
            )
            repository.updatePlaylist(updated)
            snackbarMessage.value = "Playlist updated"
        }
    }

    fun deletePlaylist(playlist: PlaylistEntity) {
        viewModelScope.launch {
            fileManager.deleteArtworkFile(playlist.customArtworkPath)
            repository.deletePlaylist(playlist.id)
            snackbarMessage.value = "Deleted playlist \"${playlist.name}\""
        }
    }

    fun addSongToPlaylist(playlistId: Long, songId: Long) {
        viewModelScope.launch {
            repository.addSongToPlaylist(playlistId, songId)
            snackbarMessage.value = "Added to playlist"
        }
    }

    fun addMultipleSongsToPlaylist(playlistId: Long, songIds: List<Long>) {
        viewModelScope.launch {
            repository.addSongsToPlaylist(playlistId, songIds)
            selectedSongIds.value = emptySet()
            isMultiSelectMode.value = false
            snackbarMessage.value = "Added ${songIds.size} songs to playlist"
        }
    }

    fun removeSongFromPlaylist(playlistId: Long, songId: Long) {
        viewModelScope.launch {
            repository.removeSongFromPlaylist(playlistId, songId)
            snackbarMessage.value = "Removed from playlist"
        }
    }

    fun reorderPlaylistSongs(playlistId: Long, songsInOrder: List<SongEntity>) {
        viewModelScope.launch {
            repository.reorderPlaylist(playlistId, songsInOrder.map { it.id })
        }
    }

    fun exportPlaylist(playlist: PlaylistEntity, songs: List<SongEntity>, destUri: Uri) {
        viewModelScope.launch {
            val success = playlistTransferManager.exportPlaylistToJson(playlist, songs, destUri)
            snackbarMessage.value = if (success) "Exported playlist to JSON" else "Export failed"
        }
    }

    fun importPlaylist(uri: Uri, onResult: (PlaylistImportSummary) -> Unit) {
        viewModelScope.launch {
            val summary = playlistTransferManager.completePlaylistImport(uri)
            onResult(summary)
            snackbarMessage.value = "Imported \"${summary.playlistName}\" (${summary.matchedSongsCount} tracks matched)"
        }
    }

    // Storage Management
    fun refreshStorageStats() {
        viewModelScope.launch {
            val stats = fileManager.getStorageStats(allSongs.value.size)
            storageStats.value = stats
        }
    }

    fun cleanUnusedAudioFiles() {
        viewModelScope.launch {
            val count = fileManager.cleanOrphanedFiles()
            refreshStorageStats()
            snackbarMessage.value = "Cleaned $count unused file(s) from storage"
        }
    }

    // Multi-Select helpers
    fun toggleSongSelection(id: Long) {
        val current = selectedSongIds.value
        selectedSongIds.value = if (current.contains(id)) current - id else current + id
        if (selectedSongIds.value.isEmpty()) {
            isMultiSelectMode.value = false
        }
    }

    fun selectAllDisplayed(songs: List<SongEntity>) {
        selectedSongIds.value = songs.map { it.id }.toSet()
        isMultiSelectMode.value = true
    }

    fun clearSelection() {
        selectedSongIds.value = emptySet()
        isMultiSelectMode.value = false
    }

    fun clearSnackbar() {
        snackbarMessage.value = null
    }

    class Factory(
        private val repository: MusicRepository,
        private val fileManager: MusicFileManager,
        private val playlistTransferManager: PlaylistTransferManager,
        private val playbackController: MusicPlaybackController
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return MusicViewModel(
                repository,
                fileManager,
                playlistTransferManager,
                playbackController
            ) as T
        }
    }
}
