package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.BookCoverTheme
import com.example.data.model.LiteraryCatalog
import com.example.ui.components.TypographicBookCover
import com.example.ui.viewmodel.AiCreationState
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AiBookCreatorScreen(
    aiCreationState: AiCreationState,
    onGenerateBook: (topic: String, genre: String, tone: String, chapterCount: Int, coverTheme: String) -> Unit,
    onBack: () -> Unit
) {
    val isGenerating = aiCreationState is AiCreationState.Generating

    BackHandler(enabled = !isGenerating) {
        onBack()
    }

    var topic by rememberSaveable { mutableStateOf("") }
    var selectedGenre by rememberSaveable { mutableStateOf(LiteraryCatalog.genres.first()) }
    var selectedTone by rememberSaveable { mutableStateOf(LiteraryCatalog.tones.first()) }
    var selectedChapterCount by rememberSaveable { mutableIntStateOf(80) }
    var chapterCountTextInput by rememberSaveable { mutableStateOf("80") }
    var selectedCoverTheme by rememberSaveable { mutableStateOf(BookCoverTheme.CRIMSON.id) }

    fun updateChapterCount(newCount: Int) {
        val clamped = newCount.coerceIn(80, 240)
        selectedChapterCount = clamped
        chapterCountTextInput = clamped.toString()
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.ai_studio_header),
                            style = MaterialTheme.typography.titleLarge
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        enabled = !isGenerating,
                        modifier = Modifier.testTag("ai_creator_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Geri"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 640.dp)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                // Header card explaining text-only AI book generation
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer
                    ),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "Yapay Zeka Edebiyat Atölyesi",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = "Konunuzu yazın ve 80 ile 240 bölüm arasında istediğiniz uzunluğu özgürce seçin. Yapay zeka her bölümü çok paragraflı, diyaloglu ve detaylı bir roman metni olarak kurgular.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }

                // Topic input
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = stringResource(R.string.ai_topic_label),
                        style = MaterialTheme.typography.titleMedium
                    )
                    OutlinedTextField(
                        value = topic,
                        onValueChange = { topic = it },
                        enabled = !isGenerating,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .testTag("ai_topic_input"),
                        placeholder = {
                            Text(stringResource(R.string.ai_topic_placeholder))
                        },
                        shape = RoundedCornerShape(16.dp)
                    )
                }

                // Quick topic inspirations
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Lightbulb,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Hazır Konu İlhamları (Dokunarak Seçin)",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        LiteraryCatalog.quickTopicIdeas.forEachIndexed { index, idea ->
                            OutlinedCard(
                                modifier = Modifier
                                    .width(250.dp)
                                    .clickable(enabled = !isGenerating) { topic = idea }
                                    .testTag("quick_idea_$index"),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Text(
                                    text = idea,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(12.dp),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }

                // Genre Selection
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = stringResource(R.string.ai_genre_label),
                        style = MaterialTheme.typography.titleMedium
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        LiteraryCatalog.genres.forEach { genre ->
                            FilterChip(
                                selected = selectedGenre == genre,
                                onClick = { if (!isGenerating) selectedGenre = genre },
                                label = { Text(genre) }
                            )
                        }
                    }
                }

                // Tone Selection
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = stringResource(R.string.ai_tone_label),
                        style = MaterialTheme.typography.titleMedium
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        LiteraryCatalog.tones.forEach { tone ->
                            FilterChip(
                                selected = selectedTone == tone,
                                onClick = { if (!isGenerating) selectedTone = tone },
                                label = { Text(tone) }
                            )
                        }
                    }
                }

                // Flexible 80 - 240 Chapter Count Selection Card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("chapter_count_selector_card"),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.MenuBook,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Bölüm Sayısı (80 – 240 Arası Özgür Seçim)",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Text(
                            text = "Seçilen: $selectedChapterCount Bölüm • Her bölüm 6-8 uzun paragraf (~${selectedChapterCount * 350}+ toplam kelime)",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )

                        // Slider for 80..240
                        Slider(
                            value = selectedChapterCount.coerceIn(80, 240).toFloat(),
                            onValueChange = { value ->
                                if (!isGenerating) {
                                    updateChapterCount(value.roundToInt())
                                }
                            },
                            valueRange = 80f..240f,
                            enabled = !isGenerating,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("chapter_count_slider")
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Min: 80 Bölüm",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Orta: 160 Bölüm",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Maks: 240 Bölüm",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        // Stepper buttons (-10, -1, Direct Input, +1, +10)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(
                                onClick = { updateChapterCount(selectedChapterCount - 10) },
                                enabled = !isGenerating && selectedChapterCount > 80,
                                modifier = Modifier.testTag("chapter_minus_10_button")
                            ) {
                                Text("-10")
                            }

                            FilledTonalIconButton(
                                onClick = { updateChapterCount(selectedChapterCount - 1) },
                                enabled = !isGenerating && selectedChapterCount > 80,
                                modifier = Modifier.testTag("chapter_minus_1_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Remove,
                                    contentDescription = "1 Bölüm Azalt"
                                )
                            }

                            OutlinedTextField(
                                value = chapterCountTextInput,
                                onValueChange = { raw ->
                                    val digits = raw.filter { it.isDigit() }.take(3)
                                    chapterCountTextInput = digits
                                    val parsed = digits.toIntOrNull()
                                    if (parsed != null) {
                                        selectedChapterCount = parsed.coerceIn(80, 240)
                                    }
                                },
                                enabled = !isGenerating,
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                label = { Text("Bölüm (80-240)") },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("chapter_count_input")
                            )

                            FilledTonalIconButton(
                                onClick = { updateChapterCount(selectedChapterCount + 1) },
                                enabled = !isGenerating && selectedChapterCount < 240,
                                modifier = Modifier.testTag("chapter_plus_1_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "1 Bölüm Artır"
                                )
                            }

                            OutlinedButton(
                                onClick = { updateChapterCount(selectedChapterCount + 10) },
                                enabled = !isGenerating && selectedChapterCount < 240,
                                modifier = Modifier.testTag("chapter_plus_10_button")
                            ) {
                                Text("+10")
                            }
                        }

                        // Quick Preset Chips across 80-240
                        Text(
                            text = "Hızlı Bölüm Seçenekleri:",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(80, 100, 120, 150, 180, 200, 240).forEach { count ->
                                FilterChip(
                                    selected = selectedChapterCount == count,
                                    onClick = { if (!isGenerating) updateChapterCount(count) },
                                    label = { Text("$count Bölüm") },
                                    modifier = Modifier.testTag("chapter_count_$count")
                                )
                            }
                        }
                    }
                }

                // Typographic Cover Theme Preview & Picker
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = stringResource(R.string.ai_cover_theme_label),
                        style = MaterialTheme.typography.titleMedium
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        TypographicBookCover(
                            title = topic.take(36).ifBlank { "Yeni AI Kitabım" },
                            subtitle = "$selectedChapterCount Bölüm • $selectedTone",
                            genre = selectedGenre,
                            coverTheme = selectedCoverTheme,
                            isAiCreated = true,
                            width = 104.dp,
                            height = 152.dp
                        )

                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            BookCoverTheme.entries.forEach { theme ->
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable(enabled = !isGenerating) {
                                            selectedCoverTheme = theme.id
                                        },
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (selectedCoverTheme == theme.id) {
                                        MaterialTheme.colorScheme.secondaryContainer
                                    } else {
                                        MaterialTheme.colorScheme.surface
                                    },
                                    border = BorderStroke(
                                        width = if (selectedCoverTheme == theme.id) 1.5.dp else 1.dp,
                                        color = if (selectedCoverTheme == theme.id) {
                                            MaterialTheme.colorScheme.secondary
                                        } else {
                                            MaterialTheme.colorScheme.surfaceVariant
                                        }
                                    )
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = theme.labelTr,
                                            style = MaterialTheme.typography.labelLarge
                                        )
                                        Text(
                                            text = theme.subtitleTr,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Error State
                if (aiCreationState is AiCreationState.Error) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("ai_creation_error_card"),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer
                        )
                    ) {
                        Text(
                            text = aiCreationState.message,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.padding(14.dp)
                        )
                    }
                }

                // Generating Progress State
                if (aiCreationState is AiCreationState.Generating) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("ai_generating_card"),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            CircularProgressIndicator()
                            Text(
                                text = stringResource(R.string.ai_generating_title),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = aiCreationState.statusMessage,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                Button(
                    onClick = {
                        val finalCount = chapterCountTextInput.toIntOrNull()?.coerceIn(80, 240)
                            ?: selectedChapterCount.coerceIn(80, 240)
                        updateChapterCount(finalCount)
                        onGenerateBook(
                            topic,
                            selectedGenre,
                            selectedTone,
                            finalCount,
                            selectedCoverTheme
                        )
                    },
                    enabled = !isGenerating,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("ai_generate_submit_button"),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "${selectedChapterCount} Bölümlük Kitabı AI ile Oluştur",
                        style = MaterialTheme.typography.titleMedium
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
