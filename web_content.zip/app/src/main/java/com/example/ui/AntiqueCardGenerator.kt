package com.example.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.data.SufiEntry
import com.example.data.SufiLanguage
import java.io.File
import java.io.FileOutputStream

/**
 * Generates and shares an authentic antique terracotta wisdom card image.
 */
object AntiqueCardGenerator {

    fun shareAntiqueCard(context: Context, entry: SufiEntry, language: SufiLanguage) {
        try {
            val bitmap = createCardBitmap(context, entry, language)
            val file = saveBitmapToCache(context, bitmap)
            if (file != null) {
                val uri: Uri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    file
                )
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "image/png"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_TEXT, "✨ Sufi Some Says...\n© JOPPAN THINKS")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(intent, "Share Wisdom Card"))
            } else {
                shareAsText(context, entry, language)
            }
        } catch (e: Exception) {
            shareAsText(context, entry, language)
        }
    }

    private fun shareAsText(context: Context, entry: SufiEntry, language: SufiLanguage) {
        val text = if (language == SufiLanguage.MALAYALAM) {
            "${entry.ml}\n\n— Sufi Some Says (© JOPPAN THINKS)"
        } else {
            "“${entry.en}”\n${if (!entry.author.isNullOrBlank()) "— ${entry.author}\n" else ""}\n— Sufi Some Says (© JOPPAN THINKS)"
        }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        context.startActivity(Intent.createChooser(intent, "Share Wisdom"))
    }

    private fun createCardBitmap(context: Context, entry: SufiEntry, language: SufiLanguage): Bitmap {
        val width = 1080
        val height = 1350
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // 1. Terracotta Gradient Canvas
        val bgPaint = Paint().apply {
            color = Color.parseColor("#38150D")
            isAntiAlias = true
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // 2. Inner border
        val borderPaint = Paint().apply {
            color = Color.parseColor("#E5C07A")
            style = Paint.Style.STROKE
            strokeWidth = 6f
            isAntiAlias = true
        }
        val margin = 50f
        canvas.drawRoundRect(RectF(margin, margin, width - margin, height - margin), 40f, 40f, borderPaint)

        // 3. Header title
        val titlePaint = Paint().apply {
            color = Color.parseColor("#FFE59E")
            textSize = 42f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
            letterSpacing = 0.2f
        }
        canvas.drawText("SUFI SOME SAYS", width / 2f, 180f, titlePaint)

        // 4. Quote / Reflection text
        val textPaint = Paint().apply {
            color = Color.parseColor("#FFF5D9")
            textSize = 48f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.SERIF, Typeface.NORMAL)
        }

        val textToDraw = if (language == SufiLanguage.MALAYALAM) entry.ml else "“${entry.en}”"
        val lines = wrapText(textToDraw, width - 200, textPaint)
        var startY = height / 2f - (lines.size * 60f) / 2f

        for (line in lines) {
            canvas.drawText(line, width / 2f, startY, textPaint)
            startY += 65f
        }

        // 5. Author
        if (entry.isQuote && !entry.author.isNullOrBlank()) {
            val authorPaint = Paint().apply {
                color = Color.parseColor("#FFE59E")
                textSize = 38f
                isAntiAlias = true
                textAlign = Paint.Align.CENTER
                typeface = Typeface.create(Typeface.SERIF, Typeface.ITALIC)
            }
            canvas.drawText("— ${entry.author}", width / 2f, startY + 60f, authorPaint)
        }

        // 6. Watermark Footer
        val watermarkPaint = Paint().apply {
            color = Color.parseColor("#E5C07A")
            textSize = 28f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.SERIF, Typeface.NORMAL)
            letterSpacing = 0.25f
        }
        canvas.drawText("© JOPPAN THINKS", width / 2f, height - 100f, watermarkPaint)

        return bitmap
    }

    private fun wrapText(text: String, maxWidth: Int, paint: Paint): List<String> {
        val words = text.split(" ")
        val lines = mutableListOf<String>()
        var currentLine = ""

        for (word in words) {
            val testLine = if (currentLine.isEmpty()) word else "$currentLine $word"
            if (paint.measureText(testLine) <= maxWidth) {
                currentLine = testLine
            } else {
                if (currentLine.isNotEmpty()) lines.add(currentLine)
                currentLine = word
            }
        }
        if (currentLine.isNotEmpty()) lines.add(currentLine)
        return lines
    }

    private fun saveBitmapToCache(context: Context, bitmap: Bitmap): File? {
        return try {
            val cachePath = File(context.cacheDir, "images")
            cachePath.mkdirs()
            val file = File(cachePath, "sufi_wisdom_${System.currentTimeMillis()}.png")
            val stream = FileOutputStream(file)
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
            stream.close()
            file
        } catch (e: Exception) {
            null
        }
    }
}
