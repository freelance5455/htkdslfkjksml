package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.DailyHormoneCycleLog
import com.example.data.model.TrendMetric
import com.example.ui.theme.CycleRose

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HormoneAndCycleTrendChart(
    logs: List<DailyHormoneCycleLog>,
    showCycleMetrics: Boolean,
    modifier: Modifier = Modifier
) {
    val availableMetrics = remember(showCycleMetrics) {
        if (showCycleMetrics) {
            TrendMetric.entries
        } else {
            listOf(
                TrendMetric.HORMONE_BALANCE,
                TrendMetric.ENERGY,
                TrendMetric.MOOD_STABILITY,
                TrendMetric.SLEEP_QUALITY
            )
        }
    }
    var selectedMetric by remember(availableMetrics) { mutableStateOf(availableMetrics.first()) }

    val filteredPoints = remember(logs, selectedMetric) {
        val raw = if (selectedMetric == TrendMetric.CRAMPS) {
            logs.filter { it.id.startsWith("c_") }
        } else {
            logs.filter { it.id.startsWith("h_") }
        }
        raw.takeLast(12)
    }

    val values = remember(filteredPoints, selectedMetric) {
        filteredPoints.map { point ->
            when (selectedMetric) {
                TrendMetric.HORMONE_BALANCE -> point.overallBalanceScore
                TrendMetric.ENERGY -> point.energyScore.toFloat()
                TrendMetric.MOOD_STABILITY -> point.moodBalanceScore.toFloat()
                TrendMetric.SLEEP_QUALITY -> point.sleepQualityScore.toFloat()
                TrendMetric.CRAMPS -> point.crampsLevel.toFloat()
            }
        }
    }

    val lineColor = if (selectedMetric == TrendMetric.CRAMPS) CycleRose else MaterialTheme.colorScheme.primary
    val gridColor = MaterialTheme.colorScheme.outlineVariant
    val dotCenterColor = MaterialTheme.colorScheme.surface

    Card(
        modifier = modifier.fillMaxWidth().testTag("hormone_cycle_trend_card"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.ShowChart, contentDescription = null, tint = lineColor)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Hormone & Cycle Trends", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                availableMetrics.forEach { metric ->
                    FilterChip(
                        selected = selectedMetric == metric,
                        onClick = { selectedMetric = metric },
                        modifier = Modifier.testTag("trend_metric_${metric.name.lowercase()}"),
                        label = { Text(metric.label, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }

            if (values.isEmpty()) {
                Text(
                    text = "Log a ${selectedMetric.label.lowercase()} check-in below to start seeing your trend over time.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
            } else {
                val avg = values.average().toFloat()
                val latest = values.last()
                val delta = if (values.size >= 2) latest - values[values.lastIndex - 1] else 0f

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Latest: ${"%.1f".format(latest)}${selectedMetric.unit}",
                        style = MaterialTheme.typography.labelLarge,
                        color = lineColor
                    )
                    Text(
                        text = "Avg: ${"%.1f".format(avg)}${selectedMetric.unit}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = when {
                            delta > 0.05f -> "+${"%.1f".format(delta)} vs prev"
                            delta < -0.05f -> "${"%.1f".format(delta)} vs prev"
                            else -> "Steady"
                        },
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(128.dp)
                        .padding(horizontal = 8.dp, vertical = 8.dp)
                        .testTag("hormone_trend_canvas")
                ) {
                    val minVal = if (selectedMetric == TrendMetric.CRAMPS) 0f else 1f
                    val maxVal = selectedMetric.maxValue
                    val range = (maxVal - minVal).coerceAtLeast(1f)

                    // Horizontal reference lines
                    for (step in 0..4) {
                        val y = size.height * (step / 4f)
                        drawLine(
                            color = gridColor.copy(alpha = 0.45f),
                            start = Offset(0f, y),
                            end = Offset(size.width, y),
                            strokeWidth = 2f
                        )
                    }

                    val points = if (values.size == 1) {
                        val normY = ((values[0] - minVal) / range).coerceIn(0f, 1f)
                        listOf(Offset(size.width / 2f, size.height * (1f - normY)))
                    } else {
                        val stepX = size.width / (values.size - 1).toFloat()
                        values.mapIndexed { idx, v ->
                            val normY = ((v - minVal) / range).coerceIn(0f, 1f)
                            Offset(idx * stepX, size.height * (1f - normY))
                        }
                    }

                    if (points.size > 1) {
                        val linePath = Path().apply {
                            moveTo(points.first().x, points.first().y)
                            for (i in 1 until points.size) {
                                lineTo(points[i].x, points[i].y)
                            }
                        }
                        val fillPath = Path().apply {
                            addPath(linePath)
                            lineTo(points.last().x, size.height)
                            lineTo(points.first().x, size.height)
                            close()
                        }
                        drawPath(
                            path = fillPath,
                            brush = Brush.verticalGradient(
                                colors = listOf(lineColor.copy(alpha = 0.25f), Color.Transparent)
                            )
                        )
                        drawPath(
                            path = linePath,
                            color = lineColor,
                            style = Stroke(width = 7f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                        )
                    }

                    points.forEach { pt ->
                        drawCircle(color = lineColor, radius = 11f, center = pt)
                        drawCircle(color = dotCenterColor, radius = 5f, center = pt)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = filteredPoints.first().dateLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (filteredPoints.size > 1) {
                        Text(
                            text = "${filteredPoints.size} entries",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = filteredPoints.last().dateLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
