package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.CalorieOrange
import com.example.ui.theme.CarbsAmber
import com.example.ui.theme.EmeraldGreenPrimary
import com.example.ui.theme.FatPurple
import com.example.ui.theme.ProteinBlue
import com.example.ui.viewmodel.MainViewModel

enum class Gender(val persianTitle: String) {
    MALE("آقا (مرد)"),
    FEMALE("خانم (زن)")
}

enum class ActivityLevel(val persianTitle: String, val factor: Double, val description: String) {
    SEDENTARY("کم‌تحرک", 1.2, "کار پشت میز و بدون ورزش منظم"),
    LIGHT("فعالیت سبک", 1.375, "ورزش ۱ تا ۳ روز در هفته"),
    MODERATE("فعالیت متوسط", 1.55, "ورزش ۳ تا ۵ روز در هفته"),
    VERY_ACTIVE("بسیار فعال", 1.725, "ورزش سنگین ۶ تا ۷ روز در هفته")
}

enum class FitnessGoal(val persianTitle: String, val calorieDelta: Int, val description: String) {
    LOSE_WEIGHT("کاهش وزن (چربی‌سوزی)", -500, "نیم کیلوگرم کاهش در هفته با سلامت کامل"),
    MAINTAIN("تثبیت وزن فعلی", 0, "حفظ سلامت و تعادل متابولیک"),
    GAIN_MUSCLE("افزایش وزن و حجم عضلانی", 400, "رشد عضلات در کنار تمرینات قدرتی")
}

@Composable
fun CalculatorScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    var gender by remember { mutableStateOf(Gender.MALE) }
    var ageText by remember { mutableStateOf("26") }
    var weightText by remember { mutableStateOf("75") }
    var heightText by remember { mutableStateOf("178") }
    var activityLevel by remember { mutableStateOf(ActivityLevel.MODERATE) }
    var fitnessGoal by remember { mutableStateOf(FitnessGoal.LOSE_WEIGHT) }
    var appliedGoalNotice by remember { mutableStateOf(false) }

    val age = ageText.toIntOrNull() ?: 25
    val weight = weightText.toDoubleOrNull() ?: 70.0
    val height = heightText.toDoubleOrNull() ?: 175.0

    // Mifflin-St Jeor Formula
    val bmr = if (gender == Gender.MALE) {
        (10 * weight) + (6.25 * height) - (5 * age) + 5
    } else {
        (10 * weight) + (6.25 * height) - (5 * age) - 161
    }.coerceAtLeast(1000.0)

    val tdee = bmr * activityLevel.factor
    val targetCalories = (tdee + fitnessGoal.calorieDelta).toInt().coerceAtLeast(1200)

    val targetProteinGrams = (targetCalories * 0.25 / 4).toInt()
    val targetCarbsGrams = (targetCalories * 0.50 / 4).toInt()
    val targetFatGrams = (targetCalories * 0.25 / 9).toInt()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("calculator_screen_list"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(EmeraldGreenPrimary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.ic_calculator),
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "محاسبه‌گر کالری و متابولیسم بدن",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "فرمول استاندارد پزشکی Mifflin-St Jeor برای تعیین کالری مجاز روزانه",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Input Fields
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(text = "مشخصات فردی", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Gender.entries.forEach { g ->
                            FilterChip(
                                selected = gender == g,
                                onClick = { gender = g },
                                label = { Text(g.persianTitle, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center) },
                                modifier = Modifier.weight(1f),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = EmeraldGreenPrimary,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = ageText,
                            onValueChange = { ageText = it },
                            label = { Text("سن (سال)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f).testTag("calc_age_input"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = weightText,
                            onValueChange = { weightText = it },
                            label = { Text("وزن (kg)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f).testTag("calc_weight_input"),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = heightText,
                            onValueChange = { heightText = it },
                            label = { Text("قد (cm)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f).testTag("calc_height_input"),
                            singleLine = true
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Text(text = "سطح فعالیت روزمره:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(8.dp))

                    ActivityLevel.entries.forEach { act ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            FilterChip(
                                selected = activityLevel == act,
                                onClick = { activityLevel = act },
                                label = {
                                    Column {
                                        Text(act.persianTitle, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        Text(act.description, fontSize = 10.sp)
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = EmeraldGreenPrimary.copy(alpha = 0.15f),
                                    selectedLabelColor = EmeraldGreenPrimary
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Text(text = "هدف تغذیه‌ای شما:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(8.dp))

                    FitnessGoal.entries.forEach { goal ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            FilterChip(
                                selected = fitnessGoal == goal,
                                onClick = { fitnessGoal = goal },
                                label = {
                                    Column {
                                        Text(goal.persianTitle, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        Text(goal.description, fontSize = 10.sp)
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CalorieOrange.copy(alpha = 0.15f),
                                    selectedLabelColor = CalorieOrange
                                )
                            )
                        }
                    }
                }
            }
        }

        // Calculated Result Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("calculator_result_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "هدف پیشنهادی کالری روزانه",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "$targetCalories",
                            fontSize = 42.sp,
                            fontWeight = FontWeight.Black,
                            color = CalorieOrange
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "کیلوکالری در روز",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "${bmr.toInt()}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(text = "متابولیسم پایه (BMR)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "${tdee.toInt()}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(text = "مصرف کل روزانه (TDEE)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Suggested Macros
                    Text(text = "تقسیم درشت‌مغذی‌های پیشنهادی:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        MacroCard(title = "پروتئین", amount = "${targetProteinGrams}g", color = ProteinBlue, modifier = Modifier.weight(1f))
                        MacroCard(title = "کربوهیدرات", amount = "${targetCarbsGrams}g", color = CarbsAmber, modifier = Modifier.weight(1f))
                        MacroCard(title = "چربی", amount = "${targetFatGrams}g", color = FatPurple, modifier = Modifier.weight(1f))
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = {
                            viewModel.updateDailyGoal(targetCalories)
                            appliedGoalNotice = true
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("apply_goal_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (appliedGoalNotice) Color(0xFF2E7D32) else EmeraldGreenPrimary
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (appliedGoalNotice) {
                            Icon(Icons.Default.Check, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("به عنوان هدف روزانه فعال شد")
                        } else {
                            Icon(
                                painter = painterResource(R.drawable.ic_speed),
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تنظیم به عنوان بودجه کالری روزانه")
                        }
                    }
                }
            }
        }
    }
}
