package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.Backspace
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Science
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.BannerAdView
import com.example.ui.components.CalcButtonType
import com.example.ui.components.CalculatorButton
import com.example.ui.localization.AppStrings
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.SoftViolet
import com.example.ui.viewmodel.MainUiState

@Composable
fun CalculatorScreen(
    uiState: MainUiState,
    isScientificInitially: Boolean = false,
    onInput: (String) -> Unit,
    onClear: () -> Unit,
    onBackspace: () -> Unit,
    onEquals: () -> Unit,
    onToggleAngleMode: () -> Unit,
    onToggleScientific: () -> Unit,
    onOpenHistory: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val language = uiState.language
    val exprScrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Clean Minimal Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .testTag("calc_btn_back")
                    .size(44.dp)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
                    contentDescription = "Back",
                    tint = MaterialTheme.colorScheme.onBackground
                )
            }

            // Title + Mode Switch
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // DEG / RAD Pill
                val angleBadgeShape = RoundedCornerShape(10.dp)
                Box(
                    modifier = Modifier
                        .testTag("calc_btn_deg_rad")
                        .clip(angleBadgeShape)
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f))
                        .border(
                            0.5.dp,
                            MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                            angleBadgeShape
                        )
                        .clickable { onToggleAngleMode() }
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = if (uiState.isDegreeMode) AppStrings.get("deg", language) else AppStrings.get("rad", language),
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                        color = ElectricBlue
                    )
                }

                // Scientific Toggle Button
                val isSci = uiState.isScientificExpanded || isScientificInitially
                IconButton(
                    onClick = onToggleScientific,
                    modifier = Modifier
                        .testTag("calc_btn_toggle_sci")
                        .size(40.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            if (isSci) SoftViolet.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
                        )
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Science,
                        contentDescription = "Scientific Mode",
                        tint = if (isSci) SoftViolet else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // History Shortcut
                IconButton(
                    onClick = onOpenHistory,
                    modifier = Modifier
                        .testTag("calc_btn_history")
                        .size(40.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f))
                ) {
                    Icon(
                        imageVector = Icons.Outlined.History,
                        contentDescription = "History",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // Display Area (Large, clean, easy to read)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 24.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.Bottom,
            horizontalAlignment = Alignment.End
        ) {
            // Expression Line (with horizontal scroll)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(exprScrollState, reverseScrolling = true),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = uiState.calcExpression.ifEmpty { " " },
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.Normal,
                        fontSize = 24.sp
                    ),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    textAlign = TextAlign.End
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Main Result Display
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Quick Copy Button
                IconButton(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("Calculator Result", uiState.calcResult)
                        clipboard.setPrimaryClip(clip)
                        Toast.makeText(context, AppStrings.get("copied", language), Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier
                        .testTag("calc_btn_copy")
                        .size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.ContentCopy,
                        contentDescription = "Copy Result",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                        modifier = Modifier.size(18.dp)
                    )
                }

                Text(
                    text = uiState.calcResult,
                    style = MaterialTheme.typography.displayLarge.copy(
                        fontWeight = FontWeight.SemiBold,
                        fontSize = if (uiState.calcResult.length > 9) 34.sp else 46.sp
                    ),
                    color = MaterialTheme.colorScheme.onBackground,
                    maxLines = 1,
                    textAlign = TextAlign.End,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Keypad Container
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val showScientific = uiState.isScientificExpanded || isScientificInitially

            // Expandable Scientific Rows
            AnimatedVisibility(
                visible = showScientific,
                enter = expandVertically(),
                exit = shrinkVertically()
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(bottom = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CalculatorButton(text = "sin", type = CalcButtonType.SCIENTIFIC, height = 48.dp, modifier = Modifier.weight(1f), isHapticsEnabled = uiState.hapticsEnabled) { onInput("sin(") }
                        CalculatorButton(text = "cos", type = CalcButtonType.SCIENTIFIC, height = 48.dp, modifier = Modifier.weight(1f), isHapticsEnabled = uiState.hapticsEnabled) { onInput("cos(") }
                        CalculatorButton(text = "tan", type = CalcButtonType.SCIENTIFIC, height = 48.dp, modifier = Modifier.weight(1f), isHapticsEnabled = uiState.hapticsEnabled) { onInput("tan(") }
                        CalculatorButton(text = "ln", type = CalcButtonType.SCIENTIFIC, height = 48.dp, modifier = Modifier.weight(1f), isHapticsEnabled = uiState.hapticsEnabled) { onInput("ln(") }
                        CalculatorButton(text = "log", type = CalcButtonType.SCIENTIFIC, height = 48.dp, modifier = Modifier.weight(1f), isHapticsEnabled = uiState.hapticsEnabled) { onInput("log(") }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CalculatorButton(text = "√", type = CalcButtonType.SCIENTIFIC, height = 48.dp, modifier = Modifier.weight(1f), isHapticsEnabled = uiState.hapticsEnabled) { onInput("sqrt(") }
                        CalculatorButton(text = "^", type = CalcButtonType.SCIENTIFIC, height = 48.dp, modifier = Modifier.weight(1f), isHapticsEnabled = uiState.hapticsEnabled) { onInput("^") }
                        CalculatorButton(text = "π", type = CalcButtonType.SCIENTIFIC, height = 48.dp, modifier = Modifier.weight(1f), isHapticsEnabled = uiState.hapticsEnabled) { onInput("π") }
                        CalculatorButton(text = "e", type = CalcButtonType.SCIENTIFIC, height = 48.dp, modifier = Modifier.weight(1f), isHapticsEnabled = uiState.hapticsEnabled) { onInput("e") }
                        CalculatorButton(text = "!", type = CalcButtonType.SCIENTIFIC, height = 48.dp, modifier = Modifier.weight(1f), isHapticsEnabled = uiState.hapticsEnabled) { onInput("!") }
                    }
                }
            }

            // Row 1: AC, (), %, ÷
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                CalculatorButton(
                    text = "AC",
                    type = CalcButtonType.ACTION,
                    testTag = "calc_btn_ac",
                    isHapticsEnabled = uiState.hapticsEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = onClear
                )
                CalculatorButton(
                    text = "( )",
                    type = CalcButtonType.ACTION,
                    testTag = "calc_btn_parens",
                    isHapticsEnabled = uiState.hapticsEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = {
                        val openCount = uiState.calcExpression.count { it == '(' }
                        val closeCount = uiState.calcExpression.count { it == ')' }
                        if (openCount > closeCount) onInput(")") else onInput("(")
                    }
                )
                CalculatorButton(
                    text = "%",
                    type = CalcButtonType.ACTION,
                    testTag = "calc_btn_percent",
                    isHapticsEnabled = uiState.hapticsEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { onInput("%") }
                )
                CalculatorButton(
                    text = "÷",
                    type = CalcButtonType.OPERATOR,
                    testTag = "calc_btn_div",
                    isHapticsEnabled = uiState.hapticsEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = { onInput("÷") }
                )
            }

            // Row 2: 7, 8, 9, ×
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                CalculatorButton(text = "7", modifier = Modifier.weight(1f), isHapticsEnabled = uiState.hapticsEnabled) { onInput("7") }
                CalculatorButton(text = "8", modifier = Modifier.weight(1f), isHapticsEnabled = uiState.hapticsEnabled) { onInput("8") }
                CalculatorButton(text = "9", modifier = Modifier.weight(1f), isHapticsEnabled = uiState.hapticsEnabled) { onInput("9") }
                CalculatorButton(text = "×", type = CalcButtonType.OPERATOR, testTag = "calc_btn_mul", isHapticsEnabled = uiState.hapticsEnabled, modifier = Modifier.weight(1f)) { onInput("×") }
            }

            // Row 3: 4, 5, 6, -
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                CalculatorButton(text = "4", modifier = Modifier.weight(1f), isHapticsEnabled = uiState.hapticsEnabled) { onInput("4") }
                CalculatorButton(text = "5", modifier = Modifier.weight(1f), isHapticsEnabled = uiState.hapticsEnabled) { onInput("5") }
                CalculatorButton(text = "6", modifier = Modifier.weight(1f), isHapticsEnabled = uiState.hapticsEnabled) { onInput("6") }
                CalculatorButton(text = "−", type = CalcButtonType.OPERATOR, testTag = "calc_btn_sub", isHapticsEnabled = uiState.hapticsEnabled, modifier = Modifier.weight(1f)) { onInput("−") }
            }

            // Row 4: 1, 2, 3, +
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                CalculatorButton(text = "1", modifier = Modifier.weight(1f), isHapticsEnabled = uiState.hapticsEnabled) { onInput("1") }
                CalculatorButton(text = "2", modifier = Modifier.weight(1f), isHapticsEnabled = uiState.hapticsEnabled) { onInput("2") }
                CalculatorButton(text = "3", modifier = Modifier.weight(1f), isHapticsEnabled = uiState.hapticsEnabled) { onInput("3") }
                CalculatorButton(text = "+", type = CalcButtonType.OPERATOR, testTag = "calc_btn_add", isHapticsEnabled = uiState.hapticsEnabled, modifier = Modifier.weight(1f)) { onInput("+") }
            }

            // Row 5: 0, ., Backspace, =
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                CalculatorButton(text = "0", modifier = Modifier.weight(1f), isHapticsEnabled = uiState.hapticsEnabled) { onInput("0") }
                CalculatorButton(text = ".", modifier = Modifier.weight(1f), isHapticsEnabled = uiState.hapticsEnabled) { onInput(".") }
                CalculatorButton(
                    icon = Icons.AutoMirrored.Outlined.Backspace,
                    text = "Del",
                    type = CalcButtonType.ACTION,
                    testTag = "calc_btn_backspace",
                    isHapticsEnabled = uiState.hapticsEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = onBackspace
                )
                CalculatorButton(
                    text = "=",
                    type = CalcButtonType.EQUALS,
                    testTag = "calc_btn_equals",
                    isHapticsEnabled = uiState.hapticsEnabled,
                    modifier = Modifier.weight(1f),
                    onClick = onEquals
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Ad Placement: clearly separated at the bottom so it never covers buttons
        BannerAdView()
    }
}
