package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Inbox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.VisitResult
import com.example.ui.components.DeviceTypeIcon
import com.example.ui.components.LatencyChip
import com.example.ui.components.StatusBadge
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber
import com.example.viewmodel.TrafficSimulatorViewModel

@Composable
fun LogsScreen(
    viewModel: TrafficSimulatorViewModel,
    modifier: Modifier = Modifier
) {
    val visits by viewModel.visits.collectAsState()
    val filteredVisits by viewModel.filteredVisits.collectAsState()
    val logFilter by viewModel.logFilter.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()

    val countSuccess = visits.count { it.statusCode in 200..299 }
    val countRedirect = visits.count { it.statusCode in 300..399 }
    val countError = visits.count { it.statusCode >= 400 || it.statusCode == 0 || it.errorMessage != null }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Search & Filter Header
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.setSearchQuery(it) },
            label = { Text("Filter by IP, browser, referrer, or URL") },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search",
                    tint = CyberCyan
                )
            },
            trailingIcon = {
                if (searchQuery.isNotBlank()) {
                    IconButton(onClick = { viewModel.setSearchQuery("") }) {
                        Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear")
                    }
                }
            },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("log_search_field")
        )

        // Status Filter Chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            FilterChip(
                selected = logFilter == "ALL",
                onClick = { viewModel.setLogFilter("ALL") },
                label = { Text("All (${visits.size})", fontSize = 11.sp) },
                modifier = Modifier.testTag("filter_all")
            )
            FilterChip(
                selected = logFilter == "SUCCESS",
                onClick = { viewModel.setLogFilter("SUCCESS") },
                label = { Text("2xx (${countSuccess})", fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = SuccessGreen.copy(alpha = 0.2f),
                    selectedLabelColor = SuccessGreen
                ),
                modifier = Modifier.testTag("filter_success")
            )
            FilterChip(
                selected = logFilter == "REDIRECT",
                onClick = { viewModel.setLogFilter("REDIRECT") },
                label = { Text("3xx (${countRedirect})", fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = WarningAmber.copy(alpha = 0.2f),
                    selectedLabelColor = WarningAmber
                ),
                modifier = Modifier.testTag("filter_redirect")
            )
            FilterChip(
                selected = logFilter == "ERROR",
                onClick = { viewModel.setLogFilter("ERROR") },
                label = { Text("Errors (${countError})", fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = ErrorRed.copy(alpha = 0.2f),
                    selectedLabelColor = ErrorRed
                ),
                modifier = Modifier.testTag("filter_error")
            )
        }

        // Visits List
        if (filteredVisits.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Inbox,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.size(48.dp)
                    )
                    Text(
                        text = if (visits.isEmpty()) "No visits simulated yet." else "No matching requests found.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = if (visits.isEmpty()) "Start a simulation from the Runner tab to generate live logs." else "Try adjusting your search query or status filter.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredVisits, key = { it.index }) { visit ->
                    LogVisitItem(
                        visit = visit,
                        onClick = { viewModel.selectVisit(visit) }
                    )
                }
            }
        }
    }
}

@Composable
private fun LogVisitItem(
    visit: VisitResult,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
        ),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("log_visit_item_${visit.index}")
    ) {
        Column(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "#${visit.index}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = CyberCyan,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    DeviceTypeIcon(
                        deviceType = visit.sessionProfile.deviceType,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = visit.sessionProfile.browserName,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LatencyChip(latencyMs = visit.latencyMs)
                    Spacer(modifier = Modifier.width(8.dp))
                    StatusBadge(statusCode = visit.statusCode, statusMessage = visit.statusMessage)
                }
            }

            // Sub-row: IP, Referrer, Cookie Indicator
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${visit.sessionProfile.simulatedIp} (${visit.sessionProfile.simulatedCountry})",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = if (visit.cookiesReceived.isNotEmpty()) "🍪 Set-Cookie (${visit.cookiesReceived.size})" else "Direct",
                    fontSize = 11.sp,
                    color = if (visit.cookiesReceived.isNotEmpty()) SuccessGreen else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
