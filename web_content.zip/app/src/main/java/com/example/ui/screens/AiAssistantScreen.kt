package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.AiUiState
import com.example.ui.viewmodel.AiViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AiAssistantScreen(
    aiViewModel: AiViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiState by aiViewModel.uiState.collectAsState()
    val selectedCategory by aiViewModel.selectedCategory.collectAsState()

    var customInput by remember { mutableStateOf("") }
    var selectedNoticeType by remember { mutableStateOf("শোকবার্তা") }
    var selectedOccasion by remember { mutableStateOf("ছাত্র সমাবেশ ও মতবিনিময় সভা") }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("ai_assistant_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Header with Gemini Badge
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Transparent),
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(Color(0xFF0F5132), Color(0xFF15803D), Color(0xFF1E3A8A))
                        )
                    )
                    .padding(20.dp)
            ) {
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.2f),
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = "AI",
                                    tint = Color(0xFFFDE047),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Column {
                            Text(
                                text = "চারঘাট ছাত্রলীগ AI সহকারী",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .background(Color(0xFF4ADE80), CircleShape)
                                )
                                Text(
                                    text = "Gemini 3.8 Flash ইন্টিগ্রেশন",
                                    color = Color(0xFFBBF7D0),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "প্রেস বিজ্ঞপ্তি, আনুষ্ঠানিক শোকবার্তা, সাংগঠনিক সভার নোটিশ ও বক্তব্যের মূল পয়েন্ট নিমেষেই নির্ভুল বাংলায় তৈরি করুন।",
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                }
            }
        }

        // Category Switcher
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val categories = listOf(
                Triple("notice", "প্রেস বিজ্ঞপ্তি", Icons.Default.Description),
                Triple("speech", "বক্তব্য সহায়িকা", Icons.Default.RecordVoiceOver),
                Triple("chat", "সরাসরি চ্যাট", Icons.Default.Forum)
            )

            categories.forEach { (catId, label, icon) ->
                val isSelected = selectedCategory == catId
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            aiViewModel.selectCategory(catId)
                        }
                        .testTag("ai_category_$catId"),
                    color = if (isSelected) Color(0xFF15803D) else Color.White,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isSelected) Color(0xFF15803D) else Color(0xFFE2E8F0)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    shadowElevation = if (isSelected) 2.dp else 0.dp
                ) {
                    Column(
                        modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = label,
                            tint = if (isSelected) Color.White else TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = label,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) Color.White else TextPrimary
                        )
                    }
                }
            }
        }

        // Active Section Content
        when (selectedCategory) {
            "notice" -> {
                NoticeGeneratorCard(
                    selectedType = selectedNoticeType,
                    onTypeSelect = { selectedNoticeType = it },
                    customTopic = customInput,
                    onTopicChange = { customInput = it },
                    isLoading = uiState is AiUiState.Loading,
                    onSubmit = {
                        val topic = if (customInput.isNotBlank()) customInput else "উপজেলা ও পৌর শাখার সাংগঠনিক কার্যক্রম ও ছাত্রদের সমস্যা সমাধান নিয়ে জরুরি পর্যালোচনা সভা"
                        aiViewModel.generateNotice(selectedNoticeType, topic)
                    }
                )
            }
            "speech" -> {
                SpeechGeneratorCard(
                    selectedOccasion = selectedOccasion,
                    onOccasionSelect = { selectedOccasion = it },
                    customDetails = customInput,
                    onDetailsChange = { customInput = it },
                    isLoading = uiState is AiUiState.Loading,
                    onSubmit = {
                        val details = if (customInput.isNotBlank()) customInput else "চারঘাট উপজেলার ছাত্রসমাজকে স্মার্ট বাংলাদেশ ও আধুনিক শিক্ষায় উদ্বুদ্ধকরণ"
                        aiViewModel.generateSpeechPoints(selectedOccasion, details)
                    }
                )
            }
            else -> {
                ChatGeneratorCard(
                    prompt = customInput,
                    onPromptChange = { customInput = it },
                    isLoading = uiState is AiUiState.Loading,
                    onSubmit = {
                        if (customInput.isNotBlank()) {
                            aiViewModel.generateContentStream(customInput)
                        } else {
                            Toast.makeText(context, "অনুগ্রহ করে প্রশ্ন বা নির্দেশ লিখুন", Toast.LENGTH_SHORT).show()
                        }
                    }
                )
            }
        }

        // Response or State Card
        AnimatedVisibility(
            visible = uiState !is AiUiState.Idle,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            when (val state = uiState) {
                is AiUiState.Loading -> {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(28.dp),
                                color = Color(0xFF15803D),
                                strokeWidth = 3.dp
                            )
                            Column {
                                Text(
                                    text = "Gemini AI উত্তর তৈরি করছে...",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "ভাষার নির্ভুলতা ও সাংগঠনিক রূপরেখা যাচাই করা হচ্ছে",
                                    fontSize = 11.sp,
                                    color = TextMuted
                                )
                            }
                        }
                    }
                }

                is AiUiState.Streaming -> {
                    ResultDisplayCard(
                        content = state.text,
                        isStreaming = true,
                        onCopy = { copyToClipboard(context, state.text) },
                        onShare = { shareText(context, state.text) },
                        onClear = { aiViewModel.resetState() }
                    )
                }

                is AiUiState.Success -> {
                    ResultDisplayCard(
                        content = state.text,
                        isStreaming = false,
                        onCopy = { copyToClipboard(context, state.text) },
                        onShare = { shareText(context, state.text) },
                        onClear = { aiViewModel.resetState() }
                    )
                }

                is AiUiState.Error -> {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFECACA))
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .background(Color(0xFFDC2626), CircleShape)
                                )
                                Text(
                                    text = "AI প্রসেসিং এ ত্রুটি হয়েছে",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = Color(0xFF991B1B)
                                )
                            }
                            Text(
                                text = state.message,
                                fontSize = 12.sp,
                                color = Color(0xFF7F1D1D),
                                lineHeight = 16.sp
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                OutlinedButton(
                                    onClick = { aiViewModel.resetState() },
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDC2626)),
                                    modifier = Modifier.testTag("ai_error_dismiss")
                                ) {
                                    Text("বন্ধ করুন", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }

                AiUiState.Idle -> {}
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun NoticeGeneratorCard(
    selectedType: String,
    onTypeSelect: (String) -> Unit,
    customTopic: String,
    onTopicChange: (String) -> Unit,
    isLoading: Boolean,
    onSubmit: () -> Unit
) {
    val noticeTypes = listOf(
        "শোকবার্তা",
        "জরুরি সাংগঠনিক সভা",
        "জাতীয় দিবস কর্মসূচি",
        "নবনির্বাচিত কমিটির শুভেচ্ছা",
        "বৃক্ষরোপণ কর্মসূচি",
        "স্বেচ্ছায় রক্তদান কর্মসূচি"
    )

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "বিজ্ঞপ্তির ধরণ নির্বাচন করুন:",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                noticeTypes.forEach { type ->
                    val selected = selectedType == type
                    FilterChip(
                        selected = selected,
                        onClick = { onTypeSelect(type) },
                        label = { Text(type, fontSize = 11.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFFDCFCE7),
                            selectedLabelColor = Color(0xFF15803D)
                        )
                    )
                }
            }

            OutlinedTextField(
                value = customTopic,
                onValueChange = onTopicChange,
                label = { Text("সুনির্দিষ্ট বিষয় বা তথ্য (ঐচ্ছিক)", fontSize = 12.sp) },
                placeholder = { Text("যেমন: তারিখ, স্থান, উপস্থিত নেতৃবৃন্দের নাম বা কারণ...", fontSize = 11.sp) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("ai_notice_input"),
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF15803D),
                    unfocusedBorderColor = Color(0xFFE2E8F0)
                ),
                maxLines = 3
            )

            Button(
                onClick = onSubmit,
                enabled = !isLoading,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("ai_notice_generate_button")
            ) {
                Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isLoading) "খসড়া তৈরি হচ্ছে..." else "প্রেস বিজ্ঞপ্তি তৈরি করুন",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SpeechGeneratorCard(
    selectedOccasion: String,
    onOccasionSelect: (String) -> Unit,
    customDetails: String,
    onDetailsChange: (String) -> Unit,
    isLoading: Boolean,
    onSubmit: () -> Unit
) {
    val occasions = listOf(
        "ছাত্র সমাবেশ ও মতবিনিময় সভা",
        "কলেজ শাখার নবীনবরণ",
        "ইউনিয়ন শাখার কর্মী সমাবেশ",
        "স্মার্ট চারঘাট বিনির্মাণ শীর্ষক আলোচনা"
    )

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "অনুষ্ঠানের উপলক্ষ নির্বাচন করুন:",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                occasions.forEach { occasion ->
                    val selected = selectedOccasion == occasion
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onOccasionSelect(occasion) },
                        color = if (selected) Color(0xFFF0FDF4) else Color(0xFFF8FAFC),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (selected) Color(0xFF15803D) else Color(0xFFE2E8F0)
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(vertical = 8.dp, horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(if (selected) Color(0xFF15803D) else Color(0xFF94A3B8), CircleShape)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = occasion,
                                fontSize = 12.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                color = if (selected) Color(0xFF15803D) else TextPrimary
                            )
                        }
                    }
                }
            }

            OutlinedTextField(
                value = customDetails,
                onValueChange = onDetailsChange,
                label = { Text("মূল বিষয় বা স্লোগান (ঐচ্ছিক)", fontSize = 12.sp) },
                placeholder = { Text("বক্তব্যে বিশেষ কোনো নির্দেশ বা তথ্য থাকলে লিখুন...", fontSize = 11.sp) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("ai_speech_input"),
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF15803D),
                    unfocusedBorderColor = Color(0xFFE2E8F0)
                ),
                maxLines = 2
            )

            Button(
                onClick = onSubmit,
                enabled = !isLoading,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("ai_speech_generate_button")
            ) {
                Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isLoading) "পয়েন্ট তৈরি হচ্ছে..." else "বক্তব্যের মূল পয়েন্ট তৈরি করুন",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
private fun ChatGeneratorCard(
    prompt: String,
    onPromptChange: (String) -> Unit,
    isLoading: Boolean,
    onSubmit: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "যেকোনো সাংগঠনিক প্রশ্ন বা সহায়তা চান:",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )

            OutlinedTextField(
                value = prompt,
                onValueChange = onPromptChange,
                label = { Text("আপনার প্রশ্ন বা প্রম্পট লিখুন", fontSize = 12.sp) },
                placeholder = { Text("যেমন: চারঘাট উপজেলার অন্তর্গত ৬টি ইউনিয়নের নাম কী কী?...", fontSize = 11.sp) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .testTag("ai_chat_input"),
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF15803D),
                    unfocusedBorderColor = Color(0xFFE2E8F0)
                )
            )

            // Quick suggestion chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                SuggestionChip(
                    text = "চারঘাট ৬ ইউনিয়নের তালিকা",
                    onClick = { onPromptChange("বাংলাদেশ ছাত্রলীগ চারঘাট উপজেলার আওতাধীন ৬টি ইউনিয়নের নাম এবং সাংগঠনিক কাঠামোর সংক্ষিপ্ত বিবরণ দাও।") }
                )
                SuggestionChip(
                    text = "ছাত্রলীগের মূলনীতি ও ইতিহাস",
                    onClick = { onPromptChange("বাংলাদেশ ছাত্রলীগের মূলনীতি কি এবং সংক্ষেপে এর ঐতিহাসিক অবদান বাংলায় লিখো।") }
                )
            }

            Button(
                onClick = onSubmit,
                enabled = !isLoading && prompt.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("ai_chat_send_button")
            ) {
                Icon(imageVector = Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isLoading) "উত্তর তৈরি হচ্ছে..." else "Gemini কে জিজ্ঞাসা করুন",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
private fun SuggestionChip(
    text: String,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() },
        color = Color(0xFFF1F5F9),
        shape = RoundedCornerShape(16.dp)
    ) {
        Text(
            text = text,
            fontSize = 10.sp,
            color = Color(0xFF475569),
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun ResultDisplayCard(
    content: String,
    isStreaming: Boolean,
    onCopy: () -> Unit,
    onShare: () -> Unit,
    onClear: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFDCFCE7)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("ai_result_card")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(if (isStreaming) Color(0xFFEAB308) else Color(0xFF15803D), CircleShape)
                    )
                    Text(
                        text = if (isStreaming) "AI খসড়া তৈরি করছে..." else "Gemini AI প্রস্তুতকৃত ফলাফল",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Color(0xFF15803D)
                    )
                }

                IconButton(
                    onClick = onClear,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear", tint = TextMuted)
                }
            }

            HorizontalDivider(color = Color(0xFFF1F5F9))

            // Body text with proper Bengali formatting
            SelectionContainerText(content = content)

            HorizontalDivider(color = Color(0xFFF1F5F9))

            // Action buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onCopy,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("ai_copy_button"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF15803D))
                ) {
                    Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("কপি করুন", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onShare,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("ai_share_button"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D))
                ) {
                    Icon(imageVector = Icons.Default.Send, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("শেয়ার করুন", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun SelectionContainerText(content: String) {
    androidx.compose.foundation.text.selection.SelectionContainer {
        Text(
            text = content,
            fontSize = 13.sp,
            color = Color(0xFF1E293B),
            lineHeight = 22.sp,
            fontWeight = FontWeight.Normal
        )
    }
}

private fun copyToClipboard(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText("Gemini Generated Content", text)
    clipboard.setPrimaryClip(clip)
    Toast.makeText(context, "টেক্সট ক্লিপবোর্ডে কপি করা হয়েছে!", Toast.LENGTH_SHORT).show()
}

private fun shareText(context: Context, text: String) {
    val sendIntent = Intent().apply {
        action = Intent.ACTION_SEND
        putExtra(Intent.EXTRA_TEXT, text)
        type = "text/plain"
    }
    val shareIntent = Intent.createChooser(sendIntent, "বিজ্ঞপ্তি বা টেক্সট শেয়ার করুন")
    context.startActivity(shareIntent)
}
