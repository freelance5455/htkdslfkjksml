package com.example.ui.components

import android.content.Intent
import android.net.Uri
import android.widget.VideoView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.GameAmber
import com.example.ui.theme.GameAmberBright
import com.example.ui.theme.GameEmerald
import com.example.ui.theme.GameSurfaceDark
import com.example.ui.theme.GameSurfaceElevated
import com.example.ui.theme.GameViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay

enum class AdRewardTarget(val title: String, val rewardDescription: String, val iconText: String) {
    HINT("💡 Free Hint", "Unlocks the next progressive hint without coins", "💡"),
    REVEAL_LETTER("🔤 Free Reveal Letter", "Reveals 1 correct letter in the slots without coins", "🔤"),
    REMOVE_WRONG("🧹 Free Remove 3 Wrong", "Eliminates 3 incorrect letters from the keyboard", "🧹"),
    COINS_BONUS("🪙 +50 Free Coins", "Awards 50 bonus coins to your balance", "🪙")
}

data class VideoAdCampaign(
    val title: String,
    val developer: String,
    val rating: String,
    val category: String,
    val iconEmoji: String,
    val packageName: String,
    val rawResName: String,
    val remoteVideoUrl: String
)

private val SAMPLE_CAMPAIGNS = listOf(
    VideoAdCampaign(
        title = "Subway Surfers",
        developer = "SYBO Games",
        rating = "★★★★★ 4.6 (44M Reviews)",
        category = "Action • Endless Runner",
        iconEmoji = "🏃",
        packageName = "com.kiloo.subwaysurf",
        rawResName = "subway_surfers",
        remoteVideoUrl = "https://raw.githubusercontent.com/Jitesh117/subwayCLI/master/internal/assets/subway-surfers.mp4"
    ),
    VideoAdCampaign(
        title = "Minecraft",
        developer = "Mojang",
        rating = "★★★★★ 4.6 (5M Reviews)",
        category = "Arcade • Sandbox • Adventure",
        iconEmoji = "🧱",
        packageName = "com.mojang.minecraftpe",
        rawResName = "minecraft",
        remoteVideoUrl = "https://raw.githubusercontent.com/Jitesh117/subwayCLI/master/internal/assets/minecraft-half.mp4"
    ),
    VideoAdCampaign(
        title = "Clash of Clans",
        developer = "Supercell",
        rating = "★★★★★ 4.6 (60M Reviews)",
        category = "Strategy • Build & Battle",
        iconEmoji = "⚔️",
        packageName = "com.supercell.clashofclans",
        rawResName = "clash_action",
        remoteVideoUrl = "https://media.w3.org/2010/05/sintel/trailer.mp4"
    ),
    VideoAdCampaign(
        title = "Candy Crush Saga",
        developer = "King",
        rating = "★★★★★ 4.6 (38M Reviews)",
        category = "Casual • Match 3 Puzzle",
        iconEmoji = "🍬",
        packageName = "com.king.candycrushsaga",
        rawResName = "subway_surfers",
        remoteVideoUrl = "https://raw.githubusercontent.com/Jitesh117/subwayCLI/master/internal/assets/subway-surfers.mp4"
    ),
    VideoAdCampaign(
        title = "Royal Match",
        developer = "Dream Games, Ltd.",
        rating = "★★★★★ 4.7 (10M Reviews)",
        category = "Puzzle • King Rescue",
        iconEmoji = "👑",
        packageName = "com.dreamgames.royalmatch",
        rawResName = "subway_surfers",
        remoteVideoUrl = "https://raw.githubusercontent.com/Jitesh117/subwayCLI/master/internal/assets/subway-surfers.mp4"
    ),
    VideoAdCampaign(
        title = "Free Fire MAX",
        developer = "Garena International I",
        rating = "★★★★★ 4.4 (17M Reviews)",
        category = "Action • Battle Royale",
        iconEmoji = "🔥",
        packageName = "com.dts.freefiremax",
        rawResName = "clash_action",
        remoteVideoUrl = "https://media.w3.org/2010/05/sintel/trailer.mp4"
    ),
    VideoAdCampaign(
        title = "Ludo King®",
        developer = "Gametion Global",
        rating = "★★★★★ 4.3 (10M Reviews)",
        category = "Board • Multiplayer • Dice",
        iconEmoji = "🎲",
        packageName = "com.ludo.king",
        rawResName = "minecraft",
        remoteVideoUrl = "https://raw.githubusercontent.com/Jitesh117/subwayCLI/master/internal/assets/minecraft-half.mp4"
    )
)

private var campaignCycleIndex = 0

@Composable
fun RewardedAdDialog(
    target: AdRewardTarget,
    onRewardEarned: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var secondsRemaining by remember { mutableIntStateOf(5) }
    var isRewardReady by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var isMuted by remember { mutableStateOf(true) }
    var videoViewRef by remember { mutableStateOf<VideoView?>(null) }

    val campaign = remember {
        val c = SAMPLE_CAMPAIGNS[campaignCycleIndex % SAMPLE_CAMPAIGNS.size]
        campaignCycleIndex++
        c
    }

    LaunchedEffect(Unit) {
        val totalSteps = 50
        for (i in 1..totalSteps) {
            delay(100)
            progress = i / totalSteps.toFloat()
            val remaining = 5 - (i / 10)
            secondsRemaining = remaining.coerceAtLeast(0)
        }
        isRewardReady = true
    }

    DisposableEffect(Unit) {
        onDispose {
            videoViewRef?.stopPlayback()
        }
    }

    fun openPlayStoreForCampaign() {
        try {
            val marketIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=${campaign.packageName}"))
            marketIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(marketIntent)
        } catch (e: Exception) {
            try {
                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=${campaign.packageName}"))
                webIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(webIntent)
            } catch (_: Exception) {}
        }
    }

    Dialog(
        onDismissRequest = {
            if (isRewardReady) {
                videoViewRef?.stopPlayback()
                onDismiss()
            }
        },
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = isRewardReady,
            dismissOnClickOutside = false
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
                .testTag("rewarded_ad_dialog")
        ) {
            // Real Fullscreen Video Element
            AndroidView(
                factory = { ctx ->
                    VideoView(ctx).apply {
                        val rawResId = ctx.resources.getIdentifier(campaign.rawResName, "raw", ctx.packageName)
                        val videoUri = if (rawResId != 0) {
                            Uri.parse("android.resource://${ctx.packageName}/$rawResId")
                        } else {
                            Uri.parse(campaign.remoteVideoUrl)
                        }
                        setVideoURI(videoUri)
                        setOnPreparedListener { mp ->
                            mp.isLooping = true
                            if (isMuted) {
                                mp.setVolume(0f, 0f)
                            } else {
                                mp.setVolume(0.7f, 0.7f)
                            }
                            start()
                        }
                        setOnErrorListener { _, _, _ ->
                            // Fallback to remote if raw failed
                            try {
                                setVideoURI(Uri.parse(campaign.remoteVideoUrl))
                                start()
                            } catch (_: Exception) {}
                            true
                        }
                        videoViewRef = this
                    }
                },
                modifier = Modifier.fillMaxSize()
            )

            // Top Header Overlay Bar (Pinned to top)
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Black.copy(alpha = 0.9f),
                                Color.Black.copy(alpha = 0.4f),
                                Color.Transparent
                            )
                        )
                    )
                    .padding(horizontal = 16.dp, vertical = 20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = GameAmber.copy(alpha = 0.3f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, GameAmber)
                        ) {
                            Text(
                                text = "AdMob",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = GameAmberBright,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }

                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable {
                                    isMuted = !isMuted
                                },
                            shape = RoundedCornerShape(12.dp),
                            color = Color.Black.copy(alpha = 0.75f),
                            border = androidx.compose.foundation.BorderStroke(0.5.dp, Color.White.copy(alpha = 0.3f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = if (isMuted) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = if (isMuted) "Unmute" else "Sound",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                    }

                    if (isRewardReady) {
                        Surface(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .clickable {
                                    videoViewRef?.stopPlayback()
                                    onDismiss()
                                },
                            shape = CircleShape,
                            color = Color(0xFFEF4444)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Close Ad",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    } else {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = Color.Black.copy(alpha = 0.8f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, GameAmber.copy(alpha = 0.5f))
                        ) {
                            Text(
                                text = "Reward in ${secondsRemaining}s",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                color = GameAmberBright,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                            )
                        }
                    }
                }
            }

            // Bottom Fullscreen Sponsor & Controls Bar (Pinned to bottom)
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color(0xFF0F172A).copy(alpha = 0.85f),
                                Color(0xFF0F172A),
                                Color.Black
                            )
                        )
                    )
                    .padding(horizontal = 16.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Video Progress Bar
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(5.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = if (isRewardReady) GameEmerald else GameAmber,
                    trackColor = Color(0xFF334155)
                )

                // Sponsor Card
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { openPlayStoreForCampaign() },
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF1E293B).copy(alpha = 0.9f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.15f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = GameViolet,
                                modifier = Modifier.size(44.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(text = campaign.iconEmoji, fontSize = 22.sp)
                                }
                            }
                            Column {
                                Text(
                                    text = campaign.title,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                                Text(
                                    text = "${campaign.rating} • ${campaign.developer}",
                                    fontSize = 10.sp,
                                    color = GameAmberBright,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${campaign.category} • Official Store Ad",
                                    fontSize = 9.sp,
                                    color = TextSecondary
                                )
                            }
                        }

                        Button(
                            onClick = { openPlayStoreForCampaign() },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = GameEmerald),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "INSTALL",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                        }
                    }
                }

                // Reward description pill
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Unlocking: ${target.title}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (isRewardReady) GameEmerald.copy(alpha = 0.25f) else Color(0xFF1E293B)
                    ) {
                        Text(
                            text = if (isRewardReady) "✓ Ready to Claim" else "Playing (Do Not Exit)",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isRewardReady) GameEmerald else GameAmberBright,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }

                // Action Button
                if (isRewardReady) {
                    Button(
                        onClick = {
                            videoViewRef?.stopPlayback()
                            onRewardEarned()
                            onDismiss()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("claim_ad_reward_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GameEmerald,
                            contentColor = Color.White
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Verified,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "CLAIM REWARD NOW! 🎉",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                } else {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(14.dp),
                        color = Color(0xFF1E293B)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = "Watching Video Ad (${secondsRemaining}s remaining)...",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextMuted
                            )
                        }
                    }
                }

                // Monetization info
                Text(
                    text = "Google AdMob Live Monetization • hazimqadir7@gmail.com",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium,
                    color = TextMuted,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
