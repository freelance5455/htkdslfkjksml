package com.example.ui.components

import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ads.AdMobManager
import com.example.ads.AdsManager
import com.example.ads.UnityAdsManager
import com.example.ads.findActivity
import com.example.ui.theme.GameAmber
import com.example.ui.theme.GameAmberBright
import com.example.ui.theme.GameEmerald
import com.example.ui.theme.GameSurfaceDark
import com.example.ui.theme.GameViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay

enum class AdRewardTarget(val title: String, val rewardDescription: String, val iconText: String) {
    HINT("💡 Free Hint", "Unlocks the next progressive hint without coins", "💡"),
    REVEAL_LETTER("🔤 Free Reveal Letter", "Reveals 1 correct letter in the slots without coins", "🔤"),
    REMOVE_WRONG("🧹 Free Remove 3 Wrong", "Eliminates 3 incorrect letters from the keyboard", "🧹"),
    COINS_BONUS("🪙 +50 Free Coins", "Awards 50 bonus coins to your balance", "🪙")
}

@Composable
fun RewardedAdDialog(
    target: AdRewardTarget,
    onRewardEarned: () -> Unit,
    onOpenAdSettings: () -> Unit = {},
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val activity = context.findActivity()
    var isSearching by remember { mutableStateOf(true) }
    var hasLaunchedRealAd by remember { mutableStateOf(false) }
    var unityStatus by remember { mutableStateOf(UnityAdsManager.lastStatus) }
    var admobStatus by remember { mutableStateOf(AdMobManager.lastStatus) }
    var retryAttempt by remember { mutableIntStateOf(0) }

    fun tryLaunchRealSdkAd(): Boolean {
        if (activity != null && AdsManager.isAnyAdReady() && !hasLaunchedRealAd) {
            hasLaunchedRealAd = true
            // Dismiss Compose Dialog first so MainActivity regains window focus for fullscreen AdActivity
            onDismiss()
            Handler(Looper.getMainLooper()).postDelayed({
                AdsManager.showRewardedAd(
                    activity = activity,
                    onUserEarnedReward = { _, _ ->
                        onRewardEarned()
                    },
                    onAdDismissed = {},
                    onFallbackToSimulatedAd = {}
                )
            }, 120L)
            return true
        }
        return false
    }

    LaunchedEffect(retryAttempt) {
        isSearching = true
        hasLaunchedRealAd = false
        AdsManager.forceLoadRealAds(context) {
            Handler(Looper.getMainLooper()).post {
                tryLaunchRealSdkAd()
            }
        }

        // Poll every 250ms for up to 7 seconds so the moment Unity Ads or AdMob loads, it launches the REAL SDK ad
        for (step in 1..28) {
            unityStatus = UnityAdsManager.lastStatus
            admobStatus = AdMobManager.lastStatus
            if (tryLaunchRealSdkAd()) {
                return@LaunchedEffect
            }
            delay(250)
        }
        unityStatus = UnityAdsManager.lastStatus
        admobStatus = AdMobManager.lastStatus
        isSearching = false
    }

    Dialog(
        onDismissRequest = { onDismiss() },
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = false
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF0F172A),
                            Color(0xFF0B0F19),
                            Color(0xFF020617)
                        )
                    )
                )
                .testTag("rewarded_ad_dialog"),
            contentAlignment = Alignment.Center
        ) {
            // Top Close & Settings Bar
            Row(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            onDismiss()
                            onOpenAdSettings()
                        },
                    shape = RoundedCornerShape(8.dp),
                    color = GameEmerald.copy(alpha = 0.2f),
                    border = BorderStroke(1.dp, GameEmerald)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = null,
                            tint = GameEmerald,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "Real Ads Only (Live SDK)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            color = GameEmerald
                        )
                    }
                }

                Surface(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .clickable { onDismiss() },
                    shape = CircleShape,
                    color = Color(0xFF334155)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // Center Live Real Ad Status Card
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp),
                shape = RoundedCornerShape(24.dp),
                color = GameSurfaceDark,
                border = BorderStroke(1.5.dp, if (isSearching) GameAmber else GameViolet)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = target.iconText,
                        fontSize = 44.sp
                    )

                    Text(
                        text = target.title,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White,
                        textAlign = TextAlign.Center
                    )

                    if (isSearching) {
                        Spacer(modifier = Modifier.height(4.dp))
                        CircularProgressIndicator(
                            color = GameEmerald,
                            strokeWidth = 3.dp,
                            modifier = Modifier.size(42.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Loading Real Live Ad from Unity Ads & Google AdMob...",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = GameAmberBright,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "Connecting directly to Unity Ads (${AdsManager.unityGameId}) & Google AdMob...",
                            fontSize = 11.sp,
                            color = TextSecondary,
                            textAlign = TextAlign.Center
                        )
                    } else {
                        Text(
                            text = "Live Ad Server Diagnostic",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = GameAmberBright,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "Check the exact message from Unity & AdMob servers below:",
                            fontSize = 11.sp,
                            color = TextSecondary,
                            textAlign = TextAlign.Center
                        )
                    }

                    // Live SDK Diagnostic Box
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        color = Color(0xFF0F172A),
                        border = BorderStroke(1.dp, Color(0xFF334155))
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "🎮 Unity Ads (Game ID: ${AdsManager.unityGameId} | ${AdsManager.unityRewardedPlacement}):",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFC4B5FD)
                            )
                            Text(
                                text = unityStatus,
                                fontSize = 11.sp,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "🟢 Google AdMob (${AdsManager.admobRewardedUnitId}):",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = GameEmerald
                            )
                            Text(
                                text = admobStatus,
                                fontSize = 11.sp,
                                color = Color.White
                            )
                        }
                    }

                    if (!isSearching) {
                        Button(
                            onClick = {
                                if (!tryLaunchRealSdkAd()) {
                                    retryAttempt++
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("claim_ad_reward_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = GameEmerald,
                                contentColor = Color.Black
                            )
                        ) {
                            Icon(
                                imageVector = if (AdsManager.isAnyAdReady()) Icons.Default.PlayArrow else Icons.Default.Refresh,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (AdsManager.isAnyAdReady()) "PLAY REAL AD NOW" else "RETRY LOADING REAL AD",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    onDismiss()
                                    onOpenAdSettings()
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    text = "Check Ad IDs",
                                    fontSize = 12.sp,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            OutlinedButton(
                                onClick = { onDismiss() },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    text = "Close",
                                    fontSize = 12.sp,
                                    color = TextMuted,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
