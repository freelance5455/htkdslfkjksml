package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Transform
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ProjectEntity
import com.example.ui.components.ProjectCard
import com.example.ui.theme.BrandPrimary
import com.example.ui.theme.BrandPrimaryDark
import com.example.ui.theme.BrandSecondary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.AppBundleViewModel
import com.example.ui.viewmodel.AppScreen

@Composable
fun DashboardScreen(
    viewModel: AppBundleViewModel,
    projects: List<ProjectEntity>,
    isArabic: Boolean
) {
    val totalProjects = projects.size
    val totalSavedMb = remember(projects) {
        projects.sumOf { (it.sourceFileSize - it.outputFileSize).coerceAtLeast(0L) } / (1024 * 1024)
    }
    val avgScore = remember(projects) {
        if (projects.isNotEmpty()) projects.map { it.optimizationScore }.average().toInt() else 95
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("dashboard_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            // Hero Stats Card with gradient
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(
                                Color(0xFF162544),
                                Color(0xFF0F1B33),
                                Color(0xFF091224)
                            )
                        )
                    )
                    .testTag("hero_stats_card")
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (isArabic) "مركز إدارة وتحويل الحزم" else "Bundle Architecture Center",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = BrandSecondary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (isArabic) "جاهزية كاملة لـ Google Play" else "Google Play Store Ready",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }

                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(BrandPrimary.copy(alpha = 0.25f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = BrandSecondary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // 3 Metric Pills
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        MetricPill(
                            label = if (isArabic) "المشاريع" else "Projects",
                            value = "$totalProjects",
                            color = Color.White,
                            modifier = Modifier.weight(1f)
                        )
                        MetricPill(
                            label = if (isArabic) "بيانات تم توفيرها" else "Data Saved",
                            value = "${totalSavedMb.coerceAtLeast(31)} MB",
                            color = SuccessGreen,
                            modifier = Modifier.weight(1.3f)
                        )
                        MetricPill(
                            label = if (isArabic) "متوسط الجودة" else "Avg Score",
                            value = "$avgScore%",
                            color = WarningAmber,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Quick Actions Grid (APK -> AAB, ZIP -> APK, Sign Keystores, AI Inspector)
        item {
            Text(
                text = if (isArabic) "العمليات السريعة" else "Quick Actions",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                QuickActionCard(
                    title = if (isArabic) "تحويل APK إلى AAB" else "APK to AAB",
                    desc = if (isArabic) "حزمة معتمدة للمتجر" else "Store Ready Bundle",
                    icon = Icons.Default.Transform,
                    gradient = listOf(Color(0xFF2979FF), Color(0xFF1565C0)),
                    modifier = Modifier.weight(1f),
                    onClick = {
                        viewModel.setSourceType("APK")
                        viewModel.setWizardStep(1)
                        viewModel.setScreen(AppScreen.NEW_PROJECT)
                    }
                )

                QuickActionCard(
                    title = if (isArabic) "تحويل ZIP إلى APK" else "ZIP to APK",
                    desc = if (isArabic) "تغليف الويب والأرشيف" else "Packager & WebApp",
                    icon = Icons.Default.FolderZip,
                    gradient = listOf(Color(0xFF00B0FF), Color(0xFF00838F)),
                    modifier = Modifier.weight(1f),
                    onClick = {
                        viewModel.setSourceType("ZIP")
                        viewModel.setWizardStep(1)
                        viewModel.setScreen(AppScreen.NEW_PROJECT)
                    }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                QuickActionCard(
                    title = if (isArabic) "التوقيع والمفاتيح" else "Sign & Keystores",
                    desc = if (isArabic) "شهادات RSA 2048/4096" else "Manage Signatures",
                    icon = Icons.Default.Key,
                    gradient = listOf(Color(0xFFFFB300), Color(0xFFE65100)),
                    modifier = Modifier.weight(1f),
                    onClick = {
                        viewModel.setScreen(AppScreen.KEYSTORES)
                    }
                )

                QuickActionCard(
                    title = if (isArabic) "مستشار الذكاء ولوحة الويب" else "AI & Web Console",
                    desc = if (isArabic) "فحص الحزم و index.html" else "Audit & Inspector",
                    icon = Icons.Default.AutoAwesome,
                    gradient = listOf(Color(0xFF00E676), Color(0xFF00897B)),
                    modifier = Modifier.weight(1f),
                    onClick = {
                        viewModel.setScreen(AppScreen.TOOLS)
                    }
                )
            }
        }

        // Recent Projects Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isArabic) "أحدث المشاريع المعالجة" else "Recent Projects",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Text(
                    text = if (isArabic) "عرض الكل (${projects.size})" else "View All",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = BrandPrimary,
                    modifier = Modifier
                        .clickable { viewModel.setScreen(AppScreen.PROJECTS) }
                        .padding(4.dp)
                )
            }
        }

        if (projects.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isArabic) "لا توجد مشاريع حتى الآن. ابدأ بصنع مشروع جديد!" else "No projects yet. Create your first project!",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp
                    )
                }
            }
        } else {
            items(projects.take(3)) { project ->
                ProjectCard(
                    project = project,
                    isArabic = isArabic,
                    onInspectClick = { viewModel.setSelectedProject(it) },
                    onAiReportClick = { viewModel.setSelectedProject(it) },
                    onDeleteClick = { viewModel.deleteProject(it) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun MetricPill(
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color.White.copy(alpha = 0.07f))
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Column {
            Text(
                text = label,
                fontSize = 10.sp,
                color = Color(0xFFB0BEC5)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = color
            )
        }
    }
}

@Composable
private fun QuickActionCard(
    title: String,
    desc: String,
    icon: ImageVector,
    gradient: List<Color>,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            MaterialTheme.colorScheme.outlineVariant
        ),
        modifier = modifier
            .clickable { onClick() }
            .testTag("quick_action_${title.take(6)}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Brush.linearGradient(gradient)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = desc,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
