package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AssistantState
import com.example.data.model.VoiceLanguage
import com.example.ui.components.ArcReactorCore
import com.example.ui.components.SoundWaveVisualizer
import com.example.ui.components.TelemetryHudBar
import com.example.ui.theme.XtraCardBorder
import com.example.ui.theme.XtraCardDark
import com.example.ui.theme.XtraCyanGlow
import com.example.ui.theme.XtraCyanPrimary
import com.example.ui.theme.XtraDarkNavyBg
import com.example.ui.theme.XtraElectricBlue
import com.example.ui.theme.XtraSurfaceDark
import com.example.ui.theme.XtraTextHigh
import com.example.ui.theme.XtraTextMed
import com.example.ui.theme.XtraWarningGold
import com.example.viewmodel.MainViewModel

@Composable
fun DashboardScreen(viewModel: MainViewModel) {
    val assistantState by viewModel.assistantState.collectAsState()
    val isListening by viewModel.voiceManager.isListening.collectAsState()
    val isSpeaking by viewModel.voiceManager.isSpeaking.collectAsState()
    val audioRms by viewModel.voiceManager.speechRms.collectAsState()
    val partialText by viewModel.voiceManager.recognizedPartialText.collectAsState()
    val deviceStatus by viewModel.deviceManager.deviceStatus.collectAsState()
    val language by viewModel.selectedLanguage.collectAsState()

    var textInput by remember { mutableStateOf("") }
    val scrollState = rememberScrollState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        XtraDarkNavyBg,
                        XtraSurfaceDark,
                        Color(0xFF030811)
                    )
                )
            )
            .testTag("dashboard_screen")
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // Telemetry HUD Header
            TelemetryHudBar(
                deviceStatus = deviceStatus,
                isSpeaking = isSpeaking,
                language = language,
                onStopSpeaking = { viewModel.stopSpeaking() },
                onLanguageClick = {
                    val nextLang = when (language) {
                        VoiceLanguage.ENGLISH -> VoiceLanguage.HINDI
                        VoiceLanguage.HINDI -> VoiceLanguage.HINGLISH
                        VoiceLanguage.HINGLISH -> VoiceLanguage.ENGLISH
                    }
                    viewModel.setLanguage(nextLang)
                }
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Main Arc Reactor Core
            ArcReactorCore(
                state = assistantState,
                size = 230.dp,
                onClick = {
                    if (isSpeaking) {
                        viewModel.stopSpeaking()
                    } else if (isListening) {
                        viewModel.voiceManager.stopListening()
                    } else {
                        viewModel.startListening()
                    }
                }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Live Recognized Speech Transcript Card
            AnimatedVisibility(
                visible = partialText.isNotBlank(),
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = XtraCardDark.copy(alpha = 0.9f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, XtraCyanPrimary.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(XtraWarningGold)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "\"$partialText\"",
                            color = XtraTextHigh,
                            fontSize = 14.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Sound Wave Visualizer
            SoundWaveVisualizer(
                isActive = isListening || isSpeaking,
                audioRms = audioRms,
                height = 42.dp
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Quick Command Chips
            Text(
                text = "SYSTEM COMMAND DIRECTIVES",
                color = XtraTextMed,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp,
                modifier = Modifier.align(Alignment.Start)
            )

            Spacer(modifier = Modifier.height(8.dp))

            val quickCommands = listOf(
                "🇮🇳 हिंदी में बोलो" to "हिंदी में बात करो",
                "🙏 नमस्ते XTRA" to "नमस्ते XTRA",
                "🔦 टॉर्च चालू" to "टॉर्च चालू करो",
                "🌦️ मौसम बताओ" to "आज का मौसम बताओ",
                "🔦 Torch" to "Turn on torch",
                "🌦️ Weather" to "What is the weather?",
                "📚 Study Mode" to "Study mode",
                "🎮 Gaming Mode" to "Gaming mode",
                "⚡ Status" to "System status",
                "📺 YouTube" to "Open YouTube",
                "💬 WhatsApp" to "Open WhatsApp",
                "📞 Dial 112" to "Call 112"
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(vertical = 4.dp)
            ) {
                quickCommands.forEach { (label, command) ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(XtraCardDark)
                            .border(1.dp, XtraCardBorder, RoundedCornerShape(20.dp))
                            .clickable { viewModel.handleUserQuery(command) }
                            .padding(horizontal = 14.dp, vertical = 9.dp)
                            .testTag("command_chip_${label.take(4)}")
                    ) {
                        Text(
                            text = label,
                            color = XtraCyanGlow,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Text & Mic Command Bar
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(XtraCardDark)
                    .border(1.dp, if (isListening) XtraWarningGold else XtraCardBorder, RoundedCornerShape(28.dp))
                    .padding(horizontal = 6.dp, vertical = 4.dp)
            ) {
                // Mic Button
                IconButton(
                    onClick = {
                        if (isListening) viewModel.voiceManager.stopListening()
                        else viewModel.startListening()
                    },
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(if (isListening) XtraWarningGold else XtraCyanPrimary.copy(alpha = 0.2f))
                        .testTag("main_mic_button")
                ) {
                    Icon(
                        imageVector = if (isListening) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = "Voice Input",
                        tint = if (isListening) Color.Black else XtraCyanPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                OutlinedTextField(
                    value = textInput,
                    onValueChange = { textInput = it },
                    placeholder = {
                        Text(
                            text = if (isListening) "Listening to voice..." else "Command XTRA or ask anything...",
                            color = XtraTextMed,
                            fontSize = 13.sp
                        )
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = XtraTextHigh,
                        unfocusedTextColor = XtraTextHigh,
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent
                    ),
                    maxLines = 2,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("command_text_input")
                )

                IconButton(
                    onClick = {
                        if (textInput.isNotBlank()) {
                            viewModel.handleUserQuery(textInput)
                            textInput = ""
                        }
                    },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(XtraElectricBlue)
                        .testTag("command_send_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Send",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
