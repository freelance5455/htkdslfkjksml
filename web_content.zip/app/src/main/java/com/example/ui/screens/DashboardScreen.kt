package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.OfflinePin
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.ClientWithBookings
import com.example.data.model.DashboardStats
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.SectionHeaderCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.BackgroundWhite
import com.example.ui.theme.BorderLight
import com.example.ui.theme.GoldBright
import com.example.ui.theme.GoldContainer
import com.example.ui.theme.GoldSecondary
import com.example.ui.theme.NavyContainer
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.StatusCancelledBg
import com.example.ui.theme.StatusCancelledFg
import com.example.ui.theme.StatusCompletedBg
import com.example.ui.theme.StatusCompletedFg
import com.example.ui.theme.StatusConfirmedBg
import com.example.ui.theme.StatusConfirmedFg
import com.example.ui.theme.StatusPendingBg
import com.example.ui.theme.StatusPendingFg
import com.example.ui.theme.SurfaceLightGray
import com.example.ui.theme.TextSecondary
import com.example.utils.CurrencyFormatters

@Composable
fun DashboardScreen(
    stats: DashboardStats,
    recentClients: List<ClientWithBookings>,
    onAddBooking: () -> Unit,
    onOpenClients: () -> Unit,
    onOpenSearch: () -> Unit,
    onOpenReports: () -> Unit,
    onOpenBackup: () -> Unit,
    onOpenClientDetail: (Long) -> Unit,
) {
    Scaffold(
        containerColor = SurfaceLightGray,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding()
                .testTag("dashboard_list"),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                DashboardHeroHeader(onAddBooking = onAddBooking)
            }

            item {
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    SectionHeaderCard(
                        title = "إحصائيات الحجوزات والمالية",
                        icon = Icons.Default.Assessment,
                    )

                    // Row 1: Clients & Bookings
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        KpiCard(
                            title = "إجمالي العملاء",
                            value = stats.totalClients.toString(),
                            icon = Icons.Default.Groups,
                            iconTint = NavyPrimary,
                            badgeBg = GoldContainer,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("kpi_total_clients"),
                        )
                        KpiCard(
                            title = "إجمالي الحجوزات",
                            value = stats.totalBookings.toString(),
                            icon = Icons.Default.ConfirmationNumber,
                            iconTint = StatusCompletedFg,
                            badgeBg = StatusCompletedBg,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("kpi_total_bookings"),
                        )
                    }

                    // Row 2: Upcoming Trips & Confirmed
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        KpiCard(
                            title = "الرحلات القادمة",
                            value = stats.upcomingTrips.toString(),
                            icon = Icons.Default.FlightTakeoff,
                            iconTint = NavyPrimary,
                            badgeBg = GoldContainer,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("kpi_upcoming_trips"),
                        )
                        KpiCard(
                            title = "الحجوزات المؤكدة",
                            value = stats.confirmedCount.toString(),
                            icon = Icons.Default.CheckCircle,
                            iconTint = StatusConfirmedFg,
                            badgeBg = StatusConfirmedBg,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("kpi_confirmed_count"),
                        )
                    }

                    // Row 3: Pending & Cancelled
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        KpiCard(
                            title = "قيد الانتظار",
                            value = stats.pendingCount.toString(),
                            icon = Icons.Default.HourglassTop,
                            iconTint = StatusPendingFg,
                            badgeBg = StatusPendingBg,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("kpi_pending_count"),
                        )
                        KpiCard(
                            title = "الحجوزات الملغاة",
                            value = stats.cancelledCount.toString(),
                            icon = Icons.Default.Cancel,
                            iconTint = StatusCancelledFg,
                            badgeBg = StatusCancelledBg,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("kpi_cancelled_count"),
                        )
                    }

                    // Row 4: Financials (Collected & Remaining)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        KpiCard(
                            title = "إجمالي المحصل",
                            value = CurrencyFormatters.formatMoney(stats.totalCollected),
                            icon = Icons.Default.Payments,
                            iconTint = StatusConfirmedFg,
                            badgeBg = StatusConfirmedBg,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("kpi_total_collected"),
                        )
                        KpiCard(
                            title = "إجمالي المتبقي",
                            value = CurrencyFormatters.formatMoney(stats.totalRemaining),
                            icon = Icons.Default.AccountBalanceWallet,
                            iconTint = StatusPendingFg,
                            badgeBg = StatusPendingBg,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("kpi_total_remaining"),
                        )
                    }
                }
            }

            item {
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    SectionHeaderCard(
                        title = "القائمة الرئيسية السريعة",
                        icon = Icons.Default.AddCircle,
                    )

                    // Primary prominent button: Add New Booking
                    Button(
                        onClick = onAddBooking,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NavyPrimary,
                            contentColor = BackgroundWhite,
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(58.dp)
                            .testTag("nav_add_booking_button"),
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddCircle,
                            contentDescription = null,
                            tint = GoldSecondary,
                            modifier = Modifier.size(24.dp),
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "إضافة حجز جديد",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    QuickNavTile(
                        title = "قائمة العملاء",
                        subtitle = "${stats.totalClients} عميل",
                        icon = Icons.Default.People,
                        onClick = onOpenClients,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("nav_clients_button"),
                    )
                    QuickNavTile(
                        title = "البحث عن عميل",
                        subtitle = "بحث متعدد المعايير",
                        icon = Icons.Default.Search,
                        onClick = onOpenSearch,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("nav_search_button"),
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    QuickNavTile(
                        title = "التقارير",
                        subtitle = "10 تقارير • Excel و PDF",
                        icon = Icons.Default.Assessment,
                        onClick = onOpenReports,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("nav_reports_button"),
                    )
                    QuickNavTile(
                        title = "النسخ الاحتياطي",
                        subtitle = "حفظ واستعادة محلية",
                        icon = Icons.Default.Backup,
                        onClick = onOpenBackup,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("nav_backup_button"),
                    )
                }
            }

            item {
                Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                    SectionHeaderCard(
                        title = "أحدث العملاء والحجوزات",
                        icon = Icons.Default.Groups,
                    )
                }
            }

            if (recentClients.isEmpty()) {
                item {
                    EmptyStateCard(
                        icon = Icons.Default.FlightTakeoff,
                        title = "لا توجد حجوزات مسجلة بعد",
                        subtitle = "ابدأ بإضافة أول عميل وحجز عمرة الآن، وسيتم حفظ جميع البيانات والمستندات محليًا على هاتفك.",
                        actionLabel = "إضافة أول حجز",
                        onAction = onAddBooking,
                        modifier = Modifier.padding(horizontal = 16.dp),
                    )
                }
            } else {
                items(recentClients.take(6), key = { it.client.id }) { item ->
                    val latestBooking = item.bookings.maxByOrNull { it.booking.createdAt }
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .clickable { onOpenClientDetail(item.client.id) }
                            .testTag("recent_client_card_${item.client.clientCode}"),
                        colors = CardDefaults.cardColors(containerColor = BackgroundWhite),
                        border = BorderStroke(1.dp, BorderLight),
                        shape = RoundedCornerShape(14.dp),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = GoldContainer,
                            ) {
                                Text(
                                    text = item.client.clientCode,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = NavyPrimary,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.client.fullName,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = NavyPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                val tripInfo = latestBooking?.let {
                                    "رحلة ${it.booking.tripDate} • المتبقي ${CurrencyFormatters.formatMoney(it.remainingAmount)}"
                                } ?: "لا توجد رحلات"
                                Text(
                                    text = tripInfo,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                            if (latestBooking != null) {
                                StatusBadge(status = latestBooking.booking.status)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DashboardHeroHeader(onAddBooking: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(196.dp)
            .clip(RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp))
            .background(NavyPrimary),
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_umrah_banner),
            contentDescription = "خلفية SD TRAVEL",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            NavyPrimary.copy(alpha = 0.88f),
                            NavyContainer.copy(alpha = 0.72f),
                        ),
                    )
                ),
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(id = R.drawable.img_sd_travel_logo),
                        contentDescription = "شعار SD TRAVEL",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape),
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "SD TRAVEL",
                            style = MaterialTheme.typography.headlineSmall,
                            color = GoldSecondary,
                            fontWeight = FontWeight.Bold,
                        )
                        Text(
                            text = "إدارة حجوزات وعملاء العمرة",
                            style = MaterialTheme.typography.bodySmall,
                            color = BackgroundWhite.copy(alpha = 0.9f),
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(50),
                    color = GoldSecondary.copy(alpha = 0.2f),
                    border = BorderStroke(1.dp, GoldSecondary.copy(alpha = 0.6f)),
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            imageVector = Icons.Default.OfflinePin,
                            contentDescription = null,
                            tint = GoldBright,
                            modifier = Modifier.size(14.dp),
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "بدون إنترنت",
                            style = MaterialTheme.typography.labelSmall,
                            color = GoldBright,
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "لوحة التحكم الرئيسية",
                        style = MaterialTheme.typography.titleLarge,
                        color = BackgroundWhite,
                    )
                    Text(
                        text = "حفظ دائم للمستندات والحسابات محليًا",
                        style = MaterialTheme.typography.bodySmall,
                        color = BackgroundWhite.copy(alpha = 0.8f),
                    )
                }
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = GoldSecondary,
                    modifier = Modifier.clickable { onAddBooking() },
                ) {
                    Text(
                        text = "+ حجز جديد",
                        style = MaterialTheme.typography.labelLarge,
                        color = NavyPrimary,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun KpiCard(
    title: String,
    value: String,
    icon: ImageVector,
    iconTint: Color,
    badgeBg: Color,
    modifier: Modifier = Modifier,
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = BackgroundWhite),
        border = BorderStroke(1.dp, BorderLight),
        shape = RoundedCornerShape(16.dp),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(badgeBg),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(22.dp),
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleLarge,
                    color = NavyPrimary,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun QuickNavTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Card(
        modifier = modifier
            .height(92.dp)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = BackgroundWhite),
        border = BorderStroke(1.dp, BorderLight),
        shape = RoundedCornerShape(16.dp),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(GoldContainer),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = NavyPrimary,
                        modifier = Modifier.size(20.dp),
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    color = NavyPrimary,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}
