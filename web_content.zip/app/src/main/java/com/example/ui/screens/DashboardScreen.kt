package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.entity.TransactionTypes
import com.example.ui.components.AppDestination
import com.example.ui.components.Elevated3DCard
import com.example.ui.components.Stat3DCard
import com.example.ui.theme.DepositBlue
import com.example.ui.theme.DepositBlueLight
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.ExpenseRedLight
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.IncomeGreenLight
import com.example.ui.theme.IslamicEmerald
import com.example.ui.theme.IslamicEmeraldLight
import com.example.ui.theme.IslamicGold
import com.example.ui.theme.IslamicGoldDark
import com.example.ui.theme.IslamicGoldLight
import com.example.ui.theme.IslamicGreenDark
import com.example.ui.theme.IslamicGreenPrimary
import com.example.ui.theme.LoanOrange
import com.example.ui.theme.LoanOrangeLight
import com.example.ui.theme.RepaidPurple
import com.example.ui.theme.RepaidPurpleLight
import com.example.ui.theme.TextPrimary
import com.example.ui.util.BanglaHelper
import com.example.ui.viewmodel.FinanceViewModel

@Composable
fun DashboardScreen(
    viewModel: FinanceViewModel,
    onNavigate: (AppDestination) -> Unit,
    modifier: Modifier = Modifier
) {
    val summary by viewModel.dashboardSummary.collectAsStateWithLifecycle()
    val transactions by viewModel.allTransactions.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- 1. Top Balance Banner Card ---
        item {
            Elevated3DCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dashboard_balance_card"),
                elevation = 4f
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(
                                    IslamicGreenDark,
                                    IslamicGreenPrimary
                                )
                            )
                        )
                        .padding(20.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "বর্তমান ব্যালেন্স",
                                fontSize = 14.sp,
                                color = IslamicGoldLight,
                                fontWeight = FontWeight.Medium
                            )
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = IslamicGold.copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = "সর্বমোট স্থিতি",
                                    color = IslamicGold,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = BanglaHelper.formatCurrency(summary.overallBalance),
                            fontSize = 28.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "মোট আয়",
                                    fontSize = 11.sp,
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                                Text(
                                    text = BanglaHelper.formatCurrency(summary.totalIncome),
                                    fontSize = 14.sp,
                                    color = Color(0xFFA7F3D0),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Column {
                                Text(
                                    text = "মোট খরচ",
                                    fontSize = 11.sp,
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                                Text(
                                    text = BanglaHelper.formatCurrency(summary.totalExpense),
                                    fontSize = 14.sp,
                                    color = Color(0xFFFECDD3),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Column {
                                Text(
                                    text = "বাকি ঋণ",
                                    fontSize = 11.sp,
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                                Text(
                                    text = BanglaHelper.formatCurrency(summary.remainingLoan),
                                    fontSize = 14.sp,
                                    color = Color(0xFFFDE68A),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // --- 2. Quick Action Buttons Row ---
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickActionPill(
                    title = "আয় যোগ",
                    icon = Icons.Default.Add,
                    color = IncomeGreen,
                    bgColor = IncomeGreenLight,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate(AppDestination.INCOME) }
                )
                QuickActionPill(
                    title = "খরচ যোগ",
                    icon = Icons.Default.Add,
                    color = ExpenseRed,
                    bgColor = ExpenseRedLight,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate(AppDestination.EXPENSE) }
                )
                QuickActionPill(
                    title = "জমা যোগ",
                    icon = Icons.Default.Add,
                    color = DepositBlue,
                    bgColor = DepositBlueLight,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate(AppDestination.DEPOSIT) }
                )
                QuickActionPill(
                    title = "দ্রুত যোগ",
                    icon = Icons.Default.Add,
                    color = IslamicGoldDark,
                    bgColor = IslamicGoldLight,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate(AppDestination.QUICK_ADD) }
                )
            }
        }

        // --- 3. আজকের হিসাব Section ---
        item {
            SectionTitle(title = "আজকের হিসাব", icon = Icons.Default.CheckCircle)
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Stat3DCard(
                        title = "আজকের মোট আয়",
                        amountText = BanglaHelper.formatCurrency(summary.todayIncome),
                        icon = Icons.Default.ArrowUpward,
                        iconTint = IncomeGreen,
                        iconBgColor = IncomeGreenLight,
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigate(AppDestination.INCOME) }
                    )
                    Stat3DCard(
                        title = "আজকের মোট খরচ",
                        amountText = BanglaHelper.formatCurrency(summary.todayExpense),
                        icon = Icons.Default.ArrowDownward,
                        iconTint = ExpenseRed,
                        iconBgColor = ExpenseRedLight,
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigate(AppDestination.EXPENSE) }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Stat3DCard(
                        title = "আজকের মোট জমা",
                        amountText = BanglaHelper.formatCurrency(summary.todayDeposit),
                        icon = Icons.Default.Savings,
                        iconTint = DepositBlue,
                        iconBgColor = DepositBlueLight,
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigate(AppDestination.DEPOSIT) }
                    )
                    Stat3DCard(
                        title = "আজকের ঋণ গ্রহণ",
                        amountText = BanglaHelper.formatCurrency(summary.todayLoan),
                        icon = Icons.Default.Handshake,
                        iconTint = LoanOrange,
                        iconBgColor = LoanOrangeLight,
                        modifier = Modifier.weight(1f),
                        onClick = { onNavigate(AppDestination.LOAN) }
                    )
                }

                Stat3DCard(
                    title = "আজকের ঋণ পরিশোধ",
                    amountText = BanglaHelper.formatCurrency(summary.todayLoanRepaid),
                    icon = Icons.Default.CheckCircle,
                    iconTint = RepaidPurple,
                    iconBgColor = RepaidPurpleLight,
                    onClick = { onNavigate(AppDestination.LOAN) }
                )
            }
        }

        // --- 4. এই মাসের হিসাব Section ---
        item {
            SectionTitle(title = "এই মাসের হিসাব", icon = Icons.Default.AccountBalance)
        }

        item {
            Elevated3DCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("this_month_summary_card"),
                elevation = 3f
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    ReportRow(
                        label = "মাসের মোট আয়",
                        value = BanglaHelper.formatCurrency(summary.monthIncome),
                        color = IncomeGreen
                    )
                    ReportRow(
                        label = "মাসের মোট খরচ",
                        value = BanglaHelper.formatCurrency(summary.monthExpense),
                        color = ExpenseRed
                    )
                    ReportRow(
                        label = "মাসের মোট জমা",
                        value = BanglaHelper.formatCurrency(summary.monthDeposit),
                        color = DepositBlue
                    )
                    ReportRow(
                        label = "মাসের মোট ঋণ গ্রহণ",
                        value = BanglaHelper.formatCurrency(summary.monthLoan),
                        color = LoanOrange
                    )
                    ReportRow(
                        label = "মাসের মোট ঋণ পরিশোধ",
                        value = BanglaHelper.formatCurrency(summary.monthLoanRepaid),
                        color = RepaidPurple
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(Color(0xFFE5EBE7))
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "মাসের বর্তমান ব্যালেন্স",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = BanglaHelper.formatCurrency(summary.monthBalance),
                            fontSize = 17.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (summary.monthBalance >= 0) IncomeGreen else ExpenseRed
                        )
                    }
                }
            }
        }

        // --- 5. সাম্প্রতিক লেনদেন Section ---
        item {
            SectionTitle(title = "সাম্প্রতিক লেনদেন", icon = Icons.Default.AccountBalanceWallet)
        }

        if (transactions.isEmpty()) {
            item {
                Elevated3DCard(
                    modifier = Modifier.fillMaxWidth(),
                    elevation = 1f
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "এখনো কোনো লেনদেন যোগ করা হয়নি",
                            color = Color(0xFF6B7280),
                            fontSize = 14.sp
                        )
                    }
                }
            }
        } else {
            items(transactions.take(5)) { tx ->
                val isIncome = tx.type == TransactionTypes.INCOME ||
                        tx.type == TransactionTypes.POND_INCOME ||
                        tx.type == TransactionTypes.MADRASAH_SALARY_INCOME ||
                        tx.type == TransactionTypes.MOSQUE_SALARY_INCOME

                val isDeposit = tx.type == TransactionTypes.DEPOSIT

                val itemColor = when {
                    isIncome -> IncomeGreen
                    isDeposit -> DepositBlue
                    else -> ExpenseRed
                }

                val itemBgColor = when {
                    isIncome -> IncomeGreenLight
                    isDeposit -> DepositBlueLight
                    else -> ExpenseRedLight
                }

                Elevated3DCard(
                    modifier = Modifier.fillMaxWidth(),
                    elevation = 2f
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(itemBgColor),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isIncome) Icons.Default.ArrowUpward
                                else if (isDeposit) Icons.Default.Savings
                                else Icons.Default.ArrowDownward,
                                contentDescription = tx.categoryLabel,
                                tint = itemColor,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = tx.description.ifBlank { tx.categoryLabel },
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${BanglaHelper.formatBanglaDate(tx.date)} • ${tx.categoryLabel}",
                                fontSize = 11.sp,
                                color = Color(0xFF6B7280)
                            )
                        }

                        Text(
                            text = (if (isIncome) "+ " else if (isDeposit) " " else "- ") +
                                    BanglaHelper.formatCurrency(tx.amount),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = itemColor
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SectionTitle(title: String, icon: ImageVector) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 4.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = IslamicGreenPrimary,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = title,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )
    }
}

@Composable
fun QuickActionPill(
    title: String,
    icon: ImageVector,
    color: Color,
    bgColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Elevated3DCard(
        modifier = modifier,
        elevation = 2f,
        backgroundColor = bgColor,
        onClick = onClick
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = color,
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = color
            )
        }
    }
}

@Composable
fun ReportRow(label: String, value: String, color: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            fontSize = 13.sp,
            color = Color(0xFF4B5563)
        )
        Text(
            text = value,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = color
        )
    }
}
