package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.ui.components.ProfitLossBadge
import com.example.ui.viewmodel.BusinessViewModel
import com.example.util.BackupManager
import com.example.util.CsvDownloadResult
import com.example.util.CsvExportHelper
import com.example.util.DateFilter
import com.example.util.FinancialMath

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DashboardScreen(
    viewModel: BusinessViewModel,
    onNavigateToWithdrawal: () -> Unit,
    onNavigateToBillPayment: () -> Unit,
    onNavigateToExpenses: () -> Unit,
    onNavigateToReports: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val summary by viewModel.dashboardSummary.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val dateFilter by viewModel.dateFilter.collectAsStateWithLifecycle()
    val periodTransactions by viewModel.filteredTransactions.collectAsStateWithLifecycle()
    val allTransactions by viewModel.allTransactions.collectAsStateWithLifecycle()

    // View mode for transactions on dashboard: All Time by default so all records are visible
    var showAllTransactionsOnDashboard by remember { mutableStateOf(true) }
    val displayTransactions = if (showAllTransactionsOnDashboard) allTransactions else periodTransactions

    // Dialog states
    var transactionToDelete by remember { mutableStateOf<TransactionEntity?>(null) }
    var transactionToEditWithdrawal by remember { mutableStateOf<TransactionEntity?>(null) }
    var transactionToEditBill by remember { mutableStateOf<TransactionEntity?>(null) }

    // Download / Export dialog state
    var downloadDialogData by remember { mutableStateOf<CsvDownloadResult?>(null) }
    var lastExportedCsvContent by remember { mutableStateOf("") }

    // Reset All Values dialog
    var showResetDialog by remember { mutableStateOf(false) }
    var showConfirmClearDataDialog by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Business Header with Reset button
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = settings.businessName,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Credit Card Withdrawal & Bill Payment Engine",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            OutlinedButton(
                onClick = { showResetDialog = true },
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("reset_all_dashboard_values_button")
            ) {
                Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Reset", fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Period filter chips
        Text(
            text = "Reporting Period",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp)
        ) {
            DateFilter.entries.forEach { filter ->
                FilterChip(
                    selected = dateFilter == filter,
                    onClick = { viewModel.setDateFilter(filter) },
                    label = { Text(filter.label, fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                    ),
                    modifier = Modifier.testTag("date_filter_${filter.name.lowercase()}")
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Hero Net Profit Card
        ElevatedCard(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.elevatedCardColors(
                containerColor = if (summary.netProfit >= 0) Color(0xFF0F2B26) else Color(0xFF3B1516)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("net_profit_hero_card")
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "CONSOLIDATED NET PROFIT",
                        color = Color(0xFFD1E7DD),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (summary.netProfit >= 0) Color(0xFF198754) else Color(0xFFDC3545)
                    ) {
                        Text(
                            text = if (summary.netProfit >= 0) "PROFITABLE" else "NET LOSS",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = FinancialMath.formatInr(summary.netProfit),
                    color = Color.White,
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.ExtraBold
                )

                Text(
                    text = "Gross Profit: ${FinancialMath.formatInr(summary.grossProfit)}  •  Expenses: ${FinancialMath.formatInr(summary.operatingExpenses)}",
                    color = Color(0xFFE2E8F0),
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 4.dp)
                )

                HorizontalDivider(
                    color = Color.White.copy(alpha = 0.2f),
                    modifier = Modifier.padding(vertical = 12.dp)
                )

                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text("Total Volume", color = Color(0xFFCBD5E1), fontSize = 11.sp)
                        Text(
                            FinancialMath.formatInr(summary.totalVolume),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                    Column {
                        Text("Gross Profit", color = Color(0xFFCBD5E1), fontSize = 11.sp)
                        Text(
                            FinancialMath.formatInr(summary.grossProfit),
                            color = Color(0xFF4ADE80),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                    Column {
                        Text("Expenses", color = Color(0xFFCBD5E1), fontSize = 11.sp)
                        Text(
                            FinancialMath.formatInr(summary.operatingExpenses),
                            color = Color(0xFFFCA5A5),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Quick Entry Buttons & Download CSV Action
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(
                onClick = onNavigateToWithdrawal,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                modifier = Modifier
                    .weight(1f)
                    .testTag("quick_add_withdrawal")
            ) {
                Icon(Icons.Default.CreditCard, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Withdrawal", fontSize = 13.sp)
            }

            Button(
                onClick = onNavigateToBillPayment,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                modifier = Modifier
                    .weight(1f)
                    .testTag("quick_add_bill_payment")
            ) {
                Icon(Icons.Default.Receipt, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Bill Pay", fontSize = 13.sp)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Download CSV from Dashboard Bar
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Download Transactions CSV",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        text = "Exports ${if (showAllTransactionsOnDashboard) allTransactions.size else periodTransactions.size} transactions to your Downloads folder",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp
                    )
                }

                Button(
                    onClick = {
                        val txs = if (showAllTransactionsOnDashboard) allTransactions else periodTransactions
                        if (txs.isEmpty()) {
                            Toast.makeText(context, "No transactions to download for current view", Toast.LENGTH_SHORT).show()
                        } else {
                            val csv = BackupManager.exportTransactionsToCsv(txs)
                            lastExportedCsvContent = csv
                            val fileName = "CredPay_Transactions_${if (showAllTransactionsOnDashboard) "ALL" else dateFilter.name}_${System.currentTimeMillis()}.csv"
                            val result = CsvExportHelper.downloadAndShareCsv(
                                context = context,
                                csvContent = csv,
                                fileName = fileName,
                                title = "CredPay Transactions CSV"
                            )
                            downloadDialogData = result
                        }
                    },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    modifier = Modifier.testTag("dashboard_download_csv_button")
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Download CSV", fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Key Business Volumes & Collections
        Text(
            text = "Business Volumes & Customer Flows",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            StatCard(
                title = "Total Volume",
                value = FinancialMath.formatInr(summary.totalVolume),
                subtitle = "${summary.withdrawalCount + summary.billPaymentCount} transactions",
                icon = Icons.Default.AccountBalance,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.weight(1f)
            )
            StatCard(
                title = "Total Commission",
                value = FinancialMath.formatInr(summary.totalCommissionReceived),
                subtitle = "Platform payouts",
                icon = Icons.AutoMirrored.Filled.TrendingUp,
                color = Color(0xFF0D652D),
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            StatCard(
                title = "Platform Fees Paid",
                value = FinancialMath.formatInr(summary.totalPlatformFees),
                subtitle = "Covered in customer payout",
                icon = Icons.AutoMirrored.Filled.TrendingDown,
                color = Color(0xFFB06000),
                modifier = Modifier.weight(1f)
            )
            StatCard(
                title = "Customer Charges",
                value = FinancialMath.formatInr(summary.totalCustomerCharges),
                subtitle = "Collected from bill customers",
                icon = Icons.Default.ReceiptLong,
                color = MaterialTheme.colorScheme.tertiary,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Separate Withdrawal Summary Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.CreditCard,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Withdrawal Operations",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "${summary.withdrawalCount} txns",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                MetricRow("Total Withdrawal Volume", FinancialMath.formatInr(summary.withdrawalVolume))
                MetricRow("Customer Payouts", FinancialMath.formatInr(summary.totalCustomerPayouts))
                MetricRow("Platform Fees Incurred", FinancialMath.formatInr(summary.withdrawalPlatformFees))
                MetricRow("Commission Received", FinancialMath.formatInr(summary.withdrawalCommission))
                MetricRow("Tx Charges Collected", FinancialMath.formatInr(summary.totalTransactionCharges))

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Withdrawal Gross Profit", fontWeight = FontWeight.Bold)
                    ProfitLossBadge(amount = summary.withdrawalGrossProfit, label = "Gross Profit")
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Separate Bill Payment Summary Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.secondary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.Receipt,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Bill Payment Operations",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "${summary.billPaymentCount} txns",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                MetricRow("Bill Payment Volume", FinancialMath.formatInr(summary.billPaymentVolume))
                MetricRow("Customer Charges Collected", FinancialMath.formatInr(summary.totalCustomerCharges))
                MetricRow("Service Charges Retained", FinancialMath.formatInr(summary.totalBillServiceCharges))
                MetricRow("Platform Fees Paid", FinancialMath.formatInr(summary.billPlatformFees))
                MetricRow("Commission Received", FinancialMath.formatInr(summary.billCommission))

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Bill Payment Gross Profit", fontWeight = FontWeight.Bold)
                    ProfitLossBadge(amount = summary.billGrossProfit, label = "Gross Profit")
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Operating Expenses Summary
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFC5221F)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.MoneyOff,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Operating Expenses",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "${summary.expenseCount} entries",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                MetricRow("Total Operating Expenses", FinancialMath.formatInr(summary.operatingExpenses))
                MetricRow("Paid Expenses", FinancialMath.formatInr(summary.paidExpenses))
                MetricRow("Unpaid / Scheduled Expenses", FinancialMath.formatInr(summary.unpaidExpenses))

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedButton(
                    onClick = onNavigateToExpenses,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Manage Expenses & Schedules")
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Transactions Done Section on Dashboard (Direct View, Edit and Delete)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                Text(
                    text = "Transactions Done (${displayTransactions.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (showAllTransactionsOnDashboard) "Showing all saved records" else "Filtered by ${dateFilter.label}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp
                )
            }

            // View toggle: Period vs All Time
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                FilterChip(
                    selected = !showAllTransactionsOnDashboard,
                    onClick = { showAllTransactionsOnDashboard = false },
                    label = { Text("Period", fontSize = 11.sp) }
                )
                FilterChip(
                    selected = showAllTransactionsOnDashboard,
                    onClick = { showAllTransactionsOnDashboard = true },
                    label = { Text("All (${allTransactions.size})", fontSize = 11.sp) }
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (displayTransactions.isEmpty()) {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp)
                ) {
                    Text("No transactions in this view", fontWeight = FontWeight.SemiBold)
                    Text(
                        if (allTransactions.isNotEmpty() && !showAllTransactionsOnDashboard)
                            "Switch to 'All (${allTransactions.size})' above or click 'Save to Dashboard' in Withdrawal/Bill Pay."
                        else
                            "Use Withdrawal or Bill Pay calculators and click 'Save to Dashboard' to record transactions.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                    if (allTransactions.isNotEmpty() && !showAllTransactionsOnDashboard) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = { showAllTransactionsOnDashboard = true },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("View All ${allTransactions.size} Transactions", fontSize = 12.sp)
                        }
                    }
                }
            }
        } else {
            displayTransactions.forEach { tx ->
                if (tx.type == TransactionType.WITHDRAWAL.name) {
                    WithdrawalTransactionCard(
                        transaction = tx,
                        onDuplicate = { viewModel.duplicateTransaction(tx) },
                        onEdit = { transactionToEditWithdrawal = tx },
                        onDelete = { transactionToDelete = tx }
                    )
                } else {
                    BillTransactionCard(
                        transaction = tx,
                        onDuplicate = { viewModel.duplicateTransaction(tx) },
                        onEdit = { transactionToEditBill = tx },
                        onDelete = { transactionToDelete = tx }
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }

    // Delete confirmation dialog
    transactionToDelete?.let { tx ->
        AlertDialog(
            onDismissRequest = { transactionToDelete = null },
            title = { Text("Delete Transaction") },
            text = { Text("Are you sure you want to delete transaction ${tx.txId} for ${FinancialMath.formatInr(tx.amount)}? This action cannot be undone.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteTransaction(tx.id)
                        transactionToDelete = null
                        Toast.makeText(context, "Transaction deleted successfully", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("confirm_delete_tx_button")
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { transactionToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Edit Withdrawal Dialog
    transactionToEditWithdrawal?.let { tx ->
        EditWithdrawalDialog(
            transaction = tx,
            onDismiss = { transactionToEditWithdrawal = null },
            onSave = { updated ->
                viewModel.updateTransaction(updated)
                transactionToEditWithdrawal = null
                Toast.makeText(context, "Transaction updated!", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Edit Bill Dialog
    transactionToEditBill?.let { tx ->
        EditBillDialog(
            transaction = tx,
            onDismiss = { transactionToEditBill = null },
            onSave = { updated ->
                viewModel.updateTransaction(updated)
                transactionToEditBill = null
                Toast.makeText(context, "Transaction updated!", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // CSV Download Result Dialog
    downloadDialogData?.let { res ->
        AlertDialog(
            onDismissRequest = { downloadDialogData = null },
            icon = { Icon(Icons.Default.Download, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
            title = { Text(if (res.isSuccess) "CSV Downloaded Successfully" else "Export Failed") },
            text = {
                Column {
                    if (res.isSuccess) {
                        Text("File saved to device Downloads:")
                        Text(
                            text = res.filePath,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(vertical = 6.dp)
                        )
                        Text(
                            text = "Ready to open in Excel, Google Sheets, or any CSV reader.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        Text("Error saving CSV: ${res.errorMessage}")
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        CsvExportHelper.copyToClipboard(context, lastExportedCsvContent, res.fileName)
                    }
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Copy CSV")
                }
            },
            dismissButton = {
                TextButton(onClick = { downloadDialogData = null }) {
                    Text("Done")
                }
            }
        )
    }

    // Reset Options Dialog
    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            icon = { Icon(Icons.Default.RestartAlt, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
            title = { Text("Reset Options") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Choose what you would like to reset:", style = MaterialTheme.typography.bodySmall)

                    OutlinedButton(
                        onClick = {
                            viewModel.setDateFilter(DateFilter.ALL_TIME)
                            showAllTransactionsOnDashboard = true
                            showResetDialog = false
                            Toast.makeText(context, "Filters reset to All Time", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Reset Period Filters to All Time")
                    }

                    Button(
                        onClick = {
                            showResetDialog = false
                            showConfirmClearDataDialog = true
                        },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.DeleteForever, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Clear All App Data & Transactions")
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Confirm Clear All Data Dialog
    if (showConfirmClearDataDialog) {
        AlertDialog(
            onDismissRequest = { showConfirmClearDataDialog = false },
            title = { Text("Clear All Business Data?") },
            text = { Text("This will permanently delete all recorded transactions, customer payouts, and expense logs from the device database. Are you sure?") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearAllData()
                        showConfirmClearDataDialog = false
                        Toast.makeText(context, "All business data cleared successfully", Toast.LENGTH_LONG).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Yes, Clear Everything")
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmClearDataDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun MetricRow(label: String, value: String) {
    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
        ),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Medium
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 11.sp
            )
        }
    }
}
