package com.example.ui.screens

import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AddTask
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.EventAvailable
import androidx.compose.material.icons.rounded.InstallMobile
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.ProjectEntity
import com.example.data.model.ProjectStatus
import com.example.data.model.TaskEntity
import com.example.data.model.TaskPriority
import com.example.data.model.TaskStatus
import com.example.data.model.TaskWithMeta
import com.example.ui.components.CompletionRing
import com.example.ui.components.EmptyProjectsIllustration
import com.example.ui.components.ProjectCard
import com.example.ui.components.QuickActionTile
import com.example.ui.components.TaskCard
import com.example.ui.components.WeeklyProductivityChart
import com.example.ui.components.WorkspaceHeroBanner
import com.example.ui.theme.PriorityHighColor
import com.example.ui.theme.PriorityUrgentColor
import com.example.ui.viewmodel.WorkspaceUiState
import com.example.util.formatDurationPersian
import com.example.util.startOfDayMillis
import com.example.util.toPersianDigits

private enum class TimelineFilter(val labelFa: String) {
    ALL("همه موعدها"),
    TODAY("امروز"),
    TOMORROW("فردا"),
    WEEK("این هفته"),
    OVERDUE("عقب‌افتاده")
}

@Composable
fun DashboardScreen(
    ownerName: String,
    uiState: WorkspaceUiState,
    onEditOwnerName: () -> Unit,
    onNewProjectClick: () -> Unit,
    onNewTaskClick: () -> Unit,
    onOpenTemplatesClick: () -> Unit,
    onLoadStarterTemplate: () -> Unit,
    onOpenFocusTab: () -> Unit,
    onOpenAppDownloadCenter: () -> Unit,
    onDownloadReportClick: () -> Unit,
    onOpenProject: (Long) -> Unit,
    onTogglePinProject: (ProjectEntity) -> Unit,
    onViewAllProjects: () -> Unit,
    onTaskClick: (TaskWithMeta) -> Unit,
    onToggleTaskDone: (TaskEntity) -> Unit,
    onAdvanceTaskStatus: (TaskEntity) -> Unit,
    onToggleBookmarkTask: (TaskEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    if (uiState.isLoading) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    var searchQuery by remember { mutableStateOf("") }
    var timelineFilter by remember { mutableStateOf(TimelineFilter.ALL) }

    val activeProjects = remember(uiState.projects) {
        uiState.projects.filter { it.project.status == ProjectStatus.ACTIVE.name }
    }
    val pendingTasks = remember(uiState.tasks) {
        uiState.tasks.filter { it.task.status != TaskStatus.DONE.name }
    }
    val filteredProjects = remember(uiState.projects, searchQuery) {
        if (searchQuery.isBlank()) uiState.projects
        else uiState.projects.filter {
            it.project.title.contains(searchQuery, ignoreCase = true) ||
                it.project.description.contains(searchQuery, ignoreCase = true)
        }
    }

    val todayStart = remember { startOfDayMillis(System.currentTimeMillis()) }
    val dayMs = 86_400_000L

    val priorityQueue = remember(pendingTasks, searchQuery, timelineFilter) {
        pendingTasks.filter { meta ->
            val matchQuery = searchQuery.isBlank() ||
                meta.task.title.contains(searchQuery, ignoreCase = true) ||
                meta.projectTitle.contains(searchQuery, ignoreCase = true) ||
                meta.task.tag.contains(searchQuery, ignoreCase = true)

            val due = meta.task.dueDateMillis
            val matchTime = when (timelineFilter) {
                TimelineFilter.ALL -> true
                TimelineFilter.TODAY -> due != null && startOfDayMillis(due) == todayStart
                TimelineFilter.TOMORROW -> due != null && startOfDayMillis(due) == todayStart + dayMs
                TimelineFilter.WEEK -> due != null && startOfDayMillis(due) in todayStart..(todayStart + 7 * dayMs)
                TimelineFilter.OVERDUE -> due != null && startOfDayMillis(due) < todayStart
            }
            matchQuery && matchTime
        }.sortedWith(
            compareByDescending<TaskWithMeta> { it.task.bookmarked }
                .thenByDescending { TaskPriority.fromName(it.task.priority).weight }
                .thenBy { it.task.dueDateMillis ?: Long.MAX_VALUE }
        ).take(10)
    }

    val animatedUrgent by animateIntAsState(
        targetValue = uiState.urgentTasksCount,
        animationSpec = tween(450),
        label = "kpi_urgent"
    )
    val animatedDonePoints by animateIntAsState(
        targetValue = uiState.doneStoryPoints,
        animationSpec = tween(450),
        label = "kpi_points"
    )
    val animatedOverdue by animateIntAsState(
        targetValue = uiState.overdueTasksCount,
        animationSpec = tween(450),
        label = "kpi_overdue"
    )

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 920.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                WorkspaceHeroBanner(
                    ownerName = ownerName,
                    activeProjectsCount = activeProjects.size,
                    pendingTasksCount = pendingTasks.size,
                    completionPercent = (uiState.overallCompletionRate * 100).toInt(),
                    activeStreakDays = uiState.activeStreakDays,
                    onEditOwnerName = onEditOwnerName,
                    onNewProjectClick = onNewProjectClick,
                    onOpenTemplatesClick = onOpenTemplatesClick,
                    onOpenAppDownloadCenter = onOpenAppDownloadCenter
                )
            }

            if (uiState.projects.isEmpty()) {
                item {
                    Card(
                        shape = MaterialTheme.shapes.extraLarge,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            EmptyProjectsIllustration()
                            Text(
                                text = stringResource(R.string.empty_projects_title),
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = stringResource(R.string.empty_projects_subtitle),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Button(
                                onClick = onNewProjectClick,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("empty_create_project_button")
                            ) {
                                Icon(Icons.Rounded.Add, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text(stringResource(R.string.action_create_first_project))
                            }
                            OutlinedButton(
                                onClick = onLoadStarterTemplate,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("load_template_button")
                            ) {
                                Icon(Icons.Rounded.AutoAwesome, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text(stringResource(R.string.action_load_template))
                            }
                        }
                    }
                }
            } else {
                // Global Search Bar across personal projects & tasks
                item {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("جست‌وجوی سریع در پروژه‌ها و تسک‌های من...") },
                        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = "جست‌وجو") },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Rounded.Close, contentDescription = "پاک کردن")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("dashboard_search_input")
                    )
                }

                // 2x2 Quick Action Command Dock
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            QuickActionTile(
                                icon = Icons.Rounded.AddTask,
                                title = "تسک سریع",
                                subtitle = "ثبت کار جدید",
                                accent = MaterialTheme.colorScheme.primary,
                                onClick = onNewTaskClick,
                                modifier = Modifier.weight(1f),
                                testTag = "quick_action_new_task"
                            )
                            QuickActionTile(
                                icon = Icons.Rounded.AutoAwesome,
                                title = "قالب آماده",
                                subtitle = "۴ سناریوی حرفه‌ای",
                                accent = MaterialTheme.colorScheme.tertiary,
                                onClick = onOpenTemplatesClick,
                                modifier = Modifier.weight(1f),
                                testTag = "quick_action_templates"
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            QuickActionTile(
                                icon = Icons.Rounded.Timer,
                                title = "تایمر تمرکز",
                                subtitle = formatDurationPersian(uiState.todayFocusMinutes) + " امروز",
                                accent = MaterialTheme.colorScheme.secondary,
                                onClick = onOpenFocusTab,
                                modifier = Modifier.weight(1f),
                                testTag = "quick_action_focus"
                            )
                            QuickActionTile(
                                icon = Icons.Rounded.InstallMobile,
                                title = "APK و دسکتاپ",
                                subtitle = "دانلود و اشتراک‌گذاری",
                                accent = PriorityHighColor,
                                onClick = onOpenAppDownloadCenter,
                                modifier = Modifier.weight(1f),
                                testTag = "quick_action_download_apk"
                            )
                        }
                    }
                }

                // Bento KPI Row
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Card(
                            shape = MaterialTheme.shapes.large,
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                CompletionRing(progress = uiState.overallCompletionRate)
                                Text(
                                    text = "پیشرفت کل تسک‌ها",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center
                                )
                                val doneCount = uiState.tasks.count { it.task.status == TaskStatus.DONE.name }
                                Text(
                                    text = "${doneCount.toPersianDigits()} از ${uiState.tasks.size.toPersianDigits()} تکمیل شده",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            KpiMiniCard(
                                icon = Icons.Rounded.Bolt,
                                iconTint = PriorityHighColor,
                                label = "کارهای فوری و بالا",
                                value = "${animatedUrgent.toPersianDigits()} تسک"
                            )
                            KpiMiniCard(
                                icon = Icons.Rounded.Star,
                                iconTint = MaterialTheme.colorScheme.primary,
                                label = "امتیاز اسپرینت",
                                value = "${animatedDonePoints.toPersianDigits()} / ${uiState.totalStoryPoints.toPersianDigits()} امتیاز"
                            )
                            if (uiState.overdueTasksCount > 0) {
                                KpiMiniCard(
                                    icon = Icons.Rounded.WarningAmber,
                                    iconTint = PriorityUrgentColor,
                                    label = "عقب‌افتاده",
                                    value = "${animatedOverdue.toPersianDigits()} تسک"
                                )
                            }
                        }
                    }
                }

                // Weekly Productivity Chart
                item {
                    Card(
                        shape = MaterialTheme.shapes.large,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "روند بهره‌وری ۷ روز اخیر",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                val weekTotal = uiState.weeklyActivity.sumOf { it.completedCount }
                                Surface(
                                    color = MaterialTheme.colorScheme.secondaryContainer,
                                    shape = RoundedCornerShape(50)
                                ) {
                                    Text(
                                        text = "${weekTotal.toPersianDigits()} تسک تکمیل‌شده",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }
                            WeeklyProductivityChart(days = uiState.weeklyActivity)
                        }
                    }
                }

                // Active / Pinned Projects
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "پروژه‌های شخصی شما",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        TextButton(onClick = onViewAllProjects) {
                            Text("همه پروژه‌ها (${uiState.projects.size.toPersianDigits()})")
                        }
                    }
                }

                item {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(
                            items = filteredProjects.take(8),
                            key = { it.project.id }
                        ) { projectItem ->
                            ProjectCard(
                                item = projectItem,
                                onClick = { onOpenProject(projectItem.project.id) },
                                onTogglePin = { onTogglePinProject(projectItem.project) },
                                modifier = Modifier.width(322.dp)
                            )
                        }
                    }
                }

                // Upcoming Deadlines & Priority Queue
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.EventAvailable,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "زمان‌بندی و اولویت‌ها",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            TextButton(
                                onClick = onNewTaskClick,
                                modifier = Modifier.testTag("dashboard_add_task_button")
                            ) {
                                Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("تسک جدید")
                            }
                        }

                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            TimelineFilter.entries.forEach { filter ->
                                FilterChip(
                                    selected = timelineFilter == filter,
                                    onClick = { timelineFilter = filter },
                                    label = { Text(filter.labelFa) }
                                )
                            }
                        }
                    }
                }

                if (priorityQueue.isEmpty()) {
                    item {
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            shape = MaterialTheme.shapes.medium,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = if (pendingTasks.isEmpty()) {
                                    "عالی! تمام تسک‌های فعال تکمیل شده‌اند."
                                } else {
                                    "تسکی با این فیلتر یا جست‌وجو پیدا نشد."
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(20.dp)
                            )
                        }
                    }
                } else {
                    items(
                        items = priorityQueue,
                        key = { it.task.id }
                    ) { taskMeta ->
                        TaskCard(
                            item = taskMeta,
                            onClick = { onTaskClick(taskMeta) },
                            onToggleDone = { onToggleTaskDone(taskMeta.task) },
                            onAdvanceStatus = { onAdvanceTaskStatus(taskMeta.task) },
                            onToggleBookmark = { onToggleBookmarkTask(taskMeta.task) }
                        )
                    }
                }

                // Quick Export Report Footer Button
                item {
                    OutlinedButton(
                        onClick = onDownloadReportClick,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("dashboard_download_report_button")
                    ) {
                        Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("خروجی گزارش کامل پروژه‌ها (.md)")
                    }
                }

                item { Spacer(modifier = Modifier.height(76.dp)) }
            }
        }
    }
}

@Composable
private fun KpiMiniCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconTint: androidx.compose.ui.graphics.Color,
    label: String,
    value: String
) {
    Card(
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Surface(
                color = iconTint.copy(alpha = 0.14f),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.size(34.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = iconTint,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            Column {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
