package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

enum class Screen(
  val route: String,
  val titleFa: String,
  val titleEn: String,
  val icon: ImageVector
) {
  HOME("home", "داشبورد", "DASHBOARD", Icons.Default.Dashboard),
  AIRPORT_WEATHER("airport_weather", "Airport Weather", "AIRPORT WX", Icons.Default.LocalAirport),
  METAR("metar", "Raw METAR / SPECI", "RAW METAR", Icons.Default.Cloud),
  TAF("taf", "Raw TAF Forecast", "RAW TAF", Icons.Default.Schedule),
  SIGMET("sigmet", "Raw SIGMET Hazards", "RAW SIGMET", Icons.Default.Warning),
  WIND_ALOFT("wind_aloft", "Wind & Temp Aloft", "WIND ALOFT", Icons.Default.Air),
  SNOWTAM("snowtam", "اسنوتام و وضعیت باند", "SNOWTAM / RCR", Icons.Default.AcUnit),
  WEATHER_MAP("weather_map", "Weather Map", "WEATHER MAP", Icons.Default.Map),
  ATC_BOARD("atc_board", "ATC Weather Board", "ATC BOARD", Icons.Default.ViewKanban),
  ICAO_GUIDE("icao_guide", "ICAO / GRF Guide", "ICAO GUIDE", Icons.Default.MenuBook),
  SETTINGS("settings", "System Settings", "SETTINGS", Icons.Default.Settings),
  ABOUT("about", "Data Sources & Standards", "ABOUT", Icons.Default.Info)
}
