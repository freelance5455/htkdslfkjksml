package com.example.ui.navigation

sealed interface VaultDestination {
    data object Splash : VaultDestination
    data object Main : VaultDestination
    data object FileRecording : VaultDestination
    data object Information : VaultDestination
    data object CreatePdf : VaultDestination
    data object ViewPdfs : VaultDestination
    data object InformationStorage : VaultDestination
}
