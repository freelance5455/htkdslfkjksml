package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

enum class Screen(
  val route: String,
  val titleFa: String,
  val titleEn: String,
  val icon: ImageVector
) {
  HOME("home", "پیشخوان عملیاتی", "HOME", Icons.Default.Dashboard),
  AIRPORT_WEATHER("airport_weather", "وضعیت فرودگاه", "AIRPORT WX", Icons.Default.LocalAirport),
  METAR("metar", "گزارش متار و اسپسی", "METAR / SPECI", Icons.Default.Cloud),
  TAF("taf", "پیش‌بینی تف", "TAF FORECAST", Icons.Default.Schedule),
  SIGMET("sigmet", "پدیده‌های خطرناک", "SIGMET", Icons.Default.Warning),
  WIND_ALOFT("wind_aloft", "باد و دمای سطوح فوقانی", "WIND ALOFT", Icons.Default.Air),
  SNOWTAM("snowtam", "اسنوتام و وضعیت باند", "SNOWTAM / RCR", Icons.Default.AcUnit),
  WEATHER_MAP("weather_map", "نقشه هواشناسی", "WEATHER MAP", Icons.Default.Map),
  ATC_BOARD("atc_board", "تابلوی چندفرودگاهی ATC", "ATC WEATHER BOARD", Icons.Default.ViewKanban),
  ICAO_GUIDE("icao_guide", "راهنمای کدها و GRF", "ICAO / GRF GUIDE", Icons.Default.MenuBook),
  SETTINGS("settings", "تنظیمات سامانه", "SETTINGS", Icons.Default.Settings),
  ABOUT("about", "منابع داده و استانداردها", "ABOUT / DATA SOURCES", Icons.Default.Info)
}
