package com.example.ui.calculator

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Backspace
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Functions
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.TactileKey
import com.example.ui.theme.AetherTheme
import com.example.ui.theme.InterFamily

@Composable
fun CalculatorScreen(
  uiState: CalculatorUiState,
  hapticsEnabled: Boolean,
  onDigit: (String) -> Unit,
  onDecimal: () -> Unit,
  onOperator: (Char) -> Unit,
  onPercent: () -> Unit,
  onToggleSign: () -> Unit,
  onClearAll: () -> Unit,
  onBackspace: () -> Unit,
  onEquals: () -> Unit,
  onToggleScientific: () -> Unit,
  onCollapseScientific: () -> Unit,
  onToggleSecondPage: () -> Unit,
  onToggleHyperbolic: () -> Unit,
  onToggleAngleMode: () -> Unit,
  onScientificFunction: (String) -> Unit,
  onScientificConstant: (String) -> Unit,
  onScientificPostfix: (String) -> Unit,
  onReciprocal: () -> Unit,
  onParen: (String) -> Unit,
  onComma: () -> Unit,
  onMemoryClear: () -> Unit,
  onMemoryRecall: () -> Unit,
  onMemoryAdd: () -> Unit,
  onMemorySubtract: () -> Unit,
  onOpenHistory: () -> Unit,
  onOpenSettings: () -> Unit,
  onCopyResult: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  BackHandler(enabled = uiState.isScientificMode) {
    onCollapseScientific()
  }

  val colors = AetherTheme.colors

  Box(
    modifier = modifier.fillMaxSize().background(colors.background),
    contentAlignment = Alignment.TopCenter,
  ) {
    BoxWithConstraints(
      modifier = Modifier.fillMaxSize().widthIn(max = 560.dp).padding(horizontal = 16.dp)
    ) {
      val compactHeight = maxHeight < 620.dp

      Column(
        modifier = Modifier.fillMaxSize().padding(bottom = 8.dp),
        verticalArrangement = Arrangement.SpaceBetween,
      ) {
        // Compact Top Bar
        CalculatorTopBar(
          isScientific = uiState.isScientificMode,
          hapticsEnabled = hapticsEnabled,
          onToggleScientific = onToggleScientific,
          onOpenHistory = onOpenHistory,
          onOpenSettings = onOpenSettings,
        )

        // Display Area
        CalculatorDisplay(
          uiState = uiState,
          compactHeight = compactHeight,
          onToggleAngleMode = onToggleAngleMode,
          onCopyResult = onCopyResult,
          modifier = Modifier.weight(if (uiState.isScientificMode) 0.9f else 1.15f).fillMaxWidth(),
        )

        // Memory Strip (MC, MR, M+, M-)
        MemoryStrip(
          hasMemory = uiState.hasMemory,
          hapticsEnabled = hapticsEnabled,
          onMemoryClear = onMemoryClear,
          onMemoryRecall = onMemoryRecall,
          onMemoryAdd = onMemoryAdd,
          onMemorySubtract = onMemorySubtract,
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Scientific Keypad (Fast non-blocking transition)
        AnimatedVisibility(
          visible = uiState.isScientificMode,
          enter = expandVertically(animationSpec = tween(85)) + fadeIn(animationSpec = tween(75)),
          exit = shrinkVertically(animationSpec = tween(70)) + fadeOut(animationSpec = tween(60)),
        ) {
          ScientificKeypadSection(
            uiState = uiState,
            hapticsEnabled = hapticsEnabled,
            compactHeight = compactHeight,
            onToggleAngleMode = onToggleAngleMode,
            onToggleSecondPage = onToggleSecondPage,
            onToggleHyperbolic = onToggleHyperbolic,
            onScientificFunction = onScientificFunction,
            onScientificConstant = onScientificConstant,
            onScientificPostfix = onScientificPostfix,
            onOperator = onOperator,
            onReciprocal = onReciprocal,
            onParen = onParen,
            onComma = onComma,
          )
        }

        // Standard 5x4 Keypad (exact arrangement)
        StandardKeypadSection(
          hapticsEnabled = hapticsEnabled,
          onDigit = onDigit,
          onDecimal = onDecimal,
          onOperator = onOperator,
          onPercent = onPercent,
          onToggleSign = onToggleSign,
          onClearAll = onClearAll,
          onBackspace = onBackspace,
          onEquals = onEquals,
          modifier =
            Modifier
              .weight(if (uiState.isScientificMode) 1.65f else 2.05f)
              .fillMaxWidth(),
        )
      }
    }
  }
}

@Composable
private fun CalculatorTopBar(
  isScientific: Boolean,
  hapticsEnabled: Boolean,
  onToggleScientific: () -> Unit,
  onOpenHistory: () -> Unit,
  onOpenSettings: () -> Unit,
) {
  val colors = AetherTheme.colors
  Row(
    modifier = Modifier.fillMaxWidth().height(52.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Text(
      text = stringResource(R.string.app_name),
      style = MaterialTheme.typography.headlineSmall,
      color = colors.textPrimary,
    )

    Row(
      horizontalArrangement = Arrangement.spacedBy(6.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Surface(
        modifier =
          Modifier
            .height(36.dp)
            .clip(CircleShape)
            .clickable(onClick = onToggleScientific)
            .testTag("toggle_scientific_button"),
        shape = CircleShape,
        color = if (isScientific) colors.accent else colors.surface,
        border =
          BorderStroke(
            1.dp,
            if (isScientific) colors.accent else colors.borderSubtle,
          ),
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 12.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
          Icon(
            imageVector = Icons.Outlined.Functions,
            contentDescription = stringResource(R.string.cd_scientific),
            tint = if (isScientific) Color(0xFFF1F0F5) else colors.lavender,
            modifier = Modifier.size(16.dp),
          )
          Text(
            text = "Sci",
            style = MaterialTheme.typography.labelMedium,
            color = if (isScientific) Color(0xFFF1F0F5) else colors.textPrimary,
          )
        }
      }

      IconButton(
        onClick = onOpenHistory,
        modifier = Modifier.size(44.dp).testTag("open_history_button"),
      ) {
        Icon(
          imageVector = Icons.Outlined.History,
          contentDescription = stringResource(R.string.cd_history),
          tint = colors.textSecondary,
        )
      }

      IconButton(
        onClick = onOpenSettings,
        modifier = Modifier.size(44.dp).testTag("open_settings_button"),
      ) {
        Icon(
          imageVector = Icons.Outlined.Settings,
          contentDescription = stringResource(R.string.cd_settings),
          tint = colors.textSecondary,
        )
      }
    }
  }
}

@Composable
private fun CalculatorDisplay(
  uiState: CalculatorUiState,
  compactHeight: Boolean,
  onToggleAngleMode: () -> Unit,
  onCopyResult: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val colors = AetherTheme.colors
  val exprScroll = rememberScrollState()

  LaunchedEffect(uiState.formattedExpression) {
    exprScroll.scrollTo(exprScroll.maxValue)
  }

  Column(
    modifier = modifier.padding(vertical = if (compactHeight) 4.dp else 10.dp),
    verticalArrangement = Arrangement.SpaceBetween,
    horizontalAlignment = Alignment.End,
  ) {
    // Conditional minimal status row (only shown when Memory active or Scientific mode active)
    Row(
      modifier = Modifier.fillMaxWidth().height(26.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      if (uiState.isScientificMode) {
        Box(
          modifier =
            Modifier
              .clip(CircleShape)
              .background(colors.surfaceElevated, CircleShape)
              .border(1.dp, colors.borderSubtle, CircleShape)
              .clickable(onClick = onToggleAngleMode)
              .padding(horizontal = 10.dp, vertical = 3.dp)
              .testTag("angle_mode_indicator"),
        ) {
          Text(
            text = uiState.angleMode.name,
            style = MaterialTheme.typography.labelSmall,
            color = colors.lavender,
          )
        }
      } else {
        Spacer(modifier = Modifier.width(1.dp))
      }

      if (uiState.hasMemory) {
        Box(
          modifier =
            Modifier
              .clip(CircleShape)
              .background(colors.surface, CircleShape)
              .border(1.dp, colors.borderSubtle, CircleShape)
              .padding(horizontal = 10.dp, vertical = 3.dp)
              .testTag("memory_active_indicator"),
        ) {
          Text(
            text = "M · ${uiState.memoryFormatted}",
            style =
              TextStyle(
                fontFamily = InterFamily,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = colors.lavender,
                fontFeatureSettings = "tnum",
              ),
          )
        }
      }
    }

    Column(
      modifier = Modifier.fillMaxWidth(),
      horizontalAlignment = Alignment.End,
    ) {
      val exprFontSize =
        when {
          uiState.formattedExpression.length > 26 -> 20.sp
          uiState.formattedExpression.length > 16 -> 26.sp
          else -> 32.sp
        }

      Box(
        modifier = Modifier.fillMaxWidth().horizontalScroll(exprScroll),
        contentAlignment = Alignment.CenterEnd,
      ) {
        Text(
          text = uiState.formattedExpression.ifEmpty { "0" },
          style =
            TextStyle(
              fontFamily = InterFamily,
              fontWeight = FontWeight.Normal,
              fontSize = if (uiState.isEvaluated) 22.sp else exprFontSize,
              color =
                if (uiState.formattedExpression.isEmpty() || uiState.isEvaluated) {
                  colors.textSecondary
                } else {
                  colors.textPrimary
                },
              fontFeatureSettings = "tnum",
            ),
          textAlign = TextAlign.End,
          maxLines = 1,
          modifier = Modifier.testTag("calc_expression_display"),
        )
      }

      Spacer(modifier = Modifier.height(if (compactHeight) 4.dp else 8.dp))

      Row(
        modifier = Modifier.fillMaxWidth().heightInMinResult(compactHeight),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        if (uiState.resultText.isNotEmpty() && uiState.errorMessage == null) {
          IconButton(
            onClick = { onCopyResult(uiState.resultText) },
            modifier = Modifier.size(40.dp).testTag("copy_result_button"),
          ) {
            Icon(
              imageVector = Icons.Outlined.ContentCopy,
              contentDescription = stringResource(R.string.cd_copy_result),
              tint = colors.textSecondary,
              modifier = Modifier.size(18.dp),
            )
          }
        } else {
          Spacer(modifier = Modifier.width(40.dp))
        }

        val resultLen = uiState.resultText.length
        val resultFontSize =
          when {
            uiState.errorMessage != null -> 22.sp
            uiState.isLivePreview ->
              when {
                resultLen > 16 -> 22.sp
                resultLen > 11 -> 28.sp
                else -> 32.sp
              }
            resultLen > 16 -> 26.sp
            resultLen > 12 -> 34.sp
            resultLen > 8 -> 42.sp
            else -> if (compactHeight) 44.sp else 52.sp
          }

        Text(
          text = uiState.resultText,
          style =
            TextStyle(
              fontFamily = InterFamily,
              fontWeight = if (uiState.isEvaluated) FontWeight.SemiBold else FontWeight.Medium,
              fontSize = resultFontSize,
              color =
                when {
                  uiState.errorMessage != null -> colors.error
                  uiState.isEvaluated -> colors.textPrimary
                  else -> colors.textSecondary
                },
              fontFeatureSettings = "tnum",
            ),
          textAlign = TextAlign.End,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier.weight(1f).testTag("calc_result_display"),
        )
      }
    }
  }
}

private fun Modifier.heightInMinResult(compact: Boolean): Modifier =
  this.height(if (compact) 48.dp else 62.dp)

@Composable
private fun MemoryStrip(
  hasMemory: Boolean,
  hapticsEnabled: Boolean,
  onMemoryClear: () -> Unit,
  onMemoryRecall: () -> Unit,
  onMemoryAdd: () -> Unit,
  onMemorySubtract: () -> Unit,
) {
  val colors = AetherTheme.colors
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    val items =
      listOf(
        Triple("MC", hasMemory, onMemoryClear),
        Triple("MR", hasMemory, onMemoryRecall),
        Triple("M+", true, onMemoryAdd),
        Triple("M−", true, onMemorySubtract),
      )
    items.forEach { (label, active, action) ->
      TactileKey(
        onClick = action,
        backgroundColor = colors.surface,
        pressedColor = colors.surfaceElevated,
        borderColor = colors.borderSubtle,
        shape = RoundedCornerShape(12.dp),
        hapticsEnabled = hapticsEnabled,
        testTag = "mem_${label.lowercase().replace("+", "plus").replace("−", "minus")}",
        modifier = Modifier.weight(1f).height(38.dp),
      ) {
        Text(
          text = label,
          style = MaterialTheme.typography.labelMedium,
          color = if (active) colors.lavender else colors.textSecondary.copy(alpha = 0.5f),
        )
      }
    }
  }
}

@Composable
private fun ScientificKeypadSection(
  uiState: CalculatorUiState,
  hapticsEnabled: Boolean,
  compactHeight: Boolean,
  onToggleAngleMode: () -> Unit,
  onToggleSecondPage: () -> Unit,
  onToggleHyperbolic: () -> Unit,
  onScientificFunction: (String) -> Unit,
  onScientificConstant: (String) -> Unit,
  onScientificPostfix: (String) -> Unit,
  onOperator: (Char) -> Unit,
  onReciprocal: () -> Unit,
  onParen: (String) -> Unit,
  onComma: () -> Unit,
) {
  val colors = AetherTheme.colors
  val keyHeight = if (compactHeight) 38.dp else 44.dp

  Column(
    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
    verticalArrangement = Arrangement.spacedBy(6.dp),
  ) {
    // Mode & delimiter strip
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      SciToggleKey(
        label = uiState.angleMode.name,
        active = false,
        hapticsEnabled = hapticsEnabled,
        onClick = onToggleAngleMode,
        testTag = "sci_deg_rad",
        modifier = Modifier.weight(1f).height(36.dp),
      )
      SciToggleKey(
        label = "2nd",
        active = uiState.isSecondPage,
        hapticsEnabled = hapticsEnabled,
        onClick = onToggleSecondPage,
        testTag = "sci_2nd",
        modifier = Modifier.weight(1f).height(36.dp),
      )
      SciToggleKey(
        label = "HYP",
        active = uiState.isHyperbolic,
        hapticsEnabled = hapticsEnabled,
        onClick = onToggleHyperbolic,
        testTag = "sci_hyp",
        modifier = Modifier.weight(1f).height(36.dp),
      )
      SciKey(
        label = "(",
        hapticsEnabled = hapticsEnabled,
        onClick = { onParen("(") },
        testTag = "sci_lparen",
        modifier = Modifier.weight(1f).height(36.dp),
      )
      SciKey(
        label = ")",
        hapticsEnabled = hapticsEnabled,
        onClick = { onParen(")") },
        testTag = "sci_rparen",
        modifier = Modifier.weight(1f).height(36.dp),
      )
      SciKey(
        label = ",",
        hapticsEnabled = hapticsEnabled,
        onClick = onComma,
        testTag = "sci_comma",
        modifier = Modifier.weight(0.8f).height(36.dp),
      )
    }

    // 2 rows x 5 cols scientific functions
    val row1: List<Pair<String, () -> Unit>> =
      when {
        uiState.isHyperbolic ->
          listOf(
            "sinh" to { onScientificFunction("sinh(") },
            "cosh" to { onScientificFunction("cosh(") },
            "tanh" to { onScientificFunction("tanh(") },
            "ln" to { onScientificFunction("ln(") },
            "log" to { onScientificFunction("log(") },
          )
        uiState.isSecondPage ->
          listOf(
            "sin⁻¹" to { onScientificFunction("asin(") },
            "cos⁻¹" to { onScientificFunction("acos(") },
            "tan⁻¹" to { onScientificFunction("atan(") },
            "logₙ" to { onScientificFunction("logBase(") },
            "1/x" to onReciprocal,
          )
        else ->
          listOf(
            "sin" to { onScientificFunction("sin(") },
            "cos" to { onScientificFunction("cos(") },
            "tan" to { onScientificFunction("tan(") },
            "ln" to { onScientificFunction("ln(") },
            "log" to { onScientificFunction("log(") },
          )
      }

    val row2: List<Pair<String, () -> Unit>> =
      when {
        uiState.isHyperbolic ->
          listOf(
            "√" to { onScientificFunction("√(") },
            "x²" to { onScientificPostfix("^2") },
            "xʸ" to { onOperator('^') },
            "x!" to { onScientificPostfix("!") },
            "|x|" to { onScientificFunction("abs(") },
          )
        uiState.isSecondPage ->
          listOf(
            "∛" to { onScientificFunction("∛(") },
            "x³" to { onScientificPostfix("^3") },
            "ʸ√x" to { onScientificFunction("nroot(") },
            "x!" to { onScientificPostfix("!") },
            "|x|" to { onScientificFunction("abs(") },
          )
        else ->
          listOf(
            "√" to { onScientificFunction("√(") },
            "x²" to { onScientificPostfix("^2") },
            "xʸ" to { onOperator('^') },
            "π" to { onScientificConstant("π") },
            "e" to { onScientificConstant("e") },
          )
      }

    listOf(row1, row2).forEach { rowItems ->
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        rowItems.forEach { (label, action) ->
          SciKey(
            label = label,
            hapticsEnabled = hapticsEnabled,
            onClick = action,
            testTag = "sci_key_$label",
            modifier = Modifier.weight(1f).height(keyHeight),
          )
        }
      }
    }
  }
}

@Composable
private fun SciToggleKey(
  label: String,
  active: Boolean,
  hapticsEnabled: Boolean,
  onClick: () -> Unit,
  testTag: String,
  modifier: Modifier = Modifier,
) {
  val colors = AetherTheme.colors
  TactileKey(
    onClick = onClick,
    backgroundColor = if (active) colors.accent else colors.surfaceElevated,
    pressedColor = if (active) colors.accentPressed else colors.surfaceHighest,
    borderColor = if (active) colors.accent else colors.borderSubtle,
    shape = RoundedCornerShape(10.dp),
    hapticsEnabled = hapticsEnabled,
    testTag = testTag,
    modifier = modifier,
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.labelMedium,
      color = if (active) Color(0xFFF1F0F5) else colors.lavender,
    )
  }
}

@Composable
private fun SciKey(
  label: String,
  hapticsEnabled: Boolean,
  onClick: () -> Unit,
  testTag: String,
  modifier: Modifier = Modifier,
) {
  val colors = AetherTheme.colors
  TactileKey(
    onClick = onClick,
    backgroundColor = colors.surfaceElevated,
    pressedColor = colors.surfaceHighest,
    borderColor = colors.borderSubtle,
    shape = RoundedCornerShape(12.dp),
    hapticsEnabled = hapticsEnabled,
    testTag = testTag,
    modifier = modifier,
  ) {
    Text(
      text = label,
      style =
        TextStyle(
          fontFamily = InterFamily,
          fontSize = 14.sp,
          fontWeight = FontWeight.Medium,
          color = colors.textPrimary,
        ),
    )
  }
}

@Composable
private fun StandardKeypadSection(
  hapticsEnabled: Boolean,
  onDigit: (String) -> Unit,
  onDecimal: () -> Unit,
  onOperator: (Char) -> Unit,
  onPercent: () -> Unit,
  onToggleSign: () -> Unit,
  onClearAll: () -> Unit,
  onBackspace: () -> Unit,
  onEquals: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val colors = AetherTheme.colors

  Column(
    modifier = modifier,
    verticalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    // Row 1: AC | DEL | % | ÷
    Row(
      modifier = Modifier.weight(1f).fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      UtilityKey("AC", hapticsEnabled, onClearAll, "key_ac", Modifier.weight(1f).fillMaxHeight())
      TactileKey(
        onClick = onBackspace,
        backgroundColor = colors.surfaceElevated,
        pressedColor = colors.surfaceHighest,
        borderColor = colors.borderSubtle,
        hapticsEnabled = hapticsEnabled,
        testTag = "key_del",
        modifier = Modifier.weight(1f).fillMaxHeight(),
      ) {
        Icon(
          imageVector = Icons.AutoMirrored.Outlined.Backspace,
          contentDescription = stringResource(R.string.cd_backspace),
          tint = colors.lavender,
          modifier = Modifier.size(22.dp),
        )
      }
      UtilityKey("%", hapticsEnabled, onPercent, "key_percent", Modifier.weight(1f).fillMaxHeight())
      OperatorKey("÷", hapticsEnabled, { onOperator('÷') }, "key_div", Modifier.weight(1f).fillMaxHeight())
    }

    // Row 2: 7 | 8 | 9 | ×
    Row(
      modifier = Modifier.weight(1f).fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      DigitKey("7", hapticsEnabled, { onDigit("7") }, Modifier.weight(1f).fillMaxHeight())
      DigitKey("8", hapticsEnabled, { onDigit("8") }, Modifier.weight(1f).fillMaxHeight())
      DigitKey("9", hapticsEnabled, { onDigit("9") }, Modifier.weight(1f).fillMaxHeight())
      OperatorKey("×", hapticsEnabled, { onOperator('×') }, "key_mul", Modifier.weight(1f).fillMaxHeight())
    }

    // Row 3: 4 | 5 | 6 | −
    Row(
      modifier = Modifier.weight(1f).fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      DigitKey("4", hapticsEnabled, { onDigit("4") }, Modifier.weight(1f).fillMaxHeight())
      DigitKey("5", hapticsEnabled, { onDigit("5") }, Modifier.weight(1f).fillMaxHeight())
      DigitKey("6", hapticsEnabled, { onDigit("6") }, Modifier.weight(1f).fillMaxHeight())
      OperatorKey("−", hapticsEnabled, { onOperator('−') }, "key_sub", Modifier.weight(1f).fillMaxHeight())
    }

    // Row 4: 1 | 2 | 3 | +
    Row(
      modifier = Modifier.weight(1f).fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      DigitKey("1", hapticsEnabled, { onDigit("1") }, Modifier.weight(1f).fillMaxHeight())
      DigitKey("2", hapticsEnabled, { onDigit("2") }, Modifier.weight(1f).fillMaxHeight())
      DigitKey("3", hapticsEnabled, { onDigit("3") }, Modifier.weight(1f).fillMaxHeight())
      OperatorKey("+", hapticsEnabled, { onOperator('+') }, "key_add", Modifier.weight(1f).fillMaxHeight())
    }

    // Row 5: +/− | 0 | . | =
    Row(
      modifier = Modifier.weight(1f).fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      DigitKey("+/−", hapticsEnabled, onToggleSign, Modifier.weight(1f).fillMaxHeight(), testTag = "key_sign", fontSize = 19)
      DigitKey("0", hapticsEnabled, { onDigit("0") }, Modifier.weight(1f).fillMaxHeight())
      DigitKey(".", hapticsEnabled, onDecimal, Modifier.weight(1f).fillMaxHeight(), testTag = "key_dot")
      TactileKey(
        onClick = onEquals,
        backgroundColor = colors.accent,
        pressedColor = colors.accentPressed,
        borderColor = colors.accent,
        hapticsEnabled = hapticsEnabled,
        testTag = "key_equals",
        modifier = Modifier.weight(1f).fillMaxHeight(),
      ) {
        Text(
          text = "=",
          style =
            TextStyle(
              fontFamily = InterFamily,
              fontSize = 28.sp,
              fontWeight = FontWeight.SemiBold,
              color = Color(0xFFF1F0F5),
            ),
        )
      }
    }
  }
}

@Composable
private fun DigitKey(
  label: String,
  hapticsEnabled: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  testTag: String = "key_$label",
  fontSize: Int = 24,
) {
  val colors = AetherTheme.colors
  TactileKey(
    onClick = onClick,
    backgroundColor = colors.surface,
    pressedColor = colors.surfaceElevated,
    borderColor = colors.borderSubtle,
    hapticsEnabled = hapticsEnabled,
    testTag = testTag,
    modifier = modifier,
  ) {
    Text(
      text = label,
      style =
        TextStyle(
          fontFamily = InterFamily,
          fontSize = fontSize.sp,
          fontWeight = FontWeight.Medium,
          color = colors.textPrimary,
          fontFeatureSettings = "tnum",
        ),
    )
  }
}

@Composable
private fun UtilityKey(
  label: String,
  hapticsEnabled: Boolean,
  onClick: () -> Unit,
  testTag: String,
  modifier: Modifier = Modifier,
) {
  val colors = AetherTheme.colors
  TactileKey(
    onClick = onClick,
    backgroundColor = colors.surfaceElevated,
    pressedColor = colors.surfaceHighest,
    borderColor = colors.borderSubtle,
    hapticsEnabled = hapticsEnabled,
    testTag = testTag,
    modifier = modifier,
  ) {
    Text(
      text = label,
      style =
        TextStyle(
          fontFamily = InterFamily,
          fontSize = 18.sp,
          fontWeight = FontWeight.SemiBold,
          color = colors.lavender,
        ),
    )
  }
}

@Composable
private fun OperatorKey(
  label: String,
  hapticsEnabled: Boolean,
  onClick: () -> Unit,
  testTag: String,
  modifier: Modifier = Modifier,
) {
  val colors = AetherTheme.colors
  TactileKey(
    onClick = onClick,
    backgroundColor = colors.surfaceElevated,
    pressedColor = colors.surfaceHighest,
    borderColor = colors.borderSubtle,
    hapticsEnabled = hapticsEnabled,
    testTag = testTag,
    modifier = modifier,
  ) {
    Text(
      text = label,
      style =
        TextStyle(
          fontFamily = InterFamily,
          fontSize = 26.sp,
          fontWeight = FontWeight.Medium,
          color = colors.lavender,
        ),
    )
  }
}
