package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

enum class CalcButtonType {
    NUMBER,
    OPERATOR,
    EQUALS,
    ACTION,      // AC, Delete
    SCIENTIFIC
}

@Composable
fun CalculatorButton(
    text: String = "",
    icon: ImageVector? = null,
    type: CalcButtonType = CalcButtonType.NUMBER,
    isHapticsEnabled: Boolean = true,
    height: Dp = 64.dp,
    modifier: Modifier = Modifier,
    testTag: String = "btn_$text",
    onClick: () -> Unit
) {
    val haptic = LocalHapticFeedback.current
    val isDark = MaterialTheme.colorScheme.background == BackgroundDark

    val bgColor = when (type) {
        CalcButtonType.NUMBER -> if (isDark) KeypadNumberDark else KeypadNumberLight
        CalcButtonType.OPERATOR -> if (isDark) ElectricBlueContainerDark else ElectricBlueContainer
        CalcButtonType.EQUALS -> ElectricBlue
        CalcButtonType.ACTION -> if (isDark) KeypadActionDark else KeypadActionLight
        CalcButtonType.SCIENTIFIC -> if (isDark) SurfaceVariantDark else SurfaceVariantLight
    }

    val contentColor = when (type) {
        CalcButtonType.NUMBER -> if (isDark) KeypadNumberTextDark else KeypadNumberTextLight
        CalcButtonType.OPERATOR -> ElectricBlue
        CalcButtonType.EQUALS -> Color.White
        CalcButtonType.ACTION -> if (isDark) TextPrimaryDark else TextPrimaryLight
        CalcButtonType.SCIENTIFIC -> if (isDark) Color(0xFFC4B5FD) else SoftViolet
    }

    val borderColor = when (type) {
        CalcButtonType.EQUALS -> Color.Transparent
        else -> MaterialTheme.colorScheme.outline.copy(alpha = if (isDark) 0.25f else 0.45f)
    }

    val shape = RoundedCornerShape(18.dp)

    Box(
        modifier = modifier
            .testTag(testTag)
            .height(height)
            .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
            .clip(shape)
            .background(bgColor)
            .border(width = 0.8.dp, color = borderColor, shape = shape)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(bounded = true, color = contentColor.copy(alpha = 0.3f))
            ) {
                if (isHapticsEnabled) {
                    try {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    } catch (_: Exception) {}
                }
                onClick()
            },
        contentAlignment = Alignment.Center
    ) {
        if (icon != null) {
            androidx.compose.material3.Icon(
                imageVector = icon,
                contentDescription = text,
                tint = contentColor,
                modifier = Modifier.size(24.dp)
            )
        } else {
            Text(
                text = text,
                color = contentColor,
                fontSize = when (type) {
                    CalcButtonType.SCIENTIFIC -> 15.sp
                    CalcButtonType.ACTION -> 18.sp
                    CalcButtonType.OPERATOR -> 22.sp
                    CalcButtonType.EQUALS -> 26.sp
                    CalcButtonType.NUMBER -> 22.sp
                },
                fontWeight = when (type) {
                    CalcButtonType.EQUALS -> FontWeight.Bold
                    CalcButtonType.OPERATOR -> FontWeight.SemiBold
                    CalcButtonType.ACTION -> FontWeight.SemiBold
                    CalcButtonType.SCIENTIFIC -> FontWeight.Medium
                    CalcButtonType.NUMBER -> FontWeight.Normal
                }
            )
        }
    }
}
