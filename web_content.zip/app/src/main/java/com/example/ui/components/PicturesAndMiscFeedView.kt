package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.MediaItem
import com.example.data.model.MediaSource
import com.example.ui.theme.YiffyPrimary
import com.example.ui.theme.YiffySecondary
import com.example.ui.theme.YiffySurface
import com.example.ui.theme.YiffySurfaceVariant

/**
 * Pictures Feed View: High-res visual stream with source filtering
 * and "+" icon on top right to add/select website sources.
 */
@Composable
fun PicturesFeedView(
    items: List<MediaItem>,
    onToggleLike: (MediaItem) -> Unit,
    onToggleFavorite: (MediaItem) -> Unit,
    onOpenComments: (MediaItem) -> Unit,
    onDownload: (MediaItem) -> Unit,
    onOpenAddSource: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedSourceFilter by remember { mutableStateOf<MediaSource?>(null) }

    val filteredItems = remember(items, selectedSourceFilter) {
        if (selectedSourceFilter == null) items
        else items.filter { it.source == selectedSourceFilter }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0A0B0E))
            .statusBarsPadding()
    ) {
        // Top Header with Title and Plus Icon (To select/add website sources)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Image, contentDescription = null, tint = YiffyPrimary)
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "Pictures",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
            }

            // Plus icon up to the right to pick/add website sources
            IconButton(
                onClick = onOpenAddSource,
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(YiffyPrimary)
                    .testTag("add_source_pictures_btn")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Website Source", tint = Color.White)
            }
        }

        // Quick platform chips row
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp)
        ) {
            FilterChip(
                selected = selectedSourceFilter == null,
                onClick = { selectedSourceFilter = null },
                label = { Text("All") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = YiffyPrimary,
                    selectedLabelColor = Color.White
                )
            )
            listOf(MediaSource.PORNHUB, MediaSource.E621, MediaSource.RULE34, MediaSource.BLUESKY, MediaSource.TWITTER, MediaSource.REDDIT).forEach { source ->
                FilterChip(
                    selected = selectedSourceFilter == source,
                    onClick = { selectedSourceFilter = if (selectedSourceFilter == source) null else source },
                    label = { Text(source.displayName) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(source.badgeColorHex),
                        selectedLabelColor = Color.White
                    )
                )
            }
        }

        // Staggered / Grid list of Pictures
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier
                .fillMaxSize()
                .testTag("pictures_grid_list")
        ) {
            items(filteredItems, key = { it.id }) { item ->
                PictureCard(
                    item = item,
                    onToggleLike = { onToggleLike(item) },
                    onToggleFavorite = { onToggleFavorite(item) },
                    onOpenComments = { onOpenComments(item) },
                    onDownload = { onDownload(item) }
                )
            }
        }
    }
}

@Composable
fun PictureCard(
    item: MediaItem,
    onToggleLike: () -> Unit,
    onToggleFavorite: () -> Unit,
    onOpenComments: () -> Unit,
    onDownload: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = YiffySurfaceVariant),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpenComments)
            .testTag("picture_card_${item.id}")
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(0.85f)
            ) {
                AsyncImage(
                    model = item.previewUrl.ifBlank { item.mediaUrl },
                    contentDescription = item.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Top source platform badge
                Surface(
                    color = Color(item.source.badgeColorHex),
                    shape = RoundedCornerShape(bottomEnd = 8.dp),
                    modifier = Modifier.align(Alignment.TopStart)
                ) {
                    Text(
                        text = item.source.displayName,
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                // Quick download icon button on top right
                IconButton(
                    onClick = onDownload,
                    modifier = Modifier
                        .size(32.dp)
                        .padding(4.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.5f))
                        .align(Alignment.TopEnd)
                ) {
                    Icon(
                        Icons.Default.Download,
                        contentDescription = "Save",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Column(modifier = Modifier.padding(8.dp)) {
                Text(
                    text = item.title,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    maxLines = 1
                )
                Text(
                    text = "@${item.author}",
                    color = Color.Gray,
                    fontSize = 11.sp
                )

                Spacer(Modifier.height(4.dp))

                // Bottom action buttons row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { onToggleLike() }
                    ) {
                        Icon(
                            if (item.isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Like",
                            tint = if (item.isLiked) YiffyPrimary else Color.LightGray,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = item.likesCount.toString(),
                            color = Color.LightGray,
                            fontSize = 11.sp
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { onOpenComments() }
                    ) {
                        Icon(
                            Icons.Default.ChatBubble,
                            contentDescription = "Comments",
                            tint = Color.LightGray,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = item.commentsCount.toString(),
                            color = Color.LightGray,
                            fontSize = 11.sp
                        )
                    }

                    IconButton(
                        onClick = onToggleFavorite,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            if (item.isFavorited) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                            contentDescription = "Favorite",
                            tint = if (item.isFavorited) Color(0xFFFFB300) else Color.LightGray,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Miscellaneous Feed View:
 * Shows social-style posts with author, user avatar, platform badge icon,
 * captions, video/picture embeds, and "+" icon up to the right to add sources.
 */
@Composable
fun MiscFeedView(
    items: List<MediaItem>,
    onToggleLike: (MediaItem) -> Unit,
    onToggleFavorite: (MediaItem) -> Unit,
    onOpenComments: (MediaItem) -> Unit,
    onDownload: (MediaItem) -> Unit,
    onOpenAddSource: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0A0B0E))
            .statusBarsPadding()
    ) {
        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Public, contentDescription = null, tint = YiffyPrimary)
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "Miscellaneous Feed",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
            }

            // Plus icon on top right to add sources
            IconButton(
                onClick = onOpenAddSource,
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(YiffyPrimary)
                    .testTag("add_source_misc_btn")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Sources", tint = Color.White)
            }
        }

        // Stream of social posts (Twitter, Bluesky, Reddit style)
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier
                .fillMaxSize()
                .testTag("misc_posts_list")
        ) {
            items(items, key = { it.id }) { item ->
                SocialPostCard(
                    item = item,
                    onToggleLike = { onToggleLike(item) },
                    onToggleFavorite = { onToggleFavorite(item) },
                    onOpenComments = { onOpenComments(item) },
                    onDownload = { onDownload(item) }
                )
            }
        }
    }
}

@Composable
fun SocialPostCard(
    item: MediaItem,
    onToggleLike: () -> Unit,
    onToggleFavorite: () -> Unit,
    onOpenComments: () -> Unit,
    onDownload: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = YiffySurfaceVariant),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("misc_card_${item.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Post Author Header: User Avatar + Handle + Platform Badge Icon
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF2C3140)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (item.authorAvatarUrl.isNotBlank()) {
                            AsyncImage(
                                model = item.authorAvatarUrl,
                                contentDescription = item.author,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Text(
                                text = item.author.take(1).uppercase(),
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(Modifier.width(10.dp))

                    Column {
                        Text(
                            text = item.author,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = item.title,
                            color = Color.LightGray,
                            fontSize = 11.sp
                        )
                    }
                }

                // Platform Badge Chip
                Surface(
                    color = Color(item.source.badgeColorHex),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = item.source.displayName,
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(Modifier.height(10.dp))

            // Text Caption (Like a Twitter / Bluesky post)
            if (item.caption.isNotBlank()) {
                Text(
                    text = item.caption,
                    color = Color(0xFFE4E8F2),
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
                Spacer(Modifier.height(10.dp))
            }

            // Media attachment embed
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1.35f)
                    .clip(RoundedCornerShape(10.dp))
                    .clickable(onClick = onOpenComments)
            ) {
                AsyncImage(
                    model = item.previewUrl.ifBlank { item.mediaUrl },
                    contentDescription = item.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(Modifier.height(12.dp))

            // Action Bar (Like, Comment, Favorite, Download)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { onToggleLike() }
                ) {
                    Icon(
                        if (item.isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Like",
                        tint = if (item.isLiked) YiffyPrimary else Color.LightGray,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = item.likesCount.toString(),
                        color = Color.LightGray,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { onOpenComments() }
                ) {
                    Icon(
                        Icons.Default.ChatBubble,
                        contentDescription = "Comments",
                        tint = Color.LightGray,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = item.commentsCount.toString(),
                        color = Color.LightGray,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { onToggleFavorite() }
                ) {
                    Icon(
                        if (item.isFavorited) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                        contentDescription = "Favorite",
                        tint = if (item.isFavorited) Color(0xFFFFB300) else Color.LightGray,
                        modifier = Modifier.size(20.dp)
                    )
                }

                IconButton(
                    onClick = onDownload,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        Icons.Default.Download,
                        contentDescription = "Save",
                        tint = Color.LightGray,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

/**
 * Add / Select Sources Dialog triggered by "+" icon
 */
@Composable
fun AddSourceDialog(
    enabledSources: Set<String>,
    onToggleSource: (String) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = YiffySurface,
        title = {
            Text(
                "Customize Platform Sources",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        },
        text = {
            Column {
                Text(
                    "Toggle sources to include in your feeds:",
                    color = Color.LightGray,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
                MediaSource.entries.forEach { source ->
                    val isEnabled = enabledSources.contains(source.name)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onToggleSource(source.name) }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(Color(source.badgeColorHex))
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(source.displayName, color = Color.White, fontSize = 14.sp)
                        }

                        if (isEnabled) {
                            Icon(Icons.Default.Check, contentDescription = "Active", tint = YiffyPrimary)
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Done", color = YiffyPrimary, fontWeight = FontWeight.Bold)
            }
        }
    )
}
