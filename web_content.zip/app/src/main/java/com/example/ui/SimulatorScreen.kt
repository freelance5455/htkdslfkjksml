package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.ArrowDropUp
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Numbers
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Remove
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.CloudDownload
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.Fingerprint
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.HttpMethod
import com.example.model.PacingMode
import com.example.model.SimulationState
import com.example.model.VisitResult
import com.example.ui.components.DeviceTypeIcon
import com.example.ui.components.LatencyChip
import com.example.ui.components.MetricCard
import com.example.ui.components.StatusBadge
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber
import com.example.viewmodel.TrafficSimulatorViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SimulatorScreen(
    viewModel: TrafficSimulatorViewModel,
    modifier: Modifier = Modifier
) {
    val config by viewModel.config.collectAsState()
    val stats by viewModel.stats.collectAsState()
    val visits by viewModel.visits.collectAsState()
    var showAdvanced by remember { mutableStateOf(false) }

    val isRunning = stats.state == SimulationState.RUNNING
    val isPaused = stats.state == SimulationState.PAUSED
    val isBusy = isRunning || isPaused

    val animatedProgress by animateFloatAsState(targetValue = stats.progress, label = "progress")

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Target URL Card
        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
            ),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Target Website",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    // Method Selector
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        HttpMethod.values().forEach { method ->
                            FilterChip(
                                selected = config.httpMethod == method,
                                onClick = { if (!isBusy) viewModel.updateHttpMethod(method) },
                                label = { Text(method.name, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                modifier = Modifier.testTag("method_${method.name.lowercase()}")
                            )
                        }
                    }
                }

                // URL Input Field
                OutlinedTextField(
                    value = config.url,
                    onValueChange = { viewModel.updateUrl(it) },
                    enabled = !isBusy,
                    label = { Text("Website URL (e.g. https://your-server.com)") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Language,
                            contentDescription = null,
                            tint = CyberCyan
                        )
                    },
                    trailingIcon = {
                        if (config.url.isNotBlank() && !isBusy) {
                            IconButton(onClick = { viewModel.updateUrl("") }) {
                                Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear URL")
                            }
                        }
                    },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("url_input_field")
                )

                // Quick Preset URL Chips
                Text(
                    text = "Quick Test Endpoints:",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(
                        "Demo (httpbin.org)" to "https://httpbin.org/get",
                        "Example.com" to "https://example.com",
                        "Cloudflare Trace" to "https://www.cloudflare.com/cdn-cgi/trace",
                        "Postman Echo" to "https://postman-echo.com/get"
                    ).forEach { (label, presetUrl) ->
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (config.url == presetUrl) CyberCyan else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier
                                .clickable(enabled = !isBusy) {
                                    viewModel.updateUrl(presetUrl)
                                }
                                .testTag("preset_${label.lowercase().replace(" ", "_")}")
                        ) {
                            Text(
                                text = label,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                color = if (config.url == presetUrl) CyberCyan else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                // Verify Real Network Ping Button
                if (!isBusy) {
                    OutlinedButton(
                        onClick = { viewModel.testSinglePing() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("verify_ping_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CyberCyan)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Speed,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Verify Real Connection (Test 1 Ping & Inspect Response)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // Engine Selection Card (HTTP Client vs Full Browser WebView)
        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
            ),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Simulation Engine",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Choose how TrafficPulse visits the target URL",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Surface(
                        color = CyberCyan.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = config.executionEngine.badge,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyberCyan,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    com.example.model.ExecutionEngine.values().forEach { engine ->
                        val isSelected = config.executionEngine == engine
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) CyberCyan.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surface,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) CyberCyan else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .clickable(enabled = !isBusy) {
                                    viewModel.updateExecutionEngine(engine)
                                }
                                .testTag("engine_${engine.name.lowercase()}")
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = engine.label,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) CyberCyan else MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (engine == com.example.model.ExecutionEngine.HTTP_CLIENT)
                                        "High throughput, low latency. Directly registers in server access logs and backend counters."
                                    else
                                        "Full WebKit browser. Executes client-side JavaScript, firing Google Analytics & tracking tags.",
                                    fontSize = 10.sp,
                                    lineHeight = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // Visits Count & Quick Chips
        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
            ),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Total Visits to Simulate",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Type any amount or tap a preset below",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        text = "${config.totalVisits} visits",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = CyberCyan
                    )
                }

                // Direct Numeric Typing Input
                var typedVisitsText by remember(config.totalVisits) { mutableStateOf(config.totalVisits.toString()) }

                OutlinedTextField(
                    value = typedVisitsText,
                    onValueChange = { input ->
                        val digits = input.filter { it.isDigit() }
                        typedVisitsText = digits
                        val parsed = digits.toIntOrNull()
                        if (parsed != null && parsed > 0) {
                            viewModel.updateTotalVisits(parsed)
                        }
                    },
                    enabled = !isBusy,
                    label = { Text("Type Number of Visits (e.g. 35, 75, 200, 500)") },
                    placeholder = { Text("Enter custom amount") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Numbers,
                            contentDescription = null,
                            tint = CyberCyan
                        )
                    },
                    trailingIcon = {
                        if (!isBusy) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = {
                                        val current = config.totalVisits
                                        if (current > 5) viewModel.updateTotalVisits(current - 5)
                                    },
                                    enabled = config.totalVisits > 5
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Remove,
                                        contentDescription = "Minus 5",
                                        tint = CyberCyan
                                    )
                                }
                                IconButton(
                                    onClick = {
                                        viewModel.updateTotalVisits(config.totalVisits + 5)
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "Plus 5",
                                        tint = CyberCyan
                                    )
                                }
                            }
                        }
                    },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number,
                        imeAction = ImeAction.Done
                    ),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("typed_visits_input")
                )

                // Quick Shortcut Preset Chips
                Text(
                    text = "Quick Presets:",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(10, 35, 50, 100, 250, 500).forEach { count ->
                        val isSelected = config.totalVisits == count
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                if (!isBusy) {
                                    viewModel.updateTotalVisits(count)
                                    typedVisitsText = count.toString()
                                }
                            },
                            label = {
                                Text(
                                    text = if (count == 35) "35 (Recommended)" else "$count",
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CyberCyan.copy(alpha = 0.2f),
                                selectedLabelColor = CyberCyan
                            ),
                            modifier = Modifier.testTag("visit_chip_$count")
                        )
                    }
                }

                // Fine-tuning Steppers
                if (!isBusy) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Quick Adjust: ",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        listOf(-25, -10, +10, +25).forEach { delta ->
                            OutlinedButton(
                                onClick = {
                                    val newCount = (config.totalVisits + delta).coerceAtLeast(1)
                                    viewModel.updateTotalVisits(newCount)
                                    typedVisitsText = newCount.toString()
                                },
                                modifier = Modifier
                                    .padding(horizontal = 2.dp)
                                    .height(30.dp),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp)
                            ) {
                                Text(
                                    text = if (delta > 0) "+$delta" else "$delta",
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Advanced Simulation Accordion (Pacing, Concurrency, Toggles)
        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
            ),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .animateContentSize()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showAdvanced = !showAdvanced },
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = null,
                            tint = CyberCyan,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Pacing, Concurrency & Signature Options",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Icon(
                        imageVector = if (showAdvanced) Icons.Default.ArrowDropUp else Icons.Default.ArrowDropDown,
                        contentDescription = null
                    )
                }

                AnimatedVisibility(visible = showAdvanced) {
                    Column(
                        modifier = Modifier.padding(top = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Pacing Mode
                        Text(
                            text = "Simulation Pacing",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            PacingMode.values().forEach { mode ->
                                FilterChip(
                                    selected = config.pacingMode == mode,
                                    onClick = { if (!isBusy) viewModel.updatePacing(mode) },
                                    label = { Text(mode.label, fontSize = 11.sp) }
                                )
                            }
                        }

                        // Concurrency Mode
                        Text(
                            text = "Concurrency Level (Workers)",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(
                                1 to "1 (Sequential)",
                                2 to "2 (Pair)",
                                5 to "5 (Batch)",
                                10 to "10 (Burst)"
                            ).forEach { (count, label) ->
                                FilterChip(
                                    selected = config.concurrency == count,
                                    onClick = { if (!isBusy) viewModel.updateConcurrency(count) },
                                    label = { Text(label, fontSize = 11.sp) }
                                )
                            }
                        }

                        // Session Profile Toggles
                        Text(
                            text = "Session Isolation & Signatures",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold
                        )
                        ToggleRow(
                            label = "Clean Isolated Cookies (Zero cookie reuse)",
                            sub = "Forces server to generate a new session cookie per visit",
                            checked = config.isolatedCookies,
                            onCheckedChange = { viewModel.toggleIsolatedCookies(it) },
                            enabled = !isBusy
                        )
                        ToggleRow(
                            label = "Rotate User-Agents (Mobile & Desktop)",
                            sub = "Varies Chrome, Safari, Firefox, iOS & Android",
                            checked = config.rotateUserAgents,
                            onCheckedChange = { viewModel.toggleRotateAgents(it) },
                            enabled = !isBusy
                        )
                        ToggleRow(
                            label = "Rotate Simulated IP Headers",
                            sub = "Applies distinct IPs to X-Forwarded-For & Client-IP",
                            checked = config.rotateSimulatedIps,
                            onCheckedChange = { viewModel.toggleRotateIps(it) },
                            enabled = !isBusy
                        )
                        ToggleRow(
                            label = "Rotate Referrers (Google, X, Reddit, Direct)",
                            sub = "Simulates authentic referral distribution for analytics",
                            checked = config.rotateReferrers,
                            onCheckedChange = { viewModel.toggleRotateReferrers(it) },
                            enabled = !isBusy
                        )
                    }
                }
            }
        }

        // Primary Control Buttons (Start / Pause / Stop / Reset)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            when {
                stats.state == SimulationState.IDLE || stats.state == SimulationState.COMPLETED || stats.state == SimulationState.STOPPED -> {
                    Button(
                        onClick = { viewModel.startSimulation() },
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("start_simulation_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyberCyan,
                            contentColor = Color(0xFF003548)
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (stats.state == SimulationState.COMPLETED) "Run Again (${config.totalVisits} Visits)" else "Start Simulation (${config.totalVisits} Visits)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
                stats.state == SimulationState.RUNNING -> {
                    Button(
                        onClick = { viewModel.pauseSimulation() },
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("pause_simulation_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = WarningAmber)
                    ) {
                        Icon(imageVector = Icons.Default.Pause, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Pause", fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = { viewModel.stopSimulation() },
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("stop_simulation_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
                    ) {
                        Icon(imageVector = Icons.Default.Stop, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Stop", fontWeight = FontWeight.Bold)
                    }
                }
                stats.state == SimulationState.PAUSED -> {
                    Button(
                        onClick = { viewModel.resumeSimulation() },
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("resume_simulation_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)
                    ) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Resume", fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = { viewModel.stopSimulation() },
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("stop_simulation_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
                    ) {
                        Icon(imageVector = Icons.Default.Stop, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Stop", fontWeight = FontWeight.Bold)
                    }
                }
            }

            if (stats.completedCount > 0 && !isBusy) {
                OutlinedButton(
                    onClick = { viewModel.resetSimulation() },
                    modifier = Modifier
                        .height(52.dp)
                        .testTag("reset_simulation_button"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = "Reset")
                }
            }
        }

        // Live Simulation Banner & Progress
        if (stats.state != SimulationState.IDLE) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        if (stats.state == SimulationState.RUNNING) CyberCyan.copy(alpha = 0.5f) else Color.Transparent,
                        RoundedCornerShape(16.dp)
                    )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when (stats.state) {
                                            SimulationState.RUNNING -> CyberCyan
                                            SimulationState.PAUSED -> WarningAmber
                                            SimulationState.COMPLETED -> SuccessGreen
                                            SimulationState.STOPPED -> ErrorRed
                                            else -> Color.Gray
                                        }
                                    )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = when (stats.state) {
                                    SimulationState.RUNNING -> "Simulating Traffic Visits..."
                                    SimulationState.PAUSED -> "Simulation Paused"
                                    SimulationState.COMPLETED -> "Simulation Completed Successfully"
                                    SimulationState.STOPPED -> "Simulation Aborted"
                                    else -> "Idle"
                                },
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "${stats.completedCount} / ${stats.totalScheduled}",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = CyberCyan
                        )
                    }

                    // Progress Bar
                    LinearProgressIndicator(
                        progress = { animatedProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = CyberCyan,
                        trackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                    )

                    // Secondary Live Metrics
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${(stats.progress * 100).toInt()}% Done",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (stats.state == SimulationState.RUNNING && stats.requestsPerSecond > 0) {
                            Text(
                                text = "Speed: ${"%.1f".format(stats.requestsPerSecond)} req/s",
                                style = MaterialTheme.typography.bodySmall,
                                color = CyberCyan
                            )
                        }
                        if (stats.state == SimulationState.RUNNING && stats.estimatedTimeRemainingSeconds > 0) {
                            Text(
                                text = "ETA: ~${stats.estimatedTimeRemainingSeconds}s",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // Live Real-Time Metrics Grid
        if (stats.completedCount > 0) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Live Traffic Metrics",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricCard(
                        title = "Success Rate",
                        value = "${if (stats.completedCount > 0) (stats.successCount * 100 / stats.completedCount) else 0}%",
                        subtitle = "${stats.successCount} of ${stats.completedCount} 2xx",
                        icon = Icons.Outlined.CheckCircle,
                        accentColor = SuccessGreen,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "Avg Latency",
                        value = "${stats.avgLatencyMs} ms",
                        subtitle = "Min: ${stats.minLatencyMs}ms / Max: ${stats.maxLatencyMs}ms",
                        icon = Icons.Outlined.Timer,
                        accentColor = CyberCyan,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricCard(
                        title = "Unique Profiles",
                        value = "${visits.map { it.sessionProfile.id }.distinct().size}",
                        subtitle = "Isolated cookie & IP jars",
                        icon = Icons.Outlined.Fingerprint,
                        accentColor = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "Errors / Drop",
                        value = "${stats.clientErrorCount + stats.serverErrorCount + stats.networkErrorCount}",
                        subtitle = "${stats.networkErrorCount} conn failed",
                        icon = Icons.Outlined.ErrorOutline,
                        accentColor = if (stats.clientErrorCount + stats.serverErrorCount + stats.networkErrorCount > 0) ErrorRed else SuccessGreen,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Streaming Recent Visits Feed
        if (visits.isNotEmpty()) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Recent Simulated Visits (${visits.size})",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Tap to inspect headers",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                // Show top 6 latest visits
                visits.take(6).forEach { visit ->
                    RecentVisitCard(
                        visit = visit,
                        onClick = { viewModel.selectVisit(visit) }
                    )
                }
            }
        }
    }
}

@Composable
fun RecentVisitCard(
    visit: VisitResult,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
        ),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("recent_visit_${visit.index}")
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 14.dp, vertical = 10.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                DeviceTypeIcon(
                    deviceType = visit.sessionProfile.deviceType,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "#${visit.index}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = CyberCyan
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = visit.sessionProfile.browserName,
                            fontWeight = FontWeight.Medium,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Text(
                        text = "${visit.sessionProfile.simulatedIp} • ${visit.sessionProfile.referer?.replace("https://", "")?.take(18) ?: "Direct"}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                LatencyChip(latencyMs = visit.latencyMs)
                Spacer(modifier = Modifier.width(10.dp))
                StatusBadge(statusCode = visit.statusCode, statusMessage = visit.statusMessage)
            }
        }
    }
}

@Composable
private fun ToggleRow(
    label: String,
    sub: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    enabled: Boolean = true
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = sub,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 11.sp
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            enabled = enabled,
            colors = SwitchDefaults.colors(
                checkedThumbColor = CyberCyan,
                checkedTrackColor = CyberCyan.copy(alpha = 0.35f)
            )
        )
    }
}
