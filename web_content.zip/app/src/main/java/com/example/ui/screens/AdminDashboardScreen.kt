package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.localization.AppLang
import com.example.localization.SjsStrings
import com.example.model.*
import com.example.ui.components.DigitalReceiptDialog
import com.example.ui.components.VerifiedBadgeChip
import com.example.ui.theme.*
import com.example.viewmodel.UiState

@Composable
fun AdminDashboardScreen(
    lang: AppLang,
    usersState: UiState<List<UserProfile>>,
    providersState: UiState<List<SecurityProvider>>,
    ordersState: UiState<List<SecurityOrder>>,
    paymentsState: UiState<List<PaymentTransaction>>,
    complaintsState: UiState<List<Complaint>>,
    auditLogsState: UiState<List<AuditLog>>,
    isBusy: Boolean,
    onVerifyProvider: (String, VerificationStatus, Boolean, Boolean) -> Unit,
    onCollectCommission: (SecurityProvider, Long) -> Unit,
    onVerifyPayment: (PaymentTransaction) -> Unit,
    onResolveComplaint: (String, ComplaintStatus, String) -> Unit,
    onBootstrapCatalog: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var receiptPreview by remember { mutableStateOf<PaymentTransaction?>(null) }

    val users = (usersState as? UiState.Success)?.data ?: emptyList()
    val providers = (providersState as? UiState.Success)?.data ?: emptyList()
    val orders = (ordersState as? UiState.Success)?.data ?: emptyList()
    val payments = (paymentsState as? UiState.Success)?.data ?: emptyList()
    val complaints = (complaintsState as? UiState.Success)?.data ?: emptyList()
    val auditLogs = (auditLogsState as? UiState.Success)?.data ?: emptyList()

    val verifiedCount = providers.count { it.verifiedBadge }
    val unverifiedCount = providers.size - verifiedCount
    val completedOrdersCount = orders.count { it.statusEnum() == OrderStatus.CLOSED }
    val cancelledOrdersCount = orders.count { it.statusEnum() == OrderStatus.CANCELLED }

    val commissionRevenue = payments
        .filter { it.paymentType == "ORDER_PAYMENT" && it.statusEnum() == PaymentStatus.VERIFIED }
        .sumOf { it.commissionTzs } + providers.sumOf { it.commissionCollectedTzs }
    val subscriptionRevenue = payments
        .filter { it.paymentType == "PROVIDER_SUBSCRIPTION" && it.statusEnum() == PaymentStatus.VERIFIED }
        .sumOf { it.amountTzs }
    val totalPlatformRevenue = commissionRevenue + subscriptionRevenue

    Column(modifier = Modifier.fillMaxSize().background(OffWhite)) {
        Surface(color = NavyDeep, contentColor = PureWhite) {
            Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = SjsStrings.t(lang, "Dashibodi ya Msimamizi (Admin)", "Smart Jones Admin Control Center"),
                    style = MaterialTheme.typography.titleLarge,
                    color = PureWhite
                )
                ScrollableTabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = NavyElevated,
                    contentColor = OrangeBright,
                    edgePadding = 0.dp
                ) {
                    listOf(
                        SjsStrings.t(lang, "Takwimu", "Analytics"),
                        SjsStrings.t(lang, "Makampuni (${providers.size})", "Providers (${providers.size})"),
                        SjsStrings.t(lang, "Malipo (${payments.size})", "Payments (${payments.size})"),
                        SjsStrings.t(lang, "Malalamiko (${complaints.size})", "Complaints (${complaints.size})"),
                        SjsStrings.t(lang, "Kumbukumbu", "Audit Logs")
                    ).forEachIndexed { idx, label ->
                        Tab(
                            selected = selectedTab == idx,
                            onClick = { selectedTab = idx },
                            text = { Text(label, maxLines = 1) }
                        )
                    }
                }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when (selectedTab) {
                0 -> {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                AdminKpiCard(SjsStrings.t(lang, "Wateja", "Customers"), users.size.toString(), NavyDeep, Modifier.weight(1f))
                                AdminKpiCard(SjsStrings.t(lang, "Makampuni", "Companies"), "${providers.size} (✓$verifiedCount / ⏳$unverifiedCount)", NavyElevated, Modifier.weight(1f))
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                AdminKpiCard(SjsStrings.t(lang, "Oda Zote", "Total Bookings"), orders.size.toString(), CharcoalGrey, Modifier.weight(1f))
                                AdminKpiCard(SjsStrings.t(lang, "Zilizokamilika / Ghairi", "Done / Cancelled"), "$completedOrdersCount / $cancelledOrdersCount", VerifiedGreen, Modifier.weight(1f))
                            }
                            AdminKpiCard(
                                SjsStrings.t(lang, "Jumla ya Mapato ya Jukwaa", "Total Platform Revenue"),
                                TzsFormatter.format(totalPlatformRevenue),
                                OrangeBrand,
                                Modifier.fillMaxWidth()
                            )
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                AdminKpiCard(SjsStrings.t(lang, "Kamisheni (5%)", "5% Commission Rev"), TzsFormatter.format(commissionRevenue), NavyDeep, Modifier.weight(1f))
                                AdminKpiCard(SjsStrings.t(lang, "Ada za Mwezi", "Subscription Rev"), TzsFormatter.format(subscriptionRevenue), NavyMuted, Modifier.weight(1f))
                            }
                        }
                    }

                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = PureWhite), shape = RoundedCornerShape(16.dp)) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text(
                                    text = SjsStrings.t(lang, "Mchanganuo wa Mapato na Oda", "Revenue & Order Analytics"),
                                    style = MaterialTheme.typography.titleMedium,
                                    color = NavyDeep
                                )
                                RevenueBarChart(
                                    commissionRevenue = commissionRevenue,
                                    subscriptionRevenue = subscriptionRevenue,
                                    completedOrders = completedOrdersCount,
                                    cancelledOrders = cancelledOrdersCount
                                )
                            }
                        }
                    }

                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = OrangeContainer), shape = RoundedCornerShape(16.dp)) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(
                                    text = SjsStrings.t(lang, "Usimamizi wa Katalogi na Nakala (Backup)", "Marketplace Controls & Backup"),
                                    style = MaterialTheme.typography.titleSmall,
                                    color = NavyDeep
                                )
                                Text(
                                    text = SjsStrings.t(
                                        lang,
                                        "Ongeza makampuni ya mwanzo yaliyohakikiwa au kagua kumbukumbu za ukaguzi (Audit Logs: ${auditLogs.size}).",
                                        "Seed verified starter companies across Tanzania or review immutable audit logs (${auditLogs.size} entries)."
                                    ),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CharcoalGrey
                                )
                                Button(
                                    onClick = onBootstrapCatalog,
                                    enabled = !isBusy,
                                    colors = ButtonDefaults.buttonColors(containerColor = NavyDeep),
                                    modifier = Modifier.testTag("admin_bootstrap_button")
                                ) {
                                    Text(SjsStrings.t(lang, "Weka Makampuni ya Mwanzo", "Bootstrap Verified Tanzania Catalog"))
                                }
                            }
                        }
                    }
                }

                1 -> {
                    items(providers, key = { it.id }) { prov ->
                        Card(colors = CardDefaults.cardColors(containerColor = PureWhite), shape = RoundedCornerShape(16.dp)) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(prov.companyName, style = MaterialTheme.typography.titleMedium, color = NavyDeep)
                                        Text("BRELA: ${prov.businessRegNumber} • PSRA: ${prov.securityLicenseNumber}", style = MaterialTheme.typography.labelSmall, color = SlateGrey)
                                    }
                                    VerifiedBadgeChip(lang, prov.verifiedBadge)
                                }
                                Text("${prov.revenueModel} • Owed: ${TzsFormatter.format(prov.commissionOwedTzs)}", style = MaterialTheme.typography.bodySmall)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = { onVerifyProvider(prov.id, VerificationStatus.VERIFIED, true, true) },
                                        enabled = !isBusy,
                                        colors = ButtonDefaults.buttonColors(containerColor = VerifiedGreen)
                                    ) {
                                        Text(SjsStrings.t(lang, "Hakiki & Beji", "Verify + Badge"))
                                    }
                                    OutlinedButton(
                                        onClick = { onVerifyProvider(prov.id, VerificationStatus.SUSPENDED, false, false) },
                                        enabled = !isBusy
                                    ) {
                                        Text(SjsStrings.t(lang, "Simamisha", "Suspend"), color = ErrorRed)
                                    }
                                    if (prov.commissionOwedTzs > 0L) {
                                        OutlinedButton(
                                            onClick = { onCollectCommission(prov, prov.commissionOwedTzs) },
                                            enabled = !isBusy
                                        ) {
                                            Text(SjsStrings.t(lang, "Kusanya 5%", "Collect"))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                2 -> {
                    items(payments, key = { it.id }) { tx ->
                        Card(colors = CardDefaults.cardColors(containerColor = PureWhite), shape = RoundedCornerShape(16.dp)) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("${tx.transactionRef} (${tx.mode})", style = MaterialTheme.typography.titleSmall, color = NavyDeep)
                                    Text(TzsFormatter.format(tx.amountTzs), style = MaterialTheme.typography.labelLarge, color = OrangeBrand)
                                }
                                Text("${tx.payerName} (${tx.payerPhone}) -> ${tx.recipientNumber}", style = MaterialTheme.typography.bodySmall, color = SlateGrey)
                                Text("Status: ${tx.status} • Type: ${tx.paymentType}", style = MaterialTheme.typography.labelMedium)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    if (tx.statusEnum() != PaymentStatus.VERIFIED) {
                                        Button(
                                            onClick = { onVerifyPayment(tx) },
                                            enabled = !isBusy,
                                            colors = ButtonDefaults.buttonColors(containerColor = VerifiedGreen)
                                        ) {
                                            Text(SjsStrings.t(lang, "Thibitisha Malipo", "Verify Settlement"))
                                        }
                                    }
                                    OutlinedButton(onClick = { receiptPreview = tx }) {
                                        Text(SjsStrings.t(lang, "Risiti", "Receipt"))
                                    }
                                }
                            }
                        }
                    }
                }

                3 -> {
                    if (complaints.isEmpty()) {
                        item {
                            Text(SjsStrings.t(lang, "Hakuna malalamiko kwa sasa.", "No customer complaints."), color = SlateGrey)
                        }
                    } else {
                        items(complaints, key = { it.id }) { cmp ->
                            Card(colors = CardDefaults.cardColors(containerColor = PureWhite), shape = RoundedCornerShape(16.dp)) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(cmp.subject, style = MaterialTheme.typography.titleSmall, color = NavyDeep)
                                        Text(cmp.status, style = MaterialTheme.typography.labelMedium, color = OrangeBrand)
                                    }
                                    Text("${cmp.customerName}: ${cmp.description}", style = MaterialTheme.typography.bodySmall)
                                    if (cmp.statusEnum() != ComplaintStatus.RESOLVED) {
                                        Button(
                                            onClick = { onResolveComplaint(cmp.id, ComplaintStatus.RESOLVED, "Resolved by Smart Jones Admin") },
                                            enabled = !isBusy,
                                            colors = ButtonDefaults.buttonColors(containerColor = VerifiedGreen)
                                        ) {
                                            Text(SjsStrings.t(lang, "Tatua Lalamiko", "Mark Resolved"))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                4 -> {
                    items(auditLogs, key = { it.id }) { log ->
                        Card(colors = CardDefaults.cardColors(containerColor = PureWhite), shape = RoundedCornerShape(12.dp)) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(log.action, style = MaterialTheme.typography.labelLarge, color = NavyDeep)
                                Text(log.summary, style = MaterialTheme.typography.bodySmall, color = CharcoalGrey)
                                Text("${log.actorEmail} • ${log.targetType}:${log.targetId}", style = MaterialTheme.typography.labelSmall, color = SlateGrey)
                            }
                        }
                    }
                }
            }
        }
    }

    receiptPreview?.let { tx ->
        DigitalReceiptDialog(payment = tx, lang = lang, onDismiss = { receiptPreview = null })
    }
}

@Composable
private fun AdminKpiCard(title: String, value: String, accent: androidx.compose.ui.graphics.Color, modifier: Modifier = Modifier) {
    Card(colors = CardDefaults.cardColors(containerColor = PureWhite), shape = RoundedCornerShape(14.dp), modifier = modifier) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = MaterialTheme.typography.bodySmall, color = SlateGrey)
            Text(value, style = MaterialTheme.typography.titleMedium, color = accent)
        }
    }
}

@Composable
private fun RevenueBarChart(
    commissionRevenue: Long,
    subscriptionRevenue: Long,
    completedOrders: Int,
    cancelledOrders: Int
) {
    val maxVal = maxOf(commissionRevenue, subscriptionRevenue, 20_000L).toFloat()
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Canvas(modifier = Modifier.fillMaxWidth().height(110.dp)) {
            val barW = size.width * 0.25f
            val h1 = ((commissionRevenue / maxVal) * size.height * 0.85f).coerceAtLeast(12f)
            val h2 = ((subscriptionRevenue / maxVal) * size.height * 0.85f).coerceAtLeast(12f)
            drawRoundRect(
                color = OrangeBrand,
                topLeft = Offset(size.width * 0.15f, size.height - h1),
                size = Size(barW, h1),
                cornerRadius = CornerRadius(12f, 12f)
            )
            drawRoundRect(
                color = NavyDeep,
                topLeft = Offset(size.width * 0.60f, size.height - h2),
                size = Size(barW, h2),
                cornerRadius = CornerRadius(12f, 12f)
            )
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
            Text("5% Commission", style = MaterialTheme.typography.labelSmall, color = OrangeBrand)
            Text("Subscriptions", style = MaterialTheme.typography.labelSmall, color = NavyDeep)
        }
        Text(
            text = "Completed: $completedOrders • Cancelled: $cancelledOrders",
            style = MaterialTheme.typography.bodySmall,
            color = SlateGrey
        )
    }
}
