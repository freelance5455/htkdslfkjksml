package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.Announcement
import com.example.data.model.Course
import com.example.data.model.Lesson
import com.example.data.model.UserProfile
import com.example.ui.theme.BorderLight
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldDark
import com.example.ui.theme.NavyCard
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.NavySurface
import com.example.ui.theme.StatusPending
import com.example.ui.theme.StatusPendingBg
import com.example.ui.theme.StatusPublished
import com.example.ui.theme.StatusPublishedBg
import com.example.ui.theme.TextDarkPrimary
import com.example.ui.theme.TextDarkSecondary
import com.example.ui.theme.TextMuted

@Composable
fun AdminDashboardScreen(
    courses: List<Course>,
    lessons: List<Lesson>,
    announcements: List<Announcement>,
    registeredUsers: List<UserProfile>,
    supabaseUrl: String,
    supabaseKey: String,
    onAddLesson: (courseId: String, title: String, status: String, desc: String, videoUrl: String?, pdfUrl: String?) -> Unit,
    onUpdateLesson: (Lesson) -> Unit,
    onDeleteLesson: (lessonId: String) -> Unit,
    onToggleLessonPublish: (lessonId: String) -> Unit,
    onToggleCoursePublish: (courseId: String) -> Unit,
    onDeleteCourse: (courseId: String) -> Unit,
    onAddAnnouncement: (title: String, content: String, isPinned: Boolean) -> Unit,
    onDeleteAnnouncement: (id: String) -> Unit,
    onSaveSupabaseConfig: (url: String, key: String) -> Unit,
    onExitAdmin: () -> Unit
) {
    var selectedTab by remember { mutableStateOf("المحاضرات") }
    val tabs = listOf("المحاضرات", "الكورسات", "التنبيهات", "الطلاب", "سحابة Supabase")

    var editingLesson by remember { mutableStateOf<Lesson?>(null) }
    var showAddLessonDialog by remember { mutableStateOf(false) }
    var showAddAnnouncementDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC))
            .padding(bottom = 80.dp)
            .testTag("admin_dashboard_screen")
    ) {
        // Admin Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(NavyDeep, NavyPrimary)
                        )
                    )
                    .padding(20.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(GoldAccent),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AdminPanelSettings,
                                    contentDescription = null,
                                    tint = NavyDeep,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "لوحة تحكم مستر زاهر",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = "إدارة المحتوى والمحاضرات والطلاب",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = GoldAccent
                                )
                            }
                        }

                        Button(
                            onClick = onExitAdmin,
                            colors = ButtonDefaults.buttonColors(containerColor = NavySurface),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("خروج", color = Color.White, fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Tab bar
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(tabs) { tab ->
                            FilterChip(
                                selected = (selectedTab == tab),
                                onClick = { selectedTab = tab },
                                label = {
                                    Text(
                                        text = tab,
                                        fontWeight = if (selectedTab == tab) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 12.sp
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = GoldAccent,
                                    selectedLabelColor = NavyDeep,
                                    containerColor = NavySurface,
                                    labelColor = Color.White
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = (selectedTab == tab),
                                    borderColor = if (selectedTab == tab) GoldAccent else Color.Transparent
                                )
                            )
                        }
                    }
                }
            }
        }

        // Content based on selected tab
        when (selectedTab) {
            "المحاضرات" -> {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "إدارة المحاضرات والشروحات",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = NavyPrimary
                            )
                            Text(
                                text = "تعديل حالة المحاضرات ورفع روابط الفيديو والمذكرات",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextMuted
                            )
                        }

                        Button(
                            onClick = { showAddLessonDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("admin_add_lesson_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("إضافة محاضرة", fontSize = 12.sp)
                        }
                    }
                }

                items(lessons) { lesson ->
                    val course = courses.find { it.id == lesson.courseId }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, BorderLight),
                        elevation = CardDefaults.cardElevation(2.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = lesson.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = NavyPrimary
                                    )
                                    Text(
                                        text = "تابع لكورس: ${course?.title ?: "غير محدد"}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = GoldDark,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }

                                Surface(
                                    color = if (lesson.status == "لسه هتنزل") StatusPendingBg else StatusPublishedBg,
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text(
                                        text = lesson.status,
                                        color = if (lesson.status == "لسه هتنزل") StatusPending else StatusPublished,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = lesson.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextDarkSecondary
                            )

                            if (!lesson.videoUrl.isNullOrBlank()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.PlayCircle, contentDescription = null, tint = NavyPrimary, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("رابط الفيديو: ${lesson.videoUrl}", fontSize = 11.sp, color = NavyPrimary, maxLines = 1)
                                }
                            }

                            if (!lesson.pdfUrl.isNullOrBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = Color.Red, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("رابط PDF: ${lesson.pdfUrl}", fontSize = 11.sp, color = TextDarkSecondary, maxLines = 1)
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = { onToggleLessonPublish(lesson.id) }
                                    ) {
                                        Icon(
                                            imageVector = if (lesson.isPublished) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                            contentDescription = "حالة النشر",
                                            tint = if (lesson.isPublished) StatusPublished else TextMuted
                                        )
                                    }
                                    Text(
                                        text = if (lesson.isPublished) "منشورة للطلاب" else "مخفية",
                                        fontSize = 11.sp,
                                        color = if (lesson.isPublished) StatusPublished else TextMuted
                                    )
                                }

                                Row {
                                    Button(
                                        onClick = { editingLesson = lesson },
                                        colors = ButtonDefaults.buttonColors(containerColor = GoldAccent),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.padding(end = 6.dp)
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = null, tint = NavyDeep, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("تعديل والمحتوى", color = NavyDeep, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }

                                    IconButton(onClick = { onDeleteLesson(lesson.id) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            "الكورسات" -> {
                item {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "الكورسات الثلاثة المعتمدة",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = NavyPrimary
                        )
                        Text(
                            text = "الكورسات الرسمية لمنصة القائد مع مستر زاهر جمال",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextMuted
                        )
                    }
                }

                items(courses) { course ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, BorderLight),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = course.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = NavyPrimary
                                )
                                Text(
                                    text = course.subtitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = GoldDark
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = if (course.isPublished) "نشط" else "معطل",
                                    fontSize = 12.sp,
                                    color = if (course.isPublished) StatusPublished else TextMuted
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Switch(
                                    checked = course.isPublished,
                                    onCheckedChange = { onToggleCoursePublish(course.id) },
                                    colors = SwitchDefaults.colors(checkedThumbColor = GoldAccent, checkedTrackColor = NavyPrimary)
                                )
                            }
                        }
                    }
                }
            }

            "التنبيهات" -> {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "تنبيهات وأخبار الطلاب",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = NavyPrimary
                        )

                        Button(
                            onClick = { showAddAnnouncementDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("نشر تنبيه", fontSize = 12.sp)
                        }
                    }
                }

                items(announcements) { ann ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, BorderLight),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = ann.title, fontWeight = FontWeight.Bold, color = NavyPrimary)
                                IconButton(onClick = { onDeleteAnnouncement(ann.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red, modifier = Modifier.size(18.dp))
                                }
                            }
                            Text(text = ann.content, fontSize = 13.sp, color = TextDarkSecondary)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = "التاريخ: ${ann.date}", fontSize = 11.sp, color = TextMuted)
                        }
                    }
                }
            }

            "الطلاب" -> {
                item {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "قائمة الطلاب المسجلين (${registeredUsers.size} طالب)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = NavyPrimary
                        )
                        Text(
                            text = "سجل الطلاب المسجلين للتواصل والمتابعة",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextMuted
                        )
                    }
                }

                items(registeredUsers) { user ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, BorderLight),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = user.fullName, fontWeight = FontWeight.Bold, color = NavyPrimary)
                                Text(text = "هاتف: ${user.phone}", fontSize = 12.sp, color = TextDarkSecondary)
                                Text(text = "المرحلة: ${user.academicStage}", fontSize = 12.sp, color = GoldDark, fontWeight = FontWeight.Medium)
                            }

                            Surface(color = Color(0xFFF1F5F9), shape = RoundedCornerShape(8.dp)) {
                                Text(
                                    text = "${user.enrolledCourses.size} كورس",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = NavyPrimary,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }

            "سحابة Supabase" -> {
                item {
                    var inputUrl by remember { mutableStateOf(supabaseUrl) }
                    var inputKey by remember { mutableStateOf(supabaseKey) }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(14.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, BorderLight),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CloudDone, contentDescription = null, tint = NavyPrimary, modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "إعدادات الربط السحابي Supabase",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = NavyPrimary
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = "يمكنك إدخال بيانات مشروع Supabase الخاص بمنصة القائد لمزامنة الطلاب والمحاضرات سحابياً في الوقت الفعلي وحفظ البيانات بأمان.",
                                fontSize = 12.sp,
                                color = TextDarkSecondary,
                                lineHeight = 18.sp
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            OutlinedTextField(
                                value = inputUrl,
                                onValueChange = { inputUrl = it },
                                label = { Text("Supabase Project URL") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = inputKey,
                                onValueChange = { inputKey = it },
                                label = { Text("Supabase Anon Public Key") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            Button(
                                onClick = { onSaveSupabaseConfig(inputUrl, inputKey) },
                                colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("حفظ وتحديث الاتصال السحابي", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // SQL Guide & RLS Policies Card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = NavyDeep),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "دليل الجداول وسياسات الأمان (RLS)",
                                fontWeight = FontWeight.Bold,
                                color = GoldAccent,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "تم تهيئة ملفات المشروع كاملة مع دليل إعداد Supabase المكتمل في SUPABASE_SETUP.md، متضمناً كود SQL لإنشاء جداول courses, lessons, announcements وسياسات Row Level Security المشددة لحماية عمليات المدير.",
                                fontSize = 12.sp,
                                color = Color.White.copy(alpha = 0.9f),
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            }
        }
    }

    // Edit Lesson Dialog
    if (editingLesson != null) {
        val current = editingLesson!!
        var title by remember { mutableStateOf(current.title) }
        var status by remember { mutableStateOf(current.status) }
        var desc by remember { mutableStateOf(current.description) }
        var videoUrl by remember { mutableStateOf(current.videoUrl ?: "") }
        var pdfUrl by remember { mutableStateOf(current.pdfUrl ?: "") }

        Dialog(onDismissRequest = { editingLesson = null }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                LazyColumn(modifier = Modifier.padding(18.dp)) {
                    item {
                        Text(
                            text = "تعديل المحاضرة",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = NavyPrimary
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = title,
                            onValueChange = { title = it },
                            label = { Text("عنوان المحاضرة") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(text = "حالة المحاضرة:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("لسه هتنزل", "متاحة الآن").forEach { st ->
                                FilterChip(
                                    selected = (status == st),
                                    onClick = { status = st },
                                    label = { Text(st) }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = desc,
                            onValueChange = { desc = it },
                            label = { Text("وصف المحاضرة وتوجيهات مستر زاهر") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = videoUrl,
                            onValueChange = { videoUrl = it },
                            label = { Text("رابط الفيديو (YouTube / MP4)") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = pdfUrl,
                            onValueChange = { pdfUrl = it },
                            label = { Text("رابط المذكرة (PDF / Drive)") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(18.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = { editingLesson = null },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("إلغاء")
                            }

                            Button(
                                onClick = {
                                    val updated = current.copy(
                                        title = title.trim(),
                                        status = status,
                                        description = desc.trim(),
                                        videoUrl = videoUrl.trim().ifBlank { null },
                                        pdfUrl = pdfUrl.trim().ifBlank { null }
                                    )
                                    onUpdateLesson(updated)
                                    editingLesson = null
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("حفظ التعديلات", color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Lesson Dialog
    if (showAddLessonDialog) {
        var selectedCourseId by remember { mutableStateOf(courses.firstOrNull()?.id ?: "") }
        var title by remember { mutableStateOf("") }
        var status by remember { mutableStateOf("لسه هتنزل") }
        var desc by remember { mutableStateOf("") }
        var videoUrl by remember { mutableStateOf("") }
        var pdfUrl by remember { mutableStateOf("") }

        Dialog(onDismissRequest = { showAddLessonDialog = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                LazyColumn(modifier = Modifier.padding(18.dp)) {
                    item {
                        Text(
                            text = "إضافة محاضرة جديدة",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = NavyPrimary
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(text = "اختر الكورس التابع له:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(courses) { c ->
                                FilterChip(
                                    selected = (selectedCourseId == c.id),
                                    onClick = { selectedCourseId = c.id },
                                    label = { Text(c.title) }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = title,
                            onValueChange = { title = it },
                            label = { Text("عنوان المحاضرة (مثال: المحاضرة الثانية)") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = desc,
                            onValueChange = { desc = it },
                            label = { Text("الوصف وتفاصيل المحاضرة") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = videoUrl,
                            onValueChange = { videoUrl = it },
                            label = { Text("رابط الفيديو (اختياري)") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = pdfUrl,
                            onValueChange = { pdfUrl = it },
                            label = { Text("رابط ملف الـ PDF (اختياري)") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(18.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = { showAddLessonDialog = false },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("إلغاء")
                            }

                            Button(
                                onClick = {
                                    if (title.isNotBlank()) {
                                        onAddLesson(selectedCourseId, title, status, desc, videoUrl, pdfUrl)
                                        showAddLessonDialog = false
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("إضافة المحاضرة", color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Announcement Dialog
    if (showAddAnnouncementDialog) {
        var annTitle by remember { mutableStateOf("") }
        var annContent by remember { mutableStateOf("") }

        Dialog(onDismissRequest = { showAddAnnouncementDialog = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "نشر تنبيه جديد للطلاب",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = NavyPrimary
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = annTitle,
                        onValueChange = { annTitle = it },
                        label = { Text("عنوان التنبيه") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = annContent,
                        onValueChange = { annContent = it },
                        label = { Text("نص التنبيه والملاحظات") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showAddAnnouncementDialog = false },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("إلغاء")
                        }

                        Button(
                            onClick = {
                                if (annTitle.isNotBlank()) {
                                    onAddAnnouncement(annTitle, annContent, false)
                                    showAddAnnouncementDialog = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("نشر الآن", color = Color.White)
                        }
                    }
                }
            }
        }
    }
}
