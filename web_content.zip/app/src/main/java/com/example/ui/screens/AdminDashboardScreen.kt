package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.AdInquiry
import com.example.data.model.Auction
import com.example.data.model.BusinessAd
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.data.model.WalletTransaction
import com.example.data.model.WithdrawalRequest
import com.example.ui.components.BidderNumberChip
import com.example.ui.components.CommissionBreakdownCard
import com.example.ui.theme.MonoFontFamily
import com.example.util.formatNaira
import com.example.util.formatTimestamp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    auctionsState: UiState<List<Auction>>,
    usersState: UiState<List<UserProfile>>,
    withdrawalsState: UiState<List<WithdrawalRequest>>,
    adsState: UiState<List<BusinessAd>>,
    inquiriesState: UiState<List<AdInquiry>>,
    transactionsState: UiState<List<WalletTransaction>>,
    isBusy: Boolean,
    onBack: () -> Unit,
    onSeedShowcase: () -> Unit,
    onUpdateAuctionStatus: (auctionId: String, newStatus: String) -> Unit,
    onToggleAuctionFeatured: (auctionId: String, featured: Boolean) -> Unit,
    onDeleteAuction: (auctionId: String) -> Unit,
    onProcessWithdrawal: (withdrawalId: String, approve: Boolean, note: String) -> Unit,
    onToggleUserStatus: (userId: String, newStatus: String) -> Unit,
    onSaveBusinessAd: (adId: String?, name: String, tagline: String, cta: String, category: String, fee: Long, status: String) -> Unit,
    onDeleteBusinessAd: (adId: String) -> Unit,
    onUpdateAdInquiry: (inquiryId: String, status: String, note: String) -> Unit
) {
    BackHandler(onBack = onBack)

    var selectedTab by remember { mutableIntStateOf(0) }
    var showAdEditor by remember { mutableStateOf(false) }
    var editingAd by remember { mutableStateOf<BusinessAd?>(null) }

    val auctions = (auctionsState as? UiState.Success)?.data ?: emptyList()
    val users = (usersState as? UiState.Success)?.data ?: emptyList()
    val withdrawals = (withdrawalsState as? UiState.Success)?.data ?: emptyList()
    val ads = (adsState as? UiState.Success)?.data ?: emptyList()
    val inquiries = (inquiriesState as? UiState.Success)?.data ?: emptyList()
    val transactions = (transactionsState as? UiState.Success)?.data ?: emptyList()

    val totalCommissions = remember(auctions) { auctions.filter { it.status == "SETTLED" }.sumOf { it.commissionAmount } }
    val totalFeaturedFees = remember(auctions) { auctions.sumOf { it.featuredFeePaid } }
    val totalAdDeals = remember(ads) { ads.sumOf { it.negotiatedFee } }
    val pendingWithdrawalsCount = remember(withdrawals) { withdrawals.count { it.status == "PENDING" } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("True A Admin Control") },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("admin_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    TextButton(
                        onClick = onSeedShowcase,
                        enabled = !isBusy,
                        modifier = Modifier.testTag("admin_seed_button")
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Seed Lots")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            ScrollableTabRow(selectedTabIndex = selectedTab, edgePadding = 12.dp) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Lots (${auctions.size})") })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Payouts ($pendingWithdrawalsCount)") })
                Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Users (${users.size})") })
                Tab(selected = selectedTab == 3, onClick = { selectedTab = 3 }, text = { Text("Business Ads") })
                Tab(selected = selectedTab == 4, onClick = { selectedTab = 4 }, text = { Text("Revenue") })
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 860.dp),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                when (selectedTab) {
                    0 -> {
                        items(auctions, key = { it.id }) { lot ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(lot.title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                                        Surface(
                                            color = MaterialTheme.colorScheme.primaryContainer,
                                            shape = RoundedCornerShape(50.dp)
                                        ) {
                                            Text(
                                                text = lot.status,
                                                style = MaterialTheme.typography.labelSmall,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = "Seller: ${lot.sellerBidderNumber} • Current: ${formatNaira(lot.currentBid)} • Bids: ${lot.bidCount}",
                                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = MonoFontFamily),
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        FilterChip(
                                            selected = lot.featured,
                                            onClick = { onToggleAuctionFeatured(lot.id, !lot.featured) },
                                            label = { Text(if (lot.featured) "Featured ★" else "Feature") }
                                        )
                                        if (lot.status == "ACTIVE") {
                                            OutlinedButton(onClick = { onUpdateAuctionStatus(lot.id, "PAUSED") }) {
                                                Text("Pause")
                                            }
                                            OutlinedButton(onClick = { onUpdateAuctionStatus(lot.id, "ENDED") }) {
                                                Text("End Now")
                                            }
                                        } else if (lot.status == "PAUSED") {
                                            OutlinedButton(onClick = { onUpdateAuctionStatus(lot.id, "ACTIVE") }) {
                                                Text("Resume")
                                            }
                                        }
                                        IconButton(onClick = { onDeleteAuction(lot.id) }) {
                                            Icon(Icons.Default.Delete, contentDescription = "Delete lot", tint = MaterialTheme.colorScheme.error)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    1 -> {
                        items(withdrawals, key = { it.id }) { wd ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text("${wd.userDisplayName} (${wd.bidderNumber})", style = MaterialTheme.typography.titleSmall)
                                            Text("${wd.bankName} • ${wd.accountNumber} (${wd.accountName})", style = MaterialTheme.typography.bodySmall)
                                        }
                                        Text(
                                            text = formatNaira(wd.amount),
                                            style = MaterialTheme.typography.titleMedium.copy(fontFamily = MonoFontFamily),
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    Text(
                                        text = "Status: ${wd.status} • ${formatTimestamp(wd.createdAt)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    if (wd.status == "PENDING") {
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Button(
                                                onClick = { onProcessWithdrawal(wd.id, true, "Approved & disbursed via NIP") },
                                                enabled = !isBusy,
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Text("Approve & Pay")
                                            }
                                            OutlinedButton(
                                                onClick = { onProcessWithdrawal(wd.id, false, "Bank verification failed") },
                                                enabled = !isBusy,
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Text("Decline & Refund")
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    2 -> {
                        items(users, key = { it.userId }) { user ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(user.displayName, style = MaterialTheme.typography.titleSmall)
                                        Text(user.email, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        BidderNumberChip(bidderNumber = user.bidderNumber)
                                    }
                                    val isSuspended = user.accountStatus == "SUSPENDED"
                                    OutlinedButton(
                                        onClick = {
                                            onToggleUserStatus(user.userId, if (isSuspended) "ACTIVE" else "SUSPENDED")
                                        },
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            contentColor = if (isSuspended) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                                        )
                                    ) {
                                        Text(if (isSuspended) "Activate" else "Suspend")
                                    }
                                }
                            }
                        }
                    }

                    3 -> {
                        item {
                            Button(
                                onClick = {
                                    editingAd = null
                                    showAdEditor = true
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Create Negotiated Business Ad")
                            }
                        }
                        items(ads, key = { it.id }) { ad ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(ad.businessName, style = MaterialTheme.typography.titleMedium)
                                        Text(
                                            text = formatNaira(ad.negotiatedFee),
                                            style = MaterialTheme.typography.titleSmall.copy(fontFamily = MonoFontFamily),
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    Text(ad.tagline, style = MaterialTheme.typography.bodySmall)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton(onClick = {
                                            editingAd = ad
                                            showAdEditor = true
                                        }) {
                                            Text("Edit")
                                        }
                                        OutlinedButton(onClick = { onDeleteBusinessAd(ad.id) }) {
                                            Text("Delete")
                                        }
                                    }
                                }
                            }
                        }
                        if (inquiries.isNotEmpty()) {
                            item {
                                Text("Incoming Ad Proposals (${inquiries.size})", style = MaterialTheme.typography.titleMedium)
                            }
                            items(inquiries, key = { it.id }) { inq ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(inq.businessName, style = MaterialTheme.typography.titleSmall)
                                            Text(
                                                text = "Budget: ${formatNaira(inq.proposedBudget)}",
                                                style = MaterialTheme.typography.labelMedium.copy(fontFamily = MonoFontFamily),
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                        Text(inq.message, style = MaterialTheme.typography.bodySmall)
                                        Text("Status: ${inq.status}", style = MaterialTheme.typography.labelSmall)
                                        if (inq.status == "PENDING" || inq.status == "NEGOTIATING") {
                                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                Button(onClick = { onUpdateAdInquiry(inq.id, "APPROVED", "Terms agreed") }) {
                                                    Text("Approve")
                                                }
                                                OutlinedButton(onClick = { onUpdateAdInquiry(inq.id, "DECLINED", "Slot unavailable") }) {
                                                    Text("Decline")
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    4 -> {
                        item {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                                shape = RoundedCornerShape(20.dp)
                            ) {
                                Column(
                                    modifier = Modifier.padding(18.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text("True A Revenue Summary", style = MaterialTheme.typography.titleLarge)
                                    Text(
                                        text = "3% Sales Commissions: ${formatNaira(totalCommissions)}",
                                        style = MaterialTheme.typography.titleMedium.copy(fontFamily = MonoFontFamily)
                                    )
                                    Text(
                                        text = "Featured Auction Fees (₦2,000 ea): ${formatNaira(totalFeaturedFees)}",
                                        style = MaterialTheme.typography.titleMedium.copy(fontFamily = MonoFontFamily)
                                    )
                                    Text(
                                        text = "Negotiated Business Ads: ${formatNaira(totalAdDeals)}",
                                        style = MaterialTheme.typography.titleMedium.copy(fontFamily = MonoFontFamily)
                                    )
                                    Text(
                                        text = "Total Platform Ledger Entries: ${transactions.size}",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }
                        item {
                            CommissionBreakdownCard(
                                grossAmount = 500000L,
                                title = "3% Standard Commission Verification (₦500,000 Sale)"
                            )
                        }
                    }
                }
            }
        }
    }

    if (showAdEditor) {
        AdminBusinessAdDialog(
            existing = editingAd,
            onDismiss = { showAdEditor = false },
            onSave = { name, tagline, cta, cat, fee, status ->
                onSaveBusinessAd(editingAd?.id, name, tagline, cta, cat, fee, status)
                showAdEditor = false
            }
        )
    }
}

@Composable
private fun AdminBusinessAdDialog(
    existing: BusinessAd?,
    onDismiss: () -> Unit,
    onSave: (String, String, String, String, Long, String) -> Unit
) {
    var name by remember { mutableStateOf(existing?.businessName ?: "") }
    var tagline by remember { mutableStateOf(existing?.tagline ?: "") }
    var cta by remember { mutableStateOf(existing?.ctaLabel ?: "Visit Partner") }
    var category by remember { mutableStateOf(existing?.category ?: "Partner") }
    var feeText by remember { mutableStateOf((existing?.negotiatedFee ?: 50000L).toString()) }
    var status by remember { mutableStateOf(existing?.status ?: "ACTIVE") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Create Business Ad" else "Edit Business Ad") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Business Name") }, singleLine = true)
                OutlinedTextField(value = tagline, onValueChange = { tagline = it }, label = { Text("Ad Tagline") }, minLines = 2)
                OutlinedTextField(value = cta, onValueChange = { cta = it }, label = { Text("Button Label") }, singleLine = true)
                OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Category") }, singleLine = true)
                OutlinedTextField(
                    value = feeText,
                    onValueChange = { feeText = it.filter { c -> c.isDigit() } },
                    label = { Text("Negotiated Fee (₦)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("ACTIVE", "PAUSED").forEach { st ->
                        FilterChip(selected = status == st, onClick = { status = st }, label = { Text(st) })
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(name, tagline, cta, category, feeText.toLongOrNull() ?: 0L, status) },
                enabled = name.trim().length >= 2 && tagline.trim().length >= 4
            ) {
                Text("Save Ad")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
