package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.PayoutEntity
import com.example.data.local.ReportEntity
import com.example.data.local.UserEntity
import com.example.data.local.VideoEntity
import com.example.ui.theme.ZingBlack
import com.example.ui.theme.ZingBorder
import com.example.ui.theme.ZingCardSurface
import com.example.ui.theme.ZingCyan
import com.example.ui.theme.ZingDarkSurface
import com.example.ui.theme.ZingEmerald
import com.example.ui.theme.ZingGold
import com.example.ui.theme.ZingNeonPink
import com.example.ui.theme.ZingTextMuted
import com.example.ui.theme.ZingTextPrimary
import com.example.ui.theme.ZingTextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val adminTabs = listOf("Reports", "Videos", "Payouts", "Users")

@Composable
fun AdminDashboardScreen(
    reports: List<ReportEntity>,
    videos: List<VideoEntity>,
    payouts: List<PayoutEntity>,
    users: List<UserEntity>,
    onBack: () -> Unit,
    onResolveReport: (String, Boolean, String?) -> Unit,
    onToggleVideoTakeDown: (String, Boolean) -> Unit,
    onUpdatePayoutStatus: (String, String) -> Unit,
    onToggleBlockUser: (String, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ZingBlack)
            .statusBarsPadding()
    ) {
        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = ZingTextPrimary)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Security, contentDescription = null, tint = ZingCyan, modifier = Modifier.size(22.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "Sinji Shorts Platform Admin",
                        color = ZingTextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Moderation, Content Safety & Payout Control",
                        color = ZingTextSecondary,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Summary Metric Badges
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AdminMetricCard(title = "Reports", count = reports.size.toString(), color = ZingNeonPink, modifier = Modifier.weight(1f))
            AdminMetricCard(title = "Videos", count = videos.size.toString(), color = ZingCyan, modifier = Modifier.weight(1f))
            AdminMetricCard(title = "Payouts", count = payouts.size.toString(), color = ZingGold, modifier = Modifier.weight(1f))
            AdminMetricCard(title = "Users", count = users.size.toString(), color = ZingEmerald, modifier = Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Tab Row
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            containerColor = ZingBlack,
            contentColor = ZingCyan,
            edgePadding = 16.dp,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = ZingCyan
                )
            }
        ) {
            adminTabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            text = title,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 13.sp
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Tab Content
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            when (selectedTab) {
                0 -> AdminReportsList(
                    reports = reports,
                    onResolveReport = { reportId, takeDown, videoId ->
                        onResolveReport(reportId, takeDown, videoId)
                        Toast.makeText(context, if (takeDown) "Content taken down!" else "Report dismissed", Toast.LENGTH_SHORT).show()
                    }
                )
                1 -> AdminVideosList(
                    videos = videos,
                    onToggleTakeDown = { videoId, takeDown ->
                        onToggleVideoTakeDown(videoId, takeDown)
                        Toast.makeText(context, if (takeDown) "Video taken down" else "Video restored", Toast.LENGTH_SHORT).show()
                    }
                )
                2 -> AdminPayoutsList(
                    payouts = payouts,
                    onUpdateStatus = { payoutId, status ->
                        onUpdatePayoutStatus(payoutId, status)
                        Toast.makeText(context, "Payout updated to $status", Toast.LENGTH_SHORT).show()
                    }
                )
                3 -> AdminUsersList(
                    users = users,
                    onToggleBlock = { userId, blocked ->
                        onToggleBlockUser(userId, blocked)
                        Toast.makeText(context, if (blocked) "User blocked" else "User unblocked", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }
    }
}

@Composable
private fun AdminMetricCard(title: String, count: String, color: Color, modifier: Modifier = Modifier) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = ZingCardSurface),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = count, color = color, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(text = title, color = ZingTextSecondary, fontSize = 10.sp)
        }
    }
}

@Composable
private fun AdminReportsList(
    reports: List<ReportEntity>,
    onResolveReport: (String, Boolean, String?) -> Unit
) {
    if (reports.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No pending reports. Platform content is clean!", color = ZingTextSecondary)
        }
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            reports.forEach { report ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = ZingCardSurface),
                    modifier = Modifier.fillMaxWidth().border(1.dp, ZingBorder, RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Reported for: ${report.reason}", color = ZingNeonPink, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (report.status == "PENDING_REVIEW") ZingGold.copy(alpha = 0.15f) else ZingEmerald.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = report.status,
                                    color = if (report.status == "PENDING_REVIEW") ZingGold else ZingEmerald,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(text = "\"${report.targetCaption}\"", color = ZingTextPrimary, fontSize = 12.sp)

                        if (report.status == "PENDING_REVIEW") {
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { onResolveReport(report.id, true, report.targetVideoId) },
                                    colors = ButtonDefaults.buttonColors(containerColor = ZingNeonPink),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Take Down Video", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                Button(
                                    onClick = { onResolveReport(report.id, false, null) },
                                    colors = ButtonDefaults.buttonColors(containerColor = ZingDarkSurface, contentColor = ZingTextSecondary),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f).border(1.dp, ZingBorder, RoundedCornerShape(10.dp))
                                ) {
                                    Text("Dismiss Report", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminVideosList(
    videos: List<VideoEntity>,
    onToggleTakeDown: (String, Boolean) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        videos.forEach { video ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = ZingCardSurface),
                modifier = Modifier.fillMaxWidth().border(1.dp, ZingBorder, RoundedCornerShape(14.dp))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "@${video.creatorHandle}",
                            color = ZingCyan,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = video.caption,
                            color = ZingTextPrimary,
                            fontSize = 12.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${video.viewsCount} views • ${video.likesCount} likes • ${if (video.isTakenDown) "REMOVED" else "ACTIVE"}",
                            color = if (video.isTakenDown) ZingNeonPink else ZingEmerald,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = { onToggleTakeDown(video.id, !video.isTakenDown) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (video.isTakenDown) ZingEmerald else ZingNeonPink
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = if (video.isTakenDown) "Restore" else "Take Down",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminPayoutsList(
    payouts: List<PayoutEntity>,
    onUpdateStatus: (String, String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        payouts.forEach { payout ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = ZingCardSurface),
                modifier = Modifier.fillMaxWidth().border(1.dp, ZingBorder, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "₹${String.format("%,.2f", payout.amount)}",
                            color = ZingGold,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Text(
                            text = payout.status,
                            color = when (payout.status) {
                                "COMPLETED" -> ZingEmerald
                                "PROCESSING" -> ZingGold
                                else -> ZingCyan
                            },
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Method: ${payout.payoutMethod} (${payout.accountDetails})",
                        color = ZingTextSecondary,
                        fontSize = 12.sp
                    )

                    if (payout.status != "COMPLETED") {
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { onUpdateStatus(payout.id, "COMPLETED") },
                                colors = ButtonDefaults.buttonColors(containerColor = ZingEmerald),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Approve & Mark Paid", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Button(
                                onClick = { onUpdateStatus(payout.id, "REJECTED") },
                                colors = ButtonDefaults.buttonColors(containerColor = ZingDarkSurface, contentColor = ZingNeonPink),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(0.6f).border(1.dp, ZingNeonPink, RoundedCornerShape(8.dp))
                            ) {
                                Text("Reject", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminUsersList(
    users: List<UserEntity>,
    onToggleBlock: (String, Boolean) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        users.forEach { user ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = ZingCardSurface),
                modifier = Modifier.fillMaxWidth().border(1.dp, ZingBorder, RoundedCornerShape(14.dp))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(user.displayName, color = ZingTextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("@${user.username} • Role: ${user.role}", color = ZingTextSecondary, fontSize = 11.sp)
                        Text(
                            text = if (user.isBlocked) "STATUS: BLOCKED" else "STATUS: ACTIVE",
                            color = if (user.isBlocked) ZingNeonPink else ZingEmerald,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = { onToggleBlock(user.id, !user.isBlocked) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (user.isBlocked) ZingEmerald else ZingDarkSurface,
                            contentColor = if (user.isBlocked) Color.White else ZingNeonPink
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.border(1.dp, if (user.isBlocked) ZingEmerald else ZingNeonPink, RoundedCornerShape(8.dp))
                    ) {
                        Text(if (user.isBlocked) "Unblock" else "Block / Ban", fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
