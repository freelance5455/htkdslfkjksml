package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.BookAiService
import com.example.data.model.AiGeneratedChapterDraft
import com.example.data.model.Book
import com.example.data.model.Chapter
import com.example.data.repository.BookRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

private const val TAG = "BookStudioVM"
private const val STOP_TIMEOUT_MILLIS = 5000L

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

sealed interface AiCreationState {
    data object Idle : AiCreationState
    data class Generating(val statusMessage: String) : AiCreationState
    data class Completed(val createdBookId: String) : AiCreationState
    data class Error(val message: String) : AiCreationState
}

enum class StudioDestination {
    HOME_LIBRARY,
    CREATE_WITH_AI,
    CREATE_MANUALLY,
    BOOK_READER
}

enum class LibraryFilter {
    ALL,
    AI_ONLY,
    MANUAL_ONLY
}

class BookStudioViewModel(
    private val repository: BookRepository,
    private val aiService: BookAiService,
    private val currentUserId: String
) : ViewModel() {

    private val _currentDestination = MutableStateFlow(StudioDestination.HOME_LIBRARY)
    val currentDestination: StateFlow<StudioDestination> = _currentDestination.asStateFlow()

    private val _selectedBookId = MutableStateFlow<String?>(null)
    val selectedBookId: StateFlow<String?> = _selectedBookId.asStateFlow()

    private val _libraryFilter = MutableStateFlow(LibraryFilter.ALL)
    val libraryFilter: StateFlow<LibraryFilter> = _libraryFilter.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _aiCreationState = MutableStateFlow<AiCreationState>(AiCreationState.Idle)
    val aiCreationState: StateFlow<AiCreationState> = _aiCreationState.asStateFlow()

    private val _operationMessage = MutableStateFlow<String?>(null)
    val operationMessage: StateFlow<String?> = _operationMessage.asStateFlow()

    private val _isSavingManual = MutableStateFlow(false)
    val isSavingManual: StateFlow<Boolean> = _isSavingManual.asStateFlow()

    private val _isGeneratingChapterAi = MutableStateFlow(false)
    val isGeneratingChapterAi: StateFlow<Boolean> = _isGeneratingChapterAi.asStateFlow()

    val booksState: StateFlow<UiState<List<Book>>> = repository.observeBooks(currentUserId)
        .map<List<Book>, UiState<List<Book>>> { UiState.Success(it) }
        .catch { error ->
            Log.w(TAG, "Failed to observe books", error)
            emit(UiState.Error(error.localizedMessage ?: "Kitaplık yüklenemedi."))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    @OptIn(ExperimentalCoroutinesApi::class)
    val activeBookState: StateFlow<Book?> = _selectedBookId
        .flatMapLatest { bookId ->
            if (bookId.isNullOrBlank()) {
                flowOf(null)
            } else {
                repository.observeBook(currentUserId, bookId)
                    .catch { e ->
                        Log.w(TAG, "Error observing active book", e)
                        emit(null)
                    }
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = null
        )

    @OptIn(ExperimentalCoroutinesApi::class)
    val activeChaptersState: StateFlow<UiState<List<Chapter>>> = _selectedBookId
        .flatMapLatest { bookId ->
            if (bookId.isNullOrBlank()) {
                flowOf(UiState.Success(emptyList()))
            } else {
                repository.observeChapters(currentUserId, bookId)
                    .map<List<Chapter>, UiState<List<Chapter>>> { UiState.Success(it) }
                    .catch { e ->
                        Log.w(TAG, "Error observing chapters", e)
                        emit(UiState.Error(e.localizedMessage ?: "Bölümler yüklenemedi."))
                    }
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = UiState.Loading
        )

    fun navigateToAiCreator() {
        _aiCreationState.value = AiCreationState.Idle
        _currentDestination.value = StudioDestination.CREATE_WITH_AI
    }

    fun navigateToManualCreator() {
        _currentDestination.value = StudioDestination.CREATE_MANUALLY
    }

    fun openBookReader(bookId: String) {
        _selectedBookId.value = bookId
        _currentDestination.value = StudioDestination.BOOK_READER
    }

    fun navigateHome() {
        _aiCreationState.value = AiCreationState.Idle
        _currentDestination.value = StudioDestination.HOME_LIBRARY
    }

    fun setLibraryFilter(filter: LibraryFilter) {
        _libraryFilter.value = filter
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun clearOperationMessage() {
        _operationMessage.value = null
    }

    fun resetAiState() {
        _aiCreationState.value = AiCreationState.Idle
    }

    fun createBookWithAi(
        topic: String,
        genre: String,
        tone: String,
        chapterCount: Int,
        coverTheme: String
    ) {
        if (topic.isBlank()) {
            _aiCreationState.value = AiCreationState.Error("Lütfen kitabınız için bir konu veya fikir yazın.")
            return
        }

        val safeChapterCount = chapterCount.coerceIn(1, 240)
        viewModelScope.launch {
            _aiCreationState.value = AiCreationState.Generating(
                "Yapay zeka \"$genre\" türünde $safeChapterCount bölümlük kitabınızı kurguluyor ve uzun bölümler halinde yazıyor…"
            )
            try {
                val generatedDraft = aiService.generateFullBook(
                    topic = topic.trim(),
                    genre = genre,
                    tone = tone,
                    targetChapterCount = safeChapterCount,
                    onProgressUpdate = { statusMsg ->
                        _aiCreationState.value = AiCreationState.Generating(statusMsg)
                    }
                )

                _aiCreationState.value = AiCreationState.Generating(
                    "${generatedDraft.chapters.size} bölüm bulut kitaplığınıza kaydediliyor…"
                )

                val bookId = repository.createBookWithChapters(
                    title = generatedDraft.title,
                    subtitle = generatedDraft.subtitle,
                    synopsis = generatedDraft.synopsis,
                    genre = genre,
                    tone = tone,
                    creationMethod = "ai",
                    coverTheme = coverTheme,
                    chapters = generatedDraft.chapters
                )

                _selectedBookId.value = bookId
                _aiCreationState.value = AiCreationState.Completed(bookId)
                _currentDestination.value = StudioDestination.BOOK_READER
                _operationMessage.value = "\"${generatedDraft.title}\" (${generatedDraft.chapters.size} bölüm) başarıyla AI ile oluşturuldu!"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "AI Book creation failed", e)
                _aiCreationState.value = AiCreationState.Error(
                    e.localizedMessage ?: "Kitap oluşturulurken bir hata meydana geldi."
                )
            }
        }
    }

    fun createManualBook(
        title: String,
        subtitle: String,
        synopsis: String,
        genre: String,
        tone: String,
        coverTheme: String,
        chapters: List<AiGeneratedChapterDraft>,
        onValidationError: (String) -> Unit
    ) {
        if (title.isBlank()) {
            onValidationError("Lütfen kitabınız için bir başlık girin.")
            return
        }
        val nonEmptyChapters = chapters.filter { it.title.isNotBlank() || it.content.isNotBlank() }
            .ifEmpty {
                listOf(
                    AiGeneratedChapterDraft(
                        chapterNumber = 1,
                        title = "1. Bölüm: Giriş",
                        summary = "İlk bölüm",
                        content = "Hikayeniz burada başlıyor…"
                    )
                )
            }

        viewModelScope.launch {
            _isSavingManual.value = true
            try {
                val bookId = repository.createBookWithChapters(
                    title = title,
                    subtitle = subtitle,
                    synopsis = synopsis,
                    genre = genre,
                    tone = tone,
                    creationMethod = "manual",
                    coverTheme = coverTheme,
                    chapters = nonEmptyChapters
                )
                _isSavingManual.value = false
                _selectedBookId.value = bookId
                _currentDestination.value = StudioDestination.BOOK_READER
                _operationMessage.value = "\"$title\" kitaplığınıza kaydedildi!"
            } catch (e: CancellationException) {
                _isSavingManual.value = false
                throw e
            } catch (e: Exception) {
                _isSavingManual.value = false
                Log.e(TAG, "Manual book creation failed", e)
                onValidationError(e.localizedMessage ?: "Kitap kaydedilemedi.")
            }
        }
    }

    fun addManualChapter(
        book: Book,
        nextChapterNumber: Int,
        title: String,
        summary: String,
        content: String,
        onComplete: () -> Unit
    ) {
        viewModelScope.launch {
            try {
                repository.addChapterToBook(
                    book = book,
                    chapterNumber = nextChapterNumber,
                    title = title,
                    summary = summary,
                    content = content
                )
                _operationMessage.value = "$nextChapterNumber. Bölüm eklendi."
                onComplete()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _operationMessage.value = e.localizedMessage ?: "Bölüm eklenemedi."
            }
        }
    }

    fun generateAndAddAiChapter(
        book: Book,
        nextChapterNumber: Int,
        directionPrompt: String,
        onComplete: () -> Unit
    ) {
        viewModelScope.launch {
            _isGeneratingChapterAi.value = true
            try {
                val draft = aiService.generateSingleChapter(
                    bookTitle = book.title,
                    bookSynopsis = book.synopsis,
                    genre = book.genre,
                    tone = book.tone,
                    chapterNumber = nextChapterNumber,
                    chapterDirection = directionPrompt
                )
                repository.addChapterToBook(
                    book = book,
                    chapterNumber = nextChapterNumber,
                    title = draft.title,
                    summary = draft.summary,
                    content = draft.content
                )
                _isGeneratingChapterAi.value = false
                _operationMessage.value = "\"${draft.title}\" AI ile yazıldı ve eklendi!"
                onComplete()
            } catch (e: CancellationException) {
                _isGeneratingChapterAi.value = false
                throw e
            } catch (e: Exception) {
                _isGeneratingChapterAi.value = false
                _operationMessage.value = e.localizedMessage ?: "AI bölüm üretimi başarısız oldu."
            }
        }
    }

    fun expandExistingChapterWithAi(
        book: Book,
        chapter: Chapter,
        totalChapters: Int
    ) {
        viewModelScope.launch {
            _isGeneratingChapterAi.value = true
            try {
                val expanded = aiService.expandChapterContent(
                    bookTitle = book.title,
                    bookSynopsis = book.synopsis,
                    genre = book.genre,
                    tone = book.tone,
                    chapterNumber = chapter.chapterNumber.toInt(),
                    totalChapters = totalChapters,
                    currentTitle = chapter.title,
                    currentSummary = chapter.summary,
                    currentContent = chapter.content
                )
                repository.updateChapter(
                    book = book,
                    chapter = chapter,
                    newTitle = expanded.title.ifBlank { chapter.title },
                    newSummary = expanded.summary.ifBlank { chapter.summary },
                    newContent = expanded.content
                )
                _isGeneratingChapterAi.value = false
                _operationMessage.value = "${chapter.chapterNumber}. Bölüm AI ile uzatıldı ve detaylandırıldı!"
            } catch (e: CancellationException) {
                _isGeneratingChapterAi.value = false
                throw e
            } catch (e: Exception) {
                _isGeneratingChapterAi.value = false
                _operationMessage.value = e.localizedMessage ?: "Bölüm genişletilemedi."
            }
        }
    }

    fun updateExistingChapter(
        book: Book,
        chapter: Chapter,
        newTitle: String,
        newSummary: String,
        newContent: String,
        onComplete: () -> Unit
    ) {
        viewModelScope.launch {
            try {
                repository.updateChapter(
                    book = book,
                    chapter = chapter,
                    newTitle = newTitle,
                    newSummary = newSummary,
                    newContent = newContent
                )
                _operationMessage.value = "Bölüm güncellendi."
                onComplete()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _operationMessage.value = e.localizedMessage ?: "Bölüm güncellenemedi."
            }
        }
    }

    fun updateBookDetails(
        bookId: String,
        title: String,
        subtitle: String,
        synopsis: String,
        genre: String,
        tone: String,
        coverTheme: String,
        onComplete: () -> Unit
    ) {
        viewModelScope.launch {
            try {
                repository.updateBookMetadata(
                    bookId = bookId,
                    title = title,
                    subtitle = subtitle,
                    synopsis = synopsis,
                    genre = genre,
                    tone = tone,
                    coverTheme = coverTheme
                )
                _operationMessage.value = "Kitap bilgileri güncellendi."
                onComplete()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _operationMessage.value = e.localizedMessage ?: "Kitap bilgileri güncellenemedi."
            }
        }
    }

    fun deleteBook(bookId: String, chapterIds: List<String>) {
        viewModelScope.launch {
            try {
                repository.deleteBook(bookId, chapterIds)
                if (_selectedBookId.value == bookId) {
                    _selectedBookId.value = null
                    _currentDestination.value = StudioDestination.HOME_LIBRARY
                }
                _operationMessage.value = "Kitap silindi."
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _operationMessage.value = e.localizedMessage ?: "Kitap silinemedi."
            }
        }
    }
}
