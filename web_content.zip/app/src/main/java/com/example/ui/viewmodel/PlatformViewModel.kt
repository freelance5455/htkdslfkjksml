package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Announcement
import com.example.data.model.Course
import com.example.data.model.Lesson
import com.example.data.model.UserProfile
import com.example.data.repository.PlatformRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class Screen {
    object Home : Screen()
    object Courses : Screen()
    data class CourseDetail(val courseId: String) : Screen()
    data class LessonDetail(val lessonId: String) : Screen()
    object StudentDashboard : Screen()
    object AdminDashboard : Screen()
}

class PlatformViewModel(application: Application) : AndroidViewModel(application) {

    val repository = PlatformRepository(application.applicationContext)

    val courses: StateFlow<List<Course>> = repository.courses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val lessons: StateFlow<List<Lesson>> = repository.lessons
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val announcements: StateFlow<List<Announcement>> = repository.announcements
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentUser: StateFlow<UserProfile?> = repository.currentUser
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val registeredUsers: StateFlow<List<UserProfile>> = repository.registeredUsers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val supabaseUrl: StateFlow<String> = repository.supabaseUrl
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")

    val supabaseKey: StateFlow<String> = repository.supabaseKey
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")

    // Navigation state
    private val _currentScreen = MutableStateFlow<Screen>(Screen.Home)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _screenHistory = mutableListOf<Screen>(Screen.Home)

    // Active course/lesson detail
    private val _selectedCourseId = MutableStateFlow<String?>(null)
    val selectedCourseId: StateFlow<String?> = _selectedCourseId.asStateFlow()

    private val _selectedLessonId = MutableStateFlow<String?>(null)
    val selectedLessonId: StateFlow<String?> = _selectedLessonId.asStateFlow()

    // Dialog & Feedback state
    private val _showLoginDialog = MutableStateFlow(false)
    val showLoginDialog: StateFlow<Boolean> = _showLoginDialog.asStateFlow()

    private val _showRegisterDialog = MutableStateFlow(false)
    val showRegisterDialog: StateFlow<Boolean> = _showRegisterDialog.asStateFlow()

    private val _showAdminPinDialog = MutableStateFlow(false)
    val showAdminPinDialog: StateFlow<Boolean> = _showAdminPinDialog.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    fun navigateTo(screen: Screen) {
        if (_currentScreen.value != screen) {
            _screenHistory.add(screen)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        if (_screenHistory.size > 1) {
            _screenHistory.removeAt(_screenHistory.size - 1)
            _currentScreen.value = _screenHistory.last()
            return true
        }
        return false
    }

    fun openCourse(courseId: String) {
        _selectedCourseId.value = courseId
        navigateTo(Screen.CourseDetail(courseId))
    }

    fun openLesson(lessonId: String) {
        _selectedLessonId.value = lessonId
        navigateTo(Screen.LessonDetail(lessonId))
    }

    fun showToast(msg: String) {
        _toastMessage.value = msg
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    fun setLoginDialog(show: Boolean) {
        _showLoginDialog.value = show
    }

    fun setRegisterDialog(show: Boolean) {
        _showRegisterDialog.value = show
    }

    fun setAdminPinDialog(show: Boolean) {
        _showAdminPinDialog.value = show
    }

    // Student Authentication
    fun registerStudent(fullName: String, phone: String, stage: String, pwd: String) {
        viewModelScope.launch {
            val result = repository.registerStudent(fullName, phone, stage, pwd)
            result.onSuccess {
                showToast("تم التسجيل بنجاح! مرحباً بك يا ${it.fullName} في منصة القائد")
                _showRegisterDialog.value = false
            }.onFailure {
                showToast(it.message ?: "حدث خطأ أثناء التسجيل")
            }
        }
    }

    fun loginStudent(phone: String, pwd: String) {
        viewModelScope.launch {
            val result = repository.loginStudent(phone, pwd)
            result.onSuccess {
                showToast("تم تسجيل الدخول بنجاح! أهلاً بك يا ${it.fullName}")
                _showLoginDialog.value = false
            }.onFailure {
                showToast(it.message ?: "خطأ في تسجيل الدخول")
            }
        }
    }

    fun loginAdmin(pin: String) {
        viewModelScope.launch {
            val success = repository.loginAdmin(pin)
            if (success) {
                showToast("مرحباً بك يا مستر زاهر! تم فتح لوحة تحكم القائد")
                _showAdminPinDialog.value = false
                navigateTo(Screen.AdminDashboard)
            } else {
                showToast("رمز الإدارة غير صحيح، برجاء المحاولة مرة أخرى")
            }
        }
    }

    fun logout() {
        repository.logout()
        showToast("تم تسجيل الخروج بنجاح")
        navigateTo(Screen.Home)
    }

    fun enrollInCourse(courseId: String) {
        repository.enrollInCourse(courseId)
        showToast("تم اشتراكك في الكورس بنجاح!")
    }

    // Admin Operations
    fun addCourse(title: String, subtitle: String, desc: String) {
        val course = repository.addCourse(title, subtitle, desc)
        showToast("تم إضافة كورس ${course.title} بنجاح")
    }

    fun updateCourse(course: Course) {
        repository.updateCourse(course)
        showToast("تم تحديث الكورس بنجاح")
    }

    fun toggleCoursePublish(courseId: String) {
        repository.toggleCoursePublish(courseId)
        showToast("تم تعديل حالة نشر الكورس")
    }

    fun deleteCourse(courseId: String) {
        repository.deleteCourse(courseId)
        showToast("تم حذف الكورس بنجاح")
    }

    fun addLesson(courseId: String, title: String, status: String, desc: String, videoUrl: String?, pdfUrl: String?) {
        val lesson = repository.addLesson(courseId, title, status, desc, videoUrl, pdfUrl)
        showToast("تم إضافة ${lesson.title} بنجاح")
    }

    fun updateLesson(lesson: Lesson) {
        repository.updateLesson(lesson)
        showToast("تم تحديث بيانات المحاضرة بنجاح")
    }

    fun toggleLessonPublish(lessonId: String) {
        repository.toggleLessonPublish(lessonId)
        showToast("تم تعديل حالة نشر المحاضرة")
    }

    fun deleteLesson(lessonId: String) {
        repository.deleteLesson(lessonId)
        showToast("تم حذف المحاضرة")
    }

    fun addAnnouncement(title: String, content: String, isPinned: Boolean) {
        repository.addAnnouncement(title, content, isPinned)
        showToast("تم نشر التنبيه بنجاح")
    }

    fun deleteAnnouncement(id: String) {
        repository.deleteAnnouncement(id)
        showToast("تم حذف التنبيه")
    }

    fun saveSupabaseConfig(url: String, key: String) {
        repository.saveSupabaseConfig(url, key)
        showToast("تم حفظ إعدادات Supabase بنجاح")
    }
}
