package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.model.HifzClass
import com.example.data.model.MonthlySummaryResult
import com.example.data.model.UiState
import com.example.export.PdfAndShareHelper
import com.example.ui.theme.WhatsAppGreen
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MonthlySummaryScreen(
    title: String,
    centre: String,
    isAdmin: Boolean,
    classes: List<HifzClass>,
    selectedClassId: String,
    yearMonth: String,
    summaryState: UiState<MonthlySummaryResult>,
    onSelectClass: (String) -> Unit,
    onChangeMonth: (String) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    val context = LocalContext.current
    var pendingSaveFile by remember { mutableStateOf<File?>(null) }

    val savePdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        val src = pendingSaveFile
        if (uri != null && src != null) {
            val ok = PdfAndShareHelper.copyPdfToUri(context, src, uri)
            Toast.makeText(
                context,
                if (ok) "ماہانہ PDF محفوظ ہو گئی ✓" else "PDF محفوظ کرنے میں خرابی",
                Toast.LENGTH_SHORT
            ).show()
        }
        pendingSaveFile = null
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ماہانہ خلاصہ · Monthly Summary") },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("monthly_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Month Stepper
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { onChangeMonth(shiftYearMonth(yearMonth, -1)) }) {
                        Icon(Icons.Default.ChevronLeft, contentDescription = "Previous Month")
                    }
                    Text(
                        text = "مہینہ: $yearMonth",
                        style = MaterialTheme.typography.titleMedium
                    )
                    IconButton(onClick = { onChangeMonth(shiftYearMonth(yearMonth, +1)) }) {
                        Icon(Icons.Default.ChevronRight, contentDescription = "Next Month")
                    }
                }
            }

            if (isAdmin && classes.size > 1) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    classes.forEach { cls ->
                        FilterChip(
                            selected = cls.id == selectedClassId,
                            onClick = { onSelectClass(cls.id) },
                            label = { Text(cls.name) }
                        )
                    }
                }
            }

            when (summaryState) {
                is UiState.Loading -> {
                    Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
                is UiState.Error -> {
                    Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text(summaryState.message, color = MaterialTheme.colorScheme.error)
                    }
                }
                is UiState.Success -> {
                    val summary = summaryState.data
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                        shape = MaterialTheme.shapes.small,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "${summary.className}  |  ریکارڈ شدہ شیٹس: ${summary.recordedSheetsCount}  |  کام کے دن: ${summary.workingDaysCount}",
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(10.dp),
                            textAlign = TextAlign.Center
                        )
                    }

                    if (summary.recordedSheetsCount == 0) {
                        Box(
                            modifier = Modifier.weight(1f).fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "اس مہینے کی کوئی محفوظ شیٹ نہیں ملی۔",
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        val hScroll = rememberScrollState()
                        val totalLines = summary.students.sumOf { it.totalSabaqLines }
                        val totalSabqi = summary.students.sumOf { it.sabqiMistakes }
                        val totalManzil = summary.students.sumOf { it.manzilMistakes }

                        Surface(
                            shape = MaterialTheme.shapes.medium,
                            tonalElevation = 1.dp,
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                        ) {
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .horizontalScroll(hScroll)
                            ) {
                                item {
                                    Row(
                                        modifier = Modifier
                                            .background(MaterialTheme.colorScheme.surfaceVariant)
                                            .padding(vertical = 8.dp)
                                    ) {
                                        MCell("#", 38.dp, bold = true)
                                        MCell("نام", 150.dp, bold = true)
                                        MCell("حاضر", 58.dp, bold = true)
                                        MCell("غیر حاضر", 66.dp, bold = true)
                                        MCell("سبق لائنیں", 82.dp, bold = true)
                                        MCell("اوسط", 58.dp, bold = true)
                                        MCell("سبقی غلطی", 78.dp, bold = true)
                                        MCell("منزل غلطی", 78.dp, bold = true)
                                        MCell("آخری پارہ", 72.dp, bold = true)
                                        MCell("⭐", 46.dp, bold = true)
                                    }
                                    HorizontalDivider()
                                }
                                itemsIndexed(summary.students, key = { _, it -> it.studentNum }) { idx, st ->
                                    Row(
                                        modifier = Modifier
                                            .background(
                                                if (idx % 2 == 1) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.22f)
                                                else MaterialTheme.colorScheme.surface
                                            )
                                            .padding(vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        MCell((idx + 1).toString(), 38.dp)
                                        MCell(st.name, 150.dp, bold = true)
                                        MCell(st.presentDays.toString(), 58.dp)
                                        MCell(st.absentDays.toString(), 66.dp)
                                        MCell(PdfAndShareHelper.formatNum(st.totalSabaqLines), 82.dp)
                                        MCell(PdfAndShareHelper.formatNum(st.dailyAvgLines), 58.dp)
                                        MCell(PdfAndShareHelper.formatNum(st.sabqiMistakes), 78.dp)
                                        MCell(PdfAndShareHelper.formatNum(st.manzilMistakes), 78.dp)
                                        MCell(st.latestSabaqPara.ifBlank { "—" }, 72.dp)
                                        MCell(if (st.sotdCount > 0) st.sotdCount.toString() else "", 46.dp)
                                    }
                                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                                }
                                item {
                                    Row(
                                        modifier = Modifier
                                            .background(MaterialTheme.colorScheme.surfaceVariant)
                                            .padding(vertical = 8.dp)
                                    ) {
                                        MCell("", 38.dp)
                                        MCell("مجموعہ (کل)", 150.dp, bold = true)
                                        MCell("", 58.dp)
                                        MCell("", 66.dp)
                                        MCell(PdfAndShareHelper.formatNum(totalLines), 82.dp, bold = true)
                                        MCell("", 58.dp)
                                        MCell(PdfAndShareHelper.formatNum(totalSabqi), 78.dp, bold = true)
                                        MCell(PdfAndShareHelper.formatNum(totalManzil), 78.dp, bold = true)
                                        MCell("", 72.dp)
                                        MCell("", 46.dp)
                                    }
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                val file = PdfAndShareHelper.generateMonthlySummaryPdf(context, title, centre, summary)
                                pendingSaveFile = file
                                savePdfLauncher.launch(file.name)
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("monthly_export_pdf_button")
                        ) {
                            Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("PDF محفوظ کریں")
                        }

                        Button(
                            onClick = {
                                val file = PdfAndShareHelper.generateMonthlySummaryPdf(context, title, centre, summary)
                                val caption = PdfAndShareHelper.buildMonthlyShareText(title, centre, summary)
                                    .lineSequence().take(5).joinToString("\n")
                                PdfAndShareHelper.shareFileToWhatsApp(
                                    context = context,
                                    file = file,
                                    mimeType = "application/pdf",
                                    captionText = caption
                                )
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = WhatsAppGreen,
                                contentColor = Color.White
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("monthly_whatsapp_pdf_button")
                        ) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("واٹس ایپ PDF شیئر")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MCell(text: String, width: Dp, bold: Boolean = false) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodyMedium.copy(
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal
        ),
        textAlign = TextAlign.Center,
        modifier = Modifier
            .width(width)
            .padding(horizontal = 4.dp)
    )
}

private fun shiftYearMonth(ym: String, deltaMonths: Int): String {
    return try {
        val sdf = SimpleDateFormat("yyyy-MM", Locale.US)
        val cal = Calendar.getInstance()
        cal.time = sdf.parse(ym) ?: return ym
        cal.add(Calendar.MONTH, deltaMonths)
        sdf.format(cal.time)
    } catch (_: Exception) {
        ym
    }
}
