package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.renderer.SceneRenderer
import com.example.viewmodel.MotionForgeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PreviewScreen(
  viewModel: MotionForgeViewModel,
  onBack: () -> Unit,
  onNavigateToTimeline: () -> Unit,
  onNavigateToExport: () -> Unit
) {
  val recipe by viewModel.recipe.collectAsState()
  val currentTime by viewModel.currentTime.collectAsState()
  val isPlaying by viewModel.isPlayingState.collectAsState()
  val audioAnalysis by viewModel.audioAnalysis.collectAsState()

  var aspectRatio by remember { mutableStateOf("9:16") }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Motion Preview & Render Studio") },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = null)
          }
        },
        actions = {
          IconButton(onClick = onNavigateToTimeline) {
            Icon(Icons.Default.Timeline, contentDescription = null)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
      )
    }
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .background(MaterialTheme.colorScheme.background)
        .padding(16.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        listOf("9:16", "16:9", "1:1").forEach { ratio ->
          FilterChip(
            selected = aspectRatio == ratio,
            onClick = { aspectRatio = ratio },
            label = { Text(ratio) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = MaterialTheme.colorScheme.primary,
              selectedLabelColor = Color.White
            )
          )
        }
      }

      Box(
        modifier = Modifier
          .weight(1f)
          .fillMaxWidth()
          .padding(vertical = 12.dp)
          .clip(RoundedCornerShape(16.dp))
          .background(Color.Black),
        contentAlignment = Alignment.Center
      ) {
        val aspectModifier = when (aspectRatio) {
          "16:9" -> Modifier.fillMaxWidth().aspectRatio(16f / 9f)
          "1:1" -> Modifier.size(350.dp)
          else -> Modifier.fillMaxHeight().aspectRatio(9f / 16f)
        }

        SceneRenderer(
          recipe = recipe,
          currentTime = currentTime,
          audioAnalysis = audioAnalysis,
          modifier = aspectModifier
        )
      }

      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "${String.format("%.2f", currentTime)}s",
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold
          )

          IconButton(
            onClick = { viewModel.togglePlay() },
            modifier = Modifier
              .size(56.dp)
              .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(28.dp))
          ) {
            Icon(
              imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
              contentDescription = null,
              tint = Color.White
            )
          }

          Text(
            text = "${recipe?.settings?.durationSeconds ?: 10f}s",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        val maxDur = recipe?.settings?.durationSeconds ?: 10f
        Slider(
          value = currentTime,
          onValueChange = { viewModel.seekTo(it) },
          valueRange = 0f..maxDur,
          colors = SliderDefaults.colors(
            thumbColor = MaterialTheme.colorScheme.primary,
            activeTrackColor = MaterialTheme.colorScheme.primary
          )
        )

        Button(
          onClick = onNavigateToExport,
          modifier = Modifier.fillMaxWidth(),
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
        ) {
          Icon(Icons.Default.Download, contentDescription = null)
          Spacer(modifier = Modifier.width(8.dp))
          Text("Proceed to Video Export")
        }
      }
    }
  }
}
