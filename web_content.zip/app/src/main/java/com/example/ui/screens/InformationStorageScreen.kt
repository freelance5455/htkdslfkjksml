package com.example.ui.screens

import android.content.Intent
import android.widget.Toast
import com.example.ui.screens.storage.DownloadFieldPdfDialog
import com.example.ui.screens.storage.EditRecordDialog
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.data.db.InformationRecord
import com.example.data.repository.VaultRepository
import com.example.ui.components.SilverButton
import com.example.ui.components.SlantedShape
import com.example.ui.components.TopBarWithClose
import com.example.ui.components.YmTextField
import com.example.ui.theme.AccentRed
import com.example.ui.theme.BlackCharcoal
import com.example.ui.theme.BlackPure
import com.example.ui.theme.SilverDark
import com.example.ui.theme.SilverLight
import com.example.ui.theme.SilverSurface
import com.example.ui.theme.SilverSurfaceVariant
import com.example.util.PdfGenerator
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun InformationStorageScreen(
    repository: VaultRepository,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val records by repository.records.collectAsState(initial = emptyList())
    var searchQuery by remember { mutableStateOf("") }

    val filteredRecords = remember(records, searchQuery) {
        if (searchQuery.isBlank()) {
            records
        } else {
            val q = searchQuery.trim().lowercase(Locale.getDefault())
            records.filter {
                it.name.lowercase().contains(q) ||
                it.place.lowercase().contains(q) ||
                it.address.lowercase().contains(q) ||
                it.email.lowercase().contains(q) ||
                it.phone1.contains(q) ||
                it.phone2.contains(q) ||
                it.transactionNumber.toString().contains(q)
            }
        }
    }

    // Edit record state
    var recordToEdit by remember { mutableStateOf<InformationRecord?>(null) }

    // Single Field PDF selection state
    var recordForFieldPdf by remember { mutableStateOf<InformationRecord?>(null) }

    // Delete record state
    var recordToDelete by remember { mutableStateOf<InformationRecord?>(null) }

    fun downloadRecordAsPdf(record: InformationRecord) {
        scope.launch {
            try {
                val (file, pageCount) = PdfGenerator.createInformationRecordPdf(context, record)
                repository.registerPdf(
                    title = "Record #TX${record.transactionNumber} - ${record.name.ifEmpty { "Client" }}",
                    file = file,
                    pageCount = pageCount
                )
                Toast.makeText(context, "Page downloaded as PDF locally: ${file.name}", Toast.LENGTH_LONG).show()

                // Share / Open prompt
                val uri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    file
                )
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/pdf")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(intent, "View Generated PDF"))
            } catch (e: Exception) {
                Toast.makeText(context, "Error creating PDF: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SilverLight)
    ) {
        // Mandatory X button at top
        TopBarWithClose(
            title = "Information Storage",
            subtitle = "Encrypted Local Storage & PDF Export",
            onCloseClick = onBack
        )

        // Search Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
        ) {
            YmTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = "Search records by name, place, transaction...",
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = BlackPure
                    )
                },
                singleLine = true,
                testTag = "input_search_storage",
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (filteredRecords.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(SlantedShape)
                            .background(SilverSurface)
                            .border(BorderStroke(1.5.dp, BlackPure), SlantedShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Storage,
                            contentDescription = null,
                            tint = BlackPure,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = if (searchQuery.isBlank()) "No Information Records Saved" else "No matching records found",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = BlackPure
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Enter and save records from the Information section. All records remain offline in this encrypted vault.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SilverDark,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(filteredRecords, key = { it.id }) { record ->
                    StorageRecordCard(
                        record = record,
                        onEdit = { recordToEdit = record },
                        onDownloadPagePdf = { downloadRecordAsPdf(record) },
                        onDownloadFieldPdf = { recordForFieldPdf = record },
                        onDelete = { recordToDelete = record }
                    )
                }
            }
        }
    }

    // Edit Record Dialog
    recordToEdit?.let { record ->
        EditRecordDialog(
            record = record,
            onDismiss = { recordToEdit = null },
            onSave = { updated ->
                scope.launch {
                    repository.updateInformationRecord(updated)
                    recordToEdit = null
                    Toast.makeText(context, "Record #${updated.transactionNumber} updated", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    // Download One Field as PDF Dialog
    recordForFieldPdf?.let { record ->
        DownloadFieldPdfDialog(
            record = record,
            onDismiss = { recordForFieldPdf = null },
            onConfirmField = { fieldName, fieldValue ->
                scope.launch {
                    try {
                        val (file, pageCount) = PdfGenerator.createSingleFieldPdf(
                            context = context,
                            record = record,
                            fieldName = fieldName,
                            fieldValue = fieldValue
                        )
                        repository.registerPdf(
                            title = "TX#${record.transactionNumber} - $fieldName",
                            file = file,
                            pageCount = pageCount
                        )
                        Toast.makeText(context, "Field PDF generated locally: ${file.name}", Toast.LENGTH_LONG).show()

                        val uri = FileProvider.getUriForFile(
                            context,
                            "${context.packageName}.fileprovider",
                            file
                        )
                        val intent = Intent(Intent.ACTION_VIEW).apply {
                            setDataAndType(uri, "application/pdf")
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(intent, "Open Field PDF"))
                    } catch (e: Exception) {
                        Toast.makeText(context, "Error creating field PDF: ${e.message}", Toast.LENGTH_LONG).show()
                    } finally {
                        recordForFieldPdf = null
                    }
                }
            }
        )
    }

    // Delete Record Dialog
    recordToDelete?.let { record ->
        AlertDialog(
            onDismissRequest = { recordToDelete = null },
            title = {
                Text(
                    text = "Delete Record #${record.transactionNumber}?",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = BlackPure
                )
            },
            text = {
                Text(
                    text = "Are you sure you want to permanently delete this record (${record.name.ifEmpty { "Unnamed" }}) from storage?",
                    style = MaterialTheme.typography.bodyMedium,
                    color = BlackCharcoal
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        scope.launch {
                            repository.deleteInformationRecord(record)
                            recordToDelete = null
                        }
                    }
                ) {
                    Text("Delete", color = AccentRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { recordToDelete = null }) {
                    Text("Cancel", color = SilverDark)
                }
            },
            containerColor = SilverLight,
            shape = SlantedShape
        )
    }
}

@Composable
fun StorageRecordCard(
    record: InformationRecord,
    onEdit: () -> Unit,
    onDownloadPagePdf: () -> Unit,
    onDownloadFieldPdf: () -> Unit,
    onDelete: () -> Unit
) {
    val formattedDate = remember(record.createdAt) {
        val sdf = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())
        sdf.format(Date(record.createdAt))
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(SlantedShape)
            .background(SilverSurface)
            .border(BorderStroke(1.5.dp, BlackPure), SlantedShape)
            .padding(16.dp)
    ) {
        Column {
            // Header: Transaction Number and Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(SlantedShape)
                            .background(BlackPure)
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = "TX #${record.transactionNumber}",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 14.sp
                            ),
                            color = SilverLight,
                            fontWeight = FontWeight.Black
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Text(
                        text = formattedDate,
                        style = MaterialTheme.typography.labelSmall,
                        color = SilverDark
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit record",
                            tint = BlackPure,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete record",
                            tint = AccentRed,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = SilverDark.copy(alpha = 0.3f), thickness = 1.dp)
            Spacer(modifier = Modifier.height(14.dp))

            // Display all 8 information fields cleanly without cutting off long text
            StorageFieldRow(label = "Name:", value = record.name)
            StorageFieldRow(label = "The age:", value = record.age)
            StorageFieldRow(label = "The place:", value = record.place)
            StorageFieldRow(label = "The address:", value = record.address)
            StorageFieldRow(label = "Phone number 1:", value = record.phone1)
            StorageFieldRow(label = "Phone number 2:", value = record.phone2)
            StorageFieldRow(label = "Email address:", value = record.email)
            StorageFieldRow(label = "Transaction number:", value = "#${record.transactionNumber}")

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = SilverDark.copy(alpha = 0.3f), thickness = 1.dp)
            Spacer(modifier = Modifier.height(14.dp))

            // Required PDF export buttons:
            // 1. Download Page as PDF
            // 2. Download One Field as PDF
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SilverButton(
                    text = "Download Page as PDF",
                    icon = Icons.Default.PictureAsPdf,
                    isDark = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_download_page_pdf_${record.transactionNumber}"),
                    onClick = onDownloadPagePdf
                )

                SilverButton(
                    text = "Download One Field as PDF",
                    icon = Icons.Default.PictureAsPdf,
                    isDark = false,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_download_one_field_pdf_${record.transactionNumber}"),
                    onClick = onDownloadFieldPdf
                )
            }
        }
    }
}

@Composable
fun StorageFieldRow(
    label: String,
    value: String
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = SilverDark,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(1.dp))
        Text(
            text = value.ifEmpty { "—" },
            style = MaterialTheme.typography.bodyLarge,
            color = BlackPure,
            fontWeight = FontWeight.Medium
        )
    }
}

