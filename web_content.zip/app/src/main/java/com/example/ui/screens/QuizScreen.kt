package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FormatStrikethrough
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Question
import com.example.ui.theme.DopingAmber
import com.example.ui.theme.DopingAmberDark
import com.example.ui.theme.DopingAmberLight
import com.example.ui.theme.DopingGreen
import com.example.ui.theme.DopingGreenContainer
import com.example.ui.theme.DopingPrimary
import com.example.ui.theme.DopingPrimaryContainer
import com.example.ui.theme.DopingPrimaryVariant
import com.example.ui.theme.DopingRed
import com.example.ui.theme.DopingRedContainer
import com.example.ui.viewmodel.QuizSessionState

@Composable
fun QuizScreen(
  quizState: QuizSessionState,
  onSelectAnswer: (Int) -> Unit,
  onToggleEliminate: (Int) -> Unit,
  onToggleSolution: () -> Unit,
  onNextQuestion: () -> Unit,
  onPreviousQuestion: () -> Unit,
  onGoToQuestion: (Int) -> Unit,
  onFinishQuiz: () -> Unit,
  onRestartQuiz: () -> Unit,
  onToggleErrorNotebook: () -> Unit,
  isSavedInErrorNotebook: Boolean,
  modifier: Modifier = Modifier
) {
  if (quizState.questions.isEmpty()) {
    Box(
      modifier = modifier
        .fillMaxSize()
        .testTag("empty_quiz_view"),
      contentAlignment = Alignment.Center
    ) {
      Text("Soru bulunamadı.", style = MaterialTheme.typography.bodyLarge)
    }
    return
  }

  // Quiz Finished Result Card (Karne)
  if (quizState.isCompleted) {
    QuizResultView(
      quizState = quizState,
      onRestart = onRestartQuiz,
      modifier = modifier
    )
    return
  }

  val currentQuestion = quizState.questions[quizState.currentIndex]
  val selectedAnswer = quizState.selectedAnswers[quizState.currentIndex]
  val eliminatedSet = quizState.eliminatedOptions[quizState.currentIndex] ?: emptySet()
  val hasAnswered = selectedAnswer != null
  val isAnswerCorrect = selectedAnswer == currentQuestion.correctOptionIndex

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .testTag("quiz_screen_scroll"),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // 1. Top Question Tracker & Timer Row
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "${currentQuestion.subject.iconEmoji} ${currentQuestion.subject.title}",
            style = MaterialTheme.typography.labelMedium,
            color = currentQuestion.subject.primaryColor,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "Soru ${quizState.currentIndex + 1} / ${quizState.questions.size}",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.ExtraBold
          )
        }

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          // Timer
          Surface(
            color = MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(12.dp)
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.Timer,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              val mins = quizState.timeElapsedSeconds / 60
              val secs = quizState.timeElapsedSeconds % 60
              Text(
                text = String.format("%02d:%02d", mins, secs),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }

          // Error Notebook Toggle
          IconButton(
            onClick = onToggleErrorNotebook,
            modifier = Modifier.testTag("quiz_error_toggle_btn")
          ) {
            Icon(
              imageVector = if (isSavedInErrorNotebook) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
              contentDescription = "Hata Defterine Ekle",
              tint = if (isSavedInErrorNotebook) DopingAmberDark else MaterialTheme.colorScheme.outline
            )
          }
        }
      }
    }

    // Question Number Pills Row
    item {
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        itemsIndexed(quizState.questions) { index, q ->
          val ans = quizState.selectedAnswers[index]
          val isCurrent = index == quizState.currentIndex
          val pillColor = when {
            ans == null -> if (isCurrent) DopingPrimary else MaterialTheme.colorScheme.surfaceVariant
            ans == q.correctOptionIndex -> DopingGreen
            else -> DopingRed
          }
          val textColor = if (ans != null || isCurrent) Color.White else MaterialTheme.colorScheme.onSurface

          Box(
            modifier = Modifier
              .size(34.dp)
              .clip(CircleShape)
              .background(pillColor)
              .clickable { onGoToQuestion(index) }
              .testTag("quiz_pill_$index"),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "${index + 1}",
              color = textColor,
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp
            )
          }
        }
      }
    }

    // 2. Question Content Card
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("question_card_${currentQuestion.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Surface(
              color = currentQuestion.subject.primaryColor.copy(alpha = 0.12f),
              shape = RoundedCornerShape(6.dp)
            ) {
              Text(
                text = currentQuestion.topicTitle,
                color = currentQuestion.subject.primaryColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
              )
            }

            Surface(
              color = Color(0xFFFEF3C7),
              shape = RoundedCornerShape(6.dp)
            ) {
              Text(
                text = currentQuestion.difficulty,
                color = Color(0xFF92400E),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          currentQuestion.passageOrPremise?.let { passage ->
            Surface(
              color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
              shape = RoundedCornerShape(8.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Text(
                text = passage,
                style = MaterialTheme.typography.bodySmall,
                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                modifier = Modifier.padding(10.dp)
              )
            }
            Spacer(modifier = Modifier.height(10.dp))
          }

          Text(
            text = currentQuestion.questionText,
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = FontWeight.SemiBold,
            lineHeight = 22.sp
          )
        }
      }
    }

    // 3. Question Options (A, B, C, D, E)
    item {
      Text(
        text = "Şıklar (Şık elemek için çizgi ikonuna dokun):",
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }

    itemsIndexed(currentQuestion.options) { optIndex, optionText ->
      val isEliminated = eliminatedSet.contains(optIndex)
      val isSelected = selectedAnswer == optIndex
      val isCorrectAnswer = optIndex == currentQuestion.correctOptionIndex

      val containerColor = when {
        !hasAnswered -> if (isEliminated) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f) else MaterialTheme.colorScheme.surface
        isCorrectAnswer -> DopingGreenContainer
        isSelected && !isCorrectAnswer -> DopingRedContainer
        else -> MaterialTheme.colorScheme.surface
      }

      val borderColor = when {
        !hasAnswered -> if (isSelected) DopingPrimary else MaterialTheme.colorScheme.outlineVariant
        isCorrectAnswer -> DopingGreen
        isSelected && !isCorrectAnswer -> DopingRed
        else -> MaterialTheme.colorScheme.outlineVariant
      }

      Card(
        modifier = Modifier
          .fillMaxWidth()
          .clickable(enabled = !hasAnswered) { onSelectAnswer(optIndex) }
          .testTag("option_card_${optIndex}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        border = BorderStroke(1.5.dp, borderColor)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 12.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          // Option letter circle
          Box(
            modifier = Modifier
              .size(28.dp)
              .clip(CircleShape)
              .background(
                when {
                  !hasAnswered -> MaterialTheme.colorScheme.surfaceVariant
                  isCorrectAnswer -> DopingGreen
                  isSelected && !isCorrectAnswer -> DopingRed
                  else -> MaterialTheme.colorScheme.surfaceVariant
                }
              ),
            contentAlignment = Alignment.Center
          ) {
            if (hasAnswered && isCorrectAnswer) {
              Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
            } else if (hasAnswered && isSelected && !isCorrectAnswer) {
              Icon(Icons.Default.Close, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
            } else {
              Text(
                text = ('A' + optIndex).toString(),
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurface
              )
            }
          }

          Spacer(modifier = Modifier.width(12.dp))

          Text(
            text = optionText,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (isSelected || isCorrectAnswer) FontWeight.Bold else FontWeight.Normal,
            textDecoration = if (isEliminated && !hasAnswered) TextDecoration.LineThrough else TextDecoration.None,
            color = if (isEliminated && !hasAnswered) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
          )

          if (!hasAnswered) {
            IconButton(
              onClick = { onToggleEliminate(optIndex) },
              modifier = Modifier.size(28.dp)
            ) {
              Icon(
                imageVector = Icons.Default.FormatStrikethrough,
                contentDescription = "Şıkkı Ele",
                tint = if (isEliminated) DopingAmberDark else MaterialTheme.colorScheme.outlineVariant,
                modifier = Modifier.size(18.dp)
              )
            }
          }
        }
      }
    }

    // 4. "DOPİNG REFLEKS ÇÖZÜMÜ" Expandable Panel
    if (hasAnswered || quizState.showSolution) {
      item {
        AnimatedVisibility(
          visible = true,
          enter = fadeIn() + slideInVertically()
        ) {
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .testTag("doping_solution_panel"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Transparent)
          ) {
            Box(
              modifier = Modifier
                .background(
                  Brush.linearGradient(
                    colors = listOf(
                      Color(0xFF1E1B4B),
                      DopingPrimaryVariant,
                      Color(0xFF312E81)
                    )
                  )
                )
                .padding(16.dp)
            ) {
              Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                      imageVector = Icons.Default.Psychology,
                      contentDescription = null,
                      tint = DopingAmberLight,
                      modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                      text = "DOPİNG REFLEKS ÇÖZÜMÜ",
                      color = DopingAmberLight,
                      fontWeight = FontWeight.Black,
                      fontSize = 13.sp,
                      letterSpacing = 0.5.sp
                    )
                  }

                  Surface(
                    color = if (isAnswerCorrect) DopingGreen else DopingRed,
                    shape = RoundedCornerShape(8.dp)
                  ) {
                    Text(
                      text = if (isAnswerCorrect) "Doğru Tebrikler!" else "Yanlış Cevap",
                      color = Color.White,
                      fontSize = 10.sp,
                      fontWeight = FontWeight.Bold,
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                  }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Fast 15-second reflex tip badge
                Surface(
                  color = Color(0xFFFEF3C7),
                  shape = RoundedCornerShape(10.dp),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Icon(
                      imageVector = Icons.Default.AutoAwesome,
                      contentDescription = null,
                      tint = DopingAmberDark,
                      modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                      Text(
                        text = "15 SANİYELİK HAFIZA REFLEKSİ",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFFB45309)
                      )
                      Text(
                        text = currentQuestion.dopingReflexTip,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF78350F)
                      )
                    }
                  }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                  text = "Adım Adım Çözüm:",
                  color = Color.White,
                  fontWeight = FontWeight.Bold,
                  fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = currentQuestion.stepByStepSolution,
                  color = Color.White.copy(alpha = 0.95f),
                  fontSize = 12.sp,
                  lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                Surface(
                  color = Color.White.copy(alpha = 0.12f),
                  shape = RoundedCornerShape(8.dp),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                      text = "⚠️ Sınavda En Çok Düşülen Tuzak:",
                      color = DopingAmberLight,
                      fontWeight = FontWeight.Bold,
                      fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                      text = currentQuestion.trapExplanation,
                      color = Color.White,
                      fontSize = 11.sp
                    )
                  }
                }
              }
            }
          }
        }
      }
    }

    // 5. Navigation Buttons (Önceki, Çözümü Göster, Sonraki / Bitir)
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedButton(
          onClick = onPreviousQuestion,
          enabled = quizState.currentIndex > 0,
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.weight(1f)
        ) {
          Icon(imageVector = Icons.Default.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Önceki", fontSize = 12.sp)
        }

        if (!hasAnswered) {
          OutlinedButton(
            onClick = onToggleSolution,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.weight(1f)
          ) {
            Text("Çözüm", fontSize = 12.sp)
          }
        }

        Button(
          onClick = {
            if (quizState.currentIndex == quizState.questions.size - 1) {
              onFinishQuiz()
            } else {
              onNextQuestion()
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = DopingPrimary),
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.weight(1.2f).testTag("quiz_next_or_finish_btn")
        ) {
          Text(
            text = if (quizState.currentIndex == quizState.questions.size - 1) "Sınavı Bitir" else "Sonraki",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.width(4.dp))
          Icon(imageVector = Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
        }
      }
    }
  }
}

@Composable
private fun QuizResultView(
  quizState: QuizSessionState,
  onRestart: () -> Unit,
  modifier: Modifier = Modifier
) {
  var correctCount = 0
  var wrongCount = 0
  var emptyCount = 0

  quizState.questions.forEachIndexed { index, question ->
    val ans = quizState.selectedAnswers[index]
    when {
      ans == null -> emptyCount++
      ans == question.correctOptionIndex -> correctCount++
      else -> wrongCount++
    }
  }

  val total = quizState.questions.size
  val net = correctCount - (wrongCount * 0.25)
  val successPercentage = if (total > 0) (correctCount * 100 / total) else 0

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .testTag("quiz_result_view"),
    contentPadding = PaddingValues(20.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
      ) {
        Box(
          modifier = Modifier
            .background(
              Brush.linearGradient(
                colors = listOf(
                  Color(0xFF312E81),
                  DopingPrimary,
                  Color(0xFF4338CA)
                )
              )
            )
            .padding(24.dp),
          contentAlignment = Alignment.Center
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
              modifier = Modifier
                .size(60.dp)
                .clip(CircleShape)
                .background(DopingAmberLight),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = Color(0xFF78350F),
                modifier = Modifier.size(36.dp)
              )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
              text = "Test Tamamlandı!",
              color = Color.White,
              fontWeight = FontWeight.Black,
              fontSize = 22.sp
            )
            Text(
              text = "Doping Hafıza Analiz Karnesi",
              color = DopingAmberLight,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(20.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceAround
            ) {
              ResultMetric(label = "Doğru", value = "$correctCount", color = DopingGreen)
              ResultMetric(label = "Yanlış", value = "$wrongCount", color = DopingRed)
              ResultMetric(label = "Boş", value = "$emptyCount", color = Color.White)
              ResultMetric(label = "Net", value = String.format("%.2f", net), color = DopingAmber)
            }
          }
        }
      }
    }

    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "📊 Başarı & Koçluk Değerlendirmesi",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
          )
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = when {
              successPercentage >= 80 -> "Harika bir performans! Konu hafızanda sağlam oturmuş. Yanlış yaptığın soruları Hata Defterinden bir kez daha gözden geçirip sıradaki konuya geçebilirsin."
              successPercentage >= 50 -> "İyi bir ilerleme. Şifreli kodlamaları biraz daha tekrar edip 15 saniyelik refleks taktiklerini ezberlersen netlerin tırmanacaktır."
              else -> "Bu konuda eksikler var. Konu Anlatımı ekranına dönüp hafıza tekniklerini ve zihinsel canlandırma hikayesini tekrar oku."
            },
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }

    item {
      Button(
        onClick = onRestart,
        modifier = Modifier
          .fillMaxWidth()
          .height(50.dp)
          .testTag("restart_quiz_btn"),
        colors = ButtonDefaults.buttonColors(containerColor = DopingPrimary),
        shape = RoundedCornerShape(14.dp)
      ) {
        Icon(imageVector = Icons.Default.Replay, contentDescription = null)
        Spacer(modifier = Modifier.width(8.dp))
        Text("Testi Yeniden Çöz", fontWeight = FontWeight.Bold, fontSize = 14.sp)
      }
    }
  }
}

@Composable
private fun ResultMetric(label: String, value: String, color: Color) {
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Text(text = label, color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
    Spacer(modifier = Modifier.height(2.dp))
    Text(text = value, color = color, fontSize = 20.sp, fontWeight = FontWeight.Black)
  }
}
