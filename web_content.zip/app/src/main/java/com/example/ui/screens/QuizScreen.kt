package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DefaultData
import com.example.data.NinjaRank
import com.example.data.QuizQuestion
import com.example.data.QuizResult
import com.example.data.Subject
import com.example.ui.DojoUiState
import com.example.ui.QuizMode
import com.example.ui.theme.ChakraCyan
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.NarutoOrange
import com.example.ui.theme.SuccessGreen

@Composable
fun QuizScreen(
  uiState: DojoUiState,
  onSelectSubject: (Subject) -> Unit,
  onStartQuiz: (Subject) -> Unit,
  onSelectOption: (Int) -> Unit,
  onNextQuestion: () -> Unit,
  onViewHistory: () -> Unit,
  onBackToSelection: () -> Unit,
  modifier: Modifier = Modifier
) {
  when (uiState.quizMode) {
    QuizMode.SELECTION -> QuizSelectionView(
      uiState = uiState,
      onSelectSubject = onSelectSubject,
      onStartQuiz = onStartQuiz,
      onViewHistory = onViewHistory,
      modifier = modifier
    )

    QuizMode.PLAYING -> QuizPlayingView(
      uiState = uiState,
      onSelectOption = onSelectOption,
      onNextQuestion = onNextQuestion,
      modifier = modifier
    )

    QuizMode.RESULT -> QuizResultView(
      uiState = uiState,
      onRetry = { onStartQuiz(uiState.quizSelectedSubject) },
      onBackToSelection = onBackToSelection,
      modifier = modifier
    )

    QuizMode.REVIEW_WRONG, QuizMode.HISTORY -> QuizHistoryView(
      uiState = uiState,
      onBackToSelection = onBackToSelection,
      modifier = modifier
    )
  }
}

@Composable
fun QuizSelectionView(
  uiState: DojoUiState,
  onSelectSubject: (Subject) -> Unit,
  onStartQuiz: (Subject) -> Unit,
  onViewHistory: () -> Unit,
  modifier: Modifier = Modifier
) {
  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp)
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "Quiz Dojo 🎯",
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Black),
            color = MaterialTheme.colorScheme.onBackground
          )
          Text(
            text = "10 MCQ Quick Drills • Offline Bank • Kerala DHSE",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        OutlinedButton(
          onClick = onViewHistory,
          modifier = Modifier.testTag("quiz_history_button"),
          shape = RoundedCornerShape(12.dp)
        ) {
          Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("History", fontSize = 12.sp)
        }
      }
    }

    item { Spacer(modifier = Modifier.height(20.dp)) }

    item {
      Text(
        text = "Select Battle Subject",
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onBackground
      )
      Spacer(modifier = Modifier.height(12.dp))
    }

    items(Subject.entries) { subject ->
      val count = DefaultData.getQuestionBank().count { it.subject == subject }
      val lastAttempt = uiState.quizResults.firstOrNull { it.subject == subject }

      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 6.dp)
          .clickable {
            onSelectSubject(subject)
            onStartQuiz(subject)
          }
          .testTag("quiz_subject_card_${subject.name.lowercase()}"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(48.dp)
              .clip(CircleShape)
              .background(subject.color.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = subject.shortCode,
              style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Black),
              color = subject.color
            )
          }

          Spacer(modifier = Modifier.width(16.dp))

          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = subject.displayName,
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = "$count MCQs in Bank • 10-Question Drill",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (lastAttempt != null) {
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "Last Drill: ${lastAttempt.score}/${lastAttempt.total} (${lastAttempt.dateFormatted.split("•").firstOrNull()?.trim()})",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                color = NarutoOrange
              )
            }
          }

          Button(
            onClick = {
              onSelectSubject(subject)
              onStartQuiz(subject)
            },
            colors = ButtonDefaults.buttonColors(containerColor = subject.color),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.testTag("start_quiz_${subject.name.lowercase()}")
          ) {
            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Start", fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
fun QuizPlayingView(
  uiState: DojoUiState,
  onSelectOption: (Int) -> Unit,
  onNextQuestion: () -> Unit,
  modifier: Modifier = Modifier
) {
  val questions = uiState.quizQuestions
  val currentIndex = uiState.currentQuizQuestionIndex
  val question = questions.getOrNull(currentIndex) ?: return
  val total = questions.size

  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp)
  ) {
    // Header with Progress & Question Number
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = uiState.quizSelectedSubject.color.copy(alpha = 0.15f)
        ) {
          Text(
            text = uiState.quizSelectedSubject.displayName,
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
            color = uiState.quizSelectedSubject.color,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
          )
        }

        Text(
          text = "Question ${currentIndex + 1} of $total",
          style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onSurface
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      LinearProgressIndicator(
        progress = { (currentIndex + 1) / total.toFloat() },
        modifier = Modifier
          .fillMaxWidth()
          .height(6.dp)
          .clip(RoundedCornerShape(3.dp)),
        color = NarutoOrange,
        trackColor = MaterialTheme.colorScheme.surfaceVariant
      )
    }

    item { Spacer(modifier = Modifier.height(20.dp)) }

    // Chapter badge
    item {
      Text(
        text = "Chapter: ${question.chapterTitle}",
        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
        color = ChakraCyan
      )
      Spacer(modifier = Modifier.height(8.dp))
    }

    // Question Box
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Text(
            text = question.question,
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.Bold,
              lineHeight = 24.sp
            ),
            color = MaterialTheme.colorScheme.onSurface
          )
        }
      }
    }

    item { Spacer(modifier = Modifier.height(20.dp)) }

    // Options (A, B, C, D)
    items(question.options.indices.toList()) { index ->
      val optionText = question.options[index]
      val isSelected = uiState.selectedOptionIndex == index
      val isCorrect = index == question.correctIndex
      val isRevealed = uiState.isAnswerRevealed

      val containerColor = when {
        !isRevealed && isSelected -> NarutoOrange.copy(alpha = 0.2f)
        isRevealed && isCorrect -> SuccessGreen.copy(alpha = 0.2f)
        isRevealed && isSelected && !isCorrect -> ErrorRed.copy(alpha = 0.2f)
        else -> MaterialTheme.colorScheme.surface
      }

      val borderColor = when {
        !isRevealed && isSelected -> NarutoOrange
        isRevealed && isCorrect -> SuccessGreen
        isRevealed && isSelected && !isCorrect -> ErrorRed
        else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
      }

      val optionLetter = ('A' + index).toString()

      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 6.dp)
          .clip(RoundedCornerShape(14.dp))
          .border(width = 1.5.dp, color = borderColor, shape = RoundedCornerShape(14.dp))
          .clickable(enabled = !isRevealed) { onSelectOption(index) }
          .testTag("quiz_option_${optionLetter.lowercase()}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = containerColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(14.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          // Option Letter Badge
          Box(
            modifier = Modifier
              .size(32.dp)
              .clip(CircleShape)
              .background(
                when {
                  isRevealed && isCorrect -> SuccessGreen
                  isRevealed && isSelected && !isCorrect -> ErrorRed
                  isSelected -> NarutoOrange
                  else -> MaterialTheme.colorScheme.surfaceVariant
                }
              ),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = optionLetter,
              style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
              color = if (isSelected || (isRevealed && isCorrect)) Color.White
              else MaterialTheme.colorScheme.onSurfaceVariant
            )
          }

          Spacer(modifier = Modifier.width(14.dp))

          Text(
            text = optionText,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
          )

          if (isRevealed) {
            if (isCorrect) {
              Icon(Icons.Default.CheckCircle, contentDescription = "Correct", tint = SuccessGreen)
            } else if (isSelected) {
              Icon(Icons.Default.Close, contentDescription = "Wrong", tint = ErrorRed)
            }
          }
        }
      }
    }

    // Instant Explanation Card
    if (uiState.isAnswerRevealed) {
      item {
        Spacer(modifier = Modifier.height(14.dp))
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(
            containerColor = if (uiState.selectedOptionIndex == question.correctIndex)
              SuccessGreen.copy(alpha = 0.12f)
            else ErrorRed.copy(alpha = 0.12f)
          )
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = if (uiState.selectedOptionIndex == question.correctIndex)
                  "🎯 Correct Jutsu!" else "⚠️ Missed! Correct Answer: ${question.options[question.correctIndex]}",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = if (uiState.selectedOptionIndex == question.correctIndex)
                  SuccessGreen else ErrorRed
              )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = question.explanation,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurface
            )
          }
        }
      }

      // Next / Finish Button
      item {
        Spacer(modifier = Modifier.height(18.dp))
        Button(
          onClick = onNextQuestion,
          modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .testTag("quiz_next_button"),
          shape = RoundedCornerShape(16.dp),
          colors = ButtonDefaults.buttonColors(containerColor = NarutoOrange)
        ) {
          Text(
            text = if (currentIndex + 1 < total) "NEXT QUESTION" else "SEE FINAL SCORE",
            fontWeight = FontWeight.Black,
            fontSize = 15.sp
          )
          Spacer(modifier = Modifier.width(8.dp))
          Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
        }
      }
    }
  }
}

@Composable
fun QuizResultView(
  uiState: DojoUiState,
  onRetry: () -> Unit,
  onBackToSelection: () -> Unit,
  modifier: Modifier = Modifier
) {
  val score = uiState.currentQuizScore
  val total = uiState.quizQuestions.size.coerceAtLeast(1)
  val percent = (score * 100) / total
  val rank = NinjaRank.calculateRank(percent)

  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 24.dp, bottom = 96.dp),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    item {
      Box(
        modifier = Modifier
          .size(100.dp)
          .clip(CircleShape)
          .background(NarutoOrange.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center
      ) {
        Text(text = rank.badgeEmoji, fontSize = 42.sp)
      }

      Spacer(modifier = Modifier.height(16.dp))

      Text(
        text = "Drill Completed!",
        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Black),
        color = MaterialTheme.colorScheme.onBackground
      )

      Spacer(modifier = Modifier.height(4.dp))

      Text(
        text = "Rank Earned: ${rank.title}",
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
        color = ChakraCyan
      )

      Spacer(modifier = Modifier.height(16.dp))

      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Text(
            text = "$score / $total",
            style = MaterialTheme.typography.displayMedium.copy(
              fontWeight = FontWeight.Black,
              color = NarutoOrange
            )
          )
          Text(
            text = "$percent% Mastery in ${uiState.quizSelectedSubject.displayName}",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          Spacer(modifier = Modifier.height(16.dp))

          Text(
            text = when {
              percent >= 80 -> "\"Outstanding! You possess the wisdom of a true Hokage!\" — Naruto"
              percent >= 50 -> "\"Great effort! With a little more review, you will excel!\" — Hinata"
              else -> "\"Don't give up! Even Naruto failed many tests before mastering Jutsu!\""
            },
            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
            color = MaterialTheme.colorScheme.onSurface
          )
        }
      }
    }

    item { Spacer(modifier = Modifier.height(24.dp)) }

    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        OutlinedButton(
          onClick = onBackToSelection,
          modifier = Modifier
            .weight(1f)
            .height(50.dp)
            .testTag("quiz_back_button"),
          shape = RoundedCornerShape(14.dp)
        ) {
          Text("All Quizzes")
        }

        Button(
          onClick = onRetry,
          modifier = Modifier
            .weight(1f)
            .height(50.dp)
            .testTag("quiz_retry_button"),
          shape = RoundedCornerShape(14.dp),
          colors = ButtonDefaults.buttonColors(containerColor = NarutoOrange)
        ) {
          Icon(Icons.Default.Replay, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Drill Again")
        }
      }
    }
  }
}

@Composable
fun QuizHistoryView(
  uiState: DojoUiState,
  onBackToSelection: () -> Unit,
  modifier: Modifier = Modifier
) {
  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp)
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        IconButton(onClick = onBackToSelection) {
          Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
        }
        Text(
          text = "Quiz Score History",
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onBackground
        )
      }
      Spacer(modifier = Modifier.height(16.dp))
    }

    if (uiState.quizResults.isEmpty()) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Text("📊", fontSize = 38.sp)
            Spacer(modifier = Modifier.height(12.dp))
            Text(
              text = "No quizzes completed yet",
              style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
            Text(
              text = "Complete your first drill to log your ninja scores!",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    } else {
      items(uiState.quizResults) { result ->
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Surface(
                shape = RoundedCornerShape(6.dp),
                color = result.subject.color.copy(alpha = 0.15f)
              ) {
                Text(
                  text = result.subject.displayName,
                  style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                  color = result.subject.color,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = result.dateFormatted,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }

            Surface(
              shape = RoundedCornerShape(12.dp),
              color = if (result.score >= 7) SuccessGreen else NarutoOrange
            ) {
              Text(
                text = "${result.score} / ${result.total}",
                style = MaterialTheme.typography.titleMedium.copy(
                  fontWeight = FontWeight.Black,
                  color = Color.White
                ),
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
              )
            }
          }
        }
      }
    }
  }
}
