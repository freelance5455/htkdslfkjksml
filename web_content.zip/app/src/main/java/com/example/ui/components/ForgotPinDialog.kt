package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.LockReset
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.data.model.UserProfile
import com.example.system.OtpChannel
import com.example.system.OtpDeliveryService
import com.example.system.OtpSendResult
import kotlin.random.Random
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ForgotPinResetDialog(
    profile: UserProfile,
    fallbackEmail: String = "",
    fallbackPhone: String = "",
    onPinResetSuccess: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val otpService = remember(context) { OtpDeliveryService(context) }

    val savedEmail = profile.backupEmail.ifBlank { fallbackEmail }.trim()
    val savedPhone = profile.phoneNumber.ifBlank { fallbackPhone }.trim()

    var selectedChannel by remember {
        mutableStateOf(if (savedPhone.isNotBlank()) OtpChannel.GLOBAL_PHONE else OtpChannel.GMAIL_OR_EMAIL)
    }
    var customEmail by remember { mutableStateOf(savedEmail) }
    var customPhone by remember { mutableStateOf(savedPhone) }

    var sentOtpCode by remember { mutableStateOf<String?>(null) }
    var maskedDestination by remember { mutableStateOf("") }
    var isSending by remember { mutableStateOf(false) }
    var isLiveDelivered by remember { mutableStateOf(false) }
    var statusNotice by remember { mutableStateOf<String?>(null) }

    var otpInput by remember { mutableStateOf("") }
    var newPin by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf<String?>(null) }

    val activeRecipient = if (selectedChannel == OtpChannel.GMAIL_OR_EMAIL) {
        savedEmail.ifBlank { customEmail.trim() }
    } else {
        savedPhone.ifBlank { customPhone.trim() }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.LockReset, contentDescription = null) },
        title = { Text("Forgot PIN? Reset via OTP") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Choose where to send your 6-digit recovery OTP. Digits/letters are hidden for privacy:",
                    style = MaterialTheme.typography.bodySmall
                )

                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = selectedChannel == OtpChannel.GLOBAL_PHONE,
                        onClick = {
                            selectedChannel = OtpChannel.GLOBAL_PHONE
                            sentOtpCode = null
                            errorText = null
                        },
                        leadingIcon = { Icon(Icons.Filled.Phone, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        label = {
                            val label = if (savedPhone.isNotBlank()) {
                                "SMS (${OtpDeliveryService.maskPhone(savedPhone)})"
                            } else "Phone Number"
                            Text(label)
                        }
                    )
                    FilterChip(
                        selected = selectedChannel == OtpChannel.GMAIL_OR_EMAIL,
                        onClick = {
                            selectedChannel = OtpChannel.GMAIL_OR_EMAIL
                            sentOtpCode = null
                            errorText = null
                        },
                        leadingIcon = { Icon(Icons.Filled.Email, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        label = {
                            val label = if (savedEmail.isNotBlank()) {
                                "Email (${OtpDeliveryService.maskEmail(savedEmail)})"
                            } else "Gmail / Email"
                            Text(label)
                        }
                    )
                }

                if (selectedChannel == OtpChannel.GMAIL_OR_EMAIL && savedEmail.isBlank()) {
                    OutlinedTextField(
                        value = customEmail,
                        onValueChange = { customEmail = it },
                        label = { Text("Enter your account Gmail / Email") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                if (selectedChannel == OtpChannel.GLOBAL_PHONE && savedPhone.isBlank()) {
                    OutlinedTextField(
                        value = customPhone,
                        onValueChange = { customPhone = it },
                        label = { Text("Enter your account Phone (+...)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Button(
                    onClick = {
                        val valid = if (selectedChannel == OtpChannel.GMAIL_OR_EMAIL) {
                            activeRecipient.contains("@") && activeRecipient.contains(".")
                        } else {
                            activeRecipient.count { it.isDigit() } >= 6
                        }
                        if (!valid) {
                            errorText = "Enter a valid ${selectedChannel.label} first."
                            return@Button
                        }
                        errorText = null
                        isSending = true
                        val code = "%06d".format(Random.nextInt(100000, 999999))
                        sentOtpCode = code
                        maskedDestination = OtpDeliveryService.maskRecipient(selectedChannel, activeRecipient)

                        scope.launch {
                            val res = otpService.sendOtp(
                                channel = selectedChannel,
                                recipient = activeRecipient,
                                code = code,
                                isDataFreeMode = profile.isDataFreeMode,
                                languageName = profile.language.nativeName
                            )
                            isSending = false
                            when (res) {
                                is OtpSendResult.DeliveredLive -> {
                                    isLiveDelivered = true
                                    statusNotice = "OTP sent to $maskedDestination! Check your messages/inbox."
                                }
                                is OtpSendResult.OfflineOrUnconfigured -> {
                                    isLiveDelivered = false
                                    if (!profile.isDataFreeMode) {
                                        if (selectedChannel == OtpChannel.GMAIL_OR_EMAIL) {
                                            otpService.launchDeviceEmailOtp(activeRecipient, code)
                                        } else {
                                            otpService.launchDeviceSmsOtp(activeRecipient, code)
                                        }
                                    }
                                    statusNotice = "OTP dispatched to $maskedDestination • ${res.reason}"
                                }
                                is OtpSendResult.Error -> {
                                    isLiveDelivered = false
                                    errorText = res.message
                                }
                            }
                        }
                    },
                    enabled = !isSending,
                    modifier = Modifier.fillMaxWidth().testTag("forgot_pin_send_otp_button")
                ) {
                    if (isSending) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    Text(if (sentOtpCode == null) "Send Recovery OTP" else "Resend OTP")
                }

                sentOtpCode?.let { code ->
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "OTP sent to: $maskedDestination",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            statusNotice?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                            if (!isLiveDelivered) {
                                OutlinedButton(
                                    onClick = {
                                        if (selectedChannel == OtpChannel.GMAIL_OR_EMAIL) {
                                            otpService.launchDeviceEmailOtp(activeRecipient, code)
                                        } else {
                                            otpService.launchDeviceSmsOtp(activeRecipient, code)
                                        }
                                    }
                                ) {
                                    Text(if (selectedChannel == OtpChannel.GMAIL_OR_EMAIL) "Send via Gmail" else "Send via SMS")
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = otpInput,
                        onValueChange = { otpInput = it.filter { c -> c.isDigit() }.take(6) },
                        label = { Text("Enter 6-Digit Recovery OTP") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("forgot_pin_otp_input")
                    )
                    OutlinedTextField(
                        value = newPin,
                        onValueChange = { newPin = it.filter { c -> c.isDigit() }.take(6) },
                        label = { Text("New Privacy PIN (4–6 digits)") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("forgot_pin_new_pin_input")
                    )
                }

                errorText?.let { err ->
                    Text(err, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            if (sentOtpCode != null) {
                Button(
                    onClick = {
                        when {
                            otpInput != sentOtpCode -> errorText = "Recovery OTP does not match."
                            newPin.length < 4 -> errorText = "Enter a new PIN of 4 to 6 digits."
                            else -> onPinResetSuccess(newPin)
                        }
                    },
                    modifier = Modifier.testTag("forgot_pin_confirm_button")
                ) {
                    Text("Verify & Reset PIN")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
