package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.DynamicFeed
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Leaderboard
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.ArkChallenge
import com.example.data.model.ArkGameType
import com.example.data.model.ArkGroup
import com.example.data.model.ArkPost
import com.example.data.model.ArkStory
import com.example.data.model.ChallengeProgress
import com.example.data.model.GameRoom
import com.example.data.model.UserProfile
import com.example.ui.components.ArkAvatarBadge
import com.example.ui.components.EmptyStateGlassCard
import com.example.ui.components.FeedPostCard
import com.example.ui.components.LevelProgressPill
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.PostSkeletonCard
import com.example.ui.theme.ArkThemeTokens

@Composable
fun HomeDashboardScreen(
    profile: UserProfile,
    posts: List<ArkPost>,
    stories: List<ArkStory>,
    viewedStoryIds: Set<String>,
    isFeedLoading: Boolean,
    isLoadingMoreFeed: Boolean,
    hasMoreFeed: Boolean,
    myReactions: Map<String, String>,
    myPollVotes: Map<String, Int>,
    bookmarkedIds: Set<String>,
    challenges: List<ArkChallenge>,
    challengeProgress: Map<String, ChallengeProgress>,
    groups: List<ArkGroup>,
    recentRooms: List<GameRoom>,
    leaderboard: List<UserProfile>,
    unreadDmCount: Int,
    isAdmin: Boolean,
    onOpenCreatePost: () -> Unit,
    onOpenExplore: () -> Unit,
    onOpenMessages: () -> Unit,
    onOpenGroups: () -> Unit,
    onOpenGames: () -> Unit,
    onAddStory: () -> Unit,
    onOpenStory: (ArkStory) -> Unit,
    onRefreshFeed: () -> Unit,
    onLoadMoreFeed: () -> Unit,
    onReaction: (ArkPost, String) -> Unit,
    onOpenComments: (ArkPost) -> Unit,
    onSharePost: (ArkPost) -> Unit,
    onToggleBookmark: (String) -> Unit,
    onVotePoll: (String, Int) -> Unit,
    onEditCaption: (ArkPost) -> Unit,
    onToggleCommentsDisabled: (ArkPost) -> Unit,
    onDeletePost: (String) -> Unit,
    onHidePost: (String) -> Unit,
    onMuteAuthor: (String, String) -> Unit,
    onReportPost: (ArkPost) -> Unit,
    onOpenMedia: (ArkPost, Int) -> Unit,
    onOpenUserProfile: (String) -> Unit,
    onHashtagClick: (String) -> Unit,
    onOpenLikers: (ArkPost) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenChallenges: () -> Unit,
    onOpenLeaderboard: () -> Unit,
    onOpenAdmin: () -> Unit,
    onOpenGroup: (String) -> Unit,
    onOpenGameRoom: (String) -> Unit
) {
    val colors = ArkThemeTokens.colors
    val activeChallenges = challenges.filter { challengeProgress[it.id]?.status == null }.take(3)
    val listState = rememberLazyListState()

    val shouldLoadMore by remember {
        derivedStateOf {
            val total = listState.layoutInfo.totalItemsCount
            val lastVisible = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            total > 4 && lastVisible >= total - 3
        }
    }

    LaunchedEffect(shouldLoadMore, hasMoreFeed, isLoadingMoreFeed) {
        if (shouldLoadMore && hasMoreFeed && !isLoadingMoreFeed) {
            onLoadMoreFeed()
        }
    }

    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Editorial Top Wordmark + Quick Social/Gaming Actions
        item(key = "home_header") {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    ArkAvatarBadge(
                        avatarPreset = profile.avatarPreset,
                        username = profile.username,
                        imageBase64 = profile.avatarImageBase64,
                        size = 40.dp,
                        isOnline = profile.isOnline,
                        showOnlineDot = profile.showOnlineStatus
                    )
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "ARK",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = colors.ink
                        )
                        Text(
                            text = "@${profile.username} • LVL ${profile.level}",
                            style = MaterialTheme.typography.labelSmall,
                            color = colors.accent,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onOpenGroups, modifier = Modifier.testTag("home_groups_button")) {
                        Icon(Icons.Default.Groups, contentDescription = "Squads & Groups", tint = colors.ink)
                    }
                    IconButton(onClick = onOpenGames, modifier = Modifier.testTag("home_games_button")) {
                        Icon(Icons.Default.SportsEsports, contentDescription = "Games Zone", tint = colors.ink)
                    }
                    if (isAdmin) {
                        IconButton(onClick = onOpenAdmin, modifier = Modifier.testTag("home_admin_button")) {
                            Icon(Icons.Default.AdminPanelSettings, contentDescription = "Admin Moderation", tint = colors.coral)
                        }
                    }
                    IconButton(onClick = onOpenMessages, modifier = Modifier.testTag("home_messages_button")) {
                        BadgedBox(
                            badge = {
                                if (unreadDmCount > 0) {
                                    Badge(containerColor = colors.coral) { Text(unreadDmCount.coerceAtMost(99).toString()) }
                                }
                            }
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = "Direct Messages", tint = colors.ink)
                        }
                    }
                    IconButton(onClick = onOpenSettings, modifier = Modifier.testTag("home_settings_button")) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings and Privacy", tint = colors.ink)
                    }
                }
            }
        }

        // Stories Horizontal Rail
        item(key = "stories_rail") {
            StoriesRail(
                profile = profile,
                stories = stories,
                viewedStoryIds = viewedStoryIds,
                onAddStoryClick = onAddStory,
                onOpenStory = onOpenStory
            )
        }

        // Create Post CTA Bar
        item(key = "create_post_cta") {
            LiquidGlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .testTag("create_post_cta_card"),
                useGlass = true,
                onClick = onOpenCreatePost,
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.AddCircle, contentDescription = null, tint = colors.accent, modifier = Modifier.size(26.dp))
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("Share a moment", style = MaterialTheme.typography.titleSmall, color = colors.ink)
                            Text("Photo carousel, short clip, poll, or squad update", style = MaterialTheme.typography.bodySmall, color = colors.ink2)
                        }
                    }
                    IconButton(onClick = onRefreshFeed) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh feed", tint = colors.accent)
                    }
                }
            }
        }

        // Quick Hub & XP Pill
        item(key = "quick_hub") {
            Column(
                modifier = Modifier.padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                LevelProgressPill(
                    level = profile.level,
                    xp = profile.xp,
                    points = profile.points,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    QuickActionTile(
                        icon = Icons.Default.Bolt,
                        label = "${activeChallenges.size} Quests",
                        accent = colors.emerald,
                        modifier = Modifier.weight(1f).testTag("quick_challenges"),
                        onClick = onOpenChallenges
                    )
                    QuickActionTile(
                        icon = Icons.Default.Leaderboard,
                        label = if (leaderboard.isNotEmpty()) "#1 @${leaderboard.first().username}" else "Rankings",
                        accent = colors.gold,
                        modifier = Modifier.weight(1f).testTag("quick_leaderboard"),
                        onClick = onOpenLeaderboard
                    )
                    QuickActionTile(
                        icon = Icons.Default.SportsEsports,
                        label = "Play Party",
                        accent = colors.violet,
                        modifier = Modifier.weight(1f).testTag("quick_play"),
                        onClick = onOpenGames
                    )
                }

                if (groups.isNotEmpty() || recentRooms.isNotEmpty()) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(groups.take(4), key = { "g_${it.id}" }) { grp ->
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = colors.surface,
                                border = BorderStroke(1.dp, colors.hairline),
                                modifier = Modifier.clickable { onOpenGroup(grp.id) }
                            ) {
                                Text(
                                    text = "Squad: ${grp.name}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = colors.ink,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                                )
                            }
                        }
                        items(recentRooms.take(3), key = { "r_${it.id}" }) { room ->
                            val game = ArkGameType.fromId(room.gameType)
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = colors.surface,
                                border = BorderStroke(1.dp, colors.violet.copy(alpha = 0.4f)),
                                modifier = Modifier.clickable { onOpenGameRoom(room.id) }
                            ) {
                                Text(
                                    text = "${game.title} #${room.roomCode}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = colors.accent,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Feed Section Header
        item(key = "feed_header") {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Feed", style = MaterialTheme.typography.titleLarge, color = colors.ink)
                TextButton(onClick = onOpenExplore) {
                    Text("Explore →", color = colors.accent)
                }
            }
        }

        // Posts Feed
        if (isFeedLoading && posts.isEmpty()) {
            items(3) {
                PostSkeletonCard(modifier = Modifier.padding(horizontal = 16.dp))
            }
        } else if (posts.isEmpty()) {
            item(key = "feed_empty") {
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    EmptyStateGlassCard(
                        icon = Icons.Default.DynamicFeed,
                        title = "Your ARK Feed Awaits",
                        subtitle = "Follow creators, join squads, or share your first photo, clip, or challenge milestone.",
                        actionLabel = "Create First Post",
                        onAction = onOpenCreatePost
                    )
                    OutlinedButton(
                        onClick = onOpenExplore,
                        modifier = Modifier.fillMaxWidth().height(48.dp)
                    ) {
                        Icon(Icons.Default.Explore, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Discover Creators in Explore")
                    }
                }
            }
        } else {
            items(posts, key = { it.id }) { post ->
                FeedPostCard(
                    post = post,
                    currentUserId = profile.userId,
                    myReaction = myReactions[post.id],
                    myPollVote = myPollVotes[post.id],
                    isBookmarked = bookmarkedIds.contains(post.id),
                    onReaction = { react -> onReaction(post, react) },
                    onOpenComments = { onOpenComments(post) },
                    onShare = { onSharePost(post) },
                    onToggleBookmark = { onToggleBookmark(post.id) },
                    onVotePoll = { idx -> onVotePoll(post.id, idx) },
                    onEditCaption = { onEditCaption(post) },
                    onToggleCommentsDisabled = { onToggleCommentsDisabled(post) },
                    onDeletePost = { onDeletePost(post.id) },
                    onHidePost = { onHidePost(post.id) },
                    onMuteAuthor = { onMuteAuthor(post.authorId, post.authorUsername) },
                    onReportPost = { onReportPost(post) },
                    onOpenMedia = { page -> onOpenMedia(post, page) },
                    modifier = Modifier.padding(horizontal = 16.dp),
                    onOpenUserProfile = onOpenUserProfile,
                    onHashtagClick = onHashtagClick,
                    onOpenLikers = { onOpenLikers(post) }
                )
            }

            if (isLoadingMoreFeed) {
                item(key = "loading_more_feed") {
                    Row(modifier = Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.Center) {
                        CircularProgressIndicator(color = colors.accent)
                    }
                }
            } else if (hasMoreFeed) {
                item(key = "load_more_btn") {
                    OutlinedButton(
                        onClick = onLoadMoreFeed,
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                    ) {
                        Text("Load Older Posts")
                    }
                }
            }
        }

        item { Spacer(Modifier.height(72.dp)) }
    }
}

@Composable
private fun QuickActionTile(
    icon: ImageVector,
    label: String,
    accent: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val colors = ArkThemeTokens.colors
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = colors.surface,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.25f))
    ) {
        Column(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = label, tint = accent, modifier = Modifier.size(20.dp))
            Spacer(Modifier.height(4.dp))
            Text(label, style = MaterialTheme.typography.labelSmall, color = colors.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}
