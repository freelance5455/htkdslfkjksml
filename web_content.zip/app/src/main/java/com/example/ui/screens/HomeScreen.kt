package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.RecipeParser
import com.example.viewmodel.MotionForgeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
  viewModel: MotionForgeViewModel,
  onNavigateToPreview: () -> Unit,
  onNavigateToRecipeEditor: () -> Unit,
  onNavigateToTimeline: () -> Unit,
  onNavigateToExport: () -> Unit
) {
  val recipe by viewModel.recipe.collectAsState()
  val sampleRecipes = remember { RecipeParser.getSampleRecipes() }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.FlashOn, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(8.dp))
            Text("MOTIONFORGE AI", fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.surface,
          titleContentColor = MaterialTheme.colorScheme.onSurface
        )
      )
    },
    bottomBar = {
      NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
        NavigationBarItem(
          icon = { Icon(Icons.Default.Dashboard, contentDescription = null) },
          label = { Text("Studio") },
          selected = true,
          onClick = {}
        )
        NavigationBarItem(
          icon = { Icon(Icons.Default.Code, contentDescription = null) },
          label = { Text("I Have Code") },
          selected = false,
          onClick = onNavigateToRecipeEditor
        )
        NavigationBarItem(
          icon = { Icon(Icons.Default.Timeline, contentDescription = null) },
          label = { Text("Timeline") },
          selected = false,
          onClick = onNavigateToTimeline
        )
        NavigationBarItem(
          icon = { Icon(Icons.Default.PlayArrow, contentDescription = null) },
          label = { Text("Preview") },
          selected = false,
          onClick = onNavigateToPreview
        )
      }
    }
  ) { padding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .background(MaterialTheme.colorScheme.background)
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
          Column(modifier = Modifier.padding(20.dp)) {
            Text("Active Project", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = recipe?.projectName ?: "No Project Loaded",
              style = MaterialTheme.typography.headlineMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = "Duration: ${recipe?.settings?.durationSeconds ?: 0f}s | Resolution: ${recipe?.settings?.width}x${recipe?.settings?.height}",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
              Button(
                onClick = onNavigateToPreview,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
              ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null)
                Spacer(modifier = Modifier.width(4.dp))
                Text("Open Preview")
              }
              OutlinedButton(
                onClick = onNavigateToTimeline,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.onSurface)
              ) {
                Icon(Icons.Default.Timeline, contentDescription = null)
                Spacer(modifier = Modifier.width(4.dp))
                Text("Timeline")
              }
            }
          }
        }
      }

      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "AI Motion Templates",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
          )
          TextButton(onClick = onNavigateToRecipeEditor) {
            Text("Paste Code", color = MaterialTheme.colorScheme.primary)
          }
        }
      }

      items(sampleRecipes.keys.toList()) { templateName ->
        val jsonCode = sampleRecipes[templateName] ?: ""
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable {
              viewModel.loadRecipeJson(jsonCode)
              onNavigateToPreview()
            },
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
          Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .size(48.dp)
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f), RoundedCornerShape(8.dp)),
              contentAlignment = Alignment.Center
            ) {
              Icon(Icons.Default.Movie, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(templateName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
              Spacer(modifier = Modifier.height(2.dp))
              Text("Tap to load and preview motion recipe", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
          }
        }
      }
    }
  }
}
