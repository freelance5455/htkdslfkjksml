package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Calculate
import androidx.compose.material.icons.outlined.Clear
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AvailableTools
import com.example.data.model.ToolCategory
import com.example.ui.components.BannerAdView
import com.example.ui.components.ToolCard
import com.example.ui.localization.AppLanguage
import com.example.ui.localization.AppStrings
import com.example.ui.theme.ElectricBlue
import com.example.ui.viewmodel.MainUiState
import com.example.ui.viewmodel.ScreenDestination

@Composable
fun HomeScreen(
    uiState: MainUiState,
    onNavigate: (ScreenDestination) -> Unit,
    onSearchChange: (String) -> Unit,
    onCategorySelect: (ToolCategory) -> Unit,
    onFavoriteToggle: (String) -> Unit,
    onOpenLanguage: () -> Unit,
    modifier: Modifier = Modifier
) {
    val focusManager = LocalFocusManager.current
    val language = uiState.language

    // Filter tools based on category and search
    val filteredTools = remember(uiState.selectedCategory, uiState.searchQuery, language) {
        AvailableTools.allTools.filter { tool ->
            val matchesCategory = uiState.selectedCategory == ToolCategory.ALL || tool.category == uiState.selectedCategory
            val title = AppStrings.get(tool.titleKey, language)
            val desc = AppStrings.get(tool.descKey, language)
            val matchesSearch = uiState.searchQuery.isBlank() ||
                    title.contains(uiState.searchQuery, ignoreCase = true) ||
                    desc.contains(uiState.searchQuery, ignoreCase = true)
            matchesCategory && matchesSearch
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Clean Modern Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(ElectricBlue.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Calculate,
                        contentDescription = null,
                        tint = ElectricBlue,
                        modifier = Modifier.size(26.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = AppStrings.get("app_name", language),
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 19.sp
                        ),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "2026 Edition",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                }
            }

            // Language switch shortcut button
            IconButton(
                onClick = onOpenLanguage,
                modifier = Modifier
                    .testTag("home_btn_language")
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Icon(
                    imageVector = Icons.Outlined.Language,
                    contentDescription = "Language",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        // Modern Search Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
        ) {
            val searchShape = RoundedCornerShape(16.dp)
            OutlinedTextField(
                value = uiState.searchQuery,
                onValueChange = onSearchChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_search_input"),
                placeholder = {
                    Text(
                        text = AppStrings.get("search_hint", language),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Outlined.Search,
                        contentDescription = "Search",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                },
                trailingIcon = {
                    if (uiState.searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchChange("") }) {
                            Icon(
                                imageVector = Icons.Outlined.Clear,
                                contentDescription = "Clear",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                singleLine = true,
                shape = searchShape,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                    focusedBorderColor = ElectricBlue,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() })
            )
        }

        // Category Filter Chips
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp),
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(ToolCategory.values()) { category ->
                val isSelected = uiState.selectedCategory == category
                val label = AppStrings.get(category.titleKey, language)
                val chipShape = RoundedCornerShape(14.dp)

                Box(
                    modifier = Modifier
                        .testTag("cat_chip_${category.key}")
                        .clip(chipShape)
                        .background(
                            if (isSelected) ElectricBlue else MaterialTheme.colorScheme.surface
                        )
                        .border(
                            width = 0.8.dp,
                            color = if (isSelected) ElectricBlue else MaterialTheme.colorScheme.outline.copy(alpha = 0.35f),
                            shape = chipShape
                        )
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = ripple(bounded = true, color = if (isSelected) Color.White else ElectricBlue.copy(alpha = 0.2f)),
                            onClick = { onCategorySelect(category) }
                        )
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                            fontSize = 13.sp
                        ),
                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        // Tools List / Grid
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (filteredTools.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = AppStrings.get("no_tools_found", language),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                items(filteredTools, key = { it.id }) { tool ->
                    val isFav = uiState.favoriteToolIds.contains(tool.id)
                    ToolCard(
                        title = AppStrings.get(tool.titleKey, language),
                        description = AppStrings.get(tool.descKey, language),
                        icon = tool.icon,
                        isFavorite = isFav,
                        testTag = "tool_card_${tool.id}",
                        onFavoriteToggle = { onFavoriteToggle(tool.id) },
                        onClick = {
                            when (tool.id) {
                                "standard_calc" -> onNavigate(ScreenDestination.StandardCalc)
                                "scientific_calc" -> onNavigate(ScreenDestination.ScientificCalc)
                                "age_calc" -> onNavigate(ScreenDestination.AgeCalc)
                                "gst_calc" -> onNavigate(ScreenDestination.GstCalc)
                                "bmi_calc" -> onNavigate(ScreenDestination.BmiCalc)
                                "unit_converter" -> onNavigate(ScreenDestination.UnitConverter)
                                "currency_converter" -> onNavigate(ScreenDestination.CurrencyConverter)
                                "discount_calc" -> onNavigate(ScreenDestination.DiscountCalc)
                                "emi_calc" -> onNavigate(ScreenDestination.EmiCalc)
                                "tip_calc" -> onNavigate(ScreenDestination.TipCalc)
                            }
                        }
                    )
                }
            }
        }

        // Bottom Ad Placement (Preserved AdMob Integration, clearly separated from controls)
        BannerAdView()
    }
}
