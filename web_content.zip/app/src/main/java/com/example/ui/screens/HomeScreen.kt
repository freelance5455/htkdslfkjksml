package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.foundation.Canvas
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.data.model.AchievementBadge
import com.example.data.model.DailyTrendPoint
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.StudyTask
import com.example.data.model.Subject
import com.example.data.model.TopicLecture
import com.example.data.model.UserProgress
import com.example.ui.theme.DopingAmber
import com.example.ui.theme.DopingAmberDark
import com.example.ui.theme.DopingAmberLight
import com.example.ui.theme.DopingGreen
import com.example.ui.theme.DopingPrimary
import com.example.ui.theme.DopingPrimaryVariant
import com.example.ui.theme.DopingRed
import com.example.ui.viewmodel.ScreenTab

@Composable
fun HomeScreen(
  userProgress: UserProgress,
  tasks: List<StudyTask>,
  topics: List<TopicLecture>,
  coachingTips: List<String>,
  badges: List<AchievementBadge> = emptyList(),
  dailyTrend: List<DailyTrendPoint> = emptyList(),
  onNavigate: (ScreenTab) -> Unit,
  onTopicSelected: (TopicLecture) -> Unit,
  onToggleTask: (String) -> Unit,
  onStartQuizForSubject: (Subject?) -> Unit,
  modifier: Modifier = Modifier
) {
  val todayTasks = tasks.filter { it.dayOfWeek == "Bugün" }
  val completedTasksCount = todayTasks.count { it.isCompleted }
  val taskProgress = if (todayTasks.isNotEmpty()) completedTasksCount.toFloat() / todayTasks.size else 0f

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .testTag("home_screen_scroll"),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // 1. Hero Countdown & Goal Card
    item {
      HeroCountdownCard(
        userProgress = userProgress,
        completedTasks = completedTasksCount,
        totalTasks = todayTasks.size,
        taskProgress = taskProgress,
        onGoToPlan = { onNavigate(ScreenTab.COACH_PLAN) }
      )
    }

    // 2. Progress Analysis (7-Day Solved Questions Line Chart)
    item {
      ProgressAnalysisCard(dailyTrend = dailyTrend)
    }

    // 3. Badges Achievement System
    item {
      BadgesShowcaseCard(badges = badges)
    }

    // 4. Personal AI Coach Advice Banner ("Doping Bireysel Koçluk")
    item {
      CoachingAdviceCard(
        advice = coachingTips.firstOrNull() ?: "Düzenli çalışma ve hafıza kodlamaları ile başarın garanti!",
        onOpenCoach = { onNavigate(ScreenTab.COACH_PLAN) }
      )
    }

    // 3. Quick Action Hub (Hızlı Erişim Kartları)
    item {
      QuickActionsGrid(
        errorCount = userProgress.errorNotebookQuestionIds.size,
        onNavigate = onNavigate
      )
    }

    // 4. "Günün Hafıza Tekniği & Kodlamaları" Showcase
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.Psychology,
            contentDescription = null,
            tint = DopingPrimary,
            modifier = Modifier.size(22.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "Görsel Hafıza Şifreleri",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
        }
        Text(
          text = "Tümünü Gör",
          color = DopingPrimary,
          fontSize = 13.sp,
          fontWeight = FontWeight.SemiBold,
          modifier = Modifier
            .clickable { onNavigate(ScreenTab.LECTURES) }
            .padding(4.dp)
            .testTag("view_all_topics_btn")
        )
      }
    }

    item {
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        items(topics) { topic ->
          MnemonicCard(
            topic = topic,
            onClick = {
              onTopicSelected(topic)
              onNavigate(ScreenTab.LECTURES)
            }
          )
        }
      }
    }

    // 5. "Bugünkü Bireysel Planım" Checklist
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.Bookmark,
            contentDescription = null,
            tint = DopingAmberDark,
            modifier = Modifier.size(22.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "Bugünkü Görevlerim",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
        }
        Text(
          text = "$completedTasksCount/${todayTasks.size} Tamamlandı",
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          fontSize = 12.sp,
          fontWeight = FontWeight.Medium
        )
      }
    }

    if (todayTasks.isEmpty()) {
      item {
        Card(
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(
            text = "Bugün için henüz bir görev yok. Koçluk planından yeni görev ekle veya akıllı plan oluştur!",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(16.dp)
          )
        }
      }
    } else {
      items(todayTasks) { task ->
        TaskItemRow(task = task, onToggle = { onToggleTask(task.id) })
      }
    }

    // 6. Sınav Dersleri Hızlı Seçici
    item {
      Text(
        text = "Dersler & Soru Çözümü",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 8.dp)
      )
    }

    item {
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        items(Subject.values()) { subject ->
          SubjectCard(
            subject = subject,
            onClick = { onStartQuizForSubject(subject) }
          )
        }
      }
    }
  }
}

@Composable
private fun HeroCountdownCard(
  userProgress: UserProgress,
  completedTasks: Int,
  totalTasks: Int,
  taskProgress: Float,
  onGoToPlan: () -> Unit
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("hero_countdown_card"),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = Color.Transparent)
  ) {
    Box(
      modifier = Modifier
        .background(
          Brush.linearGradient(
            colors = listOf(
              DopingPrimaryVariant,
              DopingPrimary,
              Color(0xFF6366F1)
            )
          )
        )
        .padding(20.dp)
    ) {
      Column(modifier = Modifier.fillMaxWidth()) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.Top
        ) {
          Column {
            Text(
              text = userProgress.selectedExam.displayName,
              color = DopingAmberLight,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold,
              letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = "Sınava Son ${userProgress.daysRemaining} Gün!",
              color = Color.White,
              fontSize = 22.sp,
              fontWeight = FontWeight.Black
            )
          }

          Surface(
            color = Color.White.copy(alpha = 0.2f),
            shape = RoundedCornerShape(12.dp)
          ) {
            Column(
              modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Text(
                text = "HEDEF NET",
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = "${userProgress.targetNet}",
                color = DopingAmberLight,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Daily Progress Bar
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Günlük Koçluk İlerlemesi",
            color = Color.White.copy(alpha = 0.9f),
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
          )
          Text(
            text = "%${(taskProgress * 100).toInt()} ($completedTasks/$totalTasks Görev)",
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        LinearProgressIndicator(
          progress = { taskProgress },
          modifier = Modifier
            .fillMaxWidth()
            .height(8.dp)
            .clip(RoundedCornerShape(4.dp)),
          color = DopingAmber,
          trackColor = Color.White.copy(alpha = 0.25f)
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Mini Stats row
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          StatSnippet(label = "Bugün Çözülen", value = "${userProgress.todaySolvedQuestions} Soru")
          StatSnippet(label = "Çalışma Süresi", value = "${userProgress.todayStudiedMinutes} Dk")
          StatSnippet(label = "Başarı Oranı", value = "%${if (userProgress.totalQuestionsSolved > 0) (userProgress.totalCorrect * 100 / userProgress.totalQuestionsSolved) else 85}")
        }
      }
    }
  }
}

@Composable
private fun StatSnippet(label: String, value: String) {
  Column {
    Text(
      text = label,
      color = Color.White.copy(alpha = 0.75f),
      fontSize = 10.sp
    )
    Text(
      text = value,
      color = Color.White,
      fontSize = 13.sp,
      fontWeight = FontWeight.Bold
    )
  }
}

@Composable
private fun CoachingAdviceCard(
  advice: String,
  onOpenCoach: () -> Unit
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onOpenCoach() }
      .testTag("coaching_advice_card"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surface
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(44.dp)
          .clip(CircleShape)
          .background(Color(0xFFFEF3C7)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.Default.AutoAwesome,
          contentDescription = "Koçluk",
          tint = DopingAmberDark,
          modifier = Modifier.size(24.dp)
        )
      }

      Spacer(modifier = Modifier.width(12.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = "Doping Bireysel Koç",
          style = MaterialTheme.typography.labelMedium,
          color = DopingPrimary,
          fontWeight = FontWeight.ExtraBold
        )
        Text(
          text = advice,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurface,
          maxLines = 2
        )
      }

      Icon(
        imageVector = Icons.Default.ArrowForward,
        contentDescription = "Planı Aç",
        tint = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.size(18.dp)
      )
    }
  }
}

@Composable
private fun QuickActionsGrid(
  errorCount: Int,
  onNavigate: (ScreenTab) -> Unit
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    QuickActionButton(
      title = "Hata Defterim",
      subtitle = "$errorCount Soru Bekliyor",
      icon = Icons.Default.ReportProblem,
      badgeColor = DopingRed,
      modifier = Modifier.weight(1f),
      testTag = "quick_action_errors",
      onClick = { onNavigate(ScreenTab.ERROR_NOTEBOOK) }
    )

    QuickActionButton(
      title = "Hafıza Kartları",
      subtitle = "Görsel Tekrar",
      icon = Icons.Default.Psychology,
      badgeColor = DopingPrimary,
      modifier = Modifier.weight(1f),
      testTag = "quick_action_flashcards",
      onClick = { onNavigate(ScreenTab.LECTURES) }
    )

    QuickActionButton(
      title = "Odak Sayacı",
      subtitle = "25 Dk Pomodoro",
      icon = Icons.Default.Timer,
      badgeColor = DopingAmberDark,
      modifier = Modifier.weight(1f),
      testTag = "quick_action_pomodoro",
      onClick = { onNavigate(ScreenTab.POMODORO) }
    )
  }
}

@Composable
private fun QuickActionButton(
  title: String,
  subtitle: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  badgeColor: Color,
  modifier: Modifier = Modifier,
  testTag: String,
  onClick: () -> Unit
) {
  Card(
    modifier = modifier
      .clickable { onClick() }
      .testTag(testTag),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp)
    ) {
      Box(
        modifier = Modifier
          .size(32.dp)
          .clip(RoundedCornerShape(8.dp))
          .background(badgeColor.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = icon,
          contentDescription = title,
          tint = badgeColor,
          modifier = Modifier.size(18.dp)
        )
      }
      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = title,
        fontWeight = FontWeight.Bold,
        fontSize = 12.sp,
        color = MaterialTheme.colorScheme.onSurface,
        maxLines = 1
      )
      Text(
        text = subtitle,
        fontSize = 10.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        maxLines = 1
      )
    }
  }
}

@Composable
private fun MnemonicCard(
  topic: TopicLecture,
  onClick: () -> Unit
) {
  Card(
    modifier = Modifier
      .width(260.dp)
      .clickable { onClick() }
      .testTag("mnemonic_card_${topic.id}"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Surface(
          color = topic.subject.primaryColor.copy(alpha = 0.15f),
          shape = RoundedCornerShape(6.dp)
        ) {
          Text(
            text = "${topic.subject.iconEmoji} ${topic.subject.title}",
            color = topic.subject.primaryColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
          )
        }
        Text(
          text = "${topic.durationMinutes} dk",
          fontSize = 11.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      Text(
        text = topic.title,
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
        maxLines = 2
      )

      Spacer(modifier = Modifier.height(6.dp))

      // Mnemonic highlight box
      Surface(
        color = Color(0xFFFEF3C7),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = Icons.Default.AutoAwesome,
            contentDescription = null,
            tint = DopingAmberDark,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = topic.mnemonicCode,
            fontSize = 11.sp,
            fontWeight = FontWeight.ExtraBold,
            color = Color(0xFF92400E),
            maxLines = 1
          )
        }
      }

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = topic.dopingReflex,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        maxLines = 2
      )
    }
  }
}

@Composable
private fun TaskItemRow(
  task: StudyTask,
  onToggle: () -> Unit
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onToggle() }
      .testTag("task_item_${task.id}"),
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (task.isCompleted) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = if (task.isCompleted) 0.dp else 1.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
        imageVector = if (task.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
        contentDescription = if (task.isCompleted) "Tamamlandı" else "Tamamlanmadı",
        tint = if (task.isCompleted) DopingGreen else MaterialTheme.colorScheme.outline,
        modifier = Modifier.size(24.dp)
      )

      Spacer(modifier = Modifier.width(12.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = task.title,
          fontWeight = FontWeight.SemiBold,
          fontSize = 13.sp,
          color = if (task.isCompleted) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
        )
        Row(
          modifier = Modifier.padding(top = 2.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          Text(
            text = "${task.subject.iconEmoji} ${task.subject.title}",
            fontSize = 10.sp,
            color = task.subject.primaryColor,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "• ${task.targetQuestions} Soru",
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Text(
            text = "• ${task.targetMinutes} Dk",
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }

      Surface(
        color = if (task.priority == "Yüksek") DopingRed.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(6.dp)
      ) {
        Text(
          text = task.priority,
          color = if (task.priority == "Yüksek") DopingRed else MaterialTheme.colorScheme.onSurfaceVariant,
          fontSize = 10.sp,
          fontWeight = FontWeight.Bold,
          modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
      }
    }
  }
}

@Composable
private fun SubjectCard(
  subject: Subject,
  onClick: () -> Unit
) {
  Card(
    modifier = Modifier
      .width(130.dp)
      .clickable { onClick() }
      .testTag("subject_card_${subject.id}"),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Box(
        modifier = Modifier
          .size(40.dp)
          .clip(CircleShape)
          .background(subject.primaryColor.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center
      ) {
        Text(text = subject.iconEmoji, fontSize = 20.sp)
      }
      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = subject.title,
        fontWeight = FontWeight.Bold,
        fontSize = 11.sp,
        maxLines = 1,
        color = MaterialTheme.colorScheme.onSurface
      )
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = "Soru Çöz >",
        color = subject.primaryColor,
        fontSize = 10.sp,
        fontWeight = FontWeight.ExtraBold
      )
    }
  }
}

@Composable
private fun ProgressAnalysisCard(
  dailyTrend: List<DailyTrendPoint>
) {
  val totalWeekly = dailyTrend.sumOf { it.solvedQuestions }
  val dailyAvg = if (dailyTrend.isNotEmpty()) totalWeekly / dailyTrend.size else 0
  val maxPoint = dailyTrend.maxByOrNull { it.solvedQuestions }

  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("progress_analysis_card"),
    shape = RoundedCornerShape(18.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "GELİŞİM ANALİZİ",
            color = DopingPrimary,
            fontSize = 11.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 0.5.sp
          )
          Text(
            text = "Son 7 Gün Soru Trendi",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
        }
        Surface(
          color = DopingGreen.copy(alpha = 0.15f),
          shape = RoundedCornerShape(20.dp)
        ) {
          Text(
            text = "📈 +%28 İlerleme",
            color = DopingGreen,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      val maxQuestions = (dailyTrend.maxOfOrNull { it.solvedQuestions } ?: 50).coerceAtLeast(60).toFloat()

      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(140.dp)
          .padding(horizontal = 4.dp)
      ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
          val width = size.width
          val height = size.height - 24.dp.toPx()
          val count = dailyTrend.size
          if (count < 2) return@Canvas

          val stepX = width / (count - 1)

          // Background dashed grid lines
          val gridSteps = 3
          for (i in 0..gridSteps) {
            val y = height * (i.toFloat() / gridSteps)
            drawLine(
              color = Color.LightGray.copy(alpha = 0.2f),
              start = Offset(0f, y),
              end = Offset(width, y),
              strokeWidth = 1.dp.toPx()
            )
          }

          // Build bezier path
          val linePath = Path()
          val fillPath = Path()
          val points = mutableListOf<Offset>()

          dailyTrend.forEachIndexed { idx, pt ->
            val x = idx * stepX
            val ratio = (pt.solvedQuestions / maxQuestions).coerceIn(0f, 1f)
            val y = height - (ratio * height)
            val point = Offset(x, y)
            points.add(point)
            if (idx == 0) {
              linePath.moveTo(x, y)
              fillPath.moveTo(x, height)
              fillPath.lineTo(x, y)
            } else {
              val prev = points[idx - 1]
              val cx = (prev.x + x) / 2
              linePath.cubicTo(cx, prev.y, cx, y, x, y)
              fillPath.cubicTo(cx, prev.y, cx, y, x, y)
            }
          }
          fillPath.lineTo(points.last().x, height)
          fillPath.close()

          // Draw gradient fill
          drawPath(
            path = fillPath,
            brush = Brush.verticalGradient(
              colors = listOf(
                DopingPrimary.copy(alpha = 0.35f),
                DopingPrimary.copy(alpha = 0.02f)
              ),
              startY = 0f,
              endY = height
            )
          )

          // Draw line
          drawPath(
            path = linePath,
            brush = Brush.horizontalGradient(
              colors = listOf(DopingPrimary, DopingAmber)
            ),
            style = Stroke(width = 3.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
          )

          // Draw dots
          points.forEachIndexed { idx, pt ->
            drawCircle(
              color = Color.White,
              radius = 5.dp.toPx(),
              center = pt
            )
            drawCircle(
              color = if (idx == points.lastIndex) DopingAmber else DopingPrimary,
              radius = 3.5.dp.toPx(),
              center = pt
            )
          }
        }

        // Labels at bottom
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .align(Alignment.BottomCenter),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          dailyTrend.forEach { pt ->
            Text(
              text = pt.dayLabel,
              fontSize = 9.sp,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              fontWeight = FontWeight.Medium
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
          .padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text(
          text = "Toplam: ${totalWeekly} Soru",
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Text(
          text = "Günlük Ort: ${dailyAvg} Soru",
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = DopingAmberDark
        )
        Text(
          text = "Zirve: ${maxPoint?.dayLabel ?: "Bugün"} (${maxPoint?.solvedQuestions ?: 0})",
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = DopingGreen
        )
      }
    }
  }
}

@Composable
private fun BadgesShowcaseCard(
  badges: List<AchievementBadge>
) {
  var selectedBadge by remember { mutableStateOf<AchievementBadge?>(null) }
  val unlockedCount = badges.count { it.isUnlocked }

  Column(modifier = Modifier.fillMaxWidth()) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Default.EmojiEvents,
          contentDescription = null,
          tint = DopingAmberDark,
          modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = "Başarı Rozetleri",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
      }
      Surface(
        color = DopingAmberLight,
        shape = RoundedCornerShape(12.dp)
      ) {
        Text(
          text = "$unlockedCount/${badges.size} Kazanıldı",
          color = Color(0xFF92400E),
          fontSize = 11.sp,
          fontWeight = FontWeight.ExtraBold,
          modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    LazyRow(
      horizontalArrangement = Arrangement.spacedBy(10.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      items(badges) { badge ->
        BadgeItemCard(
          badge = badge,
          onClick = { selectedBadge = badge }
        )
      }
    }

    selectedBadge?.let { badge ->
      AlertDialog(
        onDismissRequest = { selectedBadge = null },
        icon = { Text(text = badge.iconEmoji, fontSize = 42.sp) },
        title = {
          Text(
            text = badge.title,
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp
          )
        },
        text = {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(badge.description, style = MaterialTheme.typography.bodyMedium)
            Spacer(modifier = Modifier.height(4.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = if (badge.isUnlocked) "Durum: Kazanıldı! 🎉" else "İlerleme:",
                fontWeight = FontWeight.Bold,
                color = if (badge.isUnlocked) DopingGreen else MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 12.sp
              )
              Text(
                text = "${badge.currentValue}/${badge.targetValue}",
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
              )
            }
            LinearProgressIndicator(
              progress = { badge.progressPercent },
              modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp)),
              color = if (badge.isUnlocked) DopingAmberDark else DopingPrimary,
              trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
          }
        },
        confirmButton = {
          Button(
            onClick = { selectedBadge = null },
            colors = ButtonDefaults.buttonColors(containerColor = DopingPrimary)
          ) {
            Text("Harika!")
          }
        }
      )
    }
  }
}

@Composable
private fun BadgeItemCard(
  badge: AchievementBadge,
  onClick: () -> Unit
) {
  Card(
    modifier = Modifier
      .width(135.dp)
      .clickable { onClick() }
      .testTag("badge_card_${badge.id}"),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (badge.isUnlocked) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
    ),
    border = if (badge.isUnlocked) androidx.compose.foundation.BorderStroke(1.5.dp, DopingAmber.copy(alpha = 0.6f)) else null,
    elevation = CardDefaults.cardElevation(defaultElevation = if (badge.isUnlocked) 2.dp else 0.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(10.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Box(
        modifier = Modifier
          .size(46.dp)
          .clip(CircleShape)
          .background(
            if (badge.isUnlocked)
              Brush.linearGradient(listOf(DopingAmber, DopingAmberDark))
            else
              Brush.linearGradient(listOf(Color.Gray.copy(alpha = 0.3f), Color.DarkGray.copy(alpha = 0.3f)))
          ),
        contentAlignment = Alignment.Center
      ) {
        Text(text = badge.iconEmoji, fontSize = 24.sp)
      }

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = badge.title,
        fontWeight = FontWeight.Bold,
        fontSize = 11.sp,
        maxLines = 1,
        color = if (badge.isUnlocked) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
      )

      Text(
        text = if (badge.isUnlocked) "Kazanıldı ✅" else "${badge.currentValue}/${badge.targetValue}",
        fontSize = 10.sp,
        color = if (badge.isUnlocked) DopingGreen else MaterialTheme.colorScheme.onSurfaceVariant,
        fontWeight = FontWeight.SemiBold
      )
    }
  }
}
