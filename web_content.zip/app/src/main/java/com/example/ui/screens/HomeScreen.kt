package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.*
import com.example.ui.viewmodel.CollegeViewModel
import com.example.ui.viewmodel.Screen

data class DashboardCardItem(
    val titleEn: String,
    val titleHi: String,
    val description: String,
    val icon: ImageVector,
    val color: Color,
    val containerColor: Color,
    val screen: Screen
)

@Composable
fun HomeScreen(
    viewModel: CollegeViewModel,
    onOpenRoleDialog: () -> Unit
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val notices by viewModel.notices.collectAsState()
    val holidays by viewModel.holidays.collectAsState()

    val dashboardCards = listOf(
        DashboardCardItem(
            titleEn = "Know Your Teacher",
            titleHi = "शिक्षक परिचय",
            description = "Faculty directory, qualifications, experience & contact details.",
            icon = Icons.Default.School,
            color = NursingGreenPrimary,
            containerColor = NursingGreenContainer,
            screen = Screen.TeacherDirectory
        ),
        DashboardCardItem(
            titleEn = "Batch",
            titleHi = "बैच प्रबंधन",
            description = "4 Batches: Coordinator, Students, Syllabus & Attendance.",
            icon = Icons.Default.Groups,
            color = ClinicalBlueSecondary,
            containerColor = ClinicalBlueContainer,
            screen = Screen.BatchManagement
        ),
        DashboardCardItem(
            titleEn = "Complaint",
            titleHi = "शिकायत दर्ज करें",
            description = "Register student grievance and receive 4-digit tracking code.",
            icon = Icons.Default.ReportProblem,
            color = Color(0xFFD97706),
            containerColor = Color(0xFFFEF3C7),
            screen = Screen.ComplaintRegistration
        ),
        DashboardCardItem(
            titleEn = "Complaint Status",
            titleHi = "शिकायत की स्थिति",
            description = "Track status using 4-digit code (Received to Resolved).",
            icon = Icons.Default.TrackChanges,
            color = MedicalTealTertiary,
            containerColor = MedicalTealContainer,
            screen = Screen.ComplaintStatus
        ),
        DashboardCardItem(
            titleEn = "Notice",
            titleHi = "सूचना पट्ट",
            description = "Academic circulars, RNC updates & college announcements.",
            icon = Icons.Default.Campaign,
            color = Color(0xFF7C3AED),
            containerColor = Color(0xFFEDE9FE),
            screen = Screen.NoticeBoard
        ),
        DashboardCardItem(
            titleEn = "Holiday",
            titleHi = "अवकाश कैलेंडर",
            description = "College academic holiday calendar (Asia/Kolkata).",
            icon = Icons.Default.CalendarMonth,
            color = Color(0xFFEA580C),
            containerColor = Color(0xFFFFEDD5),
            screen = Screen.HolidayCalendar
        ),
        DashboardCardItem(
            titleEn = "Clinical Duty",
            titleHi = "क्लिनिकल ड्यूटी",
            description = "Hospital postings, clinical teachers & attendance roster.",
            icon = Icons.Default.LocalHospital,
            color = Color(0xFF0284C7),
            containerColor = Color(0xFFE0F2FE),
            screen = Screen.ClinicalDuty
        ),
        DashboardCardItem(
            titleEn = "Admin Login",
            titleHi = "प्रशासक लॉगिन",
            description = "Manage faculty, students, syllabus, logs & app settings.",
            icon = Icons.Default.AdminPanelSettings,
            color = Color(0xFF0F766E),
            containerColor = Color(0xFFCCFBF1),
            screen = Screen.AdminDashboard
        )
    )

    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 160.dp),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Hero College Banner
        item(span = { GridItemSpan(maxLineSpan) }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.gnmtc_campus_hero_1792553656252),
                        contentDescription = "GNMTC SGNR Campus",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    // Gradient overlay
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Transparent,
                                        Color(0xCC0D6938),
                                        Color(0xF0023618)
                                    )
                                )
                            )
                    )
                    // College title and emblem
                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.gnmtc_launcher_icon_1792553640961),
                            contentDescription = "College Seal",
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "GNMTC SGNR",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                            Text(
                                text = "Govt. General Nursing & Midwifery Training Centre",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Color.White.copy(alpha = 0.9f),
                                    fontSize = 11.sp
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "Sri Ganganagar, Rajasthan",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color(0xFFFFD54F)
                                )
                            )
                        }
                    }
                }
            }
        }

        // Live Bulletin Strip (Latest Notice & Holiday ticker)
        item(span = { GridItemSpan(maxLineSpan) }) {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = ClinicalBlueContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Campaign,
                        contentDescription = null,
                        tint = ClinicalBlueSecondary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "LATEST NOTICE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = ClinicalBlueSecondary
                            )
                        )
                        val latestNotice = notices.firstOrNull { it.isPublished }
                        Text(
                            text = latestNotice?.title ?: "Welcome to GNMTC SGNR Online Portal 2026-27",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    TextButton(onClick = { viewModel.navigateTo(Screen.NoticeBoard) }) {
                        Text("View", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }

        // HTML Web Version Quick Switch Banner
        item(span = { GridItemSpan(maxLineSpan) }) {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.navigateTo(Screen.HtmlAppView) }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = NursingGreenPrimary,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Public,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "HTML Web Version (वेब संस्करण)",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                text = "Converted to HTML • Click to open in-app web view",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                        }
                    }
                    Button(
                        onClick = { viewModel.navigateTo(Screen.HtmlAppView) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NursingGreenPrimary,
                            contentColor = Color.White
                        ),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text("Open HTML", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }

        // Section Title: 8 Core Folders
        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Main Folders (मुख्य विभाग)",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                )
                Text(
                    text = "8 Sections",
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = MaterialTheme.colorScheme.primary
                    )
                )
            }
        }

        // 8 Dashboard Cards
        items(dashboardCards.size) { index ->
            val card = dashboardCards[index]
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .clickable { viewModel.navigateTo(card.screen) }
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(card.containerColor),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = card.icon,
                            contentDescription = card.titleEn,
                            tint = card.color,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Column {
                        Text(
                            text = card.titleEn,
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = card.titleHi,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = card.color,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 11.sp
                            ),
                            maxLines = 1
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = card.description,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f),
                                fontSize = 10.5.sp,
                                lineHeight = 13.sp
                            ),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        // Bottom Academic Info Footer
        item(span = { GridItemSpan(maxLineSpan) }) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Affiliated with Rajasthan Nursing Council (RNC), Jaipur",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                    Text(
                        text = "Govt. Hospital Campus, Sukhadia Circle, Sri Ganganagar",
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                }
            }
        }
    }
}
