package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.MainViewModel
import com.example.ui.components.ChaufalandHeader
import com.example.ui.dialogs.AdminDialog
import com.example.ui.dialogs.GamerTagDialog

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(state.feedbackMessage) {
        state.feedbackMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.dismissFeedback()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = Color(0xFF131518),
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // HEADER OFICIAL CON LOGO 3D CHAUFALAND Y DIRT
            ChaufalandHeader(
                isOnline = state.serverStatus.online,
                statusText = state.serverStatus.statusText
            )

            // BARRA DE ACCESO RÁPIDO: GAMERTAG Y BOTÓN ADMIN
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Pill del GamerTag
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0xFF1E232B))
                        .border(1.dp, Color(0xFF2C3442), RoundedCornerShape(20.dp))
                        .clickable { viewModel.promptChangeGamerTag() }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("user_gamertag_pill")
                ) {
                    val currentTag = if (state.config.gamerTag.isNotBlank()) state.config.gamerTag else "Steve"
                    AsyncImage(
                        model = "https://minotar.net/avatar/$currentTag/64.png",
                        contentDescription = "Avatar",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(20.dp)
                            .clip(RoundedCornerShape(3.dp))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (state.config.gamerTag.isNotBlank()) state.config.gamerTag else "Sin GamerTag",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "✎",
                        fontSize = 11.sp,
                        color = Color(0xFFFFB703)
                    )
                }

                // Botón Panel Admin (Clave JuancitoChen23)
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFC0392B)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .clickable { viewModel.openAdminModal() }
                        .testTag("btn_open_admin_panel")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = "Admin", tint = Color.White, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Panel Admin",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }

            // PESTAÑAS PRINCIPALES
            val tabs = listOf(
                Pair("Servidor", Icons.Default.Dns),
                Pair("Voz P2P", Icons.Default.Mic),
                Pair("Bedrock", Icons.Default.Map),
                Pair("Archivos", Icons.Default.Code)
            )

            TabRow(
                selectedTabIndex = state.selectedTab,
                containerColor = Color(0xFF1B2028),
                contentColor = Color(0xFFFFB703),
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[state.selectedTab]),
                        color = Color(0xFFFFB703)
                    )
                }
            ) {
                tabs.forEachIndexed { index, pair ->
                    Tab(
                        selected = state.selectedTab == index,
                        onClick = { viewModel.selectTab(index) },
                        text = {
                            Text(
                                text = pair.first,
                                fontSize = 12.sp,
                                fontWeight = if (state.selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (state.selectedTab == index) Color(0xFFFFB703) else Color(0xFFA0AEC0)
                            )
                        },
                        icon = {
                            Icon(
                                imageVector = pair.second,
                                contentDescription = pair.first,
                                tint = if (state.selectedTab == index) Color(0xFFFFB703) else Color(0xFFA0AEC0),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    )
                }
            }

            // CONTENIDO DE LA PESTAÑA SELECCIONADA
            Box(modifier = Modifier.weight(1f)) {
                when (state.selectedTab) {
                    0 -> ServerStatusTab(
                        state = state,
                        onRefresh = { viewModel.refreshServerStatus() },
                        onAction = { action -> viewModel.executeServerAction(action) },
                        onSendCommand = { cmd -> viewModel.sendConsoleCommand(cmd) },
                        onOpenAdmin = { viewModel.openAdminModal() }
                    )
                    1 -> VoiceChannelsTab(
                        state = state,
                        onJoinChannel = { chId -> viewModel.joinVoiceChannel(chId) },
                        onLeaveChannel = { viewModel.leaveVoiceChannel() },
                        onToggleMute = { viewModel.toggleMute() }
                    )
                    2 -> BedrockBridgeTab(
                        state = state
                    )
                    3 -> ServerFilesTab()
                }
            }
        }
    }

    // MODAL OBLIGATORIO DE GAMERTAG
    if (state.showGamerTagDialog) {
        GamerTagDialog(
            initialGamerTag = state.config.gamerTag,
            onConfirm = { tag -> viewModel.setGamerTag(tag) }
        )
    }

    // MODAL DE ADMINISTRACIÓN (CLAVE JuancitoChen23)
    if (state.showAdminDialog) {
        AdminDialog(
            config = state.config,
            isAuthenticated = state.isAdminAuthenticated,
            onVerifyPassword = { pass -> viewModel.verifyAdminPassword(pass) },
            onSaveConfig = { updated -> viewModel.saveAdminConfig(updated) },
            onDismiss = { viewModel.closeAdminModal() }
        )
    }
}
