package com.example.ui.renderer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.example.model.ProjectRecipe
import com.example.model.Scene
import com.example.model.Layer
import com.example.engine.AudioAnalysisResult
import kotlin.math.sin
import kotlin.math.cos

@Composable
fun SceneRenderer(
  recipe: ProjectRecipe?,
  currentTime: Float,
  audioAnalysis: AudioAnalysisResult?,
  modifier: Modifier = Modifier
) {
  if (recipe == null || recipe.scenes.isEmpty()) {
    Box(modifier = modifier.background(Color.Black))
    return
  }

  // Find active scene at currentTime
  val activeScene = recipe.scenes.firstOrNull { currentTime >= it.startTime && currentTime <= (it.startTime + it.duration) }
    ?: recipe.scenes.first()

  Canvas(modifier = modifier) {
    val canvasWidth = size.width
    val canvasHeight = size.height

    // 1. Draw Background Gradient
    drawRect(
      brush = Brush.verticalGradient(
        colors = listOf(Color(0xFF0D0D0D), Color(0xFF1E1628)),
        startY = 0f,
        endY = canvasHeight
      )
    )

    // 2. Draw Audio-reactive background particle pulses if beats match
    audioAnalysis?.beatTimestamps?.let { beats ->
      val recentBeat = beats.any { kotlin.math.abs(it - currentTime) < 0.15f }
      if (recentBeat) {
        drawCircle(
          color = Color(0xFFFF6B00).copy(alpha = 0.15f),
          radius = canvasWidth * 0.7f,
          center = Offset(canvasWidth / 2f, canvasHeight / 2f)
        )
      }
    }

    // 3. Render Layers in active scene
    activeScene.layers.forEach { layer ->
      val localTime = currentTime - layer.startTime
      if (localTime >= 0f && localTime <= layer.duration) {
        renderLayer(this, layer, localTime, canvasWidth, canvasHeight)
      }
    }
  }
}

private fun renderLayer(scope: DrawScope, layer: Layer, localTime: Float, width: Float, height: Float) {
  val x = (layer.posX / 1080f) * width
  val y = (layer.posY / 1920f) * height

  when (layer.type) {
    "shape" -> {
      val pulse = 1.0f + 0.1f * sin(localTime * 4f)
      val radius = 120f * layer.scale * pulse
      scope.drawCircle(
        color = Color(0xFFFF6B00),
        radius = radius,
        center = Offset(x, y)
      )
      scope.drawCircle(
        color = Color.White,
        radius = radius + 8f,
        center = Offset(x, y),
        style = Stroke(width = 4f)
      )
    }
    "3d" -> {
      // Render 3D wireframe / geometric primitive rotation
      val angle = localTime * 45.0f
      scope.rotate(angle, pivot = Offset(x, y)) {
        val sizeBox = 160f * layer.scale
        drawRect(
          color = Color(0xFFFF9E00),
          topLeft = Offset(x - sizeBox / 2f, y - sizeBox / 2f),
          size = Size(sizeBox, sizeBox),
          style = Stroke(width = 6f)
        )
        drawRect(
          color = Color(0xFFFF6B00).copy(alpha = 0.3f),
          topLeft = Offset(x - sizeBox / 2f, y - sizeBox / 2f),
          size = Size(sizeBox, sizeBox)
        )
      }
    }
    "text" -> {
      // Text layer placeholder rendering on canvas
      val alpha = (localTime * 2f).coerceIn(0f, 1f)
      val textVal = layer.textConfig?.text ?: layer.name
      // Draw text background badge
      scope.drawRect(
        color = Color.Black.copy(alpha = 0.6f * alpha),
        topLeft = Offset(x - 300f, y - 50f),
        size = Size(600f, 100f)
      )
      scope.drawRect(
        color = Color(0xFFFF6B00).copy(alpha = alpha),
        topLeft = Offset(x - 300f, y - 50f),
        size = Size(600f, 100f),
        style = Stroke(width = 3f)
      )
    }
  }
}
