package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Female
import androidx.compose.material.icons.outlined.Male
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AppTopBar
import com.example.ui.components.BannerAdView
import com.example.ui.localization.AppStrings
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.SoftViolet
import com.example.ui.theme.SubtleMint
import com.example.ui.viewmodel.MainUiState

@Composable
fun BmiCalculatorScreen(
    uiState: MainUiState,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val language = uiState.language

    var isMale by remember { mutableStateOf(true) }
    var heightCmText by remember { mutableStateOf("175") }
    var weightKgText by remember { mutableStateOf("70") }

    val heightCm = heightCmText.toDoubleOrNull() ?: 0.0
    val weightKg = weightKgText.toDoubleOrNull() ?: 0.0

    // BMI = weight (kg) / [height (m)]^2
    val heightM = heightCm / 100.0
    val bmi = if (heightM > 0) weightKg / (heightM * heightM) else 0.0

    // Category
    val (categoryKey, categoryColor) = when {
        bmi <= 0.0 -> Pair("normal_weight", Color.Gray)
        bmi < 18.5 -> Pair("underweight", Color(0xFF3B82F6))
        bmi < 25.0 -> Pair("normal_weight", SubtleMint)
        bmi < 30.0 -> Pair("overweight", Color(0xFFF59E0B))
        else -> Pair("obese", Color(0xFFEF4444))
    }

    // Healthy weight range for height: 18.5 * h^2 to 24.9 * h^2
    val minHealthyWeight = 18.5 * heightM * heightM
    val maxHealthyWeight = 24.9 * heightM * heightM

    val cardShape = RoundedCornerShape(18.dp)

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        AppTopBar(
            title = AppStrings.get("tool_bmi", language),
            navigationIcon = Icons.AutoMirrored.Outlined.ArrowBack,
            onNavigationClick = onBack
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Inputs Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(cardShape)
                    .background(MaterialTheme.colorScheme.surface)
                    .border(0.8.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f), cardShape)
                    .padding(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    // Gender Selector
                    Text(
                        text = AppStrings.get("gender", language),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        GenderChip(
                            label = AppStrings.get("male", language),
                            icon = Icons.Outlined.Male,
                            isSelected = isMale,
                            accentColor = ElectricBlue,
                            testTag = "bmi_gender_male",
                            modifier = Modifier.weight(1f)
                        ) { isMale = true }

                        GenderChip(
                            label = AppStrings.get("female", language),
                            icon = Icons.Outlined.Female,
                            isSelected = !isMale,
                            accentColor = SoftViolet,
                            testTag = "bmi_gender_female",
                            modifier = Modifier.weight(1f)
                        ) { isMale = false }
                    }

                    // Height & Weight text fields
                    OutlinedTextField(
                        value = heightCmText,
                        onValueChange = { heightCmText = it },
                        label = { Text(AppStrings.get("height_cm", language)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("bmi_input_height"),
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricBlue,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                        )
                    )

                    OutlinedTextField(
                        value = weightKgText,
                        onValueChange = { weightKgText = it },
                        label = { Text(AppStrings.get("weight_kg", language)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("bmi_input_weight"),
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricBlue,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                        )
                    )
                }
            }

            // BMI Result Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(cardShape)
                    .background(categoryColor.copy(alpha = 0.08f))
                    .border(1.dp, categoryColor.copy(alpha = 0.3f), cardShape)
                    .padding(20.dp)
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = AppStrings.get("bmi_result", language),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (bmi > 0) "%.1f".format(bmi) else "--",
                        style = MaterialTheme.typography.displayMedium.copy(fontWeight = FontWeight.Bold),
                        color = categoryColor
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = AppStrings.get(categoryKey, language),
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = categoryColor
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Visual BMI Gauge Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp))
                    ) {
                        Box(modifier = Modifier.weight(18.5f).fillMaxHeight().background(Color(0xFF3B82F6)))
                        Box(modifier = Modifier.weight(6.5f).fillMaxHeight().background(SubtleMint))
                        Box(modifier = Modifier.weight(5f).fillMaxHeight().background(Color(0xFFF59E0B)))
                        Box(modifier = Modifier.weight(10f).fillMaxHeight().background(Color(0xFFEF4444)))
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Healthy weight advice
                    if (heightM > 0) {
                        Text(
                            text = "${AppStrings.get("healthy_range", language)}: %.1f kg - %.1f kg".format(minHealthyWeight, maxHealthyWeight),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        BannerAdView()
    }
}

@Composable
private fun GenderChip(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    accentColor: Color,
    testTag: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier = modifier
            .testTag(testTag)
            .clip(shape)
            .background(if (isSelected) accentColor.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .border(
                1.dp,
                if (isSelected) accentColor else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                shape
            )
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) accentColor else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge.copy(
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                ),
                color = if (isSelected) accentColor else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
