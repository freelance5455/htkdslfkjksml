package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.FitScreen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.MediaItem
import com.example.data.model.MediaSource
import com.example.ui.theme.YiffyPrimary
import com.example.ui.theme.YiffySecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

import com.example.data.model.GenderFilter

@Composable
fun FeedView(
    items: List<MediaItem>,
    onItemVisible: (MediaItem) -> Unit,
    onToggleLike: (MediaItem) -> Unit,
    onToggleFavorite: (MediaItem) -> Unit,
    onOpenComments: (MediaItem) -> Unit,
    onDownload: (MediaItem) -> Unit,
    onToggleSidebar: () -> Unit,
    genderFilter: GenderFilter,
    onSelectGenderFilter: (GenderFilter) -> Unit,
    currentSourceFilter: MediaSource?,
    onClearSourceFilter: () -> Unit,
    onRefresh: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    if (items.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(Color(0xFF0A0B0E)),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator(color = YiffyPrimary, modifier = Modifier.size(36.dp))
                Spacer(Modifier.height(16.dp))
                Text(
                    "Discovering media feeds...",
                    color = Color.LightGray,
                    fontSize = 14.sp
                )
            }
        }
        return
    }

    val pagerState = rememberPagerState(pageCount = { items.size })

    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.currentPage }.collect { page ->
            if (page in items.indices) {
                onItemVisible(items[page])
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .testTag("feed_view_container")
    ) {
        VerticalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize()
        ) { page ->
            val item = items[page]
            FeedItemPage(
                item = item,
                isCurrentPage = pagerState.currentPage == page,
                onToggleLike = { onToggleLike(item) },
                onToggleFavorite = { onToggleFavorite(item) },
                onOpenComments = { onOpenComments(item) },
                onDownload = { onDownload(item) }
            )
        }

        // Top Floating Control Bar (Overlay)
        FeedTopOverlay(
            onToggleSidebar = onToggleSidebar,
            genderFilter = genderFilter,
            onSelectGenderFilter = onSelectGenderFilter,
            currentSourceFilter = currentSourceFilter,
            onClearSourceFilter = onClearSourceFilter,
            onRefresh = onRefresh,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FeedItemPage(
    item: MediaItem,
    isCurrentPage: Boolean,
    onToggleLike: () -> Unit,
    onToggleFavorite: () -> Unit,
    onOpenComments: () -> Unit,
    onDownload: () -> Unit
) {
    var isPlaying by remember { mutableStateOf(true) }
    var isMuted by remember { mutableStateOf(false) }
    var showHeartAnimation by remember { mutableStateOf(false) }
    var playbackProgress by remember { mutableFloatStateOf(0f) }

    // User Requirement: "And when the video aspect ratio doesnt fit the conventional phone vertical,
    // let there be a choice between flipping the phone or watching it without it being stretched to fit the screen"
    var isFitMode by remember { mutableStateOf(false) } // false = Crop (fill vertical), true = Fit (un-stretched letterbox)
    var isFlippedLandscape by remember { mutableStateOf(false) } // true = flipped 90° landscape orientation

    val heartScale = remember { Animatable(0f) }
    val coroutineScope = rememberCoroutineScope()

    // Simulated media playback timer progress
    LaunchedEffect(isCurrentPage, isPlaying) {
        if (isCurrentPage && isPlaying) {
            playbackProgress = 0f
            while (isPlaying) {
                delay(100)
                playbackProgress = (playbackProgress + 0.02f) % 1.0f
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(
                    onDoubleTap = {
                        onToggleLike()
                        coroutineScope.launch {
                            showHeartAnimation = true
                            heartScale.snapTo(0f)
                            heartScale.animateTo(
                                targetValue = 1.3f,
                                animationSpec = spring(dampingRatio = 0.5f, stiffness = 400f)
                            )
                            delay(400)
                            heartScale.animateTo(0f, animationSpec = tween(200))
                            showHeartAnimation = false
                        }
                    },
                    onTap = {
                        isPlaying = !isPlaying
                    }
                )
            }
    ) {
        // Media Image / Simulated Video Player with Aspect Ratio and Flip Rotation Handling
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            AsyncImage(
                model = item.previewUrl.ifBlank { item.mediaUrl },
                contentDescription = item.title,
                contentScale = if (isFitMode) ContentScale.Fit else ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .rotate(if (isFlippedLandscape) 90f else 0f)
            )
        }

        // Gradient overlay for contrast
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.45f),
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.85f)
                        )
                    )
                )
        )

        // Top-left Quick Video Ratio & Flip Controls
        Row(
            modifier = Modifier
                .align(Alignment.TopStart)
                .statusBarsPadding()
                .padding(start = 16.dp, top = 56.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Aspect Ratio Mode Toggle: Fit (Letterbox / Unstretched) vs Fill (Crop)
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = if (isFitMode) YiffyPrimary else Color.Black.copy(alpha = 0.6f),
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { isFitMode = !isFitMode }
                    .testTag("feed_aspect_ratio_toggle_btn")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        if (isFitMode) Icons.Default.FitScreen else Icons.Default.Crop,
                        contentDescription = "Aspect Ratio",
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = if (isFitMode) "Fit (Natural)" else "Fill (Vertical)",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Screen Flip / Landscape Rotation Button
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = if (isFlippedLandscape) Color(0xFF00C853) else Color.Black.copy(alpha = 0.6f),
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { isFlippedLandscape = !isFlippedLandscape }
                    .testTag("feed_screen_flip_btn")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.ScreenRotation,
                        contentDescription = "Rotate Video",
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = if (isFlippedLandscape) "Rotated 90°" else "Flip / Rotate",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Play / Pause Indicator overlay on tap
        if (!isPlaying) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.6f))
                    .align(Alignment.Center)
            ) {
                Icon(
                    Icons.Default.PlayArrow,
                    contentDescription = "Paused",
                    tint = Color.White,
                    modifier = Modifier
                        .size(44.dp)
                        .align(Alignment.Center)
                )
            }
        }

        // Heart Burst Animation on Double Tap
        if (showHeartAnimation) {
            Icon(
                Icons.Default.Favorite,
                contentDescription = null,
                tint = YiffyPrimary,
                modifier = Modifier
                    .size(110.dp)
                    .scale(heartScale.value)
                    .align(Alignment.Center)
            )
        }

        // Right-Side Floating Action Rail
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 12.dp, bottom = 80.dp)
        ) {
            // Author Avatar with Source Platform Badge
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .clip(CircleShape)
                    .border(2.dp, YiffyPrimary, CircleShape)
                    .background(Color(0xFF1E212B)),
                contentAlignment = Alignment.Center
            ) {
                if (item.authorAvatarUrl.isNotBlank()) {
                    AsyncImage(
                        model = item.authorAvatarUrl,
                        contentDescription = item.author,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Text(
                        text = item.author.take(1).uppercase(),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // Like Action
            ActionRailButton(
                icon = if (item.isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                label = formatCount(item.likesCount),
                tint = if (item.isLiked) YiffyPrimary else Color.White,
                onClick = onToggleLike,
                testTag = "feed_like_btn"
            )

            Spacer(Modifier.height(16.dp))

            // Favorite Action
            ActionRailButton(
                icon = if (item.isFavorited) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                label = "Fav",
                tint = if (item.isFavorited) Color(0xFFFFB300) else Color.White,
                onClick = onToggleFavorite,
                testTag = "feed_fav_btn"
            )

            Spacer(Modifier.height(16.dp))

            // Comments Action (opens bottom sheet)
            ActionRailButton(
                icon = Icons.Default.ChatBubble,
                label = formatCount(item.commentsCount),
                tint = Color.White,
                onClick = onOpenComments,
                testTag = "feed_comments_btn"
            )

            Spacer(Modifier.height(16.dp))

            // Download Action
            ActionRailButton(
                icon = Icons.Default.Download,
                label = "Save",
                tint = Color.White,
                onClick = onDownload,
                testTag = "feed_download_btn"
            )

            Spacer(Modifier.height(16.dp))

            // Audio Mute Toggle
            IconButton(
                onClick = { isMuted = !isMuted },
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.5f))
            ) {
                Icon(
                    if (isMuted) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                    contentDescription = "Mute",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        // Bottom Content Metadata (TikTok style title, creator, caption, tags)
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth(0.80f)
                .padding(start = 16.dp, bottom = 80.dp)
        ) {
            // Source Platform Badge
            Surface(
                color = Color(item.source.badgeColorHex),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.padding(bottom = 6.dp)
            ) {
                Text(
                    text = item.source.displayName.uppercase(),
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                )
            }

            // Creator & Title
            Text(
                text = "@${item.author}",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.White
            )

            Spacer(Modifier.height(4.dp))

            Text(
                text = item.title,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                color = Color(0xFFF2F4F8)
            )

            if (item.caption.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = item.caption,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.LightGray,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // Tags row preview
            if (item.tags.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item.tags.take(4).forEach { tag ->
                        Text(
                            text = "#${tag.replace("_", " ")}",
                            color = YiffySecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // Bottom Video Playback Progress Line
        LinearProgressIndicator(
            progress = { playbackProgress },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(3.dp),
            color = YiffyPrimary,
            trackColor = Color.White.copy(alpha = 0.2f),
        )
    }
}

@Composable
fun ActionRailButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit,
    testTag: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.45f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                icon,
                contentDescription = label,
                tint = tint,
                modifier = Modifier.size(24.dp)
            )
        }
        Spacer(Modifier.height(2.dp))
        Text(
            text = label,
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun FeedTopOverlay(
    onToggleSidebar: () -> Unit,
    genderFilter: GenderFilter,
    onSelectGenderFilter: (GenderFilter) -> Unit,
    currentSourceFilter: MediaSource?,
    onClearSourceFilter: () -> Unit,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Sidebar Menu Trigger
        IconButton(
            onClick = onToggleSidebar,
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.5f))
                .testTag("open_sidebar_btn")
        ) {
            Icon(Icons.Default.Menu, contentDescription = "Sidebar", tint = Color.White)
        }

        // Active filter badge or app title
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(Color.Black.copy(alpha = 0.6f))
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            if (currentSourceFilter != null) {
                Text(
                    text = currentSourceFilter.displayName,
                    color = YiffyPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    text = "✕",
                    color = Color.LightGray,
                    fontSize = 12.sp,
                    modifier = Modifier.clickable { onClearSourceFilter() }
                )
            } else {
                Text(
                    text = "Yiffy Feed",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        }

        // Controls: Refresh + Gender Filter Badge
        Row(verticalAlignment = Alignment.CenterVertically) {
            // Live Refresh button
            IconButton(
                onClick = onRefresh,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.5f))
                    .testTag("feed_refresh_btn")
            ) {
                Text("⟳", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(Modifier.width(8.dp))

            // Multi-Option Gender Filter Button (Cycles: Any -> Female Only -> Male Only -> Trans/Herm -> Any)
            val nextGender = when (genderFilter) {
                GenderFilter.ANY -> GenderFilter.FEMALE_ONLY
                GenderFilter.FEMALE_ONLY -> GenderFilter.MALE_ONLY
                GenderFilter.MALE_ONLY -> GenderFilter.TRANS_HERM
                GenderFilter.TRANS_HERM -> GenderFilter.ANY
            }

            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(genderFilter.badgeColorHex),
                modifier = Modifier
                    .clickable { onSelectGenderFilter(nextGender) }
                    .testTag("gender_filter_toggle_btn")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = genderFilter.label,
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

fun formatCount(count: Int): String {
    return when {
        count >= 1_000_000 -> String.format("%.1fM", count / 1_000_000.0)
        count >= 1_000 -> String.format("%.1fK", count / 1_000.0)
        else -> count.toString()
    }
}
