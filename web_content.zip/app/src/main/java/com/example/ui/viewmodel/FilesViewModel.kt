package com.example.ui.viewmodel

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.MainActivity
import com.example.R
import com.example.data.local.FavoriteEntity
import com.example.data.local.FileMetadataDao
import com.example.data.local.HiddenPathEntity
import com.example.data.local.SettingsDataStore
import com.example.data.local.ShortcutEntity
import com.example.data.local.TrashEntity
import com.example.data.local.UserSettingsState
import com.example.data.model.ApkPackageMetadata
import com.example.data.model.BreadcrumbSegment
import com.example.data.model.BrowserViewMode
import com.example.data.model.ConflictAction
import com.example.data.model.ConflictPrompt
import com.example.data.model.FileCategory
import com.example.data.model.FileKind
import com.example.data.model.FileNode
import com.example.data.model.SortField
import com.example.data.model.StorageAnalysisReport
import com.example.data.model.StorageVolumeInfo
import com.example.data.model.TransferProgress
import com.example.data.storage.DeviceAndSafStorageAdapter
import com.example.data.storage.FileTypeInspector
import com.example.data.storage.UsbOtgMonitor
import com.example.ui.theme.AccentPreset
import com.example.ui.theme.AnimationMode
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

enum class AppDestination {
    ONBOARDING,
    HOME,
    BROWSER,
    CATEGORY_LIST,
    FAVORITES,
    TRASH,
    ANALYZE_STORAGE,
    SEARCH,
    SETTINGS,
    PERMISSIONS,
    CAMERA_CAPTURE,
    IMAGE_EDITOR,
    VIDEO_EDITOR,
    PREVIEWER
}

data class ClipboardState(
    val sourcePaths: List<String>,
    val isMove: Boolean
)

data class SearchFilters(
    val query: String = "",
    val category: FileCategory? = null,
    val minSizeBytes: Long? = null,
    val maxSizeBytes: Long? = null,
    val modifiedAfterEpochMs: Long? = null
)

class FilesViewModel(
    private val appContext: Context,
    val storageAdapter: DeviceAndSafStorageAdapter,
    private val dao: FileMetadataDao,
    private val settingsDataStore: SettingsDataStore,
    private val usbMonitor: UsbOtgMonitor
) : ViewModel() {

    val settingsState: StateFlow<UserSettingsState> = settingsDataStore.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UserSettingsState())

    val trashItems: StateFlow<List<TrashEntity>> = dao.observeTrash()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val shortcutItems: StateFlow<List<ShortcutEntity>> = dao.observeShortcuts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _navStack = MutableStateFlow(listOf(AppDestination.HOME))
    val currentDestination: StateFlow<AppDestination> = MutableStateFlow(AppDestination.HOME)

    private val _volumes = MutableStateFlow<List<StorageVolumeInfo>>(emptyList())
    val volumes: StateFlow<List<StorageVolumeInfo>> = _volumes.asStateFlow()

    private val _recentFiles = MutableStateFlow<List<FileNode>>(emptyList())
    val recentFiles: StateFlow<List<FileNode>> = _recentFiles.asStateFlow()

    private val _categorySummary = MutableStateFlow<Pair<Map<FileCategory, Int>, Map<FileCategory, Long>>>(
        emptyMap<FileCategory, Int>() to emptyMap()
    )
    val categorySummary = _categorySummary.asStateFlow()

    private val _currentPath = MutableStateFlow(storageAdapter.workspaceRootPath)
    val currentPath: StateFlow<String> = _currentPath.asStateFlow()

    private val _folderHistory = MutableStateFlow<List<String>>(emptyList())

    private val _breadcrumbs = MutableStateFlow<List<BreadcrumbSegment>>(emptyList())
    val breadcrumbs: StateFlow<List<BreadcrumbSegment>> = _breadcrumbs.asStateFlow()

    private val _browserItems = MutableStateFlow<List<FileNode>>(emptyList())
    val browserItems: StateFlow<List<FileNode>> = _browserItems.asStateFlow()

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    private val _selectedPaths = MutableStateFlow<Set<String>>(emptySet())
    val selectedPaths: StateFlow<Set<String>> = _selectedPaths.asStateFlow()

    private val _clipboard = MutableStateFlow<ClipboardState?>(null)
    val clipboard: StateFlow<ClipboardState?> = _clipboard.asStateFlow()

    private val _transferProgress = MutableStateFlow<TransferProgress?>(null)
    val transferProgress: StateFlow<TransferProgress?> = _transferProgress.asStateFlow()

    private val _activeConflict = MutableStateFlow<ConflictPrompt?>(null)
    val activeConflict: StateFlow<ConflictPrompt?> = _activeConflict.asStateFlow()
    private var conflictDeferred: CompletableDeferred<ConflictAction>? = null
    private var applyAllConflictAction: ConflictAction? = null
    private val cancelRequested = AtomicBoolean(false)

    private val _activeCategory = MutableStateFlow<FileCategory?>(null)
    val activeCategory: StateFlow<FileCategory?> = _activeCategory.asStateFlow()

    private val _categoryFiles = MutableStateFlow<List<FileNode>>(emptyList())
    val categoryFiles: StateFlow<List<FileNode>> = _categoryFiles.asStateFlow()

    private val _favoriteNodes = MutableStateFlow<List<FileNode>>(emptyList())
    val favoriteNodes: StateFlow<List<FileNode>> = _favoriteNodes.asStateFlow()

    private val _analysisReport = MutableStateFlow<StorageAnalysisReport?>(null)
    val analysisReport: StateFlow<StorageAnalysisReport?> = _analysisReport.asStateFlow()

    private val _searchFilters = MutableStateFlow(SearchFilters())
    val searchFilters: StateFlow<SearchFilters> = _searchFilters.asStateFlow()

    private val _searchResults = MutableStateFlow<List<FileNode>>(emptyList())
    val searchResults: StateFlow<List<FileNode>> = _searchResults.asStateFlow()

    private val _activePreviewNode = MutableStateFlow<FileNode?>(null)
    val activePreviewNode: StateFlow<FileNode?> = _activePreviewNode.asStateFlow()

    private val _inspectedApkMetadata = MutableStateFlow<ApkPackageMetadata?>(null)
    val inspectedApkMetadata: StateFlow<ApkPackageMetadata?> = _inspectedApkMetadata.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    init {
        viewModelScope.launch {
            settingsDataStore.settingsFlow.collect { s ->
                if (s.autoEmptyTrash30Days) {
                    storageAdapter.purgeExpiredTrash(30)
                }
                refreshBrowser(showSkeleton = false)
                refreshHomeDashboard()
            }
        }
        viewModelScope.launch {
            usbMonitor.observeUsbEvents().collect {
                refreshHomeDashboard()
            }
        }
    }

    fun navigateTo(dest: AppDestination) {
        _selectedPaths.value = emptySet()
        val stack = _navStack.value.toMutableList()
        if (stack.lastOrNull() != dest) {
            stack.add(dest)
            _navStack.value = stack
            (currentDestination as MutableStateFlow).value = dest
        }
        when (dest) {
            AppDestination.ANALYZE_STORAGE -> loadStorageAnalysis()
            AppDestination.FAVORITES -> loadFavorites()
            AppDestination.SEARCH -> runLocalSearch(_searchFilters.value)
            AppDestination.HOME -> refreshHomeDashboard()
            else -> {}
        }
    }

    fun navigateBack(): Boolean {
        if (_selectedPaths.value.isNotEmpty()) {
            _selectedPaths.value = emptySet()
            return true
        }
        if (currentDestination.value == AppDestination.BROWSER && _folderHistory.value.isNotEmpty()) {
            val prev = _folderHistory.value.last()
            _folderHistory.value = _folderHistory.value.dropLast(1)
            openFolder(prev, pushHistory = false)
            return true
        }
        val stack = _navStack.value.toMutableList()
        if (stack.size > 1) {
            stack.removeAt(stack.lastIndex)
            _navStack.value = stack
            val top = stack.last()
            (currentDestination as MutableStateFlow).value = top
            if (top == AppDestination.HOME) refreshHomeDashboard()
            return true
        }
        return false
    }

    fun completeOnboarding() {
        viewModelScope.launch {
            settingsDataStore.setOnboardingCompleted(true)
            _navStack.value = listOf(AppDestination.HOME)
            (currentDestination as MutableStateFlow).value = AppDestination.HOME
            refreshHomeDashboard()
        }
    }

    fun refreshHomeDashboard() {
        viewModelScope.launch {
            _volumes.value = storageAdapter.listRoots()
            _recentFiles.value = storageAdapter.queryRecentFiles(18)
            val report = storageAdapter.analyzeStorage()
            _categorySummary.value = report.categoryCounts to report.categoryBreakdown
        }
    }

    fun openVolume(volume: StorageVolumeInfo) {
        if (volume.isUnsupportedFormat) {
            postMessage(volume.unsupportedExplanation ?: "Unsupported filesystem")
            return
        }
        if (volume.rootPath.startsWith("usb://")) {
            postMessage("Grant SAF folder access to browse ${volume.title}")
            return
        }
        _folderHistory.value = emptyList()
        openFolder(volume.rootPath, pushHistory = false)
        navigateTo(AppDestination.BROWSER)
    }

    fun openFolder(path: String, pushHistory: Boolean = true) {
        viewModelScope.launch {
            if (pushHistory && _currentPath.value != path && currentDestination.value == AppDestination.BROWSER) {
                _folderHistory.value = _folderHistory.value + _currentPath.value
            }
            _currentPath.value = path
            _selectedPaths.value = emptySet()
            if (currentDestination.value != AppDestination.BROWSER) {
                navigateTo(AppDestination.BROWSER)
            }
            refreshBrowser(showSkeleton = true)
        }
    }

    fun refreshBrowser(showSkeleton: Boolean = true) {
        viewModelScope.launch {
            if (showSkeleton) _isRefreshing.value = true
            val settings = settingsState.value
            val path = _currentPath.value
            _breadcrumbs.value = storageAdapter.buildBreadcrumbs(path)
            val raw = storageAdapter.list(path, settings.showHiddenFiles)
            _browserItems.value = sortNodes(raw, settings.sortField, settings.sortAscending)
            _isRefreshing.value = false
        }
    }

    fun openCategory(category: FileCategory) {
        viewModelScope.launch {
            _activeCategory.value = category
            val settings = settingsState.value
            val raw = storageAdapter.queryByCategory(category, settings.showHiddenFiles)
            _categoryFiles.value = sortNodes(raw, settings.sortField, settings.sortAscending)
            navigateTo(AppDestination.CATEGORY_LIST)
        }
    }

    fun openFileNode(node: FileNode) {
        if (node.isDirectory) {
            openFolder(node.path, pushHistory = true)
            return
        }
        when (node.kind) {
            FileKind.APK, FileKind.APKS, FileKind.XAPK -> inspectApkNode(node)
            FileKind.EXE, FileKind.MSI -> {
                postMessage("${node.name} is a Windows binary (${node.kind.displayLabel}) and cannot run natively on Android.")
                _activePreviewNode.value = node
                navigateTo(AppDestination.PREVIEWER)
            }
            FileKind.ZIP -> {
                _activePreviewNode.value = node
                navigateTo(AppDestination.PREVIEWER)
            }
            else -> {
                _activePreviewNode.value = node
                navigateTo(AppDestination.PREVIEWER)
            }
        }
    }

    fun openImageEditor(node: FileNode) {
        _activePreviewNode.value = node
        navigateTo(AppDestination.IMAGE_EDITOR)
    }

    fun openVideoEditor(node: FileNode) {
        _activePreviewNode.value = node
        navigateTo(AppDestination.VIDEO_EDITOR)
    }

    fun inspectApkNode(node: FileNode) {
        viewModelScope.launch {
            val localFile = if (node.path.startsWith("file://")) File(node.path.removePrefix("file://")) else null
            val meta = FileTypeInspector.inspectApkArchive(
                context = appContext,
                fileName = node.name,
                sizeBytes = node.sizeBytes,
                localFile = localFile,
                streamProvider = { storageAdapter.openReadStream(node.path) }
            )
            _inspectedApkMetadata.value = meta
        }
    }

    fun dismissApkInspector() {
        _inspectedApkMetadata.value = null
    }

    fun toggleSelection(path: String) {
        val current = _selectedPaths.value.toMutableSet()
        if (path in current) current.remove(path) else current.add(path)
        _selectedPaths.value = current
    }

    fun selectAllInCurrentView(items: List<FileNode>) {
        if (_selectedPaths.value.size == items.size && items.isNotEmpty()) {
            _selectedPaths.value = emptySet()
        } else {
            _selectedPaths.value = items.map { it.path }.toSet()
        }
    }

    fun clearSelection() {
        _selectedPaths.value = emptySet()
    }

    fun createFolder(name: String) {
        viewModelScope.launch {
            runCatching {
                storageAdapter.mkdir(_currentPath.value, name)
            }.onSuccess {
                refreshBrowser(showSkeleton = false)
                refreshHomeDashboard()
                postMessage("Created folder \"$name\"")
            }.onFailure { e ->
                postMessage(e.localizedMessage ?: "Failed to create folder")
            }
        }
    }

    fun createTextNote(fileName: String, content: String) {
        viewModelScope.launch {
            val finalName = if (fileName.contains('.')) fileName else "$fileName.txt"
            runCatching {
                storageAdapter.write(
                    parentPath = _currentPath.value,
                    fileName = finalName,
                    bytes = content.toByteArray(),
                    mimeType = "text/plain",
                    overwrite = false
                )
            }.onSuccess {
                refreshBrowser(showSkeleton = false)
                refreshHomeDashboard()
                postMessage("Saved $finalName")
            }.onFailure { e ->
                postMessage(e.localizedMessage ?: "Could not save file")
            }
        }
    }

    fun renameSingle(path: String, newName: String) {
        viewModelScope.launch {
            runCatching {
                storageAdapter.rename(path, newName)
            }.onSuccess {
                _selectedPaths.value = emptySet()
                refreshBrowser(showSkeleton = false)
                refreshHomeDashboard()
                postMessage("Renamed to \"$newName\"")
            }.onFailure { e ->
                postMessage(e.localizedMessage ?: "Rename failed")
            }
        }
    }

    fun deleteSelectedToTrash(paths: List<String> = _selectedPaths.value.toList()) {
        viewModelScope.launch {
            val count = storageAdapter.deleteToTrash(paths)
            _selectedPaths.value = emptySet()
            refreshBrowser(showSkeleton = false)
            refreshHomeDashboard()
            if (currentDestination.value == AppDestination.ANALYZE_STORAGE) loadStorageAnalysis()
            if (currentDestination.value == AppDestination.CATEGORY_LIST) {
                _activeCategory.value?.let { openCategory(it) }
            }
            postMessage("Moved $count item(s) to Trash")
        }
    }

    fun restoreFromTrash(entity: TrashEntity) {
        viewModelScope.launch {
            val ok = storageAdapter.restoreTrashItem(entity)
            refreshHomeDashboard()
            refreshBrowser(showSkeleton = false)
            postMessage(if (ok) "Restored ${entity.originalName}" else "Could not restore ${entity.originalName}")
        }
    }

    fun emptyTrashAll() {
        viewModelScope.launch {
            storageAdapter.emptyTrash()
            refreshHomeDashboard()
            postMessage("Trash emptied")
        }
    }

    fun stageCopy(paths: List<String> = _selectedPaths.value.toList()) {
        if (paths.isEmpty()) return
        _clipboard.value = ClipboardState(paths, isMove = false)
        _selectedPaths.value = emptySet()
        postMessage("${paths.size} item(s) ready to copy — navigate to destination and tap Paste here")
    }

    fun stageMove(paths: List<String> = _selectedPaths.value.toList()) {
        if (paths.isEmpty()) return
        _clipboard.value = ClipboardState(paths, isMove = true)
        _selectedPaths.value = emptySet()
        postMessage("${paths.size} item(s) ready to move — navigate to destination and tap Paste here")
    }

    fun cancelClipboard() {
        _clipboard.value = null
    }

    fun pasteClipboardHere() {
        val clip = _clipboard.value ?: return
        val destDir = _currentPath.value
        viewModelScope.launch {
            cancelRequested.set(false)
            applyAllConflictAction = null
            _clipboard.value = null
            val onConflictHandler: suspend (ConflictPrompt) -> ConflictAction = { prompt ->
                val sticky = applyAllConflictAction
                if (sticky != null) {
                    sticky
                } else {
                    val def = CompletableDeferred<ConflictAction>()
                    conflictDeferred = def
                    _activeConflict.value = prompt
                    val chosen = def.await()
                    _activeConflict.value = null
                    chosen
                }
            }

            runCatching {
                if (clip.isMove) {
                    storageAdapter.move(
                        sourcePaths = clip.sourcePaths,
                        destinationDirPath = destDir,
                        onProgress = { _transferProgress.value = it },
                        onConflict = onConflictHandler,
                        isCancelled = { cancelRequested.get() }
                    )
                } else {
                    storageAdapter.copy(
                        sourcePaths = clip.sourcePaths,
                        destinationDirPath = destDir,
                        onProgress = { _transferProgress.value = it },
                        onConflict = onConflictHandler,
                        isCancelled = { cancelRequested.get() }
                    )
                }
            }.onSuccess { count ->
                _transferProgress.value = null
                refreshBrowser(showSkeleton = false)
                refreshHomeDashboard()
                postMessage(if (cancelRequested.get()) "Transfer cancelled ($count completed)" else "Completed transfer of $count item(s)")
            }.onFailure { e ->
                _transferProgress.value = null
                postMessage(e.localizedMessage ?: "Transfer failed")
            }
        }
    }

    fun resolveConflict(action: ConflictAction, applyToAll: Boolean) {
        if (applyToAll) applyAllConflictAction = action
        conflictDeferred?.complete(action)
    }

    fun cancelActiveTransfer() {
        cancelRequested.set(true)
        conflictDeferred?.complete(ConflictAction.SKIP)
    }

    fun compressSelectedToZip(zipName: String) {
        val paths = _selectedPaths.value.toList()
        if (paths.isEmpty()) return
        viewModelScope.launch {
            runCatching {
                storageAdapter.compressToZip(
                    sourcePaths = paths,
                    destinationDirPath = _currentPath.value,
                    zipFileName = zipName,
                    onProgress = { _transferProgress.value = it }
                )
            }.onSuccess { created ->
                _transferProgress.value = null
                _selectedPaths.value = emptySet()
                refreshBrowser(showSkeleton = false)
                refreshHomeDashboard()
                postMessage("Created ${created.name}")
            }.onFailure { e ->
                _transferProgress.value = null
                postMessage(e.localizedMessage ?: "ZIP compression failed")
            }
        }
    }

    fun extractZipArchive(zipNode: FileNode) {
        val dest = zipNode.parentPath ?: _currentPath.value
        viewModelScope.launch {
            runCatching {
                storageAdapter.extractZip(
                    zipPath = zipNode.path,
                    destinationDirPath = dest,
                    onProgress = { _transferProgress.value = it }
                )
            }.onSuccess { folder ->
                _transferProgress.value = null
                _selectedPaths.value = emptySet()
                refreshBrowser(showSkeleton = false)
                refreshHomeDashboard()
                postMessage("Extracted to ${folder.name}")
            }.onFailure { e ->
                _transferProgress.value = null
                postMessage(e.localizedMessage ?: "ZIP extraction failed")
            }
        }
    }

    fun toggleFavorite(node: FileNode) {
        viewModelScope.launch {
            if (node.isFavorite) {
                dao.removeFavorite(node.path)
                postMessage("Removed from Favorites")
            } else {
                dao.insertFavorite(
                    FavoriteEntity(
                        path = node.path,
                        name = node.name,
                        isDirectory = node.isDirectory,
                        addedAtEpochMs = System.currentTimeMillis()
                    )
                )
                postMessage("Added to Favorites")
            }
            _selectedPaths.value = emptySet()
            refreshBrowser(showSkeleton = false)
            loadFavorites()
        }
    }

    fun toggleHiddenStatus(node: FileNode) {
        viewModelScope.launch {
            if (node.isHidden && !node.name.startsWith(".")) {
                dao.unmarkHidden(node.path)
                postMessage("Unhid ${node.name}")
            } else {
                dao.markHidden(HiddenPathEntity(node.path, System.currentTimeMillis()))
                postMessage("Hid ${node.name}")
            }
            _selectedPaths.value = emptySet()
            refreshBrowser(showSkeleton = false)
        }
    }

    fun addShortcutForNode(node: FileNode) {
        viewModelScope.launch {
            dao.insertShortcut(
                ShortcutEntity(
                    path = node.path,
                    label = node.name,
                    isDirectory = node.isDirectory,
                    createdAtEpochMs = System.currentTimeMillis()
                )
            )
            // Also request launcher pin shortcut if supported by Android Home Launcher
            runCatching {
                if (ShortcutManagerCompat.isRequestPinShortcutSupported(appContext)) {
                    val launchIntent = Intent(appContext, MainActivity::class.java).apply {
                        action = Intent.ACTION_VIEW
                        putExtra("SHORTCUT_PATH", node.path)
                    }
                    val shortcut = ShortcutInfoCompat.Builder(appContext, "pin_${node.path.hashCode()}")
                        .setShortLabel(node.name.take(18))
                        .setLongLabel(node.name)
                        .setIcon(IconCompat.createWithResource(appContext, R.mipmap.ic_launcher))
                        .setIntent(launchIntent)
                        .build()
                    ShortcutManagerCompat.requestPinShortcut(appContext, shortcut, null)
                }
            }
            _selectedPaths.value = emptySet()
            postMessage("Added shortcut for ${node.name}")
        }
    }

    fun shareNodes(context: Context, paths: List<String>) {
        viewModelScope.launch {
            val nodes = paths.mapNotNull { storageAdapter.stat(it) }.filter { !it.isDirectory }
            if (nodes.isEmpty()) {
                postMessage("Select at least one file to share")
                return@launch
            }
            val uris = ArrayList<Uri>()
            for (n in nodes) {
                if (n.path.startsWith("file://")) {
                    val f = File(n.path.removePrefix("file://"))
                    if (f.exists()) {
                        val u = FileProvider.getUriForFile(
                            context,
                            "${context.packageName}.fileprovider",
                            f
                        )
                        uris.add(u)
                    }
                } else if (n.contentUriString != null) {
                    uris.add(Uri.parse(n.contentUriString))
                }
            }
            if (uris.isEmpty()) return@launch
            val sendIntent = if (uris.size == 1) {
                Intent(Intent.ACTION_SEND).apply {
                    type = nodes.first().mimeType
                    putExtra(Intent.EXTRA_STREAM, uris.first())
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            } else {
                Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                    type = "*/*"
                    putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            }
            context.startActivity(Intent.createChooser(sendIntent, "Share via"))
            _selectedPaths.value = emptySet()
        }
    }

    fun registerGrantedSafTree(uri: Uri, isCloud: Boolean = false) {
        viewModelScope.launch {
            runCatching {
                val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                appContext.contentResolver.takePersistableUriPermission(uri, flags)
            }
            val vol = storageAdapter.registerSafTree(uri, isCloud)
            refreshHomeDashboard()
            postMessage("Mounted \"${vol.title}\"")
        }
    }

    fun ejectOrUnmountVolume(volume: StorageVolumeInfo) {
        viewModelScope.launch {
            if (volume.type == com.example.data.model.StorageRootType.USB_OTG) {
                usbMonitor.safeEject(volume.id)
                refreshHomeDashboard()
                postMessage("Safely ejected ${volume.title}")
            } else if (volume.id.startsWith("saf_")) {
                storageAdapter.removeSafRoot(volume.id)
                refreshHomeDashboard()
                postMessage("Unmounted ${volume.title}")
            }
        }
    }

    fun loadStorageAnalysis() {
        viewModelScope.launch {
            _isRefreshing.value = true
            _analysisReport.value = storageAdapter.analyzeStorage()
            _isRefreshing.value = false
        }
    }

    private fun loadFavorites() {
        viewModelScope.launch {
            val favs = dao.observeFavorites().stateIn(viewModelScope).value
            _favoriteNodes.value = favs.mapNotNull { storageAdapter.stat(it.path) }
        }
    }

    fun updateSearchFilters(filters: SearchFilters) {
        _searchFilters.value = filters
        runLocalSearch(filters)
    }

    fun runLocalSearch(filters: SearchFilters) {
        viewModelScope.launch {
            val all = storageAdapter.collectAllAccessibleFiles(settingsState.value.showHiddenFiles)
            val qLower = filters.query.trim().lowercase()
            val filtered = all.filter { node ->
                val matchesQuery = qLower.isEmpty() ||
                    node.name.lowercase().contains(qLower) ||
                    node.extension.lowercase().contains(qLower) ||
                    node.kind.displayLabel.lowercase().contains(qLower)
                val matchesCat = filters.category == null || (!node.isDirectory && when (filters.category) {
                    FileCategory.IMAGES -> node.kind == FileKind.IMAGE
                    FileCategory.AUDIO -> node.kind == FileKind.AUDIO
                    FileCategory.VIDEOS -> node.kind == FileKind.VIDEO
                    FileCategory.DOCUMENTS -> node.kind in setOf(FileKind.PDF, FileKind.WORD, FileKind.EXCEL, FileKind.POWERPOINT, FileKind.TEXT)
                    FileCategory.DOWNLOADS -> node.path.contains("/Download", ignoreCase = true)
                    FileCategory.INSTALLATION -> node.kind in setOf(FileKind.APK, FileKind.APKS, FileKind.XAPK, FileKind.EXE, FileKind.MSI)
                    FileCategory.COMPRESSED -> node.kind in setOf(FileKind.ZIP, FileKind.ARCHIVE)
                    FileCategory.APPS -> node.kind in setOf(FileKind.APK, FileKind.APKS, FileKind.XAPK)
                })
                val matchesMin = filters.minSizeBytes == null || node.sizeBytes >= filters.minSizeBytes
                val matchesMax = filters.maxSizeBytes == null || node.sizeBytes <= filters.maxSizeBytes
                val matchesDate = filters.modifiedAfterEpochMs == null || node.lastModified >= filters.modifiedAfterEpochMs
                matchesQuery && matchesCat && matchesMin && matchesMax && matchesDate
            }
            _searchResults.value = sortNodes(filtered, settingsState.value.sortField, settingsState.value.sortAscending)
        }
    }

    fun applySmartAiFilter(
        keywords: List<String>,
        extensions: List<String>,
        categoryName: String?,
        minBytes: Long?,
        maxBytes: Long?,
        modifiedAfterMs: Long?
    ) {
        viewModelScope.launch {
            val all = storageAdapter.collectAllAccessibleFiles(settingsState.value.showHiddenFiles)
            val extSet = extensions.map { it.lowercase().removePrefix(".") }.toSet()
            val kwLower = keywords.map { it.lowercase() }.filter { it.isNotBlank() }
            val resolvedCat = categoryName?.let { name ->
                FileCategory.entries.find { it.name.equals(name, ignoreCase = true) }
            }

            val results = all.filter { node ->
                val kwOk = kwLower.isEmpty() || kwLower.any { kw ->
                    node.name.lowercase().contains(kw) || node.path.lowercase().contains(kw)
                }
                val extOk = extSet.isEmpty() || node.extension.lowercase() in extSet
                val catOk = resolvedCat == null || (!node.isDirectory && when (resolvedCat) {
                    FileCategory.IMAGES -> node.kind == FileKind.IMAGE
                    FileCategory.AUDIO -> node.kind == FileKind.AUDIO
                    FileCategory.VIDEOS -> node.kind == FileKind.VIDEO
                    FileCategory.DOCUMENTS -> node.kind in setOf(FileKind.PDF, FileKind.WORD, FileKind.EXCEL, FileKind.POWERPOINT, FileKind.TEXT)
                    FileCategory.DOWNLOADS -> node.path.contains("/Download", ignoreCase = true)
                    FileCategory.INSTALLATION -> node.kind in setOf(FileKind.APK, FileKind.APKS, FileKind.XAPK, FileKind.EXE, FileKind.MSI)
                    FileCategory.COMPRESSED -> node.kind in setOf(FileKind.ZIP, FileKind.ARCHIVE)
                    FileCategory.APPS -> node.kind in setOf(FileKind.APK, FileKind.APKS, FileKind.XAPK)
                })
                val minOk = minBytes == null || minBytes <= 0L || node.sizeBytes >= minBytes
                val maxOk = maxBytes == null || maxBytes <= 0L || node.sizeBytes <= maxBytes
                val dateOk = modifiedAfterMs == null || modifiedAfterMs <= 0L || node.lastModified >= modifiedAfterMs
                kwOk && extOk && catOk && minOk && maxOk && dateOk
            }
            _searchResults.value = sortNodes(results, settingsState.value.sortField, settingsState.value.sortAscending)
        }
    }

    // Settings updates
    fun setThemeMode(mode: ThemeMode) = viewModelScope.launch { settingsDataStore.setThemeMode(mode) }
    fun setAmoledBlack(enabled: Boolean) = viewModelScope.launch { settingsDataStore.setAmoledBlack(enabled) }
    fun setAccentPreset(preset: AccentPreset) = viewModelScope.launch { settingsDataStore.setAccentPreset(preset) }
    fun setDynamicSeed(argb: Int) = viewModelScope.launch { settingsDataStore.setDynamicSeedArgb(argb) }
    fun setAnimationMode(mode: AnimationMode) = viewModelScope.launch { settingsDataStore.setAnimationMode(mode) }
    fun setViewMode(mode: BrowserViewMode) = viewModelScope.launch { settingsDataStore.setViewMode(mode) }
    fun setSort(field: SortField, ascending: Boolean) = viewModelScope.launch { settingsDataStore.setSort(field, ascending) }
    fun setShowHidden(show: Boolean) = viewModelScope.launch { settingsDataStore.setShowHiddenFiles(show) }
    fun setShowExtensions(show: Boolean) = viewModelScope.launch { settingsDataStore.setShowFileExtensions(show) }
    fun setAutoEmptyTrash(enabled: Boolean) = viewModelScope.launch { settingsDataStore.setAutoEmptyTrash(enabled) }
    fun setLanguage(label: String) = viewModelScope.launch { settingsDataStore.setLanguage(label) }

    fun postMessage(msg: String?) {
        _statusMessage.value = msg
    }

    private fun sortNodes(nodes: List<FileNode>, field: SortField, ascending: Boolean): List<FileNode> {
        val comparator = Comparator<FileNode> { a, b ->
            // Folders always precede files in Samsung One UI My Files
            if (a.isDirectory != b.isDirectory) {
                return@Comparator if (a.isDirectory) -1 else 1
            }
            val rawCmp = when (field) {
                SortField.NAME -> a.name.compareTo(b.name, ignoreCase = true)
                SortField.DATE -> a.lastModified.compareTo(b.lastModified)
                SortField.TYPE -> a.extension.compareTo(b.extension, ignoreCase = true)
                SortField.SIZE -> a.sizeBytes.compareTo(b.sizeBytes)
            }
            if (ascending) rawCmp else -rawCmp
        }
        return nodes.sortedWith(comparator)
    }

    companion object {
        fun provideFactory(
            appContext: Context,
            storageAdapter: DeviceAndSafStorageAdapter,
            dao: FileMetadataDao,
            settingsDataStore: SettingsDataStore,
            usbMonitor: UsbOtgMonitor
        ): ViewModelProvider.Factory = viewModelFactory {
            initializer {
                FilesViewModel(appContext, storageAdapter, dao, settingsDataStore, usbMonitor)
            }
        }
    }
}
