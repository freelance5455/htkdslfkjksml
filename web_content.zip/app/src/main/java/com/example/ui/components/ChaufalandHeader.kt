package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.MinecraftDirtDark
import com.example.ui.theme.MinecraftGrassGreen

@Composable
fun ChaufalandHeader(
    isOnline: Boolean,
    statusText: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .testTag("chaufaland_header")
    ) {
        // Fondo con Banner Panorámico de Minecraft
        Image(
            painter = painterResource(id = R.drawable.minecraft_dirt_banner_1791826107618),
            contentDescription = "Fondo de Minecraft Dirt",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
        )

        // Overlay sombreado tipo viñeta
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0x99000000),
                            Color(0xD91B130E)
                        )
                    )
                )
        )

        // Borde superior de césped (Grass Edge)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(5.dp)
                .background(MinecraftGrassGreen)
        )

        // Contenido centrado
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 14.dp, horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // LOGO 3D: CHAUFALAND
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.testTag("chaufaland_logo_title")
            ) {
                // CHAUFA en Dorado 3D
                Text(
                    text = "CHAUFA",
                    style = TextStyle(
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.SansSerif,
                        color = Color(0xFFFFB703),
                        shadow = Shadow(
                            color = Color(0xFF000000),
                            offset = Offset(4f, 6f),
                            blurRadius = 4f
                        )
                    )
                )

                // L en Rojo Minecraft
                Text(
                    text = "L",
                    style = TextStyle(
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.SansSerif,
                        color = Color(0xFFE63946),
                        shadow = Shadow(
                            color = Color(0xFF000000),
                            offset = Offset(4f, 6f),
                            blurRadius = 4f
                        )
                    )
                )

                // A en Blanco Minecraft
                Text(
                    text = "A",
                    style = TextStyle(
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.SansSerif,
                        color = Color(0xFFFFFFFF),
                        shadow = Shadow(
                            color = Color(0xFF000000),
                            offset = Offset(4f, 6f),
                            blurRadius = 4f
                        )
                    )
                )

                // ND en Rojo Minecraft
                Text(
                    text = "ND",
                    style = TextStyle(
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.SansSerif,
                        color = Color(0xFFE63946),
                        shadow = Shadow(
                            color = Color(0xFF000000),
                            offset = Offset(4f, 6f),
                            blurRadius = 4f
                        )
                    )
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Subtítulo con estado de servidor
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xCC000000))
                    .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(20.dp))
                    .padding(horizontal = 12.dp, vertical = 4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (isOnline) Color(0xFF2ECC71) else Color(0xFFE74C3C))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Servidor Oficial Bedrock & Java • $statusText",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White
                    )
                }
            }
        }
    }
}
