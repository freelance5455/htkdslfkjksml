package com.example.ui.components

import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.DashboardCustomize
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.NavyDeep
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.NavySurface
import com.example.ui.viewmodel.Screen

@Composable
fun AlQaedBottomBar(
    currentScreen: Screen,
    onTabSelected: (Screen) -> Unit
) {
    NavigationBar(
        containerColor = NavyPrimary,
        tonalElevation = 8.dp,
        modifier = Modifier
            .navigationBarsPadding()
            .testTag("bottom_nav_bar")
    ) {
        // Home Tab
        val isHome = currentScreen is Screen.Home
        NavigationBarItem(
            selected = isHome,
            onClick = { onTabSelected(Screen.Home) },
            icon = {
                Icon(
                    imageVector = Icons.Default.Home,
                    contentDescription = "الرئيسية"
                )
            },
            label = {
                Text(
                    text = "الرئيسية",
                    fontSize = 12.sp,
                    fontWeight = if (isHome) FontWeight.Bold else FontWeight.Normal
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = NavyDeep,
                selectedTextColor = GoldAccent,
                indicatorColor = GoldAccent,
                unselectedIconColor = Color.White.copy(alpha = 0.6f),
                unselectedTextColor = Color.White.copy(alpha = 0.6f)
            ),
            modifier = Modifier.testTag("nav_tab_home")
        )

        // Courses Tab
        val isCourses = currentScreen is Screen.Courses || currentScreen is Screen.CourseDetail || currentScreen is Screen.LessonDetail
        NavigationBarItem(
            selected = isCourses,
            onClick = { onTabSelected(Screen.Courses) },
            icon = {
                Icon(
                    imageVector = Icons.Default.MenuBook,
                    contentDescription = "الكورسات"
                )
            },
            label = {
                Text(
                    text = "الكورسات",
                    fontSize = 12.sp,
                    fontWeight = if (isCourses) FontWeight.Bold else FontWeight.Normal
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = NavyDeep,
                selectedTextColor = GoldAccent,
                indicatorColor = GoldAccent,
                unselectedIconColor = Color.White.copy(alpha = 0.6f),
                unselectedTextColor = Color.White.copy(alpha = 0.6f)
            ),
            modifier = Modifier.testTag("nav_tab_courses")
        )

        // Student Dashboard Tab
        val isStudent = currentScreen is Screen.StudentDashboard
        NavigationBarItem(
            selected = isStudent,
            onClick = { onTabSelected(Screen.StudentDashboard) },
            icon = {
                Icon(
                    imageVector = Icons.Default.AccountCircle,
                    contentDescription = "لوحة الطالب"
                )
            },
            label = {
                Text(
                    text = "لوحة الطالب",
                    fontSize = 12.sp,
                    fontWeight = if (isStudent) FontWeight.Bold else FontWeight.Normal
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = NavyDeep,
                selectedTextColor = GoldAccent,
                indicatorColor = GoldAccent,
                unselectedIconColor = Color.White.copy(alpha = 0.6f),
                unselectedTextColor = Color.White.copy(alpha = 0.6f)
            ),
            modifier = Modifier.testTag("nav_tab_student")
        )

        // Admin Tab
        val isAdmin = currentScreen is Screen.AdminDashboard
        NavigationBarItem(
            selected = isAdmin,
            onClick = { onTabSelected(Screen.AdminDashboard) },
            icon = {
                Icon(
                    imageVector = Icons.Default.DashboardCustomize,
                    contentDescription = "لوحة الإدارة"
                )
            },
            label = {
                Text(
                    text = "لوحة الإدارة",
                    fontSize = 12.sp,
                    fontWeight = if (isAdmin) FontWeight.Bold else FontWeight.Normal
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = NavyDeep,
                selectedTextColor = GoldAccent,
                indicatorColor = GoldAccent,
                unselectedIconColor = Color.White.copy(alpha = 0.6f),
                unselectedTextColor = Color.White.copy(alpha = 0.6f)
            ),
            modifier = Modifier.testTag("nav_tab_admin")
        )
    }
}
