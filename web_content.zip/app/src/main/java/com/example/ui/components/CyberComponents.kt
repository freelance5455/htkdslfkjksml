package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.ThreatSeverity
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonBlue
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun CyberTopBar(
    currentLanguage: AppLanguage,
    onToggleLanguage: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = CyberSurface,
        modifier = modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                brush = Brush.horizontalGradient(listOf(NeonCyan.copy(alpha = 0.4f), NeonPurple.copy(alpha = 0.4f))),
                shape = RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp)
            ),
        shape = RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(listOf(NeonCyan.copy(alpha = 0.25f), NeonPurple.copy(alpha = 0.35f)))
                        )
                        .border(1.dp, NeonCyan, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Shield Logo",
                        tint = NeonCyan,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Column {
                    Text(
                        text = "TK LINK SECURITY LAB",
                        color = NeonCyan,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = if (currentLanguage == AppLanguage.EN) "Cyber Defense & Awareness Lab" else "সাইবার নিরাপত্তা সচেতনতা ল্যাব",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }

            // Language Toggle Button
            Surface(
                color = CyberSurfaceElevated,
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, NeonPurple.copy(alpha = 0.6f)),
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .clickable { onToggleLanguage() }
                    .testTag("language_toggle_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Language,
                        contentDescription = "Toggle Language",
                        tint = NeonCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = if (currentLanguage == AppLanguage.EN) "বাংলা" else "English",
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun CyberCard(
    modifier: Modifier = Modifier,
    borderColor: Color = NeonCyan.copy(alpha = 0.3f),
    content: @Composable () -> Unit
) {
    Surface(
        color = CyberSurfaceCard,
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, borderColor),
        shadowElevation = 8.dp,
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            content()
        }
    }
}

@Composable
fun ThreatBadge(
    severity: ThreatSeverity,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, label) = when (severity) {
        ThreatSeverity.CRITICAL -> Triple(NeonRed.copy(alpha = 0.15f), NeonRed, "CRITICAL")
        ThreatSeverity.HIGH -> Triple(NeonRed.copy(alpha = 0.12f), NeonRed, "HIGH RISK")
        ThreatSeverity.MEDIUM -> Triple(NeonAmber.copy(alpha = 0.15f), NeonAmber, "MEDIUM")
        ThreatSeverity.LOW -> Triple(NeonBlue.copy(alpha = 0.15f), NeonBlue, "LOW RISK")
        ThreatSeverity.SAFE -> Triple(NeonGreen.copy(alpha = 0.15f), NeonGreen, "VERIFIED SAFE")
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .border(1.dp, textColor.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = label,
            color = textColor,
            fontSize = 10.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun SafeLabDisclaimer(
    currentLanguage: AppLanguage,
    modifier: Modifier = Modifier
) {
    Surface(
        color = Color(0xFF1B2338),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, NeonAmber.copy(alpha = 0.5f)),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Default.WarningAmber,
                contentDescription = "Safe Simulation Disclaimer",
                tint = NeonAmber,
                modifier = Modifier.size(22.dp)
            )
            Column {
                Text(
                    text = if (currentLanguage == AppLanguage.EN) "SAFE EDUCATIONAL LAB ENVIRONMENT" else "নিরাপদ শিক্ষামূলক ল্যাব পরিবেশ",
                    color = NeonAmber,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = if (currentLanguage == AppLanguage.EN)
                        "All attack simulations are strictly non-functional, safe demonstrations. No passwords are collected, no camera feeds are recorded, and no data leaves this device."
                    else
                        "সমস্ত আক্রমণ সিমুলেশন সম্পূর্ণ শিক্ষামূলক ও অকার্যকর। কোনো পাসওয়ার্ড বা গোপন তথ্য সংরক্ষণ হয় না এবং কোনো ডেটা ডিভাইস ছেড়ে যায় না।",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            }
        }
    }
}

@Composable
fun AnimatedCyberRadar(
    modifier: Modifier = Modifier,
    size: Dp = 100.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "RadarSweep")
    val angle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "RadarAngle"
    )

    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(CyberBackground)
            .border(1.5.dp, NeonCyan.copy(alpha = 0.5f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val center = Offset(this.size.width / 2, this.size.height / 2)
            val radius = this.size.width / 2

            // Grid circles
            drawCircle(color = NeonCyan.copy(alpha = 0.15f), radius = radius * 0.35f, style = Stroke(1.dp.toPx()))
            drawCircle(color = NeonCyan.copy(alpha = 0.25f), radius = radius * 0.70f, style = Stroke(1.dp.toPx()))
            drawCircle(color = NeonCyan.copy(alpha = 0.35f), radius = radius, style = Stroke(1.5.dp.toPx()))

            // Crosshairs
            drawLine(
                color = NeonCyan.copy(alpha = 0.2f),
                start = Offset(center.x, 0f),
                end = Offset(center.x, this.size.height),
                strokeWidth = 1.dp.toPx()
            )
            drawLine(
                color = NeonCyan.copy(alpha = 0.2f),
                start = Offset(0f, center.y),
                end = Offset(this.size.width, center.y),
                strokeWidth = 1.dp.toPx()
            )

            // Sweep line
            val rad = Math.toRadians(angle.toDouble())
            val targetX = center.x + (radius * cos(rad)).toFloat()
            val targetY = center.y + (radius * sin(rad)).toFloat()

            drawLine(
                brush = Brush.linearGradient(
                    colors = listOf(NeonCyan, NeonPurple.copy(alpha = 0.1f)),
                    start = center,
                    end = Offset(targetX, targetY)
                ),
                start = center,
                end = Offset(targetX, targetY),
                strokeWidth = 2.5.dp.toPx()
            )

            // Blip points (simulated target threats)
            drawCircle(
                color = NeonRed,
                radius = 3.dp.toPx(),
                center = Offset(center.x + radius * 0.5f, center.y - radius * 0.3f)
            )
            drawCircle(
                color = NeonAmber,
                radius = 2.5.dp.toPx(),
                center = Offset(center.x - radius * 0.4f, center.y + radius * 0.45f)
            )
        }
    }
}
