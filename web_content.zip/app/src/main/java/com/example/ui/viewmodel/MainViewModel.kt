package com.example.ui.viewmodel

import android.graphics.Bitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.MealEntity
import com.example.data.model.FoodAnalysisResult
import com.example.data.model.MealType
import com.example.data.model.SampleFoodPreset
import com.example.data.repository.FoodRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed interface ScanUiState {
    data object Idle : ScanUiState
    data object Analyzing : ScanUiState
    data class Success(val result: FoodAnalysisResult, val bitmap: Bitmap? = null) : ScanUiState
    data class Error(val message: String) : ScanUiState
}

enum class NavigationTab(val label: String, val englishLabel: String) {
    SCAN("اسکن غذا", "Scan"),
    DIARY("دفترچه کالری", "Diary"),
    CALCULATOR("محاسبه نیاز بدن", "Calculator"),
    EXPORT("سورس و APK", "Source & APK")
}

class MainViewModel(
    private val repository: FoodRepository
) : ViewModel() {

    private val todayDateString: String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private val _currentTab = MutableStateFlow(NavigationTab.SCAN)
    val currentTab: StateFlow<NavigationTab> = _currentTab.asStateFlow()

    private val _scanState = MutableStateFlow<ScanUiState>(ScanUiState.Idle)
    val scanState: StateFlow<ScanUiState> = _scanState.asStateFlow()

    private val _dailyCalorieGoal = MutableStateFlow(2100)
    val dailyCalorieGoal: StateFlow<Int> = _dailyCalorieGoal.asStateFlow()

    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    val samplePresets: List<SampleFoodPreset> = repository.getSamplePresets()

    val todayMeals: StateFlow<List<MealEntity>> = repository.getMealsForDate(todayDateString)
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val todayCalories: StateFlow<Int> = repository.getTotalCaloriesForDate(todayDateString)
        .map { it ?: 0 }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0
        )

    fun selectTab(tab: NavigationTab) {
        _currentTab.value = tab
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    fun analyzeImage(bitmap: Bitmap) {
        viewModelScope.launch {
            _scanState.value = ScanUiState.Analyzing
            try {
                val result = repository.analyzeFood(bitmap = bitmap, presetId = null)
                _scanState.value = ScanUiState.Success(result = result, bitmap = bitmap)
            } catch (e: Exception) {
                _scanState.value = ScanUiState.Error(e.localizedMessage ?: "خطا در پردازش تصویر غذا")
            }
        }
    }

    fun analyzePreset(preset: SampleFoodPreset) {
        viewModelScope.launch {
            _scanState.value = ScanUiState.Analyzing
            try {
                val result = repository.analyzeFood(bitmap = null, presetId = preset.id)
                _scanState.value = ScanUiState.Success(result = result, bitmap = null)
            } catch (e: Exception) {
                _scanState.value = ScanUiState.Error(e.localizedMessage ?: "خطا در دریافت اطلاعات غذا")
            }
        }
    }

    fun saveCurrentAnalysisToDiary(mealType: MealType) {
        val currentState = _scanState.value
        if (currentState is ScanUiState.Success) {
            val result = currentState.result
            val meal = MealEntity(
                name = result.dishName,
                calories = result.calories,
                protein = result.proteinGrams,
                carbs = result.carbsGrams,
                fat = result.fatGrams,
                mealType = mealType.name,
                dateString = todayDateString,
                servingSize = result.servingSize,
                healthScore = result.healthScore,
                advice = result.advice
            )

            viewModelScope.launch {
                repository.saveMeal(meal)
                _userMessage.value = "غذای «${result.dishName}» با موفقیت در دفترچه ثبت شد!"
            }
        }
    }

    fun addManualMeal(
        name: String,
        calories: Int,
        mealType: MealType,
        protein: Float = 0f,
        carbs: Float = 0f,
        fat: Float = 0f
    ) {
        if (name.isBlank() || calories <= 0) return
        val meal = MealEntity(
            name = name,
            calories = calories,
            protein = protein,
            carbs = carbs,
            fat = fat,
            mealType = mealType.name,
            dateString = todayDateString,
            servingSize = "ثبت دستی"
        )
        viewModelScope.launch {
            repository.saveMeal(meal)
            _userMessage.value = "وعده «$name» ذخیره شد."
        }
    }

    fun deleteMeal(meal: MealEntity) {
        viewModelScope.launch {
            repository.deleteMeal(meal)
            _userMessage.value = "وعده «${meal.name}» حذف گردید."
        }
    }

    fun updateDailyGoal(newGoal: Int) {
        if (newGoal in 800..5000) {
            _dailyCalorieGoal.value = newGoal
            _userMessage.value = "هدف کالری روزانه روی $newGoal کیلوکالری تنظیم شد."
        }
    }

    fun resetScan() {
        _scanState.value = ScanUiState.Idle
    }
}

class MainViewModelFactory(
    private val repository: FoodRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            return MainViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
