package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.calc.CalculatorEvaluator
import com.example.data.calc.EvaluationResult
import com.example.data.model.*
import com.example.data.repository.AppPreferences
import com.example.ui.components.NavTab
import com.example.ui.localization.AppLanguage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class ScreenDestination {
    object Main : ScreenDestination()
    object StandardCalc : ScreenDestination()
    object ScientificCalc : ScreenDestination()
    object AgeCalc : ScreenDestination()
    object GstCalc : ScreenDestination()
    object BmiCalc : ScreenDestination()
    object UnitConverter : ScreenDestination()
    object CurrencyConverter : ScreenDestination()
    object DiscountCalc : ScreenDestination()
    object EmiCalc : ScreenDestination()
    object TipCalc : ScreenDestination()
    object LanguageSelect : ScreenDestination()
}

data class MainUiState(
    val currentTab: NavTab = NavTab.HOME,
    val currentScreen: ScreenDestination = ScreenDestination.Main,
    val searchQuery: String = "",
    val selectedCategory: ToolCategory = ToolCategory.ALL,
    val favoriteToolIds: Set<String> = emptySet(),
    val historyList: List<CalculationHistory> = emptyList(),
    val language: AppLanguage = AppLanguage.ENGLISH,
    val themeMode: String = "SYSTEM",
    val hapticsEnabled: Boolean = true,
    val decimalPrecision: Int = 4,
    val isDegreeMode: Boolean = true,

    // Calculator screen state
    val calcExpression: String = "",
    val calcResult: String = "0",
    val isScientificExpanded: Boolean = false,
    val isResultEvaluated: Boolean = false
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = AppPreferences(application)

    private val _uiState = MutableStateFlow(
        MainUiState(
            favoriteToolIds = prefs.getFavoriteToolIds(),
            historyList = prefs.getHistory(),
            language = prefs.language,
            themeMode = prefs.themeMode,
            hapticsEnabled = prefs.hapticsEnabled,
            decimalPrecision = prefs.decimalPrecision,
            isDegreeMode = prefs.isDegreeMode
        )
    )
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    fun selectTab(tab: NavTab) {
        _uiState.value = _uiState.value.copy(
            currentTab = tab,
            currentScreen = ScreenDestination.Main
        )
    }

    fun navigateTo(destination: ScreenDestination) {
        _uiState.value = _uiState.value.copy(currentScreen = destination)
    }

    fun navigateBack(): Boolean {
        if (_uiState.value.currentScreen != ScreenDestination.Main) {
            _uiState.value = _uiState.value.copy(currentScreen = ScreenDestination.Main)
            return true
        }
        return false
    }

    fun setSearchQuery(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
    }

    fun selectCategory(category: ToolCategory) {
        _uiState.value = _uiState.value.copy(selectedCategory = category)
    }

    fun toggleFavorite(toolId: String) {
        val updated = prefs.toggleFavorite(toolId)
        _uiState.value = _uiState.value.copy(favoriteToolIds = updated)
    }

    fun setLanguage(language: AppLanguage) {
        prefs.language = language
        _uiState.value = _uiState.value.copy(language = language)
    }

    fun setThemeMode(mode: String) {
        prefs.themeMode = mode
        _uiState.value = _uiState.value.copy(themeMode = mode)
    }

    fun setHapticsEnabled(enabled: Boolean) {
        prefs.hapticsEnabled = enabled
        _uiState.value = _uiState.value.copy(hapticsEnabled = enabled)
    }

    fun setDecimalPrecision(precision: Int) {
        prefs.decimalPrecision = precision
        _uiState.value = _uiState.value.copy(decimalPrecision = precision)
    }

    fun toggleAngleMode() {
        val newMode = !_uiState.value.isDegreeMode
        prefs.isDegreeMode = newMode
        _uiState.value = _uiState.value.copy(isDegreeMode = newMode)
        // Re-evaluate if needed
        if (_uiState.value.calcExpression.isNotEmpty()) {
            evaluateExpression(saveToHistory = false)
        }
    }

    fun toggleScientificPanel() {
        _uiState.value = _uiState.value.copy(
            isScientificExpanded = !_uiState.value.isScientificExpanded
        )
    }

    // Calculator Actions
    fun onCalcInput(input: String) {
        val current = _uiState.value
        val newExpr = if (current.isResultEvaluated && input in "0123456789.") {
            input
        } else if (current.isResultEvaluated && input in "+-×÷^") {
            current.calcResult + input
        } else {
            current.calcExpression + input
        }

        _uiState.value = current.copy(
            calcExpression = newExpr,
            isResultEvaluated = false
        )

        // Live preview of result
        if (newExpr.isNotEmpty() && !newExpr.endsWith("+") && !newExpr.endsWith("-") && !newExpr.endsWith("×") && !newExpr.endsWith("÷")) {
            val eval = CalculatorEvaluator.evaluate(newExpr, current.isDegreeMode, current.decimalPrecision)
            if (eval is EvaluationResult.Success) {
                _uiState.value = _uiState.value.copy(calcResult = eval.value)
            }
        }
    }

    fun onCalcClear() {
        _uiState.value = _uiState.value.copy(
            calcExpression = "",
            calcResult = "0",
            isResultEvaluated = false
        )
    }

    fun onCalcBackspace() {
        val currentExpr = _uiState.value.calcExpression
        if (currentExpr.isNotEmpty()) {
            val updated = currentExpr.dropLast(1)
            _uiState.value = _uiState.value.copy(
                calcExpression = updated,
                calcResult = if (updated.isEmpty()) "0" else _uiState.value.calcResult,
                isResultEvaluated = false
            )
            if (updated.isNotEmpty()) {
                val eval = CalculatorEvaluator.evaluate(updated, _uiState.value.isDegreeMode, _uiState.value.decimalPrecision)
                if (eval is EvaluationResult.Success) {
                    _uiState.value = _uiState.value.copy(calcResult = eval.value)
                }
            }
        }
    }

    fun onCalcEquals() {
        evaluateExpression(saveToHistory = true)
    }

    private fun evaluateExpression(saveToHistory: Boolean) {
        val expr = _uiState.value.calcExpression
        if (expr.isBlank()) return

        val result = CalculatorEvaluator.evaluate(
            expr,
            _uiState.value.isDegreeMode,
            _uiState.value.decimalPrecision
        )

        when (result) {
            is EvaluationResult.Success -> {
                _uiState.value = _uiState.value.copy(
                    calcResult = result.value,
                    isResultEvaluated = true
                )
                if (saveToHistory) {
                    val updated = prefs.addHistory(expr, result.value)
                    _uiState.value = _uiState.value.copy(historyList = updated)
                }
            }
            is EvaluationResult.Error -> {
                _uiState.value = _uiState.value.copy(
                    calcResult = result.message,
                    isResultEvaluated = true
                )
            }
        }
    }

    fun loadFromHistory(history: CalculationHistory) {
        _uiState.value = _uiState.value.copy(
            calcExpression = history.expression,
            calcResult = history.result,
            isResultEvaluated = true,
            currentScreen = ScreenDestination.StandardCalc
        )
    }

    fun clearAllHistory() {
        prefs.clearHistory()
        _uiState.value = _uiState.value.copy(historyList = emptyList())
    }

    fun deleteHistoryItem(id: String) {
        val updated = prefs.deleteHistoryItem(id)
        _uiState.value = _uiState.value.copy(historyList = updated)
    }

    fun toggleHistoryFavorite(id: String) {
        val updated = prefs.toggleHistoryFavorite(id)
        _uiState.value = _uiState.value.copy(historyList = updated)
    }
}
