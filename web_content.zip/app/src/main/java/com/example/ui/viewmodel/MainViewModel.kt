package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.alarm.AlarmAudioPlayer
import com.example.alarm.AlarmScheduler
import com.example.data.database.AppDatabase
import com.example.data.model.AlarmEntity
import com.example.data.model.AppSettingsEntity
import com.example.data.repository.AlarmRepository
import com.example.receiver.AlarmReceiver
import com.example.ui.theme.AppColorTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val alarmRepo = AlarmRepository(db.alarmDao())
    private val alarmScheduler = AlarmScheduler(application)

    val alarms: StateFlow<List<AlarmEntity>> = alarmRepo.allAlarms
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _settings = MutableStateFlow(AppSettingsEntity())
    val settings: StateFlow<AppSettingsEntity> = _settings.asStateFlow()

    private val _currentTheme = MutableStateFlow(AppColorTheme.NEON_CYAN)
    val currentTheme: StateFlow<AppColorTheme> = _currentTheme.asStateFlow()

    val activeRingingAlarm: StateFlow<AlarmReceiver.ActiveAlarmState?> = AlarmReceiver.activeAlarmFlow

    // Find next upcoming alarm
    val nextAlarm: StateFlow<AlarmEntity?> = alarms.combine(activeRingingAlarm) { list, _ ->
        val enabled = list.filter { it.isEnabled }
        if (enabled.isEmpty()) null
        else {
            enabled.minByOrNull { AlarmScheduler.calculateNextTriggerMillis(it) }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    init {
        // Observe settings
        viewModelScope.launch {
            db.settingsDao().getSettings().collect { s ->
                if (s != null) {
                    _settings.value = s
                    _currentTheme.value = AppColorTheme.fromId(s.themeId)
                } else {
                    // Seed default settings (Light theme by default)
                    val defaultSettings = AppSettingsEntity(isDarkMode = false)
                    db.settingsDao().insertOrUpdate(defaultSettings)
                    _settings.value = defaultSettings
                }
            }
        }

        // Seed initial friendly alarms if empty
        seedDataIfEmpty()
    }

    private fun seedDataIfEmpty() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val currentList = alarmRepo.allAlarms.first()
                if (currentList.isEmpty()) {
                    val morningAlarm = AlarmEntity(
                        hour = 7,
                        minute = 0,
                        label = "Morning Wake Up",
                        isEnabled = true,
                        daysOfWeek = "1,2,3,4,5",
                        vibrate = true,
                        soundTone = "Digital Pulse",
                        snoozeDurationMinutes = 10
                    )
                    val id = alarmRepo.insert(morningAlarm)
                    alarmScheduler.schedule(morningAlarm.copy(id = id))
                }
            } catch (e: Throwable) {
                e.printStackTrace()
            }
        }
    }

    // ----------------------------------------------------
    // ALARM OPERATIONS
    // ----------------------------------------------------
    fun addAlarm(
        hour: Int,
        minute: Int,
        label: String,
        daysOfWeek: String,
        vibrate: Boolean,
        soundTone: String,
        snoozeMinutes: Int,
        customAudioPath: String? = null,
        customAudioTitle: String? = null
    ) {
        viewModelScope.launch {
            val alarm = AlarmEntity(
                hour = hour,
                minute = minute,
                label = label.ifBlank { "Alarm" },
                isEnabled = true,
                daysOfWeek = daysOfWeek,
                vibrate = vibrate,
                soundTone = soundTone,
                customAudioPath = customAudioPath,
                customAudioTitle = customAudioTitle,
                snoozeDurationMinutes = snoozeMinutes
            )
            val id = alarmRepo.insert(alarm)
            val created = alarm.copy(id = id)
            alarmScheduler.schedule(created)
        }
    }

    fun updateAlarm(alarm: AlarmEntity) {
        viewModelScope.launch {
            alarmRepo.update(alarm)
            if (alarm.isEnabled) {
                alarmScheduler.schedule(alarm)
            } else {
                alarmScheduler.cancel(alarm)
            }
        }
    }

    fun toggleAlarm(alarm: AlarmEntity) {
        viewModelScope.launch {
            val updated = alarmRepo.toggleEnabled(alarm)
            if (updated.isEnabled) {
                alarmScheduler.schedule(updated)
            } else {
                alarmScheduler.cancel(updated)
            }
        }
    }

    fun deleteAlarm(alarm: AlarmEntity) {
        viewModelScope.launch {
            alarmScheduler.cancel(alarm)
            alarmRepo.delete(alarm)
        }
    }

    fun testAlarmNow(alarm: AlarmEntity? = null) {
        val label = alarm?.label ?: "Test Alarm"
        val tone = alarm?.soundTone ?: _settings.value.defaultTone
        val vibrate = alarm?.vibrate ?: _settings.value.defaultVibrate
        val snooze = alarm?.snoozeDurationMinutes ?: _settings.value.defaultSnoozeMinutes
        val customAudio = alarm?.customAudioPath ?: _settings.value.defaultCustomAudioPath

        AlarmAudioPlayer.start(getApplication(), vibrate, tone, customAudio)
        AlarmReceiver.activeAlarmFlow.value = AlarmReceiver.ActiveAlarmState(
            alarmId = alarm?.id ?: 9999L,
            label = label,
            snoozeMinutes = snooze,
            isRinging = true
        )
    }

    fun dismissActiveAlarm() {
        AlarmAudioPlayer.stop()
        val currentActive = AlarmReceiver.activeAlarmFlow.value
        AlarmReceiver.activeAlarmFlow.value = null

        if (currentActive != null && currentActive.alarmId > 0 && currentActive.alarmId != 9999L) {
            viewModelScope.launch {
                val alarm = alarmRepo.getAlarmById(currentActive.alarmId)
                if (alarm != null && !alarm.isRepeating) {
                    val updated = alarm.copy(isEnabled = false, isSnoozed = false)
                    alarmRepo.update(updated)
                    alarmScheduler.cancel(updated)
                }
            }
        }
    }

    fun snoozeActiveAlarm() {
        AlarmAudioPlayer.stop()
        val currentActive = AlarmReceiver.activeAlarmFlow.value
        AlarmReceiver.activeAlarmFlow.value = null

        if (currentActive != null && currentActive.alarmId > 0 && currentActive.alarmId != 9999L) {
            viewModelScope.launch {
                val alarm = alarmRepo.getAlarmById(currentActive.alarmId)
                if (alarm != null) {
                    val snoozeTime = System.currentTimeMillis() + (currentActive.snoozeMinutes * 60 * 1000L)
                    val updated = alarm.copy(isSnoozed = true, snoozeTimeMillis = snoozeTime)
                    alarmRepo.update(updated)
                    alarmScheduler.schedule(updated)
                }
            }
        }
    }

    // ----------------------------------------------------
    // THEME & SETTINGS OPERATIONS
    // ----------------------------------------------------
    fun toggleDarkMode() {
        viewModelScope.launch {
            val newDarkMode = !_settings.value.isDarkMode
            val updated = _settings.value.copy(isDarkMode = newDarkMode)
            _settings.value = updated
            db.settingsDao().insertOrUpdate(updated)
        }
    }

    fun setDarkMode(enabled: Boolean) {
        viewModelScope.launch {
            val updated = _settings.value.copy(isDarkMode = enabled)
            _settings.value = updated
            db.settingsDao().insertOrUpdate(updated)
        }
    }

    fun selectTheme(theme: AppColorTheme) {
        _currentTheme.value = theme
        viewModelScope.launch {
            val updated = _settings.value.copy(themeId = theme.id)
            _settings.value = updated
            db.settingsDao().insertOrUpdate(updated)
        }
    }

    fun toggle24HourFormat() {
        viewModelScope.launch {
            val updated = _settings.value.copy(is24HourFormat = !_settings.value.is24HourFormat)
            _settings.value = updated
            db.settingsDao().insertOrUpdate(updated)
        }
    }

    fun updateDefaultSnooze(minutes: Int) {
        viewModelScope.launch {
            val updated = _settings.value.copy(defaultSnoozeMinutes = minutes)
            _settings.value = updated
            db.settingsDao().insertOrUpdate(updated)
        }
    }

    fun updateDefaultTone(tone: String) {
        viewModelScope.launch {
            val updated = _settings.value.copy(defaultTone = tone)
            _settings.value = updated
            db.settingsDao().insertOrUpdate(updated)
        }
    }

    fun updateDefaultCustomAudio(path: String?, title: String?) {
        viewModelScope.launch {
            val updated = _settings.value.copy(
                defaultCustomAudioPath = path,
                defaultCustomAudioTitle = title
            )
            _settings.value = updated
            db.settingsDao().insertOrUpdate(updated)
        }
    }
}
