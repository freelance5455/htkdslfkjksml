package com.example.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.AppContainer
import com.example.data.export.ExcelExporter
import com.example.data.export.PdfExporter
import com.example.data.local.BookingEntity
import com.example.data.local.ClientEntity
import com.example.data.local.DocumentEntity
import com.example.data.local.PaymentEntity
import com.example.data.local.PreferencesManager
import com.example.data.model.BookingWithDetails
import com.example.data.model.ClientWithBookings
import com.example.data.model.DashboardStats
import com.example.data.model.DocumentType
import com.example.data.model.PendingAttachment
import com.example.data.model.ReportPreview
import com.example.data.model.ReportType
import com.example.data.model.RestoreSummary
import com.example.data.model.SearchFilter
import com.example.data.repository.SaveResult
import com.example.data.repository.SdTravelRepository
import com.example.data.storage.BackupManager
import com.example.data.storage.DocumentStorage
import com.example.data.storage.LocalBackupFile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

sealed class UiEvent {
    data class ShowMessage(val text: String) : UiEvent()
    data class ExportReady(val file: File, val mimeType: String, val label: String) : UiEvent()
    data class PrintReady(val pdfFile: File, val jobName: String) : UiEvent()
    data class BackupCreated(val file: File) : UiEvent()
    data class RestoreCompleted(val summary: RestoreSummary) : UiEvent()
}

class MainViewModel(
    private val repository: SdTravelRepository,
    val documentStorage: DocumentStorage,
    private val excelExporter: ExcelExporter,
    private val pdfExporter: PdfExporter,
    private val backupManager: BackupManager,
    preferencesManager: PreferencesManager,
) : ViewModel() {

    private val _events = MutableSharedFlow<UiEvent>()
    val events = _events.asSharedFlow()

    val allClients: StateFlow<List<ClientWithBookings>> = repository.allClientsWithBookings
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList(),
        )

    val dashboardStats: StateFlow<DashboardStats> = allClients
        .map { repository.computeDashboardStats(it) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = DashboardStats(),
        )

    private val _searchFilter = MutableStateFlow(SearchFilter())
    val searchFilter: StateFlow<SearchFilter> = _searchFilter.asStateFlow()

    val searchResults: StateFlow<List<ClientWithBookings>> = combine(allClients, _searchFilter) { clients, filter ->
        repository.filterClients(clients, filter)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList(),
    )

    private val _selectedReportType = MutableStateFlow(ReportType.ALL_BOOKINGS)
    val selectedReportType: StateFlow<ReportType> = _selectedReportType.asStateFlow()

    private val _reportFromDate = MutableStateFlow("")
    val reportFromDate: StateFlow<String> = _reportFromDate.asStateFlow()

    private val _reportToDate = MutableStateFlow("")
    val reportToDate: StateFlow<String> = _reportToDate.asStateFlow()

    val activeReportPreview: StateFlow<ReportPreview> = combine(
        allClients,
        _selectedReportType,
        _reportFromDate,
        _reportToDate,
    ) { clients, type, from, to ->
        repository.buildReport(type, clients, from, to)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = repository.buildReport(ReportType.ALL_BOOKINGS, emptyList(), "", ""),
    )

    val lastBackupTimestamp: StateFlow<Long?> = preferencesManager.lastBackupTimestamp
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val lastBackupName: StateFlow<String?> = preferencesManager.lastBackupName
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _localBackups = MutableStateFlow<List<LocalBackupFile>>(emptyList())
    val localBackups: StateFlow<List<LocalBackupFile>> = _localBackups.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    init {
        refreshLocalBackups()
    }

    fun observeClient(clientId: Long): Flow<ClientWithBookings?> =
        repository.observeClientWithBookings(clientId)

    suspend fun checkCodeAvailable(code: String, excludingClientId: Long? = null): Boolean =
        repository.isClientCodeAvailable(code, excludingClientId)

    fun saveNewClientAndBooking(
        clientCode: String,
        fullName: String,
        phone: String,
        whatsapp: String,
        nationalId: String,
        passportNumber: String,
        birthDate: String,
        clientNotes: String,
        booking: BookingEntity,
        depositAmount: Double,
        attachments: List<PendingAttachment>,
        onResult: (SaveResult) -> Unit,
    ) {
        viewModelScope.launch {
            val res = repository.createNewClientAndBooking(
                clientCode = clientCode,
                fullName = fullName,
                phone = phone,
                whatsapp = whatsapp,
                nationalId = nationalId,
                passportNumber = passportNumber,
                birthDate = birthDate,
                clientNotes = clientNotes,
                booking = booking,
                depositAmount = depositAmount,
                attachments = attachments,
            )
            if (res is SaveResult.Success) {
                _events.emit(UiEvent.ShowMessage("تم حفظ العميل والحجز بنجاح"))
            }
            onResult(res)
        }
    }

    fun addBookingForExistingClient(
        clientId: Long,
        booking: BookingEntity,
        depositAmount: Double,
        attachments: List<PendingAttachment>,
        onResult: (SaveResult) -> Unit,
    ) {
        viewModelScope.launch {
            val res = repository.addBookingToExistingClient(clientId, booking, depositAmount, attachments)
            if (res is SaveResult.Success) {
                _events.emit(UiEvent.ShowMessage("تم إضافة الحجز الجديد للعميل بنجاح"))
            }
            onResult(res)
        }
    }

    fun updateClient(client: ClientEntity, onResult: (SaveResult) -> Unit) {
        viewModelScope.launch {
            val res = repository.updateClient(client)
            if (res is SaveResult.Success) {
                _events.emit(UiEvent.ShowMessage("تم تحديث بيانات العميل"))
            }
            onResult(res)
        }
    }

    fun updateBooking(booking: BookingEntity) {
        viewModelScope.launch {
            repository.updateBooking(booking)
            _events.emit(UiEvent.ShowMessage("تم تحديث بيانات الرحلة والحجز"))
        }
    }

    fun deleteBooking(bookingId: Long, onDeleted: () -> Unit = {}) {
        viewModelScope.launch {
            repository.deleteBooking(bookingId)
            _events.emit(UiEvent.ShowMessage("تم حذف الحجز ومستنداته"))
            onDeleted()
        }
    }

    fun deleteClient(clientId: Long, onDeleted: () -> Unit = {}) {
        viewModelScope.launch {
            repository.deleteClient(clientId)
            _events.emit(UiEvent.ShowMessage("تم حذف ملف العميل بالكامل"))
            onDeleted()
        }
    }

    fun addPayment(payment: PaymentEntity) {
        viewModelScope.launch {
            repository.addPayment(payment)
            _events.emit(UiEvent.ShowMessage("تم تسجيل الدفعة وتحديث الحساب تلقائيًا"))
        }
    }

    fun updatePayment(payment: PaymentEntity) {
        viewModelScope.launch {
            repository.updatePayment(payment)
            _events.emit(UiEvent.ShowMessage("تم تعديل الدفعة وتحديث المتبقي"))
        }
    }

    fun deletePayment(paymentId: Long) {
        viewModelScope.launch {
            repository.deletePayment(paymentId)
            _events.emit(UiEvent.ShowMessage("تم حذف الدفعة"))
        }
    }

    fun addDocumentFromUri(bookingId: Long, docType: DocumentType, title: String, uri: Uri) {
        viewModelScope.launch {
            val temp = documentStorage.copyUriToTempFile(uri)
            if (temp != null) {
                repository.addDocumentFromTempFile(bookingId, docType, title, temp)
                _events.emit(UiEvent.ShowMessage("تم حفظ المستند في ملف العميل"))
            } else {
                _events.emit(UiEvent.ShowMessage("تعذر قراءة الصورة المختارة"))
            }
        }
    }

    fun addDocumentFromTempFile(bookingId: Long, docType: DocumentType, title: String, tempFile: File) {
        viewModelScope.launch {
            repository.addDocumentFromTempFile(bookingId, docType, title, tempFile)
            _events.emit(UiEvent.ShowMessage("تم حفظ الصورة في ملف العميل"))
        }
    }

    fun replaceDocumentFromUri(existing: DocumentEntity, uri: Uri) {
        viewModelScope.launch {
            val temp = documentStorage.copyUriToTempFile(uri)
            if (temp != null) {
                repository.replaceDocumentFile(existing, temp)
                _events.emit(UiEvent.ShowMessage("تم استبدال المستند بنجاح"))
            } else {
                _events.emit(UiEvent.ShowMessage("تعذر قراءة الصورة الجديدة"))
            }
        }
    }

    fun replaceDocumentFromFile(existing: DocumentEntity, tempFile: File) {
        viewModelScope.launch {
            repository.replaceDocumentFile(existing, tempFile)
            _events.emit(UiEvent.ShowMessage("تم استبدال الصورة بنجاح"))
        }
    }

    fun deleteDocument(document: DocumentEntity) {
        viewModelScope.launch {
            repository.deleteDocument(document)
            _events.emit(UiEvent.ShowMessage("تم حذف المستند"))
        }
    }

    fun updateSearchFilter(transform: (SearchFilter) -> SearchFilter) {
        _searchFilter.value = transform(_searchFilter.value)
    }

    fun clearSearchFilter() {
        _searchFilter.value = SearchFilter()
    }

    fun selectReportType(type: ReportType) {
        _selectedReportType.value = type
    }

    fun setReportDateRange(from: String, to: String) {
        _reportFromDate.value = from
        _reportToDate.value = to
    }

    fun exportCurrentReportExcel() {
        viewModelScope.launch {
            _isBusy.value = true
            runCatching {
                excelExporter.exportReportToXlsx(
                    report = activeReportPreview.value,
                    fromDate = _reportFromDate.value,
                    toDate = _reportToDate.value,
                )
            }.onSuccess { file ->
                _events.emit(
                    UiEvent.ExportReady(
                        file = file,
                        mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        label = "تقرير Excel",
                    )
                )
            }.onFailure { err ->
                _events.emit(UiEvent.ShowMessage("فشل تصدير Excel: ${err.message}"))
            }
            _isBusy.value = false
        }
    }

    fun exportCurrentReportPdf() {
        viewModelScope.launch {
            _isBusy.value = true
            runCatching {
                pdfExporter.exportReportToPdf(
                    report = activeReportPreview.value,
                    fromDate = _reportFromDate.value,
                    toDate = _reportToDate.value,
                )
            }.onSuccess { file ->
                _events.emit(
                    UiEvent.ExportReady(
                        file = file,
                        mimeType = "application/pdf",
                        label = "تقرير PDF",
                    )
                )
            }.onFailure { err ->
                _events.emit(UiEvent.ShowMessage("فشل تصدير PDF: ${err.message}"))
            }
            _isBusy.value = false
        }
    }

    fun exportClientPdfForShare(client: ClientWithBookings, booking: BookingWithDetails?) {
        viewModelScope.launch {
            _isBusy.value = true
            runCatching {
                pdfExporter.exportClientProfilePdf(client, booking)
            }.onSuccess { file ->
                _events.emit(UiEvent.ExportReady(file, "application/pdf", "ملف العميل PDF"))
            }.onFailure { err ->
                _events.emit(UiEvent.ShowMessage("تعذر إنشاء PDF للعميل: ${err.message}"))
            }
            _isBusy.value = false
        }
    }

    fun prepareClientPrint(client: ClientWithBookings, booking: BookingWithDetails?) {
        viewModelScope.launch {
            _isBusy.value = true
            runCatching {
                pdfExporter.exportClientProfilePdf(client, booking)
            }.onSuccess { file ->
                _events.emit(UiEvent.PrintReady(file, "SD_TRAVEL_${client.client.clientCode}"))
            }.onFailure { err ->
                _events.emit(UiEvent.ShowMessage("تعذر تجهيز الطباعة: ${err.message}"))
            }
            _isBusy.value = false
        }
    }

    fun refreshLocalBackups() {
        _localBackups.value = backupManager.listLocalBackups()
    }

    fun createBackup() {
        viewModelScope.launch {
            _isBusy.value = true
            runCatching {
                backupManager.createFullBackup()
            }.onSuccess { file ->
                refreshLocalBackups()
                _events.emit(UiEvent.BackupCreated(file))
                _events.emit(UiEvent.ShowMessage("تم إنشاء النسخة الاحتياطية بنجاح"))
            }.onFailure { err ->
                _events.emit(UiEvent.ShowMessage("خطأ في إنشاء النسخة الاحتياطية: ${err.message}"))
            }
            _isBusy.value = false
        }
    }

    fun saveBackupToUri(backupFile: File, targetUri: Uri) {
        viewModelScope.launch {
            val ok = backupManager.copyBackupToUri(backupFile, targetUri)
            _events.emit(
                UiEvent.ShowMessage(
                    if (ok) "تم حفظ النسخة الاحتياطية على الهاتف بنجاح" else "تعذر حفظ الملف في الموقع المحدد"
                )
            )
        }
    }

    fun restoreBackupFromUri(uri: Uri) {
        viewModelScope.launch {
            _isBusy.value = true
            runCatching {
                backupManager.restoreFromUri(uri)
            }.onSuccess { summary ->
                _events.emit(UiEvent.RestoreCompleted(summary))
            }.onFailure { err ->
                _events.emit(UiEvent.ShowMessage("فشل استعادة النسخة الاحتياطية: ${err.message}"))
            }
            _isBusy.value = false
        }
    }

    fun restoreBackupFromFile(file: File) {
        viewModelScope.launch {
            _isBusy.value = true
            runCatching {
                backupManager.restoreFromFile(file)
            }.onSuccess { summary ->
                _events.emit(UiEvent.RestoreCompleted(summary))
            }.onFailure { err ->
                _events.emit(UiEvent.ShowMessage("فشل استعادة النسخة: ${err.message}"))
            }
            _isBusy.value = false
        }
    }

    fun deleteBackupFile(file: File) {
        backupManager.deleteBackupFile(file)
        refreshLocalBackups()
    }
}

class AppViewModelFactory(private val container: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return MainViewModel(
            repository = container.repository,
            documentStorage = container.documentStorage,
            excelExporter = container.excelExporter,
            pdfExporter = container.pdfExporter,
            backupManager = container.backupManager,
            preferencesManager = container.preferencesManager,
        ) as T
    }
}
