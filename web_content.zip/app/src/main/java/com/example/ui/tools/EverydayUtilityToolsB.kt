package com.example.ui.tools

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.engine.FormattingOptions
import com.example.engine.NumberFormatter
import com.example.tools.FractionOp
import com.example.tools.MotionTarget
import com.example.tools.SimpleDate
import com.example.tools.ToolId
import com.example.tools.ToolsEngine
import com.example.ui.components.AetherCard
import com.example.ui.components.AetherFilterChip
import com.example.ui.components.AetherNumberField
import com.example.ui.components.AetherResultRow
import com.example.ui.theme.AetherTheme

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun EverydayUtilityToolsBView(
  toolId: ToolId,
  formatting: FormattingOptions,
  hapticsEnabled: Boolean,
  onCopy: (String) -> Unit,
) {
  val colors = AetherTheme.colors

  when (toolId) {
    ToolId.FRACTION -> {
      var n1 by remember { mutableStateOf("3") }
      var d1 by remember { mutableStateOf("4") }
      var n2 by remember { mutableStateOf("2") }
      var d2 by remember { mutableStateOf("5") }
      var op by remember { mutableStateOf(FractionOp.ADD) }

      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          AetherNumberField(n1, { n1 = it }, "Num 1", allowDecimal = false, allowNegative = true, modifier = Modifier.weight(1f))
          AetherNumberField(d1, { d1 = it }, "Den 1", allowDecimal = false, allowNegative = true, modifier = Modifier.weight(1f))
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          FractionOp.entries.forEach { item ->
            AetherFilterChip(item.symbol, op == item, { op = item }, hapticsEnabled = hapticsEnabled)
          }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          AetherNumberField(n2, { n2 = it }, "Num 2", allowDecimal = false, allowNegative = true, modifier = Modifier.weight(1f))
          AetherNumberField(d2, { d2 = it }, "Den 2", allowDecimal = false, allowNegative = true, modifier = Modifier.weight(1f))
        }
        AetherCard(backgroundColor = colors.surfaceElevated) {
          val ln1 = n1.toLongOrNull()
          val ld1 = d1.toLongOrNull()
          val ln2 = n2.toLongOrNull()
          val ld2 = d2.toLongOrNull()
          val res =
            if (ln1 != null && ld1 != null && ln2 != null && ld2 != null) {
              ToolsEngine.fraction(ln1, ld1, ln2, ld2, op)
            } else {
              null
            }
          if (res != null) {
            val fracStr = if (res.denominator == 1L) "${res.numerator}" else "${res.numerator}/${res.denominator}"
            AetherResultRow("Simplified fraction", fracStr, onCopy = { onCopy(fracStr) }, highlight = true)
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = colors.borderSubtle)
            if (res.mixedWhole != 0L && res.mixedRemNum != 0L) {
              AetherResultRow("Mixed number", "${res.mixedWhole} ${res.mixedRemNum}/${res.denominator}")
              Spacer(modifier = Modifier.height(4.dp))
            }
            AetherResultRow("Decimal", NumberFormatter.formatDouble(res.decimal, formatting))
          } else {
            Text("Denominators (and divisor) cannot be zero.", color = colors.error, style = MaterialTheme.typography.bodyMedium)
          }
        }
      }
    }

    ToolId.TIME_DURATION -> {
      var sH by remember { mutableStateOf("9") }
      var sM by remember { mutableStateOf("30") }
      var eH by remember { mutableStateOf("17") }
      var eM by remember { mutableStateOf("45") }

      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Start time (24h)", style = MaterialTheme.typography.labelMedium, color = colors.textSecondary)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          AetherNumberField(sH, { sH = it }, "Hour (0–23)", allowDecimal = false, modifier = Modifier.weight(1f))
          AetherNumberField(sM, { sM = it }, "Min (0–59)", allowDecimal = false, modifier = Modifier.weight(1f))
        }
        Text("End time (24h)", style = MaterialTheme.typography.labelMedium, color = colors.textSecondary)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          AetherNumberField(eH, { eH = it }, "Hour (0–23)", allowDecimal = false, modifier = Modifier.weight(1f))
          AetherNumberField(eM, { eM = it }, "Min (0–59)", allowDecimal = false, modifier = Modifier.weight(1f))
        }
        AetherCard(backgroundColor = colors.surfaceElevated) {
          val res =
            ToolsEngine.timeDuration(
              sH.toIntOrNull() ?: -1,
              sM.toIntOrNull() ?: -1,
              eH.toIntOrNull() ?: -1,
              eM.toIntOrNull() ?: -1,
            )
          if (res != null) {
            val durStr = "${res.first}h ${res.second}m"
            AetherResultRow("Elapsed duration", durStr, onCopy = { onCopy(durStr) }, highlight = true)
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = colors.borderSubtle)
            AetherResultRow("Total minutes", "${res.third} min")
            Spacer(modifier = Modifier.height(4.dp))
            AetherResultRow("Decimal hours", NumberFormatter.formatDouble(res.third / 60.0, formatting))
          } else {
            Text("Enter valid 24-hour times (0–23 and 0–59).", color = colors.error, style = MaterialTheme.typography.bodyMedium)
          }
        }
      }
    }

    ToolId.DATE_DIFFERENCE -> {
      val today = remember { SimpleDate.today() }
      var startDate by remember { mutableStateOf(SimpleDate(today.year, 1, 1)) }
      var endDate by remember { mutableStateOf(today) }
      var pickingForStart by remember { mutableStateOf<Boolean?>(null) }

      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Button(
          onClick = { pickingForStart = true },
          colors = ButtonDefaults.buttonColors(containerColor = colors.surfaceElevated, contentColor = colors.textPrimary),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Text("Start date: ${startDate.formatted()}")
        }
        Button(
          onClick = { pickingForStart = false },
          colors = ButtonDefaults.buttonColors(containerColor = colors.surfaceElevated, contentColor = colors.textPrimary),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Text("End date: ${endDate.formatted()}")
        }
        val diff = remember(startDate, endDate) { ToolsEngine.dateDifference(startDate, endDate) }
        AetherCard(backgroundColor = colors.surfaceElevated) {
          val daysStr = "${diff.totalDays} days"
          AetherResultRow("Total days", daysStr, onCopy = { onCopy(daysStr) }, highlight = true)
          HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = colors.borderSubtle)
          AetherResultRow("Breakdown", "${diff.years}y ${diff.months}m ${diff.days}d")
          Spacer(modifier = Modifier.height(4.dp))
          AetherResultRow("Weeks", "${diff.weeks} wk ${diff.remainingDays} d")
        }
      }

      pickingForStart?.let { isStart ->
        val initial = if (isStart) startDate else endDate
        val pickerState = rememberDatePickerState(initialSelectedDateMillis = initial.toEpochMillisUtc())
        DatePickerDialog(
          onDismissRequest = { pickingForStart = null },
          confirmButton = {
            TextButton(
              onClick = {
                pickerState.selectedDateMillis?.let { millis ->
                  val chosen = SimpleDate.fromUtcMillis(millis)
                  if (isStart) startDate = chosen else endDate = chosen
                }
                pickingForStart = null
              }
            ) {
              Text("Select", color = colors.lavender)
            }
          },
          dismissButton = {
            TextButton(onClick = { pickingForStart = null }) {
              Text("Cancel", color = colors.textSecondary)
            }
          },
        ) {
          DatePicker(state = pickerState)
        }
      }
    }

    ToolId.AGE -> {
      val today = remember { SimpleDate.today() }
      var birthDate by remember { mutableStateOf(SimpleDate((today.year - 25).coerceAtLeast(1900), 6, 15)) }
      var showPicker by remember { mutableStateOf(false) }

      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Button(
          onClick = { showPicker = true },
          colors = ButtonDefaults.buttonColors(containerColor = colors.surfaceElevated, contentColor = colors.textPrimary),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Text("Date of birth: ${birthDate.formatted()}")
        }
        val age = remember(birthDate, today) { ToolsEngine.calculateAge(birthDate, today) }
        AetherCard(backgroundColor = colors.surfaceElevated) {
          if (age != null) {
            val ageStr = "${age.years} yrs ${age.months} mos ${age.days} d"
            AetherResultRow("Age", ageStr, onCopy = { onCopy(ageStr) }, highlight = true)
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = colors.borderSubtle)
            AetherResultRow("Total days lived", NumberFormatter.formatDouble(age.totalDays.toDouble(), formatting))
            Spacer(modifier = Modifier.height(4.dp))
            AetherResultRow("Next birthday in", "${age.daysUntilNextBirthday} days")
          } else {
            Text("Birth date cannot be in the future.", color = colors.error, style = MaterialTheme.typography.bodyMedium)
          }
        }
      }

      if (showPicker) {
        val pickerState = rememberDatePickerState(initialSelectedDateMillis = birthDate.toEpochMillisUtc())
        DatePickerDialog(
          onDismissRequest = { showPicker = false },
          confirmButton = {
            TextButton(
              onClick = {
                pickerState.selectedDateMillis?.let { birthDate = SimpleDate.fromUtcMillis(it) }
                showPicker = false
              }
            ) {
              Text("Select", color = colors.lavender)
            }
          },
          dismissButton = {
            TextButton(onClick = { showPicker = false }) {
              Text("Cancel", color = colors.textSecondary)
            }
          },
        ) {
          DatePicker(state = pickerState)
        }
      }
    }

    ToolId.SPEED_DISTANCE_TIME -> {
      var target by remember { mutableStateOf(MotionTarget.SPEED) }
      var first by remember { mutableStateOf("180") }
      var second by remember { mutableStateOf("2.5") }

      val (label1, label2, resultLabel, unitSuffix) =
        when (target) {
          MotionTarget.SPEED -> listOf("Distance (km / mi)", "Time (hours)", "Speed", "per hour")
          MotionTarget.DISTANCE -> listOf("Speed (per hour)", "Time (hours)", "Distance", "units")
          MotionTarget.TIME -> listOf("Distance", "Speed (per hour)", "Time", "hours")
        }

      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        FlowRow(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          MotionTarget.entries.forEach { item ->
            AetherFilterChip(item.label, target == item, { target = item }, hapticsEnabled = hapticsEnabled)
          }
        }
        AetherNumberField(first, { first = it }, label1)
        AetherNumberField(second, { second = it }, label2)
        AetherCard(backgroundColor = colors.surfaceElevated) {
          val a = first.toDoubleOrNull()
          val b = second.toDoubleOrNull()
          val res = if (a != null && b != null) ToolsEngine.solveMotion(target, a, b) else null
          if (res != null) {
            val formatted = "${NumberFormatter.formatDouble(res, formatting)} $unitSuffix"
            AetherResultRow(resultLabel, formatted, onCopy = { onCopy(formatted) }, highlight = true)
          } else {
            AetherResultRow(resultLabel, "—", highlight = true)
          }
        }
      }
    }

    ToolId.FUEL_COST -> {
      var distance by remember { mutableStateOf("320") }
      var efficiency by remember { mutableStateOf("16") }
      var price by remember { mutableStateOf("1.65") }

      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        AetherNumberField(distance, { distance = it }, "Trip distance (km or mi)")
        AetherNumberField(efficiency, { efficiency = it }, "Efficiency (km/L or mpg)")
        AetherNumberField(price, { price = it }, "Fuel price per L or gal")
        AetherCard(backgroundColor = colors.surfaceElevated) {
          val d = distance.toDoubleOrNull()
          val e = efficiency.toDoubleOrNull()
          val p = price.toDoubleOrNull()
          val res = if (d != null && e != null && p != null) ToolsEngine.fuelCost(d, e, p) else null
          if (res != null) {
            val fCost = NumberFormatter.formatDouble(res.second, formatting)
            val fFuel = NumberFormatter.formatDouble(res.first, formatting)
            AetherResultRow("Total fuel cost", fCost, onCopy = { onCopy(fCost) }, highlight = true)
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = colors.borderSubtle)
            AetherResultRow("Fuel needed", "$fFuel L / gal")
          } else {
            AetherResultRow("Total fuel cost", "—", highlight = true)
          }
        }
      }
    }

    ToolId.UNIT_PRICE -> {
      var pA by remember { mutableStateOf("4.99") }
      var qA by remember { mutableStateOf("500") }
      var pB by remember { mutableStateOf("7.49") }
      var qB by remember { mutableStateOf("1000") }

      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Option A", style = MaterialTheme.typography.labelMedium, color = colors.lavender)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          AetherNumberField(pA, { pA = it }, "Price A", modifier = Modifier.weight(1f))
          AetherNumberField(qA, { qA = it }, "Quantity A", modifier = Modifier.weight(1f))
        }
        Text("Option B", style = MaterialTheme.typography.labelMedium, color = colors.lavender)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          AetherNumberField(pB, { pB = it }, "Price B", modifier = Modifier.weight(1f))
          AetherNumberField(qB, { qB = it }, "Quantity B", modifier = Modifier.weight(1f))
        }
        AetherCard(backgroundColor = colors.surfaceElevated) {
          val pa = pA.toDoubleOrNull()
          val qa = qA.toDoubleOrNull()
          val pb = pB.toDoubleOrNull()
          val qb = qB.toDoubleOrNull()
          val res = if (pa != null && qa != null && pb != null && qb != null) ToolsEngine.unitPriceCompare(pa, qa, pb, qb) else null
          if (res != null) {
            val winner =
              when {
                res.first < res.second -> "Option A is cheaper (${NumberFormatter.formatDouble(res.third, formatting)}% less)"
                res.second < res.first -> "Option B is cheaper (${NumberFormatter.formatDouble(res.third, formatting)}% less)"
                else -> "Both options have equal unit price"
              }
            Text(text = winner, style = MaterialTheme.typography.titleMedium, color = colors.lavender)
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = colors.borderSubtle)
            AetherResultRow("Option A / unit", NumberFormatter.formatDouble(res.first, formatting))
            Spacer(modifier = Modifier.height(4.dp))
            AetherResultRow("Option B / unit", NumberFormatter.formatDouble(res.second, formatting))
          } else {
            AetherResultRow("Comparison", "—", highlight = true)
          }
        }
      }
    }

    else -> Unit
  }
}
