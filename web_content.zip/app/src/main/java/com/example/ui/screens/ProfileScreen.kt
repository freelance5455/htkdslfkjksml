package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SwitchAccount
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.local.UserEntity
import com.example.data.local.VideoEntity
import com.example.ui.components.formatCount
import com.example.ui.theme.ZingBlack
import com.example.ui.theme.ZingBorder
import com.example.ui.theme.ZingCardSurface
import com.example.ui.theme.ZingCyan
import com.example.ui.theme.ZingDarkSurface
import com.example.ui.theme.ZingGold
import com.example.ui.theme.ZingHeartRed
import com.example.ui.theme.ZingNeonPink
import com.example.ui.theme.ZingTextMuted
import com.example.ui.theme.ZingTextPrimary
import com.example.ui.theme.ZingTextSecondary

@Composable
fun ProfileScreen(
    user: UserEntity?,
    isCurrentUser: Boolean,
    userVideos: List<VideoEntity>,
    likedVideos: List<VideoEntity>,
    allUsers: List<UserEntity>,
    onBack: (() -> Unit)?,
    onFollowClick: () -> Unit,
    onOpenCreatorStudio: () -> Unit,
    onOpenAdminDashboard: () -> Unit,
    onSwitchUser: (String) -> Unit,
    onUpdateProfile: (String, String) -> Unit,
    onOpenAuthDialog: () -> Unit,
    onVideoClick: (VideoEntity) -> Unit,
    onOpenWebFrontend: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Videos, 1: Liked
    var showEditDialog by remember { mutableStateOf(false) }
    var showSwitchAccountDialog by remember { mutableStateOf(false) }

    val safeUser = user ?: UserEntity(
        id = "unknown",
        username = "creator",
        displayName = "Sinji Creator",
        avatarUrl = "",
        bio = "Welcome to Sinji Shorts!"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ZingBlack)
            .statusBarsPadding()
    ) {
        // Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (onBack != null) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = ZingTextPrimary)
                }
            } else {
                Spacer(modifier = Modifier.width(40.dp))
            }

            Text(
                text = "@${safeUser.username}",
                color = ZingTextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp
            )

            Row {
                if (safeUser.role == "admin" || isCurrentUser) {
                    IconButton(onClick = onOpenAdminDashboard) {
                        Icon(
                            imageVector = Icons.Default.AdminPanelSettings,
                            contentDescription = "Admin Dashboard",
                            tint = ZingCyan
                        )
                    }
                }
                IconButton(onClick = { showSwitchAccountDialog = true }) {
                    Icon(
                        imageVector = Icons.Default.SwitchAccount,
                        contentDescription = "Switch Account",
                        tint = ZingTextSecondary
                    )
                }
            }
        }

        // --- Profile Header ---
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Avatar
            val avatarRes = context.resources.getIdentifier(safeUser.avatarUrl, "drawable", context.packageName)
            Box(
                modifier = Modifier
                    .size(86.dp)
                    .clip(CircleShape)
                    .border(2.5.dp, ZingNeonPink, CircleShape)
            ) {
                if (avatarRes != 0) {
                    AsyncImage(
                        model = ImageRequest.Builder(context).data(avatarRes).crossfade(true).build(),
                        contentDescription = safeUser.displayName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .fillMaxSize()
                            .background(ZingNeonPink)
                    ) {
                        Text(
                            text = safeUser.displayName.take(1),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 32.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Display Name & Verified badge
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = safeUser.displayName,
                    color = ZingTextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                if (safeUser.isVerified) {
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Default.Verified,
                        contentDescription = "Verified Creator",
                        tint = ZingCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Bio
            Text(
                text = safeUser.bio,
                color = ZingTextSecondary,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                lineHeight = 18.sp,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Stats Row: Following, Followers, Total Likes
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                ProfileStatColumn(count = formatCount(safeUser.followingCount), label = "Following")
                ProfileStatColumn(count = formatCount(safeUser.followersCount), label = "Followers")
                ProfileStatColumn(count = formatCount(safeUser.totalLikes), label = "Likes")
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Action Buttons
            if (isCurrentUser) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Creator Monetization Studio Button (शुरू से दिखे)
                    Button(
                        onClick = onOpenCreatorStudio,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ZingGold,
                            contentColor = ZingBlack
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1.3f)
                            .height(42.dp)
                            .testTag("profile_creator_studio_button")
                    ) {
                        Icon(Icons.Default.MonetizationOn, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Monetization Studio", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    // Edit Profile Button
                    Button(
                        onClick = { showEditDialog = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ZingCardSurface,
                            contentColor = ZingTextPrimary
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(0.9f)
                            .height(42.dp)
                            .border(1.dp, ZingBorder, RoundedCornerShape(14.dp))
                            .testTag("edit_profile_button")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Edit", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    }
                }

                if (onOpenWebFrontend != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = onOpenWebFrontend,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ZingDarkSurface,
                            contentColor = ZingNeonPink
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(38.dp)
                            .border(1.dp, ZingNeonPink.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
                            .testTag("profile_open_web_frontend_button")
                    ) {
                        Text("🌐 Open Full HTML/JS Web Frontend", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            } else {
                Button(
                    onClick = onFollowClick,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (safeUser.isFollowing) ZingDarkSurface else ZingNeonPink,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth(0.6f)
                        .height(42.dp)
                ) {
                    Text(
                        text = if (safeUser.isFollowing) "Following" else "Follow",
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Tabs (Videos vs Liked)
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = ZingBlack,
            contentColor = ZingNeonPink,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = ZingNeonPink
                )
            }
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                icon = { Icon(Icons.Default.GridOn, contentDescription = "Videos", modifier = Modifier.size(20.dp)) },
                text = { Text("Videos (${userVideos.size})", fontSize = 12.sp) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                icon = { Icon(Icons.Default.Favorite, contentDescription = "Liked", modifier = Modifier.size(20.dp)) },
                text = { Text("Liked", fontSize = 12.sp) }
            )
        }

        // Videos Grid
        val displayedVideos = if (selectedTab == 0) userVideos else likedVideos

        if (displayedVideos.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (selectedTab == 0) "No videos uploaded yet" else "No liked videos yet",
                    color = ZingTextSecondary,
                    fontSize = 14.sp
                )
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                items(displayedVideos, key = { it.id }) { video ->
                    Box(
                        modifier = Modifier
                            .height(150.dp)
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color(video.bgGradientStart), Color(video.bgGradientEnd))
                                )
                            )
                            .clickable { onVideoClick(video) }
                    ) {
                        val posterRes = context.resources.getIdentifier(video.posterResName, "drawable", context.packageName)
                        if (posterRes != 0) {
                            AsyncImage(
                                model = ImageRequest.Builder(context).data(posterRes).crossfade(true).build(),
                                contentDescription = video.caption,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        Row(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                            Text(text = formatCount(video.viewsCount), color = Color.White, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }

    // Edit Profile Dialog
    if (showEditDialog) {
        EditProfileDialog(
            currentName = safeUser.displayName,
            currentBio = safeUser.bio,
            onDismiss = { showEditDialog = false },
            onSave = { name, bio ->
                onUpdateProfile(name, bio)
                showEditDialog = false
            }
        )
    }

    // Switch Account / Login Dialog
    if (showSwitchAccountDialog) {
        SwitchAccountDialog(
            users = allUsers,
            currentUserId = safeUser.id,
            onDismiss = { showSwitchAccountDialog = false },
            onSelectUser = { userId ->
                onSwitchUser(userId)
                showSwitchAccountDialog = false
            },
            onCreateNewAccount = {
                showSwitchAccountDialog = false
                onOpenAuthDialog()
            }
        )
    }
}

@Composable
private fun ProfileStatColumn(count: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = count, color = ZingTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text(text = label, color = ZingTextMuted, fontSize = 11.sp)
    }
}

@Composable
fun EditProfileDialog(
    currentName: String,
    currentBio: String,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit
) {
    var displayName by remember { mutableStateOf(currentName) }
    var bio by remember { mutableStateOf(currentBio) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ZingDarkSurface,
        title = {
            Text("Edit Profile", color = ZingTextPrimary, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = displayName,
                    onValueChange = { displayName = it },
                    label = { Text("Display Name", color = ZingTextSecondary) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ZingTextPrimary,
                        unfocusedTextColor = ZingTextPrimary,
                        focusedBorderColor = ZingNeonPink,
                        unfocusedBorderColor = ZingBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = bio,
                    onValueChange = { bio = it },
                    label = { Text("Bio", color = ZingTextSecondary) },
                    minLines = 3,
                    maxLines = 4,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = ZingTextPrimary,
                        unfocusedTextColor = ZingTextPrimary,
                        focusedBorderColor = ZingNeonPink,
                        unfocusedBorderColor = ZingBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(displayName, bio) },
                colors = ButtonDefaults.buttonColors(containerColor = ZingNeonPink)
            ) {
                Text("Save Changes", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = ZingTextSecondary)
            }
        }
    )
}

@Composable
fun SwitchAccountDialog(
    users: List<UserEntity>,
    currentUserId: String,
    onDismiss: () -> Unit,
    onSelectUser: (String) -> Unit,
    onCreateNewAccount: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ZingDarkSurface,
        title = {
            Text("Switch Sinji Account", color = ZingTextPrimary, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                users.forEach { user ->
                    val isSelected = user.id == currentUserId
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) ZingCardSurface else Color.Transparent)
                            .clickable { onSelectUser(user.id) }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(if (user.role == "admin") ZingCyan else ZingNeonPink),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(user.displayName.take(1), color = Color.White, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(user.displayName, color = ZingTextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text("@${user.username} • ${user.role.uppercase()}", color = ZingTextMuted, fontSize = 11.sp)
                        }
                        if (isSelected) {
                            Text("Active", color = ZingCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Button(
                    onClick = onCreateNewAccount,
                    colors = ButtonDefaults.buttonColors(containerColor = ZingCardSurface, contentColor = ZingNeonPink),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("+ Create / Register New Account", fontWeight = FontWeight.Bold)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = ZingTextSecondary)
            }
        }
    )
}
