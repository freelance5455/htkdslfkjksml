package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.MemberEntity
import com.example.data.remote.FirebaseAuthManager
import com.example.data.remote.FirestoreRepository
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AddCommitteeMemberViewModel(
    application: Application
) : AndroidViewModel(application) {

    private val authManager = FirebaseAuthManager()
    private val firestoreRepo = FirestoreRepository.create(application)
    private val database = AppDatabase.getDatabase(application)
    private val memberDao = database.memberDao()

    val currentUser: StateFlow<FirebaseUser?> = authManager.authStateFlow()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = authManager.currentUser
        )

    val name = MutableStateFlow("")
    val designation = MutableStateFlow("")
    val customDesignation = MutableStateFlow("")
    val contactNumber = MutableStateFlow("")
    val wardNumber = MutableStateFlow("")
    val customWardNumber = MutableStateFlow("")
    val unit = MutableStateFlow("")
    val fbLink = MutableStateFlow("")

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _isSigningIn = MutableStateFlow(false)
    val isSigningIn: StateFlow<Boolean> = _isSigningIn.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _successMessage = MutableStateFlow<String?>(null)
    val successMessage: StateFlow<String?> = _successMessage.asStateFlow()

    fun onNameChange(value: String) {
        name.value = value
        _errorMessage.value = null
    }

    fun onDesignationChange(value: String) {
        designation.value = value
        _errorMessage.value = null
    }

    fun onCustomDesignationChange(value: String) {
        customDesignation.value = value
        _errorMessage.value = null
    }

    fun onContactNumberChange(value: String) {
        contactNumber.value = value
        _errorMessage.value = null
    }

    fun onWardNumberChange(value: String) {
        wardNumber.value = value
        _errorMessage.value = null
    }

    fun onCustomWardNumberChange(value: String) {
        customWardNumber.value = value
        _errorMessage.value = null
    }

    fun onUnitChange(value: String) {
        unit.value = value
        _errorMessage.value = null
    }

    fun onFbLinkChange(value: String) {
        fbLink.value = value
        _errorMessage.value = null
    }

    fun clearMessages() {
        _errorMessage.value = null
        _successMessage.value = null
    }

    fun resetForm() {
        name.value = ""
        designation.value = ""
        customDesignation.value = ""
        contactNumber.value = ""
        wardNumber.value = ""
        customWardNumber.value = ""
        unit.value = ""
        fbLink.value = ""
        _errorMessage.value = null
        _successMessage.value = null
    }

    fun signInWithGoogle(context: Context, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            _isSigningIn.value = true
            _errorMessage.value = null
            val result = authManager.signInWithGoogle(context)
            _isSigningIn.value = false
            result.onSuccess {
                _successMessage.value = "গুগল সাইন-ইন সফল হয়েছে!"
                onComplete()
            }.onFailure { err ->
                _errorMessage.value = "গুগল সাইন-ইন ব্যর্থ হয়েছে: ${err.message ?: "অজানা ত্রুটি"}"
            }
        }
    }

    fun signOut() {
        authManager.signOut()
        _successMessage.value = "সফলভাবে সাইন-আউট করা হয়েছে।"
    }

    fun submitForm(context: Context) {
        val cleanName = name.value.trim()
        val cleanContact = contactNumber.value.trim()
        val cleanUnit = unit.value.trim()

        val resolvedDesignation = when {
            designation.value == "+ অন্যান্য/নতুন পদ লিখুন" -> customDesignation.value.trim()
            designation.value.startsWith("--") -> ""
            else -> designation.value.trim()
        }

        val resolvedWard = when {
            wardNumber.value == "অন্যান্য ওয়ার্ড নম্বর" -> customWardNumber.value.trim()
            wardNumber.value.startsWith("--") -> ""
            else -> wardNumber.value.trim()
        }

        // 1. Validation
        if (cleanName.isBlank()) {
            _errorMessage.value = "অনুগ্রহ করে সদস্যের নাম লিখুন!"
            return
        }

        if (resolvedDesignation.isBlank()) {
            _errorMessage.value = "অনুগ্রহ করে পদবী নির্বাচন বা নতুন পদবী লিখুন!"
            return
        }

        if (cleanContact.isBlank()) {
            _errorMessage.value = "অনুগ্রহ করে যোগাযোগ/মোবাইল নম্বর লিখুন!"
            return
        }

        if (resolvedWard.isBlank()) {
            _errorMessage.value = "অনুগ্রহ করে ওয়ার্ড নম্বর নির্বাচন বা উল্লেখ করুন!"
            return
        }

        if (cleanUnit.isBlank() || cleanUnit.startsWith("--")) {
            _errorMessage.value = "অনুগ্রহ করে সাংগঠনিক ইউনিট নির্বাচন করুন!"
            return
        }

        // 2. Authentication check
        val user = currentUser.value
        if (user == null) {
            _errorMessage.value = "ক্লাউড ফায়ারস্টোরে তথ্য সংরক্ষণের জন্য প্রথমে গুগল দিয়ে সাইন-ইন করুন।"
            signInWithGoogle(context) {
                // If sign-in succeeds, attempt saving
                executeSave(
                    name = cleanName,
                    designation = resolvedDesignation,
                    contact = cleanContact,
                    ward = resolvedWard,
                    unit = cleanUnit,
                    fb = fbLink.value.trim(),
                    userId = authManager.currentUser?.uid.orEmpty()
                )
            }
            return
        }

        // 3. Save to Firestore and Room
        executeSave(
            name = cleanName,
            designation = resolvedDesignation,
            contact = cleanContact,
            ward = resolvedWard,
            unit = cleanUnit,
            fb = fbLink.value.trim(),
            userId = user.uid
        )
    }

    private fun executeSave(
        name: String,
        designation: String,
        contact: String,
        ward: String,
        unit: String,
        fb: String,
        userId: String
    ) {
        if (userId.isBlank()) {
            _errorMessage.value = "অথেনটিকেশন আইডি পাওয়া যায়নি। অনুগ্রহ করে পুনরায় সাইন-ইন করুন।"
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            _successMessage.value = null

            val today = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())

            val memberEntity = MemberEntity(
                type = "committee",
                union = unit,
                ward = ward,
                workerName = name,
                workerDesignation = designation,
                workerMobile = contact,
                workerFb = fb,
                otherName = name,
                otherDesignation = designation,
                otherMobile = contact,
                otherFb = fb,
                createdAt = today
            )

            val result = firestoreRepo.saveMember(memberEntity, userId)
            _isLoading.value = false

            result.onSuccess { docId ->
                // Also save to local Room database for offline cache and immediate visibility in Admin list
                try {
                    val memberRepo = com.example.data.repository.MemberRepository(
                        memberDao = database.memberDao(),
                        committeeDao = database.committeeDao(),
                        context = getApplication()
                    )
                    memberRepo.insertMember(memberEntity)
                } catch (e: Exception) {
                    // Non-fatal if local cache fails
                }

                _successMessage.value = "কমিটি সদস্য '$name' সফলভাবে Cloud Firestore-এ যুক্ত হয়েছে! (ID: $docId)"
                resetForm()
            }.onFailure { err ->
                _errorMessage.value = "Firestore-এ সংরক্ষণ ব্যর্থ হয়েছে: ${err.message ?: "সার্ভার এরর"}"
            }
        }
    }
}
