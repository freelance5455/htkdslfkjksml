package com.example.ui.components

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.outlined.AutoStories
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Quiz
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DopingPrimary
import com.example.ui.viewmodel.ScreenTab

data class NavItem(
  val tab: ScreenTab,
  val label: String,
  val selectedIcon: ImageVector,
  val unselectedIcon: ImageVector
)

@Composable
fun DopingBottomNavigation(
  currentTab: ScreenTab,
  onTabSelected: (ScreenTab) -> Unit,
  modifier: Modifier = Modifier
) {
  val items = listOf(
    NavItem(
      tab = ScreenTab.HOME,
      label = "Ana Sayfa",
      selectedIcon = Icons.Filled.Home,
      unselectedIcon = Icons.Outlined.Home
    ),
    NavItem(
      tab = ScreenTab.COACH_PLAN,
      label = "Planlayıcı",
      selectedIcon = Icons.Filled.CalendarMonth,
      unselectedIcon = Icons.Outlined.CalendarMonth
    ),
    NavItem(
      tab = ScreenTab.QUESTION_BANK,
      label = "Soru Bankası",
      selectedIcon = Icons.Filled.Quiz,
      unselectedIcon = Icons.Outlined.Quiz
    ),
    NavItem(
      tab = ScreenTab.LECTURES,
      label = "Konular",
      selectedIcon = Icons.Filled.AutoStories,
      unselectedIcon = Icons.Outlined.AutoStories
    ),
    NavItem(
      tab = ScreenTab.POMODORO,
      label = "Odak Sayacı",
      selectedIcon = Icons.Filled.Timer,
      unselectedIcon = Icons.Outlined.Timer
    )
  )

  NavigationBar(
    modifier = modifier
      .windowInsetsPadding(WindowInsets.navigationBars)
      .testTag("bottom_navigation_bar"),
    containerColor = MaterialTheme.colorScheme.surface,
    tonalElevation = 6.dp
  ) {
    items.forEach { item ->
      val selected = currentTab == item.tab
      NavigationBarItem(
        selected = selected,
        onClick = { onTabSelected(item.tab) },
        icon = {
          Icon(
            imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
            contentDescription = item.label,
            modifier = Modifier.size(24.dp)
          )
        },
        label = {
          Text(
            text = item.label,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
          )
        },
        colors = NavigationBarItemDefaults.colors(
          selectedIconColor = DopingPrimary,
          selectedTextColor = DopingPrimary,
          indicatorColor = MaterialTheme.colorScheme.primaryContainer,
          unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
          unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
        ),
        modifier = Modifier.testTag("nav_item_${item.tab.name.lowercase()}")
      )
    }
  }
}
