package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AddBox
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PersonPin
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.ArkPost
import com.example.data.model.BlockedUser
import com.example.data.model.FollowEdge
import com.example.data.model.FollowRequest
import com.example.data.model.FriendEdge
import com.example.data.model.ModerationReport
import com.example.data.model.NotificationItem
import com.example.data.model.PostDraft
import com.example.data.model.RestrictedUser
import com.example.data.model.StoryHighlight
import com.example.data.model.UserPrivateSettings
import com.example.data.model.UserProfile
import com.example.ui.components.ArkAvatarBadge
import com.example.ui.components.EmptyStateGlassCard
import com.example.ui.components.GlowingPillButton
import com.example.ui.components.LevelProgressPill
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.UserBadgeChip
import com.example.ui.theme.ArkThemeTokens
import com.example.util.ImageCompressionHelper
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileScreen(
    profile: UserProfile,
    myPosts: List<ArkPost>,
    myTaggedPosts: List<ArkPost>,
    pendingTagRequests: List<ArkPost>,
    savedPosts: List<ArkPost>,
    drafts: List<PostDraft>,
    myHighlights: List<StoryHighlight>,
    followers: List<FollowEdge>,
    following: List<FollowEdge>,
    myFriends: List<FriendEdge>,
    outgoingFollowRequests: List<FollowRequest>,
    myReactions: Map<String, String>,
    myPollVotes: Map<String, Int>,
    bookmarkedIds: Set<String>,
    onCheckUsername: suspend (String) -> Result<Boolean>,
    onSaveProfileDetails: (
        username: String,
        fullName: String,
        displayTag: String,
        bio: String,
        website: String,
        avatarPreset: String,
        profileTheme: String,
        imageBase64: String?
    ) -> Unit,
    onRenameHighlight: (String, String) -> Unit,
    onDeleteHighlight: (String) -> Unit,
    onApproveTag: (String) -> Unit,
    onDeclineTag: (String) -> Unit,
    onFollowUser: (UserProfile) -> Unit,
    onUnfollowUser: (String, String) -> Unit,
    onCancelFollowRequest: (String) -> Unit,
    onRemoveFollower: (String, String) -> Unit,
    onCreatePost: () -> Unit,
    onAddStory: () -> Unit,
    onOpenDraft: (PostDraft) -> Unit,
    onDeleteDraft: (String) -> Unit,
    onReaction: (ArkPost, String) -> Unit,
    onOpenComments: (ArkPost) -> Unit,
    onSharePost: (ArkPost) -> Unit,
    onToggleBookmark: (String) -> Unit,
    onVotePoll: (String, Int) -> Unit,
    onEditCaption: (ArkPost) -> Unit,
    onToggleCommentsDisabled: (ArkPost) -> Unit,
    onDeletePost: (String) -> Unit,
    onOpenMedia: (ArkPost, Int) -> Unit,
    onOpenUserProfile: (String) -> Unit,
    onHashtagClick: (String) -> Unit,
    onOpenLikers: (ArkPost) -> Unit,
    onOpenSettings: () -> Unit,
    onOpenNotifications: () -> Unit,
    onOpenLeaderboard: () -> Unit,
    onOpenChallenges: () -> Unit
) {
    val colors = ArkThemeTokens.colors
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Grid, 1: Posts, 2: Tagged, 3: Saved, 4: Drafts
    var showEditProfile by remember { mutableStateOf(false) }
    var activeHighlight by remember { mutableStateOf<StoryHighlight?>(null) }
    var connectionsDialogTab by remember { mutableStateOf<Int?>(null) }

    val tabLabels = listOf(
        "Grid",
        "Posts (${myPosts.size})",
        if (pendingTagRequests.isNotEmpty()) "Tagged (${pendingTagRequests.size})" else "Tagged",
        "Saved (${savedPosts.size})",
        "Drafts (${drafts.size})"
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Top Header Bar
        item(key = "profile_top_bar") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "@${profile.username}",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = colors.ink
                    )
                    if (profile.isPrivateAccount) {
                        Spacer(Modifier.width(6.dp))
                        Icon(Icons.Default.Lock, contentDescription = "Private account", tint = colors.ink2, modifier = Modifier.size(16.dp))
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onCreatePost, modifier = Modifier.testTag("profile_create_button")) {
                        Icon(Icons.Default.AddBox, contentDescription = "Create post", tint = colors.ink)
                    }
                    IconButton(onClick = onOpenNotifications, modifier = Modifier.testTag("profile_notifications_button")) {
                        Icon(Icons.Default.Notifications, contentDescription = "Notifications", tint = colors.ink)
                    }
                    IconButton(onClick = onOpenSettings, modifier = Modifier.testTag("profile_settings_button")) {
                        Icon(Icons.Default.Settings, contentDescription = "Privacy & Settings", tint = colors.ink)
                    }
                }
            }
        }

        // Instagram + Liquid Glass Profile Identity Card
        item(key = "profile_identity_card") {
            LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ArkAvatarBadge(
                        avatarPreset = profile.avatarPreset,
                        username = profile.username,
                        imageBase64 = profile.avatarImageBase64,
                        size = 78.dp,
                        isOnline = profile.isOnline,
                        showOnlineDot = profile.showOnlineStatus
                    )
                    Spacer(Modifier.width(16.dp))
                    Row(
                        modifier = Modifier.weight(1f),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        ProfileMetricItem(
                            value = maxOf(profile.postsCount, myPosts.size.toLong()).toString(),
                            label = "Posts",
                            onClick = { selectedTab = 1 }
                        )
                        ProfileMetricItem(
                            value = maxOf(profile.followersCount, followers.size.toLong()).toString(),
                            label = "Followers",
                            onClick = { connectionsDialogTab = 0 }
                        )
                        ProfileMetricItem(
                            value = maxOf(profile.followingCount, following.size.toLong()).toString(),
                            label = "Following",
                            onClick = { connectionsDialogTab = 1 }
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))
                Text(
                    text = profile.fullName.ifBlank { profile.displayTag },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.ink
                )
                Text(
                    text = "${profile.displayTag} • ${profile.friendsCount} Friends • ${profile.points} PTS",
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.accent
                )
                if (profile.bio.isNotBlank()) {
                    Spacer(Modifier.height(6.dp))
                    Text(profile.bio, style = MaterialTheme.typography.bodyMedium, color = colors.ink)
                }
                if (profile.website.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Link, contentDescription = null, tint = colors.accent, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(profile.website, style = MaterialTheme.typography.labelMedium, color = colors.accent, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }

                Spacer(Modifier.height(14.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { showEditProfile = true },
                        modifier = Modifier.weight(1f).height(44.dp).testTag("edit_profile_button")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Edit Profile")
                    }
                    OutlinedButton(
                        onClick = onOpenLeaderboard,
                        modifier = Modifier.weight(1f).height(44.dp).testTag("profile_leaderboard_button")
                    ) {
                        Text("Rankings")
                    }
                }
            }
        }

        // Story Highlights Row
        item(key = "profile_highlights") {
            HighlightsRow(
                highlights = myHighlights,
                isOwnProfile = true,
                onOpenHighlight = { activeHighlight = it },
                onCreateHint = onAddStory
            )
        }

        // Level Progress + Badges
        item(key = "profile_xp_badges") {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                LevelProgressPill(
                    level = profile.level,
                    xp = profile.xp,
                    points = profile.points,
                    modifier = Modifier.fillMaxWidth()
                )
                if (profile.badges.isNotEmpty()) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(profile.badges, key = { it }) { badge ->
                            UserBadgeChip(label = "★ $badge", accent = colors.gold)
                        }
                        item(key = "quests_link") {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = colors.accentSoft,
                                modifier = Modifier.clickable(onClick = onOpenChallenges)
                            ) {
                                Text(
                                    text = "View Quests →",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = colors.accent,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Profile Content Tabs
        item(key = "profile_tabs") {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(tabLabels.indices.toList(), key = { "ptab_$it" }) { idx ->
                    FilterChip(
                        selected = selectedTab == idx,
                        onClick = { selectedTab = idx },
                        leadingIcon = when (idx) {
                            0 -> ({ Icon(Icons.Default.GridOn, contentDescription = null, modifier = Modifier.size(15.dp)) })
                            2 -> ({ Icon(Icons.Default.PersonPin, contentDescription = null, modifier = Modifier.size(15.dp)) })
                            else -> null
                        },
                        label = { Text(tabLabels[idx]) },
                        modifier = Modifier.testTag("profile_tab_$idx")
                    )
                }
            }
        }

        when (selectedTab) {
            0 -> profileMediaGridItems(
                posts = myPosts,
                colors = colors,
                onOpenMedia = onOpenMedia,
                onCreatePost = onCreatePost,
                onOpenPostComments = onOpenComments
            )

            1 -> profilePostsItems(
                posts = myPosts,
                currentUserId = profile.userId,
                myReactions = myReactions,
                myPollVotes = myPollVotes,
                bookmarkedIds = bookmarkedIds,
                emptyTitle = "No Posts Yet",
                emptySubtitle = "Your photos, videos, polls, and squad memories appear here.",
                isSavedTab = false,
                onCreatePost = onCreatePost,
                onReaction = onReaction,
                onOpenComments = onOpenComments,
                onSharePost = onSharePost,
                onToggleBookmark = onToggleBookmark,
                onVotePoll = onVotePoll,
                onEditCaption = onEditCaption,
                onToggleCommentsDisabled = onToggleCommentsDisabled,
                onDeletePost = onDeletePost,
                onOpenMedia = onOpenMedia,
                onOpenUserProfile = onOpenUserProfile,
                onHashtagClick = onHashtagClick,
                onOpenLikers = onOpenLikers
            )

            2 -> profileTaggedItems(
                taggedPosts = myTaggedPosts,
                pendingTags = pendingTagRequests,
                isOwnProfile = true,
                colors = colors,
                onApproveTag = onApproveTag,
                onDeclineTag = onDeclineTag,
                onOpenMedia = onOpenMedia,
                onOpenComments = onOpenComments
            )

            3 -> profilePostsItems(
                posts = savedPosts,
                currentUserId = profile.userId,
                myReactions = myReactions,
                myPollVotes = myPollVotes,
                bookmarkedIds = bookmarkedIds,
                emptyTitle = "Nothing Saved Yet",
                emptySubtitle = "Bookmark posts from Home Feed or Explore — visible only to you.",
                isSavedTab = true,
                onCreatePost = onCreatePost,
                onReaction = onReaction,
                onOpenComments = onOpenComments,
                onSharePost = onSharePost,
                onToggleBookmark = onToggleBookmark,
                onVotePoll = onVotePoll,
                onEditCaption = onEditCaption,
                onToggleCommentsDisabled = onToggleCommentsDisabled,
                onDeletePost = onDeletePost,
                onOpenMedia = onOpenMedia,
                onOpenUserProfile = onOpenUserProfile,
                onHashtagClick = onHashtagClick,
                onOpenLikers = onOpenLikers
            )

            else -> profileDraftsItems(
                drafts = drafts,
                colors = colors,
                onOpenDraft = onOpenDraft,
                onDeleteDraft = onDeleteDraft,
                onCreatePost = onCreatePost
            )
        }

        item { Spacer(Modifier.height(72.dp)) }
    }

    if (showEditProfile) {
        EditProfileDialog(
            profile = profile,
            onCheckUsername = onCheckUsername,
            onSave = { username, fullName, displayTag, bio, website, preset, theme, imgB64 ->
                onSaveProfileDetails(username, fullName, displayTag, bio, website, preset, theme, imgB64)
                showEditProfile = false
            },
            onDismiss = { showEditProfile = false }
        )
    }

    if (activeHighlight != null) {
        HighlightViewerDialog(
            highlight = activeHighlight!!,
            isOwner = true,
            onRename = { newTitle -> onRenameHighlight(activeHighlight!!.id, newTitle) },
            onDelete = { onDeleteHighlight(activeHighlight!!.id) },
            onDismiss = { activeHighlight = null }
        )
    }

    if (connectionsDialogTab != null) {
        FollowConnectionsDialog(
            title = "@${profile.username}",
            initialTab = connectionsDialogTab!!,
            followers = followers,
            following = following,
            currentUser = profile,
            myFollowing = following,
            outgoingFollowRequests = outgoingFollowRequests,
            isOwnProfile = true,
            onOpenUserProfile = { uid ->
                connectionsDialogTab = null
                onOpenUserProfile(uid)
            },
            onFollowEdge = { edge ->
                onFollowUser(
                    UserProfile(
                        userId = edge.peerUid,
                        username = edge.peerUsername,
                        fullName = edge.peerFullName,
                        avatarPreset = edge.peerAvatar,
                        isPrivateAccount = false
                    )
                )
            },
            onUnfollowUser = onUnfollowUser,
            onCancelFollowRequest = onCancelFollowRequest,
            onRemoveFollower = onRemoveFollower,
            onDismiss = { connectionsDialogTab = null }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun EditProfileDialog(
    profile: UserProfile,
    onCheckUsername: suspend (String) -> Result<Boolean>,
    onSave: (
        username: String,
        fullName: String,
        displayTag: String,
        bio: String,
        website: String,
        avatarPreset: String,
        profileTheme: String,
        imageBase64: String?
    ) -> Unit,
    onDismiss: () -> Unit
) {
    val colors = ArkThemeTokens.colors
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var username by remember(profile.username) { mutableStateOf(profile.username) }
    var fullName by remember(profile.fullName) { mutableStateOf(profile.fullName) }
    var displayTag by remember(profile.displayTag) { mutableStateOf(profile.displayTag) }
    var bio by remember(profile.bio) { mutableStateOf(profile.bio) }
    var website by remember(profile.website) { mutableStateOf(profile.website) }
    var avatarPreset by remember(profile.avatarPreset) { mutableStateOf(profile.avatarPreset) }
    var profileTheme by remember(profile.profileTheme) { mutableStateOf(profile.profileTheme) }
    var pendingAvatarBase64 by remember { mutableStateOf<String?>(null) }

    var usernameAvailable by remember { mutableStateOf(true) }
    var usernameStatus by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(username) {
        val clean = username.trim().lowercase().replace(Regex("[^a-z0-9_]"), "")
        if (clean == profile.username) {
            usernameAvailable = true
            usernameStatus = null
            return@LaunchedEffect
        }
        if (clean.length < 3) {
            usernameAvailable = false
            usernameStatus = "Min 3 characters"
            return@LaunchedEffect
        }
        usernameStatus = "Checking availability..."
        delay(320L)
        onCheckUsername(clean).onSuccess { ok ->
            usernameAvailable = ok
            usernameStatus = if (ok) "@$clean is available" else "@$clean is already taken"
        }.onFailure { err ->
            usernameAvailable = false
            usernameStatus = err.message ?: "Invalid username"
        }
    }

    val avatarPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                pendingAvatarBase64 = ImageCompressionHelper.compressUriToBase64(context, uri, maxDim = 200)
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Profile") },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().heightIn(max = 430.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        ArkAvatarBadge(
                            avatarPreset = avatarPreset,
                            username = username.ifBlank { profile.username },
                            imageBase64 = pendingAvatarBase64 ?: profile.avatarImageBase64,
                            size = 56.dp
                        )
                        OutlinedButton(
                            onClick = {
                                avatarPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            }
                        ) {
                            Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(if (pendingAvatarBase64 != null) "Photo Selected ✓" else "Change Photo")
                        }
                    }
                }
                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        listOf("prism_cyan", "cyber_violet", "solar_gold", "emerald_nova", "coral_pulse").forEach { key ->
                            val selected = avatarPreset == key
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .border(
                                        width = if (selected) 2.dp else 1.dp,
                                        color = if (selected) colors.accent else colors.hairline,
                                        shape = RoundedCornerShape(12.dp)
                                    )
                                    .clickable { avatarPreset = key }
                                    .padding(4.dp)
                            ) {
                                ArkAvatarBadge(avatarPreset = key, username = profile.username, size = 34.dp)
                            }
                        }
                    }
                }
                item {
                    OutlinedTextField(
                        value = username,
                        onValueChange = { username = it.lowercase().replace(Regex("[^a-z0-9_]"), "").take(24) },
                        label = { Text("Username") },
                        singleLine = true,
                        supportingText = usernameStatus?.let { msg ->
                            { Text(msg, color = if (usernameAvailable) colors.emerald else colors.coral) }
                        },
                        modifier = Modifier.fillMaxWidth().testTag("edit_username_input")
                    )
                }
                item {
                    OutlinedTextField(
                        value = fullName,
                        onValueChange = { fullName = it.take(40) },
                        label = { Text("Full Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    OutlinedTextField(
                        value = displayTag,
                        onValueChange = { displayTag = it.take(30) },
                        label = { Text("Display Tag") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    OutlinedTextField(
                        value = bio,
                        onValueChange = { bio = it.take(160) },
                        label = { Text("Bio") },
                        maxLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    OutlinedTextField(
                        value = website,
                        onValueChange = { website = it.take(120) },
                        label = { Text("Website or Social Link") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("liquid_light", "obsidian_glass", "aurora_cyan").forEach { t ->
                            FilterChip(
                                selected = profileTheme == t,
                                onClick = { profileTheme = t },
                                label = { Text(t.replace("_", " ")) }
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = usernameAvailable && username.length >= 3,
                onClick = {
                    onSave(username, fullName, displayTag, bio, website, avatarPreset, profileTheme, pendingAvatarBase64)
                }
            ) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun NotificationsScreen(
    notifications: List<NotificationItem>,
    privateSettings: UserPrivateSettings?,
    onBack: () -> Unit,
    onMarkRead: (String) -> Unit,
    onSavePreferences: (UserPrivateSettings) -> Unit
) {
    BackHandler(onBack = onBack)
    val colors = ArkThemeTokens.colors
    var prefs by remember(privateSettings) {
        mutableStateOf(privateSettings ?: UserPrivateSettings())
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Surface(color = colors.surface) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = colors.ink)
                }
                Text("Notifications & Quiet Hours", style = MaterialTheme.typography.titleLarge, color = colors.ink)
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                LiquidGlassCard(modifier = Modifier.fillMaxWidth(), accentColor = colors.violet) {
                    Text("Notification Preferences", style = MaterialTheme.typography.titleMedium, color = colors.ink)
                    Spacer(Modifier.height(8.dp))
                    ToggleRow("Quiet Hours (10 PM – 7 AM)", prefs.quietHoursEnabled) {
                        prefs = prefs.copy(quietHoursEnabled = it)
                    }
                    ToggleRow("Friend & Follow Requests", prefs.notifyFriendRequests) {
                        prefs = prefs.copy(notifyFriendRequests = it)
                    }
                    ToggleRow("Group & Game Invites", prefs.notifyGroupInvites) {
                        prefs = prefs.copy(notifyGroupInvites = it, notifyGameInvites = it)
                    }
                    ToggleRow("Challenges & Achievements", prefs.notifyChallenges) {
                        prefs = prefs.copy(notifyChallenges = it, notifyAchievements = it)
                    }
                    Spacer(Modifier.height(8.dp))
                    GlowingPillButton(
                        text = "Save Notification Rules",
                        onClick = { onSavePreferences(prefs) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            item {
                Text("Notification History (${notifications.size})", style = MaterialTheme.typography.titleMedium, color = colors.ink)
            }

            if (notifications.isEmpty()) {
                item {
                    EmptyStateGlassCard(
                        icon = Icons.Default.Notifications,
                        title = "All Caught Up",
                        subtitle = "Follow requests, game invites, and achievement alerts appear here."
                    )
                }
            } else {
                items(notifications, key = { it.id }) { n ->
                    LiquidGlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        accentColor = if (!n.isRead) colors.accent else null,
                        onClick = { if (!n.isRead) onMarkRead(n.id) }
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(n.title, style = MaterialTheme.typography.titleSmall, color = colors.ink)
                            if (!n.isRead) UserBadgeChip(label = "NEW", accent = colors.accent)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text(n.body, style = MaterialTheme.typography.bodySmall, color = colors.ink2)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsAndPrivacyScreen(
    profile: UserProfile,
    themeMode: String,
    isAdmin: Boolean,
    blockedUsers: List<BlockedUser> = emptyList(),
    restrictedUsers: List<RestrictedUser> = emptyList(),
    followers: List<FollowEdge> = emptyList(),
    friends: List<FriendEdge> = emptyList(),
    onBack: () -> Unit,
    onChangeThemeMode: (String) -> Unit,
    onSavePrivacy: (
        isPrivate: Boolean,
        allowRequests: String,
        showOnline: Boolean,
        optOutLeaderboard: Boolean,
        allowMessagesFrom: String,
        requireTagApproval: Boolean,
        hiddenStoryFromUids: List<String>
    ) -> Unit,
    onOpenFriends: () -> Unit = {},
    onOpenNotifications: () -> Unit = {},
    onUnblockUser: (String) -> Unit = {},
    onUnrestrictUser: (String) -> Unit = {},
    onSubmitSupportFeedback: (String, String) -> Unit = { _, _ -> },
    onOpenAdmin: () -> Unit,
    onSignOut: () -> Unit,
    onDeleteAccount: () -> Unit
) {
    BackHandler(onBack = onBack)
    val colors = ArkThemeTokens.colors

    var isPrivate by remember(profile.isPrivateAccount) { mutableStateOf(profile.isPrivateAccount) }
    var allowRequests by remember(profile.allowFriendRequests) { mutableStateOf(profile.allowFriendRequests) }
    var allowMessagesFrom by remember(profile.allowMessagesFrom) { mutableStateOf(profile.allowMessagesFrom) }
    var requireTagApproval by remember(profile.requireTagApproval) { mutableStateOf(profile.requireTagApproval) }
    var showOnline by remember(profile.showOnlineStatus) { mutableStateOf(profile.showOnlineStatus) }
    var optOutBoard by remember(profile.optOutLeaderboard) { mutableStateOf(profile.optOutLeaderboard) }
    val hiddenStoryUids = remember(profile.hiddenStoryFromUids) {
        mutableStateListOf<String>().apply { addAll(profile.hiddenStoryFromUids) }
    }

    var showBlockedDialog by remember { mutableStateOf(false) }
    var showRestrictedDialog by remember { mutableStateOf(false) }
    var showHideStoryDialog by remember { mutableStateOf(false) }
    var showSupportDialog by remember { mutableStateOf(false) }
    var supportTopic by remember { mutableStateOf("App Feedback") }
    var supportDetails by remember { mutableStateOf("") }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    val storyHideCandidates = remember(followers, friends) {
        val map = linkedMapOf<String, String>()
        friends.forEach { map[it.friendUid] = it.friendUsername }
        followers.forEach { map.putIfAbsent(it.peerUid, it.peerUsername) }
        map.entries.map { it.key to it.value }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Surface(color = colors.surface) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = colors.ink)
                }
                Text("Settings & Privacy", style = MaterialTheme.typography.titleLarge, color = colors.ink)
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Palette, contentDescription = null, tint = colors.accent)
                        Spacer(Modifier.width(8.dp))
                        Text("Appearance", style = MaterialTheme.typography.titleMedium, color = colors.ink)
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("system" to "System", "light" to "Light", "dark" to "Dark").forEach { (mode, label) ->
                            FilterChip(
                                selected = themeMode == mode,
                                onClick = { onChangeThemeMode(mode) },
                                label = { Text(label) }
                            )
                        }
                    }
                }
            }

            item {
                LiquidGlassCard(modifier = Modifier.fillMaxWidth(), accentColor = colors.emerald) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = colors.emerald)
                        Spacer(Modifier.width(8.dp))
                        Text("Privacy & Safety Controls", style = MaterialTheme.typography.titleMedium, color = colors.ink)
                    }
                    Spacer(Modifier.height(10.dp))
                    ToggleRow("Private Account (Approve Followers)", isPrivate) { isPrivate = it }
                    ToggleRow("Require Approval Before Tags Appear", requireTagApproval) { requireTagApproval = it }
                    ToggleRow("Show Online Activity Status", showOnline) { showOnline = it }
                    ToggleRow("Opt Out of Public Leaderboards", optOutBoard) { optOutBoard = it }

                    Spacer(Modifier.height(8.dp))
                    Text("Who can send friend requests?", style = MaterialTheme.typography.labelMedium, color = colors.ink2)
                    Spacer(Modifier.height(4.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("everyone" to "Everyone", "group_members" to "Squads", "nobody" to "Nobody").forEach { (key, label) ->
                            FilterChip(
                                selected = allowRequests == key,
                                onClick = { allowRequests = key },
                                label = { Text(label) }
                            )
                        }
                    }

                    Spacer(Modifier.height(8.dp))
                    Text("Who can message you directly?", style = MaterialTheme.typography.labelMedium, color = colors.ink2)
                    Spacer(Modifier.height(4.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(
                            "everyone" to "Everyone",
                            "followers" to "Following",
                            "friends" to "Friends",
                            "nobody" to "Nobody"
                        ).forEach { (key, label) ->
                            FilterChip(
                                selected = allowMessagesFrom == key,
                                onClick = { allowMessagesFrom = key },
                                label = { Text(label) }
                            )
                        }
                    }

                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = { showHideStoryDialog = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Hide Story From (${hiddenStoryUids.size} people)")
                    }

                    Spacer(Modifier.height(12.dp))
                    GlowingPillButton(
                        text = "Save Privacy Controls",
                        accent = colors.emerald,
                        modifier = Modifier.fillMaxWidth().testTag("save_privacy_button"),
                        onClick = {
                            onSavePrivacy(
                                isPrivate,
                                allowRequests,
                                showOnline,
                                optOutBoard,
                                allowMessagesFrom,
                                requireTagApproval,
                                hiddenStoryUids.toList()
                            )
                        }
                    )
                }
            }

            item {
                LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = colors.accent)
                        Spacer(Modifier.width(8.dp))
                        Text("People, Safety & Notifications", style = MaterialTheme.typography.titleMedium, color = colors.ink)
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = onOpenFriends, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.People, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Manage Friends & Requests")
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { showBlockedDialog = true }, modifier = Modifier.weight(1f)) {
                            Text("Blocked (${blockedUsers.size})")
                        }
                        OutlinedButton(onClick = { showRestrictedDialog = true }, modifier = Modifier.weight(1f)) {
                            Text("Restricted (${restrictedUsers.size})")
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = onOpenNotifications, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Notifications, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Notification Rules & Quiet Hours")
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { showSupportDialog = true }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.AutoMirrored.Filled.HelpOutline, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Help & Report a Problem")
                    }
                }
            }

            if (isAdmin) {
                item {
                    LiquidGlassCard(modifier = Modifier.fillMaxWidth(), accentColor = colors.coral) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = colors.coral)
                            Spacer(Modifier.width(8.dp))
                            Text("Admin & Moderation Console", style = MaterialTheme.typography.titleMedium, color = colors.ink)
                        }
                        Spacer(Modifier.height(8.dp))
                        GlowingPillButton(
                            text = "Open Moderation Dashboard",
                            accent = colors.coral,
                            onClick = onOpenAdmin,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            item {
                LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Account Session", style = MaterialTheme.typography.titleMedium, color = colors.ink)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "ARK stores zero PII in public profiles and keeps private settings strictly encrypted and user-scoped.",
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.ink2
                    )
                    Spacer(Modifier.height(12.dp))
                    OutlinedButton(
                        onClick = onSignOut,
                        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("sign_out_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Sign Out")
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = { showDeleteConfirm = true },
                        modifier = Modifier.fillMaxWidth().height(48.dp)
                    ) {
                        Icon(Icons.Default.DeleteForever, contentDescription = null, tint = colors.coral)
                        Spacer(Modifier.width(8.dp))
                        Text("Delete Account & Data", color = colors.coral)
                    }
                }
            }
        }
    }

    if (showBlockedDialog) {
        AlertDialog(
            onDismissRequest = { showBlockedDialog = false },
            title = { Text("Blocked Users (${blockedUsers.size})") },
            text = {
                if (blockedUsers.isEmpty()) {
                    Text("No blocked accounts.")
                } else {
                    LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 260.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(blockedUsers, key = { it.blockedUid }) { b ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("@${b.blockedUsername}", style = MaterialTheme.typography.bodyMedium)
                                OutlinedButton(onClick = { onUnblockUser(b.blockedUid) }) { Text("Unblock") }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showBlockedDialog = false }) { Text("Close") } }
        )
    }

    if (showRestrictedDialog) {
        AlertDialog(
            onDismissRequest = { showRestrictedDialog = false },
            title = { Text("Restricted Accounts (${restrictedUsers.size})") },
            text = {
                if (restrictedUsers.isEmpty()) {
                    Text("No restricted accounts.")
                } else {
                    LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 260.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(restrictedUsers, key = { it.restrictedUid }) { r ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("@${r.restrictedUsername}", style = MaterialTheme.typography.bodyMedium)
                                OutlinedButton(onClick = { onUnrestrictUser(r.restrictedUid) }) { Text("Unrestrict") }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showRestrictedDialog = false }) { Text("Close") } }
        )
    }

    if (showHideStoryDialog) {
        AlertDialog(
            onDismissRequest = { showHideStoryDialog = false },
            title = { Text("Hide Story From") },
            text = {
                if (storyHideCandidates.isEmpty()) {
                    Text("Followers and friends will appear here once connected.")
                } else {
                    LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 260.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(storyHideCandidates, key = { it.first }) { (uid, uname) ->
                            val hidden = hiddenStoryUids.contains(uid)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { if (hidden) hiddenStoryUids.remove(uid) else hiddenStoryUids.add(uid) }
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("@$uname")
                                Switch(
                                    checked = hidden,
                                    onCheckedChange = { if (it) { if (!hidden) hiddenStoryUids.add(uid) } else hiddenStoryUids.remove(uid) }
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showHideStoryDialog = false }) { Text("Done (Tap Save Privacy to apply)") }
            }
        )
    }

    if (showSupportDialog) {
        AlertDialog(
            onDismissRequest = { showSupportDialog = false },
            title = { Text("Help & Report a Problem") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = supportTopic,
                        onValueChange = { supportTopic = it.take(80) },
                        label = { Text("Topic") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = supportDetails,
                        onValueChange = { supportDetails = it.take(300) },
                        label = { Text("Describe the issue or feedback") },
                        maxLines = 4,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = supportDetails.trim().length >= 5,
                    onClick = {
                        onSubmitSupportFeedback(supportTopic, supportDetails.trim())
                        supportDetails = ""
                        showSupportDialog = false
                    }
                ) { Text("Send") }
            },
            dismissButton = {
                TextButton(onClick = { showSupportDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete Account Data?") },
            text = { Text("This permanently deletes your ARK profile, private settings, follow/friend edges, notifications, and challenge progress.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteConfirm = false
                        onDeleteAccount()
                    }
                ) { Text("Delete Permanently", color = colors.coral) }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun AdminModerationScreen(
    reports: List<ModerationReport>,
    users: List<UserProfile>,
    onBack: () -> Unit,
    onResolveReport: (reportId: String, status: String) -> Unit,
    onToggleRestrictUser: (uid: String, restrict: Boolean) -> Unit,
    onPublishChallenge: (title: String, desc: String, category: String, difficulty: String, freq: String, pts: Long) -> Unit
) {
    BackHandler(onBack = onBack)
    val colors = ArkThemeTokens.colors
    var chTitle by remember { mutableStateOf("") }
    var chDesc by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize()) {
        Surface(color = colors.surface) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = colors.ink)
                }
                Text("ARK Admin & Safety Console", style = MaterialTheme.typography.titleLarge, color = colors.coral)
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                LiquidGlassCard(modifier = Modifier.fillMaxWidth(), accentColor = colors.accent) {
                    Text("Live Platform Snapshot", style = MaterialTheme.typography.titleMedium, color = colors.ink)
                    Spacer(Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        ProfileMetricItem(users.size.toString(), "Active Users", null)
                        ProfileMetricItem(reports.count { it.status == "open" }.toString(), "Open Reports", null)
                        ProfileMetricItem(users.count { it.isRestricted }.toString(), "Restricted", null)
                    }
                }
            }

            item {
                LiquidGlassCard(modifier = Modifier.fillMaxWidth(), accentColor = colors.emerald) {
                    Text("Publish Safe Real-Life Challenge", style = MaterialTheme.typography.titleMedium, color = colors.ink)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = chTitle,
                        onValueChange = { chTitle = it.take(80) },
                        label = { Text("Challenge Title") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = chDesc,
                        onValueChange = { chDesc = it.take(300) },
                        label = { Text("Safe Description") },
                        maxLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    GlowingPillButton(
                        text = "Publish (+60 PTS)",
                        enabled = chTitle.trim().length >= 3 && chDesc.trim().length >= 5,
                        onClick = {
                            onPublishChallenge(chTitle, chDesc, "Friendship", "Easy", "Daily", 60L)
                            chTitle = ""
                            chDesc = ""
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            item {
                Text("Moderation Reports (${reports.size})", style = MaterialTheme.typography.titleMedium, color = colors.ink)
            }
            items(reports, key = { it.id }) { rep ->
                LiquidGlassCard(modifier = Modifier.fillMaxWidth(), accentColor = if (rep.status == "open") colors.coral else null) {
                    Text("${rep.targetType.uppercase()} • ${rep.reason}", style = MaterialTheme.typography.titleSmall, color = colors.ink)
                    Text("Target ID: ${rep.targetId} • Status: ${rep.status}", style = MaterialTheme.typography.bodySmall, color = colors.ink2)
                    if (!rep.details.isNullOrBlank()) {
                        Text(rep.details, style = MaterialTheme.typography.bodySmall, color = colors.ink2)
                    }
                    if (rep.status == "open") {
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { onResolveReport(rep.id, "resolved") }) { Text("Resolve") }
                            OutlinedButton(onClick = { onResolveReport(rep.id, "dismissed") }) { Text("Dismiss") }
                        }
                    }
                }
            }

            item {
                Text("User Management (${users.size})", style = MaterialTheme.typography.titleMedium, color = colors.ink)
            }
            items(users.take(15), key = { it.userId }) { u ->
                LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("@${u.username}", style = MaterialTheme.typography.titleSmall, color = colors.ink)
                            Text("LVL ${u.level} • ${u.points} PTS • ${if (u.isRestricted) "RESTRICTED" else "Active"}", style = MaterialTheme.typography.bodySmall, color = if (u.isRestricted) colors.coral else colors.emerald)
                        }
                        OutlinedButton(onClick = { onToggleRestrictUser(u.userId, !u.isRestricted) }) {
                            Text(if (u.isRestricted) "Unrestrict" else "Restrict")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ToggleRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    val colors = ArkThemeTokens.colors
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = colors.ink, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
