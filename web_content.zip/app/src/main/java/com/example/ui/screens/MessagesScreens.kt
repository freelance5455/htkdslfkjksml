package com.example.ui.screens

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AddComment
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.DirectConversation
import com.example.data.model.DirectMessage
import com.example.data.model.FollowEdge
import com.example.data.model.FriendEdge
import com.example.data.model.UserProfile
import com.example.ui.components.ArkAvatarBadge
import com.example.ui.components.ArkVideoPlayerView
import com.example.ui.components.EmptyStateGlassCard
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.formatPostTimestamp
import com.example.ui.theme.ArkThemeTokens
import com.example.util.ImageCompressionHelper
import com.example.util.PreparedArkVideo
import com.example.util.rememberDecodedImageBitmap
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun MessagesInboxScreen(
    currentUser: UserProfile,
    activeConversations: List<DirectConversation>,
    messageRequests: List<DirectConversation>,
    following: List<FollowEdge>,
    friends: List<FriendEdge>,
    userSearchResults: List<UserProfile>,
    onBack: () -> Unit,
    onOpenConversation: (String) -> Unit,
    onSearchUsers: (String) -> Unit,
    onStartChatWithUser: (UserProfile) -> Unit,
    onAcceptRequest: (String) -> Unit,
    onDeclineRequest: (String) -> Unit
) {
    BackHandler(onBack = onBack)
    val colors = ArkThemeTokens.colors
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Chats, 1: Requests
    var searchFilter by remember { mutableStateOf("") }
    var showNewChatDialog by remember { mutableStateOf(false) }
    var newChatQuery by remember { mutableStateOf("") }

    LaunchedEffect(newChatQuery, showNewChatDialog) {
        if (showNewChatDialog && newChatQuery.trim().isNotEmpty()) {
            delay(250L)
            onSearchUsers(newChatQuery.trim())
        }
    }

    val currentList = remember(selectedTab, activeConversations, messageRequests, searchFilter, currentUser.userId) {
        val base = if (selectedTab == 0) activeConversations else messageRequests
        val q = searchFilter.trim().lowercase()
        if (q.isBlank()) base
        else base.filter { conv ->
            val otherUid = conv.participantUids.firstOrNull { it != currentUser.userId } ?: ""
            val peerName = conv.participantNames[otherUid].orEmpty().lowercase()
            peerName.contains(q) || conv.lastMessageText.lowercase().contains(q)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Surface(color = colors.surface) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onBack, modifier = Modifier.testTag("dm_inbox_back")) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = colors.ink)
                        }
                        Column {
                            Text("Messages", style = MaterialTheme.typography.titleLarge, color = colors.ink)
                            Text("@${currentUser.username}", style = MaterialTheme.typography.labelSmall, color = colors.ink2)
                        }
                    }
                    IconButton(
                        onClick = { showNewChatDialog = true },
                        modifier = Modifier.testTag("dm_new_chat_button")
                    ) {
                        Icon(Icons.Default.AddComment, contentDescription = "New message", tint = colors.accent)
                    }
                }
                OutlinedTextField(
                    value = searchFilter,
                    onValueChange = { searchFilter = it.take(40) },
                    placeholder = { Text("Filter conversations...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = colors.ink2) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }

        TabRow(selectedTabIndex = selectedTab, containerColor = colors.surface) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Chats (${activeConversations.size})") })
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Requests (${messageRequests.size})") })
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (currentList.isEmpty()) {
                item {
                    EmptyStateGlassCard(
                        icon = Icons.AutoMirrored.Filled.Chat,
                        title = if (selectedTab == 0) "No Direct Messages Yet" else "No Message Requests",
                        subtitle = if (selectedTab == 0) "Tap the new message button above or Message someone from their profile."
                        else "Requests from people outside your direct allow-list appear here.",
                        actionLabel = if (selectedTab == 0) "New Message" else null,
                        onAction = if (selectedTab == 0) ({ showNewChatDialog = true }) else null
                    )
                }
            } else {
                items(currentList, key = { it.id }) { conv ->
                    val otherUid = conv.participantUids.firstOrNull { it != currentUser.userId } ?: ""
                    val peerName = conv.participantNames[otherUid] ?: "player"
                    val peerAvatar = conv.participantAvatars[otherUid] ?: "prism_cyan"
                    val unread = (conv.unreadCounts[currentUser.userId] ?: 0L).toInt()
                    val isTyping = (conv.typingUids[otherUid] ?: 0L) > System.currentTimeMillis() - 8000L

                    LiquidGlassCard(
                        modifier = Modifier.fillMaxWidth().testTag("dm_conv_${conv.id}"),
                        accentColor = if (unread > 0) colors.accent else null,
                        onClick = { onOpenConversation(conv.id) }
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                ArkAvatarBadge(avatarPreset = peerAvatar, username = peerName, size = 46.dp)
                                Spacer(Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("@$peerName", style = MaterialTheme.typography.titleSmall, color = colors.ink, maxLines = 1)
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            text = formatPostTimestamp(conv.lastMessageAt),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = colors.ink3
                                        )
                                    }
                                    Text(
                                        text = when {
                                            isTyping -> "Typing..."
                                            conv.lastMessageText.isNotBlank() -> conv.lastMessageText
                                            else -> "Start chatting"
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (isTyping) colors.accent else if (unread > 0) colors.ink else colors.ink2,
                                        fontWeight = if (unread > 0) FontWeight.SemiBold else FontWeight.Normal,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            if (unread > 0) {
                                Badge(containerColor = colors.accent) {
                                    Text(unread.coerceAtMost(99).toString(), color = Color.White)
                                }
                            }
                        }

                        if (selectedTab == 1) {
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { onDeclineRequest(conv.id) }, modifier = Modifier.weight(1f)) {
                                    Text("Decline", color = colors.coral)
                                }
                                OutlinedButton(onClick = { onAcceptRequest(conv.id) }, modifier = Modifier.weight(1f)) {
                                    Text("Accept", color = colors.emerald)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showNewChatDialog) {
        val suggested = remember(friends, following, userSearchResults, newChatQuery) {
            if (newChatQuery.trim().isNotEmpty()) {
                userSearchResults
            } else {
                val map = linkedMapOf<String, UserProfile>()
                friends.forEach {
                    map[it.friendUid] = UserProfile(
                        userId = it.friendUid,
                        username = it.friendUsername,
                        avatarPreset = it.friendAvatar
                    )
                }
                following.forEach {
                    map.putIfAbsent(
                        it.peerUid,
                        UserProfile(
                            userId = it.peerUid,
                            username = it.peerUsername,
                            fullName = it.peerFullName,
                            avatarPreset = it.peerAvatar
                        )
                    )
                }
                map.values.toList()
            }
        }

        AlertDialog(
            onDismissRequest = { showNewChatDialog = false },
            title = { Text("New Message") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = newChatQuery,
                        onValueChange = { newChatQuery = it.take(30) },
                        label = { Text("Search @username") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (suggested.isEmpty()) {
                        Text("Search by username or connect with friends first.", style = MaterialTheme.typography.bodySmall, color = colors.ink2)
                    } else {
                        LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 260.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(suggested, key = { it.userId }) { u ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            showNewChatDialog = false
                                            onStartChatWithUser(u)
                                        }
                                        .padding(vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    ArkAvatarBadge(avatarPreset = u.avatarPreset, username = u.username, size = 36.dp)
                                    Spacer(Modifier.width(10.dp))
                                    Text("@${u.username}", style = MaterialTheme.typography.titleSmall, color = colors.ink)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showNewChatDialog = false }) { Text("Close") }
            }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DirectChatScreen(
    currentUser: UserProfile,
    conversation: DirectConversation?,
    messages: List<DirectMessage>,
    onBack: () -> Unit,
    onOpenUserProfile: (String) -> Unit,
    onSendMessage: (
        text: String,
        imageBase64: String?,
        videoThumb: String?,
        videoDurMs: Long,
        videoChunks: List<String>,
        replyToId: String?,
        replyToPreview: String?
    ) -> Unit,
    onAcceptRequest: (String) -> Unit,
    onDeclineRequest: (String) -> Unit,
    onBlockUser: (String, String) -> Unit,
    onMarkRead: (String) -> Unit,
    onSetTyping: (String, Boolean) -> Unit,
    onReactMessage: (String, String) -> Unit,
    onDeleteMessage: (String) -> Unit,
    onLoadVideoFile: suspend (Context, String, String) -> File?
) {
    BackHandler(onBack = onBack)
    val colors = ArkThemeTokens.colors
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    if (conversation == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            TextButton(onClick = onBack) { Text("Back to Messages") }
        }
        return
    }

    val peerUid = conversation.participantUids.firstOrNull { it != currentUser.userId } ?: ""
    val peerName = conversation.participantNames[peerUid] ?: "player"
    val peerAvatar = conversation.participantAvatars[peerUid] ?: "prism_cyan"
    val peerTyping = (conversation.typingUids[peerUid] ?: 0L) > System.currentTimeMillis() - 8000L
    val peerReadAtMs = conversation.readAtMillis[peerUid] ?: 0L
    val isIncomingRequest = conversation.status == "request" && conversation.requesterUid != currentUser.userId

    var inputText by remember(conversation.id) { mutableStateOf("") }
    var pendingImageB64 by remember(conversation.id) { mutableStateOf<String?>(null) }
    var pendingVideo by remember(conversation.id) { mutableStateOf<PreparedArkVideo?>(null) }
    var isPreparingMedia by remember(conversation.id) { mutableStateOf(false) }
    var replyTarget by remember(conversation.id) { mutableStateOf<DirectMessage?>(null) }
    var mediaError by remember { mutableStateOf<String?>(null) }
    var playingVideoMsgId by remember { mutableStateOf<String?>(null) }
    var playingVideoThumb by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(conversation.id, messages.size) {
        onMarkRead(conversation.id)
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    DisposableEffect(conversation.id) {
        onDispose { onSetTyping(conversation.id, false) }
    }

    LaunchedEffect(inputText) {
        if (inputText.isNotBlank()) {
            onSetTyping(conversation.id, true)
            delay(3500L)
            onSetTyping(conversation.id, false)
        } else {
            onSetTyping(conversation.id, false)
        }
    }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                isPreparingMedia = true
                mediaError = null
                pendingVideo = null
                pendingImageB64 = ImageCompressionHelper.compressUriToBase64(context, uri, maxDim = 480, maxBytes = 40_000)
                isPreparingMedia = false
            }
        }
    }

    val videoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                isPreparingMedia = true
                mediaError = null
                pendingImageB64 = null
                ImageCompressionHelper.extractVideoForArk(context, uri)
                    .onSuccess { pendingVideo = it }
                    .onFailure { mediaError = it.message ?: "Could not load video." }
                isPreparingMedia = false
            }
        }
    }

    val lastOutgoingId = remember(messages, currentUser.userId) {
        messages.lastOrNull { it.senderId == currentUser.userId && !it.isDeleted }?.id
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Surface(color = colors.surface) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f).clickable { if (peerUid.isNotBlank()) onOpenUserProfile(peerUid) }
                ) {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("dm_chat_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = colors.ink)
                    }
                    ArkAvatarBadge(avatarPreset = peerAvatar, username = peerName, size = 38.dp)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("@$peerName", style = MaterialTheme.typography.titleMedium, color = colors.ink)
                        Text(
                            text = if (peerTyping) "Typing..." else "Tap to view profile",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (peerTyping) colors.accent else colors.ink2
                        )
                    }
                }
            }
        }

        if (isIncomingRequest) {
            Surface(
                color = colors.accentSoft,
                border = BorderStroke(1.dp, colors.accent.copy(alpha = 0.35f)),
                modifier = Modifier.fillMaxWidth().padding(12.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("@$peerName wants to message you", style = MaterialTheme.typography.titleSmall, color = colors.ink)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { onBlockUser(peerUid, peerName); onBack() }) {
                            Text("Block", color = colors.coral)
                        }
                        OutlinedButton(onClick = { onDeclineRequest(conversation.id) }) {
                            Text("Decline")
                        }
                        OutlinedButton(onClick = { onAcceptRequest(conversation.id) }) {
                            Text("Accept", color = colors.emerald)
                        }
                    }
                }
            }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages, key = { it.id }) { msg ->
                val isMine = msg.senderId == currentUser.userId
                var menuOpen by remember(msg.id) { mutableStateOf(false) }

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = if (isMine) Alignment.End else Alignment.Start
                ) {
                    Box {
                        Surface(
                            shape = RoundedCornerShape(
                                topStart = 18.dp,
                                topEnd = 18.dp,
                                bottomStart = if (isMine) 18.dp else 4.dp,
                                bottomEnd = if (isMine) 4.dp else 18.dp
                            ),
                            color = if (isMine) colors.accent else colors.surface,
                            border = if (isMine) null else BorderStroke(1.dp, colors.hairline),
                            modifier = Modifier
                                .widthIn(max = 290.dp)
                                .combinedClickable(
                                    onClick = { menuOpen = true },
                                    onLongClick = { menuOpen = true }
                                )
                        ) {
                            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (!msg.replyToPreview.isNullOrBlank()) {
                                    Surface(
                                        color = Color.Black.copy(alpha = 0.14f),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Text(
                                            text = "Reply: ${msg.replyToPreview}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = if (isMine) Color.White.copy(alpha = 0.85f) else colors.ink2,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                            maxLines = 2
                                        )
                                    }
                                }

                                if (msg.isDeleted) {
                                    Text(
                                        text = "Message unsent",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (isMine) Color.White.copy(alpha = 0.7f) else colors.ink3
                                    )
                                } else {
                                    if (!msg.imageBase64.isNullOrBlank()) {
                                        val bmp = rememberDecodedImageBitmap(msg.imageBase64)
                                        if (bmp != null) {
                                            Image(
                                                bitmap = bmp,
                                                contentDescription = "Direct message photo",
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .heightIn(max = 200.dp)
                                                    .clip(RoundedCornerShape(12.dp)),
                                                contentScale = ContentScale.Crop
                                            )
                                        }
                                    }
                                    if (msg.videoChunkCount > 0L && !msg.videoThumbnailBase64.isNullOrBlank()) {
                                        val tbmp = rememberDecodedImageBitmap(msg.videoThumbnailBase64)
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(160.dp)
                                                .clip(RoundedCornerShape(12.dp))
                                                .clickable {
                                                    playingVideoMsgId = msg.id
                                                    playingVideoThumb = msg.videoThumbnailBase64
                                                },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (tbmp != null) {
                                                Image(
                                                    bitmap = tbmp,
                                                    contentDescription = "Direct message video",
                                                    modifier = Modifier.fillMaxSize(),
                                                    contentScale = ContentScale.Crop
                                                )
                                            }
                                            Icon(Icons.Default.PlayCircle, contentDescription = "Play video", tint = Color.White, modifier = Modifier.size(44.dp))
                                        }
                                    }
                                    if (msg.text.isNotBlank()) {
                                        Text(
                                            text = msg.text,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = if (isMine) Color.White else colors.ink
                                        )
                                    }
                                }
                            }
                        }

                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            Row(modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("❤️", "🔥", "😂", "👍", "🏆").forEach { emoji ->
                                    Text(
                                        text = emoji,
                                        fontSize = 20.sp,
                                        modifier = Modifier.clickable {
                                            onReactMessage(msg.id, emoji)
                                            menuOpen = false
                                        }
                                    )
                                }
                            }
                            DropdownMenuItem(
                                text = { Text("Reply") },
                                leadingIcon = { Icon(Icons.AutoMirrored.Filled.Reply, contentDescription = null) },
                                onClick = {
                                    replyTarget = msg
                                    menuOpen = false
                                }
                            )
                            if (isMine && !msg.isDeleted) {
                                DropdownMenuItem(
                                    text = { Text("Unsend", color = colors.coral) },
                                    onClick = {
                                        onDeleteMessage(msg.id)
                                        menuOpen = false
                                    }
                                )
                            }
                        }
                    }

                    if (msg.reactions.isNotEmpty()) {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.padding(top = 2.dp)) {
                            msg.reactions.values.distinct().forEach { emoji ->
                                Surface(shape = CircleShape, color = colors.surfaceSecondary) {
                                    Text(emoji, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                }
                            }
                        }
                    }

                    if (isMine && msg.id == lastOutgoingId) {
                        val msgMs = (msg.createdAt?.seconds ?: 0L) * 1000L
                        val seen = peerReadAtMs >= msgMs && msgMs > 0L
                        Text(
                            text = if (seen) "Seen" else formatPostTimestamp(msg.createdAt),
                            style = MaterialTheme.typography.labelSmall,
                            color = colors.ink3,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }
            }
        }

        // Composer
        Surface(color = colors.surface) {
            Column(modifier = Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (mediaError != null) {
                    Text(mediaError!!, style = MaterialTheme.typography.labelSmall, color = colors.coral)
                }
                if (replyTarget != null) {
                    Row(
                        modifier = Modifier.fillMaxWidth().background(colors.surfaceSecondary, RoundedCornerShape(10.dp)).padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Replying to @${replyTarget!!.senderUsername}: ${replyTarget!!.text.take(40)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = colors.ink2,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = { replyTarget = null }, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Cancel reply", modifier = Modifier.size(16.dp))
                        }
                    }
                }
                if (isPreparingMedia) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        androidx.compose.material3.CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = colors.accent)
                        Text("Preparing video...", style = MaterialTheme.typography.labelSmall, color = colors.ink2)
                    }
                }
                if (pendingImageB64 != null || pendingVideo != null) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text(
                            if (pendingVideo != null) "Video clip attached ✓" else "Photo attached ✓",
                            style = MaterialTheme.typography.labelSmall,
                            color = colors.emerald
                        )
                        TextButton(onClick = { pendingImageB64 = null; pendingVideo = null }) { Text("Remove") }
                    }
                }
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        enabled = !isPreparingMedia,
                        onClick = { imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
                    ) {
                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = "Attach photo", tint = colors.accent)
                    }
                    IconButton(
                        enabled = !isPreparingMedia,
                        onClick = { videoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) }
                    ) {
                        Icon(Icons.Default.Videocam, contentDescription = "Attach video", tint = colors.accent)
                    }
                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { inputText = it.take(500) },
                        placeholder = { Text("Message...") },
                        singleLine = true,
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier.weight(1f).testTag("dm_message_input")
                    )
                    Spacer(Modifier.width(6.dp))
                    val canSend = !isPreparingMedia && (inputText.trim().isNotBlank() || pendingImageB64 != null || pendingVideo != null)
                    IconButton(
                        enabled = canSend,
                        onClick = {
                            onSendMessage(
                                inputText,
                                pendingImageB64,
                                pendingVideo?.thumbnailBase64,
                                pendingVideo?.durationMs ?: 0L,
                                pendingVideo?.chunksBase64 ?: emptyList(),
                                replyTarget?.id,
                                replyTarget?.text?.take(80)
                            )
                            inputText = ""
                            pendingImageB64 = null
                            pendingVideo = null
                            replyTarget = null
                        },
                        modifier = Modifier.testTag("dm_send_button")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send",
                            tint = if (canSend) colors.accent else colors.ink3
                        )
                    }
                }
            }
        }
    }

    if (playingVideoMsgId != null) {
        var videoFile by remember(playingVideoMsgId) { mutableStateOf<File?>(null) }
        var loading by remember(playingVideoMsgId) { mutableStateOf(true) }
        LaunchedEffect(playingVideoMsgId) {
            loading = true
            videoFile = onLoadVideoFile(context, conversation.id, playingVideoMsgId!!)
            loading = false
        }
        Dialog(
            onDismissRequest = { playingVideoMsgId = null },
            properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
        ) {
            Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
                ArkVideoPlayerView(
                    videoFile = videoFile,
                    thumbnailBase64 = playingVideoThumb,
                    isLoading = loading,
                    modifier = Modifier.fillMaxSize()
                )
                IconButton(
                    onClick = { playingVideoMsgId = null },
                    modifier = Modifier.align(Alignment.TopEnd).padding(16.dp)
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Close video", tint = Color.White)
                }
            }
        }
    }
}
