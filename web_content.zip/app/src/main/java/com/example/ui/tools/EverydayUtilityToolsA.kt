package com.example.ui.tools

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.engine.FormattingOptions
import com.example.engine.NumberFormatter
import com.example.tools.ToolId
import com.example.tools.ToolsEngine
import com.example.ui.components.AetherCard
import com.example.ui.components.AetherFilterChip
import com.example.ui.components.AetherNumberField
import com.example.ui.components.AetherResultRow
import com.example.ui.theme.AetherTheme

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EverydayUtilityToolsAView(
  toolId: ToolId,
  formatting: FormattingOptions,
  hapticsEnabled: Boolean,
  onCopy: (String) -> Unit,
) {
  val colors = AetherTheme.colors

  when (toolId) {
    ToolId.DISCOUNT -> {
      var price by remember { mutableStateOf("120") }
      var disc by remember { mutableStateOf("25") }
      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        AetherNumberField(price, { price = it }, "Original price")
        AetherNumberField(disc, { disc = it }, "Discount (%)")
        AetherCard(backgroundColor = colors.surfaceElevated) {
          val p = price.toDoubleOrNull()
          val d = disc.toDoubleOrNull()
          if (p != null && d != null) {
            val (saved, finalPrice) = ToolsEngine.discount(p, d)
            val fFinal = NumberFormatter.formatDouble(finalPrice, formatting)
            val fSaved = NumberFormatter.formatDouble(saved, formatting)
            AetherResultRow("Final price", fFinal, onCopy = { onCopy(fFinal) }, highlight = true)
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = colors.borderSubtle)
            AetherResultRow("You save", fSaved, onCopy = { onCopy(fSaved) })
          } else {
            AetherResultRow("Final price", "—", highlight = true)
          }
        }
      }
    }

    ToolId.SALE_PRICE -> {
      var price by remember { mutableStateOf("150") }
      var disc by remember { mutableStateOf("20") }
      var tax by remember { mutableStateOf("8") }
      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        AetherNumberField(price, { price = it }, "Tag price")
        AetherNumberField(disc, { disc = it }, "Discount (%)")
        AetherNumberField(tax, { tax = it }, "Sales tax (%)")
        AetherCard(backgroundColor = colors.surfaceElevated) {
          val p = price.toDoubleOrNull()
          val d = disc.toDoubleOrNull()
          val t = tax.toDoubleOrNull()
          if (p != null && d != null && t != null) {
            val (saved, taxAmt, total) = ToolsEngine.salePrice(p, d, t)
            val fTot = NumberFormatter.formatDouble(total, formatting)
            AetherResultRow("Checkout price", fTot, onCopy = { onCopy(fTot) }, highlight = true)
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = colors.borderSubtle)
            AetherResultRow("Discount savings", NumberFormatter.formatDouble(saved, formatting))
            Spacer(modifier = Modifier.height(6.dp))
            AetherResultRow("Tax added", NumberFormatter.formatDouble(taxAmt, formatting))
          } else {
            AetherResultRow("Checkout price", "—", highlight = true)
          }
        }
      }
    }

    ToolId.TAX_GST -> {
      var amount by remember { mutableStateOf("1000") }
      var taxPct by remember { mutableStateOf("18") }
      var inclusive by remember { mutableStateOf(false) }

      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          AetherFilterChip("Exclusive (+Tax)", !inclusive, { inclusive = false }, hapticsEnabled = hapticsEnabled)
          AetherFilterChip("Inclusive (Extract)", inclusive, { inclusive = true }, hapticsEnabled = hapticsEnabled)
        }
        AetherNumberField(amount, { amount = it }, if (inclusive) "Gross amount" else "Net amount")
        AetherNumberField(taxPct, { taxPct = it }, "Tax / GST rate (%)")
        AetherCard(backgroundColor = colors.surfaceElevated) {
          val a = amount.toDoubleOrNull()
          val r = taxPct.toDoubleOrNull()
          if (a != null && r != null) {
            val (base, tax, total) = ToolsEngine.taxGst(a, r, inclusive)
            val fTot = NumberFormatter.formatDouble(total, formatting)
            val fTax = NumberFormatter.formatDouble(tax, formatting)
            val fBase = NumberFormatter.formatDouble(base, formatting)
            AetherResultRow(if (inclusive) "Net base price" else "Total with tax", if (inclusive) fBase else fTot, onCopy = { onCopy(if (inclusive) fBase else fTot) }, highlight = true)
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = colors.borderSubtle)
            AetherResultRow("Tax / GST amount", fTax, onCopy = { onCopy(fTax) })
            Spacer(modifier = Modifier.height(6.dp))
            AetherResultRow(if (inclusive) "Gross total" else "Net base price", if (inclusive) fTot else fBase)
          } else {
            AetherResultRow("Result", "—", highlight = true)
          }
        }
      }
    }

    ToolId.TIP -> {
      var bill by remember { mutableStateOf("64") }
      var tipPct by remember { mutableStateOf("18") }
      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        AetherNumberField(bill, { bill = it }, "Bill amount")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          listOf("10", "15", "18", "20", "25").forEach { preset ->
            AetherFilterChip("$preset%", tipPct == preset, { tipPct = preset }, hapticsEnabled = hapticsEnabled)
          }
        }
        AetherNumberField(tipPct, { tipPct = it }, "Tip (%)")
        AetherCard(backgroundColor = colors.surfaceElevated) {
          val b = bill.toDoubleOrNull()
          val t = tipPct.toDoubleOrNull()
          val res = if (b != null && t != null) ToolsEngine.tipAndSplit(b, t, 1) else null
          if (res != null) {
            val fTot = NumberFormatter.formatDouble(res.second, formatting)
            val fTip = NumberFormatter.formatDouble(res.first, formatting)
            AetherResultRow("Total bill", fTot, onCopy = { onCopy(fTot) }, highlight = true)
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = colors.borderSubtle)
            AetherResultRow("Tip amount", fTip, onCopy = { onCopy(fTip) })
          } else {
            AetherResultRow("Total bill", "—", highlight = true)
          }
        }
      }
    }

    ToolId.SPLIT_BILL -> {
      var bill by remember { mutableStateOf("120") }
      var tipPct by remember { mutableStateOf("15") }
      var people by remember { mutableStateOf("4") }
      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        AetherNumberField(bill, { bill = it }, "Bill subtotal")
        AetherNumberField(tipPct, { tipPct = it }, "Tip (%)")
        AetherNumberField(people, { people = it }, "Number of people", allowDecimal = false)
        AetherCard(backgroundColor = colors.surfaceElevated) {
          val b = bill.toDoubleOrNull()
          val t = tipPct.toDoubleOrNull()
          val p = people.toIntOrNull()
          val res = if (b != null && t != null && p != null) ToolsEngine.tipAndSplit(b, t, p) else null
          if (res != null) {
            val fEach = NumberFormatter.formatDouble(res.third, formatting)
            val fTot = NumberFormatter.formatDouble(res.second, formatting)
            val fTip = NumberFormatter.formatDouble(res.first, formatting)
            AetherResultRow("Each person pays", fEach, onCopy = { onCopy(fEach) }, highlight = true)
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = colors.borderSubtle)
            AetherResultRow("Tip amount", fTip)
            Spacer(modifier = Modifier.height(6.dp))
            AetherResultRow("Grand total", fTot)
          } else {
            AetherResultRow("Each person pays", "—", highlight = true)
          }
        }
      }
    }

    ToolId.RATIO -> {
      var valA by remember { mutableStateOf("16") }
      var valB by remember { mutableStateOf("9") }
      var scaleC by remember { mutableStateOf("1920") }
      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          AetherNumberField(valA, { valA = it }, "Ratio A", allowDecimal = false, allowNegative = true, modifier = Modifier.weight(1f))
          AetherNumberField(valB, { valB = it }, "Ratio B", allowDecimal = false, allowNegative = true, modifier = Modifier.weight(1f))
        }
        AetherNumberField(scaleC, { scaleC = it }, "Scale A to C (optional)", allowNegative = true)
        AetherCard(backgroundColor = colors.surfaceElevated) {
          val a = valA.toLongOrNull()
          val b = valB.toLongOrNull()
          val c = scaleC.toDoubleOrNull()
          val res = if (a != null && b != null) ToolsEngine.ratio(a, b, c) else null
          if (res != null) {
            val simp = "${res.first.first} : ${res.first.second}"
            AetherResultRow("Simplified ratio", simp, onCopy = { onCopy(simp) }, highlight = true)
            if (res.second != null) {
              HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = colors.borderSubtle)
              val fScaled = NumberFormatter.formatDouble(res.second!!, formatting)
              AetherResultRow("Scaled D ($scaleC : D)", fScaled, onCopy = { onCopy(fScaled) })
            }
          } else {
            AetherResultRow("Simplified ratio", "—", highlight = true)
          }
        }
      }
    }

    ToolId.AVERAGE -> {
      var rawList by remember { mutableStateOf("12, 18, 24, 30, 16") }
      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedTextField(
          value = rawList,
          onValueChange = { rawList = it },
          label = { Text("Numbers (comma or space separated)") },
          minLines = 2,
          maxLines = 4,
          colors =
            OutlinedTextFieldDefaults.colors(
              focusedContainerColor = colors.surface,
              unfocusedContainerColor = colors.surface,
              focusedBorderColor = colors.accent,
              unfocusedBorderColor = colors.borderSubtle,
              focusedLabelColor = colors.lavender,
              unfocusedLabelColor = colors.textSecondary,
              focusedTextColor = colors.textPrimary,
              unfocusedTextColor = colors.textPrimary,
            ),
          shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
          modifier = Modifier.fillMaxWidth(),
        )
        val parsed =
          remember(rawList) {
            rawList.split(',', ' ', '\n', ';')
              .mapNotNull { it.trim().toDoubleOrNull()?.takeIf { v -> v.isFinite() } }
          }
        val stats = remember(parsed) { ToolsEngine.average(parsed) }
        AetherCard(backgroundColor = colors.surfaceElevated) {
          if (stats != null) {
            val fMean = NumberFormatter.formatDouble(stats.mean, formatting)
            AetherResultRow("Mean (Average)", fMean, onCopy = { onCopy(fMean) }, highlight = true)
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = colors.borderSubtle)
            AetherResultRow("Median", NumberFormatter.formatDouble(stats.median, formatting))
            Spacer(modifier = Modifier.height(4.dp))
            AetherResultRow("Sum (${stats.count} values)", NumberFormatter.formatDouble(stats.sum, formatting))
            Spacer(modifier = Modifier.height(4.dp))
            AetherResultRow("Min / Max", "${NumberFormatter.formatDouble(stats.min, formatting)} / ${NumberFormatter.formatDouble(stats.max, formatting)}")
          } else {
            Text("Enter one or more numbers above.", style = MaterialTheme.typography.bodyMedium, color = colors.textSecondary)
          }
        }
      }
    }

    else -> Unit
  }
}
