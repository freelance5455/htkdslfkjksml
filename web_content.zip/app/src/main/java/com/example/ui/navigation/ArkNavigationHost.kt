package com.example.ui.navigation

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddBox
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.AddBox
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ArkPost
import com.example.data.model.DirectConversation
import com.example.data.model.UserProfile
import com.example.ui.components.ArkAuroraBackground
import com.example.ui.components.FeedModalOverlays
import com.example.ui.components.LiquidGlassCard
import com.example.ui.screens.ActivityScreen
import com.example.ui.screens.AdminModerationScreen
import com.example.ui.screens.ChallengesScreen
import com.example.ui.screens.CreatePostScreen
import com.example.ui.screens.DirectChatScreen
import com.example.ui.screens.ExploreScreen
import com.example.ui.screens.FriendsScreen
import com.example.ui.screens.GameRoomScreen
import com.example.ui.screens.GamesZoneScreen
import com.example.ui.screens.GroupDetailScreen
import com.example.ui.screens.GroupsScreen
import com.example.ui.screens.HomeDashboardScreen
import com.example.ui.screens.LeaderboardScreen
import com.example.ui.screens.MessagesInboxScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SettingsAndPrivacyScreen
import com.example.ui.screens.StoryViewerScreen
import com.example.ui.screens.UserProfileScreen
import com.example.ui.theme.ArkThemeTokens
import com.example.ui.viewmodel.ArkAppViewModel
import com.example.ui.viewmodel.UiState

private enum class ArkPrimaryTab(
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val tag: String
) {
    HOME("Home", Icons.Filled.Home, Icons.Outlined.Home, "nav_home"),
    EXPLORE("Explore", Icons.Filled.Explore, Icons.Outlined.Explore, "nav_explore"),
    CREATE("Create", Icons.Filled.AddBox, Icons.Outlined.AddBox, "nav_create"),
    ACTIVITY("Activity", Icons.Filled.Favorite, Icons.Outlined.FavoriteBorder, "nav_activity"),
    PROFILE("Profile", Icons.Filled.Person, Icons.Outlined.Person, "nav_profile")
}

private sealed interface ArkSecondaryRoute {
    data class CreatePost(val draftId: String? = null) : ArkSecondaryRoute
    data class ExploreHashtag(val tag: String?) : ArkSecondaryRoute
    data object MessagesInbox : ArkSecondaryRoute
    data class DirectChat(val conversationId: String) : ArkSecondaryRoute
    data class UserProfile(val userId: String) : ArkSecondaryRoute
    data object Friends : ArkSecondaryRoute
    data object Groups : ArkSecondaryRoute
    data class GroupDetail(val groupId: String) : ArkSecondaryRoute
    data object GamesZone : ArkSecondaryRoute
    data class GameRoom(val roomId: String) : ArkSecondaryRoute
    data object Challenges : ArkSecondaryRoute
    data object Leaderboard : ArkSecondaryRoute
    data class StoryViewer(val storyId: String) : ArkSecondaryRoute
    data object Notifications : ArkSecondaryRoute
    data object SettingsPrivacy : ArkSecondaryRoute
    data object AdminModeration : ArkSecondaryRoute
}

@Composable
fun ArkMainAppScaffold(
    profile: UserProfile,
    viewModel: ArkAppViewModel,
    snackbarHostState: SnackbarHostState,
    onSignOut: () -> Unit
) {
    val colors = ArkThemeTokens.colors
    var selectedTab by remember { mutableStateOf(ArkPrimaryTab.HOME) }
    val secondaryBackStack = remember { mutableStateListOf<ArkSecondaryRoute>() }
    val topSecondary = secondaryBackStack.lastOrNull()

    val socialChat = viewModel.socialAndChat
    val feedDelegate = viewModel.feed

    LaunchedEffect(topSecondary) {
        when (topSecondary) {
            is ArkSecondaryRoute.GroupDetail -> viewModel.selectGroup(topSecondary.groupId)
            is ArkSecondaryRoute.GameRoom -> viewModel.selectRoom(topSecondary.roomId)
            is ArkSecondaryRoute.DirectChat -> socialChat.selectConversation(topSecondary.conversationId)
            is ArkSecondaryRoute.UserProfile -> socialChat.openUserProfile(topSecondary.userId)
            is ArkSecondaryRoute.ExploreHashtag -> if (topSecondary.tag != null) socialChat.searchByHashtag(topSecondary.tag)
            else -> Unit
        }
    }

    val challengesState by viewModel.challengesState.collectAsStateWithLifecycle()
    val challengeProgressState by viewModel.challengeProgressState.collectAsStateWithLifecycle()
    val friendsState by viewModel.friendsState.collectAsStateWithLifecycle()
    val incomingRequestsState by viewModel.incomingRequestsState.collectAsStateWithLifecycle()
    val outgoingRequestsState by viewModel.outgoingRequestsState.collectAsStateWithLifecycle()
    val blockedUsersState by viewModel.blockedUsersState.collectAsStateWithLifecycle()
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
    val myGroupsState by viewModel.myGroupsState.collectAsStateWithLifecycle()
    val publicCommunitiesState by viewModel.publicCommunitiesState.collectAsStateWithLifecycle()
    val publicLobbiesState by viewModel.publicLobbiesState.collectAsStateWithLifecycle()
    val myGameRoomsState by viewModel.myGameRoomsState.collectAsStateWithLifecycle()
    val leaderboardState by viewModel.leaderboardState.collectAsStateWithLifecycle()
    val notificationsState by viewModel.notificationsState.collectAsStateWithLifecycle()
    val privateSettingsState by viewModel.privateSettingsState.collectAsStateWithLifecycle()
    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
    val isAdmin by viewModel.isAdmin.collectAsStateWithLifecycle()
    val reports by viewModel.reports.collectAsStateWithLifecycle()
    val allUsersModeration by viewModel.allUsersModeration.collectAsStateWithLifecycle()
    val selectedGroup by viewModel.selectedGroupState.collectAsStateWithLifecycle()
    val selectedGroupMessages by viewModel.selectedGroupMessages.collectAsStateWithLifecycle()
    val selectedGroupMedia by viewModel.selectedGroupMedia.collectAsStateWithLifecycle()
    val selectedRoom by viewModel.selectedRoomState.collectAsStateWithLifecycle()

    // Feed states
    val feedPosts by feedDelegate.feedPosts.collectAsStateWithLifecycle()
    val explorePosts by feedDelegate.explorePosts.collectAsStateWithLifecycle()
    val exploreCategory by feedDelegate.exploreCategory.collectAsStateWithLifecycle()
    val isFeedLoading by feedDelegate.isFeedLoading.collectAsStateWithLifecycle()
    val isLoadingMoreFeed by feedDelegate.isLoadingMoreFeed.collectAsStateWithLifecycle()
    val hasMoreFeed by feedDelegate.hasMoreFeed.collectAsStateWithLifecycle()
    val isExploreLoading by feedDelegate.isExploreLoading.collectAsStateWithLifecycle()
    val hasMoreExplore by feedDelegate.hasMoreExplore.collectAsStateWithLifecycle()
    val stories by feedDelegate.stories.collectAsStateWithLifecycle()
    val viewedStoryIds by feedDelegate.viewedStoryIds.collectAsStateWithLifecycle()
    val activeStoryViewers by feedDelegate.activeStoryViewers.collectAsStateWithLifecycle()
    val activeStoryReactions by feedDelegate.activeStoryReactions.collectAsStateWithLifecycle()
    val commentsPost by feedDelegate.commentsPost.collectAsStateWithLifecycle()
    val activeComments by feedDelegate.activeComments.collectAsStateWithLifecycle()
    val myPosts by feedDelegate.myPosts.collectAsStateWithLifecycle()
    val savedPosts by feedDelegate.savedPosts.collectAsStateWithLifecycle()
    val drafts by feedDelegate.drafts.collectAsStateWithLifecycle()
    val bookmarkedIds by feedDelegate.bookmarkedIds.collectAsStateWithLifecycle()
    val myReactions by feedDelegate.myReactions.collectAsStateWithLifecycle()
    val myPollVotes by feedDelegate.myPollVotes.collectAsStateWithLifecycle()
    val isPublishingPost by feedDelegate.isPublishingPost.collectAsStateWithLifecycle()

    // Social & Chat states
    val followers by socialChat.followers.collectAsStateWithLifecycle()
    val following by socialChat.following.collectAsStateWithLifecycle()
    val incomingFollowRequests by socialChat.incomingFollowRequests.collectAsStateWithLifecycle()
    val outgoingFollowRequests by socialChat.outgoingFollowRequests.collectAsStateWithLifecycle()
    val restrictedUsers by socialChat.restrictedUsers.collectAsStateWithLifecycle()
    val myHighlights by socialChat.myHighlights.collectAsStateWithLifecycle()
    val pendingTagRequests by socialChat.pendingTagRequests.collectAsStateWithLifecycle()
    val myTaggedPosts by socialChat.myTaggedPosts.collectAsStateWithLifecycle()
    val activeConversations by socialChat.activeConversations.collectAsStateWithLifecycle()
    val messageRequests by socialChat.messageRequests.collectAsStateWithLifecycle()
    val unreadDmCount by socialChat.unreadDmCount.collectAsStateWithLifecycle()
    val selectedConversation by socialChat.selectedConversation.collectAsStateWithLifecycle()
    val activeMessages by socialChat.activeMessages.collectAsStateWithLifecycle()
    val recommendedCreators by socialChat.recommendedCreators.collectAsStateWithLifecycle()
    val exploreUserSearchResults by socialChat.exploreUserSearchResults.collectAsStateWithLifecycle()
    val explorePostSearchResults by socialChat.explorePostSearchResults.collectAsStateWithLifecycle()
    val selectedHashtag by socialChat.selectedHashtag.collectAsStateWithLifecycle()
    val hashtagPosts by socialChat.hashtagPosts.collectAsStateWithLifecycle()
    val inspectedProfile by socialChat.inspectedProfile.collectAsStateWithLifecycle()
    val inspectedPosts by socialChat.inspectedPosts.collectAsStateWithLifecycle()
    val inspectedTaggedPosts by socialChat.inspectedTaggedPosts.collectAsStateWithLifecycle()
    val inspectedHighlights by socialChat.inspectedHighlights.collectAsStateWithLifecycle()
    val inspectedFollowers by socialChat.inspectedFollowers.collectAsStateWithLifecycle()
    val inspectedFollowing by socialChat.inspectedFollowing.collectAsStateWithLifecycle()

    var showAddStoryDialog by remember { mutableStateOf(false) }
    var sharingPost by remember { mutableStateOf<ArkPost?>(null) }
    var editingPost by remember { mutableStateOf<ArkPost?>(null) }
    var fullscreenMedia by remember { mutableStateOf<Pair<ArkPost, Int>?>(null) }
    var likersPost by remember { mutableStateOf<ArkPost?>(null) }
    var reportingTarget by remember { mutableStateOf<Pair<String, String>?>(null) }

    val challenges = (challengesState as? UiState.Success)?.data ?: emptyList()
    val challengeProgress = (challengeProgressState as? UiState.Success)?.data ?: emptyMap()
    val friends = (friendsState as? UiState.Success)?.data ?: emptyList()
    val incomingFriendRequests = (incomingRequestsState as? UiState.Success)?.data ?: emptyList()
    val outgoingFriendRequests = (outgoingRequestsState as? UiState.Success)?.data ?: emptyList()
    val blockedUsers = (blockedUsersState as? UiState.Success)?.data ?: emptyList()
    val myGroups = (myGroupsState as? UiState.Success)?.data ?: emptyList()
    val publicCommunities = (publicCommunitiesState as? UiState.Success)?.data ?: emptyList()
    val publicLobbies = (publicLobbiesState as? UiState.Success)?.data ?: emptyList()
    val myGameRooms = (myGameRoomsState as? UiState.Success)?.data ?: emptyList()
    val leaderboard = (leaderboardState as? UiState.Success)?.data ?: emptyList()
    val notifications = (notificationsState as? UiState.Success)?.data ?: emptyList()
    val privateSettings = (privateSettingsState as? UiState.Success)?.data

    val taggableUsers = remember(friends, following) {
        val map = linkedMapOf<String, String>()
        friends.forEach { map[it.friendUid] = it.friendUsername }
        following.forEach { map.putIfAbsent(it.peerUid, it.peerUsername) }
        map.entries.map { it.key to it.value }
    }

    val activityBadgeCount = remember(notifications, incomingFollowRequests, incomingFriendRequests, pendingTagRequests) {
        notifications.count { !it.isRead } +
            incomingFollowRequests.size +
            incomingFriendRequests.size +
            pendingTagRequests.size
    }

    fun pushRoute(route: ArkSecondaryRoute) {
        if (secondaryBackStack.lastOrNull() != route) {
            secondaryBackStack.add(route)
        }
    }

    fun popRoute() {
        if (secondaryBackStack.isNotEmpty()) {
            secondaryBackStack.removeAt(secondaryBackStack.lastIndex)
        }
    }

    fun openUserProfile(uid: String) {
        if (uid.isBlank()) return
        if (uid == profile.userId) {
            secondaryBackStack.clear()
            selectedTab = ArkPrimaryTab.PROFILE
        } else {
            socialChat.openUserProfile(uid)
            pushRoute(ArkSecondaryRoute.UserProfile(uid))
        }
    }

    fun openHashtag(tag: String) {
        socialChat.searchByHashtag(tag)
        if (topSecondary !is ArkSecondaryRoute.ExploreHashtag) {
            pushRoute(ArkSecondaryRoute.ExploreHashtag(tag))
        }
    }

    fun sendTextViaDm(targetUser: UserProfile, messageText: String) {
        socialChat.openOrStartDm(profile, targetUser, friends) { convId ->
            val conv = socialChat.conversations.value.firstOrNull { it.id == convId }
                ?: DirectConversation(
                    id = convId,
                    participantUids = listOf(profile.userId, targetUser.userId).sorted(),
                    participantNames = mapOf(profile.userId to profile.username, targetUser.userId to targetUser.username),
                    participantAvatars = mapOf(profile.userId to profile.avatarPreset, targetUser.userId to targetUser.avatarPreset)
                )
            socialChat.sendDm(conversation = conv, sender = profile, text = messageText)
        }
    }

    ArkAuroraBackground {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useRail = maxWidth >= 600.dp

            Scaffold(
                containerColor = Color.Transparent,
                snackbarHost = { SnackbarHost(snackbarHostState) },
                contentWindowInsets = WindowInsets.safeDrawing,
                bottomBar = {
                    if (!useRail && topSecondary == null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .navigationBarsPadding()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Surface(
                                shape = RoundedCornerShape(28.dp),
                                color = colors.glass,
                                border = BorderStroke(1.dp, colors.glassLine),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .widthIn(max = 520.dp)
                                    .shadow(
                                        elevation = if (colors.isDark) 14.dp else 10.dp,
                                        shape = RoundedCornerShape(28.dp),
                                        ambientColor = Color.Black.copy(alpha = 0.10f),
                                        spotColor = Color.Black.copy(alpha = 0.10f)
                                    )
                            ) {
                                NavigationBar(
                                    containerColor = Color.Transparent,
                                    tonalElevation = 0.dp,
                                    windowInsets = WindowInsets(0, 0, 0, 0)
                                ) {
                                    ArkPrimaryTab.entries.forEach { tab ->
                                        val selected = selectedTab == tab
                                        NavigationBarItem(
                                            selected = selected,
                                            onClick = {
                                                if (tab == ArkPrimaryTab.CREATE) {
                                                    pushRoute(ArkSecondaryRoute.CreatePost())
                                                } else {
                                                    selectedTab = tab
                                                }
                                            },
                                            icon = {
                                                val iconContent: @Composable () -> Unit = {
                                                    Icon(
                                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                                        contentDescription = tab.label
                                                    )
                                                }
                                                if (tab == ArkPrimaryTab.ACTIVITY && activityBadgeCount > 0) {
                                                    BadgedBox(
                                                        badge = {
                                                            Badge(containerColor = colors.coral) {
                                                                Text(activityBadgeCount.coerceAtMost(99).toString())
                                                            }
                                                        }
                                                    ) { iconContent() }
                                                } else {
                                                    iconContent()
                                                }
                                            },
                                            label = { Text(tab.label, maxLines = 1) },
                                            modifier = Modifier.testTag(tab.tag),
                                            colors = NavigationBarItemDefaults.colors(
                                                selectedIconColor = colors.accent,
                                                selectedTextColor = colors.accent,
                                                indicatorColor = colors.accentSoft,
                                                unselectedIconColor = colors.ink2,
                                                unselectedTextColor = colors.ink2
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (useRail && topSecondary == null) {
                        Surface(
                            color = colors.glass,
                            border = BorderStroke(1.dp, colors.glassLine),
                            modifier = Modifier.fillMaxHeight()
                        ) {
                            NavigationRail(containerColor = Color.Transparent) {
                                Spacer(Modifier.height(12.dp))
                                ArkPrimaryTab.entries.forEach { tab ->
                                    val selected = selectedTab == tab
                                    NavigationRailItem(
                                        selected = selected,
                                        onClick = {
                                            if (tab == ArkPrimaryTab.CREATE) {
                                                pushRoute(ArkSecondaryRoute.CreatePost())
                                            } else {
                                                selectedTab = tab
                                            }
                                        },
                                        icon = {
                                            Icon(
                                                imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                                contentDescription = tab.label
                                            )
                                        },
                                        label = { Text(tab.label) },
                                        modifier = Modifier.testTag(tab.tag),
                                        colors = NavigationRailItemDefaults.colors(
                                            selectedIconColor = colors.accent,
                                            selectedTextColor = colors.accent,
                                            indicatorColor = colors.accentSoft,
                                            unselectedIconColor = colors.ink2,
                                            unselectedTextColor = colors.ink2
                                        )
                                    )
                                }
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .weight(1f),
                        contentAlignment = Alignment.TopCenter
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .widthIn(max = 840.dp)
                        ) {
                            if (profile.isRestricted) {
                                Surface(
                                    color = colors.coral.copy(alpha = 0.16f),
                                    border = BorderStroke(1.dp, colors.coral),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = "Safety Notice: Account features are temporarily restricted by ARK Moderation.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = colors.coral,
                                        modifier = Modifier.padding(10.dp)
                                    )
                                }
                            }

                            if (topSecondary != null) {
                                when (topSecondary) {
                                    is ArkSecondaryRoute.CreatePost -> {
                                        val draftObj = drafts.firstOrNull { it.id == topSecondary.draftId }
                                        CreatePostScreen(
                                            profile = profile,
                                            groups = myGroups,
                                            drafts = drafts,
                                            taggableUsers = taggableUsers,
                                            initialDraft = draftObj,
                                            isPublishing = isPublishingPost,
                                            onBack = { popRoute() },
                                            onPublish = { type, cat, cap, imgs, vis, selGrps, loc, alts, tagged, pollQ, pollOpts, vThumb, vDur, vChunks, draftId ->
                                                feedDelegate.createPost(
                                                    author = profile,
                                                    postType = type,
                                                    category = cat,
                                                    caption = cap,
                                                    imageBase64List = imgs,
                                                    visibility = vis,
                                                    friends = friends,
                                                    selectedGroups = selGrps,
                                                    locationLabel = loc,
                                                    altTexts = alts,
                                                    taggedUids = tagged,
                                                    pollQuestion = pollQ,
                                                    pollOptions = pollOpts,
                                                    videoThumbnailBase64 = vThumb,
                                                    videoDurationMs = vDur,
                                                    videoChunksBase64 = vChunks,
                                                    draftIdToDelete = draftId,
                                                    onPublished = { popRoute() }
                                                )
                                            },
                                            onSaveDraft = { dId, type, cat, cap, imgs, vis, pollQ, pollOpts, loc, alts ->
                                                feedDelegate.saveDraft(
                                                    draftId = dId,
                                                    postType = type,
                                                    category = cat,
                                                    caption = cap,
                                                    imageBase64List = imgs,
                                                    visibility = vis,
                                                    pollQuestion = pollQ,
                                                    pollOptions = pollOpts,
                                                    locationLabel = loc,
                                                    altTexts = alts
                                                )
                                            },
                                            onDeleteDraft = { dId -> feedDelegate.deleteDraft(dId) }
                                        )
                                    }

                                    is ArkSecondaryRoute.ExploreHashtag -> {
                                        ExploreScreen(
                                            currentUser = profile,
                                            posts = explorePosts,
                                            selectedCategory = exploreCategory,
                                            isLoading = isExploreLoading,
                                            hasMore = hasMoreExplore,
                                            myReactions = myReactions,
                                            myPollVotes = myPollVotes,
                                            bookmarkedIds = bookmarkedIds,
                                            recommendedCreators = recommendedCreators,
                                            userSearchResults = exploreUserSearchResults,
                                            postSearchResults = explorePostSearchResults,
                                            selectedHashtag = selectedHashtag,
                                            hashtagPosts = hashtagPosts,
                                            publicCommunities = publicCommunities,
                                            myGroups = myGroups,
                                            myFollowing = following,
                                            outgoingFollowRequests = outgoingFollowRequests,
                                            showBackButton = true,
                                            onBack = {
                                                socialChat.searchByHashtag(null)
                                                popRoute()
                                            },
                                            onSelectCategory = { feedDelegate.setExploreCategory(it) },
                                            onRefresh = { feedDelegate.refreshExplore() },
                                            onLoadMore = { feedDelegate.loadMoreExplore() },
                                            onSearchQuery = { socialChat.searchExplore(it) },
                                            onSelectHashtag = { socialChat.searchByHashtag(it) },
                                            onClearSearch = { socialChat.clearExploreSearch() },
                                            onFollowUser = { target -> socialChat.followOrRequest(profile, target) },
                                            onUnfollowUser = { uid, name -> socialChat.unfollowUser(uid, name) },
                                            onCancelFollowRequest = { reqId -> socialChat.cancelFollowRequest(reqId) },
                                            onOpenUserProfile = { uid -> openUserProfile(uid) },
                                            onJoinCommunity = { gid ->
                                                viewModel.joinPublicGroup(gid) { joinedGid ->
                                                    pushRoute(ArkSecondaryRoute.GroupDetail(joinedGid))
                                                }
                                            },
                                            onOpenGroup = { gid -> pushRoute(ArkSecondaryRoute.GroupDetail(gid)) },
                                            onReaction = { p, r -> feedDelegate.toggleReaction(p, profile, r) },
                                            onOpenComments = { p -> feedDelegate.openComments(p) },
                                            onShare = { p -> sharingPost = p },
                                            onToggleBookmark = { pid -> feedDelegate.toggleBookmark(pid) },
                                            onVotePoll = { pid, idx -> feedDelegate.votePoll(pid, idx) },
                                            onEditCaption = { p -> editingPost = p },
                                            onToggleCommentsDisabled = { p -> feedDelegate.toggleCommentsDisabled(p.id, !p.commentsDisabled) },
                                            onDeletePost = { pid -> feedDelegate.deletePost(pid) },
                                            onHidePost = { pid -> feedDelegate.hidePost(pid) },
                                            onMuteAuthor = { uid, name -> feedDelegate.muteUser(uid, name) },
                                            onReportPost = { p -> reportingTarget = "post" to p.id },
                                            onOpenMedia = { p, page -> fullscreenMedia = p to page },
                                            onOpenLikers = { p -> likersPost = p }
                                        )
                                    }

                                    ArkSecondaryRoute.MessagesInbox -> {
                                        MessagesInboxScreen(
                                            currentUser = profile,
                                            activeConversations = activeConversations,
                                            messageRequests = messageRequests,
                                            following = following,
                                            friends = friends,
                                            userSearchResults = exploreUserSearchResults,
                                            onBack = { popRoute() },
                                            onOpenConversation = { cid -> pushRoute(ArkSecondaryRoute.DirectChat(cid)) },
                                            onSearchUsers = { socialChat.searchExplore(it) },
                                            onStartChatWithUser = { target ->
                                                socialChat.openOrStartDm(profile, target, friends) { cid ->
                                                    pushRoute(ArkSecondaryRoute.DirectChat(cid))
                                                }
                                            },
                                            onAcceptRequest = { cid -> socialChat.acceptMessageRequest(cid) },
                                            onDeclineRequest = { cid -> socialChat.declineMessageRequest(cid) }
                                        )
                                    }

                                    is ArkSecondaryRoute.DirectChat -> {
                                        DirectChatScreen(
                                            currentUser = profile,
                                            conversation = selectedConversation,
                                            messages = activeMessages,
                                            onBack = { popRoute() },
                                            onOpenUserProfile = { uid -> openUserProfile(uid) },
                                            onSendMessage = { text, img, vThumb, vDur, vChunks, replyId, replyPrev ->
                                                val conv = selectedConversation ?: return@DirectChatScreen
                                                socialChat.sendDm(
                                                    conversation = conv,
                                                    sender = profile,
                                                    text = text,
                                                    imageBase64 = img,
                                                    videoThumbnailBase64 = vThumb,
                                                    videoDurationMs = vDur,
                                                    videoChunksBase64 = vChunks,
                                                    replyToId = replyId,
                                                    replyToPreview = replyPrev
                                                )
                                            },
                                            onAcceptRequest = { cid -> socialChat.acceptMessageRequest(cid) },
                                            onDeclineRequest = { cid ->
                                                socialChat.declineMessageRequest(cid) { popRoute() }
                                            },
                                            onBlockUser = { uid, name -> viewModel.blockUser(uid, name) },
                                            onMarkRead = { cid -> socialChat.markDmRead(cid) },
                                            onSetTyping = { cid, typing -> socialChat.setDmTyping(cid, typing) },
                                            onReactMessage = { mid, emoji ->
                                                val convId = selectedConversation?.id ?: return@DirectChatScreen
                                                socialChat.reactToDm(convId, mid, emoji)
                                            },
                                            onDeleteMessage = { mid ->
                                                val convId = selectedConversation?.id ?: return@DirectChatScreen
                                                socialChat.deleteDm(convId, mid)
                                            },
                                            onLoadVideoFile = { ctx, cid, mid -> socialChat.loadDmVideoFile(ctx, cid, mid) }
                                        )
                                    }

                                    is ArkSecondaryRoute.UserProfile -> {
                                        UserProfileScreen(
                                            targetProfile = inspectedProfile,
                                            currentUser = profile,
                                            posts = inspectedPosts,
                                            taggedPosts = inspectedTaggedPosts,
                                            highlights = inspectedHighlights,
                                            targetFollowers = inspectedFollowers,
                                            targetFollowing = inspectedFollowing,
                                            myFollowers = followers,
                                            myFollowing = following,
                                            myFriends = friends,
                                            outgoingFollowRequests = outgoingFollowRequests,
                                            blockedUsers = blockedUsers,
                                            restrictedUsers = restrictedUsers,
                                            myReactions = myReactions,
                                            myPollVotes = myPollVotes,
                                            bookmarkedIds = bookmarkedIds,
                                            onBack = { popRoute() },
                                            onFollowOrRequest = { target -> socialChat.followOrRequest(profile, target) },
                                            onUnfollow = { uid, name -> socialChat.unfollowUser(uid, name) },
                                            onCancelFollowRequest = { reqId -> socialChat.cancelFollowRequest(reqId) },
                                            onMessageUser = { target ->
                                                socialChat.openOrStartDm(profile, target, friends) { cid ->
                                                    pushRoute(ArkSecondaryRoute.DirectChat(cid))
                                                }
                                            },
                                            onBlockUser = { uid, name -> viewModel.blockUser(uid, name) },
                                            onUnblockUser = { uid -> viewModel.unblockUser(uid) },
                                            onRestrictUser = { uid, name -> socialChat.restrictUser(uid, name) },
                                            onUnrestrictUser = { uid -> socialChat.unrestrictUser(uid) },
                                            onReportUser = { id, reason, details -> viewModel.submitReport("user", id, reason, details) },
                                            onOpenUserProfile = { uid -> openUserProfile(uid) },
                                            onReaction = { p, r -> feedDelegate.toggleReaction(p, profile, r) },
                                            onOpenComments = { p -> feedDelegate.openComments(p) },
                                            onSharePost = { p -> sharingPost = p },
                                            onToggleBookmark = { pid -> feedDelegate.toggleBookmark(pid) },
                                            onVotePoll = { pid, idx -> feedDelegate.votePoll(pid, idx) },
                                            onOpenMedia = { p, page -> fullscreenMedia = p to page },
                                            onHashtagClick = { tag -> openHashtag(tag) },
                                            onOpenLikers = { p -> likersPost = p }
                                        )
                                    }

                                    ArkSecondaryRoute.Friends -> {
                                        FriendsScreen(
                                            currentUser = profile,
                                            friends = friends,
                                            incomingRequests = incomingFriendRequests,
                                            outgoingRequests = outgoingFriendRequests,
                                            blockedUsers = blockedUsers,
                                            searchResults = searchResults,
                                            onSearchUsername = { viewModel.searchUsers(it) },
                                            onSendRequest = { target -> viewModel.sendFriendRequest(profile, target) },
                                            onAcceptRequest = { req -> viewModel.acceptFriendRequest(req, profile) },
                                            onRejectRequest = { reqId -> viewModel.rejectFriendRequest(reqId) },
                                            onCancelRequest = { reqId -> viewModel.cancelFriendRequest(reqId) },
                                            onRemoveFriend = { uid -> viewModel.removeFriend(uid) },
                                            onBlockUser = { uid, name -> viewModel.blockUser(uid, name) },
                                            onUnblockUser = { uid -> viewModel.unblockUser(uid) },
                                            onReportUser = { uid, reason, details -> viewModel.submitReport("user", uid, reason, details) },
                                            onBack = { popRoute() }
                                        )
                                    }

                                    ArkSecondaryRoute.Groups -> {
                                        GroupsScreen(
                                            myGroups = myGroups,
                                            publicCommunities = publicCommunities,
                                            currentUserId = profile.userId,
                                            onCreateGroup = { name, desc, theme, isPriv, allowDl ->
                                                viewModel.createGroup(name, desc, theme, isPriv, allowDl) { gid ->
                                                    pushRoute(ArkSecondaryRoute.GroupDetail(gid))
                                                }
                                            },
                                            onJoinByCode = { code ->
                                                viewModel.joinGroupByCode(code) { gid ->
                                                    pushRoute(ArkSecondaryRoute.GroupDetail(gid))
                                                }
                                            },
                                            onJoinPublic = { gid ->
                                                viewModel.joinPublicGroup(gid) { joinedGid ->
                                                    pushRoute(ArkSecondaryRoute.GroupDetail(joinedGid))
                                                }
                                            },
                                            onOpenGroup = { gid -> pushRoute(ArkSecondaryRoute.GroupDetail(gid)) },
                                            onBack = { popRoute() }
                                        )
                                    }

                                    ArkSecondaryRoute.GamesZone -> {
                                        GamesZoneScreen(
                                            publicLobbies = publicLobbies,
                                            myRooms = myGameRooms,
                                            onCreateRoom = { gameType, isPrivate ->
                                                viewModel.createGameRoom(profile, gameType, isPrivate) { rid ->
                                                    pushRoute(ArkSecondaryRoute.GameRoom(rid))
                                                }
                                            },
                                            onJoinByCode = { code ->
                                                viewModel.joinRoomByCode(code, profile) { rid ->
                                                    pushRoute(ArkSecondaryRoute.GameRoom(rid))
                                                }
                                            },
                                            onJoinRoom = { rid ->
                                                viewModel.joinPublicRoom(rid, profile) { joinedRid ->
                                                    pushRoute(ArkSecondaryRoute.GameRoom(joinedRid))
                                                }
                                            },
                                            onBack = { popRoute() }
                                        )
                                    }

                                    is ArkSecondaryRoute.StoryViewer -> {
                                        val storyViewerContext = LocalContext.current
                                        StoryViewerScreen(
                                            stories = stories,
                                            initialStoryId = topSecondary.storyId,
                                            currentUser = profile,
                                            activeViewers = activeStoryViewers,
                                            activeReactions = activeStoryReactions,
                                            myHighlights = myHighlights,
                                            onMarkViewed = { st -> feedDelegate.markStoryViewed(st, profile) },
                                            onDeleteStory = { sid -> feedDelegate.deleteStory(sid) { popRoute() } },
                                            onReactToStory = { st, key -> feedDelegate.reactToStory(st, profile, key) },
                                            onReplyViaDm = { st, reply ->
                                                sendTextViaDm(
                                                    UserProfile(
                                                        userId = st.authorId,
                                                        username = st.authorUsername,
                                                        avatarPreset = st.authorAvatar
                                                    ),
                                                    "Story Reply: $reply"
                                                )
                                            },
                                            onSaveToNewHighlight = { title, st -> socialChat.createHighlight(profile, title, st, friends) },
                                            onAddToExistingHighlight = { hl, st -> socialChat.addToHighlight(hl, st) },
                                            onOpenUserProfile = { uid -> openUserProfile(uid) },
                                            onLoadStoryVideo = { sid -> feedDelegate.loadStoryVideoFile(storyViewerContext, sid) },
                                            onBack = { popRoute() }
                                        )
                                    }

                                    is ArkSecondaryRoute.GroupDetail -> {
                                        val grp = selectedGroup
                                        if (grp == null) {
                                            SecondaryLoadingCard(title = "Loading Squad...", onBack = { popRoute() })
                                        } else {
                                            GroupDetailScreen(
                                                group = grp,
                                                currentUser = profile,
                                                messages = selectedGroupMessages,
                                                mediaItems = selectedGroupMedia,
                                                groupChallenges = challenges.take(5),
                                                onBack = { popRoute() },
                                                onSendMessage = { text, img, replyId, replyPreview ->
                                                    viewModel.sendGroupMessage(grp, profile, text, img, replyId, replyPreview)
                                                },
                                                onReactMessage = { msg, emoji -> viewModel.reactToMessage(grp.id, msg, emoji) },
                                                onDeleteMessage = { msgId -> viewModel.deleteGroupMessage(grp.id, msgId) },
                                                onUploadMedia = { album, caption, img ->
                                                    viewModel.uploadGroupMedia(grp, profile, album, caption, img)
                                                },
                                                onUpdateSettings = { name, desc, theme, allowDl ->
                                                    viewModel.updateGroupSettings(grp.id, name, desc, theme, allowDl)
                                                },
                                                onPromoteAdmin = { targetUid -> viewModel.promoteMemberToAdmin(grp, targetUid) },
                                                onRemoveMember = { targetUid -> viewModel.removeGroupMember(grp, targetUid) },
                                                onLeaveGroup = { viewModel.leaveGroup(grp) { popRoute() } },
                                                onDeleteGroup = { viewModel.deleteGroup(grp) { popRoute() } },
                                                onReportContent = { type, id, reason ->
                                                    viewModel.submitReport(type, id, reason, "Group ${grp.name}")
                                                },
                                                onLaunchGroupGame = { gameType ->
                                                    viewModel.createGameRoom(
                                                        host = profile,
                                                        gameType = gameType,
                                                        isPrivate = true,
                                                        groupId = grp.id
                                                    ) { roomId -> pushRoute(ArkSecondaryRoute.GameRoom(roomId)) }
                                                }
                                            )
                                        }
                                    }

                                    is ArkSecondaryRoute.GameRoom -> {
                                        val room = selectedRoom
                                        if (room == null) {
                                            SecondaryLoadingCard(title = "Connecting to Game Room...", onBack = { popRoute() })
                                        } else {
                                            GameRoomScreen(
                                                room = room,
                                                currentUserId = profile.userId,
                                                onBack = { popRoute() },
                                                onToggleReady = { viewModel.toggleReady(room) },
                                                onStartOrNextRound = { viewModel.startOrAdvanceGame(room) },
                                                onSubmitMove = { choice, pts, nextWord -> viewModel.submitGameMove(room, choice, pts, nextWord) },
                                                onRematch = { viewModel.requestRematch(room) },
                                                onShareGameResult = { gTitle, scoreSummary, winnerName ->
                                                    val vis = if (profile.isPrivateAccount || profile.ageBracket == "under_13") "friends" else "public"
                                                    feedDelegate.createPost(
                                                        author = profile,
                                                        postType = "game_result",
                                                        category = "Gaming",
                                                        caption = "GG squad! Just wrapped up a $gTitle match on ARK.",
                                                        imageBase64List = emptyList(),
                                                        visibility = vis,
                                                        friends = friends,
                                                        selectedGroups = emptyList(),
                                                        metaGameName = gTitle,
                                                        metaScoreLabel = scoreSummary,
                                                        metaWinner = winnerName,
                                                        metaBadge = "Party Match"
                                                    )
                                                }
                                            )
                                        }
                                    }

                                    ArkSecondaryRoute.Challenges -> {
                                        ChallengesScreen(
                                            challenges = challenges,
                                            progressMap = challengeProgress,
                                            onBack = { popRoute() },
                                            onCompleteChallenge = { ch, note -> viewModel.completeChallenge(ch, note) },
                                            onSkipChallenge = { chId -> viewModel.skipChallenge(chId) },
                                            onShareChallengeResult = { ch, note ->
                                                val vis = if (profile.isPrivateAccount || profile.ageBracket == "under_13") "friends" else "public"
                                                val cap = if (note.isNotBlank()) note else "Completed the '${ch.title}' real-life quest on ARK!"
                                                feedDelegate.createPost(
                                                    author = profile,
                                                    postType = "challenge_result",
                                                    category = "Challenges",
                                                    caption = cap,
                                                    imageBase64List = emptyList(),
                                                    visibility = vis,
                                                    friends = friends,
                                                    selectedGroups = emptyList(),
                                                    metaGameName = ch.title,
                                                    metaScoreLabel = "+${ch.rewardPoints} PTS • ${ch.difficulty}",
                                                    metaBadge = ch.category
                                                )
                                            }
                                        )
                                    }

                                    ArkSecondaryRoute.Leaderboard -> {
                                        LeaderboardScreen(
                                            currentUser = profile,
                                            globalLeaderboard = leaderboard,
                                            friends = friends,
                                            onBack = { popRoute() }
                                        )
                                    }

                                    ArkSecondaryRoute.Notifications -> {
                                        NotificationsScreen(
                                            notifications = notifications,
                                            privateSettings = privateSettings,
                                            onBack = { popRoute() },
                                            onMarkRead = { nid -> viewModel.markNotificationRead(nid) },
                                            onSavePreferences = { prefs -> viewModel.updateNotificationPrefs(prefs) }
                                        )
                                    }

                                    ArkSecondaryRoute.SettingsPrivacy -> {
                                        SettingsAndPrivacyScreen(
                                            profile = profile,
                                            themeMode = themeMode,
                                            isAdmin = isAdmin,
                                            blockedUsers = blockedUsers,
                                            restrictedUsers = restrictedUsers,
                                            followers = followers,
                                            friends = friends,
                                            onBack = { popRoute() },
                                            onChangeThemeMode = { mode -> viewModel.setThemeMode(mode) },
                                            onSavePrivacy = { priv, req, online, optOut, msgFrom, tagApproval, hiddenStoryUids ->
                                                viewModel.updatePrivacy(
                                                    isPrivateAccount = priv,
                                                    allowFriendRequests = req,
                                                    showOnlineStatus = online,
                                                    optOutLeaderboard = optOut,
                                                    allowMessagesFrom = msgFrom,
                                                    requireTagApproval = tagApproval,
                                                    hiddenStoryFromUids = hiddenStoryUids
                                                )
                                            },
                                            onOpenFriends = { pushRoute(ArkSecondaryRoute.Friends) },
                                            onOpenNotifications = { pushRoute(ArkSecondaryRoute.Notifications) },
                                            onUnblockUser = { uid -> viewModel.unblockUser(uid) },
                                            onUnrestrictUser = { uid -> socialChat.unrestrictUser(uid) },
                                            onSubmitSupportFeedback = { topic, details ->
                                                viewModel.submitReport("feedback", profile.userId, topic, details)
                                            },
                                            onOpenAdmin = { pushRoute(ArkSecondaryRoute.AdminModeration) },
                                            onSignOut = onSignOut,
                                            onDeleteAccount = { viewModel.deleteAccount { onSignOut() } }
                                        )
                                    }

                                    ArkSecondaryRoute.AdminModeration -> {
                                        AdminModerationScreen(
                                            reports = reports,
                                            users = allUsersModeration,
                                            onBack = { popRoute() },
                                            onResolveReport = { id, status -> viewModel.resolveReport(id, status) },
                                            onToggleRestrictUser = { uid, restrict -> viewModel.toggleUserRestriction(uid, restrict) },
                                            onPublishChallenge = { title, desc, cat, diff, freq, pts ->
                                                viewModel.adminCreateChallenge(title, desc, cat, diff, freq, pts)
                                            }
                                        )
                                    }
                                }
                            } else {
                                Crossfade(
                                    targetState = selectedTab,
                                    label = "ark_main_tabs"
                                ) { tab ->
                                    when (tab) {
                                        ArkPrimaryTab.HOME -> {
                                            HomeDashboardScreen(
                                                profile = profile,
                                                posts = feedPosts,
                                                stories = stories,
                                                viewedStoryIds = viewedStoryIds,
                                                isFeedLoading = isFeedLoading,
                                                isLoadingMoreFeed = isLoadingMoreFeed,
                                                hasMoreFeed = hasMoreFeed,
                                                myReactions = myReactions,
                                                myPollVotes = myPollVotes,
                                                bookmarkedIds = bookmarkedIds,
                                                challenges = challenges,
                                                challengeProgress = challengeProgress,
                                                groups = myGroups,
                                                recentRooms = myGameRooms,
                                                leaderboard = leaderboard,
                                                unreadDmCount = unreadDmCount,
                                                isAdmin = isAdmin,
                                                onOpenCreatePost = { pushRoute(ArkSecondaryRoute.CreatePost()) },
                                                onOpenExplore = { selectedTab = ArkPrimaryTab.EXPLORE },
                                                onOpenMessages = { pushRoute(ArkSecondaryRoute.MessagesInbox) },
                                                onOpenGroups = { pushRoute(ArkSecondaryRoute.Groups) },
                                                onOpenGames = { pushRoute(ArkSecondaryRoute.GamesZone) },
                                                onAddStory = { showAddStoryDialog = true },
                                                onOpenStory = { st -> pushRoute(ArkSecondaryRoute.StoryViewer(st.id)) },
                                                onRefreshFeed = { feedDelegate.refreshFeed() },
                                                onLoadMoreFeed = { feedDelegate.loadMoreFeed() },
                                                onReaction = { p, r -> feedDelegate.toggleReaction(p, profile, r) },
                                                onOpenComments = { p -> feedDelegate.openComments(p) },
                                                onSharePost = { p -> sharingPost = p },
                                                onToggleBookmark = { pid -> feedDelegate.toggleBookmark(pid) },
                                                onVotePoll = { pid, idx -> feedDelegate.votePoll(pid, idx) },
                                                onEditCaption = { p -> editingPost = p },
                                                onToggleCommentsDisabled = { p ->
                                                    feedDelegate.toggleCommentsDisabled(p.id, !p.commentsDisabled)
                                                },
                                                onDeletePost = { pid -> feedDelegate.deletePost(pid) },
                                                onHidePost = { pid -> feedDelegate.hidePost(pid) },
                                                onMuteAuthor = { uid, name -> feedDelegate.muteUser(uid, name) },
                                                onReportPost = { p -> reportingTarget = "post" to p.id },
                                                onOpenMedia = { p, page -> fullscreenMedia = p to page },
                                                onOpenUserProfile = { uid -> openUserProfile(uid) },
                                                onHashtagClick = { tag -> openHashtag(tag) },
                                                onOpenLikers = { p -> likersPost = p },
                                                onOpenSettings = { pushRoute(ArkSecondaryRoute.SettingsPrivacy) },
                                                onOpenChallenges = { pushRoute(ArkSecondaryRoute.Challenges) },
                                                onOpenLeaderboard = { pushRoute(ArkSecondaryRoute.Leaderboard) },
                                                onOpenAdmin = { pushRoute(ArkSecondaryRoute.AdminModeration) },
                                                onOpenGroup = { gid -> pushRoute(ArkSecondaryRoute.GroupDetail(gid)) },
                                                onOpenGameRoom = { rid -> pushRoute(ArkSecondaryRoute.GameRoom(rid)) }
                                            )
                                        }

                                        ArkPrimaryTab.EXPLORE -> {
                                            ExploreScreen(
                                                currentUser = profile,
                                                posts = explorePosts,
                                                selectedCategory = exploreCategory,
                                                isLoading = isExploreLoading,
                                                hasMore = hasMoreExplore,
                                                myReactions = myReactions,
                                                myPollVotes = myPollVotes,
                                                bookmarkedIds = bookmarkedIds,
                                                recommendedCreators = recommendedCreators,
                                                userSearchResults = exploreUserSearchResults,
                                                postSearchResults = explorePostSearchResults,
                                                selectedHashtag = selectedHashtag,
                                                hashtagPosts = hashtagPosts,
                                                publicCommunities = publicCommunities,
                                                myGroups = myGroups,
                                                myFollowing = following,
                                                outgoingFollowRequests = outgoingFollowRequests,
                                                showBackButton = false,
                                                onBack = {},
                                                onSelectCategory = { feedDelegate.setExploreCategory(it) },
                                                onRefresh = { feedDelegate.refreshExplore() },
                                                onLoadMore = { feedDelegate.loadMoreExplore() },
                                                onSearchQuery = { socialChat.searchExplore(it) },
                                                onSelectHashtag = { socialChat.searchByHashtag(it) },
                                                onClearSearch = { socialChat.clearExploreSearch() },
                                                onFollowUser = { target -> socialChat.followOrRequest(profile, target) },
                                                onUnfollowUser = { uid, name -> socialChat.unfollowUser(uid, name) },
                                                onCancelFollowRequest = { reqId -> socialChat.cancelFollowRequest(reqId) },
                                                onOpenUserProfile = { uid -> openUserProfile(uid) },
                                                onJoinCommunity = { gid ->
                                                    viewModel.joinPublicGroup(gid) { joinedGid ->
                                                        pushRoute(ArkSecondaryRoute.GroupDetail(joinedGid))
                                                    }
                                                },
                                                onOpenGroup = { gid -> pushRoute(ArkSecondaryRoute.GroupDetail(gid)) },
                                                onReaction = { p, r -> feedDelegate.toggleReaction(p, profile, r) },
                                                onOpenComments = { p -> feedDelegate.openComments(p) },
                                                onShare = { p -> sharingPost = p },
                                                onToggleBookmark = { pid -> feedDelegate.toggleBookmark(pid) },
                                                onVotePoll = { pid, idx -> feedDelegate.votePoll(pid, idx) },
                                                onEditCaption = { p -> editingPost = p },
                                                onToggleCommentsDisabled = { p ->
                                                    feedDelegate.toggleCommentsDisabled(p.id, !p.commentsDisabled)
                                                },
                                                onDeletePost = { pid -> feedDelegate.deletePost(pid) },
                                                onHidePost = { pid -> feedDelegate.hidePost(pid) },
                                                onMuteAuthor = { uid, name -> feedDelegate.muteUser(uid, name) },
                                                onReportPost = { p -> reportingTarget = "post" to p.id },
                                                onOpenMedia = { p, page -> fullscreenMedia = p to page },
                                                onOpenLikers = { p -> likersPost = p }
                                            )
                                        }

                                        ArkPrimaryTab.CREATE -> Unit

                                        ArkPrimaryTab.ACTIVITY -> {
                                            ActivityScreen(
                                                incomingFollowRequests = incomingFollowRequests,
                                                incomingFriendRequests = incomingFriendRequests,
                                                pendingTagRequests = pendingTagRequests,
                                                notifications = notifications,
                                                onAcceptFollowRequest = { req -> socialChat.acceptFollowRequest(req, profile) },
                                                onRejectFollowRequest = { reqId -> socialChat.rejectFollowRequest(reqId) },
                                                onAcceptFriendRequest = { req -> viewModel.acceptFriendRequest(req, profile) },
                                                onRejectFriendRequest = { reqId -> viewModel.rejectFriendRequest(reqId) },
                                                onApproveTag = { pid -> socialChat.approvePostTag(pid) },
                                                onDeclineTag = { pid -> socialChat.declineOrRemovePostTag(pid) },
                                                onNotificationClick = { n ->
                                                    if (!n.isRead) viewModel.markNotificationRead(n.id)
                                                    when {
                                                        n.type.contains("friend") -> pushRoute(ArkSecondaryRoute.Friends)
                                                        n.type.contains("follow") -> openUserProfile(n.refId ?: n.senderId)
                                                        n.type.contains("group") && !n.refId.isNullOrBlank() -> pushRoute(ArkSecondaryRoute.GroupDetail(n.refId))
                                                        n.type.contains("game") -> pushRoute(ArkSecondaryRoute.GamesZone)
                                                        n.type.contains("challenge") -> pushRoute(ArkSecondaryRoute.Challenges)
                                                        else -> selectedTab = ArkPrimaryTab.HOME
                                                    }
                                                },
                                                onMarkAllRead = { viewModel.markAllNotificationsRead() },
                                                onOpenUserProfile = { uid -> openUserProfile(uid) },
                                                onOpenFriends = { pushRoute(ArkSecondaryRoute.Friends) },
                                                onOpenNotificationRules = { pushRoute(ArkSecondaryRoute.Notifications) }
                                            )
                                        }

                                        ArkPrimaryTab.PROFILE -> {
                                            ProfileScreen(
                                                profile = profile,
                                                myPosts = myPosts,
                                                myTaggedPosts = myTaggedPosts,
                                                pendingTagRequests = pendingTagRequests,
                                                savedPosts = savedPosts,
                                                drafts = drafts,
                                                myHighlights = myHighlights,
                                                followers = followers,
                                                following = following,
                                                myFriends = friends,
                                                outgoingFollowRequests = outgoingFollowRequests,
                                                myReactions = myReactions,
                                                myPollVotes = myPollVotes,
                                                bookmarkedIds = bookmarkedIds,
                                                onCheckUsername = { u -> viewModel.checkUsernameAvailable(u) },
                                                onSaveProfileDetails = { uname, full, tag, bio, web, preset, pTheme, img ->
                                                    viewModel.updateProfileDetails(uname, full, tag, bio, web, preset, pTheme, img)
                                                },
                                                onRenameHighlight = { id, t -> socialChat.renameHighlight(id, t) },
                                                onDeleteHighlight = { id -> socialChat.deleteHighlight(id) },
                                                onApproveTag = { pid -> socialChat.approvePostTag(pid) },
                                                onDeclineTag = { pid -> socialChat.declineOrRemovePostTag(pid) },
                                                onFollowUser = { target -> socialChat.followOrRequest(profile, target) },
                                                onUnfollowUser = { uid, name -> socialChat.unfollowUser(uid, name) },
                                                onCancelFollowRequest = { reqId -> socialChat.cancelFollowRequest(reqId) },
                                                onRemoveFollower = { uid, name -> socialChat.removeFollower(uid, name) },
                                                onCreatePost = { pushRoute(ArkSecondaryRoute.CreatePost()) },
                                                onAddStory = {
                                                    val myStory = stories.firstOrNull { it.authorId == profile.userId }
                                                    if (myStory != null) {
                                                        pushRoute(ArkSecondaryRoute.StoryViewer(myStory.id))
                                                    } else {
                                                        showAddStoryDialog = true
                                                    }
                                                },
                                                onOpenDraft = { d -> pushRoute(ArkSecondaryRoute.CreatePost(d.id)) },
                                                onDeleteDraft = { dId -> feedDelegate.deleteDraft(dId) },
                                                onReaction = { p, r -> feedDelegate.toggleReaction(p, profile, r) },
                                                onOpenComments = { p -> feedDelegate.openComments(p) },
                                                onSharePost = { p -> sharingPost = p },
                                                onToggleBookmark = { pid -> feedDelegate.toggleBookmark(pid) },
                                                onVotePoll = { pid, idx -> feedDelegate.votePoll(pid, idx) },
                                                onEditCaption = { p -> editingPost = p },
                                                onToggleCommentsDisabled = { p ->
                                                    feedDelegate.toggleCommentsDisabled(p.id, !p.commentsDisabled)
                                                },
                                                onDeletePost = { pid -> feedDelegate.deletePost(pid) },
                                                onOpenMedia = { p, page -> fullscreenMedia = p to page },
                                                onOpenUserProfile = { uid -> openUserProfile(uid) },
                                                onHashtagClick = { tag -> openHashtag(tag) },
                                                onOpenLikers = { p -> likersPost = p },
                                                onOpenSettings = { pushRoute(ArkSecondaryRoute.SettingsPrivacy) },
                                                onOpenNotifications = { pushRoute(ArkSecondaryRoute.Notifications) },
                                                onOpenLeaderboard = { pushRoute(ArkSecondaryRoute.Leaderboard) },
                                                onOpenChallenges = { pushRoute(ArkSecondaryRoute.Challenges) }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            FeedModalOverlays(
                profile = profile,
                friends = friends,
                followers = followers,
                groups = myGroups,
                feedDelegate = feedDelegate,
                showAddStory = showAddStoryDialog,
                onDismissAddStory = { showAddStoryDialog = false },
                commentsPost = commentsPost,
                activeComments = activeComments,
                sharingPost = sharingPost,
                onDismissShare = { sharingPost = null },
                editingPost = editingPost,
                onDismissEdit = { editingPost = null },
                fullscreenMedia = fullscreenMedia,
                onDismissFullscreen = { fullscreenMedia = null },
                likersPost = likersPost,
                onDismissLikers = { likersPost = null },
                reportingTarget = reportingTarget,
                onRequestReport = { tType, tId -> reportingTarget = tType to tId },
                onDismissReport = { reportingTarget = null },
                onSubmitReport = { tType, tId, reason, details ->
                    viewModel.submitReport(tType, tId, reason, details)
                },
                onOpenUserProfile = { uid -> openUserProfile(uid) },
                onSendPostViaDm = { post, targetUid, targetUsername, targetAvatar ->
                    val preview = "Shared Post by @${post.authorUsername}: ${post.caption.ifBlank { post.metaGameName ?: post.postType }.take(120)}"
                    sendTextViaDm(
                        UserProfile(userId = targetUid, username = targetUsername, avatarPreset = targetAvatar),
                        preview
                    )
                }
            )
        }
    }
}

@Composable
private fun SecondaryLoadingCard(
    title: String,
    onBack: () -> Unit
) {
    val colors = ArkThemeTokens.colors
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        LiquidGlassCard(modifier = Modifier.widthIn(max = 360.dp)) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                CircularProgressIndicator(color = colors.accent)
                Text(title, style = MaterialTheme.typography.titleMedium, color = colors.ink)
                TextButton(onClick = onBack) {
                    Text("Go Back", color = colors.accent)
                }
            }
        }
    }
}
