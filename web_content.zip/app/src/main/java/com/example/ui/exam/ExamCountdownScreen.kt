package com.example.ui.exam

import android.Manifest
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.EventNote
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.model.ExamEntity
import com.example.data.model.SubjectEntity
import com.example.data.model.SubjectWithStats

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExamCountdownScreen(
    activeExams: List<ExamEntity>,
    archivedExams: List<ExamEntity>,
    subjectsMap: Map<Long, SubjectEntity>,
    activeSubjects: List<SubjectWithStats>,
    onOpenDrawer: () -> Unit,
    onAddExam: (String, String, Long?, Boolean, Boolean, Boolean) -> Unit,
    onUpdateExam: (ExamEntity) -> Unit,
    onDeleteExam: (Long) -> Unit
) {
    val context = LocalContext.current
    var showAddDialog by remember { mutableStateOf(false) }
    var examBeingEdited by remember { mutableStateOf<ExamEntity?>(null) }
    var showDeleteConfirmDialog by remember { mutableStateOf<ExamEntity?>(null) }
    var showArchivedSheet by remember { mutableStateOf(false) }

    // Dialog Input States
    var nameInput by remember { mutableStateOf("") }
    var dateInput by remember { mutableStateOf("") }
    var selectedSubjectId by remember { mutableStateOf<Long?>(null) }
    var remind30 by remember { mutableStateOf(false) }
    var remind7 by remember { mutableStateOf(true) }
    var remind1 by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    // Android 13+ Notification permission request launcher
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (!isGranted) {
            Toast.makeText(context, "Notifications disabled. Reminders will not ring until enabled in settings.", Toast.LENGTH_LONG).show()
        }
    }

    fun openAdd() {
        examBeingEdited = null
        nameInput = ""
        dateInput = ""
        selectedSubjectId = activeSubjects.firstOrNull()?.subject?.id
        remind30 = false
        remind7 = true
        remind1 = true
        errorMessage = null
        showAddDialog = true
    }

    fun openEdit(exam: ExamEntity) {
        examBeingEdited = exam
        nameInput = exam.name
        dateInput = exam.date
        selectedSubjectId = exam.subjectId
        remind30 = exam.remind30Days
        remind7 = exam.remind7Days
        remind1 = exam.remind1Day
        errorMessage = null
        showAddDialog = true
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Exam Countdown",
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onOpenDrawer,
                        modifier = Modifier.testTag("exam_menu_drawer_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Menu,
                            contentDescription = "Open left navigation drawer"
                        )
                    }
                },
                actions = {
                    if (archivedExams.isNotEmpty()) {
                        IconButton(
                            onClick = { showArchivedSheet = true },
                            modifier = Modifier.testTag("open_archived_exams_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Archive,
                                contentDescription = "View past archived exams"
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header summary row with Add button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Upcoming Exams",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${activeExams.size} upcoming exams scheduled",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                FilledTonalButton(
                    onClick = {
                        // Request notification permission if Android 13+
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !ExamNotificationHelper.hasNotificationPermission(context)) {
                            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                        openAdd()
                    },
                    modifier = Modifier.testTag("add_exam_header_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Exam")
                }
            }

            if (activeExams.isEmpty()) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp)
                        .testTag("empty_exams_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.EventNote,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No upcoming exams yet",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Add your exam dates to see days left countdowns and receive timely review reminders.",
                            style = MaterialTheme.typography.bodySmall,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { openAdd() },
                            modifier = Modifier.testTag("add_exam_empty_state_button")
                        ) {
                            Text("Add Your First Exam")
                        }
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(activeExams, key = { it.id }) { exam ->
                        val isNearest = exam.id == activeExams.firstOrNull()?.id
                        val subject = exam.subjectId?.let { subjectsMap[it] }

                        ExamItemCard(
                            exam = exam,
                            subject = subject,
                            isNearest = isNearest,
                            onEdit = { openEdit(exam) },
                            onDelete = { showDeleteConfirmDialog = exam }
                        )
                    }
                }
            }
        }
    }

    // Add / Edit Exam Dialog
    if (showAddDialog) {
        ExamDialog(
            isEditing = examBeingEdited != null,
            name = nameInput,
            onNameChange = { nameInput = it; errorMessage = null },
            date = dateInput,
            onDateChange = { dateInput = it; errorMessage = null },
            selectedSubjectId = selectedSubjectId,
            onSubjectChange = { selectedSubjectId = it },
            activeSubjects = activeSubjects,
            remind30 = remind30,
            onRemind30Change = { remind30 = it },
            remind7 = remind7,
            onRemind7Change = { remind7 = it },
            remind1 = remind1,
            onRemind1Change = { remind1 = it },
            errorMessage = errorMessage,
            onDismiss = { showAddDialog = false },
            onSave = {
                val trimmedName = nameInput.trim()
                val trimmedDate = dateInput.trim()

                if (trimmedName.isEmpty()) {
                    errorMessage = "Please enter an exam name"
                    return@ExamDialog
                }
                if (!trimmedDate.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) {
                    errorMessage = "Please enter date in format YYYY-MM-DD"
                    return@ExamDialog
                }

                if (remind30 || remind7 || remind1) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !ExamNotificationHelper.hasNotificationPermission(context)) {
                        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }

                val editing = examBeingEdited
                if (editing != null) {
                    onUpdateExam(
                        editing.copy(
                            name = trimmedName,
                            date = trimmedDate,
                            subjectId = selectedSubjectId,
                            remind30Days = remind30,
                            remind7Days = remind7,
                            remind1Day = remind1
                        )
                    )
                } else {
                    onAddExam(trimmedName, trimmedDate, selectedSubjectId, remind30, remind7, remind1)
                }
                showAddDialog = false
            }
        )
    }

    // Delete Exam Confirmation Dialog
    if (showDeleteConfirmDialog != null) {
        val exam = showDeleteConfirmDialog!!
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = null },
            title = { Text("Delete Exam?") },
            text = { Text("Are you sure you want to delete \"${exam.name}\"?") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteExam(exam.id)
                        showDeleteConfirmDialog = null
                    },
                    modifier = Modifier.testTag("confirm_delete_exam_button")
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Archived Exams Bottom Sheet
    if (showArchivedSheet) {
        ArchivedExamsSheet(
            archivedExams = archivedExams,
            subjectsMap = subjectsMap,
            onDismiss = { showArchivedSheet = false },
            onDelete = { onDeleteExam(it) }
        )
    }
}
