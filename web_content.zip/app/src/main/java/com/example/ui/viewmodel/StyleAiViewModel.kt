package com.example.ui.viewmodel

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.catalog.FashionCatalogDataSource
import com.example.data.model.AiOutfitRecommendation
import com.example.data.model.ChatMessage
import com.example.data.model.FashionProduct
import com.example.data.model.RecentlyViewedProduct
import com.example.data.model.SavedOutfit
import com.example.data.model.TryOnSession
import com.example.data.model.UserProfile
import com.example.data.model.WishlistItem
import com.example.data.repository.StyleAiRepository
import com.example.util.LoginPersonaPrefs
import com.example.util.PrivatePhotoStorage
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.ImagePart
import com.google.firebase.ai.type.ResponseModality
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import java.util.UUID
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

private const val TAG = "StyleAiViewModel"

sealed interface DataUiState<out T> {
    data object Loading : DataUiState<Nothing>
    data class Success<T>(val data: T) : DataUiState<T>
    data class Error(val message: String) : DataUiState<Nothing>
}

sealed interface StylistUiState {
    data object Idle : StylistUiState
    data object Loading : StylistUiState
    data class Success(
        val summaryHeadline: String,
        val recommendations: List<AiOutfitRecommendation>
    ) : StylistUiState
    data class Error(val message: String) : StylistUiState
}

sealed interface TryOnUiState {
    data object Idle : TryOnUiState
    data object Generating : TryOnUiState
    data class Success(
        val originalBitmap: Bitmap,
        val generatedBitmap: Bitmap,
        val product: FashionProduct,
        val selectedColor: String,
        val selectedSize: String,
        val aiFitNotes: String,
        val savedSessionId: String? = null
    ) : TryOnUiState
    data class Error(val message: String) : TryOnUiState
}

sealed interface ChatUiState {
    data object Idle : ChatUiState
    data class Streaming(val partialText: String) : ChatUiState
    data class Error(val message: String) : ChatUiState
}

class StyleAiViewModel(
    private val repository: StyleAiRepository,
    private val currentUserId: String,
    private val displayName: String
) : ViewModel() {

    // 1. Structured JSON Stylist Model (gemini-3.8-flash)
    private val stylistSchema = Schema.obj(
        properties = mapOf(
            "summaryHeadline" to Schema.string(description = "A concise luxury stylist summary of the personalized lookbook"),
            "recommendations" to Schema.array(
                items = Schema.obj(
                    properties = mapOf(
                        "outfitTitle" to Schema.string(description = "Name of the recommended outfit or garment"),
                        "category" to Schema.string(description = "Clothing category"),
                        "occasion" to Schema.string(description = "Target occasion"),
                        "matchedProductId" to Schema.string(description = "ID from the catalog that best matches this recommendation"),
                        "whyRecommended" to Schema.string(description = "Detailed stylist explanation of why this outfit suits the user"),
                        "stylingTips" to Schema.string(description = "How to layer, drape, or accessorize this look"),
                        "colorPalette" to Schema.string(description = "Recommended color harmony"),
                        "estimatedPriceInr" to Schema.integer(description = "Estimated price in INR"),
                        "matchingFootwear" to Schema.string(description = "Matching shoes"),
                        "matchingAccessories" to Schema.string(description = "Matching accessories")
                    )
                ),
                description = "List of 3 to 4 personalized outfit recommendations"
            )
        )
    )

    private val stylistModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = stylistSchema
            }
        )
    }

    // 2. Conversational Chat Stylist Model (gemini-3.8-flash)
    private val chatModel by lazy {
        Firebase.ai.generativeModel("gemini-3.8-flash")
    }

    // 3. Realistic Virtual Try-On Image Model (gemini-nano-banana-2.1)
    private val tryOnImageModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-nano-banana-2.1",
            generationConfig = generationConfig {
                responseModalities = listOf(ResponseModality.IMAGE)
            }
        )
    }

    // Firestore Reactive Streams (Two-Tier Flow Error Handling)
    val userProfileState: StateFlow<DataUiState<UserProfile?>> = repository.observeUserProfile(currentUserId)
        .map<UserProfile?, DataUiState<UserProfile?>> { DataUiState.Success(it) }
        .catch { e ->
            Log.w(TAG, "Error observing user profile", e)
            emit(DataUiState.Error(e.message ?: "Failed to load user profile"))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), DataUiState.Loading)

    val wishlistItemsState: StateFlow<DataUiState<List<WishlistItem>>> = repository.observeWishlistItems(currentUserId)
        .map<List<WishlistItem>, DataUiState<List<WishlistItem>>> { DataUiState.Success(it) }
        .catch { e ->
            Log.w(TAG, "Error observing wishlist items", e)
            emit(DataUiState.Error(e.message ?: "Failed to load wishlist items"))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), DataUiState.Loading)

    val savedOutfitsState: StateFlow<DataUiState<List<SavedOutfit>>> = repository.observeSavedOutfits(currentUserId)
        .map<List<SavedOutfit>, DataUiState<List<SavedOutfit>>> { DataUiState.Success(it) }
        .catch { e ->
            Log.w(TAG, "Error observing saved outfits", e)
            emit(DataUiState.Error(e.message ?: "Failed to load saved outfits"))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), DataUiState.Loading)

    val tryOnSessionsState: StateFlow<DataUiState<List<TryOnSession>>> = repository.observeTryOnSessions(currentUserId)
        .map<List<TryOnSession>, DataUiState<List<TryOnSession>>> { DataUiState.Success(it) }
        .catch { e ->
            Log.w(TAG, "Error observing try-on sessions", e)
            emit(DataUiState.Error(e.message ?: "Failed to load try-on sessions"))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), DataUiState.Loading)

    val recentlyViewedState: StateFlow<DataUiState<List<RecentlyViewedProduct>>> = repository.observeRecentlyViewed(currentUserId)
        .map<List<RecentlyViewedProduct>, DataUiState<List<RecentlyViewedProduct>>> { DataUiState.Success(it) }
        .catch { e ->
            Log.w(TAG, "Error observing recently viewed products", e)
            emit(DataUiState.Error(e.message ?: "Failed to load recently viewed products"))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), DataUiState.Loading)

    // Catalogue & Filters
    private val _catalogProducts = MutableStateFlow<List<FashionProduct>>(FashionCatalogDataSource.getCuratedCatalog())
    val catalogProducts: StateFlow<List<FashionProduct>> = _catalogProducts.asStateFlow()

    private val _catalogFeedStatus = MutableStateFlow("Syncing Authorized Partner Feeds...")
    val catalogFeedStatus: StateFlow<String> = _catalogFeedStatus.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _selectedOccasion = MutableStateFlow("All")
    val selectedOccasion: StateFlow<String> = _selectedOccasion.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _maxPriceFilter = MutableStateFlow(10000)
    val maxPriceFilter: StateFlow<Int> = _maxPriceFilter.asStateFlow()

    // Selected Product for Detail / Try-On / Price Comparison
    private val _selectedProduct = MutableStateFlow<FashionProduct>(FashionCatalogDataSource.getCuratedCatalog().first())
    val selectedProduct: StateFlow<FashionProduct> = _selectedProduct.asStateFlow()

    private val _selectedColorVariant = MutableStateFlow(FashionCatalogDataSource.getCuratedCatalog().first().color)
    val selectedColorVariant: StateFlow<String> = _selectedColorVariant.asStateFlow()

    private val _selectedSizeVariant = MutableStateFlow("M")
    val selectedSizeVariant: StateFlow<String> = _selectedSizeVariant.asStateFlow()

    // Personal Photo State
    private val _userPhotoBitmap = MutableStateFlow<Bitmap?>(null)
    val userPhotoBitmap: StateFlow<Bitmap?> = _userPhotoBitmap.asStateFlow()

    private val _photoConsentAccepted = MutableStateFlow(true)
    val photoConsentAccepted: StateFlow<Boolean> = _photoConsentAccepted.asStateFlow()

    // AI States
    private val _stylistUiState = MutableStateFlow<StylistUiState>(StylistUiState.Idle)
    val stylistUiState: StateFlow<StylistUiState> = _stylistUiState.asStateFlow()

    private val _tryOnUiState = MutableStateFlow<TryOnUiState>(TryOnUiState.Idle)
    val tryOnUiState: StateFlow<TryOnUiState> = _tryOnUiState.asStateFlow()

    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                id = "welcome_msg",
                isUser = false,
                text = "Welcome to StyleAI Atelier. Ask me for outfit ideas for any occasion or budget — for example: \"Suggest a stylish college outfit under ₹1,000\" or \"What should I wear to a formal winter wedding?\"",
                recommendedProducts = FashionCatalogDataSource.getCuratedCatalog().take(2)
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _chatUiState = MutableStateFlow<ChatUiState>(ChatUiState.Idle)
    val chatUiState: StateFlow<ChatUiState> = _chatUiState.asStateFlow()

    private val _statusBannerMessage = MutableStateFlow<String?>(null)
    val statusBannerMessage: StateFlow<String?> = _statusBannerMessage.asStateFlow()

    // Indian AI Showroom Salesman State (Female AI Ananya for Male User / Male AI Kabir for Female User)
    private val _userGender = MutableStateFlow("MALE")
    val userGender: StateFlow<String> = _userGender.asStateFlow()

    private val _preferredLanguage = MutableStateFlow("Auto Local")
    val preferredLanguage: StateFlow<String> = _preferredLanguage.asStateFlow()

    private val _salesmanPitchText = MutableStateFlow(
        LoginPersonaPrefs.buildInstantSalesPitch("WELCOME", "MALE", "Auto Local").first
    )
    val salesmanPitchText: StateFlow<String> = _salesmanPitchText.asStateFlow()

    private val _salesmanActionLabel = MutableStateFlow(
        LoginPersonaPrefs.buildInstantSalesPitch("WELCOME", "MALE", "Auto Local").second
    )
    val salesmanActionLabel: StateFlow<String> = _salesmanActionLabel.asStateFlow()

    private val _salesmanTargetRoute = MutableStateFlow("DISCOVER")
    val salesmanTargetRoute: StateFlow<String> = _salesmanTargetRoute.asStateFlow()

    private val _isSalesmanBubbleVisible = MutableStateFlow(true)
    val isSalesmanBubbleVisible: StateFlow<Boolean> = _isSalesmanBubbleVisible.asStateFlow()

    init {
        refreshLiveCatalogFeed()
    }

    fun initializeSessionWithLoginPersona(
        context: Context,
        onSpeakPitch: (text: String, gender: String, lang: String) -> Unit
    ) {
        val gender = LoginPersonaPrefs.getUserGender(context)
        val lang = LoginPersonaPrefs.getPreferredLanguage(context)
        _userGender.value = gender
        _preferredLanguage.value = lang

        val (welcomePitch, actionLabel) = LoginPersonaPrefs.buildInstantSalesPitch(
            screenKey = "WELCOME",
            userGender = gender,
            preferredLanguage = lang,
            featuredProduct = _selectedProduct.value
        )
        _salesmanPitchText.value = welcomePitch
        _salesmanActionLabel.value = actionLabel
        _salesmanTargetRoute.value = "DISCOVER"
        _isSalesmanBubbleVisible.value = true

        onSpeakPitch(welcomePitch, gender, lang)

        viewModelScope.launch {
            val res = repository.createOrInitializeProfile(
                displayName = displayName,
                userGender = gender,
                preferredLanguage = lang
            )
            // Ensure Firestore reflects the user's latest login gender & language selection
            if (LoginPersonaPrefs.hasConfirmedGenderAtLogin(context)) {
                repository.updateGenderAndLanguage(gender, lang)
            } else {
                res.getOrNull()?.let { existingProfile ->
                    if (existingProfile.userGender.isNotBlank()) {
                        _userGender.value = existingProfile.userGender
                    }
                    if (existingProfile.preferredLanguage.isNotBlank()) {
                        _preferredLanguage.value = existingProfile.preferredLanguage
                    }
                }
            }
        }
    }

    fun updateUserGenderAndLanguage(
        context: Context,
        newGender: String,
        newLanguage: String,
        currentScreenKey: String,
        onSpeakPitch: (text: String, gender: String, lang: String) -> Unit
    ) {
        val normalizedGender = if (newGender.uppercase() == "FEMALE") "FEMALE" else "MALE"
        _userGender.value = normalizedGender
        _preferredLanguage.value = newLanguage
        LoginPersonaPrefs.saveLoginPersona(context, normalizedGender, newLanguage)

        val (pitch, action) = LoginPersonaPrefs.buildInstantSalesPitch(
            screenKey = currentScreenKey,
            userGender = normalizedGender,
            preferredLanguage = newLanguage,
            featuredProduct = _selectedProduct.value
        )
        _salesmanPitchText.value = pitch
        _salesmanActionLabel.value = action
        _isSalesmanBubbleVisible.value = true

        onSpeakPitch(pitch, normalizedGender, newLanguage)

        viewModelScope.launch {
            repository.updateGenderAndLanguage(normalizedGender, newLanguage)
        }
    }

    fun dismissSalesmanBubble() {
        _isSalesmanBubbleVisible.value = false
    }

    fun showSalesmanBubble() {
        _isSalesmanBubbleVisible.value = true
    }

    fun onSalesmanDirectScreenChange(
        screenKey: String,
        featuredProduct: FashionProduct? = null,
        onSpeakPitch: (text: String, gender: String, lang: String) -> Unit
    ) {
        val gender = _userGender.value
        val lang = _preferredLanguage.value
        val product = featuredProduct ?: _selectedProduct.value
        val (instantPitch, actionLabel) = LoginPersonaPrefs.buildInstantSalesPitch(
            screenKey = screenKey,
            userGender = gender,
            preferredLanguage = lang,
            featuredProduct = product
        )
        _salesmanPitchText.value = instantPitch
        _salesmanActionLabel.value = actionLabel
        _salesmanTargetRoute.value = when (screenKey) {
            "HOME", "WELCOME" -> "DISCOVER"
            "DISCOVER" -> "PRODUCT_DETAIL"
            "PRODUCT_DETAIL" -> "TRY_ON"
            "TRY_ON" -> "PRODUCT_DETAIL"
            else -> "DISCOVER"
        }
        _isSalesmanBubbleVisible.value = true
        onSpeakPitch(instantPitch, gender, lang)
    }

    fun askSalesmanCustomPitch(
        userQuestion: String,
        onSpeakPitch: (text: String, gender: String, lang: String) -> Unit
    ) {
        val trimmed = userQuestion.trim()
        if (trimmed.isBlank()) return

        val gender = _userGender.value
        val lang = _preferredLanguage.value
        val persona = LoginPersonaPrefs.getOppositeGenderSalesmanPersona(gender)
        val effectiveLanguage = LoginPersonaPrefs.resolveEffectiveLanguageKey(lang)

        val matchedProducts = matchProductsForQueryAndResponse(trimmed, "")
        val topProduct = matchedProducts.firstOrNull() ?: _selectedProduct.value
        _selectedProduct.value = topProduct

        val catalogSnippet = matchedProducts.joinToString("\n") {
            "- ${it.name} by ${it.brand}: ₹${it.priceInr} on ${it.primaryRetailer} (${it.occasion})"
        }

        val prompt = buildString {
            appendLine("You are ${persona.assistantName}, a charismatic, warm Indian AI Showroom Fashion Salesperson (${persona.roleTitle}).")
            appendLine("The customer is ${if (gender == "FEMALE") "Female (address her respectfully as Ma'am)" else "Male (address him respectfully as Sir)"}.")
            appendLine("CRITICAL LANGUAGE RULE: Respond ENTIRELY in $effectiveLanguage so the customer feels at home in their local Indian language.")
            appendLine("Keep your response to 2 short, energetic showroom salesperson sentences (max 45 words) that sound natural when spoken aloud.")
            appendLine("Direct the customer to this best matching outfit and its exact ₹ price:")
            appendLine(catalogSnippet)
            appendLine("Customer asked: $trimmed")
        }

        viewModelScope.launch {
            _isSalesmanBubbleVisible.value = true
            _salesmanPitchText.value = "${persona.assistantName}: Finding the best showroom deal for you, ${persona.userHonorific}..."
            try {
                val response = withTimeout(60_000L) {
                    chatModel.generateContent(prompt)
                }
                val reply = response.text?.trim().orEmpty()
                if (reply.isNotBlank()) {
                    _salesmanPitchText.value = reply
                    _salesmanActionLabel.value = "View ₹${topProduct.priceInr} Deal"
                    _salesmanTargetRoute.value = "PRODUCT_DETAIL"
                    onSpeakPitch(reply, gender, lang)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.w(TAG, "Custom salesman pitch fallback used: ${e.message}")
                val (fallbackPitch, fallbackAction) = LoginPersonaPrefs.buildInstantSalesPitch(
                    screenKey = "PRODUCT_DETAIL",
                    userGender = gender,
                    preferredLanguage = lang,
                    featuredProduct = topProduct
                )
                _salesmanPitchText.value = fallbackPitch
                _salesmanActionLabel.value = fallbackAction
                _salesmanTargetRoute.value = "PRODUCT_DETAIL"
                onSpeakPitch(fallbackPitch, gender, lang)
            }
        }
    }

    fun clearStatusBanner() {
        _statusBannerMessage.value = null
    }

    fun refreshLiveCatalogFeed() {
        viewModelScope.launch {
            _catalogFeedStatus.value = "Refreshing live prices across Myntra, AJIO, Amazon & Flipkart..."
            val (items, status) = FashionCatalogDataSource.fetchSynchronizedCatalog()
            _catalogProducts.value = items
            _catalogFeedStatus.value = status
        }
    }

    fun loadExistingPersonalPhoto(context: Context) {
        viewModelScope.launch {
            val loaded = PrivatePhotoStorage.loadUserPersonalPhoto(context)
            _userPhotoBitmap.value = loaded
        }
    }

    fun setPhotoConsent(context: Context, granted: Boolean) {
        _photoConsentAccepted.value = granted
        viewModelScope.launch {
            if (!granted) {
                PrivatePhotoStorage.deleteUserPersonalPhoto(context)
                _userPhotoBitmap.value = null
            }
            repository.updatePhotoState(
                consentGranted = granted,
                hasUploadedPhoto = _userPhotoBitmap.value != null
            )
        }
    }

    fun onPersonalPhotoCaptured(context: Context, bitmap: Bitmap) {
        viewModelScope.launch {
            val savedBitmap = PrivatePhotoStorage.saveUserPersonalPhoto(context, bitmap)
            _userPhotoBitmap.value = savedBitmap
            _photoConsentAccepted.value = true
            repository.updatePhotoState(consentGranted = true, hasUploadedPhoto = true)
            _statusBannerMessage.value = "Personal photo captured and saved to private on-device storage."
        }
    }

    fun onPersonalPhotoSelectedFromUri(context: Context, uri: Uri) {
        viewModelScope.launch {
            val savedBitmap = PrivatePhotoStorage.saveUserPhotoFromUri(context, uri)
            if (savedBitmap != null) {
                _userPhotoBitmap.value = savedBitmap
                _photoConsentAccepted.value = true
                repository.updatePhotoState(consentGranted = true, hasUploadedPhoto = true)
                _statusBannerMessage.value = "Personal photo uploaded and encrypted in private storage."
            } else {
                val fallbackPreset = _userGender.value.ifBlank { "MALE" }
                val fallbackBitmap = PrivatePhotoStorage.saveStudioModelPhotoPreset(context, fallbackPreset)
                _userPhotoBitmap.value = fallbackBitmap
                _photoConsentAccepted.value = true
                repository.updatePhotoState(consentGranted = true, hasUploadedPhoto = true)
                _statusBannerMessage.value = "Selected file could not be read; loaded Studio Portrait photo for Virtual Try-On."
            }
        }
    }

    fun onUploadStudioPresetPhoto(context: Context, presetType: String) {
        viewModelScope.launch {
            val savedBitmap = PrivatePhotoStorage.saveStudioModelPhotoPreset(context, presetType)
            _userPhotoBitmap.value = savedBitmap
            _photoConsentAccepted.value = true
            repository.updatePhotoState(consentGranted = true, hasUploadedPhoto = true)
            val label = when {
                presetType.uppercase().contains("FEMALE") -> "Female Studio Portrait"
                presetType.uppercase().contains("STREET") -> "Streetwear Portrait"
                else -> "Male Studio Portrait"
            }
            _statusBannerMessage.value = "$label uploaded and ready for AI Virtual Try-On!"
        }
    }

    fun deletePersonalPhoto(context: Context) {
        viewModelScope.launch {
            PrivatePhotoStorage.deleteUserPersonalPhoto(context)
            _userPhotoBitmap.value = null
            repository.updatePhotoState(consentGranted = _photoConsentAccepted.value, hasUploadedPhoto = false)
            _statusBannerMessage.value = "Personal photo permanently deleted from your device."
        }
    }

    fun updateCategoryFilter(category: String) {
        _selectedCategory.value = category
    }

    fun updateOccasionFilter(occasion: String) {
        _selectedOccasion.value = occasion
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun updateMaxPriceFilter(maxInr: Int) {
        _maxPriceFilter.value = maxInr
    }

    fun selectProduct(product: FashionProduct) {
        _selectedProduct.value = product
        _selectedColorVariant.value = product.color
        _selectedSizeVariant.value = product.availableSizes.firstOrNull() ?: "M"
        viewModelScope.launch {
            repository.recordRecentlyViewed(product)
        }
    }

    fun selectColorVariant(color: String) {
        _selectedColorVariant.value = color
    }

    fun selectSizeVariant(size: String) {
        _selectedSizeVariant.value = size
    }

    fun addProductToWishlist(
        product: FashionProduct,
        selectedColor: String = _selectedColorVariant.value.ifBlank { product.color },
        selectedSize: String = _selectedSizeVariant.value.ifBlank { "M" },
        notes: String = product.stylistWhyItWorks
    ) {
        viewModelScope.launch {
            val res = repository.addItemToWishlist(
                productId = product.id,
                title = product.name,
                brand = product.brand,
                category = product.category,
                occasion = product.occasion,
                selectedColor = selectedColor.ifBlank { product.color },
                selectedSize = selectedSize.ifBlank { "M" },
                priceInr = product.priceInr,
                originalPriceInr = product.originalPriceInr,
                imageUrl = product.imageUrl,
                productUrl = product.productUrl,
                retailer = product.primaryRetailer,
                notes = notes.ifBlank { product.stylistWhyItWorks }
            )
            if (res.isSuccess) {
                _statusBannerMessage.value = "Added \"${product.name}\" to your Wishlist."
            } else {
                _statusBannerMessage.value = "Could not add to Wishlist: ${res.exceptionOrNull()?.localizedMessage}"
            }
        }
    }

    fun updateWishlistItemVariant(
        itemId: String,
        selectedColor: String,
        selectedSize: String,
        notes: String
    ) {
        viewModelScope.launch {
            val res = repository.updateWishlistItemVariant(
                itemId = itemId,
                selectedColor = selectedColor,
                selectedSize = selectedSize,
                notes = notes
            )
            if (res.isSuccess) {
                _statusBannerMessage.value = "Updated Wishlist item preferences ($selectedSize • $selectedColor)."
            } else {
                _statusBannerMessage.value = "Could not update Wishlist item: ${res.exceptionOrNull()?.localizedMessage}"
            }
        }
    }

    fun removeWishlistItem(itemId: String) {
        viewModelScope.launch {
            repository.removeWishlistItem(itemId)
            _statusBannerMessage.value = "Removed item from your Wishlist."
        }
    }

    fun saveProductToWardrobe(product: FashionProduct, customNote: String? = null) {
        viewModelScope.launch {
            val activeColor = _selectedColorVariant.value.ifBlank { product.color }
            val activeSize = _selectedSizeVariant.value.ifBlank { "M" }
            val noteText = customNote ?: product.stylistWhyItWorks

            // Save to both Wishlist and Wardrobe per userId in Firestore
            repository.addItemToWishlist(
                productId = product.id,
                title = product.name,
                brand = product.brand,
                category = product.category,
                occasion = product.occasion,
                selectedColor = activeColor,
                selectedSize = activeSize,
                priceInr = product.priceInr,
                originalPriceInr = product.originalPriceInr,
                imageUrl = product.imageUrl,
                productUrl = product.productUrl,
                retailer = product.primaryRetailer,
                notes = noteText
            )

            val res = repository.saveOutfitToWardrobe(
                outfitId = product.id,
                title = product.name,
                category = product.category,
                occasion = product.occasion,
                brand = product.brand,
                color = activeColor,
                priceInr = product.priceInr,
                imageUrl = product.imageUrl,
                productUrl = product.productUrl,
                retailer = product.primaryRetailer,
                stylistNote = noteText,
                matchingShoes = product.matchingShoes,
                matchingAccessories = product.matchingAccessories
            )
            if (res.isSuccess) {
                _statusBannerMessage.value = "Saved \"${product.name}\" to Wishlist & Wardrobe."
            } else {
                _statusBannerMessage.value = "Could not save item: ${res.exceptionOrNull()?.localizedMessage}"
            }
        }
    }

    fun removeOutfitFromWardrobe(outfitId: String) {
        viewModelScope.launch {
            repository.removeSavedOutfit(outfitId)
            _statusBannerMessage.value = "Removed outfit from My Wardrobe."
        }
    }

    fun deleteTryOnSessionItem(sessionId: String) {
        viewModelScope.launch {
            repository.deleteTryOnSession(sessionId)
            _statusBannerMessage.value = "Try-on preview removed."
        }
    }

    fun toggleMembershipTier(currentTier: String) {
        val nextTier = if (currentTier == "PREMIUM") "FREE" else "PREMIUM"
        viewModelScope.launch {
            repository.updateMembershipTier(nextTier)
            _statusBannerMessage.value = if (nextTier == "PREMIUM") {
                "Upgraded to StyleAI Noir Atelier Premium! Unlimited Try-Ons & Styling unlocked."
            } else {
                "Switched to Free Membership tier."
            }
        }
    }

    fun saveBodyMeasurements(
        heightCm: Int,
        weightKg: Int,
        preferredTopSize: String,
        preferredBottomSize: String,
        bodyFitPreference: String
    ) {
        val clampedHeight = heightCm.coerceIn(100, 250)
        val clampedWeight = weightKg.coerceIn(30, 250)
        val safeTop = preferredTopSize.trim().ifBlank { "M" }
        val safeBottom = preferredBottomSize.trim().ifBlank { "32" }
        val safeFit = bodyFitPreference.trim().ifBlank { "Tailored Fit" }

        // Automatically sync the active try-on size variant to the user's calibrated top size
        _selectedSizeVariant.value = safeTop

        viewModelScope.launch {
            val res = repository.updateBodyMeasurements(
                heightCm = clampedHeight,
                weightKg = clampedWeight,
                preferredTopSize = safeTop,
                preferredBottomSize = safeBottom,
                bodyFitPreference = safeFit
            )
            if (res.isSuccess) {
                _statusBannerMessage.value = "Body measurements (${clampedHeight} cm, ${clampedWeight} kg, Size $safeTop / $safeBottom • $safeFit) saved for Virtual Try-On calibration."
            } else {
                _statusBannerMessage.value = "Could not save body measurements: ${res.exceptionOrNull()?.localizedMessage}"
            }
        }
    }

    fun deleteAccountAndPersonalData(context: Context, onComplete: () -> Unit) {
        viewModelScope.launch {
            PrivatePhotoStorage.clearAllPrivatePhotos(context)
            _userPhotoBitmap.value = null
            repository.deleteAllUserData()
            onComplete()
        }
    }

    /**
     * Generates personalized AI fashion recommendations using Gemini 3.8 Flash structured output.
     * Supports both full questionnaire answers and instant skip-questions mode.
     */
    fun generatePersonalizedRecommendations(
        preferredStyle: String,
        occasion: String,
        clothingPreferences: String,
        preferredColors: String,
        budgetInr: Int,
        shoppingPreferences: String,
        skippedQuestions: Boolean = false
    ) {
        val profile = (userProfileState.value as? DataUiState.Success)?.data
        if (profile != null && profile.membershipTier == "FREE" && profile.recommendationsUsed >= 5L) {
            _stylistUiState.value = StylistUiState.Error(
                "Free membership limit reached (5/5 AI Stylist sessions used). Upgrade to Premium in Profile for unlimited AI styling."
            )
            return
        }

        viewModelScope.launch {
            _stylistUiState.value = StylistUiState.Loading
            if (!skippedQuestions) {
                repository.updateStylingPreferences(
                    preferredStyle = preferredStyle,
                    preferredOccasion = occasion,
                    preferredColors = preferredColors,
                    budgetMaxInr = budgetInr.toLong(),
                    preferredRetailers = shoppingPreferences
                )
            }

            val catalogSummary = _catalogProducts.value.joinToString("\n") { p ->
                "- ID: ${p.id} | Name: ${p.name} | Category: ${p.category} | Occasion: ${p.occasion} | Price: ₹${p.priceInr} | Brand: ${p.brand}"
            }

            val userHeight = profile?.heightCm ?: 172L
            val userWeight = profile?.weightKg ?: 68L
            val userTopSize = profile?.preferredTopSize ?: "M"
            val userBottomSize = profile?.preferredBottomSize ?: "32"
            val userFitPref = profile?.bodyFitPreference ?: "Tailored Fit"

            val promptText = buildString {
                appendLine("You are StyleAI, an elite personal fashion stylist and luxury wardrobe director.")
                appendLine("User Body Measurements & Fit Calibration:")
                appendLine("- Height: ${userHeight} cm | Weight: ${userWeight} kg")
                appendLine("- Preferred Top Size: $userTopSize | Preferred Waist/Bottom Size: $userBottomSize")
                appendLine("- Silhouette & Fit Preference: $userFitPref")
                if (skippedQuestions) {
                    appendLine("The user chose to skip the questionnaire and wants immediate versatile recommendations across College, Casual, Office, Traditional Indian, and Party looks.")
                } else {
                    appendLine("User Styling Preferences:")
                    appendLine("- Preferred Fashion Style: $preferredStyle")
                    appendLine("- Target Occasion: $occasion")
                    appendLine("- Clothing Preferences: $clothingPreferences")
                    appendLine("- Preferred Colours: $preferredColors")
                    appendLine("- Maximum Budget: ₹$budgetInr")
                    appendLine("- Preferred Shopping Platforms: $shoppingPreferences")
                }
                appendLine("\nAvailable Authorized Catalogue Products (match `matchedProductId` to one of these IDs):")
                appendLine(catalogSummary)
                appendLine("\nProvide 3 to 4 curated outfit recommendations. For each outfit, clearly explain WHY you recommend it for the user's ${userHeight}cm/${userWeight}kg body proportions, size ($userTopSize/$userBottomSize, $userFitPref), color harmony, occasion, and budget.")
            }

            try {
                val userPhoto = _userPhotoBitmap.value
                val response = withTimeout(60_000L) {
                    if (userPhoto != null) {
                        stylistModel.generateContent(
                            content {
                                image(userPhoto)
                                text("$promptText\nAlso consider the user's uploaded photo appearance and lighting when explaining why each outfit suits them.")
                            }
                        )
                    } else {
                        stylistModel.generateContent(promptText)
                    }
                }

                val jsonString = response.text ?: throw IllegalStateException("AI Stylist returned an empty response.")
                val root = JSONObject(jsonString)
                val headline = root.optString("summaryHeadline", "Curated Personal Lookbook")
                val arr = root.getJSONArray("recommendations")
                val parsedList = (0 until arr.length()).map { idx ->
                    val obj = arr.getJSONObject(idx)
                    AiOutfitRecommendation(
                        outfitTitle = obj.getString("outfitTitle"),
                        category = obj.getString("category"),
                        occasion = obj.getString("occasion"),
                        matchedProductId = obj.getString("matchedProductId"),
                        whyRecommended = obj.getString("whyRecommended"),
                        stylingTips = obj.getString("stylingTips"),
                        colorPalette = obj.getString("colorPalette"),
                        estimatedPriceInr = obj.optInt("estimatedPriceInr", 1999),
                        matchingFootwear = obj.getString("matchingFootwear"),
                        matchingAccessories = obj.getString("matchingAccessories")
                    )
                }

                repository.incrementUsageCounters(recommendationDelta = 1L)
                _stylistUiState.value = StylistUiState.Success(
                    summaryHeadline = headline,
                    recommendations = parsedList
                )
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "AI Stylist generation timed out", e)
                _stylistUiState.value = StylistUiState.Error("Styling recommendation timed out after 60 seconds. Please try again.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "AI Stylist generation failed", e)
                _stylistUiState.value = StylistUiState.Error(e.localizedMessage ?: "Failed to generate AI styling recommendations.")
            }
        }
    }

    /**
     * Generates a realistic virtual try-on preview using `gemini-nano-banana-2.1`
     * preserving the user's facial appearance, original pose, and clothing proportions
     * calibrated to their saved height, weight, and size preferences.
     */
    fun generateVirtualTryOn(context: Context) {
        val originalPhoto = _userPhotoBitmap.value
        if (originalPhoto == null) {
            _tryOnUiState.value = TryOnUiState.Error("Please upload or capture your personal photo first before generating a Virtual Try-On.")
            return
        }

        val profile = (userProfileState.value as? DataUiState.Success)?.data
        if (profile != null && profile.membershipTier == "FREE" && profile.tryOnCountUsed >= 3L) {
            _tryOnUiState.value = TryOnUiState.Error(
                "Free membership limit reached (3/3 Virtual Try-Ons used). Upgrade to StyleAI Premium in the Profile tab for more Virtual Try-Ons."
            )
            return
        }

        val product = _selectedProduct.value
        val color = _selectedColorVariant.value.ifBlank { product.color }
        val userHeight = profile?.heightCm ?: 172L
        val userWeight = profile?.weightKg ?: 68L
        val userTopSize = profile?.preferredTopSize ?: "M"
        val userBottomSize = profile?.preferredBottomSize ?: "32"
        val userFitPref = profile?.bodyFitPreference ?: "Tailored Fit"
        val size = _selectedSizeVariant.value.ifBlank { userTopSize }

        val editInstruction = buildString {
            append("Realistic virtual fashion try-on edit: Dress the person in this photo in the following outfit: ")
            append("${product.name} (${product.category}) by ${product.brand} in colour '$color' (size $size, fit style: $userFitPref). ")
            append("Body Measurement Calibration: Height ${userHeight} cm, Weight ${userWeight} kg, Top Size $size, Waist/Bottom Size $userBottomSize, Silhouette Preference: $userFitPref. ")
            append("Garment details: ${product.description}. ")
            append("CRITICAL REQUIREMENTS: ")
            append("1. Preserve the person's exact recognizable facial appearance, expression, head angle, and skin tone without alteration. ")
            append("2. Preserve the person's original body pose and background surroundings as closely as possible. ")
            append("3. Calibrate garment length, shoulder seam width, sleeve hem, and torso drape accurately for a ${userHeight} cm, ${userWeight} kg physique wearing size $size ($userFitPref) in '$color'. ")
            append("4. Pair with ${product.matchingShoes} if full-body is visible.")
        }

        viewModelScope.launch {
            _tryOnUiState.value = TryOnUiState.Generating
            try {
                val generatedBitmap = withTimeout(60_000L) {
                    val response = tryOnImageModel.generateContent(
                        content {
                            image(originalPhoto)
                            text(editInstruction)
                        }
                    )
                    response.candidates.firstOrNull()
                        ?.content?.parts?.filterIsInstance<ImagePart>()
                        ?.firstOrNull()?.image
                }

                if (generatedBitmap != null) {
                    val fitNotes = "Calibrated for ${userHeight} cm / ${userWeight} kg ($userFitPref • Top Size $size, Bottom $userBottomSize) in $color: Preserved facial identity and posture while tailoring realistic shoulder seams and hem length. Pair with ${product.matchingShoes} and ${product.matchingAccessories}."
                    var savedSessionId: String? = null
                    if (_photoConsentAccepted.value) {
                        val sessionId = "tryon_${UUID.randomUUID().toString().take(8)}"
                        val filename = PrivatePhotoStorage.saveTryOnPreviewBitmap(context, sessionId, generatedBitmap)
                        repository.saveTryOnSession(
                            sessionId = sessionId,
                            outfitId = product.id,
                            outfitTitle = product.name,
                            outfitCategory = product.category,
                            selectedColor = color,
                            selectedSize = size,
                            aiFitNotes = fitNotes,
                            localPreviewFilename = filename
                        )
                        savedSessionId = sessionId
                    }
                    repository.incrementUsageCounters(tryOnDelta = 1L)
                    _tryOnUiState.value = TryOnUiState.Success(
                        originalBitmap = originalPhoto,
                        generatedBitmap = generatedBitmap,
                        product = product,
                        selectedColor = color,
                        selectedSize = size,
                        aiFitNotes = fitNotes,
                        savedSessionId = savedSessionId
                    )
                } else {
                    _tryOnUiState.value = TryOnUiState.Error("The AI Virtual Try-On model did not return an image. Please try again.")
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Virtual Try-On timed out", e)
                _tryOnUiState.value = TryOnUiState.Error("Virtual Try-On timed out after 60 seconds. Please try again.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Virtual Try-On generation failed", e)
                _tryOnUiState.value = TryOnUiState.Error(e.localizedMessage ?: "Virtual Try-On generation failed.")
            }
        }
    }

    fun resetTryOnState() {
        _tryOnUiState.value = TryOnUiState.Idle
    }

    /**
     * Conversational AI Chat Stylist with streaming response and automatic product card matching.
     */
    fun sendChatStylistMessage(userMessage: String) {
        val trimmed = userMessage.trim()
        if (trimmed.isBlank()) return

        val userMsgObj = ChatMessage(
            id = "user_${System.currentTimeMillis()}",
            isUser = true,
            text = trimmed
        )
        _chatMessages.value = _chatMessages.value + userMsgObj

        val catalogContext = _catalogProducts.value.joinToString("\n") { p ->
            "- [${p.id}] ${p.name} by ${p.brand} (${p.category}, ${p.occasion}) — ₹${p.priceInr} on ${p.primaryRetailer}"
        }

        val fullPrompt = buildString {
            appendLine("You are StyleAI, a conversational personal fashion stylist and shopping advisor.")
            appendLine("Answer the user's fashion question concisely, warmly, and knowledgeably.")
            appendLine("Recommend specific outfits from the StyleAI catalogue below that match their request (including budget in ₹ and occasion), and mention the exact product names and prices:")
            appendLine(catalogContext)
            appendLine("\nUser message: $trimmed")
        }

        viewModelScope.launch {
            _chatUiState.value = ChatUiState.Streaming("")
            val accumulated = StringBuilder()
            try {
                withTimeout(60_000L) {
                    chatModel.generateContentStream(fullPrompt).collect { chunk ->
                        val chunkText = chunk.text.orEmpty()
                        accumulated.append(chunkText)
                        _chatUiState.value = ChatUiState.Streaming(accumulated.toString())
                    }
                }
                val finalResponse = accumulated.toString().trim()
                if (finalResponse.isNotEmpty()) {
                    val matchedProducts = matchProductsForQueryAndResponse(trimmed, finalResponse)
                    _chatMessages.value = _chatMessages.value + ChatMessage(
                        id = "ai_${System.currentTimeMillis()}",
                        isUser = false,
                        text = finalResponse,
                        recommendedProducts = matchedProducts
                    )
                    _chatUiState.value = ChatUiState.Idle
                } else {
                    _chatUiState.value = ChatUiState.Error("Stylist returned an empty response.")
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Chat streaming timed out", e)
                _chatUiState.value = ChatUiState.Error("Chat response timed out after 60 seconds.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Chat generation failed", e)
                _chatUiState.value = ChatUiState.Error(e.localizedMessage ?: "Chat stylist failed.")
            }
        }
    }

    private fun matchProductsForQueryAndResponse(query: String, aiResponse: String): List<FashionProduct> {
        val combined = "$query $aiResponse".lowercase()
        val all = _catalogProducts.value
        val directMatches = all.filter { product ->
            combined.contains(product.id.lowercase()) ||
                combined.contains(product.name.lowercase().take(16)) ||
                combined.contains(product.brand.lowercase()) ||
                combined.contains(product.occasion.lowercase())
        }
        val budgetUnder1000 = combined.contains("1,000") || combined.contains("1000")
        val filtered = if (budgetUnder1000) {
            all.filter { it.priceInr <= 1050 }
        } else {
            directMatches
        }
        return (if (filtered.isNotEmpty()) filtered else all).take(3)
    }

    companion object {
        fun provideFactory(
            repository: StyleAiRepository,
            currentUserId: String,
            displayName: String
        ): ViewModelProvider.Factory = viewModelFactory {
            initializer {
                StyleAiViewModel(repository, currentUserId, displayName)
            }
        }
    }
}
