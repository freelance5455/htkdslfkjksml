package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.MinecraftCard
import com.example.ui.theme.MinecraftBorder
import com.example.ui.theme.MinecraftDiamond
import com.example.ui.theme.MinecraftEmerald
import com.example.ui.theme.MinecraftGold
import com.example.ui.theme.MinecraftGrass
import com.example.ui.theme.MinecraftText
import com.example.ui.theme.MinecraftTextDim

@Composable
fun GuideScreen(modifier: Modifier = Modifier) {
  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(12.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    item {
      MinecraftCard(borderColor = MinecraftEmerald) {
        Column(modifier = Modifier.fillMaxWidth()) {
          Text(
            text = "📜 GUÍA DE DESPLIEGUE CHAUFALAND",
            color = MinecraftGold,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
          )
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "Tu proyecto incluye todos los archivos necesarios listos para producción:",
            color = MinecraftTextDim,
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace
          )
        }
      }
    }

    item {
      InstructionStepCard(
        stepNumber = "1",
        title = "INICIAR SERVIDOR NODE.JS (WEBRTC + BRIDGE)",
        borderColor = MinecraftGrass,
        description = "Abre tu terminal en la raíz del proyecto y ejecuta:",
        code = "npm install\nnode server.js"
      )
    }

    item {
      InstructionStepCard(
        stepNumber = "2",
        title = "ADDON BEDROCK (@minecraft/server-net)",
        borderColor = MinecraftDiamond,
        description = "Copia el archivo 'scripts/main.js' en la carpeta de Behavior Packs de tu servidor Bedrock. La estructura es:",
        code = "behavior_packs/\n  └── chaufaland_bridge/\n      ├── manifest.json\n      └── scripts/\n          └── main.js"
      )
    }

    item {
      InstructionStepCard(
        stepNumber = "3",
        title = "PANEL ADMIN Y CLAVE SECRETA",
        borderColor = MinecraftGold,
        description = "Para configurar el API Token de Exaroton o cambiar a Aternos, ingresa a la pestaña ADMIN con la contraseña:",
        code = "JuancitoChen23"
      )
    }

    item {
      InstructionStepCard(
        stepNumber = "4",
        title = "APLICACIÓN WEB / PWA",
        borderColor = Color(0xFF9B59B6),
        description = "El servidor Express sirve automáticamente la web interactiva con canales de voz WebRTC en:",
        code = "http://localhost:3000"
      )
    }
  }
}

@Composable
private fun InstructionStepCard(
  stepNumber: String,
  title: String,
  borderColor: Color,
  description: String,
  code: String
) {
  MinecraftCard(borderColor = borderColor) {
    Column(modifier = Modifier.fillMaxWidth()) {
      Text(
        text = "PASO $stepNumber: $title",
        color = borderColor,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        fontFamily = FontFamily.Monospace
      )
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = description,
        color = MinecraftText,
        fontSize = 11.sp,
        fontFamily = FontFamily.Monospace,
        lineHeight = 16.sp
      )
      Spacer(modifier = Modifier.height(8.dp))
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .background(Color(0xFF0C0907), RoundedCornerShape(2.dp))
          .border(1.dp, Color(0xFF281E15), RoundedCornerShape(2.dp))
          .padding(8.dp)
      ) {
        Text(
          text = code,
          color = Color(0xFF5CD892),
          fontSize = 11.sp,
          fontFamily = FontFamily.Monospace,
          lineHeight = 16.sp
        )
      }
    }
  }
}
