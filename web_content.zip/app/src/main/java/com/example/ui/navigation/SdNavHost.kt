package com.example.ui.navigation

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.export.ClientPrintHelper
import com.example.data.model.RestoreSummary
import com.example.ui.screens.AddBookingScreen
import com.example.ui.screens.BackupScreen
import com.example.ui.screens.ClientDetailScreen
import com.example.ui.screens.ClientsListScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.GoldSecondary
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.StatusConfirmedFg
import com.example.ui.viewmodel.MainViewModel
import com.example.ui.viewmodel.UiEvent
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileInputStream

object Routes {
    const val SPLASH = "splash"
    const val DASHBOARD = "dashboard"
    const val ADD_BOOKING = "add_booking?clientId={clientId}"
    const val CLIENTS = "clients"
    const val SEARCH = "search"
    const val CLIENT_DETAIL = "client_detail/{clientId}"
    const val REPORTS = "reports"
    const val BACKUP = "backup"

    fun addBooking(clientId: Long? = null): String =
        if (clientId != null) "add_booking?clientId=$clientId" else "add_booking?clientId=-1"

    fun clientDetail(clientId: Long): String = "client_detail/$clientId"
}

@Composable
fun SdNavHost(
    viewModel: MainViewModel,
    skipSplashForTests: Boolean = false,
) {
    val context = LocalContext.current
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    val stats by viewModel.dashboardStats.collectAsStateWithLifecycle()
    val allClients by viewModel.allClients.collectAsStateWithLifecycle()
    val searchFilter by viewModel.searchFilter.collectAsStateWithLifecycle()
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
    val selectedReportType by viewModel.selectedReportType.collectAsStateWithLifecycle()
    val reportFromDate by viewModel.reportFromDate.collectAsStateWithLifecycle()
    val reportToDate by viewModel.reportToDate.collectAsStateWithLifecycle()
    val reportPreview by viewModel.activeReportPreview.collectAsStateWithLifecycle()
    val lastBackupTimestamp by viewModel.lastBackupTimestamp.collectAsStateWithLifecycle()
    val lastBackupName by viewModel.lastBackupName.collectAsStateWithLifecycle()
    val localBackups by viewModel.localBackups.collectAsStateWithLifecycle()
    val isBusy by viewModel.isBusy.collectAsStateWithLifecycle()

    var readyExport by remember { mutableStateOf<UiEvent.ExportReady?>(null) }
    var restoreSummary by remember { mutableStateOf<RestoreSummary?>(null) }

    val saveExportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("*/*")
    ) { uri ->
        val exp = readyExport
        if (uri != null && exp != null) {
            scope.launch {
                runCatching {
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        FileInputStream(exp.file).use { input -> input.copyTo(out) }
                    }
                }.onSuccess {
                    snackbarHostState.showSnackbar("تم حفظ الملف في الهاتف بنجاح")
                }.onFailure {
                    snackbarHostState.showSnackbar("تعذر حفظ الملف")
                }
            }
        }
    }

    LaunchedEffect(viewModel) {
        viewModel.events.collect { event ->
            when (event) {
                is UiEvent.ShowMessage -> snackbarHostState.showSnackbar(event.text)
                is UiEvent.ExportReady -> readyExport = event
                is UiEvent.PrintReady -> ClientPrintHelper.printPdfFile(context, event.pdfFile, event.jobName)
                is UiEvent.BackupCreated -> {
                    // Already recorded & displayed in BackupScreen list
                }
                is UiEvent.RestoreCompleted -> restoreSummary = event.summary
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
    ) { _ ->
        NavHost(
            navController = navController,
            startDestination = if (skipSplashForTests) Routes.DASHBOARD else Routes.SPLASH,
        ) {
            composable(Routes.SPLASH) {
                SplashScreen(
                    onFinished = {
                        navController.navigate(Routes.DASHBOARD) {
                            popUpTo(Routes.SPLASH) { inclusive = true }
                        }
                    },
                )
            }

            composable(Routes.DASHBOARD) {
                DashboardScreen(
                    stats = stats,
                    recentClients = allClients,
                    onAddBooking = { navController.navigate(Routes.addBooking()) },
                    onOpenClients = { navController.navigate(Routes.CLIENTS) },
                    onOpenSearch = { navController.navigate(Routes.SEARCH) },
                    onOpenReports = { navController.navigate(Routes.REPORTS) },
                    onOpenBackup = { navController.navigate(Routes.BACKUP) },
                    onOpenClientDetail = { id -> navController.navigate(Routes.clientDetail(id)) },
                )
            }

            composable(
                route = Routes.ADD_BOOKING,
                arguments = listOf(
                    navArgument("clientId") {
                        type = NavType.LongType
                        defaultValue = -1L
                    }
                ),
            ) { backStackEntry ->
                val rawId = backStackEntry.arguments?.getLong("clientId") ?: -1L
                val existingId = if (rawId > 0L) rawId else null
                AddBookingScreen(
                    viewModel = viewModel,
                    existingClientId = existingId,
                    onBack = { navController.popBackStack() },
                    onSavedSuccess = { savedClientId ->
                        navController.navigate(Routes.clientDetail(savedClientId)) {
                            popUpTo(Routes.DASHBOARD)
                        }
                    },
                )
            }

            composable(Routes.CLIENTS) {
                ClientsListScreen(
                    clients = allClients,
                    onBack = { navController.popBackStack() },
                    onAddBooking = { navController.navigate(Routes.addBooking()) },
                    onOpenClientDetail = { id -> navController.navigate(Routes.clientDetail(id)) },
                )
            }

            composable(Routes.SEARCH) {
                SearchScreen(
                    filter = searchFilter,
                    results = searchResults,
                    onUpdateFilter = viewModel::updateSearchFilter,
                    onClearFilter = viewModel::clearSearchFilter,
                    onBack = { navController.popBackStack() },
                    onOpenClientDetail = { id -> navController.navigate(Routes.clientDetail(id)) },
                )
            }

            composable(
                route = Routes.CLIENT_DETAIL,
                arguments = listOf(
                    navArgument("clientId") { type = NavType.LongType }
                ),
            ) { backStackEntry ->
                val clientId = backStackEntry.arguments?.getLong("clientId") ?: return@composable
                ClientDetailScreen(
                    clientId = clientId,
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() },
                    onAddBookingForClient = { id ->
                        navController.navigate(Routes.addBooking(id))
                    },
                )
            }

            composable(Routes.REPORTS) {
                ReportsScreen(
                    selectedType = selectedReportType,
                    fromDate = reportFromDate,
                    toDate = reportToDate,
                    preview = reportPreview,
                    isBusy = isBusy,
                    onSelectType = viewModel::selectReportType,
                    onDateRangeChange = viewModel::setReportDateRange,
                    onExportExcel = viewModel::exportCurrentReportExcel,
                    onExportPdf = viewModel::exportCurrentReportPdf,
                    onBack = { navController.popBackStack() },
                )
            }

            composable(Routes.BACKUP) {
                BackupScreen(
                    lastBackupTimestamp = lastBackupTimestamp,
                    lastBackupName = lastBackupName,
                    localBackups = localBackups,
                    isBusy = isBusy,
                    restoreSummary = restoreSummary,
                    onDismissRestoreSummary = { restoreSummary = null },
                    onCreateBackup = viewModel::createBackup,
                    onSaveBackupToPhoneUri = viewModel::saveBackupToUri,
                    onShareBackup = { file -> shareFile(context, file, "application/zip", "مشاركة النسخة الاحتياطية") },
                    onRestoreFromUri = viewModel::restoreBackupFromUri,
                    onRestoreFromFile = viewModel::restoreBackupFromFile,
                    onDeleteBackup = viewModel::deleteBackupFile,
                    onBack = { navController.popBackStack() },
                )
            }
        }
    }

    if (readyExport != null) {
        val exp = readyExport!!
        AlertDialog(
            onDismissRequest = { readyExport = null },
            icon = { Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StatusConfirmedFg) },
            title = { Text("تم تجهيز ${exp.label}", style = MaterialTheme.typography.titleLarge) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("اسم الملف: ${exp.file.name}", style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(4.dp))
                    Button(
                        onClick = {
                            val uri = viewModel.documentStorage.getShareUri(exp.file)
                            val openIntent = Intent(Intent.ACTION_VIEW).apply {
                                setDataAndType(uri, exp.mimeType)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            runCatching { context.startActivity(Intent.createChooser(openIntent, "فتح الملف")) }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("فتح الملف")
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        OutlinedButton(
                            onClick = { saveExportLauncher.launch(exp.file.name) },
                            modifier = Modifier.weight(1f),
                        ) {
                            Icon(Icons.Default.SaveAlt, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("حفظ بالهاتف")
                        }
                        OutlinedButton(
                            onClick = { shareFile(context, exp.file, exp.mimeType, "مشاركة ${exp.label}") },
                            modifier = Modifier.weight(1f),
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("مشاركة")
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { readyExport = null }) {
                    Text("إغلاق", color = NavyPrimary, fontWeight = FontWeight.Bold)
                }
            },
        )
    }
}

private fun shareFile(context: android.content.Context, file: File, mimeType: String, chooserTitle: String) {
    val uri = androidx.core.content.FileProvider.getUriForFile(
        context,
        "${context.packageName}.fileprovider",
        file,
    )
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = mimeType
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, chooserTitle))
}
