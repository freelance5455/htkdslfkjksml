package com.example.ui.components

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.PanchangStrings
import com.example.model.AppLanguage
import com.example.model.DailyPanchang
import com.example.ui.theme.EkadashiGreen

@Composable
fun DayPanchangDetailsView(
    panchang: DailyPanchang,
    language: AppLanguage,
    onAddReminderClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Hero Card: Selected Date & Primary Vedic Attributes
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = Color.White
            ),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE0E0E0)),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        val gregorianMonthNames = listOf(
                            "जनवरी", "फरवरी", "मार्च", "अप्रैल", "मई", "जून",
                            "जुलाई", "अगस्त", "सितंबर", "अक्टूबर", "नवंबर", "दिसंबर"
                        )
                        val gMonth = gregorianMonthNames.getOrElse(panchang.gregorianMonth - 1) { "" }
                        Text(
                            text = "तारीख: ${panchang.gregorianDay} $gMonth • तिथि: ${panchang.tithiName} (${panchang.paksha.name})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                        Text(
                            text = "${panchang.dayOfWeek} • ${panchang.hinduMonth} मास • संवत ${panchang.vikramSamvat} • ${panchang.ritu}",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF444444)
                        )
                    }

                    IconButton(
                        onClick = {
                            val shareText = buildString {
                                append("🕉️ *दैनिक वैदिक पंचांग*\n")
                                append("📅 दिनांक: ${panchang.dateString} (${panchang.dayOfWeek})\n")
                                append("🚩 ${panchang.hinduMonth} मास • संवत ${panchang.vikramSamvat}\n")
                                append("✨ तिथि: ${panchang.tithiName} (${panchang.paksha.name})\n")
                                append("🌟 नक्षत्र: ${panchang.nakshatra}\n")
                                append("🌅 सूर्योदय: ${panchang.sunrise} | 🌄 सूर्यास्त: ${panchang.sunset}\n")
                                append("⭐ अभिजीत मुहूर्त: ${panchang.abhijitMuhurat}\n")
                                append("⚠️ राहुकाल: ${panchang.rahuKaal}\n")
                                if (panchang.panchak.isActive) append("⚠️ पंचक: ${panchang.panchak.title}\n")
                                if (panchang.bichhuda.isActive) append("🦂 बिछुड़ा: सक्रिय\n")
                                if (panchang.festivals.isNotEmpty()) append("🎉 पर्व: ${panchang.festivals.joinToString(", ")}\n")
                            }
                            val sendIntent = Intent().apply {
                                action = Intent.ACTION_SEND
                                putExtra(Intent.EXTRA_TEXT, shareText)
                                type = "text/plain"
                            }
                            context.startActivity(Intent.createChooser(sendIntent, "पंचांग शेयर करें"))
                        },
                        modifier = Modifier.testTag("share_panchang_btn")
                    ) {
                        Icon(Icons.Default.Share, contentDescription = "Share", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = Color(0xFFEEEEEE))
                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "पंचांग के मुख्य पंच-अंग",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    PanchangAttributeItem(
                        label = PanchangStrings.get(language, "tithi"),
                        value = panchang.tithiName,
                        subtext = "${panchang.paksha.name} • ${panchang.tithiEndTime}",
                        modifier = Modifier.weight(1f)
                    )
                    PanchangAttributeItem(
                        label = PanchangStrings.get(language, "nakshatra"),
                        value = panchang.nakshatra,
                        subtext = panchang.nakshatraEndTime,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    PanchangAttributeItem(
                        label = PanchangStrings.get(language, "yoga"),
                        value = panchang.yoga,
                        subtext = "अहोरात्र शुभ फल",
                        modifier = Modifier.weight(1f)
                    )
                    PanchangAttributeItem(
                        label = PanchangStrings.get(language, "karana"),
                        value = panchang.karana,
                        subtext = "प्रथम प्रहर",
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Sun & Moon Timings Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = Color.White
            ),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE0E0E0)),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp)
            ) {
                Text(
                    text = "सूर्य एवं चंद्र संचरण",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    SunMoonItem(
                        icon = Icons.Default.WbSunny,
                        iconTint = Color(0xFFFF9800),
                        title = PanchangStrings.get(language, "sunrise"),
                        time = panchang.sunrise
                    )
                    SunMoonItem(
                        icon = Icons.Default.WbSunny,
                        iconTint = Color(0xFFE65100),
                        title = PanchangStrings.get(language, "sunset"),
                        time = panchang.sunset
                    )
                    SunMoonItem(
                        icon = Icons.Default.Bedtime,
                        iconTint = Color(0xFF5C6BC0),
                        title = PanchangStrings.get(language, "moonrise"),
                        time = panchang.moonrise
                    )
                    SunMoonItem(
                        icon = Icons.Default.Bedtime,
                        iconTint = Color(0xFF7E57C2),
                        title = PanchangStrings.get(language, "moonset"),
                        time = panchang.moonset
                    )
                }
            }
        }

        // Shubh & Ashubh Muhurat Timings
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = Color.White
            ),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE0E0E0)),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "शुभ एवं अशुभ मुहूर्त काल",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )

                MuhuratRowItem(
                    label = PanchangStrings.get(language, "abhijit_muhurat"),
                    time = panchang.abhijitMuhurat,
                    isAuspicious = true
                )

                MuhuratRowItem(
                    label = PanchangStrings.get(language, "amrit_kaal"),
                    time = panchang.amritKaal,
                    isAuspicious = true
                )

                MuhuratRowItem(
                    label = PanchangStrings.get(language, "brahma_muhurat"),
                    time = panchang.brahmaMuhurat,
                    isAuspicious = true
                )

                HorizontalDivider(color = Color(0xFFEEEEEE))

                MuhuratRowItem(
                    label = PanchangStrings.get(language, "rahu_kaal"),
                    time = panchang.rahuKaal,
                    isAuspicious = false
                )

                MuhuratRowItem(
                    label = PanchangStrings.get(language, "yamaganda_kaal"),
                    time = panchang.yamagandaKaal,
                    isAuspicious = false
                )
            }
        }

        // Festivals and Vrats Section
        if (panchang.festivals.isNotEmpty() || panchang.vrats.isNotEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = Color.White
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE0E0E0)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp)
                ) {
                    Text(
                        text = "🚩 ${PanchangStrings.get(language, "festivals_vrats")}",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    panchang.festivals.forEach { fest ->
                        Text(
                            text = "• $fest",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    panchang.vrats.forEach { vrat ->
                        Text(
                            text = "• $vrat",
                            style = MaterialTheme.typography.bodyMedium,
                            color = EkadashiGreen,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PanchangAttributeItem(
    label: String,
    value: String,
    subtext: String,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.padding(4.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = subtext,
            style = MaterialTheme.typography.bodySmall,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.primary
        )
    }
}

@Composable
private fun SunMoonItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconTint: Color,
    title: String,
    time: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = iconTint,
            modifier = Modifier.size(22.dp)
        )
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
            fontSize = 11.sp
        )
        Text(
            text = time,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun MuhuratRowItem(
    label: String,
    time: String,
    isAuspicious: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(if (isAuspicious) Color(0xFF4CAF50) else Color(0xFFE53935))
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        Text(
            text = time,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.SemiBold,
            color = if (isAuspicious) Color(0xFF2E7D32) else Color(0xFFC62828)
        )
    }
}
