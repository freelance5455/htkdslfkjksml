package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.MonitorHeart
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.CycleLogEntity
import com.example.data.local.HormoneCheckEntity
import com.example.data.local.VitalityLogEntity
import com.example.data.model.CycleSymptom
import com.example.data.model.DailyHormoneCycleLog
import com.example.data.model.GenderOption
import com.example.data.model.UserProfile
import com.example.localization.LocalizedStrings
import com.example.ui.components.AiFirebaseNoticeBanner
import com.example.ui.components.HormoneAndCycleTrendChart
import com.example.ui.theme.CycleRose
import com.example.ui.theme.CycleRoseSoft
import com.example.ui.theme.VitalityAmber
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WellnessScreen(
    profile: UserProfile,
    strings: LocalizedStrings,
    cycleLogs: List<CycleLogEntity>,
    vitalityLogs: List<VitalityLogEntity>,
    hormoneChecks: List<HormoneCheckEntity>,
    hormoneCycleLogs: List<DailyHormoneCycleLog>,
    isAiThinking: Boolean,
    onLogPeriodToday: (flow: String, cramps: Int, symptoms: String, notes: String) -> Unit,
    onLogBoysVitality: (workoutMins: Int, workoutType: String, proteinMeals: Int, zincHydration: Boolean, sleepHours: Float, notes: String) -> Unit,
    onRunHormoneCheck: (energy: Int, mood: Int, skin: Int, sleep: Int, stress: Int, symptoms: String) -> Unit
) {
    val todayEpochDay = System.currentTimeMillis() / 86_400_000L

    // Cycle state
    var flowLevel by remember { mutableStateOf("Medium") }
    var crampsLevel by remember { mutableFloatStateOf(2f) }
    var selectedSymptoms by remember { mutableStateOf(setOf("Fatigue")) }
    var cycleNotes by remember { mutableStateOf("") }

    // Boys vitality state
    var workoutMins by remember { mutableFloatStateOf(30f) }
    var workoutType by remember { mutableStateOf("Strength & Cardio") }
    var proteinMeals by remember { mutableIntStateOf(3) }
    var zincHydrationDone by remember { mutableStateOf(true) }
    var sleepHours by remember { mutableFloatStateOf(8f) }
    var vitalityNotes by remember { mutableStateOf("") }

    // Non-binary choice to view either or both
    var showCycleSection by remember(profile.gender) { mutableStateOf(profile.gender == GenderOption.GIRL) }
    var showVitalitySection by remember(profile.gender) { mutableStateOf(profile.gender == GenderOption.BOY) }

    // Hormone check sliders & symptoms
    var hEnergy by remember { mutableFloatStateOf(3f) }
    var hMood by remember { mutableFloatStateOf(3f) }
    var hSkin by remember { mutableFloatStateOf(4f) }
    var hSleep by remember { mutableFloatStateOf(3f) }
    var hStress by remember { mutableFloatStateOf(3f) }
    var hormoneSymptoms by remember { mutableStateOf(setOf<String>()) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(shape = RoundedCornerShape(24.dp)) {
                Column {
                    Image(
                        painter = painterResource(id = R.drawable.img_vitality_cycle),
                        contentDescription = "Wellness and hormone balance banner",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxWidth().height(120.dp)
                    )
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = when (profile.gender) {
                                GenderOption.GIRL -> strings.cycleTitle
                                GenderOption.BOY -> strings.boysVitalityTitle
                                GenderOption.NON_BINARY -> "Body, Cycle & Vitality Hub"
                            },
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Tailored for ${profile.gender.label}, age ${profile.age}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (profile.gender == GenderOption.NON_BINARY) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = showCycleSection,
                                    onClick = { showCycleSection = !showCycleSection },
                                    label = { Text("Cycle Tracker") }
                                )
                                FilterChip(
                                    selected = showVitalitySection,
                                    onClick = { showVitalitySection = !showVitalitySection },
                                    label = { Text("Fitness & Vitality") }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Girls Menstruation Cycle Tracker
        if (showCycleSection) {
            item {
                val daysSinceStart = if (profile.lastPeriodEpochDay > 0L) {
                    ((todayEpochDay - profile.lastPeriodEpochDay) % profile.cycleLengthDays).toInt() + 1
                } else 1
                val daysUntilNext = (profile.cycleLengthDays - daysSinceStart).coerceAtLeast(0)
                val phase = when {
                    daysSinceStart <= 5 -> "Menstrual Phase — Rest, hydrate & stay warm"
                    daysSinceStart <= 13 -> "Follicular Phase — Energy rising, great for movement"
                    daysSinceStart <= 16 -> "Ovulation Window — Peak vitality"
                    else -> "Luteal Phase — Prioritize sleep, iron & magnesium foods"
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(92.dp)) {
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    drawArc(
                                        color = CycleRoseSoft,
                                        startAngle = 0f,
                                        sweepAngle = 360f,
                                        useCenter = false,
                                        style = Stroke(width = 18f)
                                    )
                                    drawArc(
                                        color = CycleRose,
                                        startAngle = -90f,
                                        sweepAngle = (daysSinceStart.toFloat() / profile.cycleLengthDays) * 360f,
                                        useCenter = false,
                                        style = Stroke(width = 18f, cap = StrokeCap.Round)
                                    )
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Day $daysSinceStart", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Text("of ${profile.cycleLengthDays}", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(phase, style = MaterialTheme.typography.titleSmall, color = CycleRose)
                                Text(
                                    text = if (profile.lastPeriodEpochDay == 0L) {
                                        "Tap 'Log Period Start Today' to start predicting your cycle."
                                    } else {
                                        "Next predicted period in ~$daysUntilNext days"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Text("Flow Intensity", style = MaterialTheme.typography.labelLarge)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Spotting", "Light", "Medium", "Heavy").forEach { level ->
                                FilterChip(
                                    selected = flowLevel == level,
                                    onClick = { flowLevel = level },
                                    label = { Text(level) }
                                )
                            }
                        }

                        Text("Cramps Level: ${crampsLevel.roundToInt()} / 5", style = MaterialTheme.typography.labelLarge)
                        Slider(value = crampsLevel, onValueChange = { crampsLevel = it }, valueRange = 0f..5f, steps = 4)

                        Text("Symptoms", style = MaterialTheme.typography.labelLarge)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("Fatigue", "Cramps", "Headache", "Bloating", "Mood Swings", "Clear").forEach { sym ->
                                FilterChip(
                                    selected = sym in selectedSymptoms,
                                    onClick = {
                                        selectedSymptoms = if (sym in selectedSymptoms) selectedSymptoms - sym else selectedSymptoms + sym
                                    },
                                    label = { Text(sym) }
                                )
                            }
                        }

                        OutlinedTextField(
                            value = cycleNotes,
                            onValueChange = { cycleNotes = it },
                            label = { Text("Cycle Notes (optional)") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Button(
                            onClick = {
                                onLogPeriodToday(
                                    flowLevel,
                                    crampsLevel.roundToInt(),
                                    selectedSymptoms.joinToString(", "),
                                    cycleNotes
                                )
                                cycleNotes = ""
                            },
                            modifier = Modifier.fillMaxWidth().testTag("log_period_button")
                        ) {
                            Icon(Icons.Filled.WaterDrop, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Log Period Start / Flow Today")
                        }
                    }
                }
            }

            items(cycleLogs.take(4), key = { it.id }) { log ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Flow: ${log.flowLevel} • Cramps ${log.crampsLevel}/5", style = MaterialTheme.typography.titleSmall)
                        if (log.symptoms.isNotBlank()) Text("Symptoms: ${log.symptoms}", style = MaterialTheme.typography.bodySmall)
                        if (log.notes.isNotBlank()) Text(log.notes, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        // Boys Fit, Healthy & Fertile Hub
        if (showVitalitySection) {
            item {
                Card {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.FitnessCenter, contentDescription = null, tint = VitalityAmber)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(strings.boysVitalityTitle, style = MaterialTheme.typography.titleLarge)
                        }
                        Text(
                            "Build lifelong strength, balanced testosterone & healthy fertility naturally through daily movement, whole nutrition, hydration, cool habits, and 8–9h sleep.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Text("Workout Type", style = MaterialTheme.typography.labelLarge)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Strength & Cardio", "Football / Sports", "Running", "Pushups & Core").forEach { wt ->
                                FilterChip(selected = workoutType == wt, onClick = { workoutType = wt }, label = { Text(wt) })
                            }
                        }

                        Text("Active Minutes: ${workoutMins.roundToInt()} mins", style = MaterialTheme.typography.labelLarge)
                        Slider(value = workoutMins, onValueChange = { workoutMins = it }, valueRange = 0f..120f, steps = 11)

                        Text("Sleep Last Night: ${"%.1f".format(sleepHours)} hrs (target 8–9h for hormone recovery)", style = MaterialTheme.typography.labelLarge)
                        Slider(value = sleepHours, onValueChange = { sleepHours = it }, valueRange = 4f..11f, steps = 13)

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Protein & Whole Meals Today: $proteinMeals", modifier = Modifier.weight(1f))
                            FilterChip(selected = false, onClick = { proteinMeals = (proteinMeals + 1).coerceAtMost(6) }, label = { Text("+1") })
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = zincHydrationDone, onCheckedChange = { zincHydrationDone = it })
                            Text("Hydrated + Zinc/Vitamins + Avoided overheating (laptop off lap, breathable clothing)", style = MaterialTheme.typography.bodySmall)
                        }

                        OutlinedTextField(
                            value = vitalityNotes,
                            onValueChange = { vitalityNotes = it },
                            label = { Text("Fitness & Health Note") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Button(
                            onClick = {
                                onLogBoysVitality(
                                    workoutMins.roundToInt(),
                                    workoutType,
                                    proteinMeals,
                                    zincHydrationDone,
                                    sleepHours,
                                    vitalityNotes
                                )
                                vitalityNotes = ""
                            },
                            modifier = Modifier.fillMaxWidth().testTag("log_vitality_button")
                        ) {
                            Icon(Icons.Filled.Bolt, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Log Fit & Vitality Day")
                        }
                    }
                }
            }

            items(vitalityLogs.take(4), key = { it.id }) { log ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("${log.workoutType} • ${log.workoutMinutes} mins • ${log.sleepHours}h sleep", style = MaterialTheme.typography.titleSmall)
                        Text("Meals: ${log.proteinMeals} • Fertility/Hydration habits: ${if (log.hydrationAndZincDone) "Completed" else "Pending"}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        // Hormone Check-In for Everyone
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.MonitorHeart, contentDescription = null, tint = MaterialTheme.colorScheme.onSecondaryContainer)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(strings.hormoneCheckTitle, style = MaterialTheme.typography.titleLarge)
                    }

                    AiFirebaseNoticeBanner()

                    Text("Energy Level: ${hEnergy.roundToInt()} / 5", style = MaterialTheme.typography.labelLarge)
                    Slider(value = hEnergy, onValueChange = { hEnergy = it }, valueRange = 1f..5f, steps = 3)

                    Text("Mood Stability: ${hMood.roundToInt()} / 5", style = MaterialTheme.typography.labelLarge)
                    Slider(value = hMood, onValueChange = { hMood = it }, valueRange = 1f..5f, steps = 3)

                    Text("Skin Clarity: ${hSkin.roundToInt()} / 5", style = MaterialTheme.typography.labelLarge)
                    Slider(value = hSkin, onValueChange = { hSkin = it }, valueRange = 1f..5f, steps = 3)

                    Text("Sleep Quality: ${hSleep.roundToInt()} / 5", style = MaterialTheme.typography.labelLarge)
                    Slider(value = hSleep, onValueChange = { hSleep = it }, valueRange = 1f..5f, steps = 3)

                    Text("Stress Calmness: ${hStress.roundToInt()} / 5", style = MaterialTheme.typography.labelLarge)
                    Slider(value = hStress, onValueChange = { hStress = it }, valueRange = 1f..5f, steps = 3)

                    Text("Daily Symptoms (optional)", style = MaterialTheme.typography.labelLarge)
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        CycleSymptom.entries.forEach { sym ->
                            FilterChip(
                                selected = sym.label in hormoneSymptoms,
                                onClick = {
                                    hormoneSymptoms = if (sym.label in hormoneSymptoms) {
                                        hormoneSymptoms - sym.label
                                    } else {
                                        hormoneSymptoms + sym.label
                                    }
                                },
                                label = { Text(sym.label, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }

                    Button(
                        onClick = {
                            onRunHormoneCheck(
                                hEnergy.roundToInt(),
                                hMood.roundToInt(),
                                hSkin.roundToInt(),
                                hSleep.roundToInt(),
                                hStress.roundToInt(),
                                hormoneSymptoms.joinToString(", ")
                            )
                        },
                        enabled = !isAiThinking,
                        modifier = Modifier.fillMaxWidth().testTag("run_hormone_check_button")
                    ) {
                        if (isAiThinking) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                        Text("Check My Hormone Balance")
                    }
                }
            }
        }

        // Hormone & Cycle Trend Chart
        item {
            HormoneAndCycleTrendChart(
                logs = hormoneCycleLogs,
                showCycleMetrics = showCycleSection
            )
        }

        items(hormoneChecks.take(3), key = { it.id }) { check ->
            val dateText = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(check.timestamp))
            Card {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Check-in ($dateText)", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    if (check.dailySymptoms.isNotBlank()) {
                        Text("Symptoms: ${check.dailySymptoms}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                    }
                    Text(check.insightSummary, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
