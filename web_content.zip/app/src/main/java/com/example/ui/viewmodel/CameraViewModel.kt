package com.example.ui.viewmodel

import android.app.Application
import android.graphics.Bitmap
import androidx.camera.core.CameraControl
import androidx.camera.core.CameraInfo
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.PhotoRepository
import com.example.detector.ColorDetector
import com.example.model.CapturedPhoto
import com.example.model.DetectionRegion
import com.example.model.DetectionState
import com.example.model.TargetTrigger
import com.example.model.TriggerType
import com.example.util.FeedbackHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.Executor
import java.util.concurrent.Executors

class CameraViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = PhotoRepository(application)
    private val detector = ColorDetector()
    private val feedbackHelper = FeedbackHelper(application)
    private val cameraExecutor: Executor = Executors.newSingleThreadExecutor()

    val photos: StateFlow<List<CapturedPhoto>> = repository.photos
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Auto capture loop state
    private val _isAutoCaptureActive = MutableStateFlow(false)
    val isAutoCaptureActive: StateFlow<Boolean> = _isAutoCaptureActive.asStateFlow()

    // Configured Triggers
    private val _triggers = MutableStateFlow(TargetTrigger.createDefaultTriggers())
    val triggers: StateFlow<List<TargetTrigger>> = _triggers.asStateFlow()

    // Detection State
    private val _detectionState = MutableStateFlow(DetectionState())
    val detectionState: StateFlow<DetectionState> = _detectionState.asStateFlow()

    // Detection Region
    private val _detectionRegion = MutableStateFlow(DetectionRegion.CENTER_RETICLE)
    val detectionRegion: StateFlow<DetectionRegion> = _detectionRegion.asStateFlow()

    // Cooldown in seconds between continuous auto shots
    private val _cooldownSeconds = MutableStateFlow(1.2f)
    val cooldownSeconds: StateFlow<Float> = _cooldownSeconds.asStateFlow()

    // Sensitivity threshold percent (e.g. 8% of sampled area)
    private val _sensitivityPercent = MutableStateFlow(8f)
    val sensitivityPercent: StateFlow<Float> = _sensitivityPercent.asStateFlow()

    // Camera hardware controls
    private val _lensFacing = MutableStateFlow(CameraSelector.LENS_FACING_BACK)
    val lensFacing: StateFlow<Int> = _lensFacing.asStateFlow()

    private val _isTorchOn = MutableStateFlow(false)
    val isTorchOn: StateFlow<Boolean> = _isTorchOn.asStateFlow()

    // Sound & Haptic options
    private val _soundEnabled = MutableStateFlow(true)
    val soundEnabled: StateFlow<Boolean> = _soundEnabled.asStateFlow()

    private val _vibrationEnabled = MutableStateFlow(true)
    val vibrationEnabled: StateFlow<Boolean> = _vibrationEnabled.asStateFlow()

    // UI Feedback
    private val _captureCounter = MutableStateFlow(0)
    val captureCounter: StateFlow<Int> = _captureCounter.asStateFlow()

    private val _isShutterFlashing = MutableStateFlow(false)
    val isShutterFlashing: StateFlow<Boolean> = _isShutterFlashing.asStateFlow()

    // Selected photo for detail dialog/viewer
    private val _selectedPhoto = MutableStateFlow<CapturedPhoto?>(null)
    val selectedPhoto: StateFlow<CapturedPhoto?> = _selectedPhoto.asStateFlow()

    // Gallery & Settings Dialogs
    private val _isGalleryOpen = MutableStateFlow(false)
    val isGalleryOpen: StateFlow<Boolean> = _isGalleryOpen.asStateFlow()

    private val _isSettingsOpen = MutableStateFlow(false)
    val isSettingsOpen: StateFlow<Boolean> = _isSettingsOpen.asStateFlow()

    private val _isEyeDropperActive = MutableStateFlow(false)
    val isEyeDropperActive: StateFlow<Boolean> = _isEyeDropperActive.asStateFlow()

    // CameraX internal handles
    var imageCapture: ImageCapture? = null
    var cameraControl: CameraControl? = null
    var cameraInfo: CameraInfo? = null

    private var lastCaptureTimestamp = 0L
    private var isCapturingNow = false

    fun toggleAutoCapture() {
        val next = !_isAutoCaptureActive.value
        _isAutoCaptureActive.value = next
        if (next) {
            _captureCounter.value = 0
            if (_vibrationEnabled.value) feedbackHelper.vibrateTriggerDetected()
        }
    }

    fun setAutoCapture(active: Boolean) {
        _isAutoCaptureActive.value = active
    }

    fun toggleTrigger(triggerId: String) {
        _triggers.value = _triggers.value.map {
            if (it.id == triggerId) it.copy(isEnabled = !it.isEnabled) else it
        }
    }

    fun addCustomColorTrigger(color: Color, name: String = "Custom Color") {
        val newTrigger = TargetTrigger.fromColor(color, nameEn = name, nameAr = "لون مخصص")
        _triggers.value = _triggers.value + newTrigger
    }

    fun removeTrigger(triggerId: String) {
        _triggers.value = _triggers.value.filter { it.id != triggerId }
    }

    fun updateCustomTriggerTolerance(triggerId: String, newTolerance: Float) {
        _triggers.value = _triggers.value.map {
            if (it.id == triggerId) it.copy(tolerance = newTolerance) else it
        }
    }

    fun setCooldown(seconds: Float) {
        _cooldownSeconds.value = seconds.coerceIn(0.4f, 6.0f)
    }

    fun setSensitivity(percent: Float) {
        _sensitivityPercent.value = percent.coerceIn(2f, 40f)
    }

    fun setDetectionRegion(region: DetectionRegion) {
        _detectionRegion.value = region
    }

    fun toggleDetectionRegion() {
        _detectionRegion.value = if (_detectionRegion.value == DetectionRegion.CENTER_RETICLE) {
            DetectionRegion.FULL_FRAME
        } else {
            DetectionRegion.CENTER_RETICLE
        }
    }

    fun toggleLensFacing() {
        _lensFacing.value = if (_lensFacing.value == CameraSelector.LENS_FACING_BACK) {
            CameraSelector.LENS_FACING_FRONT
        } else {
            CameraSelector.LENS_FACING_BACK
        }
        _isTorchOn.value = false
    }

    fun toggleTorch() {
        val next = !_isTorchOn.value
        cameraControl?.enableTorch(next)
        _isTorchOn.value = next
    }

    fun toggleSound() {
        _soundEnabled.value = !_soundEnabled.value
    }

    fun toggleVibration() {
        _vibrationEnabled.value = !_vibrationEnabled.value
    }

    fun openGallery() {
        _isGalleryOpen.value = true
    }

    fun closeGallery() {
        _isGalleryOpen.value = false
    }

    fun openSettings() {
        _isSettingsOpen.value = true
    }

    fun closeSettings() {
        _isSettingsOpen.value = false
    }

    fun selectPhoto(photo: CapturedPhoto?) {
        _selectedPhoto.value = photo
    }

    fun deletePhoto(photo: CapturedPhoto) {
        viewModelScope.launch {
            repository.deletePhoto(photo)
            if (_selectedPhoto.value?.id == photo.id) {
                _selectedPhoto.value = null
            }
        }
    }

    fun clearAllPhotos() {
        viewModelScope.launch {
            repository.clearAll()
            _selectedPhoto.value = null
        }
    }

    fun toggleEyeDropper() {
        _isEyeDropperActive.value = !_isEyeDropperActive.value
    }

    /**
     * Called when user taps on the screen in EyeDropper mode or samples center color.
     */
    fun sampleCurrentColorAsTrigger() {
        val currentHex = _detectionState.value.sampledColorHex
        val currentRgb = _detectionState.value.sampledColorRgb
        val color = Color(currentRgb)
        addCustomColorTrigger(color, name = "Target $currentHex")
        _isEyeDropperActive.value = false
        if (_vibrationEnabled.value) feedbackHelper.vibrateTriggerDetected()
    }

    /**
     * Analyzes incoming frame from CameraX ImageAnalysis.
     * Evaluates triggers and performs continuous auto-capture when conditions are met.
     */
    fun processImageFrame(imageProxy: ImageProxy) {
        val state = detector.analyzeFrame(
            image = imageProxy,
            triggers = _triggers.value,
            region = _detectionRegion.value,
            sensitivityThresholdPercent = _sensitivityPercent.value
        )

        _detectionState.value = state

        if (_isAutoCaptureActive.value && state.isTriggered && state.activeTrigger != null) {
            val now = System.currentTimeMillis()
            val cooldownMs = (_cooldownSeconds.value * 1000f).toLong()

            if (!isCapturingNow && (now - lastCaptureTimestamp >= cooldownMs)) {
                lastCaptureTimestamp = now
                takePhoto(
                    triggerName = state.activeTrigger.nameEn,
                    triggerColorHex = String.format("#%06X", (0xFFFFFF and state.activeTrigger.color.toArgb())),
                    confidence = state.confidencePercent,
                    isAuto = true
                )
            }
        }
    }

    /**
     * Captures photo using CameraX ImageCapture, saves file with metadata, and updates gallery.
     */
    fun takePhoto(
        triggerName: String = "Manual Capture",
        triggerColorHex: String = "#00E5FF",
        confidence: Float = 100f,
        isAuto: Boolean = false
    ) {
        val capture = imageCapture ?: return
        if (isCapturingNow) return
        isCapturingNow = true

        // Play feedback immediately
        if (_soundEnabled.value) feedbackHelper.playShutterSound()
        if (_vibrationEnabled.value) feedbackHelper.vibrateCapture()

        // Flash shutter UI
        _isShutterFlashing.value = true
        viewModelScope.launch {
            kotlinx.coroutines.delay(120)
            _isShutterFlashing.value = false
        }

        val cacheFile = File(getApplication<Application>().cacheDir, "temp_capture_${System.currentTimeMillis()}.jpg")
        val outputOptions = ImageCapture.OutputFileOptions.Builder(cacheFile).build()

        capture.takePicture(
            outputOptions,
            cameraExecutor,
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                    viewModelScope.launch {
                        try {
                            repository.savePhotoFile(
                                sourceFile = cacheFile,
                                triggerName = triggerName,
                                triggerColorHex = triggerColorHex,
                                confidence = confidence,
                                isAutoCaptured = isAuto
                            )
                            _captureCounter.value += 1
                        } catch (e: Exception) {
                            e.printStackTrace()
                        } finally {
                            cacheFile.delete()
                            isCapturingNow = false
                        }
                    }
                }

                override fun onError(exception: ImageCaptureException) {
                    exception.printStackTrace()
                    isCapturingNow = false
                }
            }
        )
    }

    fun getShareIntent(photo: CapturedPhoto) = repository.createShareIntent(photo)

    override fun onCleared() {
        super.onCleared()
        feedbackHelper.release()
    }
}
