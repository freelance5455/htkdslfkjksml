package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HomeWork
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Password
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.MainUiState

@Composable
fun MainDashboardScreen(
    uiState: MainUiState,
    snackbarHostState: SnackbarHostState,
    onRequestAccessibility: () -> Unit,
    onRequestDeviceAdmin: () -> Unit,
    onRequestOverlay: () -> Unit,
    onToggleMaster: (Boolean) -> Unit,
    onTogglePowerRule: (Boolean) -> Unit,
    onToggleAdminRule: (Boolean) -> Unit,
    onToggleDesktopRule: (Boolean) -> Unit,
    onChangePin: () -> Unit,
    onLockPanel: () -> Unit,
    onTestOverlayLock: () -> Unit,
    onOpenAppSettings: () -> Unit,
) {
    val permissions = uiState.permissions
    val settings = uiState.settings
    val isFullyProtected = permissions.allGranted && settings.masterProtectionEnabled

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing,
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter,
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 600.dp),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                // Header
                item {
                    DashboardTopBar(
                        onChangePin = onChangePin,
                        onLockPanel = onLockPanel,
                    )
                }

                // Hero Status Banner + Master Protection Switch
                item {
                    HeroProtectionCard(
                        allGranted = permissions.allGranted,
                        grantedCount = permissions.grantedCount,
                        masterEnabled = settings.masterProtectionEnabled,
                        interceptionCount = settings.interceptionCount,
                        isFullyProtected = isFullyProtected,
                        onToggleMaster = onToggleMaster,
                    )
                }

                // System Permissions Section
                item {
                    SectionHeader(title = stringResource(R.string.section_permissions))
                }

                item {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        PermissionCard(
                            icon = Icons.Filled.AccessibilityNew,
                            title = stringResource(R.string.perm_accessibility_title),
                            description = stringResource(R.string.perm_accessibility_desc),
                            isGranted = permissions.accessibilityEnabled,
                            actionLabel = stringResource(R.string.action_grant),
                            testTag = "btn_grant_accessibility",
                            onClick = onRequestAccessibility,
                        )

                        PermissionCard(
                            icon = Icons.Filled.AdminPanelSettings,
                            title = stringResource(R.string.perm_admin_title),
                            description = stringResource(R.string.perm_admin_desc),
                            isGranted = permissions.deviceAdminEnabled,
                            actionLabel = stringResource(R.string.action_grant),
                            testTag = "btn_grant_device_admin",
                            onClick = onRequestDeviceAdmin,
                        )

                        PermissionCard(
                            icon = Icons.Filled.Layers,
                            title = stringResource(R.string.perm_overlay_title),
                            description = stringResource(R.string.perm_overlay_desc),
                            isGranted = permissions.overlayEnabled,
                            actionLabel = stringResource(R.string.action_allow),
                            testTag = "btn_grant_overlay",
                            onClick = onRequestOverlay,
                        )
                    }
                }

                // Protected Areas Section
                item {
                    SectionHeader(title = stringResource(R.string.section_protected_areas))
                }

                item {
                    Surface(
                        shape = RoundedCornerShape(22.dp),
                        color = MaterialTheme.colorScheme.surfaceContainer,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                        tonalElevation = 1.dp,
                    ) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            ProtectedRuleRow(
                                icon = Icons.Filled.PowerSettingsNew,
                                title = stringResource(R.string.rule_power_title),
                                description = stringResource(R.string.rule_power_desc),
                                checked = settings.protectPowerAndReboot,
                                enabled = settings.masterProtectionEnabled,
                                testTag = "switch_rule_power",
                                onCheckedChange = onTogglePowerRule,
                            )
                            HorizontalDivider(
                                modifier = Modifier.padding(horizontal = 16.dp),
                                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f),
                            )
                            ProtectedRuleRow(
                                icon = Icons.Filled.Security,
                                title = stringResource(R.string.rule_admin_title),
                                description = stringResource(R.string.rule_admin_desc),
                                checked = settings.protectAccessibilityAndAdmin,
                                enabled = settings.masterProtectionEnabled,
                                testTag = "switch_rule_admin",
                                onCheckedChange = onToggleAdminRule,
                            )
                            HorizontalDivider(
                                modifier = Modifier.padding(horizontal = 16.dp),
                                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f),
                            )
                            ProtectedRuleRow(
                                icon = Icons.Filled.HomeWork,
                                title = stringResource(R.string.rule_desktop_title),
                                description = stringResource(R.string.rule_desktop_desc),
                                checked = settings.protectDesktopSettings,
                                enabled = settings.masterProtectionEnabled,
                                testTag = "switch_rule_desktop",
                                onCheckedChange = onToggleDesktopRule,
                            )
                        }
                    }
                }

                // Quick verification + Tecno HiOS tip
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(
                            onClick = onTestOverlayLock,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("btn_test_pin_overlay"),
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Shield,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp),
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = stringResource(R.string.action_test_lock),
                                style = MaterialTheme.typography.labelLarge,
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.55f),
                            border = BorderStroke(
                                1.dp,
                                MaterialTheme.colorScheme.outline.copy(alpha = 0.35f),
                            ),
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Tune,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(22.dp),
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = stringResource(R.string.hios_tip_title),
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.onSurface,
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = stringResource(R.string.hios_tip_desc),
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                                TextButton(
                                    onClick = onOpenAppSettings,
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .testTag("btn_open_app_settings"),
                                ) {
                                    Text(
                                        text = stringResource(R.string.action_app_battery),
                                        style = MaterialTheme.typography.labelMedium,
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }
        }
    }
}

@Composable
private fun DashboardTopBar(
    onChangePin: () -> Unit,
    onLockPanel: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = stringResource(R.string.dashboard_title),
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground,
            )
            Text(
                text = stringResource(R.string.dashboard_subtitle),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            FilledTonalButton(
                onClick = onChangePin,
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("btn_change_pin"),
            ) {
                Icon(
                    imageVector = Icons.Filled.Password,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = stringResource(R.string.action_change_pin),
                    style = MaterialTheme.typography.labelMedium,
                )
            }

            IconButton(
                onClick = onLockPanel,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("btn_lock_panel"),
            ) {
                Icon(
                    imageVector = Icons.Filled.Lock,
                    contentDescription = stringResource(R.string.action_lock_app),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun HeroProtectionCard(
    allGranted: Boolean,
    grantedCount: Int,
    masterEnabled: Boolean,
    interceptionCount: Int,
    isFullyProtected: Boolean,
    onToggleMaster: (Boolean) -> Unit,
) {
    val accentColor by animateColorAsState(
        targetValue = when {
            isFullyProtected -> MaterialTheme.colorScheme.primary
            !allGranted -> MaterialTheme.colorScheme.tertiary
            else -> MaterialTheme.colorScheme.secondary
        },
        label = "heroAccent",
    )

    val statusTitle = when {
        isFullyProtected -> stringResource(R.string.status_protected)
        !allGranted -> stringResource(R.string.status_pending_permissions, grantedCount)
        else -> stringResource(R.string.status_paused)
    }

    val statusDesc = when {
        isFullyProtected -> stringResource(R.string.status_protected_desc)
        !allGranted -> stringResource(R.string.status_pending_desc)
        else -> stringResource(R.string.status_paused_desc)
    }

    Surface(
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.2.dp, accentColor.copy(alpha = 0.45f)),
        color = MaterialTheme.colorScheme.surfaceContainer,
        tonalElevation = 3.dp,
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            accentColor.copy(alpha = 0.16f),
                            Color.Transparent,
                        ),
                    ),
                )
                .padding(18.dp),
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    Surface(
                        shape = CircleShape,
                        color = accentColor.copy(alpha = 0.18f),
                        modifier = Modifier.size(52.dp),
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (isFullyProtected) {
                                    Icons.Filled.VerifiedUser
                                } else {
                                    Icons.Filled.WarningAmber
                                },
                                contentDescription = statusTitle,
                                tint = accentColor,
                                modifier = Modifier.size(28.dp),
                            )
                        }
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = statusTitle,
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = statusDesc,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column {
                        Text(
                            text = stringResource(R.string.master_switch_label),
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                        Text(
                            text = stringResource(R.string.stats_interceptions, interceptionCount),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }

                    Switch(
                        checked = masterEnabled,
                        onCheckedChange = onToggleMaster,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                            checkedTrackColor = MaterialTheme.colorScheme.primary,
                        ),
                        modifier = Modifier.testTag("switch_master_protection"),
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(
        text = title.uppercase(),
        style = MaterialTheme.typography.labelMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(horizontal = 4.dp),
    )
}

@Composable
private fun PermissionCard(
    icon: ImageVector,
    title: String,
    description: String,
    isGranted: Boolean,
    actionLabel: String,
    testTag: String,
    onClick: () -> Unit,
) {
    val badgeBg = if (isGranted) {
        MaterialTheme.colorScheme.primaryContainer
    } else {
        MaterialTheme.colorScheme.tertiaryContainer
    }
    val badgeText = if (isGranted) {
        MaterialTheme.colorScheme.onPrimaryContainer
    } else {
        MaterialTheme.colorScheme.onTertiaryContainer
    }

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        border = BorderStroke(
            1.dp,
            if (isGranted) {
                MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
            } else {
                MaterialTheme.colorScheme.outline.copy(alpha = 0.45f)
            },
        ),
        tonalElevation = 1.dp,
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = if (isGranted) {
                    MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
                } else {
                    MaterialTheme.colorScheme.surfaceVariant
                },
                modifier = Modifier.size(44.dp),
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = if (isGranted) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        modifier = Modifier.size(22.dp),
                    )
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f, fill = false),
                    )
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = badgeBg,
                    ) {
                        Text(
                            text = if (isGranted) {
                                stringResource(R.string.badge_active)
                            } else {
                                stringResource(R.string.badge_pending)
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = badgeText,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
                        )
                    }
                }
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            if (isGranted) {
                IconButton(
                    onClick = onClick,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag(testTag),
                ) {
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = stringResource(R.string.action_configured),
                        tint = MaterialTheme.colorScheme.primary,
                    )
                }
            } else {
                Button(
                    onClick = onClick,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                    ),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag(testTag),
                ) {
                    Text(
                        text = actionLabel,
                        style = MaterialTheme.typography.labelLarge,
                    )
                }
            }
        }
    }
}

@Composable
private fun ProtectedRuleRow(
    icon: ImageVector,
    title: String,
    description: String,
    checked: Boolean,
    enabled: Boolean,
    testTag: String,
    onCheckedChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (checked && enabled) {
                MaterialTheme.colorScheme.primary
            } else {
                MaterialTheme.colorScheme.onSurfaceVariant
            },
            modifier = Modifier.size(24.dp),
        )

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        Switch(
            checked = checked,
            enabled = enabled,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(testTag),
        )
    }
}
