package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatterySaver
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.FlashlightOff
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NetworkCell
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.XtraCardBorder
import com.example.ui.theme.XtraCardDark
import com.example.ui.theme.XtraCyanGlow
import com.example.ui.theme.XtraCyanPrimary
import com.example.ui.theme.XtraDarkNavyBg
import com.example.ui.theme.XtraNeonGreen
import com.example.ui.theme.XtraSurfaceDark
import com.example.ui.theme.XtraTextHigh
import com.example.ui.theme.XtraTextMed
import com.example.ui.theme.XtraWarningGold
import com.example.viewmodel.MainViewModel

@Composable
fun PhoneControlsScreen(viewModel: MainViewModel) {
    val deviceStatus by viewModel.deviceManager.deviceStatus.collectAsState()
    var volumeSliderValue by remember(deviceStatus.mediaVolumePercent) {
        mutableFloatStateOf(deviceStatus.mediaVolumePercent.toFloat())
    }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(XtraDarkNavyBg)
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("phone_controls_screen")
    ) {
        // Screen Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                Text(
                    text = "HARDWARE INTEGRATION",
                    color = XtraCyanGlow,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Phone Controls",
                    color = XtraTextHigh,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            IconButton(onClick = { viewModel.deviceManager.refreshStatus() }) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Refresh Telemetry",
                    tint = XtraCyanPrimary
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Device Telemetry Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = XtraCardDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, XtraCardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = XtraCyanPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "DEVICE TELEMETRY & SPECS",
                        color = XtraCyanPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text(text = "Model", color = XtraTextMed, fontSize = 11.sp)
                        Text(text = deviceStatus.deviceModel, color = XtraTextHigh, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(text = "OS Version", color = XtraTextMed, fontSize = 11.sp)
                        Text(text = deviceStatus.androidVersion, color = XtraTextHigh, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text(text = "Battery Status", color = XtraTextMed, fontSize = 11.sp)
                        Text(
                            text = "${deviceStatus.batteryPercent}% (${if (deviceStatus.isCharging) "Charging" else "Discharging"})",
                            color = XtraNeonGreen,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(text = "Internal Storage", color = XtraTextMed, fontSize = 11.sp)
                        Text(text = deviceStatus.memoryUsageText, color = XtraTextHigh, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Flashlight Toggle Tile
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = XtraCardDark,
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (deviceStatus.isTorchOn) XtraWarningGold else XtraCardBorder
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (deviceStatus.isTorchOn) Icons.Default.FlashlightOn else Icons.Default.FlashlightOff,
                        contentDescription = "Flashlight",
                        tint = if (deviceStatus.isTorchOn) XtraWarningGold else XtraTextMed,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(14.dp))
                    Column {
                        Text(
                            text = "Flashlight / Torch",
                            color = XtraTextHigh,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (deviceStatus.isTorchOn) "Active (Illuminating)" else "Deactivated",
                            color = if (deviceStatus.isTorchOn) XtraWarningGold else XtraTextMed,
                            fontSize = 12.sp
                        )
                    }
                }

                Switch(
                    checked = deviceStatus.isTorchOn,
                    onCheckedChange = { enabled ->
                        viewModel.deviceManager.setFlashlight(enabled)
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.Black,
                        checkedTrackColor = XtraWarningGold
                    ),
                    modifier = Modifier.testTag("flashlight_switch")
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Volume Adjustment Slider
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = XtraCardDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, XtraCardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "Volume",
                            tint = XtraCyanPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Media Volume",
                            color = XtraTextHigh,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "${volumeSliderValue.toInt()}%",
                        color = XtraCyanGlow,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Slider(
                    value = volumeSliderValue,
                    onValueChange = { volumeSliderValue = it },
                    onValueChangeFinished = {
                        viewModel.deviceManager.setMediaVolume(volumeSliderValue.toInt())
                    },
                    valueRange = 0f..100f,
                    colors = SliderDefaults.colors(
                        thumbColor = XtraCyanPrimary,
                        activeTrackColor = XtraCyanPrimary,
                        inactiveTrackColor = XtraCardBorder
                    ),
                    modifier = Modifier.testTag("volume_slider")
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Hardware Shortcuts Grid
        Text(
            text = "SYSTEM SETTINGS INTERFACES",
            color = XtraTextMed,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        val controlButtons = listOf(
            Triple("Wi-Fi Settings", Icons.Default.Wifi) { viewModel.deviceManager.openWifiSettings(); Unit },
            Triple("Bluetooth", Icons.Default.Bluetooth) { viewModel.deviceManager.openBluetoothSettings(); Unit },
            Triple("Mobile Network", Icons.Default.NetworkCell) { viewModel.deviceManager.openNetworkSettings(); Unit },
            Triple("Location", Icons.Default.LocationOn) { viewModel.deviceManager.openLocationSettings(); Unit },
            Triple("Battery Saver", Icons.Default.BatterySaver) { viewModel.deviceManager.openBatterySaverSettings(); Unit },
            Triple("Display Settings", Icons.Default.Settings) { viewModel.deviceManager.openDisplaySettings(); Unit },
            Triple("Open Camera", Icons.Default.CameraAlt) { viewModel.deviceManager.openCamera(); Unit },
            Triple("Open Gallery", Icons.Default.PhotoLibrary) { viewModel.deviceManager.openGallery(); Unit },
            Triple("Share via Android", Icons.Default.Share) { viewModel.deviceManager.shareText("Shared using XTRA AI Personal Assistant"); Unit }
        )

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            controlButtons.chunked(2).forEach { rowItems ->
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    rowItems.forEach { (label, icon, onClick) ->
                        OutlinedButton(
                            onClick = onClick,
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, XtraCardBorder),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = XtraCardDark
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("control_btn_${label.replace(" ", "_")}")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = label,
                                    tint = XtraCyanPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = label,
                                    color = XtraTextHigh,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                    if (rowItems.size == 1) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Lock Screen Notice Card (Requirement: Do not pretend action succeeded if Android denies permission)
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = XtraSurfaceDark,
            border = androidx.compose.foundation.BorderStroke(1.dp, XtraCardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(14.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Lock Info",
                    tint = XtraWarningGold,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Screen Lock Policy",
                        color = XtraTextHigh,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "On standard Android devices, programmatic screen locking requires Device Administrator enrollment. You can lock your phone instantly using your physical power button.",
                        color = XtraTextMed,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
