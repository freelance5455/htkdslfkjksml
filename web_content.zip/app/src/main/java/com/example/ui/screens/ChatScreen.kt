package com.example.ui.screens

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.ChatLanguage
import com.example.data.models.ChatMessage
import com.example.data.models.MessageSender
import com.example.ui.theme.AiBubbleDark
import com.example.ui.theme.HazimCyan
import com.example.ui.theme.HazimCyanGlow
import com.example.ui.theme.HazimDarkBackground
import com.example.ui.theme.HazimDarkBorder
import com.example.ui.theme.HazimDarkSurface
import com.example.ui.theme.HazimDarkSurfaceVariant
import com.example.ui.theme.HazimPurple
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import com.example.ui.theme.TextTertiaryDark
import com.example.ui.theme.UserBubbleDark
import com.example.viewmodel.HazimAiViewModel

@Composable
fun ChatScreen(
    viewModel: HazimAiViewModel,
    onOpenDrawer: () -> Unit
) {
    val context = LocalContext.current
    val listState = rememberLazyListState()

    val messages by viewModel.messages.collectAsState()
    val isChatLoading by viewModel.isChatLoading.collectAsState()
    val chatInputText by viewModel.chatInputText.collectAsState()
    val chatLanguage by viewModel.chatLanguage.collectAsState()

    var showLanguageMenu by remember { mutableStateOf(false) }

    // Speech-to-text launcher
    val speechRecognizerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spokenText = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!spokenText.isNullOrBlank()) {
                viewModel.setChatInputText(spokenText)
            }
        }
    }

    // Auto-scroll on new message
    LaunchedEffect(messages.size, isChatLoading) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(HazimDarkBackground)
            .imePadding()
            .navigationBarsPadding()
    ) {
        // Top Bar (ChatGPT / Claude / Gemini style)
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = HazimDarkBackground,
            shadowElevation = 0.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onOpenDrawer,
                        modifier = Modifier.testTag("chat_open_drawer_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Menu,
                            contentDescription = "Open Drawer",
                            tint = TextPrimaryDark
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // Model Badge Pill
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .border(1.dp, HazimDarkBorder, RoundedCornerShape(20.dp)),
                        color = HazimDarkSurface
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(HazimCyan)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "HAZIM AI Pro",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryDark
                            )
                        }
                    }
                }

                // Language Switcher Chip (English, Hindi, Hinglish, Kashmiri)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .border(1.dp, HazimCyan.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                            .clickable { showLanguageMenu = !showLanguageMenu }
                            .testTag("chat_language_selector"),
                        color = HazimDarkSurfaceVariant
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Language,
                                contentDescription = "Language",
                                tint = HazimCyan,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = chatLanguage.displayName,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = HazimCyan
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    IconButton(
                        onClick = { viewModel.createNewChat() },
                        modifier = Modifier.testTag("chat_new_session_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "New Chat",
                            tint = TextSecondaryDark
                        )
                    }
                }
            }
        }

        // Language Dropdown Banner if toggled
        if (showLanguageMenu) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                shape = RoundedCornerShape(12.dp),
                color = HazimDarkSurfaceVariant,
                border = androidx.compose.foundation.BorderStroke(1.dp, HazimDarkBorder)
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Text(
                        text = "Choose Chat & Response Language:",
                        fontSize = 12.sp,
                        color = TextSecondaryDark,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ChatLanguage.values().forEach { lang ->
                            val isSelected = chatLanguage == lang
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) HazimCyan else HazimDarkSurface)
                                    .clickable {
                                        viewModel.setChatLanguage(lang)
                                        showLanguageMenu = false
                                        Toast
                                            .makeText(
                                                context,
                                                "Language set to ${lang.displayName}",
                                                Toast.LENGTH_SHORT
                                            )
                                            .show()
                                    }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = lang.displayName,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) Color.Black else TextPrimaryDark
                                )
                            }
                        }
                    }
                }
            }
        }

        // Messages List or Welcome Screen
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            val showWelcomeState = messages.isEmpty() || (messages.size == 1 && messages[0].sender == MessageSender.AI)
            if (showWelcomeState) {
                // Empty / Welcome state with starter prompt suggestions
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    item {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(RoundedCornerShape(18.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(HazimCyan, HazimPurple)
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = Color.Black,
                                modifier = Modifier.size(34.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "What can HAZIM AI help with today?",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Chat in English, हिन्दी, Hinglish & Kashmiri. Create TTI art, ITV videos & STV natural voices.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondaryDark,
                            fontSize = 13.sp
                        )

                        Spacer(modifier = Modifier.height(28.dp))

                        // Prompt Suggestions Cards
                        Column(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            PromptSuggestionCard(
                                title = "🏔️ Kashmiri Poetry & Culture",
                                prompt = "کٔشیر ہنٛز خوبصورتی تہٕ ڈل جھیل پؠٹھ کٲشُر منز اکھ خوبصورت نظم لؠکھ (Write a beautiful Kashmiri poem on Dal Lake)",
                                onClick = {
                                    viewModel.setChatInputText("کٔشیر ہنٛز خوبصورتی پؠٹھ کٲشُر منز اکھ خوبصورت نظم لؠکھ")
                                    viewModel.setChatLanguage(ChatLanguage.KASHMIRI)
                                }
                            )

                            PromptSuggestionCard(
                                title = "🇮🇳 Hinglish Creative Chat",
                                prompt = "Bhai, AI kaise kaam karta hai aur Text-to-Image (TTI) ka secret kya hai? Ekdum simple Hinglish me samjhao!",
                                onClick = {
                                    viewModel.setChatInputText("Bhai, AI kaise kaam karta hai aur TTI ka secret kya hai? Hinglish me samjhao!")
                                    viewModel.setChatLanguage(ChatLanguage.HINGLISH)
                                }
                            )

                            PromptSuggestionCard(
                                title = "🎨 TTI Prompt Creator",
                                prompt = "Create a master prompt for Text-to-Image generator: Futuristic Srinagar smart city in 2050 with floating shikaras and neon lights.",
                                onClick = {
                                    viewModel.setChatInputText("Create a detailed 8k TTI prompt for Futuristic Srinagar Kashmir in 2050 with neon shikaras.")
                                }
                            )

                            PromptSuggestionCard(
                                title = "🎙️ STV Voice Script",
                                prompt = "Write an inspiring 30-second speech script in Hindi for Speech to Voice (STV) synthesis.",
                                onClick = {
                                    viewModel.setChatInputText("Speech to Voice (STV) के लिए एक प्रेरणादायक 30 सेकंड का हिन्दी भाषण स्क्रिप्ट लिखो।")
                                    viewModel.setChatLanguage(ChatLanguage.HINDI)
                                }
                            )
                        }
                    }
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item { Spacer(modifier = Modifier.height(6.dp)) }

                    items(messages) { message ->
                        ChatMessageItem(
                            message = message,
                            onCopy = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("HAZIM AI", message.text)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
                            },
                            onSpeak = { viewModel.speakMessage(message) },
                            onShare = {
                                val sendIntent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_TEXT, message.text)
                                    type = "text/plain"
                                }
                                context.startActivity(Intent.createChooser(sendIntent, "Share Message"))
                            }
                        )
                    }

                    if (isChatLoading) {
                        item {
                            AiTypingIndicator()
                        }
                    }

                    item { Spacer(modifier = Modifier.height(10.dp)) }
                }
            }
        }

        // Bottom Input Bar (ChatGPT / Claude clean aesthetic)
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            shape = RoundedCornerShape(26.dp),
            color = HazimDarkSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, HazimDarkBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Voice input button (Microphone)
                IconButton(
                    onClick = {
                        try {
                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(
                                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                                )
                                putExtra(
                                    RecognizerIntent.EXTRA_PROMPT,
                                    "Speak to HAZIM AI (${chatLanguage.displayName})..."
                                )
                            }
                            speechRecognizerLauncher.launch(intent)
                        } catch (e: Exception) {
                            Toast.makeText(context, "Speech recognition not available", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.testTag("chat_mic_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Voice Input",
                        tint = HazimCyan,
                        modifier = Modifier.size(22.dp)
                    )
                }

                // Text Input Field
                TextField(
                    value = chatInputText,
                    onValueChange = { viewModel.setChatInputText(it) },
                    placeholder = {
                        Text(
                            text = "Message HAZIM AI in ${chatLanguage.displayName}...",
                            color = TextTertiaryDark,
                            fontSize = 14.sp
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chat_input_field"),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        focusedTextColor = TextPrimaryDark,
                        unfocusedTextColor = TextPrimaryDark
                    ),
                    maxLines = 4,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { viewModel.sendChatMessage() })
                )

                // Send Button
                val hasInput = chatInputText.isNotBlank()
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(
                            if (hasInput && !isChatLoading) HazimCyan else HazimDarkSurfaceVariant
                        )
                        .clickable(enabled = hasInput && !isChatLoading) {
                            viewModel.sendChatMessage()
                        }
                        .testTag("chat_send_button"),
                    contentAlignment = Alignment.Center
                ) {
                    if (isChatLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            color = HazimCyan,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.ArrowUpward,
                            contentDescription = "Send",
                            tint = if (hasInput) Color.Black else TextSecondaryDark,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatMessageItem(
    message: ChatMessage,
    onCopy: () -> Unit,
    onSpeak: () -> Unit,
    onShare: () -> Unit
) {
    val isUser = message.sender == MessageSender.USER

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        if (!isUser) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Brush.linearGradient(listOf(HazimCyan, HazimPurple))),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "H",
                        color = Color.Black,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "HAZIM AI",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = TextPrimaryDark
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = message.language.displayName,
                    fontSize = 10.sp,
                    color = HazimCyanGlow
                )
            }
        }

        Surface(
            modifier = Modifier
                .fillMaxWidth(if (isUser) 0.85f else 0.98f)
                .clip(
                    RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (isUser) 16.dp else 4.dp,
                        bottomEnd = if (isUser) 4.dp else 16.dp
                    )
                )
                .border(
                    1.dp,
                    if (isUser) HazimDarkBorder else HazimDarkBorder.copy(alpha = 0.5f),
                    RoundedCornerShape(16.dp)
                ),
            color = if (isUser) UserBubbleDark else AiBubbleDark
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = message.text,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextPrimaryDark,
                    lineHeight = 22.sp
                )

                if (!isUser) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onSpeak,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = "Listen voice",
                                tint = HazimCyan,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        IconButton(
                            onClick = onCopy,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy",
                                tint = TextSecondaryDark,
                                modifier = Modifier.size(15.dp)
                            )
                        }

                        IconButton(
                            onClick = onShare,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = "Share",
                                tint = TextSecondaryDark,
                                modifier = Modifier.size(15.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AiTypingIndicator() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(22.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(Brush.linearGradient(listOf(HazimCyan, HazimPurple))),
            contentAlignment = Alignment.Center
        ) {
            Text("H", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.width(10.dp))
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = HazimDarkSurfaceVariant,
            modifier = Modifier.border(1.dp, HazimDarkBorder, RoundedCornerShape(12.dp))
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(14.dp),
                    strokeWidth = 2.dp,
                    color = HazimCyan
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "HAZIM AI is thinking...",
                    fontSize = 12.sp,
                    color = TextSecondaryDark
                )
            }
        }
    }
}

@Composable
private fun PromptSuggestionCard(
    title: String,
    prompt: String,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, HazimDarkBorder, RoundedCornerShape(14.dp))
            .clickable { onClick() },
        color = HazimDarkSurface
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = HazimCyan
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = prompt,
                fontSize = 12.sp,
                color = TextSecondaryDark,
                lineHeight = 18.sp
            )
        }
    }
}
