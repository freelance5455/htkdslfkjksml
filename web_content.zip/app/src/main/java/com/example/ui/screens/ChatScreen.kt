package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.ArrowUpward
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.KeyboardArrowDown
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ChatEntity
import com.example.data.local.MessageEntity
import com.example.ui.components.ChatDrawerContent
import com.example.ui.components.MarkdownMessage
import com.example.ui.components.XireLogo
import com.example.ui.components.XirePromptDialog
import com.example.ui.theme.InterFontFamily
import com.example.ui.theme.LocalXireColors
import com.example.ui.theme.LoraFontFamily
import com.example.ui.viewmodel.XireUiState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ChatScreen(
    uiState: XireUiState,
    onNewChat: () -> Unit,
    onSelectChat: (Long) -> Unit,
    onRenameChat: (Long, String) -> Unit,
    onDeleteChat: (Long) -> Unit,
    onSelectModel: (String) -> Unit,
    onOpenModels: () -> Unit,
    onOpenSettings: () -> Unit,
    onSendMessage: (String) -> Unit,
    onStopGeneration: () -> Unit,
    onRegenerateLast: () -> Unit
) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    var desktopDrawerOpen by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()

    var chatToRename by remember { mutableStateOf<ChatEntity?>(null) }
    var chatToDelete by remember { mutableStateOf<ChatEntity?>(null) }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isExpandedScreen = maxWidth >= 840.dp

        if (isExpandedScreen) {
            Row(modifier = Modifier.fillMaxSize()) {
                AnimatedVisibility(visible = desktopDrawerOpen) {
                    ChatDrawerContent(
                        chats = uiState.chats,
                        activeChatId = uiState.activeChatId,
                        userProfile = uiState.userProfile,
                        onCloseDrawer = { desktopDrawerOpen = false },
                        onNewChat = onNewChat,
                        onSelectChat = onSelectChat,
                        onRenameChat = { chatToRename = it },
                        onDeleteChat = { chatToDelete = it },
                        onOpenModels = onOpenModels,
                        onOpenSettings = onOpenSettings
                    )
                }
                ChatMainContent(
                    uiState = uiState,
                    onToggleDrawer = { desktopDrawerOpen = !desktopDrawerOpen },
                    onSelectModel = onSelectModel,
                    onOpenModels = onOpenModels,
                    onSendMessage = onSendMessage,
                    onStopGeneration = onStopGeneration,
                    onRegenerateLast = onRegenerateLast,
                    modifier = Modifier.weight(1f)
                )
            }
        } else {
            ModalNavigationDrawer(
                drawerState = drawerState,
                drawerContent = {
                    ChatDrawerContent(
                        chats = uiState.chats,
                        activeChatId = uiState.activeChatId,
                        userProfile = uiState.userProfile,
                        onCloseDrawer = { scope.launch { drawerState.close() } },
                        onNewChat = {
                            onNewChat()
                            scope.launch { drawerState.close() }
                        },
                        onSelectChat = { chatId ->
                            onSelectChat(chatId)
                            scope.launch { drawerState.close() }
                        },
                        onRenameChat = { chatToRename = it },
                        onDeleteChat = { chatToDelete = it },
                        onOpenModels = {
                            scope.launch { drawerState.close() }
                            onOpenModels()
                        },
                        onOpenSettings = {
                            scope.launch { drawerState.close() }
                            onOpenSettings()
                        }
                    )
                }
            ) {
                ChatMainContent(
                    uiState = uiState,
                    onToggleDrawer = { scope.launch { drawerState.open() } },
                    onSelectModel = onSelectModel,
                    onOpenModels = onOpenModels,
                    onSendMessage = onSendMessage,
                    onStopGeneration = onStopGeneration,
                    onRegenerateLast = onRegenerateLast,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }

    chatToRename?.let { target ->
        XirePromptDialog(
            title = "Rename chat",
            initialValue = target.title,
            confirmLabel = "Save",
            onDismiss = { chatToRename = null },
            onConfirm = { newTitle ->
                onRenameChat(target.id, newTitle)
                chatToRename = null
            }
        )
    }

    chatToDelete?.let { target ->
        XirePromptDialog(
            title = "Delete this chat?",
            initialValue = null,
            confirmLabel = "Delete",
            isDestructive = true,
            onDismiss = { chatToDelete = null },
            onConfirm = {
                onDeleteChat(target.id)
                chatToDelete = null
            }
        )
    }
}

@Composable
private fun ChatMainContent(
    uiState: XireUiState,
    onToggleDrawer: () -> Unit,
    onSelectModel: (String) -> Unit,
    onOpenModels: () -> Unit,
    onSendMessage: (String) -> Unit,
    onStopGeneration: () -> Unit,
    onRegenerateLast: () -> Unit,
    modifier: Modifier = Modifier
) {
    val xireColors = LocalXireColors.current
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    val itemCount = uiState.messages.size + if (uiState.isGenerating) 1 else 0
    LaunchedEffect(itemCount) {
        if (itemCount > 0) {
            listState.animateScrollToItem(itemCount - 1)
        }
    }
    LaunchedEffect(uiState.streamingText) {
        if (uiState.isGenerating && uiState.streamingText.isNotEmpty() && itemCount > 0) {
            listState.scrollToItem(itemCount - 1)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        // Top bar (#top)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                onClick = onToggleDrawer,
                shape = CircleShape,
                color = xireColors.card,
                border = BorderStroke(1.dp, xireColors.border),
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .size(40.dp)
                    .testTag("menu_button")
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Outlined.Menu,
                        contentDescription = "Open sidebar",
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            if (uiState.settings.selectedModelName.isNotBlank()) {
                Surface(
                    onClick = onOpenModels,
                    shape = RoundedCornerShape(999.dp),
                    color = xireColors.card,
                    border = BorderStroke(1.dp, xireColors.border)
                ) {
                    Text(
                        text = uiState.settings.selectedModelName,
                        fontFamily = InterFontFamily,
                        fontSize = 12.sp,
                        color = xireColors.muted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier
                            .widthIn(max = 200.dp)
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }
        }

        // Messages or Hero empty state (#msgs)
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.TopCenter
        ) {
            if (uiState.messages.isEmpty() && !uiState.isGenerating) {
                HeroEmptyState(
                    userName = uiState.userProfile.name,
                    selectedModelName = uiState.settings.selectedModelName
                )
            } else {
                LazyColumn(
                    state = listState,
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp),
                    modifier = Modifier
                        .widthIn(max = 760.dp)
                        .fillMaxWidth()
                        .fillMaxHeight()
                ) {
                    itemsIndexed(
                        items = uiState.messages,
                        key = { _, msg -> msg.id }
                    ) { index, message ->
                        if (message.role == "user") {
                            UserBubble(text = message.content)
                        } else {
                            val isLatestAssistant = index == uiState.messages.lastIndex && !uiState.isGenerating
                            AssistantBubble(
                                message = message,
                                showRegenerate = isLatestAssistant,
                                onRegenerate = onRegenerateLast
                            )
                        }
                    }

                    if (uiState.isGenerating) {
                        item(key = "streaming_bubble") {
                            StreamingAssistantBubble(
                                text = uiState.streamingText,
                                statusText = uiState.streamingStatusText
                            )
                        }
                    }
                }
            }
        }

        // Bottom composer (#cw / #comp)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val modelNames = remember(uiState.installedModels) {
                uiState.installedModels.map { it.name }
            }
            ComposerCard(
                inputText = inputText,
                onInputChange = { inputText = it },
                installedModels = modelNames,
                selectedModelName = uiState.settings.selectedModelName,
                isGenerating = uiState.isGenerating,
                onSelectModel = onSelectModel,
                onOpenModels = onOpenModels,
                onSend = {
                    val toSend = inputText.trim()
                    if (toSend.isNotEmpty()) {
                        inputText = ""
                        onSendMessage(toSend)
                    }
                },
                onStop = onStopGeneration
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Runs fully on your device. No data leaves it.",
                fontFamily = InterFontFamily,
                fontSize = 12.sp,
                color = xireColors.muted,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun HeroEmptyState(
    userName: String,
    selectedModelName: String
) {
    val xireColors = LocalXireColors.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        XireLogo(size = 64.dp, spin = true)
        Spacer(modifier = Modifier.height(14.dp))
        Text(
            text = "Back at it, ${userName.ifBlank { "friend" }}",
            style = MaterialTheme.typography.displaySmall,
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = if (selectedModelName.isBlank()) {
                "Add a model with ＋, then start chatting."
            } else {
                "Ready on device with $selectedModelName."
            },
            fontFamily = InterFontFamily,
            fontSize = 14.sp,
            color = xireColors.muted,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(48.dp))
    }
}

@Composable
private fun UserBubble(text: String) {
    val xireColors = LocalXireColors.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End
    ) {
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = xireColors.card,
            border = BorderStroke(1.dp, xireColors.border),
            modifier = Modifier.widthIn(max = 580.dp)
        ) {
            Text(
                text = text,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
            )
        }
    }
}

@Composable
private fun AssistantBubble(
    message: MessageEntity,
    showRegenerate: Boolean,
    onRegenerate: () -> Unit
) {
    val xireColors = LocalXireColors.current
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }

    LaunchedEffect(copied) {
        if (copied) {
            delay(1300)
            copied = false
        }
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.Top
    ) {
        XireLogo(
            size = 26.dp,
            modifier = Modifier.padding(top = 4.dp)
        )
        Column(modifier = Modifier.weight(1f)) {
            MarkdownMessage(text = message.content)

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                IconButton(
                    onClick = {
                        clipboard.setText(AnnotatedString(message.content))
                        copied = true
                    },
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.ContentCopy,
                        contentDescription = "Copy response",
                        tint = if (copied) MaterialTheme.colorScheme.onBackground else xireColors.muted,
                        modifier = Modifier.size(16.dp)
                    )
                }

                if (showRegenerate) {
                    IconButton(
                        onClick = onRegenerate,
                        modifier = Modifier.size(34.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Refresh,
                            contentDescription = "Write again",
                            tint = xireColors.muted,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                if (message.tokens != null && message.durationMs != null) {
                    val secs = message.durationMs / 1000.0
                    val tokPerSec = if (secs > 0.05 && message.tokens > 0) {
                        String.format(java.util.Locale.US, " · %.1f tok/s", message.tokens / secs)
                    } else {
                        ""
                    }
                    Text(
                        text = "${message.tokens} tokens · ${String.format(java.util.Locale.US, "%.1fs", secs)}$tokPerSec",
                        fontFamily = InterFontFamily,
                        fontSize = 12.5.sp,
                        color = xireColors.muted,
                        modifier = Modifier.padding(start = 6.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun StreamingAssistantBubble(
    text: String,
    statusText: String
) {
    val xireColors = LocalXireColors.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.Top
    ) {
        XireLogo(
            size = 26.dp,
            pulse = true,
            modifier = Modifier.padding(top = 4.dp)
        )
        Column(modifier = Modifier.weight(1f)) {
            if (text.isBlank()) {
                Text(
                    text = statusText.ifBlank { "Thinking…" },
                    fontFamily = InterFontFamily,
                    fontSize = 14.sp,
                    color = xireColors.muted,
                    modifier = Modifier.padding(top = 4.dp)
                )
            } else {
                MarkdownMessage(text = text)
            }
        }
    }
}

@Composable
private fun ComposerCard(
    inputText: String,
    onInputChange: (String) -> Unit,
    installedModels: List<String>,
    selectedModelName: String,
    isGenerating: Boolean,
    onSelectModel: (String) -> Unit,
    onOpenModels: () -> Unit,
    onSend: () -> Unit,
    onStop: () -> Unit
) {
    val xireColors = LocalXireColors.current
    var modelDropdownExpanded by remember { mutableStateOf(false) }

    Surface(
        shape = RoundedCornerShape(28.dp),
        color = xireColors.card,
        border = BorderStroke(1.dp, xireColors.border),
        modifier = Modifier
            .widthIn(max = 760.dp)
            .fillMaxWidth()
            .shadow(elevation = 4.dp, shape = RoundedCornerShape(28.dp), clip = false)
    ) {
        Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 36.dp, max = 160.dp)
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                if (inputText.isEmpty()) {
                    Text(
                        text = "Message XIRE AI",
                        fontFamily = LoraFontFamily,
                        fontSize = 16.sp,
                        color = xireColors.muted
                    )
                }
                BasicTextField(
                    value = inputText,
                    onValueChange = onInputChange,
                    textStyle = TextStyle(
                        fontFamily = LoraFontFamily,
                        fontSize = 16.sp,
                        lineHeight = 23.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("message_input")
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Add model '+' button
                Surface(
                    onClick = onOpenModels,
                    shape = CircleShape,
                    color = xireColors.card,
                    border = BorderStroke(1.dp, xireColors.border),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .size(38.dp)
                        .testTag("add_model_plus_button")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Outlined.Add,
                            contentDescription = "Add model file",
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                // Model selector pill
                Box(modifier = Modifier.weight(1f)) {
                    Surface(
                        onClick = {
                            if (installedModels.isEmpty()) {
                                onOpenModels()
                            } else {
                                modelDropdownExpanded = true
                            }
                        },
                        shape = RoundedCornerShape(999.dp),
                        color = xireColors.card,
                        border = BorderStroke(1.dp, xireColors.border),
                        modifier = Modifier
                            .heightIn(min = 38.dp)
                            .testTag("model_selector_pill")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = selectedModelName.ifBlank { "No model – tap ＋" },
                                fontFamily = InterFontFamily,
                                fontSize = 13.5.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f, fill = false)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Outlined.KeyboardArrowDown,
                                contentDescription = "Select model",
                                tint = xireColors.muted,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = modelDropdownExpanded,
                        onDismissRequest = { modelDropdownExpanded = false },
                        modifier = Modifier
                            .background(xireColors.card)
                            .border(1.dp, xireColors.border, RoundedCornerShape(16.dp))
                    ) {
                        installedModels.forEach { name ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = name,
                                        fontFamily = InterFontFamily,
                                        fontSize = 13.5.sp
                                    )
                                },
                                onClick = {
                                    modelDropdownExpanded = false
                                    onSelectModel(name)
                                }
                            )
                        }
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = "＋ Manage models…",
                                    fontFamily = InterFontFamily,
                                    fontSize = 13.5.sp,
                                    color = xireColors.muted
                                )
                            },
                            onClick = {
                                modelDropdownExpanded = false
                                onOpenModels()
                            }
                        )
                    }
                }

                // Send or Stop button
                val canSend = inputText.trim().isNotEmpty()
                Surface(
                    onClick = {
                        if (isGenerating) onStop() else if (canSend) onSend()
                    },
                    enabled = isGenerating || canSend,
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primary.copy(
                        alpha = if (isGenerating || canSend) 1f else 0.35f
                    ),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .size(38.dp)
                        .testTag("send_button")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (isGenerating) Icons.Outlined.Stop else Icons.Outlined.ArrowUpward,
                            contentDescription = if (isGenerating) "Stop generation" else "Send message",
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(19.dp)
                        )
                    }
                }
            }
        }
    }
}
