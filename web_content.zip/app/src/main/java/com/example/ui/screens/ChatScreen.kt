package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material.icons.outlined.AttachFile
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.PermMedia
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AssistantPersona
import com.example.data.model.ChatMessage
import com.example.data.model.GeminiModelOption
import com.example.data.model.MessageRole
import com.example.ui.MainViewModel
import com.example.ui.components.MessageBubble
import com.example.ui.theme.EditorialSerifFontFamily
import com.example.ui.theme.NexusAuroraBackdrop
import com.example.ui.theme.NexusBackground
import com.example.ui.theme.NexusBorder
import com.example.ui.theme.NexusCyan
import com.example.ui.theme.NexusCyanDark
import com.example.ui.theme.NexusCyanDim
import com.example.ui.theme.NexusEmerald
import com.example.ui.theme.NexusRose
import com.example.ui.theme.NexusSurface
import com.example.ui.theme.NexusSurfaceElevated
import com.example.ui.theme.NexusSurfaceVariant
import com.example.ui.theme.NexusTextPrimary
import com.example.ui.theme.NexusTextSecondary
import com.example.ui.theme.NexusTextTertiary
import com.example.ui.theme.NexusVioletLight
import com.example.ui.theme.SpaceGroteskFontFamily
import com.example.util.AttachmentReader

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: MainViewModel,
    onOpenSidebar: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val messages by viewModel.currentMessages.collectAsStateWithLifecycle()
    val currentSessionId by viewModel.currentSessionId.collectAsStateWithLifecycle()
    val isGenerating by viewModel.isGenerating.collectAsStateWithLifecycle()
    val streamingResponse by viewModel.streamingResponse.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val errorMessage by viewModel.errorMessage.collectAsStateWithLifecycle()
    val statusText by viewModel.statusText.collectAsStateWithLifecycle()
    val isOnline by viewModel.isOnline.collectAsStateWithLifecycle()
    val pendingAttachments by viewModel.pendingAttachments.collectAsStateWithLifecycle()

    // Clean per-session plain-text input state without any character restrictions
    var inputText by remember(currentSessionId) { mutableStateOf("") }
    var showModelSheet by remember { mutableStateOf(false) }
    var showAttachSheet by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    val visualMediaPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(5)
    ) { uris ->
        if (uris.isNotEmpty()) viewModel.addAttachmentUris(uris)
    }

    val documentFilePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) viewModel.addAttachmentUris(uris)
    }

    val infiniteTransition = rememberInfiniteTransition(label = "cursor_blink")
    val cursorAlpha by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "cursor"
    )

    LaunchedEffect(messages.size, streamingResponse.length, isGenerating) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size)
        }
    }

    if (showModelSheet) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { showModelSheet = false },
            sheetState = sheetState,
            containerColor = NexusSurface,
            contentColor = NexusTextPrimary,
            modifier = Modifier.testTag("model_selector_sheet")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 8.dp)
                    .navigationBarsPadding()
            ) {
                Text(
                    text = "Модель и интеллект",
                    fontFamily = SpaceGroteskFontFamily,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = NexusTextPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (isOnline) "Подключение к сети активно" else "Автономный режим (Helio G100)",
                    fontSize = 12.sp,
                    color = NexusTextSecondary
                )
                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "ВЕРСИЯ GEMINI",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = NexusTextTertiary
                )
                Spacer(modifier = Modifier.height(8.dp))

                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = NexusSurfaceVariant,
                    border = BorderStroke(0.8.dp, NexusBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        GeminiModelOption.values().forEachIndexed { idx, option ->
                            val selected = settings.geminiModel == option
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.updateGeminiModel(option)
                                        showModelSheet = false
                                    }
                                    .padding(horizontal = 16.dp, vertical = 13.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = option.title,
                                        fontSize = 14.sp,
                                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                                        color = if (selected) NexusVioletLight else NexusTextPrimary
                                    )
                                    Text(
                                        text = option.description,
                                        fontSize = 11.5.sp,
                                        color = NexusTextSecondary
                                    )
                                }
                                if (selected) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        tint = NexusCyan,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                            if (idx < GeminiModelOption.values().lastIndex) {
                                HorizontalDivider(thickness = 0.8.dp, color = NexusBorder)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "СТИЛЬ И ХАРАКТЕР",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = NexusTextTertiary
                )
                Spacer(modifier = Modifier.height(8.dp))

                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = NexusSurfaceVariant,
                    border = BorderStroke(0.8.dp, NexusBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        AssistantPersona.values().forEachIndexed { idx, persona ->
                            val selected = settings.persona == persona
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.updatePersona(persona)
                                        showModelSheet = false
                                    }
                                    .padding(horizontal = 16.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = persona.title,
                                        fontSize = 14.sp,
                                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                                        color = if (selected) NexusVioletLight else NexusTextPrimary
                                    )
                                    Text(
                                        text = persona.description,
                                        fontSize = 11.5.sp,
                                        color = NexusTextSecondary
                                    )
                                }
                                if (selected) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        tint = NexusCyan,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                            if (idx < AssistantPersona.values().lastIndex) {
                                HorizontalDivider(thickness = 0.8.dp, color = NexusBorder)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))
            }
        }
    }

    if (showAttachSheet) {
        val attachSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { showAttachSheet = false },
            sheetState = attachSheetState,
            containerColor = NexusSurface,
            contentColor = NexusTextPrimary,
            modifier = Modifier.testTag("attachment_picker_sheet")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp)
                    .navigationBarsPadding()
            ) {
                Text(
                    text = "Прикрепить к сообщению",
                    fontFamily = SpaceGroteskFontFamily,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = NexusTextPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Фото, видео (до 5 файлов), PDF, DOCX/XLSX, аудио или код",
                    fontSize = 12.sp,
                    color = NexusTextSecondary
                )
                Spacer(modifier = Modifier.height(14.dp))

                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = NexusSurfaceVariant,
                    border = BorderStroke(0.8.dp, NexusBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    showAttachSheet = false
                                    visualMediaPicker.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                                    )
                                }
                                .padding(horizontal = 16.dp, vertical = 15.dp)
                                .testTag("attach_pick_media_option"),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(NexusCyanDark),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.PermMedia,
                                    contentDescription = null,
                                    tint = NexusVioletLight,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Фото и видео из галереи",
                                    fontSize = 14.5.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = NexusTextPrimary
                                )
                                Text(
                                    text = "JPG, PNG, WEBP, MP4, MOV и др.",
                                    fontSize = 11.5.sp,
                                    color = NexusTextSecondary
                                )
                            }
                        }

                        HorizontalDivider(thickness = 0.8.dp, color = NexusBorder)

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    showAttachSheet = false
                                    documentFilePicker.launch(arrayOf("*/*"))
                                }
                                .padding(horizontal = 16.dp, vertical = 15.dp)
                                .testTag("attach_pick_file_option"),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(NexusCyanDark),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.Description,
                                    contentDescription = null,
                                    tint = NexusVioletLight,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Файлы и документы",
                                    fontSize = 14.5.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = NexusTextPrimary
                                )
                                Text(
                                    text = "PDF, DOCX, XLSX, TXT, исходный код, аудио",
                                    fontSize = 11.5.sp,
                                    color = NexusTextSecondary
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(18.dp))
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NexusBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        // ChatGPT / Claude Style Minimalist Borderless Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onOpenSidebar,
                modifier = Modifier
                    .size(44.dp)
                    .testTag("open_sidebar_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = "Открыть меню и разделы",
                    tint = NexusTextPrimary
                )
            }

            // Center Model Switcher Pill (exact ChatGPT / Claude pattern)
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = NexusSurface,
                border = BorderStroke(0.8.dp, NexusBorder),
                modifier = Modifier
                    .clickable { showModelSheet = true }
                    .testTag("model_selector_pill")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(if (isOnline) NexusEmerald else NexusRose)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "${settings.assistantName} • ${if (settings.engineType.isOffline) "Офлайн" else settings.effectiveGeminiModelTitle()}",
                        fontFamily = SpaceGroteskFontFamily,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = NexusTextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.widthIn(max = 210.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowDown,
                        contentDescription = "Сменить модель",
                        tint = NexusTextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = { showAttachSheet = true },
                    modifier = Modifier
                        .size(42.dp)
                        .testTag("top_attach_button")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.AttachFile,
                        contentDescription = "Прикрепить фото, видео или файл",
                        tint = if (pendingAttachments.isNotEmpty()) NexusVioletLight else NexusTextPrimary,
                        modifier = Modifier.size(21.dp)
                    )
                }
                IconButton(
                    onClick = { viewModel.startNewChat() },
                    modifier = Modifier
                        .size(42.dp)
                        .testTag("new_chat_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.EditNote,
                        contentDescription = "Новый диалог",
                        tint = NexusTextPrimary,
                        modifier = Modifier.size(23.dp)
                    )
                }
            }
        }

        // Error Banner
        AnimatedVisibility(visible = errorMessage != null) {
            Surface(
                color = NexusRose.copy(alpha = 0.14f),
                border = BorderStroke(0.8.dp, NexusRose.copy(alpha = 0.45f)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.WarningAmber,
                            contentDescription = null,
                            tint = NexusRose,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = errorMessage ?: "",
                            fontSize = 12.sp,
                            color = NexusTextPrimary,
                            lineHeight = 16.sp
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { viewModel.retryLastMessage() },
                            modifier = Modifier.size(30.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Повторить",
                                tint = NexusVioletLight,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        IconButton(
                            onClick = { viewModel.clearError() },
                            modifier = Modifier.size(30.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Закрыть",
                                tint = NexusTextTertiary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        // Conversation Stream (centered max-width for adaptive tablets + airy mobile margins)
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.TopCenter
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 720.dp)
                    .padding(horizontal = 18.dp),
                contentPadding = PaddingValues(top = 8.dp, bottom = 18.dp)
            ) {
                if (messages.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 84.dp, bottom = 32.dp)
                                .background(NexusAuroraBackdrop, RoundedCornerShape(32.dp))
                                .padding(vertical = 36.dp, horizontal = 20.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(NexusCyanDark)
                                        .border(0.8.dp, NexusCyan.copy(alpha = 0.5f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = null,
                                        tint = NexusVioletLight,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(18.dp))
                                Text(
                                    text = "Чем я могу помочь?",
                                    fontFamily = EditorialSerifFontFamily,
                                    fontSize = 27.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = NexusTextPrimary,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "${settings.assistantName} • ${settings.persona.title}",
                                    fontSize = 12.5.sp,
                                    color = NexusTextSecondary,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }

                items(messages, key = { it.id }) { msg ->
                    MessageBubble(
                        message = msg,
                        assistantName = settings.assistantName,
                        onSpeakClick = { textToSpeak ->
                            viewModel.speakText(textToSpeak)
                        }
                    )
                }

                if (isGenerating && streamingResponse.isNotBlank()) {
                    item {
                        val streamMsg = ChatMessage(
                            sessionId = 0,
                            role = MessageRole.ASSISTANT,
                            content = streamingResponse + if (cursorAlpha > 0.5f) " ▍" else "",
                            engineUsed = settings.engineType.title,
                            isStreaming = true
                        )
                        MessageBubble(
                            message = streamMsg,
                            assistantName = settings.assistantName,
                            onSpeakClick = {}
                        )
                    }
                } else if (isGenerating) {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = NexusVioletLight,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = statusText,
                                fontSize = 13.sp,
                                color = NexusTextSecondary
                            )
                        }
                    }
                }
            }
        }

        // Pending Attachments Preview Strip (only shown when user attached photo/video/file)
        AnimatedVisibility(visible = pendingAttachments.isNotEmpty()) {
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(pendingAttachments, key = { it.uriString }) { att ->
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(NexusSurfaceElevated)
                            .border(0.9.dp, NexusCyan.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                            .padding(start = 10.dp, end = 4.dp, top = 5.dp, bottom = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.widthIn(max = 180.dp)) {
                            Text(
                                text = att.displayName,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = NexusTextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${att.kind.label} • ${AttachmentReader.formatFileSize(att.sizeBytes)}",
                                fontSize = 10.sp,
                                color = NexusTextSecondary
                            )
                        }
                        IconButton(
                            onClick = { viewModel.removeAttachment(att.uriString) },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Удалить вложение",
                                tint = NexusTextSecondary,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
        }

        // Floating Minimalist ChatGPT / Claude Style Composer Pill (zero extra buttons, zero emojis)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            val canSend = inputText.isNotBlank() || pendingAttachments.isNotEmpty()

            Surface(
                shape = RoundedCornerShape(26.dp),
                color = NexusSurfaceVariant,
                border = BorderStroke(
                    0.9.dp,
                    if (canSend) NexusCyan.copy(alpha = 0.55f) else NexusBorder
                ),
                shadowElevation = 6.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 720.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 8.dp, end = 6.dp, top = 3.dp, bottom = 3.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    TextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        placeholder = {
                            Text(
                                text = "Написать сообщение...",
                                fontSize = 15.sp,
                                color = NexusTextTertiary
                            )
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("chat_input_field"),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            disabledContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent,
                            disabledIndicatorColor = Color.Transparent,
                            focusedTextColor = NexusTextPrimary,
                            unfocusedTextColor = NexusTextPrimary,
                            cursorColor = NexusVioletLight
                        ),
                        maxLines = 5,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Text,
                            capitalization = KeyboardCapitalization.Sentences,
                            autoCorrectEnabled = true,
                            imeAction = ImeAction.Send
                        ),
                        keyboardActions = KeyboardActions(
                            onSend = {
                                if (canSend && !isGenerating) {
                                    viewModel.sendMessage(inputText)
                                    inputText = ""
                                }
                            }
                        )
                    )

                    Spacer(modifier = Modifier.width(4.dp))

                    Box(modifier = Modifier.padding(bottom = 5.dp)) {
                        if (isGenerating) {
                            IconButton(
                                onClick = { viewModel.stopGeneration() },
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(NexusRose.copy(alpha = 0.2f))
                                    .border(1.dp, NexusRose, CircleShape)
                                    .testTag("stop_generation_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Stop,
                                    contentDescription = "Остановить генерацию",
                                    tint = NexusRose,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        } else {
                            IconButton(
                                onClick = {
                                    if (canSend) {
                                        viewModel.sendMessage(inputText)
                                        inputText = ""
                                    }
                                },
                                enabled = canSend,
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (canSend) Brush.linearGradient(listOf(NexusCyan, NexusCyanDim))
                                        else Brush.linearGradient(listOf(NexusSurfaceElevated, NexusSurfaceElevated))
                                    )
                                    .testTag("send_message_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ArrowUpward,
                                    contentDescription = "Отправить",
                                    tint = if (canSend) NexusTextPrimary else NexusTextTertiary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
