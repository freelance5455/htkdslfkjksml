package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.User
import com.example.ui.theme.DangerRed
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.GemCyan
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.SuccessGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MenuBottomSheet(
    user: User,
    onDismiss: () -> Unit,
    onLogoutClick: () -> Unit,
    onNavigateToWallet: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val context = LocalContext.current
    var activeDialog by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = DarkSurface,
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
                .testTag("menu_bottom_sheet")
        ) {
            // Profile Summary Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(DarkCard)
                    .border(1.dp, DarkBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                if (!user.photoUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = user.photoUrl,
                        contentDescription = "User Avatar",
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .border(2.dp, GoldPrimary, CircleShape)
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(GoldPrimary.copy(alpha = 0.2f))
                            .border(2.dp, GoldPrimary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = GoldPrimary,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = user.displayName.ifBlank { "Quest Player" },
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                    Text(
                        text = user.email.ifBlank { "Google Verified" },
                        color = Color.Gray,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "UID: ${user.uid.take(12)}...",
                            color = GemCyan,
                            fontSize = 11.sp
                        )
                        IconButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("UID", user.uid))
                                Toast.makeText(context, "UID copied to clipboard", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.size(20.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy UID",
                                tint = GemCyan,
                                modifier = Modifier.size(12.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Menu Items List
            MenuItemRow(
                icon = Icons.Default.Person,
                title = "My Profile",
                subtitle = "View full statistics and rewards history",
                onClick = { activeDialog = "PROFILE" }
            )

            MenuItemRow(
                icon = Icons.Default.History,
                title = "Task & Reward History",
                subtitle = "Track coin and gem earnings",
                onClick = {
                    onDismiss()
                    onNavigateToWallet()
                }
            )

            MenuItemRow(
                icon = Icons.Default.Share,
                title = "Refer and Earn",
                subtitle = "Invite friends and earn 50 bonus coins",
                onClick = { activeDialog = "REFERRAL" }
            )

            MenuItemRow(
                icon = Icons.Default.CloudDone,
                title = "Account Connect",
                subtitle = "Synced with Google Identity & Cloud Firestore",
                onClick = { activeDialog = "ACCOUNT" }
            )

            MenuItemRow(
                icon = Icons.Default.Policy,
                title = "Privacy Policy",
                subtitle = "Data handling & rewards redemption terms",
                onClick = { activeDialog = "PRIVACY" }
            )

            HorizontalDivider(
                color = DarkBorder,
                thickness = 1.dp,
                modifier = Modifier.padding(vertical = 12.dp)
            )

            // Logout Option
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .clickable {
                        onDismiss()
                        onLogoutClick()
                    }
                    .padding(vertical = 12.dp, horizontal = 8.dp)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Logout,
                    contentDescription = "Logout",
                    tint = DangerRed,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(14.dp))
                Column {
                    Text(
                        text = "Logout",
                        color = DangerRed,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Text(
                        text = "Sign out and clean local cache session",
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }

    // Dialogs
    when (activeDialog) {
        "PROFILE" -> {
            AlertDialog(
                onDismissRequest = { activeDialog = null },
                containerColor = DarkCard,
                title = { Text("My Profile", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Player: ${user.displayName}", color = Color.LightGray)
                        Text("Email: ${user.email}", color = Color.LightGray)
                        Text("Total Coins: ${user.coins} 🪙", color = GoldPrimary, fontWeight = FontWeight.Bold)
                        Text("Total Gems: ${user.gems} 💎", color = GemCyan, fontWeight = FontWeight.Bold)
                        Text("Daily Coins Today: ${user.dailyCoins}", color = Color.LightGray)
                        Text("Weekly Coins This Week: ${user.weeklyCoins}", color = Color.LightGray)
                    }
                },
                confirmButton = {
                    TextButton(onClick = { activeDialog = null }) {
                        Text("Close", color = GoldPrimary)
                    }
                }
            )
        }
        "REFERRAL" -> {
            AlertDialog(
                onDismissRequest = { activeDialog = null },
                containerColor = DarkCard,
                title = { Text("Refer and Earn", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Share your unique referral code with friends:", color = Color.LightGray)
                        Text(
                            text = "QUEST-${user.uid.take(6).uppercase()}",
                            color = GoldPrimary,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 20.sp
                        )
                        Text("Both you and your friend will receive +50 Coins when they complete their first offer!", color = Color.Gray, fontSize = 13.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("Referral", "QUEST-${user.uid.take(6).uppercase()}"))
                        Toast.makeText(context, "Referral code copied!", Toast.LENGTH_SHORT).show()
                        activeDialog = null
                    }) {
                        Text("Copy Code", color = GoldPrimary)
                    }
                }
            )
        }
        "ACCOUNT" -> {
            AlertDialog(
                onDismissRequest = { activeDialog = null },
                containerColor = DarkCard,
                title = { Text("Account Connection", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.CloudDone, contentDescription = null, tint = SuccessGreen)
                            Text("Google Play Services: Connected", color = Color.White)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.CloudDone, contentDescription = null, tint = SuccessGreen)
                            Text("Firestore Cloud Sync: Active", color = Color.White)
                        }
                        Text("Your progress is safely backed up to the cloud in real time.", color = Color.Gray, fontSize = 13.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = { activeDialog = null }) {
                        Text("Done", color = GoldPrimary)
                    }
                }
            )
        }
        "PRIVACY" -> {
            AlertDialog(
                onDismissRequest = { activeDialog = null },
                containerColor = DarkCard,
                title = { Text("Privacy Policy", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Quest Rewards complies with Google Play Developer Program policies.", color = Color.LightGray)
                        Text("• We only store your public Google profile information (Name, Email, UID) for reward crediting.", color = Color.Gray, fontSize = 13.sp)
                        Text("• Rewarded video ads are served directly via Google AdMob.", color = Color.Gray, fontSize = 13.sp)
                        Text("• All payout redemptions are processed transparently via the Admin Panel.", color = Color.Gray, fontSize = 13.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = { activeDialog = null }) {
                        Text("Understood", color = GoldPrimary)
                    }
                }
            )
        }
    }
}

@Composable
private fun MenuItemRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(vertical = 10.dp, horizontal = 8.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = GoldPrimary,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp
            )
            Text(
                text = subtitle,
                color = Color.Gray,
                fontSize = 12.sp
            )
        }
        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
            contentDescription = null,
            tint = DarkBorder,
            modifier = Modifier.size(14.dp)
        )
    }
}
