package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BlackCharcoal
import com.example.ui.theme.BlackPure
import com.example.ui.theme.SilverDark
import com.example.ui.theme.SilverLight
import com.example.ui.theme.SilverMuted
import com.example.ui.theme.SilverSurface
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@Composable
fun SplashScreen(
    onSplashFinished: () -> Unit
) {
    // 5 loading dots animations
    val dotScales = List(5) { remember { Animatable(0.7f) } }
    val dotOffsets = List(5) { remember { Animatable(0f) } }

    LaunchedEffect(Unit) {
        // Staggered smooth animation for the 5 dots
        dotScales.forEachIndexed { index, anim ->
            launch {
                delay(index * 130L)
                anim.animateTo(
                    targetValue = 1.35f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(450, easing = FastOutSlowInEasing),
                        repeatMode = RepeatMode.Reverse
                    )
                )
            }
        }
        dotOffsets.forEachIndexed { index, anim ->
            launch {
                delay(index * 130L)
                anim.animateTo(
                    targetValue = -10f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(450, easing = FastOutSlowInEasing),
                        repeatMode = RepeatMode.Reverse
                    )
                )
            }
        }

        // Automatic transition after smooth loading
        delay(2300L)
        onSplashFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(SilverLight),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // YM in large font, dark silver with black details
            Text(
                text = "YM",
                style = MaterialTheme.typography.displayLarge.copy(
                    fontSize = 58.sp,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 4.sp
                ),
                color = BlackPure,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(4.dp))

            // secret in small font under YM
            Text(
                text = "secret",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Normal,
                    letterSpacing = 9.sp
                ),
                color = SilverDark,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(36.dp))

            // 5 animated loading dots under "secret"
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                for (i in 0 until 5) {
                    Box(
                        modifier = Modifier
                            .offset { IntOffset(0, dotOffsets[i].value.roundToInt()) }
                            .scale(dotScales[i].value)
                            .size(11.dp)
                            .clip(CircleShape)
                            .background(SilverDark)
                            .border(BorderStroke(1.2.dp, BlackPure), CircleShape)
                    )
                }
            }
        }
    }
}
