package com.example.ui.animation

import androidx.compose.animation.core.withInfiniteAnimationFrameMillis
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.ui.theme.*
import kotlinx.coroutines.isActive
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

data class Particle(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    var size: Float,
    var alpha: Float = 1f,
    val color: Color,
    val lifeMax: Float,
    var lifeRemaining: Float,
    val type: ParticleType
)

enum class ParticleType {
    SPARK,
    HOURGLASS,
    LIGHTNING,
    RING
}

class ParticleManager {
    val particles = mutableStateListOf<Particle>()

    fun spawnBurst(origin: Offset, isUltimate: Boolean, intensity: Float = 1f) {
        val primaryColor = if (isUltimate) UltimateRedBright else OmnitrixGreenBright
        val secondaryColor = if (isUltimate) AlienGold else AlienCyan
        val coreColor = if (isUltimate) WhitePure else OmnitrixGreen

        // 1. Expanding Plasma Shockwave Ring
        particles.add(
            Particle(
                x = origin.x,
                y = origin.y,
                vx = 0f,
                vy = 0f,
                size = 10f,
                alpha = 0.9f,
                color = primaryColor,
                lifeMax = 320f,
                lifeRemaining = 320f,
                type = ParticleType.RING
            )
        )

        // 2. Radial Energy Sparks (14-20 particles)
        val sparkCount = (14 * intensity).toInt().coerceIn(8, 28)
        for (i in 0 until sparkCount) {
            val angle = Random.nextFloat() * 2f * Math.PI.toFloat()
            val speed = (Random.nextFloat() * 12f + 4f) * intensity
            val color = when (Random.nextInt(4)) {
                0 -> primaryColor
                1 -> secondaryColor
                2 -> coreColor
                else -> if (isUltimate) UltimateRedGlow else OmnitrixGreenGlow
            }
            val life = Random.nextFloat() * 260f + 180f
            particles.add(
                Particle(
                    x = origin.x,
                    y = origin.y,
                    vx = cos(angle) * speed,
                    vy = sin(angle) * speed,
                    size = Random.nextFloat() * 7f + 4f,
                    alpha = 1f,
                    color = color,
                    lifeMax = life,
                    lifeRemaining = life,
                    type = ParticleType.SPARK
                )
            )
        }

        // 3. Floating Omnitrix Hourglass Glyphs (3-5 items)
        for (i in 0 until 4) {
            val angle = Random.nextFloat() * 2f * Math.PI.toFloat()
            val speed = Random.nextFloat() * 6f + 2f
            particles.add(
                Particle(
                    x = origin.x + cos(angle) * 15f,
                    y = origin.y + sin(angle) * 15f,
                    vx = cos(angle) * speed,
                    vy = sin(angle) * speed - 2.5f, // float upward
                    size = Random.nextFloat() * 10f + 12f,
                    alpha = 1f,
                    color = if (i % 2 == 0) primaryColor else secondaryColor,
                    lifeMax = 360f,
                    lifeRemaining = 360f,
                    type = ParticleType.HOURGLASS
                )
            )
        }

        // 4. Electric Galvanic Arcs (2-4 items)
        for (i in 0 until 3) {
            val angle = Random.nextFloat() * 2f * Math.PI.toFloat()
            val speed = Random.nextFloat() * 8f + 5f
            particles.add(
                Particle(
                    x = origin.x,
                    y = origin.y,
                    vx = cos(angle) * speed,
                    vy = sin(angle) * speed,
                    size = Random.nextFloat() * 20f + 16f,
                    alpha = 1f,
                    color = secondaryColor,
                    lifeMax = 200f,
                    lifeRemaining = 200f,
                    type = ParticleType.LIGHTNING
                )
            )
        }
    }

    fun update(deltaMs: Float) {
        val iterator = particles.iterator()
        while (iterator.hasNext()) {
            val p = iterator.next()
            p.lifeRemaining -= deltaMs
            if (p.lifeRemaining <= 0) {
                iterator.remove()
                continue
            }

            val lifeRatio = p.lifeRemaining / p.lifeMax
            p.alpha = lifeRatio.coerceIn(0f, 1f)

            if (p.type == ParticleType.RING) {
                // Expanding ring
                p.size += deltaMs * 0.45f
            } else {
                p.x += p.vx
                p.y += p.vy
                p.vx *= 0.94f // air drag
                p.vy *= 0.94f
                if (p.type == ParticleType.SPARK) {
                    p.vy += 0.25f // gentle gravity
                }
            }
        }
    }
}

@Composable
fun ParticleOverlay(
    particleManager: ParticleManager,
    modifier: Modifier = Modifier
) {
    var lastFrameTime by remember { mutableLongStateOf(0L) }

    LaunchedEffect(Unit) {
        while (isActive) {
            withInfiniteAnimationFrameMillis { frameTime ->
                if (lastFrameTime != 0L) {
                    val delta = (frameTime - lastFrameTime).coerceAtMost(32L).toFloat()
                    if (particleManager.particles.isNotEmpty()) {
                        particleManager.update(delta)
                    }
                }
                lastFrameTime = frameTime
            }
        }
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        for (p in particleManager.particles) {
            when (p.type) {
                ParticleType.RING -> {
                    drawCircle(
                        color = p.color.copy(alpha = p.alpha * 0.7f),
                        radius = p.size,
                        center = Offset(p.x, p.y),
                        style = Stroke(width = 3.5f * p.alpha)
                    )
                }
                ParticleType.SPARK -> {
                    drawCircle(
                        color = p.color.copy(alpha = p.alpha),
                        radius = p.size * p.alpha,
                        center = Offset(p.x, p.y)
                    )
                }
                ParticleType.HOURGLASS -> {
                    drawHourglassParticle(
                        center = Offset(p.x, p.y),
                        size = p.size * (0.5f + 0.5f * p.alpha),
                        color = p.color.copy(alpha = p.alpha)
                    )
                }
                ParticleType.LIGHTNING -> {
                    drawLightningParticle(
                        start = Offset(p.x, p.y),
                        length = p.size,
                        angle = p.vx,
                        color = p.color.copy(alpha = p.alpha)
                    )
                }
            }
        }
    }
}

private fun DrawScope.drawHourglassParticle(center: Offset, size: Float, color: Color) {
    val half = size / 2f
    val path = Path().apply {
        // Top triangle
        moveTo(center.x - half, center.y - half)
        lineTo(center.x + half, center.y - half)
        lineTo(center.x, center.y)
        close()
        // Bottom triangle
        moveTo(center.x - half, center.y + half)
        lineTo(center.x + half, center.y + half)
        lineTo(center.x, center.y)
        close()
    }
    drawPath(path = path, color = color)
}

private fun DrawScope.drawLightningParticle(start: Offset, length: Float, angle: Float, color: Color) {
    val mid1 = Offset(start.x + cos(angle) * (length * 0.4f) + 4f, start.y + sin(angle) * (length * 0.4f) - 3f)
    val mid2 = Offset(mid1.x + cos(angle) * (length * 0.3f) - 4f, mid1.y + sin(angle) * (length * 0.3f) + 3f)
    val end = Offset(start.x + cos(angle) * length, start.y + sin(angle) * length)

    val path = Path().apply {
        moveTo(start.x, start.y)
        lineTo(mid1.x, mid1.y)
        lineTo(mid2.x, mid2.y)
        lineTo(end.x, end.y)
    }
    drawPath(path = path, color = color, style = Stroke(width = 2.5f))
}
