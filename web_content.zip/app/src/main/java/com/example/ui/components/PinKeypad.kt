package com.example.ui.components

import android.view.HapticFeedbackConstants
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.keyframes
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberCard
import com.example.ui.theme.CyberCardBorder
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.roundToInt

@Composable
fun PinKeypad(
    pinLength: Int = 6,
    currentPin: String,
    onPinChange: (String) -> Unit,
    onPinComplete: (String) -> Unit,
    errorMessage: String? = null,
    title: String = "Introduce tu PIN",
    subtitle: String = "Ingresa el PIN de 6 dígitos",
    modifier: Modifier = Modifier
) {
    val view = LocalView.current
    val shakeOffset = remember { Animatable(0f) }

    LaunchedEffect(errorMessage) {
        if (!errorMessage.isNullOrEmpty()) {
            shakeOffset.animateTo(
                targetValue = 0f,
                animationSpec = keyframes {
                    durationMillis = 400
                    0f at 0
                    -20f at 50
                    20f at 100
                    -15f at 150
                    15f at 200
                    -10f at 250
                    10f at 300
                    0f at 400
                }
            )
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Icon and Titles
        Box(
            modifier = Modifier
                .size(64.dp)
                .clip(CircleShape)
                .background(CyberCard)
                .border(1.5.dp, CyberCyan.copy(alpha = 0.5f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = null,
                tint = CyberCyan,
                modifier = Modifier.size(32.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            ),
            modifier = Modifier.testTag("pin_title")
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodyMedium.copy(
                color = TextSecondary
            )
        )

        Spacer(modifier = Modifier.height(28.dp))

        // 6 Dots PIN Indicator
        Row(
            modifier = Modifier
                .offset { IntOffset(shakeOffset.value.roundToInt(), 0) }
                .testTag("pin_dots_row"),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            for (i in 0 until pinLength) {
                val isFilled = i < currentPin.length
                val isError = !errorMessage.isNullOrEmpty()
                val dotColor = when {
                    isError -> CyberRed
                    isFilled -> CyberCyan
                    else -> CyberCardBorder
                }

                Box(
                    modifier = Modifier
                        .size(18.dp)
                        .clip(CircleShape)
                        .background(if (isFilled) dotColor else Color.Transparent)
                        .border(
                            width = 2.dp,
                            color = dotColor,
                            shape = CircleShape
                        )
                )
            }
        }

        // Error message row
        Box(
            modifier = Modifier
                .height(36.dp)
                .padding(top = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            if (!errorMessage.isNullOrEmpty()) {
                Text(
                    text = errorMessage,
                    color = CyberRed,
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                    modifier = Modifier.testTag("pin_error_text")
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Numeric Keypad Grid
        val keypadRows = listOf(
            listOf("1", "2", "3"),
            listOf("4", "5", "6"),
            listOf("7", "8", "9"),
            listOf("C", "0", "DEL")
        )

        Column(
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            for (row in keypadRows) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(22.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    for (key in row) {
                        KeypadButton(
                            label = key,
                            onClick = {
                                view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                                when (key) {
                                    "C" -> {
                                        onPinChange("")
                                    }
                                    "DEL" -> {
                                        if (currentPin.isNotEmpty()) {
                                            onPinChange(currentPin.dropLast(1))
                                        }
                                    }
                                    else -> {
                                        if (currentPin.length < pinLength) {
                                            val updated = currentPin + key
                                            onPinChange(updated)
                                            if (updated.length == pinLength) {
                                                onPinComplete(updated)
                                            }
                                        }
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun KeypadButton(
    label: String,
    onClick: () -> Unit
) {
    val isAction = label == "C" || label == "DEL"
    val interactionSource = remember { MutableInteractionSource() }

    Surface(
        modifier = Modifier
            .size(72.dp)
            .clip(CircleShape)
            .clickable(
                interactionSource = interactionSource,
                indication = ripple(bounded = true, color = CyberCyan),
                onClick = onClick
            )
            .border(
                width = 1.dp,
                color = if (isAction) CyberCardBorder.copy(alpha = 0.5f) else CyberCardBorder,
                shape = CircleShape
            )
            .testTag("keypad_button_$label"),
        shape = CircleShape,
        color = if (isAction) CyberCard.copy(alpha = 0.4f) else CyberCard
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(72.dp)
        ) {
            when (label) {
                "DEL" -> {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Backspace,
                        contentDescription = "Borrar",
                        tint = TextSecondary,
                        modifier = Modifier.size(24.dp)
                    )
                }
                "C" -> {
                    Text(
                        text = "C",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = TextMuted,
                            fontSize = 18.sp
                        )
                    )
                }
                else -> {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary,
                            fontSize = 26.sp
                        )
                    )
                }
            }
        }
    }
}
