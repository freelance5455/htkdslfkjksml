package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.DriveFileRenameOutline
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material.icons.outlined.RecordVoiceOver
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.local.MessageEntity
import com.example.ui.theme.RaynoxBlue
import com.example.ui.theme.RaynoxCyanAccent
import com.example.ui.theme.RaynoxIndigo
import com.example.ui.theme.RaynoxViolet
import com.example.util.PreparedAttachment
import com.example.voice.VoiceRecognitionState
import java.io.File
import kotlinx.coroutines.delay

@Composable
fun RaynoxTopBar(
    currentModel: String,
    hasMessages: Boolean,
    isDarkTheme: Boolean,
    autoSpeakEnabled: Boolean,
    wakeWordRunning: Boolean,
    temporalContext: com.example.util.DateTimeHelper.TemporalContext? = null,
    onOpenCalendarSheet: () -> Unit = {},
    onOpenToolsSheet: () -> Unit = {},
    onOpenSidebar: () -> Unit,
    onNewChat: () -> Unit,
    onSwitchModel: (String) -> Unit,
    onRenameChat: () -> Unit,
    onCopyTranscript: () -> Unit,
    onToggleAutoSpeak: () -> Unit,
    onToggleWakeWord: () -> Unit,
    onToggleTheme: () -> Unit,
    onDeleteCurrentChat: () -> Unit
) {
    var showOverflowMenu by remember { mutableStateOf(false) }
    var showModelMenu by remember { mutableStateOf(false) }

    val shortModelLabel = if (currentModel.contains("pro", ignoreCase = true)) "Pro" else "Core"

    Surface(
        color = MaterialTheme.colorScheme.background.copy(alpha = 0.96f),
        tonalElevation = 0.dp
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .height(56.dp)
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Left: Three-line Menu Button
                IconButton(
                    onClick = onOpenSidebar,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("open_sidebar_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Menu,
                        contentDescription = "Open navigation menu",
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }

                // Center: RAYNOX AI Title + Model Selector Pill
                val shortModelLabel = if (currentModel.contains("pro", ignoreCase = true)) "Pro" else "Core"
                Box {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { showModelMenu = true }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                            .testTag("top_bar_brand_selector"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(
                                        listOf(RaynoxIndigo, RaynoxBlue)
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(13.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "RAYNOX AI",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            ),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = shortModelLabel,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                color = RaynoxIndigo,
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = showModelMenu,
                        onDismissRequest = { showModelMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text("Raynox Core", fontWeight = FontWeight.SemiBold)
                                    Text(
                                        "Fast, versatile everyday intelligence",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            },
                            trailingIcon = {
                                if (!currentModel.contains("pro", ignoreCase = true)) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = RaynoxIndigo)
                                }
                            },
                            onClick = {
                                onSwitchModel(com.example.data.remote.GeminiClient.MODEL_RAYNOX_CORE)
                                showModelMenu = false
                            }
                        )
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text("Raynox Pro", fontWeight = FontWeight.SemiBold)
                                    Text(
                                        "Advanced reasoning, coding & analytical depth",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            },
                            trailingIcon = {
                                if (currentModel.contains("pro", ignoreCase = true)) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = RaynoxIndigo)
                                }
                            },
                            onClick = {
                                onSwitchModel(com.example.data.remote.GeminiClient.MODEL_RAYNOX_PRO)
                                showModelMenu = false
                            }
                        )
                    }
                }

                // Right: Clock Pill + Tools + New Chat + Compact Overflow Menu
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (temporalContext != null) {
                        LiveClockPill(
                            temporalContext = temporalContext,
                            onClick = onOpenCalendarSheet,
                            modifier = Modifier.padding(end = 4.dp)
                        )
                    }

                    IconButton(
                        onClick = onOpenToolsSheet,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("tools_top_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "Phone Tools & Reminders",
                            tint = MaterialTheme.colorScheme.onBackground
                        )
                    }

                    IconButton(
                        onClick = onNewChat,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("new_chat_top_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.EditNote,
                            contentDescription = "New Chat",
                            tint = MaterialTheme.colorScheme.onBackground
                        )
                    }

                    Box {
                        IconButton(
                            onClick = { showOverflowMenu = true },
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("more_options_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.MoreVert,
                                contentDescription = "More options",
                                tint = MaterialTheme.colorScheme.onBackground
                            )
                        }

                        DropdownMenu(
                            expanded = showOverflowMenu,
                            onDismissRequest = { showOverflowMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Live Clock & Calendar") },
                                leadingIcon = { Icon(Icons.Default.CalendarMonth, contentDescription = null) },
                                onClick = {
                                    showOverflowMenu = false
                                    onOpenCalendarSheet()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Phone Tools & Reminders") },
                                leadingIcon = { Icon(Icons.Default.Tune, contentDescription = null) },
                                onClick = {
                                    showOverflowMenu = false
                                    onOpenToolsSheet()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("New Chat") },
                                leadingIcon = { Icon(Icons.Default.EditNote, contentDescription = null) },
                                onClick = {
                                    showOverflowMenu = false
                                    onNewChat()
                                }
                            )
                            if (hasMessages) {
                                DropdownMenuItem(
                                    text = { Text("Rename Conversation") },
                                    leadingIcon = { Icon(Icons.Outlined.DriveFileRenameOutline, contentDescription = null) },
                                    onClick = {
                                        showOverflowMenu = false
                                        onRenameChat()
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Copy Conversation") },
                                    leadingIcon = { Icon(Icons.Outlined.ContentCopy, contentDescription = null) },
                                    onClick = {
                                        showOverflowMenu = false
                                        onCopyTranscript()
                                    }
                                )
                            }
                            DropdownMenuItem(
                                text = {
                                    Text(if (autoSpeakEnabled) "Auto-Speak Replies: ON" else "Auto-Speak Replies: OFF")
                                },
                                leadingIcon = { Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = null) },
                                onClick = {
                                    showOverflowMenu = false
                                    onToggleAutoSpeak()
                                }
                            )
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        if (wakeWordRunning) "Stop \"Hey Raynox\" Guard"
                                        else "Enable \"Hey Raynox\" Guard"
                                    )
                                },
                                leadingIcon = { Icon(Icons.Outlined.RecordVoiceOver, contentDescription = null) },
                                onClick = {
                                    showOverflowMenu = false
                                    onToggleWakeWord()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(if (isDarkTheme) "Switch to Light Theme" else "Switch to Dark Theme") },
                                leadingIcon = {
                                    Icon(
                                        if (isDarkTheme) Icons.Outlined.LightMode else Icons.Outlined.DarkMode,
                                        contentDescription = null
                                    )
                                },
                                onClick = {
                                    showOverflowMenu = false
                                    onToggleTheme()
                                }
                            )
                            if (hasMessages) {
                                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                                DropdownMenuItem(
                                    text = { Text("Delete Chat", color = MaterialTheme.colorScheme.error) },
                                    leadingIcon = {
                                        Icon(
                                            Icons.Outlined.DeleteOutline,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.error
                                        )
                                    },
                                    onClick = {
                                        showOverflowMenu = false
                                        onDeleteCurrentChat()
                                    }
                                )
                            }
                        }
                    }
                }
            }

            HorizontalDivider(
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f),
                thickness = 0.5.dp
            )
        }
    }
}

data class SuggestedPromptItem(
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val label: String,
    val subtitle: String,
    val fullPrompt: String
)

private val DEFAULT_SUGGESTED_PROMPTS = listOf(
    SuggestedPromptItem(
        icon = Icons.Default.CalendarMonth,
        label = "Live Date & Time",
        subtitle = "Aaj kya date hai, kal & parson ki date",
        fullPrompt = "Aaj kya date hai, abhi kitne baje hain aur kal kaunsa din hoga? Calendar details ke sath samjhao."
    ),
    SuggestedPromptItem(
        icon = Icons.Default.Tune,
        label = "Phone Assistant",
        subtitle = "Torch, battery, open apps & alarms",
        fullPrompt = "Torch on karo, battery percentage check karo aur YouTube open karo."
    ),
    SuggestedPromptItem(
        icon = Icons.Default.AutoAwesome,
        label = "Explain a concept",
        subtitle = "Clear, intuitive breakdown with analogies",
        fullPrompt = "Explain artificial intelligence and neural networks in a clear, intuitive way using relatable analogies."
    ),
    SuggestedPromptItem(
        icon = Icons.Default.GraphicEq,
        label = "Hindi & Hinglish",
        subtitle = "Bilingual productivity & creative assistance",
        fullPrompt = "Namaste Raynox! Mujhe apni daily productivity boost karne ke 5 practical tips Hinglish mein samjhao."
    )
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RaynoxWelcomeScreen(
    userName: String,
    onSelectPrompt: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 24.dp)
            .testTag("welcome_screen"),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Minimalist Luminous Emblem
        Box(
            modifier = Modifier
                .size(54.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(
                    Brush.linearGradient(
                        colors = listOf(RaynoxIndigo, RaynoxBlue, RaynoxViolet)
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = "RAYNOX AI Emblem",
                tint = Color.White,
                modifier = Modifier.size(26.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "RAYNOX AI",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.4.sp
            ),
            color = RaynoxIndigo
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = if (userName.isNotBlank()) {
                "Hi $userName, how can I help you today?"
            } else {
                "How can I help you today?"
            },
            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "Beyond Intelligence. Beyond Limits.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(26.dp))

        // Compact Suggested Prompts (2x2 or vertical compact pills depending on width)
        FlowRow(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 560.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            maxItemsInEachRow = 2
        ) {
            DEFAULT_SUGGESTED_PROMPTS.forEachIndexed { index, item ->
                Surface(
                    onClick = { onSelectPrompt(item.fullPrompt) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("suggested_prompt_$index"),
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = null,
                                tint = RaynoxIndigo,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.label,
                                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = item.subtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChatMessageRow(
    message: MessageEntity,
    isSpeakingThisMessage: Boolean,
    onRetry: (MessageEntity) -> Unit,
    onRegenerate: (MessageEntity) -> Unit,
    onToggleSpeak: (MessageEntity) -> Unit
) {
    if (message.role == "user") {
        UserMessageBubbleRight(message = message)
    } else {
        AssistantMessageLeft(
            message = message,
            isSpeaking = isSpeakingThisMessage,
            onRetry = { onRetry(message) },
            onRegenerate = { onRegenerate(message) },
            onToggleSpeak = { onToggleSpeak(message) }
        )
    }
}

@Composable
private fun UserMessageBubbleRight(message: MessageEntity) {
    // MANDATORY: User messages appear on the RIGHT
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .testTag("user_message_row_${message.id}"),
        horizontalArrangement = Arrangement.End
    ) {
        Column(
            modifier = Modifier.widthIn(min = 40.dp, max = 460.dp),
            horizontalAlignment = Alignment.End
        ) {
            // Attachment Preview inside User Message if present
            if (message.attachmentType != null) {
                UserAttachmentBadge(
                    attachmentType = message.attachmentType,
                    attachmentPath = message.attachmentPath,
                    attachmentName = message.attachmentName ?: "Attached file"
                )
                Spacer(modifier = Modifier.height(6.dp))
            }

            if (message.content.isNotBlank()) {
                Surface(
                    shape = RoundedCornerShape(
                        topStart = 18.dp,
                        topEnd = 18.dp,
                        bottomStart = 18.dp,
                        bottomEnd = 4.dp
                    ),
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    border = BorderStroke(
                        0.5.dp,
                        MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
                    )
                ) {
                    SelectionContainer {
                        Text(
                            text = message.content,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.padding(horizontal = 15.dp, vertical = 10.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun UserAttachmentBadge(
    attachmentType: String,
    attachmentPath: String?,
    attachmentName: String
) {
    when (attachmentType) {
        "IMAGE" -> {
            if (attachmentPath != null && File(attachmentPath).exists()) {
                AsyncImage(
                    model = File(attachmentPath),
                    contentDescription = attachmentName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(width = 200.dp, height = 150.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(14.dp))
                )
            }
        }

        "PDF", "TEXT" -> {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (attachmentType == "PDF") Icons.Default.PictureAsPdf else Icons.Default.Code,
                        contentDescription = null,
                        tint = if (attachmentType == "PDF") Color(0xFFEF4444) else RaynoxCyanAccent,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = attachmentName,
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun AssistantMessageLeft(
    message: MessageEntity,
    isSpeaking: Boolean,
    onRetry: () -> Unit,
    onRegenerate: () -> Unit,
    onToggleSpeak: () -> Unit
) {
    val context = LocalContext.current
    var copied by remember { mutableStateOf(false) }

    LaunchedEffect(copied) {
        if (copied) {
            delay(2000L)
            copied = false
        }
    }

    // MANDATORY: AI responses appear on the LEFT
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp)
            .testTag("assistant_message_row_${message.id}"),
        horizontalArrangement = Arrangement.Start,
        verticalAlignment = Alignment.Top
    ) {
        // Raynox Assistant Avatar on the Left
        Box(
            modifier = Modifier
                .padding(top = 2.dp)
                .size(28.dp)
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(
                        listOf(RaynoxIndigo, RaynoxBlue)
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = "Raynox AI",
                tint = Color.White,
                modifier = Modifier.size(15.dp)
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(
            modifier = Modifier
                .weight(1f)
                .widthIn(max = 580.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "RAYNOX AI",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.8.sp
                    ),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (message.isStreaming) {
                    StreamingPulseBadge()
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            when {
                message.isError -> {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.errorContainer,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.ErrorOutline,
                                    contentDescription = "Error",
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Response Failed",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = message.content,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = onRetry,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.error,
                                    contentColor = MaterialTheme.colorScheme.onError
                                ),
                                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("retry_message_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Retry", style = MaterialTheme.typography.labelLarge)
                            }
                        }
                    }
                }

                message.isStreaming && message.content.isBlank() -> {
                    TypingDotsIndicator()
                }

                else -> {
                    MarkdownText(
                        markdown = message.content,
                        textColor = MaterialTheme.colorScheme.onBackground
                    )

                    if (!message.isStreaming && message.content.isNotBlank()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        // Subtle Action Row (Copy, Read Aloud / Stop TTS, Regenerate)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            IconButton(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Raynox Response", message.content))
                                    copied = true
                                },
                                modifier = Modifier
                                    .size(34.dp)
                                    .testTag("copy_response_button_${message.id}")
                            ) {
                                Icon(
                                    imageVector = if (copied) Icons.Default.Check else Icons.Outlined.ContentCopy,
                                    contentDescription = "Copy response",
                                    tint = if (copied) Color(0xFF10B981) else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                            }

                            IconButton(
                                onClick = onToggleSpeak,
                                modifier = Modifier
                                    .size(34.dp)
                                    .testTag("speak_response_button_${message.id}")
                            ) {
                                Icon(
                                    imageVector = if (isSpeaking) Icons.Default.Stop else Icons.AutoMirrored.Filled.VolumeUp,
                                    contentDescription = if (isSpeaking) "Stop speaking" else "Read aloud",
                                    tint = if (isSpeaking) RaynoxIndigo else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(17.dp)
                                )
                            }

                            IconButton(
                                onClick = onRegenerate,
                                modifier = Modifier
                                    .size(34.dp)
                                    .testTag("regenerate_response_button_${message.id}")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Regenerate response",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(17.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StreamingPulseBadge() {
    val transition = rememberInfiniteTransition(label = "stream_pulse")
    val alpha by transition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(650), RepeatMode.Reverse),
        label = "pulse_alpha"
    )
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.alpha(alpha)
    ) {
        Box(
            modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(RaynoxCyanAccent)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = "Generating…",
            style = MaterialTheme.typography.labelSmall,
            color = RaynoxCyanAccent
        )
    }
}

@Composable
fun TypingDotsIndicator() {
    val transition = rememberInfiniteTransition(label = "typing_dots")
    val a1 by transition.animateFloat(
        initialValue = 0.25f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(500, delayMillis = 0), RepeatMode.Reverse),
        label = "d1"
    )
    val a2 by transition.animateFloat(
        initialValue = 0.25f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(500, delayMillis = 160), RepeatMode.Reverse),
        label = "d2"
    )
    val a3 by transition.animateFloat(
        initialValue = 0.25f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(500, delayMillis = 320), RepeatMode.Reverse),
        label = "d3"
    )

    Row(
        modifier = Modifier
            .padding(vertical = 8.dp)
            .testTag("typing_indicator"),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        listOf(a1, a2, a3).forEach { alpha ->
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .alpha(alpha)
                    .clip(CircleShape)
                    .background(RaynoxIndigo)
            )
        }
    }
}

@Composable
fun BottomMessageComposer(
    inputText: String,
    onInputTextChanged: (String) -> Unit,
    pendingAttachment: PreparedAttachment?,
    onRemoveAttachment: () -> Unit,
    onPickImage: () -> Unit,
    onPickDocument: () -> Unit,
    isGenerating: Boolean,
    onSendMessage: () -> Unit,
    onStopGenerating: () -> Unit,
    voiceState: VoiceRecognitionState,
    voiceLanguage: String,
    onCycleVoiceLanguage: () -> Unit,
    onToggleVoiceInput: () -> Unit
) {
    var showAttachMenu by remember { mutableStateOf(false) }
    val canSend = !isGenerating && (inputText.trim().isNotEmpty() || pendingAttachment != null)

    Surface(
        color = MaterialTheme.colorScheme.background,
        tonalElevation = 2.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .imePadding()
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            // Live Voice Listening Indicator Bar
            AnimatedVisibility(
                visible = voiceState.isListening || voiceState.error != null,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    border = BorderStroke(1.dp, RaynoxIndigo.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = null,
                                tint = if (voiceState.isListening) RaynoxCyanAccent else MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = when {
                                    voiceState.error != null -> voiceState.error
                                    voiceState.partialTranscript.isNotBlank() -> voiceState.partialTranscript
                                    else -> "Listening… Speak in English or Hindi"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                onClick = onCycleVoiceLanguage,
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surface
                            ) {
                                Text(
                                    text = if (voiceLanguage.startsWith("hi")) "हिन्दी (HI)" else "EN / Hinglish",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = RaynoxIndigo,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                            if (voiceState.isListening) {
                                IconButton(
                                    onClick = onToggleVoiceInput,
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Cancel voice input",
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Pending Attachment Preview Strip
            AnimatedVisibility(visible = pendingAttachment != null) {
                pendingAttachment?.let { att ->
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (att.previewImagePath != null && File(att.previewImagePath).exists()) {
                                AsyncImage(
                                    model = File(att.previewImagePath),
                                    contentDescription = att.displayName,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MaterialTheme.colorScheme.surface),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (att.attachmentType == "PDF") Icons.Default.PictureAsPdf else Icons.Default.Description,
                                        contentDescription = null,
                                        tint = RaynoxIndigo
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = att.displayName,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = att.fileSizeLabel,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            IconButton(
                                onClick = onRemoveAttachment,
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Remove attachment",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Main Composer Pill Container
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.Bottom
                ) {
                    // Attachment (+) Button with Menu
                    Box {
                        IconButton(
                            onClick = { showAttachMenu = true },
                            modifier = Modifier
                                .size(44.dp)
                                .testTag("attach_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Attach image or file",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        DropdownMenu(
                            expanded = showAttachMenu,
                            onDismissRequest = { showAttachMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text("Upload Image or Screenshot", fontWeight = FontWeight.Medium)
                                        Text(
                                            "Analyze photos, charts, or UI screenshots",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                },
                                leadingIcon = {
                                    Icon(Icons.Default.Image, contentDescription = null, tint = RaynoxIndigo)
                                },
                                onClick = {
                                    showAttachMenu = false
                                    onPickImage()
                                }
                            )
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text("Attach PDF, Text, or Code File", fontWeight = FontWeight.Medium)
                                        Text(
                                            "Supports .pdf, .txt, .md, .py, .kt, .js, .json, .csv",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                },
                                leadingIcon = {
                                    Icon(Icons.Default.Description, contentDescription = null, tint = RaynoxCyanAccent)
                                },
                                onClick = {
                                    showAttachMenu = false
                                    onPickDocument()
                                }
                            )
                        }
                    }

                    // Expandable Multiline Input Field
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 44.dp, max = 132.dp)
                            .padding(horizontal = 4.dp, vertical = 10.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        if (inputText.isEmpty()) {
                            Text(
                                text = "Message Raynox AI…",
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        }
                        BasicTextField(
                            value = inputText,
                            onValueChange = onInputTextChanged,
                            textStyle = MaterialTheme.typography.bodyLarge.copy(
                                color = MaterialTheme.colorScheme.onSurface
                            ),
                            cursorBrush = SolidColor(RaynoxIndigo),
                            maxLines = 5,
                            keyboardOptions = KeyboardOptions(
                                capitalization = KeyboardCapitalization.Sentences,
                                imeAction = ImeAction.Default
                            ),
                            keyboardActions = KeyboardActions(
                                onSend = { if (canSend) onSendMessage() }
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("message_input_field")
                        )
                    }

                    // Microphone Voice-Input Button
                    IconButton(
                        onClick = onToggleVoiceInput,
                        modifier = Modifier
                            .size(44.dp)
                            .testTag("voice_input_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Voice input",
                            tint = if (voiceState.isListening) RaynoxCyanAccent else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.width(2.dp))

                    // Send Button OR Stop Generation Button
                    if (isGenerating) {
                        IconButton(
                            onClick = onStopGenerating,
                            modifier = Modifier
                                .padding(bottom = 2.dp, end = 2.dp)
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.onBackground)
                                .testTag("stop_generation_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Stop,
                                contentDescription = "Stop generating",
                                tint = MaterialTheme.colorScheme.background,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    } else {
                        IconButton(
                            onClick = { if (canSend) onSendMessage() },
                            enabled = canSend,
                            modifier = Modifier
                                .padding(bottom = 2.dp, end = 2.dp)
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(
                                    if (canSend) RaynoxIndigo
                                    else MaterialTheme.colorScheme.surfaceVariant
                                )
                                .testTag("send_message_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ArrowUpward,
                                contentDescription = "Send message",
                                tint = if (canSend) Color.White
                                else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
