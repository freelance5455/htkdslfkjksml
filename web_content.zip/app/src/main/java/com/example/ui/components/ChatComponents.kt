package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.UiChatMessage
import com.example.ui.theme.SuesaAccentWhite
import com.example.ui.theme.SuesaBorder
import com.example.ui.theme.SuesaBubbleModel
import com.example.ui.theme.SuesaBubbleUser
import com.example.ui.theme.SuesaCodeBg
import com.example.ui.theme.SuesaCodeHeader
import com.example.ui.theme.SuesaPurple
import com.example.ui.theme.SuesaPurpleBorder
import com.example.ui.theme.SuesaSurface
import com.example.ui.theme.SuesaTextPrimary
import com.example.ui.theme.SuesaTextSecondary
import com.example.util.SelectedAttachment
import kotlinx.coroutines.delay

@Composable
fun SuesaHeader(
    isFloatingPanelOpen: Boolean,
    onOpenSummaries: () -> Unit,
    onNewChat: () -> Unit,
    onToggleFloatingPanel: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = SuesaSurface,
        modifier = modifier.fillMaxWidth()
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(62.dp)
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Logo / Chat Summary Avatar Button ("S")
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF292929))
                        .border(1.dp, SuesaPurpleBorder, CircleShape)
                        .clickable(onClick = onOpenSummaries)
                        .testTag("chat_summaries_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "S",
                        color = SuesaAccentWhite,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 17.sp
                    )
                }

                Spacer(modifier = Modifier.width(9.dp))

                Text(
                    text = "Suesa AI",
                    color = SuesaTextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    HeaderTabButton(
                        text = "＋ Yeni",
                        isActive = false,
                        onClick = onNewChat,
                        modifier = Modifier.testTag("new_chat_button")
                    )

                    HeaderTabButton(
                        text = if (isFloatingPanelOpen) "👁️ Panel Açık" else "🖥️ Panel",
                        isActive = isFloatingPanelOpen,
                        isPurpleHighlight = isFloatingPanelOpen,
                        onClick = onToggleFloatingPanel,
                        modifier = Modifier.testTag("header_panel_button")
                    )

                    HeaderTabButton(
                        text = "⚙️",
                        isActive = false,
                        onClick = onOpenSettings,
                        modifier = Modifier.testTag("settings_button")
                    )
                }
            }
            HorizontalDivider(color = Color(0xFF303030), thickness = 1.dp)
        }
    }
}

@Composable
private fun HeaderTabButton(
    text: String,
    isActive: Boolean,
    isPurpleHighlight: Boolean = false,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bgColor = when {
        isPurpleHighlight -> SuesaPurple
        isActive -> SuesaAccentWhite
        else -> Color(0xFF202020)
    }
    val contentColor = when {
        isPurpleHighlight -> SuesaAccentWhite
        isActive -> Color(0xFF111111)
        else -> Color(0xFFDDDDDD)
    }
    val borderColor = if (isPurpleHighlight) SuesaPurpleBorder else Color(0xFF444444)

    Box(
        modifier = modifier
            .heightIn(min = 38.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(bgColor)
            .border(1.dp, borderColor, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = contentColor,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun EmptyChatGreeting(
    onQuickPrompt: (String) -> Unit,
    onOpenPanelQuick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 36.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_suesa_avatar),
            contentDescription = "Suesa AI Avatar",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(84.dp)
                .clip(CircleShape)
                .border(2.dp, SuesaPurpleBorder, CircleShape)
        )

        Spacer(modifier = Modifier.height(14.dp))

        Text(
            text = "Suesa AI",
            color = Color(0xFFEEEEEE),
            fontSize = 28.sp,
            fontWeight = FontWeight.ExtraBold
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Merhaba! Ben Suesa. Nasıl yardımcı olabilirim?",
            color = SuesaTextSecondary,
            fontSize = 15.sp,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(22.dp))

        // Quick action chips
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            QuickSuggestionChip(
                label = "🖥️ Yüzen Paneli Aç (Ekranı Gör)",
                isHighlight = true,
                onClick = onOpenPanelQuick
            )
            QuickSuggestionChip(
                label = "👋 Selam Suesa, naber?",
                onClick = { onQuickPrompt("Selam Suesa, naber?") }
            )
            QuickSuggestionChip(
                label = "⛏️ @Suesa_S bot durumu",
                onClick = { onQuickPrompt("Minecraft'ta @Suesa_S botuyla neler yapabiliriz?") }
            )
        }
    }
}

@Composable
private fun QuickSuggestionChip(
    label: String,
    isHighlight: Boolean = false,
    onClick: () -> Unit
) {
    val bg = if (isHighlight) Color(0xFF241C2E) else Color(0xFF202020)
    val border = if (isHighlight) SuesaPurpleBorder else Color(0xFF3A3A3A)
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(bg)
            .border(1.dp, border, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 13.dp, vertical = 9.dp)
    ) {
        Text(
            text = label,
            color = if (isHighlight) Color(0xFFE9D5FF) else Color(0xFFDDDDDD),
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

private sealed interface MessageSegment {
    data class PlainText(val text: String) : MessageSegment
    data class CodeBlock(val language: String, val code: String) : MessageSegment
}

private fun parseMessageSegments(raw: String): List<MessageSegment> {
    val regex = Regex("```([^\\n]*)\\n?([\\s\\S]*?)```")
    val segments = mutableListOf<MessageSegment>()
    var lastIndex = 0
    for (match in regex.findAll(raw)) {
        if (match.range.first > lastIndex) {
            val textPart = raw.substring(lastIndex, match.range.first)
            if (textPart.isNotBlank()) {
                segments.add(MessageSegment.PlainText(textPart.trim('\n')))
            }
        }
        val lang = match.groupValues[1].trim().ifEmpty { "Kod" }
        val code = match.groupValues[2].trim('\n')
        segments.add(MessageSegment.CodeBlock(lang, code))
        lastIndex = match.range.last + 1
    }
    if (lastIndex < raw.length) {
        val tail = raw.substring(lastIndex)
        if (tail.isNotBlank()) {
            segments.add(MessageSegment.PlainText(tail.trim('\n')))
        }
    }
    if (segments.isEmpty() && raw.isNotBlank()) {
        segments.add(MessageSegment.PlainText(raw))
    }
    return segments
}

@Composable
fun MessageBubble(
    message: UiChatMessage,
    modifier: Modifier = Modifier
) {
    val isUser = message.sender == "user"
    val bubbleColor = if (isUser) SuesaBubbleUser else SuesaBubbleModel
    val segments = remember(message.text) { parseMessageSegments(message.text) }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 340.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(bubbleColor)
                .padding(horizontal = 14.dp, vertical = 11.dp)
        ) {
            segments.forEachIndexed { idx, segment ->
                when (segment) {
                    is MessageSegment.PlainText -> {
                        Text(
                            text = segment.text,
                            color = SuesaTextPrimary,
                            fontSize = 15.sp,
                            lineHeight = 22.sp
                        )
                    }
                    is MessageSegment.CodeBlock -> {
                        if (idx > 0) Spacer(modifier = Modifier.height(8.dp))
                        CodeBlockCard(language = segment.language, code = segment.code)
                        if (idx < segments.lastIndex) Spacer(modifier = Modifier.height(8.dp))
                    }
                }
            }

            // Runtime attachments (images & files)
            message.attachments.forEach { att ->
                Spacer(modifier = Modifier.height(8.dp))
                if (att.previewBitmap != null) {
                    Column(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF191919))
                            .padding(8.dp)
                    ) {
                        Image(
                            bitmap = att.previewBitmap.asImageBitmap(),
                            contentDescription = att.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 200.dp)
                                .clip(RoundedCornerShape(10.dp))
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${att.badgeEmoji} ${att.name}",
                            color = Color(0xFFCCCCCC),
                            fontSize = 12.sp
                        )
                    }
                } else {
                    AttachmentBadgeItem(badge = att.badgeEmoji, name = att.name)
                }
            }

            // Persisted badges (when restored from Room history)
            if (message.attachments.isEmpty() && message.persistedBadges.isNotEmpty()) {
                message.persistedBadges.forEach { (badge, name) ->
                    Spacer(modifier = Modifier.height(6.dp))
                    AttachmentBadgeItem(badge = badge, name = name)
                }
            }
        }
    }
}

@Composable
private fun AttachmentBadgeItem(badge: String, name: String) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF191919))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "$badge $name",
            color = Color(0xFFCCCCCC),
            fontSize = 13.sp
        )
    }
}

@Composable
private fun CodeBlockCard(language: String, code: String) {
    val clipboardManager = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }

    LaunchedEffect(copied) {
        if (copied) {
            delay(1200)
            copied = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(SuesaCodeBg)
            .border(1.dp, Color(0xFF3A3A3A), RoundedCornerShape(12.dp))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(36.dp)
                .background(SuesaCodeHeader)
                .padding(start = 12.dp, end = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = language,
                color = Color(0xFFAAAAAA),
                fontSize = 12.sp
            )

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF292929))
                    .border(1.dp, Color(0xFF444444), RoundedCornerShape(8.dp))
                    .clickable {
                        clipboardManager.setText(AnnotatedString(code))
                        copied = true
                    }
                    .padding(horizontal = 9.dp, vertical = 4.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (copied) Icons.Default.Check else Icons.Default.ContentCopy,
                        contentDescription = "Kodu kopyala",
                        tint = Color(0xFFEEEEEE),
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (copied) "Kopyalandı ✓" else "Kopyala",
                        color = Color(0xFFEEEEEE),
                        fontSize = 11.sp
                    )
                }
            }
        }

        HorizontalDivider(color = Color(0xFF303030), thickness = 1.dp)

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(12.dp)
        ) {
            Text(
                text = code,
                color = Color(0xFFF1F1F1),
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                lineHeight = 19.sp
            )
        }
    }
}

@Composable
fun BottomChatBar(
    statusText: String,
    selectedAttachments: List<SelectedAttachment>,
    inputText: String,
    isSending: Boolean,
    onInputTextChange: (String) -> Unit,
    onRemoveAttachment: (String) -> Unit,
    onOpenAttachmentMenu: () -> Unit,
    onSendMessage: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = SuesaSurface,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp)
        ) {
            HorizontalDivider(color = Color(0xFF303030), thickness = 1.dp)
            Spacer(modifier = Modifier.height(4.dp))

            // Status line
            Text(
                text = statusText,
                color = SuesaTextSecondary,
                fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )

            // Selected file chips strip
            AnimatedVisibility(visible = selectedAttachments.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 4.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    selectedAttachments.forEach { file ->
                        SelectedFileChip(
                            file = file,
                            onRemove = { onRemoveAttachment(file.id) }
                        )
                    }
                }
            }

            // Input row: [＋] [Textarea] [➤]
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                // ＋ Attach / Menu button
                IconButton(
                    onClick = onOpenAttachmentMenu,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(SuesaBubbleModel)
                        .border(1.dp, Color(0xFF444444), CircleShape)
                        .testTag("attach_menu_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Dosya ekle veya Paneli aç",
                        tint = Color(0xFFEEEEEE)
                    )
                }

                // Message Input
                OutlinedTextField(
                    value = inputText,
                    onValueChange = onInputTextChange,
                    placeholder = {
                        Text(
                            text = "Suesa'ya bir şey yaz...",
                            color = SuesaTextSecondary,
                            fontSize = 15.sp
                        )
                    },
                    maxLines = 4,
                    shape = RoundedCornerShape(17.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = SuesaBubbleModel,
                        unfocusedContainerColor = SuesaBubbleModel,
                        focusedBorderColor = Color(0xFF666666),
                        unfocusedBorderColor = Color(0xFF444444),
                        focusedTextColor = SuesaAccentWhite,
                        unfocusedTextColor = SuesaAccentWhite,
                        cursorColor = SuesaAccentWhite
                    ),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { onSendMessage() }),
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp, max = 140.dp)
                        .testTag("chat_input_field")
                )

                // ➤ Send button
                val canSend = (inputText.isNotBlank() || selectedAttachments.isNotEmpty()) && !isSending
                IconButton(
                    onClick = onSendMessage,
                    enabled = canSend,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(if (canSend) SuesaAccentWhite else Color(0xFF555555))
                        .testTag("send_message_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Gönder",
                        tint = Color(0xFF111111),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun SelectedFileChip(
    file: SelectedAttachment,
    onRemove: () -> Unit
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF252525))
            .border(1.dp, Color(0xFF3A3A3A), RoundedCornerShape(12.dp))
            .padding(horizontal = 9.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        if (file.previewBitmap != null) {
            Image(
                bitmap = file.previewBitmap.asImageBitmap(),
                contentDescription = file.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(30.dp)
                    .clip(RoundedCornerShape(7.dp))
            )
        }

        val displayName = if (file.name.length > 22) {
            file.name.take(19) + "..."
        } else {
            file.name
        }

        Text(
            text = "${file.badgeEmoji} $displayName",
            color = Color(0xFFDDDDDD),
            fontSize = 12.sp
        )

        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(Color(0xFF3A3A3A))
                .clickable(onClick = onRemove),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Dosyayı kaldır",
                tint = Color(0xFFDDDDDD),
                modifier = Modifier.size(14.dp)
            )
        }
    }
}
