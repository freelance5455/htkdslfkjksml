package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Alien
import com.example.model.AlienRoster
import com.example.ui.theme.*

@Composable
fun AlienSelectorBar(
    selectedAlien: Alien,
    isUltimateMode: Boolean,
    onSelectAlien: (Alien) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "DNA CODEX MATRIX",
                color = if (isUltimateMode) UltimateRedBright else OmnitrixGreenBright,
                fontSize = 11.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.sp
            )

            Text(
                text = "PWR: ${if (isUltimateMode) selectedAlien.powerLevel + 2500 else selectedAlien.powerLevel} GW",
                color = AlienCyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }

        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(AlienRoster.aliens, key = { it.id }) { alien ->
                val isSelected = alien.id == selectedAlien.id
                val scale by animateFloatAsState(
                    targetValue = if (isSelected) 1.05f else 0.95f,
                    animationSpec = spring(),
                    label = "alienScale"
                )

                val activeColor = if (isUltimateMode) alien.ultimateColor else alien.themeColor
                val borderColor by animateColorAsState(
                    targetValue = if (isSelected) {
                        if (isUltimateMode) UltimateRedBright else OmnitrixGreenBright
                    } else {
                        GalvanBorder
                    },
                    label = "alienBorder"
                )

                Box(
                    modifier = Modifier
                        .scale(scale)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (isSelected) {
                                Brush.verticalGradient(
                                    listOf(GalvanSurfaceLight, GalvanDark)
                                )
                            } else {
                                Brush.verticalGradient(
                                    listOf(GalvanDark, GalvanBlack)
                                )
                            }
                        )
                        .border(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = borderColor,
                            shape = RoundedCornerShape(12.dp)
                        )
                        .clickable { onSelectAlien(alien) }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("alien_chip_${alien.id}")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Alien Mini Core Dot
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(RoundedCornerShape(50))
                                .background(activeColor)
                        )

                        Column {
                            Text(
                                text = if (isUltimateMode) alien.ultimateName else alien.name,
                                color = if (isSelected) WhitePure else WhiteMuted,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = alien.species,
                                color = TextMuted,
                                fontSize = 9.sp,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }
    }
}
