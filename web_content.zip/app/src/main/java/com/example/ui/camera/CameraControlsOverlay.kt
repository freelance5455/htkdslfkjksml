package com.example.ui.camera

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Colorize
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.FlipCameraAndroid
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.model.DetectionRegion
import com.example.ui.theme.ChromaGreen
import com.example.ui.theme.ChromaPrimary
import com.example.ui.theme.ChromaRed
import com.example.ui.theme.ChromaYellow
import com.example.ui.viewmodel.CameraViewModel
import java.io.File

@Composable
fun CameraControlsOverlay(
    viewModel: CameraViewModel,
    modifier: Modifier = Modifier
) {
    val isAutoCaptureActive by viewModel.isAutoCaptureActive.collectAsState()
    val detectionState by viewModel.detectionState.collectAsState()
    val triggers by viewModel.triggers.collectAsState()
    val detectionRegion by viewModel.detectionRegion.collectAsState()
    val isTorchOn by viewModel.isTorchOn.collectAsState()
    val photos by viewModel.photos.collectAsState()
    val captureCounter by viewModel.captureCounter.collectAsState()
    val isEyeDropperActive by viewModel.isEyeDropperActive.collectAsState()

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
    ) {
        // Top Gradient & Header Controls
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.82f),
                            Color.Black.copy(alpha = 0.4f),
                            Color.Transparent
                        )
                    )
                )
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Top Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // App Title & Continuous status badge
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (isAutoCaptureActive) ChromaGreen else Color.Gray)
                    )
                    Text(
                        text = "ChromaSnap",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Color.White
                    )
                    if (isAutoCaptureActive) {
                        Surface(
                            color = ChromaGreen.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, ChromaGreen)
                        ) {
                            Text(
                                text = "تلقائي ON",
                                color = ChromaGreen,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                // Quick Hardware Icons
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Eyedropper Tool
                    IconButton(
                        onClick = { viewModel.toggleEyeDropper() },
                        modifier = Modifier
                            .size(40.dp)
                            .background(
                                if (isEyeDropperActive) ChromaPrimary else Color.White.copy(alpha = 0.15f),
                                CircleShape
                            )
                            .testTag("eyedropper_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Colorize,
                            contentDescription = "Color Eyedropper",
                            tint = if (isEyeDropperActive) Color.Black else Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Torch
                    IconButton(
                        onClick = { viewModel.toggleTorch() },
                        modifier = Modifier
                            .size(40.dp)
                            .background(
                                if (isTorchOn) ChromaYellow else Color.White.copy(alpha = 0.15f),
                                CircleShape
                            )
                            .testTag("torch_button")
                    ) {
                        Icon(
                            imageVector = if (isTorchOn) Icons.Default.FlashOn else Icons.Default.FlashOff,
                            contentDescription = "Toggle Torch",
                            tint = if (isTorchOn) Color.Black else Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Switch Lens (Front/Back)
                    IconButton(
                        onClick = { viewModel.toggleLensFacing() },
                        modifier = Modifier
                            .size(40.dp)
                            .background(Color.White.copy(alpha = 0.15f), CircleShape)
                            .testTag("switch_camera_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.FlipCameraAndroid,
                            contentDescription = "Switch Camera",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Region Mode (Center vs Full)
                    IconButton(
                        onClick = { viewModel.toggleDetectionRegion() },
                        modifier = Modifier
                            .size(40.dp)
                            .background(Color.White.copy(alpha = 0.15f), CircleShape)
                            .testTag("region_toggle_button")
                    ) {
                        Icon(
                            imageVector = if (detectionRegion == DetectionRegion.CENTER_RETICLE) {
                                Icons.Default.CenterFocusStrong
                            } else {
                                Icons.Default.CropFree
                            },
                            contentDescription = "Detection Region",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Settings / Trigger Config
                    IconButton(
                        onClick = { viewModel.openSettings() },
                        modifier = Modifier
                            .size(40.dp)
                            .background(Color.White.copy(alpha = 0.15f), CircleShape)
                            .testTag("settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "Settings",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Quick Color Trigger Chips (Horizontal Scrollable)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "الألوان المستهدفة:",
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )

                triggers.forEach { trigger ->
                    val isEnabled = trigger.isEnabled
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { viewModel.toggleTrigger(trigger.id) }
                            .testTag("trigger_chip_${trigger.type.name}"),
                        color = if (isEnabled) trigger.color.copy(alpha = 0.28f) else Color.White.copy(alpha = 0.1f),
                        border = androidx.compose.foundation.BorderStroke(
                            width = if (isEnabled) 1.5.dp else 1.dp,
                            color = if (isEnabled) trigger.color else Color.White.copy(alpha = 0.2f)
                        ),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(trigger.color)
                                    .border(1.dp, Color.White.copy(alpha = 0.6f), CircleShape)
                            )
                            Text(
                                text = trigger.nameAr,
                                color = if (isEnabled) Color.White else Color.White.copy(alpha = 0.5f),
                                fontSize = 12.sp,
                                fontWeight = if (isEnabled) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }
        }

        // Floating Real-Time Detection Pill Banner (Center-Top)
        AnimatedVisibility(
            visible = detectionState.isTriggered || isAutoCaptureActive,
            enter = fadeIn() + slideInVertically(initialOffsetY = { -it }),
            exit = fadeOut() + slideOutVertically(targetOffsetY = { -it }),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 110.dp)
        ) {
            val isHit = detectionState.isTriggered
            val activeTrigger = detectionState.activeTrigger

            Surface(
                color = Color.Black.copy(alpha = 0.75f),
                shape = RoundedCornerShape(24.dp),
                border = androidx.compose.foundation.BorderStroke(
                    width = 1.5.dp,
                    color = if (isHit && activeTrigger != null) activeTrigger.color else Color.White.copy(alpha = 0.3f)
                ),
                shadowElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (isHit && activeTrigger != null) {
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .clip(CircleShape)
                                .background(activeTrigger.color)
                        )
                        Text(
                            text = "تم رصد ${activeTrigger.nameAr} (${detectionState.confidencePercent.toInt()}%)",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        if (isAutoCaptureActive) {
                            Text(
                                text = "• جاري التصوير...",
                                color = ChromaGreen,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    } else if (isAutoCaptureActive) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(ChromaGreen)
                        )
                        Text(
                            text = "في انتظار ظهور أحد الألوان (أحمر، أخضر، أصفر...)",
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Bottom Controls Container
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.65f),
                            Color.Black.copy(alpha = 0.92f)
                        )
                    )
                )
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Auto Capture Switch Banner with Continuous status
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 14.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = { viewModel.toggleAutoCapture() },
                    modifier = Modifier
                        .fillMaxWidth(0.92f)
                        .height(48.dp)
                        .testTag("auto_capture_toggle_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isAutoCaptureActive) ChromaRed else ChromaGreen,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = if (isAutoCaptureActive) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isAutoCaptureActive) "إيقاف التصوير" else "بدء التصوير التلقائي",
                            modifier = Modifier.size(22.dp)
                        )
                        Text(
                            text = if (isAutoCaptureActive) {
                                "إيقاف التصوير التلقائي المستمر (تم التقاط $captureCounter)"
                            } else {
                                "تشغيل التصوير التلقائي المستمر"
                            },
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }

            // Bottom Shutter & Gallery Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                // Gallery Thumbnail Button
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.White.copy(alpha = 0.15f))
                        .border(1.5.dp, Color.White.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                        .clickable { viewModel.openGallery() }
                        .testTag("gallery_thumbnail_button"),
                    contentAlignment = Alignment.Center
                ) {
                    val latestPhoto = photos.firstOrNull()
                    if (latestPhoto != null) {
                        AsyncImage(
                            model = ImageRequest.Builder(LocalContext.current)
                                .data(File(latestPhoto.filePath))
                                .crossfade(true)
                                .build(),
                            contentDescription = "معرض الصور",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.PhotoLibrary,
                            contentDescription = "معرض الصور",
                            tint = Color.White,
                            modifier = Modifier.size(26.dp)
                        )
                    }

                    // Count Badge
                    if (photos.isNotEmpty()) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(2.dp)
                                .size(20.dp)
                                .clip(CircleShape)
                                .background(ChromaPrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (photos.size > 99) "99+" else "${photos.size}",
                                color = Color.Black,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Main Circular Shutter Button
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .scale(if (isAutoCaptureActive) pulseScale else 1f)
                        .clip(CircleShape)
                        .border(
                            width = 4.dp,
                            color = if (isAutoCaptureActive) ChromaGreen else Color.White,
                            shape = CircleShape
                        )
                        .clickable {
                            viewModel.takePhoto(
                                triggerName = "Manual Shutter",
                                triggerColorHex = "#FFFFFF",
                                confidence = 100f,
                                isAuto = false
                            )
                        }
                        .padding(6.dp)
                        .testTag("shutter_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                            .background(
                                if (isAutoCaptureActive) ChromaGreen else Color.White
                            )
                    )
                }

                // Quick Color Settings / Picker
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.15f))
                        .border(1.5.dp, Color.White.copy(alpha = 0.35f), CircleShape)
                        .clickable { viewModel.openSettings() }
                        .testTag("color_picker_quick_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.ColorLens,
                        contentDescription = "Color Triggers",
                        tint = ChromaYellow,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }
        }
    }
}
