package com.example.ui.screens

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.MainUiState

@Composable
fun VoiceChannelsTab(
    state: MainUiState,
    onJoinChannel: (String) -> Unit,
    onLeaveChannel: () -> Unit,
    onToggleMute: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    text = "CANALES DE VOZ PEER-TO-PEER",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFA0AEC0)
                )
                Text(
                    text = "Audio directo estilo Discord. Toca un canal para unirte a la llamada.",
                    fontSize = 12.sp,
                    color = Color(0xFF718096)
                )
                Spacer(modifier = Modifier.height(4.dp))
            }

            items(state.voiceChannels) { channel ->
                val isJoined = state.currentVoiceChannelId == channel.id
                val usersInChannel = state.voiceUsers.filter { it.channelId == channel.id }

                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isJoined) Color(0xFF1B3324) else Color(0xFF1E232B)
                    ),
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        width = if (isJoined) 2.dp else 1.dp,
                        color = if (isJoined) Color(0xFF2ECC71) else Color(0xFF2C3442)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onJoinChannel(channel.id) }
                        .testTag("voice_channel_${channel.id}")
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = channel.icon, fontSize = 20.sp)
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = channel.name,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isJoined) Color(0xFF2ECC71) else Color.White
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0x33000000))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "${usersInChannel.size} conectados",
                                    fontSize = 11.sp,
                                    color = Color(0xFFA0AEC0)
                                )
                            }
                        }

                        // Lista de jugadores en el canal
                        if (usersInChannel.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Column(
                                verticalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(start = 12.dp)
                            ) {
                                usersInChannel.forEach { user ->
                                    VoiceUserItem(user = user)
                                }
                            }
                        }
                    }
                }
            }

            // Espaciador para no tapar con el dock flotante
            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }

        // BARRA DOCK FLOTANTE DE LLAMADA ACTIVA
        if (state.currentVoiceChannelId != null) {
            val currentChan = state.voiceChannels.find { it.id == state.currentVoiceChannelId }
            VoiceDockBar(
                channelName = currentChan?.name ?: "En Voz",
                isMuted = state.isMuted,
                onToggleMute = onToggleMute,
                onLeave = onLeaveChannel,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp)
            )
        }
    }
}

@Composable
private fun VoiceUserItem(user: com.example.data.model.VoiceUser) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(600),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0x40000000))
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(contentAlignment = Alignment.Center) {
                if (user.isSpeaking) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .scale(pulseScale)
                            .clip(CircleShape)
                            .background(Color(0x552ECC71))
                    )
                }

                AsyncImage(
                    model = "https://minotar.net/avatar/${user.gamerTag}/64.png",
                    contentDescription = user.gamerTag,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(26.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .border(
                            width = if (user.isSpeaking) 2.dp else 1.dp,
                            color = if (user.isSpeaking) Color(0xFF2ECC71) else Color(0x33FFFFFF),
                            shape = RoundedCornerShape(4.dp)
                        )
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Text(
                text = user.gamerTag,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            if (user.isMuted) {
                Icon(
                    Icons.Default.MicOff,
                    contentDescription = "Muteado",
                    tint = Color(0xFFE74C3C),
                    modifier = Modifier.size(16.dp)
                )
            } else if (user.isSpeaking) {
                Icon(
                    Icons.Default.VolumeUp,
                    contentDescription = "Hablando",
                    tint = Color(0xFF2ECC71),
                    modifier = Modifier.size(16.dp)
                )
            } else {
                Icon(
                    Icons.Default.Mic,
                    contentDescription = "Micrófono listo",
                    tint = Color(0xFF718096),
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
private fun VoiceDockBar(
    channelName: String,
    isMuted: Boolean,
    onToggleMute: () -> Unit,
    onLeave: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF14181F)),
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(2.dp, Color(0xFF2ECC71)),
        elevation = CardDefaults.cardElevation(10.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("voice_dock_bar")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "CANAL DE VOZ ACTIVO",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF2ECC71)
                )
                Text(
                    text = channelName,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                // Botón Mute / Unmute
                FloatingActionButton(
                    onClick = onToggleMute,
                    containerColor = if (isMuted) Color(0xFFE74C3C) else Color(0xFF2D3748),
                    contentColor = Color.White,
                    shape = CircleShape,
                    modifier = Modifier.size(44.dp).testTag("btn_toggle_mute")
                ) {
                    Icon(
                        imageVector = if (isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = "Mute"
                    )
                }

                // Botón Desconectar Llamada
                FloatingActionButton(
                    onClick = onLeave,
                    containerColor = Color(0xFFC0392B),
                    contentColor = Color.White,
                    shape = CircleShape,
                    modifier = Modifier.size(44.dp).testTag("btn_leave_voice")
                ) {
                    Icon(
                        imageVector = Icons.Default.CallEnd,
                        contentDescription = "Desconectar"
                    )
                }
            }
        }
    }
}
