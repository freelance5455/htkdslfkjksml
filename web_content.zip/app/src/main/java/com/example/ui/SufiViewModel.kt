package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.SufiSoundManager
import com.example.data.SufiContentRepository
import com.example.data.SufiEntry
import com.example.data.SufiLanguage
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SufiUiState(
    val currentEntry: SufiEntry? = null,
    val isThinking: Boolean = false,
    val isFirstLaunch: Boolean = true,
    val showSavedSheet: Boolean = false,
    val showShareDialog: Boolean = false,
    val isCandlelitMode: Boolean = false,
    val peaceMomentsCount: Int = 0
)

class SufiViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = SufiContentRepository(application)
    val soundManager = SufiSoundManager(application)
    private val prefs = application.getSharedPreferences("sufi_user_prefs", Context.MODE_PRIVATE)

    private val _uiState = MutableStateFlow(
        SufiUiState(
            isCandlelitMode = prefs.getBoolean("is_candlelit_mode", false),
            peaceMomentsCount = prefs.getInt("peace_moments_count", 0)
        )
    )
    val uiState: StateFlow<SufiUiState> = _uiState.asStateFlow()

    val savedIds: StateFlow<Set<String>> = repository.savedIds
    val currentLanguage: StateFlow<SufiLanguage> = repository.currentLanguage

    val savedEntries: StateFlow<List<SufiEntry>> = repository.savedIds
        .map { repository.getSavedEntries() }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun onSufiSaysTapped() {
        if (_uiState.value.isThinking) return

        // 1. Play magical sparkling twinkling sound on button tap
        soundManager.playTwinkle()

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                isThinking = true
            )

            // 2. Play reed pen gliding sound as calligraphy writing starts
            delay(150)
            soundManager.playPenGlide()

            // Contemplative Qalam reed pen calligraphy writing duration (1.2s)
            delay(1050)

            val nextEntry = repository.getRandomEntry()
            val newCount = _uiState.value.peaceMomentsCount + 1
            prefs.edit().putInt("peace_moments_count", newCount).apply()

            _uiState.value = _uiState.value.copy(
                currentEntry = nextEntry,
                isThinking = false,
                isFirstLaunch = false,
                peaceMomentsCount = newCount
            )

            // 3. Play peaceful wisdom reveal chime
            soundManager.playWisdomChime()
        }
    }

    fun toggleCandlelitMode() {
        soundManager.playSoftClick()
        val newMode = !_uiState.value.isCandlelitMode
        prefs.edit().putBoolean("is_candlelit_mode", newMode).apply()
        _uiState.value = _uiState.value.copy(isCandlelitMode = newMode)
    }

    fun onTasbeehTapped() {
        soundManager.playTasbeehBead()
    }

    fun setShareDialogVisible(visible: Boolean) {
        soundManager.playSoftClick()
        _uiState.value = _uiState.value.copy(showShareDialog = visible)
    }

    fun selectEntry(entry: SufiEntry) {
        soundManager.playSoftClick()
        _uiState.value = _uiState.value.copy(
            currentEntry = entry,
            isFirstLaunch = false,
            showSavedSheet = false
        )
    }

    fun toggleSaveCurrent() {
        val entry = _uiState.value.currentEntry ?: return
        soundManager.playSoftClick()
        repository.toggleSave(entry.id)
    }

    fun toggleSave(id: String) {
        soundManager.playSoftClick()
        repository.toggleSave(id)
    }

    fun setLanguage(language: SufiLanguage) {
        soundManager.playSoftClick()
        repository.setLanguage(language)
    }

    fun setSavedSheetVisible(visible: Boolean) {
        soundManager.playSoftClick()
        _uiState.value = _uiState.value.copy(showSavedSheet = visible)
    }

    fun getSavedList(): List<SufiEntry> {
        return repository.getSavedEntries()
    }

    override fun onCleared() {
        super.onCleared()
        soundManager.release()
    }
}
