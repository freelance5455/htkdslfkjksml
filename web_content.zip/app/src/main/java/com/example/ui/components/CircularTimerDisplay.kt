package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.KawaiiSticker
import com.example.data.model.Subject
import com.example.ui.PomodoroMode
import com.example.ui.theme.AestheticBlack
import com.example.ui.theme.BorderGrey
import com.example.ui.theme.CardGrey
import com.example.ui.theme.DeepPink
import com.example.ui.theme.KawaiiPink
import com.example.ui.theme.MutedGrey
import com.example.ui.theme.PastelPinkBg
import com.example.ui.theme.PastelPinkContainer
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoseTint
import com.example.ui.theme.TextGrey

@Composable
fun CircularTimerDisplay(
    mode: PomodoroMode,
    isRunning: Boolean,
    totalSeconds: Int,
    secondsRemaining: Int,
    selectedSubject: Subject?,
    completedCycles: Int,
    activeSticker: KawaiiSticker?,
    onSubjectClick: () -> Unit,
    onStickerClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val progress = if (totalSeconds > 0) {
        (secondsRemaining.toFloat() / totalSeconds.toFloat()).coerceIn(0f, 1f)
    } else 0f

    val minutes = secondsRemaining / 60
    val seconds = secondsRemaining % 60
    val timeFormatted = "%02d:%02d".format(minutes, seconds)

    // Cohesive aesthetic colors: soft kawaii pink, deep pink, soft grey, charcoal black
    val activeRingBrush = when (mode) {
        PomodoroMode.FOCUS -> Brush.sweepGradient(listOf(KawaiiPink, DeepPink, RoseTint, KawaiiPink))
        PomodoroMode.SHORT_BREAK -> Brush.sweepGradient(listOf(RoseTint, KawaiiPink, RoseTint))
        PomodoroMode.LONG_BREAK -> Brush.sweepGradient(listOf(KawaiiPink, DeepPink, KawaiiPink))
    }

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isRunning) 1.025f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Box(
        modifier = modifier
            .size(285.dp)
            .testTag("circular_timer_display"),
        contentAlignment = Alignment.Center
    ) {
        // Soft white card disc behind the timer
        Surface(
            shape = CircleShape,
            color = PureWhite,
            shadowElevation = 6.dp,
            modifier = Modifier.size(270.dp)
        ) {}

        // Canvas for timer track & progress arc
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .scale(pulseScale)
        ) {
            val strokeWidth = 12.dp.toPx()
            val diameter = size.minDimension - strokeWidth - 16.dp.toPx()
            val arcSize = Size(diameter, diameter)
            val topLeft = Offset(
                (size.width - diameter) / 2,
                (size.height - diameter) / 2
            )

            // Background subtle track
            drawArc(
                color = CardGrey,
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )

            // Progress stroke
            if (progress > 0f) {
                drawArc(
                    brush = activeRingBrush,
                    startAngle = -90f,
                    sweepAngle = 360f * progress,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                )
            }
        }

        // Inner Content
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(20.dp)
        ) {
            // Cute active companion sticker at top (clickable to open sticker board)
            if (activeSticker != null) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = PastelPinkBg,
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, PureWhite),
                    shadowElevation = 2.dp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { onStickerClick() }
                        .padding(bottom = 4.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(text = activeSticker.emoji, fontSize = 14.sp)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = activeSticker.name,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            ),
                            color = AestheticBlack
                        )
                    }
                }
            }

            // Big Timer Text
            Text(
                text = timeFormatted,
                style = MaterialTheme.typography.displayLarge.copy(
                    fontSize = 54.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = (-1).sp
                ),
                color = AestheticBlack,
                modifier = Modifier.testTag("timer_countdown_text")
            )

            // Subject selector sticker pill
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = PureWhite,
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderGrey),
                shadowElevation = 2.dp,
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .clickable { onSubjectClick() }
                    .testTag("timer_subject_pill")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = selectedSubject?.icon ?: "🐰",
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = selectedSubject?.name ?: "Select Subject",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                        color = AestheticBlack,
                        maxLines = 1
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Default.ArrowDropDown,
                        contentDescription = "Switch subject",
                        tint = TextGrey,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Pomodoro cycles progress dots
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val cycleInGroup = completedCycles % 4
                for (i in 0 until 4) {
                    val isDone = i < cycleInGroup
                    val isCurrent = i == cycleInGroup && isRunning && mode == PomodoroMode.FOCUS
                    Box(
                        modifier = Modifier
                            .size(if (isCurrent) 10.dp else 8.dp)
                            .clip(CircleShape)
                            .background(
                                when {
                                    isDone -> DeepPink
                                    isCurrent -> KawaiiPink
                                    else -> CardGrey
                                }
                            )
                            .border(
                                1.dp,
                                if (isDone || isCurrent) DeepPink.copy(alpha = 0.3f) else BorderGrey,
                                CircleShape
                            )
                    )
                }
            }
        }
    }
}
