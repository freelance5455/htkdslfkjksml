package com.example.ui.utils

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

object IntentUtils {

    fun launchUpiPayment(
        context: Context,
        upiId: String,
        payeeName: String,
        amount: String,
        clientName: String,
        orderId: String? = null
    ): Boolean {
        val cleanAmount = amount.replace(Regex("[^0-9.]"), "").trim()
        if (cleanAmount.isBlank() || cleanAmount.toDoubleOrNull() == null || cleanAmount.toDouble() <= 0) {
            Toast.makeText(context, "Please enter a valid amount to pay via UPI", Toast.LENGTH_SHORT).show()
            return false
        }

        val noteText = if (!orderId.isNullOrBlank()) {
            "Payment for Order $orderId by ${clientName.ifBlank { "Client" }}"
        } else {
            "Payment by ${clientName.ifBlank { "Client" }} to Edito X"
        }

        val encodedNote = try {
            URLEncoder.encode(noteText, StandardCharsets.UTF_8.toString())
        } catch (_: Exception) {
            "Order Payment"
        }

        val encodedPayee = try {
            URLEncoder.encode(payeeName, StandardCharsets.UTF_8.toString())
        } catch (_: Exception) {
            "EditoXAIStudio"
        }

        val upiUriString = "upi://pay?pa=$upiId&pn=$encodedPayee&am=$cleanAmount&cu=INR&tn=$encodedNote"
        val uri = Uri.parse(upiUriString)

        val upiIntent = Intent(Intent.ACTION_VIEW, uri)
        val chooser = Intent.createChooser(upiIntent, "Pay via UPI App (GPay, PhonePe, Paytm)")

        return try {
            context.startActivity(chooser)
            true
        } catch (e: Exception) {
            Toast.makeText(
                context,
                "No UPI application found. UPI ID: $upiId copied to clipboard!",
                Toast.LENGTH_LONG
            ).show()
            copyToClipboard(context, "UPI ID", upiId)
            false
        }
    }

    fun openDialer(context: Context, phoneNumber: String) {
        if (phoneNumber.isBlank()) return
        try {
            val cleanPhone = phoneNumber.replace(Regex("[^0-9+]"), "")
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$cleanPhone"))
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Cannot open dialer: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    fun openWhatsApp(context: Context, phoneNumber: String, message: String = "") {
        if (phoneNumber.isBlank()) return
        try {
            var cleanPhone = phoneNumber.replace(Regex("[^0-9]"), "")
            if (cleanPhone.length == 10) {
                cleanPhone = "91$cleanPhone"
            }
            val encodedMessage = URLEncoder.encode(message, StandardCharsets.UTF_8.toString())
            val url = if (encodedMessage.isNotBlank()) {
                "https://api.whatsapp.com/send?phone=$cleanPhone&text=$encodedMessage"
            } else {
                "https://api.whatsapp.com/send?phone=$cleanPhone"
            }
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Cannot open WhatsApp: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    fun openBrowserLink(context: Context, rawUrl: String) {
        if (rawUrl.isBlank()) return
        try {
            var url = rawUrl.trim()
            if (!url.startsWith("http://") && !url.startsWith("https://")) {
                url = "https://$url"
            }
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Cannot open link: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    fun shareText(context: Context, text: String, title: String = "Share Order Details") {
        try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
            }
            context.startActivity(Intent.createChooser(intent, title))
        } catch (e: Exception) {
            Toast.makeText(context, "Cannot share: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    fun copyToClipboard(context: Context, label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "$label copied to clipboard!", Toast.LENGTH_SHORT).show()
    }
}
