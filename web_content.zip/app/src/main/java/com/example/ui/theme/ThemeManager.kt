package com.example.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

enum class AppColorTheme(
    val id: String,
    val displayName: String,
    val accentColor: Color,
    val secondaryColor: Color,
    val description: String
) {
    NEON_CYAN(
        id = "CYBER_NEON",
        displayName = "Sky Blue",
        accentColor = Color(0xFF0284C7),
        secondaryColor = Color(0xFF0EA5E9),
        description = "Crisp sky blue with modern oceanic accents"
    ),
    COSMIC_INDIGO(
        id = "COSMIC_INDIGO",
        displayName = "Cosmic Indigo",
        accentColor = Color(0xFF4F46E5),
        secondaryColor = Color(0xFF6366F1),
        description = "Deep contemporary indigo with refined purple tones"
    ),
    EMERALD_MATRIX(
        id = "EMERALD_MATRIX",
        displayName = "Emerald Mint",
        accentColor = Color(0xFF059669),
        secondaryColor = Color(0xFF10B981),
        description = "Clean modern emerald with fresh mint luminescence"
    ),
    SUNSET_AMBER(
        id = "SUNSET_AMBER",
        displayName = "Sunset Amber",
        accentColor = Color(0xFFD97706),
        secondaryColor = Color(0xFFF59E0B),
        description = "Warm radiant amber and golden honey glow"
    ),
    AURORA_VIOLET(
        id = "AURORA_VIOLET",
        displayName = "Aurora Violet",
        accentColor = Color(0xFF7C3AED),
        secondaryColor = Color(0xFFA855F7),
        description = "Striking royal violet with lilac accents"
    ),
    RUBY_CRIMSON(
        id = "RUBY_CRIMSON",
        displayName = "Ruby Rose",
        accentColor = Color(0xFFE11D48),
        secondaryColor = Color(0xFFF43F5E),
        description = "Vibrant berry rose with elegant coral warmth"
    );

    fun toColorScheme(isDarkMode: Boolean = false): ColorScheme {
        return if (isDarkMode) {
            when (this) {
                NEON_CYAN -> darkColorScheme(
                    primary = Color(0xFF38BDF8),
                    onPrimary = Color(0xFF082F49),
                    primaryContainer = Color(0xFF0C4A6E),
                    onPrimaryContainer = Color(0xFFBAE6FD),
                    secondary = Color(0xFF00F2FE),
                    onSecondary = Color(0xFF041E28),
                    secondaryContainer = Color(0xFF004D5A),
                    onSecondaryContainer = Color(0xFF8CF3FF),
                    tertiary = Color(0xFF2DD4BF),
                    onTertiary = Color(0xFF042F2E),
                    background = Color(0xFF0B0F17),
                    onBackground = Color(0xFFF8FAFC),
                    surface = Color(0xFF131823),
                    onSurface = Color(0xFFF8FAFC),
                    surfaceVariant = Color(0xFF1C2436),
                    onSurfaceVariant = Color(0xFF94A3B8),
                    outline = Color(0xFF29354D),
                    outlineVariant = Color(0xFF192131)
                )
                COSMIC_INDIGO -> darkColorScheme(
                    primary = Color(0xFF818CF8),
                    onPrimary = Color(0xFF151845),
                    primaryContainer = Color(0xFF272C75),
                    onPrimaryContainer = Color(0xFFE0E7FF),
                    secondary = Color(0xFF6366F1),
                    onSecondary = Color(0xFF0E1236),
                    secondaryContainer = Color(0xFF3730A3),
                    onSecondaryContainer = Color(0xFFC7D2FE),
                    tertiary = Color(0xFFA5B4FC),
                    onTertiary = Color(0xFF10133A),
                    background = Color(0xFF090A13),
                    onBackground = Color(0xFFF8FAFC),
                    surface = Color(0xFF121422),
                    onSurface = Color(0xFFF8FAFC),
                    surfaceVariant = Color(0xFF1B1E34),
                    onSurfaceVariant = Color(0xFF9CA3AF),
                    outline = Color(0xFF2D3254),
                    outlineVariant = Color(0xFF1A1D33)
                )
                EMERALD_MATRIX -> darkColorScheme(
                    primary = Color(0xFF34D399),
                    onPrimary = Color(0xFF02261A),
                    primaryContainer = Color(0xFF064E3B),
                    onPrimaryContainer = Color(0xFFA7F3D0),
                    secondary = Color(0xFF10B981),
                    onSecondary = Color(0xFF02261A),
                    secondaryContainer = Color(0xFF065F46),
                    onSecondaryContainer = Color(0xFFD1FAE5),
                    tertiary = Color(0xFF6EE7B7),
                    onTertiary = Color(0xFF022115),
                    background = Color(0xFF070E0A),
                    onBackground = Color(0xFFF0FDF4),
                    surface = Color(0xFF0E1A14),
                    onSurface = Color(0xFFF0FDF4),
                    surfaceVariant = Color(0xFF162A20),
                    onSurfaceVariant = Color(0xFF86A596),
                    outline = Color(0xFF234433),
                    outlineVariant = Color(0xFF152A20)
                )
                SUNSET_AMBER -> darkColorScheme(
                    primary = Color(0xFFFBBF24),
                    onPrimary = Color(0xFF2E1802),
                    primaryContainer = Color(0xFF5C3305),
                    onPrimaryContainer = Color(0xFFFDE68A),
                    secondary = Color(0xFFFB923C),
                    onSecondary = Color(0xFF3B1504),
                    secondaryContainer = Color(0xFF6E2808),
                    onSecondaryContainer = Color(0xFFFFEDD5),
                    tertiary = Color(0xFFF59E0B),
                    onTertiary = Color(0xFF332002),
                    background = Color(0xFF0E0B07),
                    onBackground = Color(0xFFFAF6F0),
                    surface = Color(0xFF18130D),
                    onSurface = Color(0xFFFAF6F0),
                    surfaceVariant = Color(0xFF261E14),
                    onSurfaceVariant = Color(0xFFA39A8E),
                    outline = Color(0xFF3D3021),
                    outlineVariant = Color(0xFF261E15)
                )
                AURORA_VIOLET -> darkColorScheme(
                    primary = Color(0xFFC084FC),
                    onPrimary = Color(0xFF280B44),
                    primaryContainer = Color(0xFF4A1878),
                    onPrimaryContainer = Color(0xFFF3E8FF),
                    secondary = Color(0xFFA855F7),
                    onSecondary = Color(0xFF23083B),
                    secondaryContainer = Color(0xFF581C87),
                    onSecondaryContainer = Color(0xFFE9D5FF),
                    tertiary = Color(0xFFE879F9),
                    onTertiary = Color(0xFF38083F),
                    background = Color(0xFF0C0914),
                    onBackground = Color(0xFFF8F5FC),
                    surface = Color(0xFF161122),
                    onSurface = Color(0xFFF8F5FC),
                    surfaceVariant = Color(0xFF221A35),
                    onSurfaceVariant = Color(0xFFA197B3),
                    outline = Color(0xFF372A54),
                    outlineVariant = Color(0xFF221A35)
                )
                RUBY_CRIMSON -> darkColorScheme(
                    primary = Color(0xFFFB7185),
                    onPrimary = Color(0xFF33040F),
                    primaryContainer = Color(0xFF66091E),
                    onPrimaryContainer = Color(0xFFFFE4E6),
                    secondary = Color(0xFFF43F5E),
                    onSecondary = Color(0xFF3E0814),
                    secondaryContainer = Color(0xFF881337),
                    onSecondaryContainer = Color(0xFFFECDD3),
                    tertiary = Color(0xFFFDA4AF),
                    onTertiary = Color(0xFF28020A),
                    background = Color(0xFF0F070A),
                    onBackground = Color(0xFFFFF1F2),
                    surface = Color(0xFF1A0E13),
                    onSurface = Color(0xFFFFF1F2),
                    surfaceVariant = Color(0xFF28151D),
                    onSurfaceVariant = Color(0xFFA39297),
                    outline = Color(0xFF42212C),
                    outlineVariant = Color(0xFF29151C)
                )
            }
        } else {
            // Modern, clean, crisp LIGHT COLOR SCHEME (Default!)
            when (this) {
                NEON_CYAN -> lightColorScheme(
                    primary = Color(0xFF0284C7),
                    onPrimary = Color(0xFFFFFFFF),
                    primaryContainer = Color(0xFFE0F2FE),
                    onPrimaryContainer = Color(0xFF0369A1),
                    secondary = Color(0xFF0EA5E9),
                    onSecondary = Color(0xFFFFFFFF),
                    secondaryContainer = Color(0xFFBAE6FD),
                    onSecondaryContainer = Color(0xFF075985),
                    tertiary = Color(0xFF0D9488),
                    onTertiary = Color(0xFFFFFFFF),
                    background = Color(0xFFF8FAFC),
                    onBackground = Color(0xFF0F172A),
                    surface = Color(0xFFFFFFFF),
                    onSurface = Color(0xFF0F172A),
                    surfaceVariant = Color(0xFFF1F5F9),
                    onSurfaceVariant = Color(0xFF475569),
                    outline = Color(0xFFE2E8F0),
                    outlineVariant = Color(0xFFCBD5E1)
                )
                COSMIC_INDIGO -> lightColorScheme(
                    primary = Color(0xFF4F46E5),
                    onPrimary = Color(0xFFFFFFFF),
                    primaryContainer = Color(0xFFEEF2FF),
                    onPrimaryContainer = Color(0xFF3730A3),
                    secondary = Color(0xFF6366F1),
                    onSecondary = Color(0xFFFFFFFF),
                    secondaryContainer = Color(0xFFE0E7FF),
                    onSecondaryContainer = Color(0xFF312E81),
                    tertiary = Color(0xFF7C3AED),
                    onTertiary = Color(0xFFFFFFFF),
                    background = Color(0xFFF8FAFC),
                    onBackground = Color(0xFF0F172A),
                    surface = Color(0xFFFFFFFF),
                    onSurface = Color(0xFF0F172A),
                    surfaceVariant = Color(0xFFF1F5F9),
                    onSurfaceVariant = Color(0xFF475569),
                    outline = Color(0xFFE2E8F0),
                    outlineVariant = Color(0xFFCBD5E1)
                )
                EMERALD_MATRIX -> lightColorScheme(
                    primary = Color(0xFF059669),
                    onPrimary = Color(0xFFFFFFFF),
                    primaryContainer = Color(0xFFD1FAE5),
                    onPrimaryContainer = Color(0xFF065F46),
                    secondary = Color(0xFF10B981),
                    onSecondary = Color(0xFFFFFFFF),
                    secondaryContainer = Color(0xFFA7F3D0),
                    onSecondaryContainer = Color(0xFF047857),
                    tertiary = Color(0xFF047857),
                    onTertiary = Color(0xFFFFFFFF),
                    background = Color(0xFFF8FAF9),
                    onBackground = Color(0xFF061A12),
                    surface = Color(0xFFFFFFFF),
                    onSurface = Color(0xFF061A12),
                    surfaceVariant = Color(0xFFECFDF5),
                    onSurfaceVariant = Color(0xFF335C49),
                    outline = Color(0xFFD1E7DD),
                    outlineVariant = Color(0xFFA7D5C1)
                )
                SUNSET_AMBER -> lightColorScheme(
                    primary = Color(0xFFD97706),
                    onPrimary = Color(0xFFFFFFFF),
                    primaryContainer = Color(0xFFFEF3C7),
                    onPrimaryContainer = Color(0xFF92400E),
                    secondary = Color(0xFFEA580C),
                    onSecondary = Color(0xFFFFFFFF),
                    secondaryContainer = Color(0xFFFFEDD5),
                    onSecondaryContainer = Color(0xFF9A3412),
                    tertiary = Color(0xFFB45309),
                    onTertiary = Color(0xFFFFFFFF),
                    background = Color(0xFFFCFAF7),
                    onBackground = Color(0xFF26190B),
                    surface = Color(0xFFFFFFFF),
                    onSurface = Color(0xFF26190B),
                    surfaceVariant = Color(0xFFFFFBEB),
                    onSurfaceVariant = Color(0xFF6B5842),
                    outline = Color(0xFFF3E7D5),
                    outlineVariant = Color(0xFFE5D2B8)
                )
                AURORA_VIOLET -> lightColorScheme(
                    primary = Color(0xFF7C3AED),
                    onPrimary = Color(0xFFFFFFFF),
                    primaryContainer = Color(0xFFEDE9FE),
                    onPrimaryContainer = Color(0xFF5B21B6),
                    secondary = Color(0xFFA855F7),
                    onSecondary = Color(0xFFFFFFFF),
                    secondaryContainer = Color(0xFFF3E8FF),
                    onSecondaryContainer = Color(0xFF6B21A8),
                    tertiary = Color(0xFF9333EA),
                    onTertiary = Color(0xFFFFFFFF),
                    background = Color(0xFFFAF8FD),
                    onBackground = Color(0xFF1B0F2A),
                    surface = Color(0xFFFFFFFF),
                    onSurface = Color(0xFF1B0F2A),
                    surfaceVariant = Color(0xFFF5F3FF),
                    onSurfaceVariant = Color(0xFF59486D),
                    outline = Color(0xFFE8E0F5),
                    outlineVariant = Color(0xFFD4C4EB)
                )
                RUBY_CRIMSON -> lightColorScheme(
                    primary = Color(0xFFE11D48),
                    onPrimary = Color(0xFFFFFFFF),
                    primaryContainer = Color(0xFFFFE4E6),
                    onPrimaryContainer = Color(0xFF9F1239),
                    secondary = Color(0xFFF43F5E),
                    onSecondary = Color(0xFFFFFFFF),
                    secondaryContainer = Color(0xFFFECDD3),
                    onSecondaryContainer = Color(0xFF881337),
                    tertiary = Color(0xFFBE123C),
                    onTertiary = Color(0xFFFFFFFF),
                    background = Color(0xFFFCF8F9),
                    onBackground = Color(0xFF280B14),
                    surface = Color(0xFFFFFFFF),
                    onSurface = Color(0xFF280B14),
                    surfaceVariant = Color(0xFFFFF1F2),
                    onSurfaceVariant = Color(0xFF6E4B54),
                    outline = Color(0xFFF7DEE3),
                    outlineVariant = Color(0xFFE9BFC7)
                )
            }
        }
    }

    companion object {
        fun fromId(id: String): AppColorTheme {
            return entries.firstOrNull { it.id.equals(id, ignoreCase = true) } ?: NEON_CYAN
        }
    }
}
