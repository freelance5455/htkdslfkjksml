package com.example.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.SufiLanguage
import com.example.ui.theme.CandleGlow
import com.example.ui.theme.CandleOrange
import com.example.ui.theme.GoldGleam
import com.example.ui.theme.GoldLuster
import com.example.ui.theme.GoldLusterBright
import com.example.ui.theme.GoldLusterDark
import com.example.ui.theme.TerracottaDark
import com.example.ui.theme.TerracottaWarm

/**
 * SufiDivineLandingPage:
 * Live animated divine splash & landing screen matching the exact aesthetic of the artwork:
 * - Rich warm terracotta leather / parchment background
 * - Breathing divine golden flame with ambient halo & floating celestial sparks
 * - Ornate calligraphic gold typography "SUFI SOME SAYS..."
 * - Interactive golden beveled glowing button "SUFI SAYS..." with corner lens flare stars
 * - Elegant watermark "© JOPPAN THINKS" at bottom
 */
@Composable
fun SufiDivineLandingPage(
    language: SufiLanguage,
    onSufiSaysTapped: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "divine_splash")

    // Flame gentle breathing & flickering
    val flamePulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "flamePulse"
    )

    // Ambient halo breathing
    val haloAlpha by infiniteTransition.animateFloat(
        initialValue = 0.45f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "haloAlpha"
    )

    // Button corner star sparkle glint
    val flareRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(5000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "flareRotation"
    )

    val flareScale by infiniteTransition.animateFloat(
        initialValue = 0.7f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "flareScale"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(TerracottaDark)
    ) {
        // Base textured background (img_terracotta_bg.jpg)
        Image(
            painter = painterResource(id = R.drawable.img_terracotta_bg),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        // Warm radial divine lighting vignette
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            CandleGlow.copy(alpha = 0.35f * haloAlpha),
                            TerracottaWarm.copy(alpha = 0.25f),
                            TerracottaDark.copy(alpha = 0.65f)
                        ),
                        radius = 1100f
                    )
                )
        )

        // Live Canvas: Rising golden embers & floating celestial sparks
        Canvas(
            modifier = Modifier.fillMaxSize()
        ) {
            drawDivineCelestialAccents(
                w = size.width,
                h = size.height,
                pulse = flamePulse,
                haloFactor = haloAlpha
            )
        }

        // Main Layout: Flame + Ornate Title + Illuminated Button + Joppan Thinks Footer
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            // Center Column: Divine Flame + Calligraphic Artwork
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // 1. Divine Glowing Flame Emblem with ambient halo
                Box(
                    modifier = Modifier
                        .size(200.dp)
                        .scale(flamePulse),
                    contentAlignment = Alignment.Center
                ) {
                    // Ambient radial aura behind the logo
                    Box(
                        modifier = Modifier
                            .size(190.dp)
                            .clip(RoundedCornerShape(28.dp))
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(
                                        CandleGlow.copy(alpha = 0.55f * haloAlpha),
                                        CandleOrange.copy(alpha = 0.25f * haloAlpha),
                                        Color.Transparent
                                    )
                                )
                            )
                    )

                    // Logo Emblem Image (Pure golden flame rising from open manuscript)
                    Image(
                        painter = painterResource(id = R.drawable.sufi_pure_flame_emblem_1787995182456),
                        contentDescription = "Sufi Sacred Flame Emblem",
                        modifier = Modifier
                            .size(180.dp)
                            .shadow(16.dp, RoundedCornerShape(24.dp))
                            .clip(RoundedCornerShape(24.dp))
                            .border(
                                1.5.dp,
                                Brush.linearGradient(
                                    listOf(
                                        GoldLusterBright.copy(alpha = 0.85f),
                                        GoldLuster.copy(alpha = 0.35f),
                                        GoldLusterBright.copy(alpha = 0.75f)
                                    )
                                ),
                                RoundedCornerShape(24.dp)
                            ),
                        contentScale = ContentScale.Crop
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                // 2. Ornate Calligraphic Title: SUFI SOME SAYS...
                CalligraphicArtworkTitle(
                    haloAlpha = haloAlpha,
                    modifier = Modifier.padding(horizontal = 12.dp)
                )

                Spacer(modifier = Modifier.height(38.dp))

                // 3. Interactive Golden Beveled Illuminated Button "SUFI SAYS..."
                DivineGoldenSufiButton(
                    language = language,
                    onClick = onSufiSaysTapped,
                    flareRotation = flareRotation,
                    flareScale = flareScale,
                    haloAlpha = haloAlpha
                )
            }

            // 4. Bottom Watermark: © JOPPAN THINKS
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            ) {
                Text(
                    text = "© JOPPAN THINKS",
                    style = MaterialTheme.typography.labelMedium,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    color = GoldLuster.copy(alpha = 0.92f),
                    letterSpacing = 4.5.sp,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.testTag("joppan_thinks_splash_watermark")
                )
            }
        }
    }
}

/**
 * Draws the Divine Illuminated Golden Flame with radiant aura and inner core
 */
private fun DrawScope.drawDivineIlluminatedFlame(w: Float, h: Float, haloAlpha: Float) {
    val cx = w * 0.5f
    val cy = h * 0.55f

    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                CandleGlow.copy(alpha = 0.75f * haloAlpha),
                CandleOrange.copy(alpha = 0.35f * haloAlpha),
                Color.Transparent
            ),
            center = Offset(cx, cy),
            radius = w * 0.55f
        ),
        radius = w * 0.55f,
        center = Offset(cx, cy)
    )

    val outerFlame = Path().apply {
        moveTo(cx, cy - h * 0.42f)
        cubicTo(cx + w * 0.22f, cy - h * 0.15f, cx + w * 0.28f, cy + h * 0.18f, cx, cy + h * 0.35f)
        cubicTo(cx - w * 0.28f, cy + h * 0.18f, cx - w * 0.22f, cy - h * 0.15f, cx, cy - h * 0.42f)
        close()
    }

    drawPath(
        path = outerFlame,
        brush = Brush.verticalGradient(
            colors = listOf(GoldGleam, GoldLusterBright, GoldLusterDark),
            startY = cy - h * 0.42f,
            endY = cy + h * 0.35f
        ),
        style = Stroke(width = 3.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
    )

    val innerFlame = Path().apply {
        moveTo(cx, cy - h * 0.15f)
        cubicTo(cx + w * 0.12f, cy, cx + w * 0.14f, cy + h * 0.20f, cx, cy + h * 0.28f)
        cubicTo(cx - w * 0.14f, cy + h * 0.20f, cx - w * 0.12f, cy, cx, cy - h * 0.15f)
        close()
    }

    drawPath(
        path = innerFlame,
        brush = Brush.verticalGradient(
            colors = listOf(GoldGleam, GoldLusterBright),
            startY = cy - h * 0.15f,
            endY = cy + h * 0.28f
        ),
        style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
    )
}

/**
 * Draws celestial floating accents (+ stars and sweeping flourishes) around flame
 */
private fun DrawScope.drawDivineCelestialAccents(w: Float, h: Float, pulse: Float, haloFactor: Float) {
    val cx = w * 0.5f
    val flameY = h * 0.28f

    val starX = cx + 55.dp.toPx()
    val starY = flameY - 45.dp.toPx()
    val starLen = 7.dp.toPx() * pulse

    drawLine(
        color = GoldLusterBright.copy(alpha = 0.85f * haloFactor),
        start = Offset(starX - starLen, starY),
        end = Offset(starX + starLen, starY),
        strokeWidth = 2.dp.toPx(),
        cap = StrokeCap.Round
    )
    drawLine(
        color = GoldLusterBright.copy(alpha = 0.85f * haloFactor),
        start = Offset(starX, starY - starLen),
        end = Offset(starX, starY + starLen),
        strokeWidth = 2.dp.toPx(),
        cap = StrokeCap.Round
    )

    val ribbonPath = Path().apply {
        moveTo(starX + 12.dp.toPx(), starY + 8.dp.toPx())
        lineTo(starX + 22.dp.toPx(), starY + 22.dp.toPx())
        lineTo(starX + 32.dp.toPx(), starY + 12.dp.toPx())
        lineTo(starX + 48.dp.toPx(), starY + 18.dp.toPx())
    }
    drawPath(
        path = ribbonPath,
        color = GoldLuster.copy(alpha = 0.75f),
        style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
    )

    val sparkLeftX = cx - 65.dp.toPx()
    val sparkLeftY = flameY - 10.dp.toPx()
    val leftCrescent = Path().apply {
        moveTo(sparkLeftX, sparkLeftY - 10.dp.toPx())
        cubicTo(sparkLeftX - 6.dp.toPx(), sparkLeftY, sparkLeftX - 2.dp.toPx(), sparkLeftY + 8.dp.toPx(), sparkLeftX + 6.dp.toPx(), sparkLeftY + 10.dp.toPx())
    }
    drawPath(
        path = leftCrescent,
        color = GoldLuster.copy(alpha = 0.75f),
        style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
    )

    val particles = listOf(
        Offset(cx - 90f, flameY + 60f),
        Offset(cx + 85f, flameY + 80f),
        Offset(cx - 120f, flameY + 140f),
        Offset(cx + 110f, flameY + 170f),
        Offset(cx - 70f, flameY + 220f)
    )
    for (p in particles) {
        drawCircle(
            color = GoldLusterBright.copy(alpha = 0.6f * haloFactor),
            radius = 1.8.dp.toPx(),
            center = p
        )
    }
}

/**
 * Renders the Calligraphic Golden Artwork Title: "SUFI SOME SAYS..." matching the sacred emblem style
 */
@Composable
private fun CalligraphicArtworkTitle(
    haloAlpha: Float,
    modifier: Modifier = Modifier
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(horizontal = 8.dp)
        ) {
            Text(
                text = "SUFI SOME SAYS...",
                style = MaterialTheme.typography.headlineLarge,
                fontFamily = FontFamily.Serif,
                fontStyle = FontStyle.Italic,
                fontWeight = FontWeight.Bold,
                color = GoldLusterBright,
                fontSize = 30.sp,
                letterSpacing = 4.sp,
                textAlign = TextAlign.Center
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "A BREATHE OF COMFORT",
            style = MaterialTheme.typography.labelSmall,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Medium,
            color = GoldLuster.copy(alpha = 0.9f),
            letterSpacing = 3.5.sp,
            fontSize = 11.sp,
            textAlign = TextAlign.Center
        )
    }
}

/**
 * Interactive Golden Beveled Button "SUFI SAYS..." with corner lens flare stars
 */
@Composable
fun DivineGoldenSufiButton(
    language: SufiLanguage,
    onClick: () -> Unit,
    flareRotation: Float,
    flareScale: Float,
    haloAlpha: Float,
    modifier: Modifier = Modifier
) {
    val buttonLabel = when (language) {
        SufiLanguage.MALAYALAM -> "SUFI SAYS..."
        SufiLanguage.ENGLISH -> "SUFI SAYS..."
        SufiLanguage.DUAL -> "SUFI SAYS..."
    }

    Box(
        modifier = modifier
            .width(280.dp)
            .height(76.dp)
            .testTag("sufi_says_button"),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            CandleGlow.copy(alpha = 0.55f * haloAlpha),
                            Color.Transparent
                        ),
                        radius = 240f
                    )
                )
        )

        Box(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .height(60.dp)
                .shadow(12.dp, RoundedCornerShape(16.dp))
                .clip(RoundedCornerShape(16.dp))
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            GoldGleam.copy(alpha = 0.85f),
                            GoldLusterBright,
                            GoldLuster,
                            GoldLusterDark
                        )
                    )
                )
                .border(
                    width = 2.dp,
                    brush = Brush.verticalGradient(
                        colors = listOf(GoldGleam, GoldLusterBright, GoldLusterDark)
                    ),
                    shape = RoundedCornerShape(16.dp)
                )
                .clickable { onClick() },
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(3.dp)
                    .border(
                        1.dp,
                        Brush.verticalGradient(
                            listOf(Color.White.copy(alpha = 0.4f), Color.Transparent)
                        ),
                        RoundedCornerShape(13.dp)
                    )
            )

            Text(
                text = buttonLabel,
                style = MaterialTheme.typography.titleLarge,
                fontFamily = FontFamily.Serif,
                fontStyle = FontStyle.Italic,
                fontWeight = FontWeight.Bold,
                color = TerracottaDark,
                fontSize = 21.sp,
                letterSpacing = 3.sp,
                textAlign = TextAlign.Center
            )
        }

        Canvas(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 2.dp, top = 2.dp)
                .size(24.dp)
        ) {
            rotate(degrees = flareRotation) {
                drawLensFlareStar(center = Offset(size.width / 2, size.height / 2), scale = flareScale)
            }
        }

        Canvas(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 2.dp, bottom = 2.dp)
                .size(24.dp)
        ) {
            rotate(degrees = -flareRotation) {
                drawLensFlareStar(center = Offset(size.width / 2, size.height / 2), scale = flareScale)
            }
        }
    }
}

private fun DrawScope.drawLensFlareStar(center: Offset, scale: Float) {
    val rayLen = 10.dp.toPx() * scale
    val rayWidth = 2.dp.toPx()

    drawCircle(
        color = GoldGleam,
        radius = 3.dp.toPx() * scale,
        center = center
    )

    drawLine(
        brush = Brush.horizontalGradient(
            colors = listOf(Color.Transparent, GoldGleam, Color.Transparent),
            startX = center.x - rayLen,
            endX = center.x + rayLen
        ),
        start = Offset(center.x - rayLen, center.y),
        end = Offset(center.x + rayLen, center.y),
        strokeWidth = rayWidth
    )

    drawLine(
        brush = Brush.verticalGradient(
            colors = listOf(Color.Transparent, GoldGleam, Color.Transparent),
            startY = center.y - rayLen,
            endY = center.y + rayLen
        ),
        start = Offset(center.x, center.y - rayLen),
        end = Offset(center.x, center.y + rayLen),
        strokeWidth = rayWidth
    )
}
