package com.example.ui.components

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Feedback
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.PanchangStrings
import com.example.model.AppLanguage
import com.example.model.DailyPanchang

@Composable
fun AllOptionsScreen(
    currentPanchang: DailyPanchang,
    language: AppLanguage,
    onNavigateToChoghadiya: () -> Unit,
    onNavigateToMuhurat: () -> Unit,
    onNavigateToMakanUdghatan: () -> Unit = onNavigateToMuhurat,
    onNavigateToOfficeUdghatan: () -> Unit = onNavigateToMuhurat,
    onNavigateToPanchak: () -> Unit,
    onNavigateToRashifal: () -> Unit,
    onNavigateToVratKatha: () -> Unit,
    onNavigateToReminders: () -> Unit,
    onNavigateToSmartTools: () -> Unit = {},
    onNavigateToWebApp: () -> Unit = {},
    onOpenLanguageDialog: () -> Unit,
    onOpenMonthYearPicker: () -> Unit,
    onOpenFeedback: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            // Header Hero Banner
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, Color(0xFFE0E0E0)),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(Color.Black),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "ॐ",
                            color = Color.White,
                            fontSize = 26.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column {
                        Text(
                            text = PanchangStrings.get(language, "all_options"),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                        Text(
                            text = "पंचांग की सभी सुविधाएं व्यवस्थित एवं सुलभ",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF444444)
                        )
                    }
                }
            }
        }

        // Section: स्मार्ट वैदिक उपकरण (Smart Tools Premier Hub)
        item {
            OptionSectionHeader(title = "स्मार्ट वैदिक उपकरण (Smart Vedic Tools Hub)")
        }

        item {
            OptionItemCard(
                icon = Icons.Default.Explore,
                title = "स्मार्ट वैदिक उपकरण (Smart Vedic Tools)",
                subtitle = "वास्तु कंपास, 108 जाप माला, होरा चक्र, 36 गुण मिलान, दिशा शूल, घंटी-शंख व आयु गणना",
                badge = "7 उपकरण",
                onClick = onNavigateToSmartTools,
                testTag = "opt_smart_tools"
            )
        }

        item {
            OptionItemCard(
                icon = Icons.Default.DateRange,
                title = "एकल फ़ाइल वेब पंचांग (index.html)",
                subtitle = "पूरा ऐप एकल index.html में खोलें (ऑफ़लाइन व ब्राउज़र समर्थित)",
                badge = "index.html",
                onClick = onNavigateToWebApp,
                testTag = "opt_web_app"
            )
        }

        // Section 1: काल एवं मुहूर्त विकल्प (Time & Muhurat)
        item {
            OptionSectionHeader(title = "काल एवं मुहूर्त विकल्प (Muhurat & Timings)")
        }

        item {
            OptionItemCard(
                icon = Icons.Default.Schedule,
                title = "चौघड़िया मुहूर्त (Choghadiya)",
                subtitle = "दिन व रात के 16 चौघड़िया (शुभ, अमृत, लाभ, चर, काल)",
                badge = "16 मुहूर्त",
                onClick = onNavigateToChoghadiya,
                testTag = "opt_choghadiya"
            )
        }

        item {
            OptionItemCard(
                icon = Icons.Default.Home,
                title = "मकान उद्घाटन व गृह प्रवेश (Makan Udghatan)",
                subtitle = "नूतन मकान, फ्लैट, विला का गृह प्रवेश, वास्तु शांति व पावन लग्न",
                badge = "गृह प्रवेश",
                onClick = onNavigateToMakanUdghatan,
                testTag = "opt_makan_udghatan"
            )
        }

        item {
            OptionItemCard(
                icon = Icons.Default.Storefront,
                title = "ऑफिस व दुकान उद्घाटन (Office Muhurat)",
                subtitle = "नया ऑफिस, दुकान, शोरूम व व्यापार शुभारंभ हेतु स्थिर लग्न व वेला",
                badge = "व्यापार वेला",
                onClick = onNavigateToOfficeUdghatan,
                testTag = "opt_office_udghatan"
            )
        }

        item {
            OptionItemCard(
                icon = Icons.Default.Favorite,
                title = "विवाह शुभ मुहूर्त (Vivah Muhurat)",
                subtitle = "विवाह व मांगलिक कार्यों हेतु शुभ लग्न, नक्षत्र व तिथियां",
                badge = "2026-27",
                onClick = onNavigateToMuhurat,
                testTag = "opt_muhurat"
            )
        }

        item {
            OptionItemCard(
                icon = Icons.Default.Warning,
                title = "पंचक व बिछुड़ा विवरण (Panchak & Bichhuda)",
                subtitle = "पंचक के 5 प्रकार, बिछुड़ा (वृश्चिक चंद्र), वर्जित कार्य व उपाय",
                badge = if (currentPanchang.panchak.isActive) "सक्रिय" else "पंचक मुक्त",
                onClick = onNavigateToPanchak,
                testTag = "opt_panchak"
            )
        }

        // Section 2: ज्योतिष एवं व्रत कथा विकल्प (Astrology & Vrats)
        item {
            OptionSectionHeader(title = "ज्योतिष एवं व्रत विकल्प (Astrology & Vrat)")
        }

        item {
            OptionItemCard(
                icon = Icons.Default.AutoAwesome,
                title = "दैनिक राशिफल (Daily Rashifal)",
                subtitle = "मेष से मीन 12 राशियों का आज का भविष्यफल, शुभ अंक, रंग व उपाय",
                badge = "12 राशियां",
                onClick = onNavigateToRashifal,
                testTag = "opt_rashifal"
            )
        }

        item {
            OptionItemCard(
                icon = Icons.Default.MenuBook,
                title = "प्रमुख व्रत कथाएं व नियम (Vrat Katha)",
                subtitle = "एकादशी, प्रदोष, सत्यनारायण पूर्णिमा, संकष्टी व शिवरात्रि कथा",
                badge = "सचित्र कथा",
                onClick = onNavigateToVratKatha,
                testTag = "opt_vrat_katha"
            )
        }

        item {
            OptionItemCard(
                icon = Icons.Default.Notifications,
                title = "स्मरण एवं व्रत अलर्ट (Reminders)",
                subtitle = "एकादशी, पूर्णिमा, प्रदोष व व्यक्तिगत तिथियों पर समय पर सूचना",
                badge = "अलर्ट",
                onClick = onNavigateToReminders,
                testTag = "opt_reminders"
            )
        }

        // Section 3: कैलेंडर एवं उपयोगिता विकल्प (Calendar & Utility)
        item {
            OptionSectionHeader(title = "कैलेंडर व उपयोगिता विकल्प (Calendar Utilities)")
        }

        item {
            OptionItemCard(
                icon = Icons.Default.Translate,
                title = "भाषा विकल्प (Language)",
                subtitle = "हिंदी, English, मराठी, गुजराती, बंगाली, तमिल, तेलुगु",
                badge = language.nativeName,
                onClick = onOpenLanguageDialog,
                testTag = "opt_language"
            )
        }

        item {
            OptionItemCard(
                icon = Icons.Default.CalendarMonth,
                title = "माह व वर्ष चुनें (Month/Year)",
                subtitle = "संवत 1900 से 2100 तक किसी भी माह व वर्ष का पंचांग देखें",
                badge = "खोजें",
                onClick = onOpenMonthYearPicker,
                testTag = "opt_month_year"
            )
        }

        item {
            OptionItemCard(
                icon = Icons.Default.Share,
                title = "दैनिक पंचांग शेयर करें (Share)",
                subtitle = "आज का पंचांग, तिथि, नक्षत्र व चौघड़िया मित्रों को भेजें",
                badge = "शेयर",
                onClick = { sharePanchang(context, currentPanchang) },
                testTag = "opt_share"
            )
        }

        // Section 4: सहायता एवं प्रतिक्रिया (Help & Feedback)
        item {
            OptionSectionHeader(title = "सहायता एवं प्रतिक्रिया (Support & Feedback)")
        }

        item {
            OptionItemCard(
                icon = Icons.Default.Feedback,
                title = "सुझाव व प्रतिक्रिया (Feedback)",
                subtitle = "ऐप सुधार व नए विकल्प हेतु ईमेल भेजें: devilaldheerjangid@gmail.com",
                badge = "ईमेल",
                onClick = onOpenFeedback,
                testTag = "opt_feedback"
            )
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun OptionSectionHeader(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelLarge,
        fontWeight = FontWeight.Bold,
        color = Color(0xFF333333),
        modifier = Modifier.padding(start = 4.dp, top = 4.dp)
    )
}

@Composable
fun OptionItemCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    badge: String? = null,
    onClick: () -> Unit,
    testTag: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag(testTag),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFE0E0E0)),
        shape = RoundedCornerShape(14.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFFF5F5F5))
                        .border(1.dp, Color(0xFFE0E0E0), RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = Color.Black,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black,
                            fontSize = 14.sp
                        )
                        if (badge != null) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xFFEEEEEE))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = badge,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF222222)
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF555555),
                        fontSize = 11.5.sp,
                        lineHeight = 15.sp
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                contentDescription = null,
                tint = Color(0xFF888888),
                modifier = Modifier.size(14.dp)
            )
        }
    }
}

private fun sharePanchang(context: Context, panchang: DailyPanchang) {
    val shareText = buildString {
        append("🕉️ *दैनिक वैदिक पंचांग*\n")
        append("📅 दिनांक: ${panchang.dateString} (${panchang.dayOfWeek})\n")
        append("🚩 ${panchang.hinduMonth} मास • संवत ${panchang.vikramSamvat}\n")
        append("✨ तिथि: ${panchang.tithiName} (${panchang.paksha.name})\n")
        append("🌟 नक्षत्र: ${panchang.nakshatra}\n")
        append("🌅 सूर्योदय: ${panchang.sunrise} | 🌄 सूर्यास्त: ${panchang.sunset}\n")
        append("⭐ अभिजीत मुहूर्त: ${panchang.abhijitMuhurat}\n")
        append("⚠️ राहुकाल: ${panchang.rahuKaal}\n")
        if (panchang.panchak.isActive) append("⚠️ पंचक: ${panchang.panchak.title}\n")
        if (panchang.bichhuda.isActive) append("🦂 बिछुड़ा: सक्रिय\n")
        if (panchang.festivals.isNotEmpty()) append("🎉 पर्व: ${panchang.festivals.joinToString(", ")}\n")
    }
    val sendIntent = Intent().apply {
        action = Intent.ACTION_SEND
        putExtra(Intent.EXTRA_TEXT, shareText)
        type = "text/plain"
    }
    context.startActivity(Intent.createChooser(sendIntent, "पंचांग शेयर करें"))
}
