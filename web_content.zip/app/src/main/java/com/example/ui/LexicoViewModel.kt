package com.example.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import android.speech.tts.TextToSpeech
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.db.ReviewQuality
import com.example.data.db.SrsRepository
import com.example.data.db.SrsWordEntity
import com.example.data.gemini.GeminiVocabularyService
import com.example.data.model.ScannedDocument
import com.example.data.model.WordContext
import com.example.data.model.WordDefinition
import com.example.data.pdf.PdfProcessor
import com.example.data.pdf.SampleDocuments
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Locale

data class LexicoUiState(
    val document: ScannedDocument? = null,
    val currentPageIndex: Int = 0,
    val currentWordIndexInPage: Int = 0,
    val filterStopwords: Boolean = true,
    val isAutoScanning: Boolean = false,
    val autoScanDelayMs: Long = 1800L,
    val unknownWords: List<WordContext> = emptyList(),
    val knownWordsCount: Int = 0,
    val glossary: List<WordDefinition> = emptyList(),
    val isProcessingDoc: Boolean = false,
    val isGeneratingGlossary: Boolean = false,
    val errorMessage: String? = null,
    val currentScreen: Screen = Screen.Home
)

enum class Screen {
    Home,
    Scan,
    Glossary,
    Flashcards,
    RhythmChallenge
}

class LexicoViewModel(application: Application) : AndroidViewModel(application), TextToSpeech.OnInitListener {

    private val database = AppDatabase.getDatabase(application)
    private val repository = SrsRepository(database.srsWordDao())
    private val gamificationRepo = com.example.data.db.UserGamificationRepository(application)

    private val _uiState = MutableStateFlow(LexicoUiState())
    val uiState: StateFlow<LexicoUiState> = _uiState.asStateFlow()

    private val _simulatedCurrentTime = MutableStateFlow(System.currentTimeMillis())
    val simulatedCurrentTime: StateFlow<Long> = _simulatedCurrentTime.asStateFlow()

    val gameStats: StateFlow<com.example.data.db.GameStatsState> = gamificationRepo.gameStats

    val srsWords: StateFlow<List<SrsWordEntity>> = repository.getAllWords()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private var tts: TextToSpeech? = null
    private var isTtsReady = false
    private var autoScanJob: Job? = null

    init {
        tts = TextToSpeech(application, this)
    }

    fun initTts(context: Context = getApplication()) {
        if (tts == null) {
            tts = TextToSpeech(context.applicationContext, this)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale.forLanguageTag("es-ES"))
            if (result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED) {
                isTtsReady = true
            }
        }
    }

    fun speakText(text: String) {
        if (isTtsReady) {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "lexico_tts_${System.currentTimeMillis()}")
        }
    }

    fun advanceSimulatedTime(minutes: Long) {
        _simulatedCurrentTime.update { it + (minutes * 60 * 1000L) }
    }

    fun answerFlashcardQuality(wordId: String, quality: ReviewQuality) {
        viewModelScope.launch {
            repository.recordReview(
                wordId = wordId,
                quality = quality,
                now = _simulatedCurrentTime.value
            )
        }
    }

    fun recordQuizAnswer(
        isCorrect: Boolean,
        direction: com.example.data.model.QuizDirection,
        elapsedTimeMs: Long
    ): Pair<Int, com.example.data.model.RhythmResult?> {
        return gamificationRepo.recordQuizAnswer(isCorrect, direction, elapsedTimeMs)
    }

    fun loadSample(index: Int) {
        val sample = SampleDocuments.SAMPLES.getOrNull(index) ?: SampleDocuments.SAMPLES.first()
        viewModelScope.launch {
            _uiState.update { it.copy(isProcessingDoc = true, errorMessage = null) }
            try {
                val doc = PdfProcessor.processTextDocument(sample.title, sample.text)
                _uiState.update {
                    it.copy(
                        document = doc,
                        currentPageIndex = 0,
                        currentWordIndexInPage = 0,
                        unknownWords = emptyList(),
                        knownWordsCount = 0,
                        glossary = emptyList(),
                        isProcessingDoc = false,
                        currentScreen = Screen.Scan
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isProcessingDoc = false, errorMessage = "Error al cargar texto: ${e.message}") }
            }
        }
    }

    fun loadPdf(context: Context, uri: Uri) {
        viewModelScope.launch {
            _uiState.update { it.copy(isProcessingDoc = true, errorMessage = null) }
            try {
                val doc = PdfProcessor.processPdfUri(context, uri)
                _uiState.update {
                    it.copy(
                        document = doc,
                        currentPageIndex = 0,
                        currentWordIndexInPage = 0,
                        unknownWords = emptyList(),
                        knownWordsCount = 0,
                        glossary = emptyList(),
                        isProcessingDoc = false,
                        currentScreen = Screen.Scan
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isProcessingDoc = false, errorMessage = "Error al abrir PDF: ${e.message}") }
            }
        }
    }

    fun loadCustomText(title: String, text: String) {
        if (text.isBlank()) return
        viewModelScope.launch {
            _uiState.update { it.copy(isProcessingDoc = true, errorMessage = null) }
            try {
                val doc = PdfProcessor.processTextDocument(title.ifBlank { "Texto Importado" }, text)
                _uiState.update {
                    it.copy(
                        document = doc,
                        currentPageIndex = 0,
                        currentWordIndexInPage = 0,
                        unknownWords = emptyList(),
                        knownWordsCount = 0,
                        glossary = emptyList(),
                        isProcessingDoc = false,
                        currentScreen = Screen.Scan
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isProcessingDoc = false, errorMessage = "Error procesando texto: ${e.message}") }
            }
        }
    }

    fun getActiveWordsForCurrentPage(): List<WordContext> {
        val state = _uiState.value
        val doc = state.document ?: return emptyList()
        val page = doc.pages.getOrNull(state.currentPageIndex) ?: return emptyList()

        return if (state.filterStopwords) {
            page.words.filter { !it.isStopWord }
        } else {
            page.words
        }
    }

    fun getActiveWord(): WordContext? {
        val words = getActiveWordsForCurrentPage()
        val index = _uiState.value.currentWordIndexInPage
        return words.getOrNull(index)
    }

    fun answerCurrentWord(known: Boolean) {
        val activeWord = getActiveWord() ?: return
        activeWord.isKnown = known

        val updatedUnknown = _uiState.value.unknownWords.toMutableList()
        var updatedKnownCount = _uiState.value.knownWordsCount

        if (!known) {
            if (!updatedUnknown.any { it.word.equals(activeWord.word, ignoreCase = true) }) {
                updatedUnknown.add(activeWord)
            }
        } else {
            updatedKnownCount++
        }

        _uiState.update {
            it.copy(
                unknownWords = updatedUnknown,
                knownWordsCount = updatedKnownCount
            )
        }

        advanceToNextWord()
    }

    fun skipCurrentWord() {
        advanceToNextWord()
    }

    fun previousWord() {
        val currentIndex = _uiState.value.currentWordIndexInPage
        if (currentIndex > 0) {
            _uiState.update { it.copy(currentWordIndexInPage = currentIndex - 1) }
        } else if (_uiState.value.currentPageIndex > 0) {
            val prevPage = _uiState.value.currentPageIndex - 1
            _uiState.update {
                it.copy(
                    currentPageIndex = prevPage,
                    currentWordIndexInPage = 0
                )
            }
        }
    }

    private fun advanceToNextWord() {
        val words = getActiveWordsForCurrentPage()
        val currentIndex = _uiState.value.currentWordIndexInPage

        if (currentIndex + 1 < words.size) {
            _uiState.update { it.copy(currentWordIndexInPage = currentIndex + 1) }
        } else {
            // End of current page
            val doc = _uiState.value.document
            if (doc != null && _uiState.value.currentPageIndex + 1 < doc.totalPages) {
                _uiState.update {
                    it.copy(
                        currentPageIndex = it.currentPageIndex + 1,
                        currentWordIndexInPage = 0
                    )
                }
            } else {
                // End of document
                stopAutoScan()
                if (_uiState.value.unknownWords.isNotEmpty()) {
                    generateGlossary()
                }
            }
        }
    }

    fun jumpToPage(pageIndex: Int) {
        val doc = _uiState.value.document ?: return
        if (pageIndex in 0 until doc.totalPages) {
            _uiState.update {
                it.copy(
                    currentPageIndex = pageIndex,
                    currentWordIndexInPage = 0
                )
            }
        }
    }

    fun toggleFilterStopwords() {
        _uiState.update {
            it.copy(
                filterStopwords = !it.filterStopwords,
                currentWordIndexInPage = 0
            )
        }
    }

    fun toggleAutoScan() {
        if (_uiState.value.isAutoScanning) {
            stopAutoScan()
        } else {
            startAutoScan()
        }
    }

    private fun startAutoScan() {
        _uiState.update { it.copy(isAutoScanning = true) }
        autoScanJob?.cancel()
        autoScanJob = viewModelScope.launch {
            while (_uiState.value.isAutoScanning) {
                delay(_uiState.value.autoScanDelayMs)
                if (!_uiState.value.isAutoScanning) break
                advanceToNextWord()
            }
        }
    }

    private fun stopAutoScan() {
        autoScanJob?.cancel()
        autoScanJob = null
        _uiState.update { it.copy(isAutoScanning = false) }
    }

    fun generateGlossary() {
        stopAutoScan()
        val unknownList = _uiState.value.unknownWords
        if (unknownList.isEmpty()) {
            _uiState.update {
                it.copy(
                    errorMessage = "¡Fantástico! No has marcado ninguna palabra como desconocida.",
                    currentScreen = Screen.Glossary
                )
            }
            return
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isGeneratingGlossary = true,
                    errorMessage = null,
                    currentScreen = Screen.Glossary
                )
            }

            try {
                val docTitle = _uiState.value.document?.title ?: "Material de lectura"
                val definitions = GeminiVocabularyService.explainUnknownWords(
                    unknownWords = unknownList,
                    materialTopic = docTitle
                )

                // Save unknown words into Spaced Repetition repository (15 minutes initial interval)
                repository.saveNewLearnedWords(
                    definitions = definitions,
                    sourceDoc = docTitle,
                    now = _simulatedCurrentTime.value
                )

                _uiState.update {
                    it.copy(
                        glossary = definitions,
                        isGeneratingGlossary = false
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isGeneratingGlossary = false,
                        errorMessage = "Error al generar explicaciones: ${e.message}"
                    )
                }
            }
        }
    }

    fun toggleMemorized(definitionId: String) {
        val updated = _uiState.value.glossary.map {
            if (it.id == definitionId) it.copy(isMemorized = !it.isMemorized)
            else it
        }
        _uiState.update { it.copy(glossary = updated) }
    }

    fun navigateTo(screen: Screen) {
        stopAutoScan()
        _uiState.update { it.copy(currentScreen = screen, errorMessage = null) }
    }

    fun clearError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    override fun onCleared() {
        super.onCleared()
        autoScanJob?.cancel()
        tts?.stop()
        tts?.shutdown()
    }
}
