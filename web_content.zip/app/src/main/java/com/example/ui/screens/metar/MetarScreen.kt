package com.example.ui.screens.metar

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MetarData
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.UiState
import com.example.ui.viewmodel.WeatherViewModel
import java.util.Locale

@Composable
fun MetarScreen(
  viewModel: WeatherViewModel,
  modifier: Modifier = Modifier
) {
  val selectedAirport by viewModel.selectedAirport.collectAsState()
  val metarState by viewModel.metarState.collectAsState()
  val isOffline by viewModel.isOffline.collectAsState()

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp)
      .testTag("metar_screen"),
    verticalArrangement = Arrangement.spacedBy(14.dp),
    contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
  ) {
    if (isOffline) {
      item { OfflineNoticeBanner() }
    }

    // Screen Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "گزارش جوی ایستگاه هوانوردی (METAR / SPECI)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "${selectedAirport.icao} • ${selectedAirport.nameFa}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        IconButton(onClick = { viewModel.loadWeatherForSelectedAirport() }) {
          Icon(Icons.Default.Refresh, contentDescription = "به‌روزرسانی", tint = MaterialTheme.colorScheme.primary)
        }
      }
    }

    when (val state = metarState) {
      is UiState.Success -> {
        val metar = state.data

        // SPECI highlight banner if present
        if (metar.isSpeci) {
          item {
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = StatusRed.copy(alpha = 0.2f),
              border = CardDefaults.outlinedCardBorder(),
              modifier = Modifier.fillMaxWidth().testTag("speci_highlight_banner")
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(Icons.Default.Warning, contentDescription = null, tint = StatusRed)
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                  Text(
                    text = "گزارش ویژه SPECI صادر شده است",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = StatusRed
                  )
                  Text(
                    text = "این گزارش به دلیل تغییرات ناگهانی و بحرانی در شرایط جوی فرودگاه (باد، دید، سقف ابر یا پدیده جوی) به صورت ویژه صادر گردیده است.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface
                  )
                }
              }
            }
          }
        }

        // 1. ORIGINAL RAW MESSAGE (Prominently displayed, untouched)
        item {
          RawMessageCard(
            titleFa = if (metar.isSpeci) "متن خام گزارش ویژه (RAW SPECI)" else "متن خام متار (RAW METAR)",
            rawText = metar.rawMetar,
            source = metar.source,
            issueTimeUtc = metar.obsTimeUtc,
            receiptTimeUtc = metar.receiptTimeUtc,
            isSpeci = metar.isSpeci,
            isParsingFailed = metar.parsingFailed
          )
        }

        // 2. OBSERVATION & METADATA CARD
        item {
          Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            border = CardDefaults.outlinedCardBorder(),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Text(
                text = "مشخصات رصد و زمان‌بندی پیام (Observation & Timing)",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
              )
              Spacer(modifier = Modifier.height(10.dp))
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                MetarMetaItem("زمان رصد (Observation UTC)", metar.obsTimeUtc.ifBlank { "--" })
                MetarMetaItem("دسته‌بندی پرواز", metar.flightCategory)
                MetarMetaItem("وضعیت دریافت", if (state.isCachedOffline) "ذخیره در حافظه" else "زنده (Live)")
                MetarMetaItem("آخرین تازه‌سازی", state.lastUpdatedUtc)
              }
            }
          }
        }

        // 3. COMPLETE DECODED WEATHER FIELDS
        item {
          Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            border = CardDefaults.outlinedCardBorder(),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = "پارامترهای جوی رمزگشایی شده (Decoded Fields)",
                  style = MaterialTheme.typography.titleSmall,
                  fontWeight = FontWeight.Bold
                )
                FlightCategoryBadge(category = metar.flightCategory)
              }

              Spacer(modifier = Modifier.height(14.dp))

              // Wind Section
              Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(text = "باد سطحی (Surface Wind)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  val windStr = buildString {
                    if (metar.isWindCalm) append("CALM (آرام 00000KT)")
                    else {
                      append(metar.windDirDeg?.let { "$it°" } ?: if (metar.isWindVariable) "متغیر (VRB)" else "--")
                      append(" / ")
                      append(metar.windSpeedKt?.let { "$it KT" } ?: "--")
                      metar.windGustKt?.let { append(" (تندباد Gust: $it KT)") }
                    }
                  }
                  Text(text = windStr, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

                  if (metar.windVariableFromDeg != null && metar.windVariableToDeg != null) {
                    Text(
                      text = "تغییرات زاویه باد: بین ${metar.windVariableFromDeg}° و ${metar.windVariableToDeg}°",
                      style = MaterialTheme.typography.labelSmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                  }
                }

                if (metar.windDirDeg != null && metar.windSpeedKt != null) {
                  WindVectorVisualizer(
                    windDirDeg = metar.windDirDeg,
                    windSpeedKt = metar.windSpeedKt
                  )
                }
              }

              Divider(modifier = Modifier.padding(vertical = 12.dp))

              // Visibility & RVR
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(text = "دید افقی (Visibility)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  val visStr = if (metar.isCavok) "CAVOK (دید بیش از ۱۰ کیلومتر و بدون ابر)"
                  else metar.visibilityMeters?.let { "${it}m (${it / 1000.0} km)" } ?: metar.visibilitySm ?: "گزارش نشده"
                  Text(text = visStr, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                }

                Column(modifier = Modifier.weight(1f)) {
                  Text(text = "دید باند (RVR)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text(text = metar.rvr ?: "بدون گزارش RVR", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                }
              }

              Divider(modifier = Modifier.padding(vertical = 12.dp))

              // Clouds & Ceiling
              Column {
                Text(text = "پوشش ابرها و کف ابر (Clouds & Ceiling)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(text = metar.cloudsSummary, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                if (metar.ceilingFt != null) {
                  Text(
                    text = "سقف پرواز عملیاتی (Ceiling): ${metar.ceilingFt} پا بالاتر از سطح فرودگاه",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary
                  )
                }
              }

              Divider(modifier = Modifier.padding(vertical = 12.dp))

              // Temperature, Dewpoint, Altimeter
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                  Text(text = "دما (Temperature)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text(text = "${metar.tempC ?: "--"} °C", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                }
                Column {
                  Text(text = "نقطه شبنم (Dew Point)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text(text = "${metar.dewPointC ?: "--"} °C", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                }
                Column {
                  Text(text = "فشار هوانوردی (QNH)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text(text = "${metar.altimeterHpa?.toInt()?.let { "Q$it hPa" } ?: "--"}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
                if (metar.altimeterInHg != null) {
                  Column {
                    Text(text = "اینچ جیوه (inHg)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(text = "A${String.format(Locale.US, "%.2f", metar.altimeterInHg)}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                  }
                }
              }

              Divider(modifier = Modifier.padding(vertical = 12.dp))

              // Present Weather & Trend
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(text = "پدیده هوای حاضر (Present Weather)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text(text = metar.presentWeather ?: "هیچ پدیده نامساعدی گزارش نشده است", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                }
                Column(modifier = Modifier.weight(1f)) {
                  Text(text = "روند ۲ ساعته (Trend)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text(text = metar.trend ?: "NOSIG (بدون تغییر مهم)", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                }
              }
            }
          }
        }
      }

      is UiState.Loading -> {
        item {
          Card(modifier = Modifier.fillMaxWidth()) {
            Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator()
                Spacer(modifier = Modifier.height(12.dp))
                Text("در حال دریافت آخرین گزارش METAR/SPECI از سرورهای بین‌المللی...")
              }
            }
          }
        }
      }

      is UiState.Error -> {
        item {
          Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Column(modifier = Modifier.padding(16.dp)) {
              Text("خطا در دریافت متار: ${state.message}", color = StatusRed, fontWeight = FontWeight.Bold)
              Spacer(modifier = Modifier.height(8.dp))
              Text("داده‌های فعلی برای این ایستگاه در دسترس نیست (NO CURRENT DATA).", style = MaterialTheme.typography.bodySmall)
            }
          }
        }
      }
    }

    item { OperationalDisclaimerCard() }
  }
}

@Composable
private fun MetarMetaItem(label: String, value: String) {
  Column {
    Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Text(text = value, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
  }
}
