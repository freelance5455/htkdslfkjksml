package com.example.ui.screens.metar

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.UiState
import com.example.ui.viewmodel.WeatherViewModel

@Composable
fun MetarScreen(
  viewModel: WeatherViewModel,
  modifier: Modifier = Modifier
) {
  val selectedAirport by viewModel.selectedAirport.collectAsState()
  val metarState by viewModel.metarState.collectAsState()
  val isOffline by viewModel.isOffline.collectAsState()
  val clipboard = LocalClipboardManager.current
  val context = LocalContext.current

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp)
      .testTag("metar_screen"),
    verticalArrangement = Arrangement.spacedBy(14.dp),
    contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
  ) {
    if (isOffline) {
      item { OfflineNoticeBanner() }
    }

    // Screen Header (English)
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "Aviation Weather Report (RAW METAR / SPECI)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = AtcTextMain
          )
          Text(
            text = "${selectedAirport.icao} (${selectedAirport.iata}) • ${selectedAirport.nameEn}",
            style = MaterialTheme.typography.bodySmall,
            color = AtcTextMuted
          )
        }

        IconButton(onClick = { viewModel.loadWeatherForSelectedAirport() }) {
          Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = OceanBlue)
        }
      }
    }

    when (val state = metarState) {
      is UiState.Success -> {
        val metar = state.data

        // SPECI Banner if special report
        if (metar.isSpeci) {
          item {
            Surface(
              shape = RoundedCornerShape(10.dp),
              color = StatusRed.copy(alpha = 0.12f),
              border = androidx.compose.foundation.BorderStroke(1.5.dp, StatusRed),
              modifier = Modifier.fillMaxWidth().testTag("speci_highlight_banner")
            ) {
              Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(Icons.Default.Warning, contentDescription = null, tint = StatusRed)
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                  Text(
                    text = "SPECI (Special Weather Report Issued)",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = StatusRed
                  )
                  Text(
                    text = "Critical sudden weather deterioration / criteria change observed at station.",
                    style = MaterialTheme.typography.labelSmall,
                    color = AtcTextMain
                  )
                }
              }
            }
          }
        }

        // PURE RAW METAR CARD - SOFT PURPLE (بنفش ملایم)
        // No explanations, no interpretations, pure raw code for controllers
        item {
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MetarCardBg),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, MetarCardBorder),
            modifier = Modifier.fillMaxWidth().testTag("raw_metar_card")
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(
                    imageVector = Icons.Default.Terminal,
                    contentDescription = null,
                    tint = MetarCardText,
                    modifier = Modifier.size(22.dp)
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = if (metar.isSpeci) "RAW SPECI" else "RAW METAR",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MetarCardText
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  FlightCategoryBadge(category = metar.flightCategory)
                }

                IconButton(
                  onClick = {
                    clipboard.setText(AnnotatedString(metar.rawMetar))
                    Toast.makeText(context, "METAR copied to clipboard", Toast.LENGTH_SHORT).show()
                  },
                  modifier = Modifier.testTag("btn_copy_metar")
                ) {
                  Icon(
                    imageVector = Icons.Default.ContentCopy,
                    contentDescription = "Copy RAW METAR",
                    tint = MetarCardText
                  )
                }
              }

              Spacer(modifier = Modifier.height(12.dp))

              // Technical Monospace Display for RAW METAR (Full soft purple card body)
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color.White.copy(alpha = 0.25f),
                border = androidx.compose.foundation.BorderStroke(1.dp, MetarCardBorder),
                modifier = Modifier.fillMaxWidth()
              ) {
                Text(
                  text = metar.rawMetar.ifBlank { "NO RAW METAR DATA AVAILABLE" },
                  style = MaterialTheme.typography.bodyLarge.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 0.8.sp,
                    lineHeight = 24.sp
                  ),
                  color = MetarCardText,
                  modifier = Modifier.padding(16.dp)
                )
              }

              Spacer(modifier = Modifier.height(12.dp))

              // Minimal Header Metadata (No interpretation)
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Column {
                  Text(text = "Station / FIR", style = MaterialTheme.typography.labelSmall, color = MetarCardText.copy(alpha = 0.7f))
                  Text(text = "${metar.icao} • ${selectedAirport.fir}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = MetarCardText)
                }
                Column {
                  Text(text = "Observation Time (UTC)", style = MaterialTheme.typography.labelSmall, color = MetarCardText.copy(alpha = 0.7f))
                  Text(text = metar.obsTimeUtc.ifBlank { "--" }, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = MetarCardText)
                }
                Column {
                  Text(text = "Data Source", style = MaterialTheme.typography.labelSmall, color = MetarCardText.copy(alpha = 0.7f))
                  Text(text = metar.source, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = MetarCardText)
                }
              }
            }
          }
        }
      }

      is UiState.Loading -> {
        item {
          Card(modifier = Modifier.fillMaxWidth()) {
            Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
              CircularProgressIndicator(color = OceanBlue)
            }
          }
        }
      }

      is UiState.Error -> {
        item {
          Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
              Text("METAR Error: ${state.message}", color = StatusRed, fontWeight = FontWeight.Bold)
              Text("Station data currently unavailable from OPMET feed.", style = MaterialTheme.typography.bodySmall)
            }
          }
        }
      }
    }

    item { OperationalDisclaimerCard() }
  }
}
