package com.example.ui.navigation

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.InstallMobile
import androidx.compose.material.icons.outlined.ViewKanban
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.InstallMobile
import androidx.compose.material.icons.rounded.ViewKanban
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.R
import com.example.data.model.ProjectEntity
import com.example.data.model.TaskEntity
import com.example.data.model.TaskStatus
import com.example.data.model.ThemeMode
import com.example.ui.components.CreateEditProjectSheet
import com.example.ui.components.CreateEditTaskSheet
import com.example.ui.components.EditWorkspaceProfileDialog
import com.example.ui.components.TaskDetailSheet
import com.example.ui.components.TemplatesBottomSheet
import com.example.ui.components.WebsitePreviewDialog
import com.example.ui.screens.AnalyticsFocusScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.KanbanScreen
import com.example.ui.screens.ProjectDetailScreen
import com.example.ui.screens.ProjectsScreen
import com.example.ui.viewmodel.ProjectViewModel
import com.example.util.AppDistributionHelper
import com.example.util.toPersianDigits
import kotlinx.coroutines.launch

const val ROUTE_DASHBOARD = "dashboard"
const val ROUTE_PROJECTS = "projects"
const val ROUTE_KANBAN = "kanban"
const val ROUTE_FOCUS_ANALYTICS = "focus_analytics"
const val ROUTE_PROJECT_DETAIL = "project_detail/{projectId}"

private data class TopLevelDestination(
    val route: String,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

private val topLevelDestinations = listOf(
    TopLevelDestination(
        route = ROUTE_DASHBOARD,
        labelRes = R.string.nav_dashboard,
        selectedIcon = Icons.Rounded.Dashboard,
        unselectedIcon = Icons.Outlined.Dashboard,
        testTag = "nav_dashboard"
    ),
    TopLevelDestination(
        route = ROUTE_PROJECTS,
        labelRes = R.string.nav_projects,
        selectedIcon = Icons.Rounded.Folder,
        unselectedIcon = Icons.Outlined.Folder,
        testTag = "nav_projects"
    ),
    TopLevelDestination(
        route = ROUTE_KANBAN,
        labelRes = R.string.nav_kanban,
        selectedIcon = Icons.Rounded.ViewKanban,
        unselectedIcon = Icons.Outlined.ViewKanban,
        testTag = "nav_kanban"
    ),
    TopLevelDestination(
        route = ROUTE_FOCUS_ANALYTICS,
        labelRes = R.string.nav_focus,
        selectedIcon = Icons.Rounded.InstallMobile,
        unselectedIcon = Icons.Outlined.InstallMobile,
        testTag = "nav_focus"
    )
)

@Composable
fun ProzheYarApp(
    viewModel: ProjectViewModel,
    themeMode: ThemeMode
) {
    val context = LocalContext.current
    @Suppress("DEPRECATION")
    val clipboardManager = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val navController = rememberNavController()
    val uiState by viewModel.workspaceState.collectAsStateWithLifecycle()
    val focusTimer by viewModel.focusTimer.collectAsStateWithLifecycle()
    val ownerName by viewModel.ownerName.collectAsStateWithLifecycle()
    val forceDesktopLayout by viewModel.forceDesktopLayout.collectAsStateWithLifecycle()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    var showProjectSheet by remember { mutableStateOf(false) }
    var editingProject by remember { mutableStateOf<ProjectEntity?>(null) }
    var showTemplatesSheet by remember { mutableStateOf(false) }
    var showProfileDialog by remember { mutableStateOf(false) }
    var showWebsitePreview by remember { mutableStateOf(false) }
    var scrollToDistributionTrigger by remember { mutableIntStateOf(0) }

    var showTaskSheet by remember { mutableStateOf(false) }
    var editingTask by remember { mutableStateOf<TaskEntity?>(null) }
    var taskInitialProjectId by remember { mutableStateOf<Long?>(null) }
    var taskInitialStatus by remember { mutableStateOf(TaskStatus.TODO) }

    var pendingReportProjectId by remember { mutableStateOf<Long?>(null) }

    var activeDetailTaskId by remember { mutableStateOf<Long?>(null) }
    val activeDetailTask = remember(uiState.tasks, activeDetailTaskId) {
        uiState.tasks.firstOrNull { it.task.id == activeDetailTaskId }
    }

    val createApkLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/vnd.android.package-archive")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val result = AppDistributionHelper.copyInstalledApkToUri(context, uri)
                result.onSuccess {
                    snackbarHostState.showSnackbar("فایل نصبی APK با موفقیت در حافظه ذخیره شد")
                }.onFailure { err ->
                    snackbarHostState.showSnackbar(err.message ?: "خطا در ذخیره فایل APK")
                }
            }
        }
    }

    val createWebsiteHtmlLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/html")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val result = AppDistributionHelper.copyBundledWebsiteToUri(context, uri)
                result.onSuccess {
                    snackbarHostState.showSnackbar("فایل سایت معرفی (HTML) با موفقیت ذخیره شد")
                }.onFailure { err ->
                    snackbarHostState.showSnackbar(err.message ?: "خطا در ذخیره فایل سایت")
                }
            }
        }
    }

    val createMarkdownLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/markdown")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val report = viewModel.buildMarkdownReport(pendingReportProjectId)
                try {
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(report.toByteArray(Charsets.UTF_8))
                    }
                    snackbarHostState.showSnackbar("فایل گزارش با موفقیت ذخیره شد")
                } catch (_: Exception) {
                    snackbarHostState.showSnackbar("خطا در ذخیره فایل گزارش")
                }
            }
        }
    }

    val createJsonBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val json = viewModel.exportWorkspaceJson()
                try {
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(json.toByteArray(Charsets.UTF_8))
                    }
                    snackbarHostState.showSnackbar("فایل پشتیبان JSON با موفقیت دانلود شد")
                } catch (_: Exception) {
                    snackbarHostState.showSnackbar("خطا در ذخیره فایل پشتیبان")
                }
            }
        }
    }

    val importJsonBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    val content = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    if (content != null) {
                        val result = viewModel.importWorkspaceJson(content)
                        result.onSuccess { count ->
                            snackbarHostState.showSnackbar("${count.toPersianDigits()} پروژه از فایل بازیابی شد")
                        }.onFailure {
                            snackbarHostState.showSnackbar("ساختار فایل پشتیبان معتبر نیست")
                        }
                    }
                } catch (_: Exception) {
                    snackbarHostState.showSnackbar("خطا در خواندن فایل انتخاب‌شده")
                }
            }
        }
    }

    fun triggerMarkdownDownload(projectId: Long? = null) {
        pendingReportProjectId = projectId
        val fileName = if (projectId == null) "ProzheYar-Report.md" else "Project-$projectId-Report.md"
        createMarkdownLauncher.launch(fileName)
    }

    fun shareTextReport(projectId: Long? = null) {
        scope.launch {
            val report = viewModel.buildMarkdownReport(projectId)
            val shareText = "$report\n\nساخته‌شده با اپلیکیشن مدیریت پروژه پروژه‌یار"
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "گزارش مدیریت پروژه - پروژه‌یار")
                putExtra(Intent.EXTRA_TEXT, shareText)
            }
            context.startActivity(Intent.createChooser(intent, "اشتراک‌گذاری گزارش پروژه"))
        }
    }

    fun shareApkFile() {
        scope.launch {
            val result = AppDistributionHelper.createShareApkIntent(context)
            result.onSuccess { chooserIntent ->
                context.startActivity(chooserIntent)
            }.onFailure { err ->
                snackbarHostState.showSnackbar(err.message ?: "خطا در آماده‌سازی فایل APK")
            }
        }
    }

    fun openDesktopWeb() {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(AppDistributionHelper.DESKTOP_WEB_URL))
            context.startActivity(intent)
        } catch (_: Exception) {
            scope.launch {
                snackbarHostState.showSnackbar("مرورگر برای باز کردن لینک یافت نشد")
            }
        }
    }

    fun copyDesktopLink() {
        clipboardManager.setText(AnnotatedString(AppDistributionHelper.DESKTOP_WEB_URL))
        scope.launch {
            snackbarHostState.showSnackbar("لینک نسخه دسکتاپ و وب کپی شد")
        }
    }

    val isTopLevel = currentRoute in topLevelDestinations.map { it.route }

    fun navigateTopLevel(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavRail = forceDesktopLayout || maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            bottomBar = {
                if (!useNavRail && isTopLevel) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        topLevelDestinations.forEach { dest ->
                            val selected = currentRoute == dest.route
                            val label = stringResource(dest.labelRes)
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTopLevel(dest.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = label
                                    )
                                },
                                label = { Text(label, maxLines = 1) },
                                modifier = Modifier.testTag(dest.testTag)
                            )
                        }
                    }
                }
            },
            floatingActionButton = {
                if (currentRoute == ROUTE_DASHBOARD && uiState.projects.isNotEmpty()) {
                    FloatingActionButton(
                        onClick = {
                            editingTask = null
                            taskInitialProjectId = uiState.projects.firstOrNull()?.project?.id
                            taskInitialStatus = TaskStatus.TODO
                            showTaskSheet = true
                        },
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.testTag("fab_quick_add_task")
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = stringResource(R.string.action_new_task))
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useNavRail && isTopLevel) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        Spacer(Modifier.weight(0.2f))
                        topLevelDestinations.forEach { dest ->
                            val selected = currentRoute == dest.route
                            val label = stringResource(dest.labelRes)
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTopLevel(dest.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = label
                                    )
                                },
                                label = { Text(label, maxLines = 1) },
                                modifier = Modifier.testTag(dest.testTag)
                            )
                        }
                        Spacer(Modifier.weight(1f))
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                    NavHost(
                        navController = navController,
                        startDestination = ROUTE_DASHBOARD,
                        enterTransition = { fadeIn(tween(240)) + slideInHorizontally(tween(240)) { it / 16 } },
                        exitTransition = { fadeOut(tween(180)) },
                        popEnterTransition = { fadeIn(tween(240)) },
                        popExitTransition = { fadeOut(tween(180)) }
                    ) {
                        composable(ROUTE_DASHBOARD) {
                            DashboardScreen(
                                ownerName = ownerName,
                                uiState = uiState,
                                onEditOwnerName = { showProfileDialog = true },
                                onNewProjectClick = {
                                    editingProject = null
                                    showProjectSheet = true
                                },
                                onNewTaskClick = {
                                    editingTask = null
                                    taskInitialProjectId = uiState.projects.firstOrNull()?.project?.id
                                    taskInitialStatus = TaskStatus.TODO
                                    showTaskSheet = true
                                },
                                onOpenTemplatesClick = { showTemplatesSheet = true },
                                onLoadStarterTemplate = { viewModel.loadStarterTemplate() },
                                onOpenFocusTab = { navigateTopLevel(ROUTE_FOCUS_ANALYTICS) },
                                onOpenAppDownloadCenter = {
                                    scrollToDistributionTrigger++
                                    navigateTopLevel(ROUTE_FOCUS_ANALYTICS)
                                },
                                onDownloadReportClick = { triggerMarkdownDownload(null) },
                                onOpenProject = { projectId ->
                                    navController.navigate("project_detail/$projectId")
                                },
                                onTogglePinProject = { viewModel.togglePinProject(it) },
                                onViewAllProjects = { navigateTopLevel(ROUTE_PROJECTS) },
                                onTaskClick = { activeDetailTaskId = it.task.id },
                                onToggleTaskDone = { viewModel.toggleTaskDone(it) },
                                onAdvanceTaskStatus = {
                                    val next = TaskStatus.fromName(it.status).next()
                                    viewModel.moveTaskStatus(it, next)
                                },
                                onToggleBookmarkTask = { viewModel.toggleBookmarkTask(it) }
                            )
                        }

                        composable(ROUTE_PROJECTS) {
                            ProjectsScreen(
                                ownerName = ownerName,
                                projects = uiState.projects,
                                onNewProjectClick = {
                                    editingProject = null
                                    showProjectSheet = true
                                },
                                onOpenTemplatesClick = { showTemplatesSheet = true },
                                onOpenProject = { projectId ->
                                    navController.navigate("project_detail/$projectId")
                                },
                                onTogglePinProject = { viewModel.togglePinProject(it) }
                            )
                        }

                        composable(ROUTE_KANBAN) {
                            KanbanScreen(
                                projects = uiState.projects,
                                tasks = uiState.tasks,
                                forceWideBoard = forceDesktopLayout,
                                onNewTaskClick = { projectId, status ->
                                    editingTask = null
                                    taskInitialProjectId = projectId ?: uiState.projects.firstOrNull()?.project?.id
                                    taskInitialStatus = status
                                    showTaskSheet = true
                                },
                                onTaskClick = { activeDetailTaskId = it.task.id },
                                onToggleTaskDone = { viewModel.toggleTaskDone(it) },
                                onAdvanceTaskStatus = {
                                    val next = TaskStatus.fromName(it.status).next()
                                    viewModel.moveTaskStatus(it, next)
                                },
                                onToggleBookmarkTask = { viewModel.toggleBookmarkTask(it) }
                            )
                        }

                        composable(ROUTE_FOCUS_ANALYTICS) {
                            AnalyticsFocusScreen(
                                ownerName = ownerName,
                                uiState = uiState,
                                timerState = focusTimer,
                                themeMode = themeMode,
                                forceDesktopLayout = forceDesktopLayout,
                                scrollToDistributionTrigger = scrollToDistributionTrigger,
                                onEditOwnerName = { showProfileDialog = true },
                                onToggleDesktopLayout = { enabled ->
                                    viewModel.setForceDesktopLayout(enabled)
                                    scope.launch {
                                        snackbarHostState.showSnackbar(
                                            if (enabled) "حالت نمای دسکتاپ فعال شد" else "حالت نمای موبایل فعال شد"
                                        )
                                    }
                                },
                                onDownloadApkFile = {
                                    createApkLauncher.launch(AppDistributionHelper.suggestedApkFileName())
                                },
                                onShareApkFile = { shareApkFile() },
                                onOpenDesktopWeb = { openDesktopWeb() },
                                onCopyDesktopLink = { copyDesktopLink() },
                                onPreviewWebsite = { showWebsitePreview = true },
                                onDownloadWebsiteHtml = {
                                    createWebsiteHtmlLauncher.launch(AppDistributionHelper.suggestedWebsiteFileName())
                                },
                                onSelectFocusTask = { viewModel.selectFocusTask(it) },
                                onSetDuration = { viewModel.setFocusDuration(it) },
                                onToggleTimer = { viewModel.toggleFocusTimer() },
                                onResetTimer = { viewModel.resetFocusTimer() },
                                onLogElapsedNow = { viewModel.logElapsedFocusNow() },
                                onClearFocusMessage = { viewModel.clearFocusMessage() },
                                onSetThemeMode = { viewModel.setThemeMode(it) },
                                onExportMarkdownAll = { triggerMarkdownDownload(null) },
                                onExportJsonBackup = {
                                    createJsonBackupLauncher.launch("ProzheYar-Backup.json")
                                },
                                onImportJsonBackup = {
                                    importJsonBackupLauncher.launch(arrayOf("application/json", "text/*"))
                                },
                                onShareAppAndReport = { shareTextReport(null) }
                            )
                        }

                        composable(
                            route = ROUTE_PROJECT_DETAIL,
                            arguments = listOf(navArgument("projectId") { type = NavType.LongType })
                        ) { entry ->
                            val projectId = entry.arguments?.getLong("projectId") ?: 0L
                            val projectStats = uiState.projects.firstOrNull { it.project.id == projectId }
                            val projectTasks = uiState.tasks.filter { it.task.projectId == projectId }
                            val projectMilestones = uiState.milestones.filter { it.projectId == projectId }

                            ProjectDetailScreen(
                                projectWithStats = projectStats,
                                tasks = projectTasks,
                                milestones = projectMilestones,
                                onBack = { navController.popBackStack() },
                                onEditProject = {
                                    editingProject = it
                                    showProjectSheet = true
                                },
                                onDeleteProject = { viewModel.deleteProject(it) },
                                onTogglePin = { viewModel.togglePinProject(it) },
                                onChangeProjectStatus = { proj, st ->
                                    viewModel.updateProjectStatus(proj, st)
                                },
                                onUpdateProjectNotes = { proj, newNotes ->
                                    viewModel.updateProjectNotes(proj, newNotes)
                                    scope.launch {
                                        snackbarHostState.showSnackbar("یادداشت پروژه ذخیره شد")
                                    }
                                },
                                onExportProjectMarkdown = { id -> triggerMarkdownDownload(id) },
                                onShareProjectSummary = { id -> shareTextReport(id) },
                                onAddTask = { status ->
                                    editingTask = null
                                    taskInitialProjectId = projectId
                                    taskInitialStatus = status
                                    showTaskSheet = true
                                },
                                onTaskClick = { activeDetailTaskId = it.task.id },
                                onToggleTaskDone = { viewModel.toggleTaskDone(it) },
                                onAdvanceTaskStatus = {
                                    val next = TaskStatus.fromName(it.status).next()
                                    viewModel.moveTaskStatus(it, next)
                                },
                                onToggleBookmarkTask = { viewModel.toggleBookmarkTask(it) },
                                onAddMilestone = { title ->
                                    viewModel.addMilestone(projectId, title, null)
                                },
                                onToggleMilestone = { viewModel.toggleMilestone(it) },
                                onDeleteMilestone = { viewModel.deleteMilestone(it) }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showProfileDialog) {
        EditWorkspaceProfileDialog(
            currentOwnerName = ownerName,
            onDismiss = { showProfileDialog = false },
            onSave = { newName ->
                viewModel.setOwnerName(newName)
                showProfileDialog = false
                scope.launch {
                    snackbarHostState.showSnackbar("نام فضای کاری شخصی به‌روزرسانی شد")
                }
            }
        )
    }

    if (showTemplatesSheet) {
        TemplatesBottomSheet(
            onDismiss = { showTemplatesSheet = false },
            onSelectTemplate = { template ->
                showTemplatesSheet = false
                viewModel.createFromTemplate(template) { newId ->
                    navController.navigate("project_detail/$newId")
                }
            }
        )
    }

    if (showProjectSheet) {
        CreateEditProjectSheet(
            existingProject = editingProject,
            onDismiss = { showProjectSheet = false },
            onSave = { title, desc, notes, budgetLabel, cat, colorIdx, targetDate ->
                val current = editingProject
                if (current == null) {
                    viewModel.createProject(title, desc, notes, budgetLabel, cat, colorIdx, targetDate)
                } else {
                    viewModel.updateProject(
                        current.copy(
                            title = title,
                            description = desc,
                            notes = notes,
                            budgetLabel = budgetLabel,
                            category = cat.name,
                            colorIndex = colorIdx,
                            targetDateMillis = targetDate
                        )
                    )
                }
                showProjectSheet = false
            }
        )
    }

    if (showTaskSheet) {
        CreateEditTaskSheet(
            projects = uiState.projects,
            initialProjectId = taskInitialProjectId,
            initialStatus = taskInitialStatus,
            existingTask = editingTask,
            onDismiss = { showTaskSheet = false },
            onSave = { projId, title, desc, priority, status, dueDate, estMins, storyPoints, assigneeName, tag ->
                val current = editingTask
                if (current == null) {
                    viewModel.createTask(
                        projId, title, desc, priority, status, dueDate, estMins, storyPoints, assigneeName, tag
                    )
                } else {
                    viewModel.updateTask(
                        current.copy(
                            title = title,
                            description = desc,
                            priority = priority.name,
                            status = status.name,
                            dueDateMillis = dueDate,
                            estimatedMinutes = estMins,
                            storyPoints = storyPoints,
                            assigneeName = assigneeName,
                            tag = tag
                        )
                    )
                }
                showTaskSheet = false
            }
        )
    }

    if (activeDetailTask != null) {
        TaskDetailSheet(
            taskMeta = activeDetailTask,
            onDismiss = { activeDetailTaskId = null },
            onMoveStatus = { newStatus ->
                viewModel.moveTaskStatus(activeDetailTask.task, newStatus)
            },
            onEditTask = {
                editingTask = activeDetailTask.task
                taskInitialProjectId = activeDetailTask.task.projectId
                activeDetailTaskId = null
                showTaskSheet = true
            },
            onDuplicateTask = {
                viewModel.duplicateTask(activeDetailTask.task)
                activeDetailTaskId = null
                scope.launch {
                    snackbarHostState.showSnackbar("یک کپی از تسک ساخته شد")
                }
            },
            onDeleteTask = {
                viewModel.deleteTask(activeDetailTask.task.id)
                activeDetailTaskId = null
            },
            onStartFocus = {
                viewModel.selectFocusTask(activeDetailTask.task.id)
                activeDetailTaskId = null
                navigateTopLevel(ROUTE_FOCUS_ANALYTICS)
            },
            onAddSubtask = { subTitle ->
                viewModel.addSubtask(activeDetailTask.task.id, subTitle)
            },
            onToggleSubtask = { viewModel.toggleSubtask(it) },
            onDeleteSubtask = { viewModel.deleteSubtask(it) }
        )
    }

    if (showWebsitePreview) {
        WebsitePreviewDialog(
            onDismiss = { showWebsitePreview = false },
            onExportWebsiteHtml = {
                createWebsiteHtmlLauncher.launch(AppDistributionHelper.suggestedWebsiteFileName())
            },
            onTriggerApkDownload = {
                createApkLauncher.launch(AppDistributionHelper.suggestedApkFileName())
            }
        )
    }
}
