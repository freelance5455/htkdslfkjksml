package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.widget.VideoView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Comment
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.local.VideoEntity
import com.example.ui.theme.ZingBlack
import com.example.ui.theme.ZingCyan
import com.example.ui.theme.ZingGold
import com.example.ui.theme.ZingHeartRed
import com.example.ui.theme.ZingNeonPink
import com.example.ui.theme.ZingTextPrimary
import com.example.ui.theme.ZingTextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.sin

@Composable
fun VideoPlayerItem(
    video: VideoEntity,
    isCurrentPage: Boolean,
    onLikeClick: () -> Unit,
    onCommentClick: () -> Unit,
    onShareClick: () -> Unit,
    onGiftClick: () -> Unit,
    onFollowClick: () -> Unit,
    onReportClick: () -> Unit,
    onBlockCreatorClick: () -> Unit,
    onCreatorProfileClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var isPlaying by remember { mutableStateOf(true) }
    var showPlayPauseIcon by remember { mutableStateOf(false) }
    var showDoubleTapHeart by remember { mutableStateOf(false) }
    var tapHeartPosition by remember { mutableStateOf(Offset.Zero) }
    var showMenu by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    // Rotating vinyl disc animation
    val infiniteTransition = rememberInfiniteTransition(label = "disc")
    val discRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "disc_rot"
    )

    // Animated progress simulation
    var progress by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(isCurrentPage, isPlaying) {
        if (isCurrentPage && isPlaying) {
            while (true) {
                delay(100)
                progress = (progress + 0.01f) % 1f
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ZingBlack)
            .pointerInput(video.id) {
                detectTapGestures(
                    onDoubleTap = { offset ->
                        tapHeartPosition = offset
                        showDoubleTapHeart = true
                        if (!video.isLiked) {
                            onLikeClick()
                        }
                        coroutineScope.launch {
                            delay(800)
                            showDoubleTapHeart = false
                        }
                    },
                    onTap = {
                        isPlaying = !isPlaying
                        showPlayPauseIcon = true
                        coroutineScope.launch {
                            delay(600)
                            showPlayPauseIcon = false
                        }
                    }
                )
            }
    ) {
        // --- Video Media Background ---
        if (video.videoUri.isNotBlank()) {
            // Real video player via AndroidView VideoView
            AndroidView(
                factory = { ctx ->
                    VideoView(ctx).apply {
                        setVideoURI(Uri.parse(video.videoUri))
                        setOnPreparedListener { mp ->
                            mp.isLooping = true
                            if (isCurrentPage && isPlaying) start()
                        }
                    }
                },
                update = { view ->
                    if (isCurrentPage && isPlaying) {
                        if (!view.isPlaying) view.start()
                    } else {
                        if (view.isPlaying) view.pause()
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            // Creative animated short-video canvas
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(video.bgGradientStart),
                                Color(video.bgGradientEnd),
                                Color(0xFF07050A)
                            )
                        )
                    )
            ) {
                // If there is a poster image generated
                if (video.posterResName.isNotBlank()) {
                    val resId = context.resources.getIdentifier(video.posterResName, "drawable", context.packageName)
                    if (resId != 0) {
                        AsyncImage(
                            model = ImageRequest.Builder(context)
                                .data(resId)
                                .crossfade(true)
                                .build(),
                            contentDescription = video.caption,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }

                // Dynamic ambient reactive neon lighting
                val waveAnim by infiniteTransition.animateFloat(
                    initialValue = 0f,
                    targetValue = 6.28f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(3000, easing = LinearEasing),
                        repeatMode = RepeatMode.Restart
                    ),
                    label = "wave"
                )

                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer(alpha = 0.25f)
                ) {
                    val centerX = size.width / 2f
                    val centerY = size.height / 2f
                    val radius = (size.width * 0.4f) + (sin(waveAnim.toDouble()) * 30).toFloat()

                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(ZingNeonPink, Color.Transparent),
                            center = Offset(centerX, centerY),
                            radius = radius
                        )
                    )
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(ZingCyan, Color.Transparent),
                            center = Offset(centerX + 60f, centerY - 80f),
                            radius = radius * 0.8f
                        )
                    )
                }
            }
        }

        // Vignette Overlays for crisp readability of text and controls
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
                .align(Alignment.TopCenter)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0x99000000), Color.Transparent)
                    )
                )
        )
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp)
                .align(Alignment.BottomCenter)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, Color(0xE6000000))
                    )
                )
        )

        // Center Play / Pause Animated Icon
        AnimatedVisibility(
            visible = showPlayPauseIcon,
            enter = scaleIn(spring()) + fadeIn(),
            exit = scaleOut() + fadeOut(),
            modifier = Modifier.align(Alignment.Center)
        ) {
            Surface(
                shape = CircleShape,
                color = Color(0x66000000),
                modifier = Modifier.size(76.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.PlayArrow else Icons.Default.PlayArrow,
                        contentDescription = "Playback state",
                        tint = Color.White,
                        modifier = Modifier.size(44.dp)
                    )
                }
            }
        }

        // Double Tap Floating Heart
        AnimatedVisibility(
            visible = showDoubleTapHeart,
            enter = scaleIn(spring(dampingRatio = 0.5f)) + fadeIn(),
            exit = scaleOut() + fadeOut(),
            modifier = Modifier.align(Alignment.Center)
        ) {
            Icon(
                imageVector = Icons.Default.Favorite,
                contentDescription = "Liked",
                tint = ZingHeartRed,
                modifier = Modifier
                    .size(110.dp)
                    .graphicsLayer {
                        shadowElevation = 20f
                    }
            )
        }

        // --- Right Action Bar ---
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 12.dp, bottom = 48.dp)
        ) {
            // Creator Avatar with follow button
            Box(
                contentAlignment = Alignment.BottomCenter,
                modifier = Modifier.padding(bottom = 8.dp)
            ) {
                val avatarResId = context.resources.getIdentifier(video.creatorAvatar, "drawable", context.packageName)
                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .clip(CircleShape)
                        .border(2.dp, ZingNeonPink, CircleShape)
                        .clickable { onCreatorProfileClick(video.creatorId) }
                ) {
                    if (avatarResId != 0) {
                        AsyncImage(
                            model = ImageRequest.Builder(context).data(avatarResId).crossfade(true).build(),
                            contentDescription = video.creatorName,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .fillMaxSize()
                                .background(ZingNeonPink)
                        ) {
                            Text(
                                text = video.creatorName.take(1),
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                        }
                    }
                }

                // Follow badge (+)
                Surface(
                    shape = CircleShape,
                    color = ZingNeonPink,
                    modifier = Modifier
                        .size(20.dp)
                        .offset(y = 6.dp)
                        .clickable { onFollowClick() }
                        .testTag("follow_creator_button")
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Follow",
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            // Like Action
            ActionIcon(
                icon = if (video.isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                tint = if (video.isLiked) ZingHeartRed else Color.White,
                count = formatCount(video.likesCount),
                onClick = onLikeClick,
                testTag = "like_video_button"
            )

            // Comment Action
            ActionIcon(
                icon = Icons.Default.Comment,
                tint = Color.White,
                count = formatCount(video.commentsCount),
                onClick = onCommentClick,
                testTag = "comment_video_button"
            )

            // Gift / Send Coins (Monetization Tip)
            ActionIcon(
                icon = Icons.Default.CardGiftcard,
                tint = ZingGold,
                count = "Gift",
                onClick = onGiftClick,
                testTag = "gift_video_button"
            )

            // Share Action
            ActionIcon(
                icon = Icons.Default.Share,
                tint = Color.White,
                count = formatCount(video.sharesCount),
                onClick = onShareClick,
                testTag = "share_video_button"
            )

            // Overflow Menu (Report / Block)
            Box {
                IconButton(
                    onClick = { showMenu = true },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "More options",
                        tint = Color.White.copy(alpha = 0.8f)
                    )
                }

                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Report Video", color = ZingNeonPink) },
                        onClick = {
                            showMenu = false
                            onReportClick()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Block @${video.creatorHandle}") },
                        onClick = {
                            showMenu = false
                            onBlockCreatorClick()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Share link") },
                        onClick = {
                            showMenu = false
                            onShareClick()
                        }
                    )
                }
            }

            // Rotating Musical Disc
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF1F1E2A))
                    .border(2.dp, Color(0xFF353347), CircleShape)
                    .rotate(if (isPlaying) discRotation else 0f)
            ) {
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(ZingNeonPink)
                )
                Icon(
                    imageVector = Icons.Default.MusicNote,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(12.dp)
                )
            }
        }

        // --- Bottom Creator Info & Caption ---
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth(0.78f)
                .padding(start = 16.dp, bottom = 32.dp)
        ) {
            // Creator Handle & Verified badge
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.clickable { onCreatorProfileClick(video.creatorId) }
            ) {
                Text(
                    text = "@${video.creatorHandle}",
                    color = ZingTextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                    imageVector = Icons.Default.Verified,
                    contentDescription = "Verified Creator",
                    tint = ZingCyan,
                    modifier = Modifier.size(16.dp)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Caption & Hashtags
            Text(
                text = video.caption,
                color = Color.White.copy(alpha = 0.95f),
                fontSize = 14.sp,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Audio Track Marquee
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0x40000000))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.MusicNote,
                    contentDescription = null,
                    tint = ZingGold,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = video.soundTitle,
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        // Bottom Seek Progress Bar
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(2.dp)
                .align(Alignment.BottomCenter),
            color = ZingNeonPink,
            trackColor = Color.White.copy(alpha = 0.2f)
        )
    }
}

@Composable
private fun ActionIcon(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    count: String,
    onClick: () -> Unit,
    testTag: String
) {
    val scale = remember { Animatable(1f) }
    val coroutineScope = rememberCoroutineScope()

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null
        ) {
            coroutineScope.launch {
                scale.animateTo(1.3f, tween(100))
                scale.animateTo(1.0f, spring(dampingRatio = 0.6f))
            }
            onClick()
        }
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(Color(0x33000000))
                .scale(scale.value)
                .testTag(testTag)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = count,
                tint = tint,
                modifier = Modifier.size(28.dp)
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = count,
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

fun formatCount(count: Int): String {
    return when {
        count >= 1_000_000 -> String.format("%.1fM", count / 1_000_000.0)
        count >= 1_000 -> String.format("%.1fK", count / 1_000.0)
        else -> count.toString()
    }
}
