@file:OptIn(ExperimentalMaterial3Api::class)
package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.data.repository.CollegeRepository
import com.example.ui.theme.*
import com.example.ui.viewmodel.CollegeViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// --------------------------------------------------------------------------------
// SECTION 9: CLINICAL DUTY SCREEN
// --------------------------------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ClinicalDutyScreen(viewModel: CollegeViewModel) {
    val selectedBatch by viewModel.selectedBatch.collectAsState()
    val teachers by viewModel.teachers.collectAsState()
    val students by viewModel.batchStudents.collectAsState()
    val rosters by viewModel.batchClinicalRosters.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    val clinicalTeachers = remember(teachers) { teachers.filter { it.isClinicalDuty } }

    var mainSectionTab by remember { mutableStateOf(0) } // 0: Section A. Teacher, 1: Section B. Roster
    var rosterSubOption by remember { mutableStateOf(0) } // 0: 1. Roster, 1: 2. Present / Absent

    val todayDate = remember { SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Main Navigation: A. Teacher vs B. Roster
        TabRow(
            selectedTabIndex = mainSectionTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = ClinicalBlueSecondary
        ) {
            Tab(
                selected = mainSectionTab == 0,
                onClick = { mainSectionTab = 0 },
                text = { Text("A. Clinical Teachers", style = MaterialTheme.typography.titleSmall) }
            )
            Tab(
                selected = mainSectionTab == 1,
                onClick = { mainSectionTab = 1 },
                text = { Text("B. Hospital Roster", style = MaterialTheme.typography.titleSmall) }
            )
        }

        if (mainSectionTab == 0) {
            // 9A. TEACHER SECTION
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(
                        text = "Clinical Instructors & Hospital Supervisors",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Faculty posted at Govt. District Hospital Sri Ganganagar",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                    )
                }
                items(clinicalTeachers) { teacher ->
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(50.dp)
                                    .clip(CircleShape)
                                    .background(ClinicalBlueContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.LocalHospital, contentDescription = null, tint = ClinicalBlueSecondary)
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column {
                                Text(teacher.name, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                Text(teacher.designation, style = MaterialTheme.typography.bodySmall.copy(color = ClinicalBlueSecondary))
                                Text("Department: ${teacher.department}", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        } else {
            // 9B. ROSTER SECTION WITH 4 BATCH FOLDERS & 2 SUB-OPTIONS
            Column(modifier = Modifier.fillMaxSize()) {
                // 4 Batch Tabs
                ScrollableTabRow(
                    selectedTabIndex = CollegeRepository.BATCHES.indexOf(selectedBatch).coerceAtLeast(0),
                    edgePadding = 16.dp,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    CollegeRepository.BATCHES.forEach { batch ->
                        Tab(
                            selected = batch == selectedBatch,
                            onClick = { viewModel.selectBatch(batch) },
                            text = { Text(batch, style = MaterialTheme.typography.labelMedium) }
                        )
                    }
                }

                // Exactly Two Sub-options: 1. Roster, 2. Present / Absent
                SecondaryTabRow(selectedTabIndex = rosterSubOption) {
                    Tab(
                        selected = rosterSubOption == 0,
                        onClick = { rosterSubOption = 0 },
                        text = { Text("1. Roster Schedule", style = MaterialTheme.typography.labelMedium) }
                    )
                    Tab(
                        selected = rosterSubOption == 1,
                        onClick = { rosterSubOption = 1 },
                        text = { Text("2. Present / Absent", style = MaterialTheme.typography.labelMedium) }
                    )
                }

                if (rosterSubOption == 0) {
                    // Option 1: Roster schedule view
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        val roster = rosters.firstOrNull()
                        item {
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Official Duty Schedule",
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                        )
                                        AssistChip(
                                            onClick = {},
                                            label = { Text("Active Roster", style = MaterialTheme.typography.labelSmall) }
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(
                                        text = roster?.title ?: "Hospital Clinical Duty Chart - $selectedBatch",
                                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold)
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "Posting Location: ${roster?.hospitalLocation ?: "District Hospital (Govt. Hospital), Sri Ganganagar"}",
                                        style = MaterialTheme.typography.bodySmall.copy(color = ClinicalBlueSecondary)
                                    )
                                    Text(
                                        text = "Effective Period: ${roster?.effectiveDate ?: "Oct - Nov 2026"}",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                    Text(
                                        text = "Published By: ${roster?.updatedBy ?: "Vice Principal Sunita Verma"}",
                                        style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                                    )

                                    Spacer(modifier = Modifier.height(14.dp))
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = ClinicalBlueContainer.copy(alpha = 0.6f),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Text(
                                                text = "Ward Rotations:",
                                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                                            )
                                            Text("• Group A: Emergency & Trauma Ward (Shift: 08:00 - 14:00)", style = MaterialTheme.typography.bodySmall)
                                            Text("• Group B: Intensive Care Unit (ICU) & OT (Shift: 14:00 - 20:00)", style = MaterialTheme.typography.bodySmall)
                                            Text("• Group C: Maternal & Child Health (Shift: 08:00 - 14:00)", style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    // Option 2: Present / Absent Clinical Attendance List
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "Clinical Attendance: $todayDate",
                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                        )
                                        Text(
                                            text = "Location: District Hospital SGNR",
                                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp)
                                        )
                                    }
                                    if (currentUser.role == UserRole.TEACHER || currentUser.role == UserRole.ADMIN) {
                                        Text(
                                            text = "Tap to toggle",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = NursingGreenPrimary
                                        )
                                    }
                                }
                            }
                        }

                        items(students) { student ->
                            var isPresent by remember { mutableStateOf(true) }
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = student.name,
                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                        )
                                        Text(
                                            text = "ID: ${student.rollNo} | $selectedBatch",
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                                                fontSize = 11.5.sp
                                            )
                                        )
                                    }

                                    if (currentUser.role == UserRole.TEACHER || currentUser.role == UserRole.ADMIN) {
                                        FilledTonalButton(
                                            onClick = {
                                                isPresent = !isPresent
                                                val statusStr = if (isPresent) "PRESENT" else "ABSENT"
                                                viewModel.markClinicalAttendance(
                                                    batchId = selectedBatch,
                                                    studentId = student.id,
                                                    studentName = student.name,
                                                    date = todayDate,
                                                    status = statusStr,
                                                    hospital = "District Hospital SGNR"
                                                )
                                            },
                                            colors = ButtonDefaults.filledTonalButtonColors(
                                                containerColor = if (isPresent) NursingGreenContainer else Color(0xFFFFE4E6),
                                                contentColor = if (isPresent) NursingGreenPrimary else Color(0xFFE11D48)
                                            )
                                        ) {
                                            Text(
                                                text = if (isPresent) "Present" else "Absent",
                                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                                            )
                                        }
                                    } else {
                                        Badge(
                                            containerColor = if (isPresent) NursingGreenContainer else Color(0xFFFFE4E6),
                                            contentColor = if (isPresent) NursingGreenPrimary else Color(0xFFE11D48)
                                        ) {
                                            Text(if (isPresent) "Present" else "Absent")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// --------------------------------------------------------------------------------
// SECTION 10: ADMIN DASHBOARD SCREEN
// --------------------------------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    viewModel: CollegeViewModel,
    onOpenRoleDialog: () -> Unit
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val teachers by viewModel.teachers.collectAsState()
    val notices by viewModel.notices.collectAsState()
    val holidays by viewModel.holidays.collectAsState()
    val complaints by viewModel.allComplaints.collectAsState()

    var showStatusUpdateDialog by remember { mutableStateOf<Complaint?>(null) }

    var adminIdInput by remember { mutableStateOf("GNMTC26") }
    var passwordInput by remember { mutableStateOf("GNMTC2026") }
    var passwordVisible by remember { mutableStateOf(false) }
    var loginError by remember { mutableStateOf<String?>(null) }

    if (currentUser.role != UserRole.ADMIN) {
        // Admin Login Form
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFFEF3C7)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AdminPanelSettings,
                        contentDescription = "Admin Lock",
                        tint = Color(0xFFD97706),
                        modifier = Modifier.size(46.dp)
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "GNMTC SGNR Admin Portal",
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "प्रशासक लॉगिन (Restricted Administrative Access)",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                )
            }

            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "Enter Administrative Credentials",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )

                        OutlinedTextField(
                            value = adminIdInput,
                            onValueChange = {
                                adminIdInput = it
                                loginError = null
                            },
                            label = { Text("Admin ID") },
                            placeholder = { Text("GNMTC26") },
                            leadingIcon = {
                                Icon(Icons.Default.Badge, contentDescription = null, tint = NursingGreenPrimary)
                            },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = passwordInput,
                            onValueChange = {
                                passwordInput = it
                                loginError = null
                            },
                            label = { Text("Password") },
                            placeholder = { Text("GNMTC2026") },
                            leadingIcon = {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = NursingGreenPrimary)
                            },
                            trailingIcon = {
                                IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                    Icon(
                                        imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                        contentDescription = "Toggle password visibility"
                                    )
                                }
                            },
                            visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        loginError?.let { err ->
                            Text(
                                text = err,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.Info,
                                    contentDescription = null,
                                    tint = ClinicalBlueSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Default Credentials: ID: GNMTC26 | Pass: GNMTC2026",
                                    style = MaterialTheme.typography.labelSmall.copy(color = ClinicalBlueSecondary)
                                )
                            }
                        }

                        Button(
                            onClick = {
                                val success = viewModel.verifyAdminLogin(adminIdInput, passwordInput)
                                if (!success) {
                                    loginError = "Invalid credentials. Use Admin ID: GNMTC26 and Password: GNMTC2026."
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NursingGreenPrimary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                        ) {
                            Icon(Icons.Default.Login, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Sign In as Administrator", style = MaterialTheme.typography.titleSmall)
                        }
                    }
                }
            }
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Admin Profile Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(NursingGreenContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = NursingGreenPrimary)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(currentUser.name, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                Text("Admin ID: GNMTC26 | Session Active", style = MaterialTheme.typography.bodySmall.copy(color = NursingGreenPrimary))
                            }
                        }

                        OutlinedButton(
                            onClick = { viewModel.logout() }
                        ) {
                            Text("Sign Out")
                        }
                    }
                }
            }
        }

        // Live Administrative Metrics
        item {
            Text(
                text = "College Metrics & Live Overview",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricTile(
                    title = "Batches",
                    count = "4",
                    icon = Icons.Default.Groups,
                    color = ClinicalBlueSecondary,
                    modifier = Modifier.weight(1f)
                )
                MetricTile(
                    title = "Faculty",
                    count = "${teachers.size}",
                    icon = Icons.Default.School,
                    color = NursingGreenPrimary,
                    modifier = Modifier.weight(1f)
                )
                MetricTile(
                    title = "Notices",
                    count = "${notices.size}",
                    icon = Icons.Default.Campaign,
                    color = Color(0xFF7C3AED),
                    modifier = Modifier.weight(1f)
                )
                MetricTile(
                    title = "Grievances",
                    count = "${complaints.size}",
                    icon = Icons.Default.ReportProblem,
                    color = Color(0xFFD97706),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Complaint Proctorial Queue for Admin
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Student Grievance Queue (Proctorial Review)",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Authorize status updates: Received -> Under Review -> In Progress -> Resolved",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    if (complaints.isEmpty()) {
                        Text("No complaints in queue.", style = MaterialTheme.typography.bodySmall)
                    } else {
                        complaints.forEach { comp ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "#${comp.trackingCode} - ${comp.studentName} (${comp.batch})",
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = comp.description,
                                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                FilledTonalButton(onClick = { showStatusUpdateDialog = comp }) {
                                    Text(comp.status, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                            HorizontalDivider()
                        }
                    }
                }
            }
        }

        // Administrative Activity Logs
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Administrative Activity Audit Log", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("• Batch 2026-27 coordinator verified: Ms. Priyanka Meena", style = MaterialTheme.typography.bodySmall)
                    Text("• RNC Examination circular published to Notice Board", style = MaterialTheme.typography.bodySmall)
                    Text("• District Hospital clinical duty attendance synchronized", style = MaterialTheme.typography.bodySmall)
                    Text("• Firebase security rules active on Cloud Firestore", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }

    // Modal: Admin Update Complaint Status
    showStatusUpdateDialog?.let { comp ->
        var newStatus by remember { mutableStateOf(comp.status) }
        var note by remember { mutableStateOf(comp.resolutionNote) }

        AlertDialog(
            onDismissRequest = { showStatusUpdateDialog = null },
            title = { Text("Update Complaint #${comp.trackingCode}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Student: ${comp.studentName} | Batch: ${comp.batch}", style = MaterialTheme.typography.bodySmall)
                    Text("Change Status:", style = MaterialTheme.typography.labelMedium)
                    listOf("Received", "Under Review", "In Progress", "Resolved", "Rejected").forEach { s ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { newStatus = s },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = newStatus == s, onClick = { newStatus = s })
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(s, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("Official Action / Resolution Note") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateComplaintStatus(comp.id, newStatus, note)
                        showStatusUpdateDialog = null
                    }
                ) {
                    Text("Update Status")
                }
            },
            dismissButton = {
                TextButton(onClick = { showStatusUpdateDialog = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun MetricTile(
    title: String,
    count: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = count, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
        }
    }
}
