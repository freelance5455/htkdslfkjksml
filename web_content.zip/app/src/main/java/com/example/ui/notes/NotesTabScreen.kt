package com.example.ui.notes

import androidx.compose.runtime.Composable
import com.example.data.model.SubjectEntity

@Composable
fun NotesTabScreen(
    notesState: NotesUiState,
    subjects: List<SubjectEntity>,
    subjectsMap: Map<Long, SubjectEntity>,
    onOpenDrawer: () -> Unit,
    onSearchChange: (String) -> Unit,
    onSortChange: (NoteSortMode) -> Unit,
    onSubjectFilterChange: (Long?) -> Unit,
    onOpenNewNote: () -> Unit,
    onOpenEditNote: (com.example.data.model.NoteEntity) -> Unit,
    onCloseEditor: () -> Unit,
    onTogglePinInList: (com.example.data.model.NoteEntity) -> Unit,
    onTitleChange: (String) -> Unit,
    onDocumentChange: (com.example.data.notes.RichNoteDocument, Boolean) -> Unit,
    onSubjectChange: (Long?) -> Unit,
    onTogglePinInEditor: () -> Unit,
    onFontFamilyChange: (String) -> Unit,
    onFontSizeChange: (Int) -> Unit,
    onAlignmentChange: (com.example.data.notes.NoteAlignment) -> Unit,
    onBlockTypeChange: (Int, com.example.data.notes.BlockType) -> Unit,
    onBlockTextChange: (Int, String) -> Unit,
    onToggleChecklist: (String) -> Unit,
    onAddBlock: (Int, com.example.data.notes.BlockType) -> Unit,
    onRemoveBlock: (Int) -> Unit,
    onApplyInlineSpan: (Int, Int, Int, Boolean?, Boolean?, Boolean?, Boolean?, String?, String?) -> Unit,
    onUndoClick: () -> Unit,
    onRedoClick: () -> Unit,
    onSaveClick: () -> Unit,
    onDeleteNote: (com.example.data.model.NoteEntity) -> Unit,
    onDeleteCurrentEditingNote: () -> Unit
) {
    if (notesState.isEditorOpen) {
        NoteEditorScreen(
            title = notesState.editorTitle,
            document = notesState.editorDocument,
            selectedSubjectId = notesState.editorSubjectId,
            isPinned = notesState.editorIsPinned,
            autosaveStatus = notesState.autosaveStatus,
            canUndo = notesState.canUndo,
            canRedo = notesState.canRedo,
            subjects = subjects,
            onBackClick = onCloseEditor,
            onTitleChange = onTitleChange,
            onDocumentChange = onDocumentChange,
            onSubjectChange = onSubjectChange,
            onTogglePin = onTogglePinInEditor,
            onFontFamilyChange = onFontFamilyChange,
            onFontSizeChange = onFontSizeChange,
            onAlignmentChange = onAlignmentChange,
            onBlockTypeChange = onBlockTypeChange,
            onBlockTextChange = onBlockTextChange,
            onToggleChecklist = onToggleChecklist,
            onAddBlock = onAddBlock,
            onRemoveBlock = onRemoveBlock,
            onApplyInlineSpan = onApplyInlineSpan,
            onUndoClick = onUndoClick,
            onRedoClick = onRedoClick,
            onSaveClick = onSaveClick,
            onDeleteClick = onDeleteCurrentEditingNote
        )
    } else {
        NotesListScreen(
            notes = notesState.filteredNotes,
            searchQuery = notesState.searchQuery,
            sortMode = notesState.sortMode,
            selectedSubjectId = notesState.selectedSubjectFilter,
            subjectsMap = subjectsMap,
            onOpenDrawer = onOpenDrawer,
            onSearchChange = onSearchChange,
            onSortChange = onSortChange,
            onSubjectFilterChange = onSubjectFilterChange,
            onNoteClick = onOpenEditNote,
            onTogglePin = onTogglePinInList,
            onDeleteNote = onDeleteNote,
            onNewNoteClick = onOpenNewNote
        )
    }
}
