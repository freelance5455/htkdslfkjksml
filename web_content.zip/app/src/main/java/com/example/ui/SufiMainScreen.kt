package com.example.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.SufiEntry
import com.example.data.SufiLanguage
import com.example.ui.theme.CandleGlow
import com.example.ui.theme.CandleNightDark
import com.example.ui.theme.GoldGleam
import com.example.ui.theme.GoldLuster
import com.example.ui.theme.GoldLusterBright
import com.example.ui.theme.GoldLusterDark
import com.example.ui.theme.ParchmentSurface
import com.example.ui.theme.SufiCharcoal
import com.example.ui.theme.SufiMaroon
import com.example.ui.theme.SufiMutedText
import com.example.ui.theme.TerracottaDark

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SufiMainScreen(
    viewModel: SufiViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val savedIds by viewModel.savedIds.collectAsState()
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val isMuted by viewModel.soundManager.isMuted.collectAsState()
    val context = LocalContext.current

    var showLangMenu by remember { mutableStateOf(false) }

    val infiniteTransition = rememberInfiniteTransition(label = "candle")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.70f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowAlpha"
    )

    // INITIAL LAUNCH: Full-screen Live Divine Splash / Landing Page matching image artwork
    if (uiState.isFirstLaunch) {
        SufiDivineLandingPage(
            language = currentLanguage,
            onSufiSaysTapped = { viewModel.onSufiSaysTapped() },
            modifier = modifier
        )
        return
    }

    // MAIN INNER CONTAINER: Clean Textured Terracotta Canvas
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(if (uiState.isCandlelitMode) CandleNightDark else TerracottaDark)
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_terracotta_bg),
            contentDescription = null,
            modifier = Modifier
                .fillMaxSize()
                .alpha(if (uiState.isCandlelitMode) 0.45f else 0.85f),
            contentScale = ContentScale.Crop
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            CandleGlow.copy(alpha = glowAlpha * (if (uiState.isCandlelitMode) 0.45f else 0.30f)),
                            Color.Transparent,
                            if (uiState.isCandlelitMode) CandleNightDark.copy(alpha = 0.85f) else TerracottaDark.copy(alpha = 0.75f)
                        ),
                        radius = 1200f
                    )
                )
        )

        CandlelitSanctuaryOverlay(isCandlelitMode = uiState.isCandlelitMode)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // TOP BAR: App Title in Ornate Calligraphic Serif Font + Controls
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box {
                        IconButton(
                            onClick = { viewModel.setSavedSheetVisible(true) },
                            modifier = Modifier
                                .size(42.dp)
                                .testTag("bookmarks_button")
                        ) {
                            Icon(
                                imageVector = if (savedIds.isNotEmpty()) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                                contentDescription = "Saved lines",
                                tint = if (savedIds.isNotEmpty()) GoldLusterBright else GoldLuster.copy(alpha = 0.7f),
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        if (savedIds.isNotEmpty()) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(top = 4.dp, end = 4.dp)
                                    .size(15.dp)
                                    .background(SufiMaroon, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${savedIds.size}",
                                    color = GoldGleam,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    IconButton(
                        onClick = { viewModel.soundManager.toggleMute() },
                        modifier = Modifier
                            .size(42.dp)
                            .testTag("sound_toggle_button")
                    ) {
                        Icon(
                            imageVector = if (isMuted) Icons.Filled.VolumeOff else Icons.Filled.VolumeUp,
                            contentDescription = if (isMuted) "Unmute soundscape" else "Mute soundscape",
                            tint = if (!isMuted) GoldLusterBright else GoldLuster.copy(alpha = 0.45f),
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    IconButton(
                        onClick = { viewModel.toggleCandlelitMode() },
                        modifier = Modifier
                            .size(42.dp)
                            .testTag("candlelit_mode_toggle")
                    ) {
                        Icon(
                            imageVector = if (uiState.isCandlelitMode) Icons.Filled.LightMode else Icons.Filled.DarkMode,
                            contentDescription = if (uiState.isCandlelitMode) "Day parchment mode" else "Candlelit sanctuary mode",
                            tint = if (uiState.isCandlelitMode) CandleGlow else GoldLuster,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                // Center Title: Calligraphic SUFI SOME SAYS... with Miniature Logo Emblem
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.sufi_pure_flame_emblem_1787995182456),
                        contentDescription = "Logo",
                        modifier = Modifier
                            .size(28.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .border(1.dp, GoldLusterBright.copy(alpha = 0.6f), RoundedCornerShape(6.dp)),
                        contentScale = ContentScale.Crop
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "SUFI SOME SAYS",
                                style = MaterialTheme.typography.titleMedium,
                                fontFamily = FontFamily.Serif,
                                fontStyle = FontStyle.Italic,
                                color = GoldLusterBright,
                                letterSpacing = 2.sp,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            BlinkingLoadingDots(modifier = Modifier.padding(start = 2.dp))
                        }
                        Text(
                            text = "A BREATHE OF COMFORT",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Serif,
                            color = GoldLuster.copy(alpha = 0.8f),
                            letterSpacing = 2.sp,
                            fontSize = 8.sp
                        )
                    }
                }

                // Right: Language Selector
                Box {
                    IconButton(
                        onClick = {
                            viewModel.soundManager.playSoftClick()
                            showLangMenu = true
                        },
                        modifier = Modifier
                            .size(42.dp)
                            .testTag("language_toggle")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Translate,
                            contentDescription = "Select language",
                            tint = GoldLusterBright,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = showLangMenu,
                        onDismissRequest = { showLangMenu = false },
                        modifier = Modifier.background(ParchmentSurface)
                    ) {
                        SufiLanguage.values().forEach { lang ->
                            DropdownMenuItem(
                                text = {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = lang.nativeLabel,
                                            fontFamily = FontFamily.Serif,
                                            color = if (currentLanguage == lang) GoldLusterBright else SufiCharcoal,
                                            fontWeight = if (currentLanguage == lang) FontWeight.Bold else FontWeight.Normal
                                        )
                                        if (currentLanguage == lang) {
                                            Text(" ✓", color = GoldLuster, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                },
                                onClick = {
                                    viewModel.setLanguage(lang)
                                    showLangMenu = false
                                }
                            )
                        }
                    }
                }
            }

            if (uiState.peaceMomentsCount > 0) {
                TasbeehPeaceCounter(
                    peaceMomentsCount = uiState.peaceMomentsCount,
                    language = currentLanguage,
                    onTapCounter = { viewModel.onTasbeehTapped() },
                    modifier = Modifier.padding(top = 2.dp, bottom = 4.dp)
                )
            }

            // MIDDLE AREA: Hand-to-Hand Scroll Passing OR Wisdom Unrolling Card
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                if (uiState.isThinking) {
                    ParchmentPassingAnimation(language = currentLanguage)
                } else {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        AnimatedContent(
                            targetState = uiState.currentEntry,
                            transitionSpec = {
                                (fadeIn(animationSpec = tween(600, easing = FastOutSlowInEasing)) +
                                        slideInVertically(animationSpec = tween(600)) { height -> height / 10 })
                                    .togetherWith(
                                        fadeOut(animationSpec = tween(250)) +
                                                slideOutVertically(animationSpec = tween(250)) { height -> -height / 10 }
                                    )
                            },
                            label = "wisdom_transition"
                        ) { entry ->
                            if (entry != null) {
                                UnrollingParchmentCard(
                                    entry = entry,
                                    language = currentLanguage,
                                    isCandlelitMode = uiState.isCandlelitMode,
                                    isSaved = savedIds.contains(entry.id),
                                    onToggleSave = { viewModel.toggleSaveCurrent() },
                                    onCopy = {
                                        viewModel.soundManager.playSoftClick()
                                        copyWisdomToClipboard(context, entry, currentLanguage)
                                    },
                                    onShare = {
                                        viewModel.soundManager.playSoftClick()
                                        viewModel.setShareDialogVisible(true)
                                    }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        // Golden Beveled Action Button: "SUFI SAYS..."
                        GoldenSufiSaysActionButton(
                            language = currentLanguage,
                            isThinking = uiState.isThinking,
                            onClick = { viewModel.onSufiSaysTapped() }
                        )
                    }
                }
            }

            // BOTTOM WATERMARK: Minimal, Subtle & Quiet in inner pages (low opacity)
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 6.dp)
            ) {
                Text(
                    text = "© JOPPAN THINKS",
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Normal,
                    color = GoldLuster.copy(alpha = 0.40f),
                    letterSpacing = 4.sp,
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.testTag("joppan_thinks_inner_watermark")
                )
            }
        }

        if (uiState.showShareDialog && uiState.currentEntry != null) {
            AntiqueCardShareDialog(
                entry = uiState.currentEntry!!,
                language = currentLanguage,
                onDismiss = { viewModel.setShareDialogVisible(false) },
                onShareImage = {
                    viewModel.setShareDialogVisible(false)
                    AntiqueCardGenerator.shareAntiqueCard(context, uiState.currentEntry!!, currentLanguage)
                },
                onShareText = {
                    viewModel.setShareDialogVisible(false)
                    shareWisdom(context, uiState.currentEntry!!, currentLanguage)
                }
            )
        }

        if (uiState.showSavedSheet) {
            SavedQuotesSheet(
                savedEntries = viewModel.getSavedList(),
                currentLanguage = currentLanguage,
                onDismiss = { viewModel.setSavedSheetVisible(false) },
                onSelectEntry = { entry ->
                    viewModel.selectEntry(entry)
                },
                onUnsave = { id ->
                    viewModel.toggleSave(id)
                }
            )
        }
    }
}

/**
 * Three softly blinking dots "..." that pulse to show tranquility / rhythm.
 */
@Composable
fun BlinkingLoadingDots(
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "dots_blink")

    val dot1Alpha by transition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(450, delayMillis = 0, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "dot1"
    )
    val dot2Alpha by transition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(450, delayMillis = 150, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "dot2"
    )
    val dot3Alpha by transition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(450, delayMillis = 300, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "dot3"
    )

    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "•",
            color = GoldLusterBright.copy(alpha = dot1Alpha),
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 1.dp)
        )
        Text(
            text = "•",
            color = GoldLusterBright.copy(alpha = dot2Alpha),
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 1.dp)
        )
        Text(
            text = "•",
            color = GoldLusterBright.copy(alpha = dot3Alpha),
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 1.dp)
        )
    }
}

/**
 * Matching Golden Beveled Action Button "SUFI SAYS..." for inner pages
 */
@Composable
fun GoldenSufiSaysActionButton(
    language: SufiLanguage,
    isThinking: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val buttonLabel = when (language) {
        SufiLanguage.MALAYALAM -> "SUFI SAYS..."
        SufiLanguage.ENGLISH -> "SUFI SAYS..."
        SufiLanguage.DUAL -> "SUFI SAYS..."
    }

    Box(
        modifier = modifier
            .width(260.dp)
            .height(56.dp)
            .shadow(10.dp, RoundedCornerShape(16.dp))
            .clip(RoundedCornerShape(16.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        GoldGleam.copy(alpha = 0.90f),
                        GoldLusterBright,
                        GoldLuster,
                        GoldLusterDark
                    )
                )
            )
            .border(
                width = 1.5.dp,
                brush = Brush.verticalGradient(
                    colors = listOf(GoldGleam, GoldLusterBright, GoldLusterDark)
                ),
                shape = RoundedCornerShape(16.dp)
            )
            .clickable(enabled = !isThinking) { onClick() }
            .testTag("sufi_says_button"),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = buttonLabel,
            style = MaterialTheme.typography.titleMedium,
            fontFamily = FontFamily.Serif,
            fontStyle = FontStyle.Italic,
            fontWeight = FontWeight.Bold,
            color = TerracottaDark,
            fontSize = 18.sp,
            letterSpacing = 2.5.sp,
            textAlign = TextAlign.Center
        )
    }
}

private fun copyWisdomToClipboard(context: Context, entry: SufiEntry, language: SufiLanguage) {
    val textToCopy = buildString {
        when (language) {
            SufiLanguage.MALAYALAM -> append(entry.ml)
            SufiLanguage.ENGLISH -> append("“${entry.en}”")
            SufiLanguage.DUAL -> {
                append(entry.ml)
                append("\n\n")
                append("“${entry.en}”")
            }
        }
        if (entry.isQuote && !entry.author.isNullOrBlank()) {
            append("\n— ${entry.author}")
        }
        append("\n\n(from Sufi Some Says...)")
    }

    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText("Sufi Wisdom", textToCopy)
    clipboard.setPrimaryClip(clip)
    Toast.makeText(context, "Wisdom copied to clipboard", Toast.LENGTH_SHORT).show()
}

private fun shareWisdom(context: Context, entry: SufiEntry, language: SufiLanguage) {
    val shareText = buildString {
        when (language) {
            SufiLanguage.MALAYALAM -> append(entry.ml)
            SufiLanguage.ENGLISH -> append("“${entry.en}”")
            SufiLanguage.DUAL -> {
                append(entry.ml)
                append("\n\n")
                append("“${entry.en}”")
            }
        }
        if (entry.isQuote && !entry.author.isNullOrBlank()) {
            append("\n— ${entry.author}")
        }
        append("\n\n✨ Sufi Some Says...\n© JOPPAN THINKS")
    }

    val sendIntent = Intent().apply {
        action = Intent.ACTION_SEND
        putExtra(Intent.EXTRA_TEXT, shareText)
        type = "text/plain"
    }
    val shareIntent = Intent.createChooser(sendIntent, "Share Sufi Wisdom")
    context.startActivity(shareIntent)
}
