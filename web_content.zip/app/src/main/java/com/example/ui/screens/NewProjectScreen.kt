package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Transform
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.KeystoreEntity
import com.example.ui.theme.BrandPrimary
import com.example.ui.theme.BrandSecondary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.AppBundleViewModel
import com.example.ui.viewmodel.AppScreen

@Composable
fun NewProjectScreen(
    viewModel: AppBundleViewModel,
    keystores: List<KeystoreEntity>,
    isArabic: Boolean
) {
    val context = LocalContext.current
    val currentStep by viewModel.wizardStep.collectAsStateWithLifecycle()
    val sourceType by viewModel.sourceType.collectAsStateWithLifecycle()
    val sourceFileName by viewModel.sourceFileName.collectAsStateWithLifecycle()
    val sourceFileBytes by viewModel.sourceFileBytes.collectAsStateWithLifecycle()
    val targetType by viewModel.targetType.collectAsStateWithLifecycle()
    val autoSign by viewModel.autoSign.collectAsStateWithLifecycle()
    val selectedKeystore by viewModel.selectedKeystore.collectAsStateWithLifecycle()
    val optimizeZipAlign by viewModel.optimizeZipAlign.collectAsStateWithLifecycle()
    val removeDebuggable by viewModel.removeDebuggable.collectAsStateWithLifecycle()
    val compressAssets by viewModel.compressAssets.collectAsStateWithLifecycle()
    val isConverting by viewModel.isConverting.collectAsStateWithLifecycle()
    val progress by viewModel.conversionProgress.collectAsStateWithLifecycle()
    val statusText by viewModel.conversionStatusText.collectAsStateWithLifecycle()
    val logs by viewModel.conversionLogs.collectAsStateWithLifecycle()
    val result by viewModel.lastConversionResult.collectAsStateWithLifecycle()

    var projectNameInput by remember { mutableStateOf("") }

    // File picker launcher
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val input = context.contentResolver.openInputStream(uri)
                val bytes = input?.readBytes()
                val name = uri.lastPathSegment?.split("/")?.lastOrNull() ?: "uploaded_file"
                if (bytes != null) {
                    viewModel.setSourceFile(name, bytes)
                    if (projectNameInput.isBlank()) {
                        projectNameInput = name.substringBeforeLast(".")
                    }
                }
            } catch (_: Exception) { }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("new_project_screen")
    ) {
        Spacer(modifier = Modifier.height(6.dp))

        // Stepper Navigation Header
        StepperHeader(
            currentStep = currentStep,
            isArabic = isArabic,
            onStepClick = { step ->
                if (!isConverting && step < currentStep) {
                    viewModel.setWizardStep(step)
                }
            }
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Step Content Container
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            when (currentStep) {
                1 -> Step1SourceSelection(
                    sourceType = sourceType,
                    sourceFileName = sourceFileName,
                    sourceFileBytes = sourceFileBytes,
                    projectNameInput = projectNameInput,
                    isArabic = isArabic,
                    onTypeChange = { viewModel.setSourceType(it) },
                    onNameChange = { projectNameInput = it },
                    onPickFile = {
                        val mime = if (sourceType == "APK") "application/vnd.android.package-archive" else "application/zip"
                        filePickerLauncher.launch("*/*")
                    },
                    onUseSample = { viewModel.loadSampleSource(sourceType) }
                )
                2 -> Step2OptimizationOptions(
                    sourceType = sourceType,
                    targetType = targetType,
                    optimizeZipAlign = optimizeZipAlign,
                    removeDebuggable = removeDebuggable,
                    compressAssets = compressAssets,
                    isArabic = isArabic,
                    onZipAlignChange = { viewModel.setOptimizeZipAlign(it) },
                    onRemoveDebuggableChange = { viewModel.setRemoveDebuggable(it) },
                    onCompressAssetsChange = { viewModel.setCompressAssets(it) }
                )
                3 -> Step3SigningOptions(
                    autoSign = autoSign,
                    selectedKeystore = selectedKeystore,
                    keystores = keystores,
                    isArabic = isArabic,
                    onAutoSignChange = { viewModel.setAutoSign(it) },
                    onKeystoreSelect = { viewModel.setSelectedKeystore(it) }
                )
                4 -> Step4ExecutionAndResults(
                    isConverting = isConverting,
                    progress = progress,
                    statusText = statusText,
                    logs = logs,
                    result = result,
                    isArabic = isArabic,
                    onViewProjects = { viewModel.setScreen(AppScreen.PROJECTS) },
                    onRestart = { viewModel.setWizardStep(1) }
                )
            }
        }

        // Stepper Navigation Controls
        if (currentStep < 4) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (currentStep > 1) {
                    OutlinedButton(
                        onClick = { viewModel.setWizardStep(currentStep - 1) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(if (isArabic) "السابق" else "Back")
                    }
                }

                Button(
                    onClick = {
                        if (currentStep == 3) {
                            viewModel.setWizardStep(4)
                            viewModel.startConversion(projectNameInput)
                        } else {
                            viewModel.setWizardStep(currentStep + 1)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BrandPrimary),
                    modifier = Modifier.weight(1.5f).testTag("wizard_next_button")
                ) {
                    Text(
                        text = if (currentStep == 3) {
                            if (isArabic) "بدء التحويل والتوقيع 🚀" else "Start Build & Sign 🚀"
                        } else {
                            if (isArabic) "التالي" else "Next"
                        },
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun StepperHeader(
    currentStep: Int,
    isArabic: Boolean,
    onStepClick: (Int) -> Unit
) {
    val steps = if (isArabic) {
        listOf("المصدر", "التحسينات", "التوقيع", "التنفيذ")
    } else {
        listOf("Source", "Optimize", "Sign", "Build")
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        steps.forEachIndexed { index, name ->
            val stepNumber = index + 1
            val isActive = stepNumber == currentStep
            val isDone = stepNumber < currentStep

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.clickable { onStepClick(stepNumber) }
            ) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                isActive -> BrandPrimary
                                isDone -> SuccessGreen
                                else -> MaterialTheme.colorScheme.surfaceVariant
                            }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isDone) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    } else {
                        Text(
                            text = "$stepNumber",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isActive) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.width(6.dp))

                Text(
                    text = name,
                    fontSize = 12.sp,
                    fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                    color = if (isActive) BrandPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun Step1SourceSelection(
    sourceType: String,
    sourceFileName: String,
    sourceFileBytes: ByteArray?,
    projectNameInput: String,
    isArabic: Boolean,
    onTypeChange: (String) -> Unit,
    onNameChange: (String) -> Unit,
    onPickFile: () -> Unit,
    onUseSample: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(
            text = if (isArabic) "1. حدد نوع العملية والملف المراد معالجته:" else "1. Choose Conversion Mode & File:",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = MaterialTheme.colorScheme.onSurface
        )

        // Type Selector Cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ModeSelectCard(
                title = if (isArabic) "تحويل APK إلى AAB" else "APK to AAB",
                subtitle = if (isArabic) "حزمة متجر Google Play" else "Play Store Bundle",
                icon = Icons.Default.Transform,
                isSelected = sourceType == "APK",
                modifier = Modifier.weight(1f),
                onClick = { onTypeChange("APK") }
            )

            ModeSelectCard(
                title = if (isArabic) "تحويل ZIP إلى APK" else "ZIP to APK",
                subtitle = if (isArabic) "تغليف وتوقيع مستقل" else "Web & Asset Packager",
                icon = Icons.Default.FolderZip,
                isSelected = sourceType == "ZIP",
                modifier = Modifier.weight(1f),
                onClick = { onTypeChange("ZIP") }
            )
        }

        // Project Name Input
        OutlinedTextField(
            value = projectNameInput,
            onValueChange = onNameChange,
            label = { Text(if (isArabic) "اسم المشروع المخصص" else "Custom Project Name") },
            placeholder = { Text(if (isArabic) "مثال: تطبيقي التجاري الإصدار 2" else "e.g. My Commercial App v2") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("project_name_input"),
            shape = RoundedCornerShape(12.dp)
        )

        // File Selection Box
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(BrandPrimary.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.FileUpload,
                        contentDescription = "Upload",
                        tint = BrandPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = if (isArabic) "الملف المحدد حالياً:" else "Current Selected File:",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = sourceFileName,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "${(sourceFileBytes?.size ?: 0) / 1024} KB",
                    fontSize = 12.sp,
                    color = SuccessGreen
                )

                Spacer(modifier = Modifier.height(14.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = onPickFile,
                        colors = ButtonDefaults.buttonColors(containerColor = BrandPrimary),
                        modifier = Modifier.testTag("pick_file_button")
                    ) {
                        Text(if (isArabic) "اختيار من الجهاز" else "Pick File")
                    }

                    OutlinedButton(
                        onClick = onUseSample,
                        modifier = Modifier.testTag("use_sample_button")
                    ) {
                        Text(if (isArabic) "عينة تجربة فورية" else "Use Sample")
                    }
                }
            }
        }
    }
}

@Composable
private fun Step2OptimizationOptions(
    sourceType: String,
    targetType: String,
    optimizeZipAlign: Boolean,
    removeDebuggable: Boolean,
    compressAssets: Boolean,
    isArabic: Boolean,
    onZipAlignChange: (Boolean) -> Unit,
    onRemoveDebuggableChange: (Boolean) -> Unit,
    onCompressAssetsChange: (Boolean) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(
            text = if (isArabic) "2. خيارات التحسين ومعمارية الحزمة الناتجة:" else "2. Optimizations & Target Architecture:",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = MaterialTheme.colorScheme.onSurface
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = SuccessGreen.copy(alpha = 0.1f)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = SuccessGreen,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = if (isArabic) "اقتراحات التحسين التلقائية (AI & Best Practices)" else "Smart Recommendations",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = SuccessGreen
                    )
                    Text(
                        text = if (isArabic) "تم تفعيل أفضل إعدادات التوافق مع متجر Google Play وأجهزة أندرويد الحديثة." else "Optimized for Play Store compliance & fast execution.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Toggles List
        SwitchItem(
            title = if (isArabic) "محاذاة Zipalign (4-byte alignment)" else "Zipalign 4-byte boundary",
            desc = if (isArabic) "محاذاة ملفات .so والصور لتسريع قراءتها من الذاكرة العشوائية RAM" else "Aligns uncompressed resources for instant RAM mapping",
            checked = optimizeZipAlign,
            onCheckedChange = onZipAlignChange
        )

        SwitchItem(
            title = if (isArabic) "إزالة راية التصحيح (android:debuggable=false)" else "Remove debuggable flag",
            desc = if (isArabic) "إغلاق منافذ التصحيح للحماية من الهندسة العكسية واختراق الكود" else "Prevents security exploits and reverse engineering",
            checked = removeDebuggable,
            onCheckedChange = onRemoveDebuggableChange
        )

        SwitchItem(
            title = if (isArabic) "ضغط الأصول والموارد (Asset Compression)" else "Asset & Resource Compression",
            desc = if (isArabic) "تقليص حجم ملفات الويب والوسائط لتوفير استهلاك البيانات" else "Reduces app bundle download size significantly",
            checked = compressAssets,
            onCheckedChange = onCompressAssetsChange
        )
    }
}

@Composable
private fun Step3SigningOptions(
    autoSign: Boolean,
    selectedKeystore: KeystoreEntity?,
    keystores: List<KeystoreEntity>,
    isArabic: Boolean,
    onAutoSignChange: (Boolean) -> Unit,
    onKeystoreSelect: (KeystoreEntity?) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(
            text = if (isArabic) "3. إعدادات التوقيع الرقمي والمفاتيح (Digital Signing):" else "3. Digital Signing & Keystore:",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = MaterialTheme.colorScheme.onSurface
        )

        SwitchItem(
            title = if (isArabic) "تفعيل التوقيع التلقائي (Auto-Signing)" else "Enable Auto-Signing",
            desc = if (isArabic) "توقيع الحزمة بشهادة RSA موثقة لتمكين تثبيتها ورفعها للمتجر" else "Signs package with valid RSA certificate for installation",
            checked = autoSign,
            onCheckedChange = onAutoSignChange
        )

        if (autoSign) {
            Text(
                text = if (isArabic) "اختر مفتاح التوقيع:" else "Select Keystore:",
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface
            )

            keystores.forEach { key ->
                val isSelected = selectedKeystore?.id == key.id || (selectedKeystore == null && key.isDefault)
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) BrandPrimary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, BrandPrimary) else null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onKeystoreSelect(key) }
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Key,
                                contentDescription = null,
                                tint = if (isSelected) BrandPrimary else WarningAmber,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = key.alias,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    if (key.isDefault) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(BrandPrimary.copy(alpha = 0.2f))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = if (isArabic) "افتراضي" else "Default",
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = BrandPrimary
                                            )
                                        }
                                    }
                                }
                                Text(
                                    text = "${key.keyType} • صلاحية ${key.validityYears} سنة",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Selected",
                                tint = BrandPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Step4ExecutionAndResults(
    isConverting: Boolean,
    progress: Int,
    statusText: String,
    logs: List<String>,
    result: com.example.engine.ArchiveConverterEngine.ConversionResult?,
    isArabic: Boolean,
    onViewProjects: () -> Unit,
    onRestart: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        if (isConverting) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = if (isArabic) "جاري معالجة وتوقيع الحزمة…" else "Processing & Signing Package…",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    LinearProgressIndicator(
                        progress = { progress / 100f },
                        color = BrandPrimary,
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = statusText,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else if (result != null && result.success) {
            Card(
                colors = CardDefaults.cardColors(containerColor = SuccessGreen.copy(alpha = 0.12f)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Success",
                        tint = SuccessGreen,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (isArabic) "اكتملت العملية بنجاح! 🚀" else "Build Succeeded! 🚀",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = SuccessGreen
                    )
                    Text(
                        text = if (isArabic) "تم إنشاء الحزمة المعتمدة وتوقيعها وحفظها في مشاريعك." else "Package created, signed, and saved to projects.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = if (isArabic) "الحجم الجديد" else "New Size", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(text = "${result.outputSize / 1024} KB", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = if (isArabic) "التوفير" else "Savings", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(text = "${"%.1f".format(result.compressionRatio)}%", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = SuccessGreen)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = if (isArabic) "الملفات" else "Files", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(text = "${result.totalFiles}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = onViewProjects,
                            colors = ButtonDefaults.buttonColors(containerColor = BrandPrimary),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (isArabic) "عرض في مشاريعي" else "View Projects")
                        }

                        OutlinedButton(
                            onClick = onRestart,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (isArabic) "مشروع جديد" else "New Project")
                        }
                    }
                }
            }
        }

        // Live Terminal Logs Window
        Text(
            text = if (isArabic) "سجل العمليات المباشر (Terminal Console):" else "Live Console Logs:",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF070B12))
                .border(1.dp, Color(0xFF19253B), RoundedCornerShape(10.dp))
                .padding(12.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text(
                text = if (logs.isNotEmpty()) logs.joinToString("\n") else "[INFO] في انتظار بدء المعالجة...",
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                color = SuccessGreen,
                lineHeight = 16.sp
            )
        }
    }
}

@Composable
private fun ModeSelectCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) BrandPrimary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
        ),
        shape = RoundedCornerShape(14.dp),
        border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, BrandPrimary) else null,
        modifier = modifier.clickable { onClick() }
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (isSelected) BrandPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun SwitchItem(
    title: String,
    desc: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = desc,
                    fontSize = 11.sp,
                    lineHeight = 15.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = BrandPrimary
                )
            )
        }
    }
}
