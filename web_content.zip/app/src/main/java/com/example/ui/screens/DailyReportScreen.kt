package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarOutline
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.SeedData
import com.example.data.model.Student
import com.example.data.model.StudentRowData
import com.example.export.PdfAndShareHelper
import com.example.ui.AttendanceFilter
import com.example.ui.MainSessionUiState
import com.example.ui.SyncIndicatorState
import com.example.ui.theme.WhatsAppGreen
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DailyReportScreen(
    uiState: MainSessionUiState,
    searchQuery: String,
    attendanceFilter: AttendanceFilter,
    onSearchQueryChange: (String) -> Unit,
    onFilterChange: (AttendanceFilter) -> Unit,
    onSelectClass: (String) -> Unit,
    onSelectDate: (String) -> Unit,
    onUpdateAttendance: (Long, String, Boolean) -> Unit,
    onUpdateField: (Long, String, String) -> Unit,
    onSelectSotd: (String) -> Unit,
    onMarkAllPresent: (Boolean) -> Unit,
    onOpenMonthlySummary: () -> Unit,
    onOpenStudentProfiles: () -> Unit,
    onOpenAdmin: () -> Unit,
    onSwitchRoleOrSignOut: () -> Unit,
    onClearToast: () -> Unit,
    onClearError: () -> Unit
) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    var showDatePicker by remember { mutableStateOf(false) }
    var targetDateStudentNum by remember { mutableStateOf<Long?>(null) }
    var showShareSheet by remember { mutableStateOf(false) }
    var showSotdMenu by remember { mutableStateOf(false) }
    var expandedStudentNum by remember { mutableStateOf<Long?>(null) }
    var pendingSavePdf by remember { mutableStateOf<File?>(null) }

    val savePdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        val src = pendingSavePdf
        if (uri != null && src != null) {
            val ok = PdfAndShareHelper.copyPdfToUri(context, src, uri)
            Toast.makeText(
                context,
                if (ok) "یومیہ PDF محفوظ ہو گئی ✓" else "PDF محفوظ کرنے میں خرابی",
                Toast.LENGTH_SHORT
            ).show()
        }
        pendingSavePdf = null
    }

    LaunchedEffect(uiState.toastMessage) {
        val msg = uiState.toastMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            onClearToast()
        }
    }

    LaunchedEffect(uiState.errorMessage) {
        val err = uiState.errorMessage
        if (!err.isNullOrBlank()) {
            snackbarHostState.showSnackbar(err)
            onClearError()
        }
    }

    val currentClassName = uiState.classes.firstOrNull { it.id == uiState.selectedClassId }?.name ?: ""
    val isAdmin = uiState.member?.role == "admin"

    val filteredStudents by remember(uiState.students, uiState.rows, searchQuery, attendanceFilter) {
        derivedStateOf {
            uiState.students.filter { st ->
                val matchesSearch = searchQuery.isBlank() || st.name.contains(searchQuery.trim(), ignoreCase = true)
                val row = uiState.rows[st.studentNum.toString()] ?: StudentRowData()
                val matchesFilter = when (attendanceFilter) {
                    AttendanceFilter.ALL -> true
                    AttendanceFilter.PRESENT -> row.isPresent
                    AttendanceFilter.ABSENT -> !row.isPresent
                }
                matchesSearch && matchesFilter
            }
        }
    }

    val presentCount by remember(uiState.students, uiState.rows) {
        derivedStateOf {
            uiState.students.count { (uiState.rows[it.studentNum.toString()] ?: StudentRowData()).isPresent }
        }
    }
    val totalSabaqLines by remember(uiState.students, uiState.rows) {
        derivedStateOf {
            uiState.students.sumOf { SeedData.parseNumeric((uiState.rows[it.studentNum.toString()] ?: StudentRowData()).sl) }
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            Surface(
                tonalElevation = 4.dp,
                shadowElevation = 6.dp,
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = onOpenMonthlySummary,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("monthly_summary_button")
                    ) {
                        Icon(Icons.Default.Assessment, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("ماہانہ خلاصہ", maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }

                    Button(
                        onClick = { showShareSheet = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = WhatsAppGreen,
                            contentColor = Color.White
                        ),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                        modifier = Modifier
                            .weight(1.25f)
                            .height(48.dp)
                            .testTag("whatsapp_share_button")
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("واٹس ایپ / شیئر", maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }

                    OutlinedButton(
                        onClick = {
                            val pdf = PdfAndShareHelper.generateDailyReportPdf(
                                context = context,
                                title = uiState.school?.title ?: SeedData.DEFAULT_TITLE,
                                centre = uiState.school?.centre ?: SeedData.DEFAULT_CENTRE,
                                className = currentClassName,
                                dateIso = uiState.selectedDate,
                                students = uiState.students,
                                rows = uiState.rows,
                                sotdStudentNum = uiState.sotd
                            )
                            pendingSavePdf = pdf
                            savePdfLauncher.launch(pdf.name)
                        },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                        modifier = Modifier
                            .weight(0.9f)
                            .height(48.dp)
                            .testTag("quick_pdf_export_button")
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("PDF", maxLines = 1)
                    }
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 16.dp)
        ) {
            // Header Card
            item {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = MaterialTheme.shapes.large,
                    tonalElevation = 2.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            SyncStatusPill(state = uiState.syncState)
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                AssistChip(
                                    onClick = onOpenStudentProfiles,
                                    label = { Text("طلبہ") },
                                    leadingIcon = {
                                        Icon(
                                            Icons.Default.Group,
                                            contentDescription = "Student Profiles",
                                            modifier = Modifier.size(18.dp)
                                        )
                                    },
                                    modifier = Modifier.testTag("student_profiles_button")
                                )
                                if (isAdmin) {
                                    AssistChip(
                                        onClick = onOpenAdmin,
                                        label = { Text("ایڈمن") },
                                        leadingIcon = {
                                            Icon(
                                                Icons.Default.AdminPanelSettings,
                                                contentDescription = "Admin Panel",
                                                modifier = Modifier.size(18.dp)
                                            )
                                        },
                                        modifier = Modifier.testTag("admin_panel_button")
                                    )
                                }
                                IconButton(
                                    onClick = onSwitchRoleOrSignOut,
                                    modifier = Modifier.testTag("logout_button")
                                ) {
                                    Icon(
                                        Icons.AutoMirrored.Filled.Logout,
                                        contentDescription = "Sign Out or Switch Role"
                                    )
                                }
                            }
                        }

                        Text(
                            text = "${uiState.school?.title ?: SeedData.DEFAULT_TITLE} ($currentClassName)",
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.primary
                        )
                        val centreText = uiState.school?.centre ?: SeedData.DEFAULT_CENTRE
                        if (centreText.isNotBlank()) {
                            Text(
                                text = centreText,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        // Admin live class status chips
                        if (isAdmin && uiState.classStatuses.isNotEmpty()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                uiState.classStatuses.forEach { st ->
                                    val label = if (st.hasReport) {
                                        "${st.className}: ✓ ${st.updatedTimeText} (${st.presentCount}/${st.totalStudents})"
                                    } else {
                                        "${st.className}: ابھی تک نہیں"
                                    }
                                    FilterChip(
                                        selected = st.classId == uiState.selectedClassId,
                                        onClick = { onSelectClass(st.classId) },
                                        label = { Text(label, style = MaterialTheme.typography.labelMedium) }
                                    )
                                }
                            }
                        }

                        // Class Switch Tabs for Admin
                        if (isAdmin && uiState.classes.size > 1) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                uiState.classes.forEach { cls ->
                                    FilterChip(
                                        selected = cls.id == uiState.selectedClassId,
                                        onClick = { onSelectClass(cls.id) },
                                        label = { Text(cls.name) },
                                        modifier = Modifier.testTag("class_tab_${cls.id}")
                                    )
                                }
                            }
                        }

                        // Date Selector Row
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                                    MaterialTheme.shapes.medium
                                )
                                .padding(horizontal = 6.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { onSelectDate(shiftIsoDate(uiState.selectedDate, -1)) }) {
                                Icon(Icons.Default.ChevronRight, contentDescription = "Previous Day")
                            }
                            Row(
                                modifier = Modifier
                                    .clickable { showDatePicker = true }
                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                                    .testTag("date_picker_button"),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    Icons.Default.CalendarMonth,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "${uiState.selectedDate} · ${SeedData.urduDayForIso(uiState.selectedDate)}",
                                    style = MaterialTheme.typography.titleMedium
                                )
                            }
                            IconButton(onClick = { onSelectDate(shiftIsoDate(uiState.selectedDate, +1)) }) {
                                Icon(Icons.Default.ChevronLeft, contentDescription = "Next Day")
                            }
                        }
                    }
                }
            }

            // Stats & Quick Actions Strip
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatBadge("کل طلبہ: ${uiState.students.size}")
                    StatBadge("حاضر: $presentCount")
                    StatBadge("سبق لائنیں: ${PdfAndShareHelper.formatNum(totalSabaqLines)}")
                    Box {
                        val sotdName = uiState.students.firstOrNull {
                            it.studentNum.toString() == uiState.sotd
                        }?.name ?: "منتخب کریں"
                        AssistChip(
                            onClick = { showSotdMenu = true },
                            label = { Text("⭐ $sotdName") },
                            colors = AssistChipDefaults.assistChipColors(
                                containerColor = MaterialTheme.colorScheme.secondaryContainer
                            ),
                            modifier = Modifier.testTag("sotd_selector_chip")
                        )
                        DropdownMenu(
                            expanded = showSotdMenu,
                            onDismissRequest = { showSotdMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("— کوئی نہیں —") },
                                onClick = {
                                    onSelectSotd("")
                                    showSotdMenu = false
                                }
                            )
                            uiState.students.forEach { st ->
                                DropdownMenuItem(
                                    text = { Text(st.name) },
                                    onClick = {
                                        onSelectSotd(st.studentNum.toString())
                                        showSotdMenu = false
                                    }
                                )
                            }
                        }
                    }
                    AssistChip(
                        onClick = { onMarkAllPresent(true) },
                        label = { Text("سب فرسٹ ٹائم حاضر") },
                        leadingIcon = {
                            Icon(Icons.Default.DoneAll, contentDescription = null, modifier = Modifier.size(16.dp))
                        },
                        modifier = Modifier.testTag("mark_all_present_button")
                    )
                }
            }

            // Search & Filter Row
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = onSearchQueryChange,
                        placeholder = { Text("طالب علم تلاش کریں…") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("student_search_input")
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = attendanceFilter == AttendanceFilter.ALL,
                            onClick = { onFilterChange(AttendanceFilter.ALL) },
                            label = { Text("سب (${uiState.students.size})") }
                        )
                        FilterChip(
                            selected = attendanceFilter == AttendanceFilter.PRESENT,
                            onClick = { onFilterChange(AttendanceFilter.PRESENT) },
                            label = { Text("حاضر ($presentCount)") }
                        )
                        FilterChip(
                            selected = attendanceFilter == AttendanceFilter.ABSENT,
                            onClick = { onFilterChange(AttendanceFilter.ABSENT) },
                            label = { Text("غیر حاضر (${uiState.students.size - presentCount})") }
                        )
                    }
                }
            }

            if (filteredStudents.isEmpty()) {
                item {
                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 24.dp)
                    ) {
                        Text(
                            text = if (uiState.students.isEmpty()) {
                                "اس کلاس میں ابھی کوئی طالب علم نہیں۔ ایڈمن پینل سے طلبہ شامل کریں۔"
                            } else {
                                "کوئی طالب علم نہیں ملا۔"
                            },
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(24.dp)
                        )
                    }
                }
            } else {
                itemsIndexed(
                    items = filteredStudents,
                    key = { _, st -> "${uiState.selectedClassId}_${st.id}" }
                ) { idx, student ->
                    val row = uiState.rows[student.studentNum.toString()] ?: StudentRowData()
                    val isSotd = uiState.sotd == student.studentNum.toString()
                    val isExpanded = expandedStudentNum == student.studentNum
                    StudentReportCard(
                        index = idx + 1,
                        student = student,
                        row = row,
                        isSotd = isSotd,
                        isExpanded = isExpanded,
                        onToggleExpand = {
                            expandedStudentNum = if (isExpanded) null else student.studentNum
                        },
                        onToggleAttendance = { field, checked ->
                            onUpdateAttendance(student.studentNum, field, checked)
                        },
                        onFieldChange = { key, value ->
                            onUpdateField(student.studentNum, key, value)
                        },
                        onToggleSotd = {
                            onSelectSotd(if (isSotd) "" else student.studentNum.toString())
                        },
                        onPickTargetDate = { targetDateStudentNum = student.studentNum }
                    )
                }
            }
        }
    }

    if (showDatePicker) {
        IsoDatePickerDialog(
            initialIso = uiState.selectedDate,
            onDateSelected = { iso ->
                onSelectDate(iso)
                showDatePicker = false
            },
            onDismiss = { showDatePicker = false }
        )
    }

    targetDateStudentNum?.let { stuNum ->
        val existingTd = uiState.rows[stuNum.toString()]?.td ?: ""
        IsoDatePickerDialog(
            initialIso = existingTd.ifBlank { uiState.selectedDate },
            onDateSelected = { iso ->
                onUpdateField(stuNum, "td", iso)
                targetDateStudentNum = null
            },
            onDismiss = { targetDateStudentNum = null }
        )
    }

    if (showShareSheet) {
        ShareReportSheet(
            title = "یومیہ رپورٹ شیئر / PDF",
            showDetailToggle = true,
            defaultFileName = "Hifz_Daily_${currentClassName}_${uiState.selectedDate}.pdf",
            buildText = { includeDet ->
                PdfAndShareHelper.buildDailyShareText(
                    title = uiState.school?.title ?: SeedData.DEFAULT_TITLE,
                    centre = uiState.school?.centre ?: SeedData.DEFAULT_CENTRE,
                    className = currentClassName,
                    dateIso = uiState.selectedDate,
                    students = uiState.students,
                    rows = uiState.rows,
                    sotdStudentNum = uiState.sotd,
                    includeDetails = includeDet
                )
            },
            generatePdf = {
                PdfAndShareHelper.generateDailyReportPdf(
                    context = context,
                    title = uiState.school?.title ?: SeedData.DEFAULT_TITLE,
                    centre = uiState.school?.centre ?: SeedData.DEFAULT_CENTRE,
                    className = currentClassName,
                    dateIso = uiState.selectedDate,
                    students = uiState.students,
                    rows = uiState.rows,
                    sotdStudentNum = uiState.sotd
                )
            },
            onDismiss = { showShareSheet = false }
        )
    }
}

@Composable
private fun SyncStatusPill(state: SyncIndicatorState) {
    val (bg, fg, icon, text) = when (state) {
        SyncIndicatorState.LIVE_SYNCED -> Quad(
            MaterialTheme.colorScheme.primaryContainer,
            MaterialTheme.colorScheme.onPrimaryContainer,
            Icons.Default.CloudDone,
            "آن لائن ہم آہنگ ✓"
        )
        SyncIndicatorState.SYNCING -> Quad(
            MaterialTheme.colorScheme.secondaryContainer,
            MaterialTheme.colorScheme.onSecondaryContainer,
            Icons.Default.CloudUpload,
            "ہم آہنگ ہو رہا ہے…"
        )
        SyncIndicatorState.CACHED_OFFLINE -> Quad(
            MaterialTheme.colorScheme.surfaceVariant,
            MaterialTheme.colorScheme.onSurfaceVariant,
            Icons.Default.CloudOff,
            "آف لائن کیش ✓"
        )
        SyncIndicatorState.ERROR -> Quad(
            MaterialTheme.colorScheme.errorContainer,
            MaterialTheme.colorScheme.error,
            Icons.Default.CloudOff,
            "سنک خرابی"
        )
    }
    Surface(color = bg, shape = CircleShape) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Icon(icon, contentDescription = null, tint = fg, modifier = Modifier.size(15.dp))
            Text(text, style = MaterialTheme.typography.labelMedium, color = fg)
        }
    }
}

private data class Quad<A, B, C, D>(val a: A, val b: B, val c: C, val d: D)

@Composable
private fun StatBadge(text: String) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = MaterialTheme.shapes.small,
        tonalElevation = 1.dp
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        )
    }
}

@Composable
private fun StudentReportCard(
    index: Int,
    student: Student,
    row: StudentRowData,
    isSotd: Boolean,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    onToggleAttendance: (String, Boolean) -> Unit,
    onFieldChange: (String, String) -> Unit,
    onToggleSotd: () -> Unit,
    onPickTargetDate: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isSotd) {
                MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.35f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isExpanded) 3.dp else 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (row.isPresent) 1.dp else 0.5.dp,
                color = if (row.isPresent) {
                    MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)
                } else {
                    MaterialTheme.colorScheme.outlineVariant
                },
                shape = MaterialTheme.shapes.medium
            )
            .testTag("student_card_${student.studentNum}")
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Header row: # + Name + Attendance checkboxes + Expand
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onToggleExpand),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(
                                if (row.isPresent) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.surfaceVariant
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = index.toString(),
                            style = MaterialTheme.typography.labelMedium,
                            color = if (row.isPresent) MaterialTheme.colorScheme.onPrimary
                            else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = student.name,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        val summaryBits = buildList {
                            if (row.sp.isNotBlank() || row.sl.isNotBlank()) {
                                add("سبق: پ${row.sp} (${row.sl.ifBlank { "0" }} ل)")
                            }
                            if (row.sq.isNotBlank() || row.sqm.isNotBlank()) {
                                add("سبقی: پ${row.sq} غ${row.sqm.ifBlank { "0" }}")
                            }
                            if (row.mp.isNotBlank() || row.mm.isNotBlank()) {
                                add("منزل: پ${row.mp} غ${row.mm.ifBlank { "0" }}")
                            }
                        }
                        if (summaryBits.isNotEmpty()) {
                            Text(
                                text = summaryBits.joinToString("  •  "),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("اول", style = MaterialTheme.typography.labelSmall)
                        Checkbox(
                            checked = row.a1,
                            onCheckedChange = { onToggleAttendance("a1", it) },
                            modifier = Modifier.testTag("att_a1_${student.studentNum}")
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("ثانی", style = MaterialTheme.typography.labelSmall)
                        Checkbox(
                            checked = row.a2,
                            onCheckedChange = { onToggleAttendance("a2", it) },
                            modifier = Modifier.testTag("att_a2_${student.studentNum}")
                        )
                    }
                    IconButton(onClick = onToggleExpand) {
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = "Expand Student Details"
                        )
                    }
                }
            }

            // Always-accessible quick Sabaq row so teachers can log Sabaq in 1 tap without expanding
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CompactField(
                    label = "سبق پارہ",
                    value = row.sp,
                    onValueChange = { onFieldChange("sp", it) },
                    modifier = Modifier.weight(1f),
                    testTag = "sp_${student.studentNum}"
                )
                CompactField(
                    label = "لائنیں",
                    value = row.sl,
                    onValueChange = { onFieldChange("sl", it) },
                    keyboardType = KeyboardType.Number,
                    modifier = Modifier.weight(1f),
                    testTag = "sl_${student.studentNum}"
                )
                CompactField(
                    label = "سبقی غلطی",
                    value = row.sqm,
                    onValueChange = { onFieldChange("sqm", it) },
                    keyboardType = KeyboardType.Number,
                    modifier = Modifier.weight(1f)
                )
                CompactField(
                    label = "منزل غلطی",
                    value = row.mm,
                    onValueChange = { onFieldChange("mm", it) },
                    keyboardType = KeyboardType.Number,
                    modifier = Modifier.weight(1f)
                )
            }

            // Full Sabqi, Manzil, Target Para, SOTD details
            AnimatedVisibility(visible = isExpanded) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    HorizontalDivider()

                    // Sabqi Section
                    Text("سبقی (Sabqi)", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        CompactField("پارہ", row.sq, { onFieldChange("sq", it) }, Modifier.weight(1f))
                        CompactField("غلطیاں", row.sqm, { onFieldChange("sqm", it) }, Modifier.weight(1f), KeyboardType.Number)
                        CompactField("سامع", row.sqs, { onFieldChange("sqs", it) }, Modifier.weight(1.4f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        CompactField("پہلا ربع", row.sq1, { onFieldChange("sq1", it) }, Modifier.weight(1f))
                        CompactField("دوسرا ربع", row.sq2, { onFieldChange("sq2", it) }, Modifier.weight(1f))
                        CompactField("تیسرا ربع", row.sq3, { onFieldChange("sq3", it) }, Modifier.weight(1f))
                        CompactField("چوتھا ربع", row.sq4, { onFieldChange("sq4", it) }, Modifier.weight(1f))
                    }

                    // Manzil Section
                    Text("منزل (Manzil)", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        CompactField("پارہ", row.mp, { onFieldChange("mp", it) }, Modifier.weight(1f))
                        CompactField("غلطیاں", row.mm, { onFieldChange("mm", it) }, Modifier.weight(1f), KeyboardType.Number)
                        CompactField("سامع", row.ms, { onFieldChange("ms", it) }, Modifier.weight(1.4f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        CompactField("پہلا ربع", row.q1, { onFieldChange("q1", it) }, Modifier.weight(1f))
                        CompactField("دوسرا ربع", row.q2, { onFieldChange("q2", it) }, Modifier.weight(1f))
                        CompactField("تیسرا ربع", row.q3, { onFieldChange("q3", it) }, Modifier.weight(1f))
                        CompactField("چوتھا ربع", row.q4, { onFieldChange("q4", it) }, Modifier.weight(1f))
                    }

                    // Target Para + SOTD
                    Text("ہدف پارہ (Target Para)", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CompactField("ہدف لائنیں", row.tl, { onFieldChange("tl", it) }, Modifier.weight(1f), KeyboardType.Number)
                        OutlinedButton(
                            onClick = onPickTargetDate,
                            modifier = Modifier
                                .weight(1.3f)
                                .height(50.dp)
                        ) {
                            Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(row.td.ifBlank { "ہدف تاریخ" }, style = MaterialTheme.typography.bodySmall)
                        }
                        IconButton(onClick = onToggleSotd) {
                            Icon(
                                imageVector = if (isSotd) Icons.Default.Star else Icons.Default.StarOutline,
                                contentDescription = "Student of the Day",
                                tint = if (isSotd) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CompactField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    keyboardType: KeyboardType = KeyboardType.Text,
    testTag: String? = null
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelSmall) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        textStyle = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
        modifier = if (testTag != null) modifier.testTag(testTag) else modifier
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun IsoDatePickerDialog(
    initialIso: String,
    onDateSelected: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val initialMillis = remember(initialIso) {
        try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }
            sdf.parse(initialIso)?.time
        } catch (_: Exception) {
            null
        }
    }
    val state = rememberDatePickerState(initialSelectedDateMillis = initialMillis)
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(
                onClick = {
                    val millis = state.selectedDateMillis
                    if (millis != null) {
                        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
                            timeZone = TimeZone.getTimeZone("UTC")
                        }
                        onDateSelected(sdf.format(Date(millis)))
                    } else {
                        onDismiss()
                    }
                }
            ) {
                Text("منتخب کریں")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("منسوخ") }
        }
    ) {
        DatePicker(state = state)
    }
}

private fun shiftIsoDate(iso: String, deltaDays: Int): String {
    return try {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val cal = Calendar.getInstance()
        cal.time = sdf.parse(iso) ?: return iso
        cal.add(Calendar.DAY_OF_MONTH, deltaDays)
        sdf.format(cal.time)
    } catch (_: Exception) {
        iso
    }
}
