package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.DownloadedEntity
import com.example.data.local.UserCommentEntity
import com.example.data.model.MediaItem
import com.example.data.model.MediaSource
import com.example.data.model.MediaType
import com.example.data.preferences.UserPreferences
import com.example.data.preferences.UserPreferencesRepository
import com.example.data.repository.MediaRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class ProfileSubTab {
    FAVORITES,
    LIKES,
    COMMENTS,
    DOWNLOADED
}

data class ProfileUiState(
    val selectedSubTab: ProfileSubTab = ProfileSubTab.FAVORITES,
    val isDropdownMenuOpen: Boolean = false,
    val selectedPlatformFilter: MediaSource? = null,
    val selectedMediaTypeFilter: MediaType? = null,
    val favoritesList: List<MediaItem> = emptyList(),
    val likesList: List<MediaItem> = emptyList(),
    val commentsList: List<UserCommentEntity> = emptyList(),
    val downloadedList: List<DownloadedEntity> = emptyList(),
    val favoritesCount: Int = 0,
    val likesCount: Int = 0,
    val commentsCount: Int = 0,
    val isEditProfileOpen: Boolean = false,
    val isSettingsOpen: Boolean = false
)

class ProfileViewModel(
    private val mediaRepository: MediaRepository,
    private val preferencesRepository: UserPreferencesRepository,
    private val database: AppDatabase
) : ViewModel() {

    private val _uiState = MutableStateFlow(ProfileUiState())
    val uiState: StateFlow<ProfileUiState> = _uiState.asStateFlow()

    val userPreferences: StateFlow<UserPreferences> = preferencesRepository.userPreferencesFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = UserPreferences()
        )

    init {
        observeData()
    }

    private fun observeData() {
        val dao = database.mediaDao()
        viewModelScope.launch {
            combine(
                mediaRepository.favoriteItems,
                mediaRepository.likedItems,
                mediaRepository.userComments,
                dao.getDownloadedItems()
            ) { favs, likes, comments, downloads ->
                Quad(favs, likes, comments, downloads)
            }.collect { (favs, likes, comments, downloads) ->
                _uiState.value = _uiState.value.copy(
                    favoritesList = favs,
                    likesList = likes,
                    commentsList = comments,
                    downloadedList = downloads,
                    favoritesCount = favs.size,
                    likesCount = likes.size,
                    commentsCount = comments.size
                )
            }
        }
    }

    fun selectSubTab(tab: ProfileSubTab) {
        if (_uiState.value.selectedSubTab == tab) {
            // Clicking active tab slider toggles the dropdown filter menu (arrow icon displayed)
            _uiState.value = _uiState.value.copy(
                isDropdownMenuOpen = !_uiState.value.isDropdownMenuOpen
            )
        } else {
            _uiState.value = _uiState.value.copy(
                selectedSubTab = tab,
                isDropdownMenuOpen = false
            )
        }
    }

    fun toggleDropdown(open: Boolean) {
        _uiState.value = _uiState.value.copy(isDropdownMenuOpen = open)
    }

    fun setPlatformFilter(source: MediaSource?) {
        _uiState.value = _uiState.value.copy(
            selectedPlatformFilter = source,
            isDropdownMenuOpen = false
        )
    }

    fun setMediaTypeFilter(type: MediaType?) {
        _uiState.value = _uiState.value.copy(
            selectedMediaTypeFilter = type,
            isDropdownMenuOpen = false
        )
    }

    fun openEditProfile(open: Boolean) {
        _uiState.value = _uiState.value.copy(isEditProfileOpen = open)
    }

    fun openSettings(open: Boolean) {
        _uiState.value = _uiState.value.copy(isSettingsOpen = open)
    }

    fun saveProfile(name: String, bio: String) {
        viewModelScope.launch {
            preferencesRepository.updateProfile(name, bio)
            _uiState.value = _uiState.value.copy(isEditProfileOpen = false)
        }
    }

    fun deleteDownloadedItem(id: String) {
        viewModelScope.launch {
            database.mediaDao().deleteDownloaded(id)
        }
    }

    private data class Quad<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
}
