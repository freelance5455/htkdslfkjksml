package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Alien
import com.example.ui.theme.*

@Composable
fun UltimateEvolutionBanner(
    visible: Boolean,
    alien: Alien,
    isUltimate: Boolean,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn() + slideInVertically(initialOffsetY = { -it }),
        exit = fadeOut() + slideOutVertically(targetOffsetY = { -it }),
        modifier = modifier
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(
                    if (isUltimate) {
                        Brush.horizontalGradient(
                            listOf(UltimateRedDark, UltimateRed, UltimateRedDark)
                        )
                    } else {
                        Brush.horizontalGradient(
                            listOf(OmnitrixGreenDark, OmnitrixGreen, OmnitrixGreenDark)
                        )
                    }
                )
                .border(
                    2.dp,
                    if (isUltimate) UltimateRedBright else OmnitrixGreenBright,
                    RoundedCornerShape(16.dp)
                )
                .padding(vertical = 8.dp, horizontal = 14.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = if (isUltimate) "⚡ ULTIMATE EVOLUTION ENGAGED! ⚡" else "🧬 STANDARD PROTOCOL RESTORED 🧬",
                    color = if (isUltimate) WhitePure else GalvanBlack,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )

                Text(
                    text = if (isUltimate) alien.ultimateQuote else alien.quote,
                    color = if (isUltimate) AlienGold else GalvanBlack,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}
