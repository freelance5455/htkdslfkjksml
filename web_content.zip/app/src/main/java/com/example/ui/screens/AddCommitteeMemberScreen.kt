package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.DropdownSelector
import com.example.ui.model.CharghatData
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.TextHint
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.AddCommitteeMemberViewModel

@Composable
fun AddCommitteeMemberScreen(
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: AddCommitteeMemberViewModel = viewModel()
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    val currentUser by viewModel.currentUser.collectAsState()
    val name by viewModel.name.collectAsState()
    val designation by viewModel.designation.collectAsState()
    val customDesignation by viewModel.customDesignation.collectAsState()
    val contactNumber by viewModel.contactNumber.collectAsState()
    val wardNumber by viewModel.wardNumber.collectAsState()
    val customWardNumber by viewModel.customWardNumber.collectAsState()
    val unit by viewModel.unit.collectAsState()
    val fbLink by viewModel.fbLink.collectAsState()

    val isLoading by viewModel.isLoading.collectAsState()
    val isSigningIn by viewModel.isSigningIn.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()
    val successMessage by viewModel.successMessage.collectAsState()

    val isCustomDesignation = designation == "+ অন্যান্য/নতুন পদ লিখুন"
    val isCustomWard = wardNumber == "অন্যান্য ওয়ার্ড নম্বর"

    BackHandler {
        onNavigateBack()
    }

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = TextPrimary,
        unfocusedTextColor = TextPrimary,
        focusedLabelColor = TextPrimary,
        unfocusedLabelColor = TextSecondary,
        focusedPlaceholderColor = TextHint,
        unfocusedPlaceholderColor = TextHint,
        focusedBorderColor = EmeraldPrimary,
        unfocusedBorderColor = Color(0xFF9CA3AF),
        focusedContainerColor = Color.White,
        unfocusedContainerColor = Color.White
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF3F4F6))
            .verticalScroll(scrollState)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Navigation Header Bar
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier.testTag("back_to_dashboard_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "ফিরে যান",
                        tint = TextPrimary
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                Column {
                    Text(
                        text = "কমিটি সদস্য এন্ট্রি",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF15803D)
                    )
                    Text(
                        text = "Cloud Firestore ডাটাবেজ সংরক্ষণ ফরম",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = TextSecondary
                    )
                }
            }
        }

        // 2. Authentication Status Banner Card (Google Sign-In via Credential Manager)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (currentUser != null) Color(0xFFF0FDF4) else Color(0xFFEFF6FF)
            ),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (currentUser != null) Color(0xFF86EFAC) else Color(0xFFBFDBFE)
            )
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                if (currentUser != null) {
                    // Signed In State
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFDCFCE7)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CloudDone,
                                    contentDescription = null,
                                    tint = Color(0xFF15803D),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "Firestore কানেকশন সক্রিয়",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF14532D)
                                )
                                Text(
                                    text = currentUser?.displayName ?: currentUser?.email ?: "লগইনকৃত এডমিন",
                                    fontSize = 12.sp,
                                    color = Color(0xFF166534)
                                )
                            }
                        }

                        OutlinedButton(
                            onClick = { viewModel.signOut() },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFCA5A5))
                        ) {
                            Text("সাইন-আউট", fontSize = 11.sp, color = Color(0xFFDC2626), fontWeight = FontWeight.Bold)
                        }
                    }
                } else {
                    // Unauthenticated State
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = Color(0xFF1D4ED8),
                                modifier = Modifier.size(24.dp)
                            )
                            Column {
                                Text(
                                    text = "গুগল সাইন-ইন প্রয়োজন",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF1E3A8A)
                                )
                                Text(
                                    text = "ফায়ারস্টোর সিকিউরিটি নিয়মানুযায়ী ডাটা সেভ করার জন্য সাইন-ইন করুন",
                                    fontSize = 11.sp,
                                    color = Color(0xFF1E40AF),
                                    lineHeight = 15.sp
                                )
                            }
                        }

                        Button(
                            onClick = { viewModel.signInWithGoogle(context) },
                            enabled = !isSigningIn,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1D4ED8)),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                            modifier = Modifier.testTag("google_sign_in_button")
                        ) {
                            if (isSigningIn) {
                                CircularProgressIndicator(
                                    color = Color.White,
                                    strokeWidth = 2.dp,
                                    modifier = Modifier.size(16.dp)
                                )
                            } else {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.AccountCircle, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Text("সাইন-ইন", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // 3. Feedback Messages (Success / Error)
        AnimatedVisibility(visible = successMessage != null) {
            successMessage?.let { msg ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFDCFCE7))
                        .border(1.dp, Color(0xFF86EFAC), RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.CloudDone, contentDescription = null, tint = Color(0xFF15803D), modifier = Modifier.size(20.dp))
                        Text(
                            text = msg,
                            color = Color(0xFF14532D),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        AnimatedVisibility(visible = errorMessage != null) {
            errorMessage?.let { err ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFFEE2E2))
                        .border(1.dp, Color(0xFFFCA5A5), RoundedCornerShape(12.dp))
                        .padding(14.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.ErrorOutline, contentDescription = null, tint = Color(0xFFB91C1C), modifier = Modifier.size(20.dp))
                        Text(
                            text = err,
                            color = Color(0xFF991B1B),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // 4. Main Committee Member Entry Form Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Section Title
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFDCFCE7)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.Badge, contentDescription = null, tint = Color(0xFF15803D), modifier = Modifier.size(16.dp))
                    }
                    Text(
                        text = "কমিটি সদস্যের তথ্যাবলী",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                // 1. Unit Selector
                DropdownSelector(
                    label = "ইউনিট নির্বাচন করুন *",
                    items = CharghatData.units,
                    selectedItem = if (unit.isEmpty()) "-- ইউনিট নির্বাচন করুন --" else unit,
                    onItemSelected = { viewModel.onUnitChange(it) },
                    testTag = "committee_member_unit_select"
                )

                // 2. Member Name Input
                OutlinedTextField(
                    value = name,
                    onValueChange = { viewModel.onNameChange(it) },
                    label = { Text("সদস্যের পূর্ণ নাম *", fontWeight = FontWeight.SemiBold, color = TextSecondary) },
                    placeholder = { Text("যেমন: মো: রফিকুল ইসলাম", color = TextHint) },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = Color(0xFF15803D))
                    },
                    colors = fieldColors,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(color = TextPrimary, fontWeight = FontWeight.SemiBold),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("committee_member_name_input")
                )

                // 3. Designation Dropdown & Custom Field
                DropdownSelector(
                    label = "পদবী নির্বাচন করুন *",
                    items = listOf("-- পদবী নির্বাচন করুন --") + CharghatData.leaderDesignations,
                    selectedItem = if (designation.isEmpty()) "-- পদবী নির্বাচন করুন --" else designation,
                    onItemSelected = { viewModel.onDesignationChange(it) },
                    testTag = "committee_member_designation_select"
                )

                AnimatedVisibility(visible = isCustomDesignation) {
                    OutlinedTextField(
                        value = customDesignation,
                        onValueChange = { viewModel.onCustomDesignationChange(it) },
                        label = { Text("নতুন পদবী লিখুন *", fontWeight = FontWeight.SemiBold, color = TextSecondary) },
                        placeholder = { Text("যেমন: সহ-সম্পাদক, সমাজসেবা সম্পাদক", color = TextHint) },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.Badge, contentDescription = null, tint = Color(0xFF15803D))
                        },
                        colors = fieldColors,
                        textStyle = MaterialTheme.typography.bodyLarge.copy(color = TextPrimary, fontWeight = FontWeight.SemiBold),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("committee_member_designation_input")
                    )
                }

                // 4. Contact Number Input
                OutlinedTextField(
                    value = contactNumber,
                    onValueChange = { viewModel.onContactNumberChange(it) },
                    label = { Text("যোগাযোগ / মোবাইল নম্বর *", fontWeight = FontWeight.SemiBold, color = TextSecondary) },
                    placeholder = { Text("017XXXXXXXX", color = TextHint) },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Phone, contentDescription = null, tint = Color(0xFF15803D))
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    colors = fieldColors,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(color = TextPrimary, fontWeight = FontWeight.SemiBold),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("committee_member_contact_input")
                )

                // 5. Ward Number Dropdown & Custom Field
                val wardList = listOf("-- ওয়ার্ড নির্বাচন করুন --") + CharghatData.wards + listOf("অন্যান্য ওয়ার্ড নম্বর")
                DropdownSelector(
                    label = "ওয়ার্ড নম্বর নির্বাচন করুন *",
                    items = wardList,
                    selectedItem = if (wardNumber.isEmpty()) "-- ওয়ার্ড নির্বাচন করুন --" else wardNumber,
                    onItemSelected = { viewModel.onWardNumberChange(it) },
                    testTag = "committee_member_ward_select"
                )

                AnimatedVisibility(visible = isCustomWard) {
                    OutlinedTextField(
                        value = customWardNumber,
                        onValueChange = { viewModel.onCustomWardNumberChange(it) },
                        label = { Text("ওয়ার্ড নম্বর লিখুন *", fontWeight = FontWeight.SemiBold, color = TextSecondary) },
                        placeholder = { Text("যেমন: ৩নং ওয়ার্ড অথবা ওয়ার্ড নম্বর", color = TextHint) },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.LocationOn, contentDescription = null, tint = Color(0xFF15803D))
                        },
                        colors = fieldColors,
                        textStyle = MaterialTheme.typography.bodyLarge.copy(color = TextPrimary, fontWeight = FontWeight.SemiBold),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("committee_member_ward_input")
                    )
                }

                // 6. Facebook Profile Link (Optional)
                OutlinedTextField(
                    value = fbLink,
                    onValueChange = { viewModel.onFbLinkChange(it) },
                    label = { Text("ফেসবুক প্রোফাইল লিংক (ঐচ্ছিক)", fontWeight = FontWeight.SemiBold, color = TextSecondary) },
                    placeholder = { Text("https://facebook.com/...", color = TextHint) },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Link, contentDescription = null, tint = TextMuted)
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    colors = fieldColors,
                    textStyle = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("committee_member_fb_input")
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Submit Button to Firestore
                Button(
                    onClick = { viewModel.submitForm(context) },
                    enabled = !isLoading,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("submit_committee_member_button")
                ) {
                    if (isLoading) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            CircularProgressIndicator(
                                color = Color.White,
                                strokeWidth = 2.5.dp,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                "Firestore-এ সংরক্ষণ করা হচ্ছে...",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = Color.White
                            )
                        }
                    } else {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudUpload,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                "Firestore-এ সংরক্ষণ করুন",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}
