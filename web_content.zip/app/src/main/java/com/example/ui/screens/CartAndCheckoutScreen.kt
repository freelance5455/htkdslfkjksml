package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ShoppingCartCheckout
import androidx.compose.material.icons.outlined.ShoppingBag
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.CartItem
import com.example.model.DeliveryZone
import com.example.model.OrderItem
import com.example.model.Product
import com.example.model.ShopSettings
import com.example.model.UiState
import com.example.ui.components.ProductThumbnail
import com.example.ui.components.formatBdt
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.AmberNotice
import com.example.ui.theme.CoralAlert
import com.example.ui.theme.ForestEmerald
import com.example.ui.theme.VibrantEmerald

data class ResolvedCartLine(
    val product: Product,
    val qty: Long
)

@Composable
fun CartScreen(
    cartItems: List<CartItem>,
    productsState: UiState<List<Product>>,
    selectedZone: DeliveryZone,
    shopSettings: ShopSettings,
    isMutating: Boolean,
    defaultCustomerName: String,
    defaultPhone: String = "",
    defaultAddress: String = "",
    onSelectZone: (DeliveryZone) -> Unit,
    onUpdateQty: (String, Long) -> Unit,
    onBrowseMarket: () -> Unit,
    onPlaceOrder: (
        customerName: String,
        phone: String,
        address: String,
        note: String,
        items: List<OrderItem>,
        clearCart: Boolean,
        onDone: (String) -> Unit
    ) -> Unit,
    onGoToOrders: () -> Unit,
    modifier: Modifier = Modifier
) {
    val products = (productsState as? UiState.Success)?.data.orEmpty()
    val resolvedLines = remember(cartItems, products) {
        cartItems.mapNotNull { cartItem ->
            val p = products.firstOrNull { it.id == cartItem.productId }
            p?.let { ResolvedCartLine(it, cartItem.qty) }
        }
    }

    val subtotal = resolvedLines.sumOf { it.product.price * it.qty }
    val deliveryFee = if (selectedZone == DeliveryZone.DHAKA_CITY) {
        shopSettings.dhakaDeliveryFee
    } else {
        shopSettings.outsideDeliveryFee
    }
    val grandTotal = subtotal + if (resolvedLines.isNotEmpty()) deliveryFee else 0L

    var showCheckoutSheet by remember { mutableStateOf(false) }
    var confirmedOrderNumber by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(modifier = Modifier.widthIn(max = 720.dp).fillMaxSize()) {
            Spacer(modifier = Modifier.height(14.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "আপনার শপিং কার্ট",
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.onBackground
                )
                if (resolvedLines.isNotEmpty()) {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(50)
                    ) {
                        Text(
                            text = "${resolvedLines.sumOf { it.qty }}টি আইটেম",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))

            if (resolvedLines.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primaryContainer,
                                modifier = Modifier.size(72.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Outlined.ShoppingBag,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(34.dp)
                                    )
                                }
                            }
                            Text(
                                text = "আপনার কার্ট এখনো খালি",
                                style = MaterialTheme.typography.titleLarge
                            )
                            Text(
                                text = "পছন্দের পণ্য বেছে নিন এবং ক্যাশ অন ডেলিভারিতে সহজে অর্ডার করুন।",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                            Button(
                                onClick = onBrowseMarket,
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = ForestEmerald, contentColor = Color.White)
                            ) {
                                Text("পণ্য দেখুন")
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 16.dp)
                ) {
                    items(resolvedLines, key = { it.product.id }) { line ->
                        CartLineCard(
                            line = line,
                            onIncrease = { onUpdateQty(line.product.id, line.qty + 1) },
                            onDecrease = { onUpdateQty(line.product.id, line.qty - 1) },
                            onRemove = { onUpdateQty(line.product.id, 0L) }
                        )
                    }

                    item {
                        DeliveryZoneSelectorCard(
                            selectedZone = selectedZone,
                            dhakaFee = shopSettings.dhakaDeliveryFee,
                            outsideFee = shopSettings.outsideDeliveryFee,
                            onSelectZone = onSelectZone
                        )
                    }
                }

                // Sticky Bottom Order Summary Bar
                Card(
                    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("পণ্যের মূল্য", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(formatBdt(subtotal), style = MaterialTheme.typography.titleMedium)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("ডেলিভারি চার্জ (${selectedZone.label})", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(formatBdt(deliveryFee), style = MaterialTheme.typography.titleMedium)
                        }
                        HorizontalDivider()
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("সর্বমোট (COD)", style = MaterialTheme.typography.titleLarge)
                            Text(
                                text = formatBdt(grandTotal),
                                style = MaterialTheme.typography.headlineMedium,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                        Button(
                            onClick = { showCheckoutSheet = true },
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = ForestEmerald, contentColor = Color.White),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("proceed_checkout_button")
                        ) {
                            Icon(Icons.Filled.ShoppingCartCheckout, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("অর্ডার সম্পন্ন করুন", style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
            }
        }
    }

    if (showCheckoutSheet) {
        BackHandler { showCheckoutSheet = false }
        val orderItems = resolvedLines.map {
            OrderItem(
                productId = it.product.id,
                name = it.product.name,
                price = it.product.price,
                qty = it.qty,
                emoji = it.product.emoji
            )
        }
        CheckoutSheet(
            items = orderItems,
            selectedZone = selectedZone,
            deliveryFee = deliveryFee,
            defaultName = defaultCustomerName,
            defaultPhone = defaultPhone,
            defaultAddress = defaultAddress,
            isMutating = isMutating,
            onSelectZone = onSelectZone,
            onDismiss = { showCheckoutSheet = false },
            onConfirmOrder = { name, phone, address, note ->
                onPlaceOrder(name, phone, address, note, orderItems, true) { orderNo ->
                    showCheckoutSheet = false
                    confirmedOrderNumber = orderNo
                }
            }
        )
    }

    confirmedOrderNumber?.let { orderNo ->
        OrderSuccessDialog(
            orderNumber = orderNo,
            onDismiss = { confirmedOrderNumber = null },
            onViewOrders = {
                confirmedOrderNumber = null
                onGoToOrders()
            }
        )
    }
}

@Composable
private fun CartLineCard(
    line: ResolvedCartLine,
    onIncrease: () -> Unit,
    onDecrease: () -> Unit,
    onRemove: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ProductThumbnail(
                product = line.product,
                modifier = Modifier
                    .size(72.dp)
                    .clip(RoundedCornerShape(14.dp)),
                emojiFontSizeSp = 34
            )
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = line.product.name,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${formatBdt(line.product.price)} × ${line.qty} = ${formatBdt(line.product.price * line.qty)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .clickable(onClick = onDecrease)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.Remove, contentDescription = "কমান", modifier = Modifier.size(16.dp))
                        }
                    }
                    Text("${line.qty}", style = MaterialTheme.typography.titleMedium)
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .clickable(onClick = onIncrease)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.Add, contentDescription = "বাড়ান", modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
            IconButton(onClick = onRemove) {
                Icon(
                    imageVector = Icons.Filled.DeleteOutline,
                    contentDescription = "মুছে ফেলুন",
                    tint = CoralAlert
                )
            }
        }
    }
}

@Composable
fun DeliveryZoneSelectorCard(
    selectedZone: DeliveryZone,
    dhakaFee: Long,
    outsideFee: Long,
    onSelectZone: (DeliveryZone) -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Filled.LocalShipping, contentDescription = null, tint = VibrantEmerald)
                Text("ডেলিভারি এলাকা নির্বাচন করুন", style = MaterialTheme.typography.titleMedium)
            }
            DeliveryZone.entries.forEach { zone ->
                val fee = if (zone == DeliveryZone.DHAKA_CITY) dhakaFee else outsideFee
                val selected = zone == selectedZone
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.background,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onSelectZone(zone) }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = selected, onClick = { onSelectZone(zone) })
                        Column(modifier = Modifier.weight(1f)) {
                            Text(zone.label, style = MaterialTheme.typography.titleSmall)
                            Text(zone.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(
                            text = formatBdt(fee),
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CheckoutSheet(
    items: List<OrderItem>,
    selectedZone: DeliveryZone,
    deliveryFee: Long,
    defaultName: String,
    defaultPhone: String = "",
    defaultAddress: String = "",
    isMutating: Boolean,
    onSelectZone: (DeliveryZone) -> Unit,
    onDismiss: () -> Unit,
    onConfirmOrder: (name: String, phone: String, address: String, note: String) -> Unit
) {
    var customerName by remember { mutableStateOf(defaultName) }
    var phone by remember { mutableStateOf(defaultPhone) }
    var address by remember { mutableStateOf(defaultAddress) }
    var note by remember { mutableStateOf("") }
    var formError by remember { mutableStateOf<String?>(null) }

    val subtotal = items.sumOf { it.price * it.qty }
    val total = subtotal + deliveryFee

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "অর্ডার ও ডেলিভারি তথ্য",
                style = MaterialTheme.typography.headlineSmall
            )

            OutlinedTextField(
                value = customerName,
                onValueChange = { customerName = it; formError = null },
                label = { Text("আপনার নাম *") },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().testTag("checkout_name_input")
            )

            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it.filter { ch -> ch.isDigit() }.take(11); formError = null },
                label = { Text("মোবাইল নম্বর * (01XXXXXXXXX)") },
                placeholder = { Text("017XXXXXXXX") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().testTag("checkout_phone_input")
            )

            OutlinedTextField(
                value = address,
                onValueChange = { address = it; formError = null },
                label = { Text("সম্পূর্ণ ঠিকানা *") },
                placeholder = { Text("বাড়ি, রোড, এলাকা, থানা, জেলা") },
                minLines = 2,
                maxLines = 3,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().testTag("checkout_address_input")
            )

            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text("অতিরিক্ত নির্দেশনা (ঐচ্ছিক)") },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                DeliveryZone.entries.forEach { zone ->
                    val selected = zone == selectedZone
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (selected) ForestEmerald else MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onSelectZone(zone) }
                    ) {
                        Text(
                            text = zone.label,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 10.dp)
                        )
                    }
                }
            }

            Surface(
                color = AmberContainer,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Filled.Payments, contentDescription = null, tint = AmberNotice)
                    Text(
                        text = "পেমেন্ট: Cash on Delivery (পণ্য হাতে পেয়ে মূল্য পরিশোধ করবেন)।",
                        style = MaterialTheme.typography.bodySmall,
                        color = AmberNotice
                    )
                }
            }

            if (formError != null) {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = formError!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            HorizontalDivider()

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("মোট প্রদেয় (${items.sumOf { it.qty }}টি পণ্য + ডেলিভারি)", style = MaterialTheme.typography.bodyMedium)
                Text(
                    text = formatBdt(total),
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.ExtraBold
                )
            }

            Button(
                onClick = {
                    val cleanName = customerName.trim()
                    val cleanPhone = phone.trim()
                    val cleanAddr = address.trim()
                    when {
                        cleanName.isEmpty() -> formError = "অনুগ্রহ করে আপনার নাম লিখুন"
                        !cleanPhone.matches(Regex("^01[0-9]{9}$")) -> formError = "সঠিক ১১ ডিজিটের মোবাইল নম্বর দিন (01XXXXXXXXX)"
                        cleanAddr.length < 4 -> formError = "অনুগ্রহ করে সম্পূর্ণ ডেলিভারি ঠিকানা লিখুন"
                        else -> onConfirmOrder(cleanName, cleanPhone, cleanAddr, note.trim())
                    }
                },
                enabled = !isMutating,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = ForestEmerald, contentColor = Color.White),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("confirm_order_button")
            ) {
                if (isMutating) {
                    CircularProgressIndicator(modifier = Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
                } else {
                    Text("অর্ডার কনফার্ম করুন • ${formatBdt(total)}", style = MaterialTheme.typography.labelLarge)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
fun OrderSuccessDialog(
    orderNumber: String,
    onDismiss: () -> Unit,
    onViewOrders: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Filled.CheckCircle,
                contentDescription = null,
                tint = VibrantEmerald,
                modifier = Modifier.size(54.dp)
            )
        },
        title = {
            Text(
                text = "অর্ডার গ্রহণ করা হয়েছে!",
                style = MaterialTheme.typography.headlineSmall,
                textAlign = TextAlign.Center
            )
        },
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "ধন্যবাদ! আপনার অর্ডারটি সফলভাবে জমা হয়েছে।",
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center
                )
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "অর্ডার নম্বর: $orderNumber",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }
                Text(
                    text = "আমাদের প্রতিনিধি শীঘ্রই আপনার দেওয়া নম্বরে যোগাযোগ করবেন।",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onViewOrders,
                colors = ButtonDefaults.buttonColors(containerColor = ForestEmerald, contentColor = Color.White)
            ) {
                Text("আমার অর্ডার দেখুন")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("ঠিক আছে")
            }
        }
    )
}
