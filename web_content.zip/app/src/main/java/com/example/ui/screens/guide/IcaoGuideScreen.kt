package com.example.ui.screens.guide

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.OperationalDisclaimerCard
import com.example.ui.theme.*

@Composable
fun IcaoGuideScreen(
  modifier: Modifier = Modifier
) {
  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp)
      .testTag("icao_guide_screen"),
    verticalArrangement = Arrangement.spacedBy(14.dp),
    contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
  ) {
    // Header
    item {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.School, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
        Spacer(modifier = Modifier.width(10.dp))
        Column {
          Text(
            text = "راهنمای استانداردهای ایکائو و فرمت GRF",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "ICAO Annex 3, Doc 10066 & Global Reporting Format (GRF 2021)",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }

    // Notice distinguishing education from approved local procedures
    item {
      Surface(
        shape = RoundedCornerShape(10.dp),
        color = StatusYellow.copy(alpha = 0.15f),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Shield, contentDescription = null, tint = StatusYellow)
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "توجه: این بخش صرفاً جهت آموزش و ارتقای دانش فنی کنترلرهای ترافیک هوایی تدوین گردیده است. دستورالعمل‌های محلی و مدارک مصوب سازمان هواپیمایی کشوری ملاک اصلی عملیات هوانوردی است.",
            style = MaterialTheme.typography.labelSmall,
            lineHeight = 18.sp
          )
        }
      }
    }

    // 1. What is SNOWTAM & RCR
    item {
      GuideSectionCard(
        title = "۱. اسنوتام (SNOWTAM) و گزارش وضعیت باند (RCR) چیست؟",
        content = """
          اسنوتام یک سری اختصاصی از پیام‌های نوتام (NOTAM) است که بر اساس فرمت استاندارد هوانوردی ICAO Doc 10066 جهت اطلاع‌رسانی وجود شرایط خطرناک ناشی از برف، یخ، برف آبکی (Slush) یا آب راکد روی سطوح پروازی صادر می‌گردد.
          
          از نوامبر سال ۲۰۲۱، استاندارد بین‌المللی ایکائو با عنوان Global Reporting Format (GRF) لازم‌الاجرا شد. در فرمت جدید، گزارش ارزیابی وضعیت باند تحت عنوان Runway Condition Report (RCR) تهیه شده و در قالب اسنوتام استاندارد مخابره می‌شود.
        """.trimIndent()
      )
    }

    // 2. What is RWYCC
    item {
      GuideSectionCard(
        title = "۲. مفهوم کد وضعیت باند (RWYCC - Runway Condition Code)",
        content = """
          کد RWYCC یک عدد از ۰ تا ۶ است که میزان ترمزگیری و چسبندگی هواپیما به سطح باند را تعیین می‌کند:
          
          • کد ۶ (Good): سطح خشک بدون آلاینده لغزنده. ترمزگیری عادی.
          • کد ۵ (Good): سطح مرطوب (Wet) یا لایه نازک برف خشک کمتر از ۳ میلی‌متر.
          • کد ۴ (Medium to Good): برف متراکم و فشرده در دمای زیر ۱۵- درجه سانتی‌گراد.
          • کد ۳ (Medium): برف فشرده در دمای بالای ۱۵- درجه یا برف تر تا ۳ میلی‌متر.
          • کد ۲ (Medium to Poor): برف آبکی (Slush) یا آب ایستاده با عمق بیش از ۳ میلی‌متر.
          • کد ۱ (Poor): یخ خشک. ترمزگیری بسیار ضعیف و احتمال لغزش بالا.
          • کد ۰ (Less than Poor): یخ مرطوب یا لایه آب روی یخ. بحرانی‌ترین شرایط، کنترل‌پذیری بسیار ناپایدار.
        """.trimIndent()
      )
    }

    // 3. Why runway reported in thirds
    item {
      GuideSectionCard(
        title = "۳. چرا وضعیت باند در سه بخش (Thirds) گزارش می‌شود؟",
        content = """
          باند به ۳ قسمت مساوی طولی تقسیم می‌شود:
          • THIRD 1 (ابتدای باند / Touchdown Zone)
          • THIRD 2 (میانه باند / Mid-point)
          • THIRD 3 (انتهای باند / Roll-out Zone)
          
          دلیل: هواپیما در مراحل مختلف فرود یا برخاست نیازهای دینامیکی متفاوتی دارد. به عنوان مثال، در بخش ابتدایی ترمزها فعال نمی‌شوند و راندمان ایرودینامیک حاکم است، اما در بخش میانی حداکثر ترمزگیری چرخ‌ها اعمال می‌شود. بنابراین گزارش مجزای هر بخش به خلبان و دیسپچر اجازه می‌دهد عملکرد ترمزگیری را بر اساس پرفورمنس دقیق هواپیما محاسبه کنند.
        """.trimIndent()
      )
    }

    // 4. Quick Checklist for ATC Controllers
    item {
      GuideSectionCard(
        title = "۴. مواردی که کنترلر برج یا اپروچ باید سریعاً بررسی کند",
        content = """
          کنترلر ترافیک هوایی (Tower / Approach) هنگام دریافت اسنوتام یا گزارش RCR باید موارد زیر را بلافاصله شناسایی و به ترافیک ورودی/خروجی مخابره کند:
          
          ۱. شماره باند مورد استفاده (Runway Designator).
          ۲. سه رقم کدهای وضعیت باند (RWYCC Thirds)، به ویژه کمترین رقم گزارش شده (Lowest RWYCC).
          ۳. نوع آلاینده (مانند ICE, SLUSH, WET SNOW).
          ۴. عمق آلاینده در صورت وجود (Depth in mm).
          ۵. عرض پاک‌سازی شده باند (Cleared Width) در صورتی که کمتر از عرض کامل باند باشد.
          ۶. هرگونه عملیات شن‌پاشی یا مواد شیمیایی یخ‌زدا (Chemical Treatment).
        """.trimIndent()
      )
    }

    item { OperationalDisclaimerCard() }
  }
}

@Composable
private fun GuideSectionCard(title: String, content: String) {
  Card(
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    border = CardDefaults.outlinedCardBorder(),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Text(
        text = title,
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary
      )
      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = content,
        style = MaterialTheme.typography.bodyMedium,
        lineHeight = 22.sp,
        color = MaterialTheme.colorScheme.onSurface
      )
    }
  }
}
