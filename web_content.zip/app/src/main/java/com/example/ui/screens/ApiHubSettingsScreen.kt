package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.AiModelOption
import com.example.data.model.AiProvider
import com.example.data.model.SubscriptionTier
import com.example.data.model.UserSubscription
import com.example.data.remote.CardCheckoutSession
import com.example.data.remote.GenerationTelemetry
import com.example.data.remote.StripeCheckoutSessionResult
import com.example.data.remote.UpiCheckoutSession
import com.example.data.remote.UpiHandleOption
import com.example.data.repository.ApiHubConfig
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun ApiHubSettingsScreen(
    apiConfig: ApiHubConfig,
    userSubscription: UserSubscription,
    isProcessingBilling: Boolean,
    activeCheckoutSession: StripeCheckoutSessionResult?,
    activeUpiSession: UpiCheckoutSession?,
    activeCardSession: CardCheckoutSession?,
    isTestingEndpoint: Boolean,
    telemetryHistory: List<GenerationTelemetry>,
    userEmail: String?,
    onSelectProvider: (AiProvider) -> Unit,
    onSelectModel: (AiModelOption) -> Unit,
    onSaveStripeKey: (String) -> Unit,
    onStartUpiCheckout: (SubscriptionTier) -> Unit,
    onSelectUpiHandle: (UpiHandleOption) -> Unit,
    onUpiIntentResponse: (String?) -> Unit,
    onVerifyUpiUtr: (String, SubscriptionTier) -> Unit,
    onDismissUpiModal: () -> Unit,
    onStartCardCheckout: (SubscriptionTier) -> Unit,
    onSelectCardSettlementHandle: (UpiHandleOption) -> Unit,
    onAuthorizeCardDetails: (String, String, String, String) -> Boolean,
    onCardSettlementIntentResponse: (String?) -> Unit,
    onVerifyCardOtpOrRrn: (String, SubscriptionTier) -> Unit,
    onDismissCardModal: () -> Unit,
    onStartStripeCheckout: (SubscriptionTier) -> Unit,
    onVerifyCheckoutSession: (String, SubscriptionTier) -> Unit,
    onCancelSubscription: () -> Unit,
    onDismissCheckoutModal: () -> Unit,
    onSaveCredentials: (String, String, String, Boolean, Float, Int, Boolean) -> Unit,
    onTestEndpointConnection: () -> Unit,
    onClearCredentials: () -> Unit,
    onSignOut: () -> Unit,
    onNavigateBackToStudio: () -> Unit
) {
    BackHandler {
        onNavigateBackToStudio()
    }

    var openAiKeyInput by remember(apiConfig.openAiApiKey) { mutableStateOf(apiConfig.openAiApiKey) }
    var anthropicKeyInput by remember(apiConfig.anthropicApiKey) { mutableStateOf(apiConfig.anthropicApiKey) }
    var geminiKeyInput by remember(apiConfig.geminiCustomApiKey) { mutableStateOf(apiConfig.geminiCustomApiKey) }
    var useFirebaseAi by remember(apiConfig.useFirebaseAiForGemini) {
        mutableStateOf(apiConfig.useFirebaseAiForGemini)
    }
    var temperatureSlider by remember(apiConfig.temperature) {
        mutableFloatStateOf(apiConfig.temperature)
    }
    var maxTokensSlider by remember(apiConfig.maxOutputTokens) {
        mutableIntStateOf(apiConfig.maxOutputTokens)
    }
    var includeFullScaffold by remember(apiConfig.includeFullGradleScaffold) {
        mutableStateOf(apiConfig.includeFullGradleScaffold)
    }

    var showOpenAiKey by remember { mutableStateOf(false) }
    var showAnthropicKey by remember { mutableStateOf(false) }
    var showGeminiKey by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("api_hub_settings_list"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Header Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Hub,
                                contentDescription = "Multi-Model API Hub",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Settings & Multi-Model API Hub",
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Configure personal API keys, select your active AI synthesis model, and tune generation parameters.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // 1b. Direct UPI & Card Subscription Hub
        item {
            DirectStripeSubscriptionCard(
                subscription = userSubscription,
                configuredStripeKey = apiConfig.stripeSecretKey,
                isProcessingBilling = isProcessingBilling,
                activeCheckoutSession = activeCheckoutSession,
                activeUpiSession = activeUpiSession,
                activeCardSession = activeCardSession,
                onSaveStripeKey = onSaveStripeKey,
                onStartUpiCheckout = onStartUpiCheckout,
                onSelectUpiHandle = onSelectUpiHandle,
                onUpiIntentResponse = onUpiIntentResponse,
                onVerifyUpiUtr = onVerifyUpiUtr,
                onDismissUpiModal = onDismissUpiModal,
                onStartCardCheckout = onStartCardCheckout,
                onSelectCardSettlementHandle = onSelectCardSettlementHandle,
                onAuthorizeCardDetails = onAuthorizeCardDetails,
                onCardSettlementIntentResponse = onCardSettlementIntentResponse,
                onVerifyCardOtpOrRrn = onVerifyCardOtpOrRrn,
                onDismissCardModal = onDismissCardModal,
                onStartStripeCheckout = onStartStripeCheckout,
                onVerifyCheckoutSession = onVerifyCheckoutSession,
                onCancelSubscription = onCancelSubscription,
                onDismissCheckoutModal = onDismissCheckoutModal
            )
        }

        // 1c. Donate Us — Custom Supporter Contribution Section
        item {
            DonateUsSectionCard(
                onStatusMessage = {}
            )
        }

        // 2. Dynamic Provider & Model Selection Matrix
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Select AI Backend & Model",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    AiProvider.entries.forEach { provider ->
                        val isProviderSelected = apiConfig.selectedProvider == provider
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (isProviderSelected) {
                                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
                                    } else {
                                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                                    }
                                )
                                .border(
                                    width = 1.dp,
                                    color = if (isProviderSelected) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                                    },
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable { onSelectProvider(provider) }
                                .padding(12.dp)
                                .testTag("provider_card_${provider.id.lowercase()}"),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = provider.displayName,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = provider.vendorSubtitle,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                if (isProviderSelected) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = "Selected provider",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }

                            AiModelOption.forProvider(provider).forEach { modelOption ->
                                val isModelSelected = apiConfig.selectedModel == modelOption
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(
                                            if (isModelSelected) {
                                                MaterialTheme.colorScheme.surface
                                            } else {
                                                MaterialTheme.colorScheme.surface.copy(alpha = 0.5f)
                                            }
                                        )
                                        .clickable { onSelectModel(modelOption) }
                                        .padding(10.dp)
                                        .testTag("model_option_${modelOption.modelId}"),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = if (isModelSelected) {
                                            Icons.Default.RadioButtonChecked
                                        } else {
                                            Icons.Default.RadioButtonUnchecked
                                        },
                                        contentDescription = modelOption.displayName,
                                        tint = if (isModelSelected) {
                                            MaterialTheme.colorScheme.primary
                                        } else {
                                            MaterialTheme.colorScheme.onSurfaceVariant
                                        },
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = modelOption.displayName,
                                                style = MaterialTheme.typography.titleSmall,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Surface(
                                                color = MaterialTheme.colorScheme.secondaryContainer,
                                                shape = RoundedCornerShape(4.dp)
                                            ) {
                                                Text(
                                                    text = modelOption.contextBadge,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                        Text(
                                            text = modelOption.architectureNote,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 3. Personal API Key Vault + Generation Parameters + Live Endpoint Ping
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Key,
                            contentDescription = "API Keys",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Personal API Key Credentials",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Text(
                        text = "Keys entered below are stored strictly in private device preferences and used to authenticate direct HTTPS calls to your chosen provider.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = openAiKeyInput,
                        onValueChange = { openAiKeyInput = it },
                        label = { Text("OpenAI API Key (GPT-4o / GPT-4o-mini)") },
                        placeholder = { Text("sk-...") },
                        singleLine = true,
                        visualTransformation = if (showOpenAiKey) {
                            VisualTransformation.None
                        } else {
                            PasswordVisualTransformation()
                        },
                        trailingIcon = {
                            IconButton(onClick = { showOpenAiKey = !showOpenAiKey }) {
                                Icon(
                                    imageVector = if (showOpenAiKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Toggle OpenAI key visibility"
                                )
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("openai_api_key_input"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = anthropicKeyInput,
                        onValueChange = { anthropicKeyInput = it },
                        label = { Text("Anthropic API Key (Claude 3.5 Sonnet)") },
                        placeholder = { Text("sk-ant-...") },
                        singleLine = true,
                        visualTransformation = if (showAnthropicKey) {
                            VisualTransformation.None
                        } else {
                            PasswordVisualTransformation()
                        },
                        trailingIcon = {
                            IconButton(onClick = { showAnthropicKey = !showAnthropicKey }) {
                                Icon(
                                    imageVector = if (showAnthropicKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Toggle Anthropic key visibility"
                                )
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("anthropic_api_key_input"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Use Firebase AI Logic Attestation for Gemini",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Routes Gemini 4 Argon & Gemini 3.5 Flash through App Check without requiring a manual key.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Switch(
                            checked = useFirebaseAi,
                            onCheckedChange = { useFirebaseAi = it },
                            modifier = Modifier.testTag("firebase_ai_toggle")
                        )
                    }

                    OutlinedTextField(
                        value = geminiKeyInput,
                        onValueChange = { geminiKeyInput = it },
                        label = { Text("Custom Google Gemini REST API Key (Optional)") },
                        placeholder = { Text("AIza...") },
                        singleLine = true,
                        visualTransformation = if (showGeminiKey) {
                            VisualTransformation.None
                        } else {
                            PasswordVisualTransformation()
                        },
                        trailingIcon = {
                            IconButton(onClick = { showGeminiKey = !showGeminiKey }) {
                                Icon(
                                    imageVector = if (showGeminiKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Toggle Gemini key visibility"
                                )
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("gemini_api_key_input"),
                        shape = RoundedCornerShape(12.dp)
                    )

                    // Feature 10: Model Generation Parameters & Archive Scaffold Toggle
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "Synthesis Parameters",
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Synthesis & Export Parameters",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Sampling Temperature",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = String.format(Locale.US, "%.2f", temperatureSlider),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Slider(
                            value = temperatureSlider,
                            onValueChange = { temperatureSlider = it },
                            valueRange = 0.0f..1.0f,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("temperature_slider")
                        )
                    }

                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Max Synthesis Tokens",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "$maxTokensSlider tokens",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Slider(
                            value = maxTokensSlider.toFloat(),
                            onValueChange = { maxTokensSlider = it.roundToInt() },
                            valueRange = 1024f..8192f,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("max_tokens_slider")
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Include Full Gradle Scaffold in .zip Exports",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Adds settings.gradle.kts, gradle.properties, and .gitignore to exported archives.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Switch(
                            checked = includeFullScaffold,
                            onCheckedChange = { includeFullScaffold = it },
                            modifier = Modifier.testTag("full_gradle_scaffold_toggle")
                        )
                    }

                    Button(
                        onClick = {
                            onSaveCredentials(
                                openAiKeyInput,
                                anthropicKeyInput,
                                geminiKeyInput,
                                useFirebaseAi,
                                temperatureSlider,
                                maxTokensSlider,
                                includeFullScaffold
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("save_api_keys_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Save,
                            contentDescription = "Save API Hub Configuration",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Save API Hub Configuration",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Live Endpoint Latency Ping Button
                    OutlinedButton(
                        onClick = onTestEndpointConnection,
                        enabled = !isTestingEndpoint,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("test_endpoint_latency_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (isTestingEndpoint) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Pinging ${apiConfig.selectedModel.displayName}...")
                        } else {
                            Icon(
                                imageVector = Icons.Default.NetworkCheck,
                                contentDescription = "Test Active Endpoint Latency",
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Test Active Endpoint Latency (${apiConfig.selectedModel.displayName})")
                        }
                    }

                    OutlinedButton(
                        onClick = {
                            openAiKeyInput = ""
                            anthropicKeyInput = ""
                            geminiKeyInput = ""
                            useFirebaseAi = true
                            onClearCredentials()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("clear_api_keys_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteSweep,
                            contentDescription = "Clear Stored Keys",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Clear Stored Custom Keys")
                    }
                }
            }
        }

        // 4. Live Routing Telemetry Log (No Dummy Data)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Model Routing Telemetry",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    if (telemetryHistory.isEmpty()) {
                        Text(
                            text = stringResource(R.string.empty_telemetry_message),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("empty_telemetry_text")
                        )
                    } else {
                        telemetryHistory.forEach { entry ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                    .padding(10.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${entry.provider.id} • ${entry.modelId}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = "${entry.latencyMs} ms",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.tertiary
                                    )
                                }
                                Text(
                                    text = entry.statusMessage,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }

        // 5. Authenticated Session Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = "Workspace Account",
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Authenticated Studio Session",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = userEmail ?: "Google Account Connected",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    OutlinedButton(
                        onClick = onSignOut,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("sign_out_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = MaterialTheme.colorScheme.error
                        )
                    ) {
                        Text(stringResource(R.string.sign_out))
                    }
                }
            }
        }
    }
}
