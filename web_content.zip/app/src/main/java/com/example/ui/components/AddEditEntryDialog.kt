package com.example.ui.components

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.DeliveryDining
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DeliveryEntry
import com.example.data.repository.DeliveryRepository
import com.example.ui.theme.DexterCyanPrimary
import com.example.ui.theme.DexterEmeraldSecondary
import com.example.ui.theme.DexterSurface
import com.example.ui.theme.DexterSurfaceVariant
import com.example.ui.theme.KamaiGreenGlow

@Composable
fun AddEditEntryDialog(
    initialEntry: DeliveryEntry? = null,
    defaultRate: Double = 14.0,
    currentDateString: String,
    onDismiss: () -> Unit,
    onSave: (date: String, count: Int, rate: Double, notes: String, id: Long) -> Unit
) {
    var dateString by remember { mutableStateOf(initialEntry?.dateString ?: currentDateString) }
    var countText by remember { mutableStateOf((initialEntry?.deliveriesCount ?: 50).toString()) }
    var rateText by remember { mutableStateOf((initialEntry?.ratePerDelivery ?: defaultRate).toInt().toString()) }
    var notes by remember { mutableStateOf(initialEntry?.notes ?: "") }

    val countInt = countText.toIntOrNull() ?: 0
    val rateDouble = rateText.toDoubleOrNull() ?: 0.0
    val totalEarnings by remember { derivedStateOf { (countInt * rateDouble).toInt() } }

    val cycleNumber = remember(dateString) {
        val (_, _, day) = DeliveryRepository.parseCycleInfo(dateString)
        DeliveryRepository.getCycleForDay(day)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DexterSurface,
        shape = RoundedCornerShape(24.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(DexterCyanPrimary.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.DeliveryDining,
                        contentDescription = null,
                        tint = DexterCyanPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = if (initialEntry == null) "Daily Delivery Entry" else "Edit Delivery Entry",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Text(
                        text = "Real-time automatic payout calculation",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .animateContentSize()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Dexter Neon Glowing Hero Calculation Card
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF0B192C),
                    border = BorderStroke(1.5.dp, DexterEmeraldSecondary.copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        DexterEmeraldSecondary.copy(alpha = 0.12f),
                                        Color(0xFF091424)
                                    )
                                )
                            )
                            .padding(16.dp)
                    ) {
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.FlashOn,
                                        contentDescription = null,
                                        tint = DexterEmeraldSecondary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "DAILY KAMAI CALCULATION",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = DexterEmeraldSecondary,
                                        letterSpacing = 0.8.sp
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = DexterCyanPrimary.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = "Cycle $cycleNumber",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = DexterCyanPrimary,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                verticalAlignment = Alignment.Bottom,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "$countInt drops × ₹${rateDouble.toInt()}",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFFCBD5E1)
                                )

                                Text(
                                    text = "₹$totalEarnings",
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Black,
                                    color = KamaiGreenGlow
                                )
                            }
                        }
                    }
                }

                // Date Input
                OutlinedTextField(
                    value = dateString,
                    onValueChange = { dateString = it },
                    label = { Text("Delivery Date (YYYY-MM-DD)") },
                    leadingIcon = { Icon(Icons.Default.CalendarToday, contentDescription = "Date", tint = DexterCyanPrimary) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = DexterCyanPrimary,
                        unfocusedBorderColor = Color(0xFF334155),
                        focusedContainerColor = DexterSurfaceVariant,
                        unfocusedContainerColor = DexterSurfaceVariant
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().testTag("entry_date_input")
                )

                // Deliveries Count Input with +/- adjustments
                Column {
                    OutlinedTextField(
                        value = countText,
                        onValueChange = { countText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Successful Deliveries Count") },
                        leadingIcon = { Icon(Icons.Default.DeliveryDining, contentDescription = "Count", tint = DexterCyanPrimary) },
                        trailingIcon = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = {
                                    val cur = countText.toIntOrNull() ?: 0
                                    if (cur > 0) countText = (cur - 1).toString()
                                }) {
                                    Icon(Icons.Default.Remove, contentDescription = "Minus 1", tint = Color.White)
                                }
                                IconButton(onClick = {
                                    val cur = countText.toIntOrNull() ?: 0
                                    countText = (cur + 1).toString()
                                }) {
                                    Icon(Icons.Default.Add, contentDescription = "Plus 1", tint = DexterEmeraldSecondary)
                                }
                            }
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = DexterCyanPrimary,
                            unfocusedBorderColor = Color(0xFF334155),
                            focusedContainerColor = DexterSurfaceVariant,
                            unfocusedContainerColor = DexterSurfaceVariant
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().testTag("entry_count_input")
                    )

                    // Quick Chips Presets
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(25, 40, 50, 60, 75).forEach { preset ->
                            val isSelected = countInt == preset
                            FilterChip(
                                selected = isSelected,
                                onClick = { countText = preset.toString() },
                                label = { Text("$preset", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = DexterCyanPrimary,
                                    selectedLabelColor = Color(0xFF001E2E),
                                    containerColor = DexterSurfaceVariant,
                                    labelColor = Color(0xFF94A3B8)
                                ),
                                border = BorderStroke(1.dp, if (isSelected) DexterCyanPrimary else Color(0xFF334155))
                            )
                        }
                    }
                }

                // Custom Rate Input with Preset Chips
                Column {
                    OutlinedTextField(
                        value = rateText,
                        onValueChange = { rateText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        label = { Text("Your Rate Per Delivery (₹)") },
                        leadingIcon = { Icon(Icons.Default.CurrencyRupee, contentDescription = "Rate", tint = DexterEmeraldSecondary) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = DexterEmeraldSecondary,
                            unfocusedBorderColor = Color(0xFF334155),
                            focusedContainerColor = DexterSurfaceVariant,
                            unfocusedContainerColor = DexterSurfaceVariant
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().testTag("entry_rate_input")
                    )

                    // Quick Rate presets: 12, 14, 16, 18, 20
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(12, 14, 16, 18, 20).forEach { presetRate ->
                            val isSelected = rateDouble.toInt() == presetRate
                            FilterChip(
                                selected = isSelected,
                                onClick = { rateText = presetRate.toString() },
                                label = { Text("₹$presetRate", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = DexterEmeraldSecondary,
                                    selectedLabelColor = Color(0xFF003822),
                                    containerColor = DexterSurfaceVariant,
                                    labelColor = Color(0xFF94A3B8)
                                ),
                                border = BorderStroke(1.dp, if (isSelected) DexterEmeraldSecondary else Color(0xFF334155))
                            )
                        }
                    }
                }

                // Shift notes
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Shift Note / Platform (Optional)") },
                    placeholder = { Text("e.g. Swiggy, Zomato, Amazon, Blinkit") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = DexterCyanPrimary,
                        unfocusedBorderColor = Color(0xFF334155),
                        focusedContainerColor = DexterSurfaceVariant,
                        unfocusedContainerColor = DexterSurfaceVariant
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        dateString.trim(),
                        countInt,
                        rateDouble,
                        notes.trim(),
                        initialEntry?.id ?: 0L
                    )
                },
                enabled = countInt >= 0 && rateDouble > 0 && dateString.isNotBlank(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = DexterEmeraldSecondary,
                    contentColor = Color(0xFF003822)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("save_entry_button")
            ) {
                Text(
                    text = "Save Entry (₹$totalEarnings)",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 14.sp
                )
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Color(0xFF475569))
            ) {
                Text("Cancel", color = Color(0xFF94A3B8))
            }
        }
    )
}
