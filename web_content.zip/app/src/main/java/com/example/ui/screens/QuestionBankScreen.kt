package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Subject
import com.example.data.model.SubjectProgress
import com.example.data.model.TestCategory
import com.example.ui.theme.DopingAmber
import com.example.ui.theme.DopingAmberDark
import com.example.ui.theme.DopingGreen
import com.example.ui.theme.DopingPrimary
import com.example.ui.theme.DopingPrimaryVariant
import com.example.ui.theme.DopingRed

@Composable
fun QuestionBankScreen(
  testCategories: List<TestCategory>,
  subjectProgress: Map<Subject, SubjectProgress>,
  onStartTestCategory: (TestCategory) -> Unit,
  onStartSubjectQuiz: (Subject?) -> Unit,
  modifier: Modifier = Modifier
) {
  var selectedSubjectFilter by remember { mutableStateOf<Subject?>(null) }
  var searchQuery by remember { mutableStateOf("") }
  var selectedDifficultyFilter by remember { mutableStateOf("Tümü") }

  val filteredTests = testCategories.filter { test ->
    val matchSubject = selectedSubjectFilter == null || test.subject == selectedSubjectFilter
    val matchDifficulty = selectedDifficultyFilter == "Tümü" || test.difficulty.contains(selectedDifficultyFilter, ignoreCase = true)
    val matchSearch = searchQuery.isBlank() ||
      test.title.contains(searchQuery, ignoreCase = true) ||
      test.topicName.contains(searchQuery, ignoreCase = true)
    matchSubject && matchDifficulty && matchSearch
  }

  // Calculate overall performance summary
  val totalSolvedAcrossSubjects = subjectProgress.values.sumOf { it.totalSolved }
  val totalCorrectAcrossSubjects = subjectProgress.values.sumOf { it.correctCount }
  val overallSuccessRate = if (totalSolvedAcrossSubjects > 0) {
    (totalCorrectAcrossSubjects * 100 / totalSolvedAcrossSubjects)
  } else 82

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .testTag("question_bank_screen"),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // 1. Hero Performance Banner
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("question_bank_hero_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
      ) {
        Box(
          modifier = Modifier
            .background(
              Brush.linearGradient(
                colors = listOf(
                  Color(0xFF1E1B4B),
                  DopingPrimary,
                  Color(0xFF312E81)
                )
              )
            )
            .padding(18.dp)
        ) {
          Column(modifier = Modifier.fillMaxWidth()) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(
                  text = "DOPİNG SORU BANKASI",
                  color = DopingAmber,
                  fontWeight = FontWeight.Black,
                  fontSize = 12.sp,
                  letterSpacing = 1.sp
                )
                Text(
                  text = "Kategorize Edilmiş Testler",
                  color = Color.White,
                  fontWeight = FontWeight.ExtraBold,
                  fontSize = 18.sp
                )
              }

              Surface(
                color = Color.White.copy(alpha = 0.2f),
                shape = RoundedCornerShape(12.dp)
              ) {
                Column(
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                  horizontalAlignment = Alignment.CenterHorizontally
                ) {
                  Text(
                    text = "GENEL BAŞARI",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                  )
                  Text(
                    text = "%$overallSuccessRate",
                    color = DopingAmber,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black
                  )
                }
              }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Stats breakdown
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceAround
            ) {
              StatPill(title = "Çözülen Soru", value = "$totalSolvedAcrossSubjects")
              StatPill(title = "Toplam Doğru", value = "$totalCorrectAcrossSubjects")
              StatPill(title = "Kayıtlı Test", value = "${testCategories.size}")
            }
          }
        }
      }
    }

    // 2. Search & Filters
    item {
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        modifier = Modifier
          .fillMaxWidth()
          .testTag("search_question_bank_input"),
        placeholder = { Text("Ders, konu veya test ara...") },
        leadingIcon = {
          Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = DopingPrimary)
        },
        shape = RoundedCornerShape(14.dp),
        singleLine = true
      )
    }

    // 3. Subject Selector Horizontal Row
    item {
      Column {
        Text(
          text = "Ders Bazında İlerleme:",
          style = MaterialTheme.typography.titleSmall,
          fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          item {
            FilterChip(
              selected = selectedSubjectFilter == null,
              onClick = { selectedSubjectFilter = null },
              label = { Text("Tüm Dersler", fontWeight = FontWeight.Bold) },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = DopingPrimary,
                selectedLabelColor = Color.White
              ),
              modifier = Modifier.testTag("filter_all_subjects_qb")
            )
          }
          items(Subject.values()) { subject ->
            val sp = subjectProgress[subject]
            val success = sp?.successRate ?: 0
            FilterChip(
              selected = selectedSubjectFilter == subject,
              onClick = { selectedSubjectFilter = if (selectedSubjectFilter == subject) null else subject },
              label = {
                Text("${subject.iconEmoji} ${subject.title} (%$success)", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
              },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = subject.primaryColor,
                selectedLabelColor = Color.White
              ),
              modifier = Modifier.testTag("filter_subject_${subject.id}_qb")
            )
          }
        }
      }
    }

    // 4. Subject Progress Progress Bar Cards (Visual tracking)
    if (selectedSubjectFilter != null) {
      val sp = subjectProgress[selectedSubjectFilter] ?: SubjectProgress(selectedSubjectFilter!!)
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "${selectedSubjectFilter!!.iconEmoji} ${selectedSubjectFilter!!.title} İstatistikleri",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
              )
              Surface(
                color = DopingGreen.copy(alpha = 0.15f),
                shape = RoundedCornerShape(6.dp)
              ) {
                Text(
                  text = "Başarı: %${sp.successRate}",
                  color = DopingGreen,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(10.dp))

            LinearProgressIndicator(
              progress = { sp.successRate / 100f },
              modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp)),
              color = selectedSubjectFilter!!.primaryColor,
              trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(text = "Toplam: ${sp.totalSolved} Soru", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
              Text(text = "Doğru: ${sp.correctCount}", fontSize = 11.sp, color = DopingGreen, fontWeight = FontWeight.Bold)
              Text(text = "Yanlış: ${sp.wrongCount}", fontSize = 11.sp, color = DopingRed, fontWeight = FontWeight.Bold)
              Text(text = "Net: ${String.format("%.2f", sp.net)}", fontSize = 11.sp, color = DopingPrimary, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }

    // 5. Test Categories Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "Mevcut İnteraktif Testler (${filteredTests.size})",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )

        Button(
          onClick = { onStartSubjectQuiz(selectedSubjectFilter) },
          colors = ButtonDefaults.buttonColors(containerColor = DopingPrimary),
          shape = RoundedCornerShape(12.dp),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
          modifier = Modifier.testTag("start_quick_mixed_quiz")
        ) {
          Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Karma Başlat", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
      }
    }

    // 6. Test Cards List
    if (filteredTests.isEmpty()) {
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Icon(imageVector = Icons.Default.Quiz, contentDescription = null, tint = DopingPrimary, modifier = Modifier.size(40.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text("Arama kriterinize uygun test bulunamadı.", fontWeight = FontWeight.Bold)
          }
        }
      }
    } else {
      items(filteredTests) { test ->
        TestCategoryCard(
          test = test,
          onStart = { onStartTestCategory(test) }
        )
      }
    }
  }
}

@Composable
private fun StatPill(title: String, value: String) {
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Text(text = title, color = Color.White.copy(alpha = 0.75f), fontSize = 10.sp)
    Spacer(modifier = Modifier.height(2.dp))
    Text(text = value, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Black)
  }
}

@Composable
private fun TestCategoryCard(
  test: TestCategory,
  onStart: () -> Unit
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onStart() }
      .testTag("test_category_card_${test.id}"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Surface(
          color = test.subject.primaryColor.copy(alpha = 0.15f),
          shape = RoundedCornerShape(6.dp)
        ) {
          Text(
            text = "${test.subject.iconEmoji} ${test.subject.title}",
            color = test.subject.primaryColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
          )
        }

        Surface(
          color = when (test.difficulty) {
            "Kolay" -> DopingGreen.copy(alpha = 0.15f)
            "Zor" -> DopingRed.copy(alpha = 0.15f)
            else -> DopingAmber.copy(alpha = 0.15f)
          },
          shape = RoundedCornerShape(6.dp)
        ) {
          Text(
            text = test.difficulty,
            color = when (test.difficulty) {
              "Kolay" -> DopingGreen
              "Zor" -> DopingRed
              else -> DopingAmberDark
            },
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = test.title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )

      Text(
        text = "Konu: ${test.topicName}",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "• ${test.questionCount} Soru",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Text(
            text = "• ~${test.estimatedMinutes} Dk",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          if (test.isCompleted) {
            Text(
              text = "• En İyi: ${test.bestScore}",
              fontSize = 11.sp,
              color = DopingGreen,
              fontWeight = FontWeight.Bold
            )
          }
        }

        Button(
          onClick = onStart,
          colors = ButtonDefaults.buttonColors(containerColor = test.subject.primaryColor),
          shape = RoundedCornerShape(10.dp),
          contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
        ) {
          Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = if (test.isCompleted) "Tekrar Çöz" else "Başlat",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }
  }
}
