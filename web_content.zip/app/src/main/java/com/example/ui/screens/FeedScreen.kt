package com.example.ui.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.VideoEntity
import com.example.ui.components.VideoPlayerItem
import com.example.ui.theme.ZingBlack
import com.example.ui.theme.ZingGold
import com.example.ui.theme.ZingNeonPink
import com.example.ui.theme.ZingTextPrimary
import com.example.ui.theme.ZingTextSecondary

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FeedScreen(
    videos: List<VideoEntity>,
    onLikeClick: (VideoEntity) -> Unit,
    onCommentClick: (VideoEntity) -> Unit,
    onShareClick: (VideoEntity) -> Unit,
    onGiftClick: (VideoEntity) -> Unit,
    onFollowClick: (String) -> Unit,
    onReportClick: (VideoEntity) -> Unit,
    onBlockCreatorClick: (String) -> Unit,
    onCreatorProfileClick: (String) -> Unit,
    onOpenSearch: () -> Unit,
    onOpenCreatorStudio: () -> Unit,
    onOpenWebFrontend: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var selectedFeedTab by remember { mutableStateOf("For You") } // "Following" vs "For You"
    val filteredVideos = remember(videos, selectedFeedTab) {
        if (selectedFeedTab == "Following") {
            videos.take(2) // Simulates followed creators
        } else {
            videos
        }
    }

    val pagerState = rememberPagerState(pageCount = { filteredVideos.size })

    Box(modifier = modifier.fillMaxSize().background(ZingBlack)) {
        if (filteredVideos.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
                    Text(
                        text = "No short videos yet",
                        color = ZingTextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Be the first creator to upload a reel on Sinji Shorts!",
                        color = ZingTextSecondary,
                        fontSize = 14.sp
                    )
                }
            }
        } else {
            // Vertical short video feed (swipe up / down)
            VerticalPager(
                state = pagerState,
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("vertical_video_pager")
            ) { page ->
                val video = filteredVideos[page]
                val isCurrentPage = pagerState.currentPage == page

                VideoPlayerItem(
                    video = video,
                    isCurrentPage = isCurrentPage,
                    onLikeClick = { onLikeClick(video) },
                    onCommentClick = { onCommentClick(video) },
                    onShareClick = { onShareClick(video) },
                    onGiftClick = { onGiftClick(video) },
                    onFollowClick = { onFollowClick(video.creatorId) },
                    onReportClick = { onReportClick(video) },
                    onBlockCreatorClick = { onBlockCreatorClick(video.creatorId) },
                    onCreatorProfileClick = onCreatorProfileClick
                )
            }
        }

        // Top Navigation Bar (Branded Broken Heart + Following | For You + Monetization Pill + Search)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Sinji Shorts Logo with clean broken heart vector
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0x66000000))
                    .padding(horizontal = 8.dp, vertical = 5.dp)
            ) {
                androidx.compose.material3.Icon(
                    painter = androidx.compose.ui.res.painterResource(id = com.example.R.drawable.ic_broken_heart),
                    contentDescription = "Sinji Shorts Logo",
                    tint = ZingNeonPink,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(5.dp))
                Text(
                    text = "Sinji",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Feed Switching Tabs (Following | For You)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                // Following Tab
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.clickable { selectedFeedTab = "Following" }
                ) {
                    Text(
                        text = "Following",
                        color = if (selectedFeedTab == "Following") ZingTextPrimary else ZingTextSecondary.copy(alpha = 0.7f),
                        fontSize = 16.sp,
                        fontWeight = if (selectedFeedTab == "Following") FontWeight.Bold else FontWeight.Normal
                    )
                    if (selectedFeedTab == "Following") {
                        Spacer(modifier = Modifier.height(3.dp))
                        Box(
                            modifier = Modifier
                                .size(width = 24.dp, height = 3.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(ZingNeonPink)
                        )
                    }
                }

                // For You Tab
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.clickable { selectedFeedTab = "For You" }
                ) {
                    Text(
                        text = "For You",
                        color = if (selectedFeedTab == "For You") ZingTextPrimary else ZingTextSecondary.copy(alpha = 0.7f),
                        fontSize = 16.sp,
                        fontWeight = if (selectedFeedTab == "For You") FontWeight.Bold else FontWeight.Normal
                    )
                    if (selectedFeedTab == "For You") {
                        Spacer(modifier = Modifier.height(3.dp))
                        Box(
                            modifier = Modifier
                                .size(width = 24.dp, height = 3.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(ZingNeonPink)
                        )
                    }
                }
            }

            // Actions Row (Web Frontend + Monetization + Search)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                // HTML Web Frontend Switcher Pill
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0x66000000),
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .clickable { onOpenWebFrontend() }
                        .testTag("top_web_frontend_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = "🌐",
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = "Web UI",
                            color = ZingNeonPink,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0x66000000),
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .clickable { onOpenCreatorStudio() }
                        .testTag("top_monetization_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MonetizationOn,
                            contentDescription = "Monetization",
                            tint = ZingGold,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = "₹ Earn",
                            color = ZingGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Search Button
                IconButton(
                    onClick = onOpenSearch,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(0x55000000))
                        .testTag("feed_search_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}
