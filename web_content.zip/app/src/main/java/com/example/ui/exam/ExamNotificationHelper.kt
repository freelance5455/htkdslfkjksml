package com.example.ui.exam

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.R
import com.example.data.model.ExamEntity

object ExamNotificationHelper {

    const val CHANNEL_ID = "daily_study_exam_reminders"
    const val CHANNEL_NAME = "Exam Countdown Reminders"

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Reminders for upcoming study exams at 30, 7, and 1 days before."
            }
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    fun hasNotificationPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun postExamReminderNotification(
        context: Context,
        exam: ExamEntity,
        daysLeft: Long
    ) {
        createNotificationChannel(context)

        if (!hasNotificationPermission(context)) return

        val title = when (daysLeft) {
            0L -> "Exam Today: ${exam.name}"
            1L -> "Exam Tomorrow: ${exam.name}"
            else -> "Exam Countdown: ${exam.name}"
        }

        val message = when (daysLeft) {
            0L -> "${exam.name} is scheduled for today. Best of luck!"
            1L -> "${exam.name} is tomorrow! Final review time."
            else -> "$daysLeft days left until ${exam.name} (${exam.date}). Stay on track with your study sessions!"
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_study_logo)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()

        try {
            NotificationManagerCompat.from(context).notify(exam.id.toInt().coerceAtLeast(100), notification)
        } catch (_: SecurityException) {}
    }
}
