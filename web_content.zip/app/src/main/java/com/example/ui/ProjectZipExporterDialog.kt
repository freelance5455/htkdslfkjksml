package com.example.ui

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import java.io.File

const val BUNDLED_PROJECT_ZIP_ASSET = "MoonChess-Reader-Android-Project.zip"

@Composable
fun ProjectZipExporterDialog(
    onDismiss: () -> Unit,
    onExportStatus: (String) -> Unit
) {
    val context = LocalContext.current
    var statusNote by remember { mutableStateOf<String?>(null) }

    val saveZipLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip")
    ) { destUri ->
        if (destUri != null) {
            val result = runCatching {
                context.assets.open(BUNDLED_PROJECT_ZIP_ASSET).use { input ->
                    context.contentResolver.openOutputStream(destUri)?.use { output ->
                        input.copyTo(output)
                    } ?: error("Unable to open destination file.")
                }
            }
            if (result.isSuccess) {
                val msg = "Saved MoonChess-Reader-Android-Project.zip successfully!"
                statusNote = msg
                onExportStatus(msg)
            } else {
                val msg = "Export error: ${result.exceptionOrNull()?.localizedMessage ?: "Bundle unavailable"}"
                statusNote = msg
                onExportStatus(msg)
            }
        }
    }

    fun shareZipExternally() {
        val result = runCatching {
            val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
            val outZip = File(exportDir, BUNDLED_PROJECT_ZIP_ASSET)
            context.assets.open(BUNDLED_PROJECT_ZIP_ASSET).use { input ->
                outZip.outputStream().use { output ->
                    input.copyTo(output)
                }
            }
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                outZip
            )
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/zip"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "MoonChess Reader — Complete Android Project (.zip)")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Export Android Project (.zip)"))
        }
        if (result.isFailure) {
            val msg = "Share error: ${result.exceptionOrNull()?.localizedMessage ?: "Bundle unavailable"}"
            statusNote = msg
            onExportStatus(msg)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Export Complete Android Project (.ZIP)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Includes 100% of the Android Studio project needed to build the APK: Gradle scripts, Kotlin + Compose code, 4-phase diagram scanner, Room database, fonts, adaptive launcher icons, debug.keystore, and a 1-click GitHub Actions APK builder.",
                    style = MaterialTheme.typography.bodyMedium
                )

                Button(
                    onClick = { saveZipLauncher.launch(BUNDLED_PROJECT_ZIP_ASSET) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("dialog_save_zip_button")
                ) {
                    Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Save .ZIP to Downloads", fontWeight = FontWeight.SemiBold)
                }

                OutlinedButton(
                    onClick = { shareZipExternally() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("dialog_share_zip_button")
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Share / Send .ZIP (Drive, Email, Files)")
                }

                statusNote?.let { note ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = note,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Using AI Studio on a Phone Browser?",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                        Text(
                            text = "• Saving inside AI Studio's cloud emulator saves to the virtual emulator's storage.\n" +
                                "• To download directly to your real phone: tap the Code (<>) tab at the top of AI Studio, find MoonChess-Reader-Android-Project.zip at the very top of the file list, and tap Download — OR open Chrome's ⋮ menu → turn on Desktop site → tap the Download ZIP / APK icon in the top-right bar.",
                            fontSize = 11.5.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}
