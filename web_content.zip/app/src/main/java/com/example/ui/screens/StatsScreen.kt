package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.StudySession
import com.example.data.model.Subject
import com.example.ui.components.AddManualSessionDialog
import com.example.ui.components.SessionDetailDialog
import com.example.ui.theme.AestheticBlack
import com.example.ui.theme.BorderGrey
import com.example.ui.theme.CardGrey
import com.example.ui.theme.DeepPink
import com.example.ui.theme.KawaiiPink
import com.example.ui.theme.MutedGrey
import com.example.ui.theme.PastelPinkBg
import com.example.ui.theme.PastelPinkContainer
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RoseTint
import com.example.ui.theme.TextGrey
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun StatsScreen(
    subjects: List<Subject>,
    sessions: List<StudySession>,
    dailyGoalMinutes: Int,
    onDeleteSession: (Long) -> Unit,
    onAddManualSession: (Subject, Int, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedSessionForDetail by remember { mutableStateOf<StudySession?>(null) }
    var showManualLogDialog by remember { mutableStateOf(false) }

    // Midnight today
    val todayCal = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }
    val startOfToday = todayCal.timeInMillis

    // Today's statistics
    val todaySessions = sessions.filter { it.timestamp >= startOfToday && it.sessionType == "FOCUS" }
    val todayTotalSeconds = todaySessions.sumOf { it.durationSeconds }
    val todayMinutes = todayTotalSeconds / 60
    val todayHours = todayMinutes / 60
    val todayRemainMins = todayMinutes % 60
    val goalPercent = if (dailyGoalMinutes > 0) ((todayMinutes.toFloat() / dailyGoalMinutes) * 100).toInt() else 0

    // Streak calculation
    var currentStreak = 0
    val checkCal = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }
    var dayOffset = 0
    val studiedToday = sessions.any { it.timestamp >= checkCal.timeInMillis && it.sessionType == "FOCUS" }
    if (!studiedToday) {
        dayOffset = 1
        checkCal.add(Calendar.DAY_OF_YEAR, -1)
    }
    while (dayOffset < 30) {
        val dayStart = checkCal.timeInMillis
        val dayEnd = dayStart + 24 * 3600 * 1000L
        val hadStudy = sessions.any { it.timestamp in dayStart until dayEnd && it.sessionType == "FOCUS" }
        if (hadStudy) {
            currentStreak++
            checkCal.add(Calendar.DAY_OF_YEAR, -1)
            dayOffset++
        } else {
            break
        }
    }

    // Weekly 7-day stats
    val dayFormat = SimpleDateFormat("EEE", Locale.getDefault())
    val weekDays = (6 downTo 0).map { daysAgo ->
        val c = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            add(Calendar.DAY_OF_YEAR, -daysAgo)
        }
        val s = c.timeInMillis
        val e = s + 24 * 3600 * 1000L
        val dayMins = sessions
            .filter { it.timestamp in s until e && it.sessionType == "FOCUS" }
            .sumOf { it.durationSeconds } / 60
        Triple(dayFormat.format(Date(s)), dayMins, daysAgo == 0)
    }
    val maxWeeklyMins = (weekDays.maxOfOrNull { it.second } ?: 60).coerceAtLeast(60)

    // Subject breakdown
    val allFocusSessions = sessions.filter { it.sessionType == "FOCUS" }
    val totalFocusMins = allFocusSessions.sumOf { it.durationSeconds } / 60
    val subjectBreakdowns = subjects.mapNotNull { subj ->
        val mins = allFocusSessions.filter { it.subjectId == subj.id }.sumOf { it.durationSeconds } / 60
        if (mins > 0) {
            val pct = if (totalFocusMins > 0) (mins.toFloat() / totalFocusMins) else 0f
            Triple(subj, mins, pct)
        } else null
    }.sortedByDescending { it.second }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(PastelPinkBg)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "📊 Focus Analytics",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = (-0.5).sp
                        ),
                        color = AestheticBlack
                    )
                    Text(
                        text = "Daily study time and historical trends",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextGrey
                    )
                }

                OutlinedButton(
                    onClick = { showManualLogDialog = true },
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = AestheticBlack),
                    border = androidx.compose.foundation.BorderStroke(1.dp, AestheticBlack),
                    modifier = Modifier.testTag("log_session_btn")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Log", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                }
            }
        }

        // Today's Big Metric Card
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderGrey),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "TODAY'S STUDY TIME",
                        style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.sp, fontWeight = FontWeight.Bold),
                        color = TextGrey
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (todayHours > 0) "${todayHours}h ${todayRemainMins}m" else "${todayRemainMins}m",
                            style = MaterialTheme.typography.displaySmall.copy(fontWeight = FontWeight.Bold),
                            color = AestheticBlack
                        )

                        // Streak badge
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = PastelPinkContainer,
                            border = androidx.compose.foundation.BorderStroke(1.dp, DeepPink.copy(alpha = 0.4f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.LocalFireDepartment,
                                    contentDescription = "Streak",
                                    tint = DeepPink,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "$currentStreak day streak",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = DeepPink
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Progress toward daily goal
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Daily Goal: $dailyGoalMinutes min",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextGrey
                        )
                        Text(
                            text = "$goalPercent%",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            color = DeepPink
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    LinearProgressIndicator(
                        progress = { (todayMinutes.toFloat() / dailyGoalMinutes.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = DeepPink,
                        trackColor = CardGrey,
                        strokeCap = StrokeCap.Round
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Mini Stats Footer
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Sessions", style = MaterialTheme.typography.labelSmall, color = TextGrey)
                            Text(
                                "${todaySessions.size}",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = AestheticBlack
                            )
                        }
                        Box(modifier = Modifier.width(1.dp).height(28.dp).background(BorderGrey))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Total Focus", style = MaterialTheme.typography.labelSmall, color = TextGrey)
                            val totalH = totalFocusMins / 60
                            val totalM = totalFocusMins % 60
                            Text(
                                "${totalH}h ${totalM}m",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = AestheticBlack
                            )
                        }
                        Box(modifier = Modifier.width(1.dp).height(28.dp).background(BorderGrey))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Avg Session", style = MaterialTheme.typography.labelSmall, color = TextGrey)
                            val avgMin = if (todaySessions.isNotEmpty()) todayMinutes / todaySessions.size else 0
                            Text(
                                "${avgMin}m",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = AestheticBlack
                            )
                        }
                    }
                }
            }
        }

        // 7-Day Weekly Chart
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderGrey),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Weekly Focus (Past 7 Days)",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = AestheticBlack
                        )
                        Icon(
                            imageVector = Icons.Default.DateRange,
                            contentDescription = null,
                            tint = TextGrey,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Visual Bar Chart
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        weekDays.forEach { (label, minutes, isToday) ->
                            val heightFraction = (minutes.toFloat() / maxWeeklyMins.toFloat()).coerceIn(0.08f, 1f)
                            val barColor = if (isToday) DeepPink else CardGrey

                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Bottom,
                                modifier = Modifier.weight(1f)
                            ) {
                                if (minutes > 0) {
                                    Text(
                                        text = "${minutes}m",
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                        color = if (isToday) DeepPink else TextGrey
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                }

                                Box(
                                    modifier = Modifier
                                        .width(22.dp)
                                        .height((100 * heightFraction).dp)
                                        .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                                        .background(barColor)
                                        .border(
                                            1.dp,
                                            if (isToday) DeepPink else BorderGrey,
                                            RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp)
                                        )
                                )

                                Spacer(modifier = Modifier.height(6.dp))

                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal
                                    ),
                                    color = if (isToday) DeepPink else TextGrey
                                )
                            }
                        }
                    }
                }
            }
        }

        // Subject Breakdown
        if (subjectBreakdowns.isNotEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderGrey),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "Subject Distribution",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = AestheticBlack
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Stacked horizontal color bar
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(12.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(CardGrey)
                        ) {
                            subjectBreakdowns.forEach { (subject, _, pct) ->
                                val color = try {
                                    Color(android.graphics.Color.parseColor(subject.colorHex))
                                } catch (_: Exception) {
                                    DeepPink
                                }
                                Box(
                                    modifier = Modifier
                                        .weight(pct.coerceAtLeast(0.01f))
                                        .height(12.dp)
                                        .background(color)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Breakdown Items
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            subjectBreakdowns.forEach { (subject, mins, pct) ->
                                val color = try {
                                    Color(android.graphics.Color.parseColor(subject.colorHex))
                                } catch (_: Exception) {
                                    DeepPink
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(10.dp)
                                                .clip(CircleShape)
                                                .background(color)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "${subject.icon} ${subject.name}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = AestheticBlack
                                        )
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = "${mins}m",
                                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                            color = AestheticBlack
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "(${(pct * 100).toInt()}%)",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextGrey
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Recent Sessions Log
        item {
            Text(
                text = "Recent Study Sessions",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = AestheticBlack,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        if (sessions.isEmpty()) {
            item {
                Text(
                    text = "No recorded sessions yet. Start the Pomodoro timer to begin tracking!",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextGrey
                )
            }
        } else {
            val timeFormat = SimpleDateFormat("h:mm a • MMM d", Locale.getDefault())
            items(sessions.take(15), key = { it.id }) { session ->
                val durationMin = session.durationSeconds / 60
                val durationSec = session.durationSeconds % 60

                Card(
                    onClick = { selectedSessionForDetail = session },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderGrey),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("session_item_${session.id}")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(PastelPinkBg)
                                    .border(1.dp, BorderGrey, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(text = session.subjectIcon, fontSize = 18.sp)
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column {
                                Text(
                                    text = session.subjectName,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                    color = AestheticBlack
                                )
                                Text(
                                    text = timeFormat.format(Date(session.timestamp)),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextGrey
                                )
                                if (session.notes.isNotBlank()) {
                                    Text(
                                        text = session.notes,
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                                        color = TextGrey,
                                        maxLines = 1
                                    )
                                }
                            }
                        }

                        // Duration Badge
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = PastelPinkContainer,
                            border = androidx.compose.foundation.BorderStroke(1.dp, DeepPink.copy(alpha = 0.3f))
                        ) {
                            Text(
                                text = if (durationSec > 0) "${durationMin}m ${durationSec}s" else "${durationMin}m",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = DeepPink,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }

    if (selectedSessionForDetail != null) {
        SessionDetailDialog(
            session = selectedSessionForDetail!!,
            onDelete = { id ->
                onDeleteSession(id)
            },
            onDismiss = { selectedSessionForDetail = null }
        )
    }

    if (showManualLogDialog) {
        AddManualSessionDialog(
            subjects = subjects,
            onSave = { subject, duration, notes ->
                onAddManualSession(subject, duration, notes)
            },
            onDismiss = { showManualLogDialog = false }
        )
    }
}
