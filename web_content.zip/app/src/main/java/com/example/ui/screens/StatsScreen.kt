package com.example.ui.screens

import android.content.ContentResolver
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.NinjaRank
import com.example.data.Subject
import com.example.ui.DojoUiState
import com.example.ui.theme.ChakraCyan
import com.example.ui.theme.NarutoFlame
import com.example.ui.theme.NarutoOrange
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter

@Composable
fun StatsScreen(
  uiState: DojoUiState,
  onToggleDarkMode: () -> Unit,
  onExportBackup: () -> String,
  onRestoreBackup: (String) -> Boolean,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()

  val exportLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.CreateDocument("application/json")
  ) { uri ->
    uri?.let {
      coroutineScope.launch {
        val json = onExportBackup()
        val success = saveJsonToUri(context.contentResolver, it, json)
        if (success) {
          Toast.makeText(context, "Ninja Progress Exported! 📜", Toast.LENGTH_SHORT).show()
        } else {
          Toast.makeText(context, "Failed to export chakra records.", Toast.LENGTH_SHORT).show()
        }
      }
    }
  }

  val importLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.OpenDocument()
  ) { uri ->
    uri?.let {
      coroutineScope.launch {
        val json = readJsonFromUri(context.contentResolver, it)
        if (json != null) {
          val success = onRestoreBackup(json)
          if (success) {
            Toast.makeText(context, "Ninja Progress Restored! ⚡", Toast.LENGTH_SHORT).show()
          } else {
            Toast.makeText(context, "Invalid scroll format.", Toast.LENGTH_SHORT).show()
          }
        } else {
          Toast.makeText(context, "Could not read the scroll.", Toast.LENGTH_SHORT).show()
        }
      }
    }
  }

  val rank = uiState.ninjaRank
  val completedChaptersCount = uiState.chapters.count { it.isCompleted }
  val totalChapters = uiState.chapters.size.coerceAtLeast(1)
  val totalStudyHours = uiState.studySessions.sumOf { it.durationMinutes } / 60
  val remMinutes = uiState.studySessions.sumOf { it.durationMinutes } % 60

  LazyColumn(
    modifier = modifier.fillMaxSize(),
    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp)
  ) {
    // Ninja Profile Card
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("ninja_profile_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
      ) {
        Column(modifier = Modifier.padding(20.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(68.dp)
                .clip(CircleShape)
                .background(
                  Brush.linearGradient(
                    colors = listOf(NarutoOrange, NarutoFlame)
                  )
                ),
              contentAlignment = Alignment.Center
            ) {
              Image(
                painter = painterResource(id = R.drawable.ic_app_icon_fg),
                contentDescription = "Ninja Emblem",
                modifier = Modifier
                  .size(54.dp)
                  .clip(CircleShape),
                contentScale = ContentScale.Crop
              )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = "Kerala DHSE Shinobi",
                  style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black),
                  color = MaterialTheme.colorScheme.onSurface
                )
              }
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = "Class 12 • Computer Science Stream",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
              Spacer(modifier = Modifier.height(4.dp))
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = NarutoOrange.copy(alpha = 0.15f)
              ) {
                Text(
                  text = "${rank.badgeEmoji} Rank: ${rank.title}",
                  style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                  color = NarutoOrange,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(20.dp))

          // Chakra Meter Progress
          Text(
            text = "Chakra Mastery (Syllabus Progress)",
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface
          )
          Spacer(modifier = Modifier.height(6.dp))
          LinearProgressIndicator(
            progress = { uiState.overallProgressPercent / 100f },
            modifier = Modifier
              .fillMaxWidth()
              .height(10.dp)
              .clip(RoundedCornerShape(5.dp)),
            color = NarutoOrange,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
          )
          Spacer(modifier = Modifier.height(4.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = "$completedChaptersCount of $totalChapters Chapters Finished",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
              text = "${uiState.overallProgressPercent}%",
              style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
              color = NarutoOrange
            )
          }
        }
      }
    }

    item { Spacer(modifier = Modifier.height(18.dp)) }

    // Key Ninja Stats Grid
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // Study Time Logged
        Card(
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Text("⏱️ Total Focus", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "${totalStudyHours}h ${remMinutes}m",
              style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black),
              color = NarutoOrange
            )
            Text(
              text = "${uiState.studySessions.size} training bouts",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        // Quizzes Completed
        Card(
          modifier = Modifier.weight(1f),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Text("🎯 Quizzes Taken", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "${uiState.quizResults.size}",
              style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Black),
              color = ChakraCyan
            )
            val avgScore = if (uiState.quizResults.isNotEmpty()) {
              (uiState.quizResults.map { it.score * 10 }.average()).toInt()
            } else 0
            Text(
              text = "Avg: $avgScore% accuracy",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    }

    item { Spacer(modifier = Modifier.height(20.dp)) }

    // Ninja Ranks Ladder
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "Shinobi Advancement Ladder",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface
          )
          Spacer(modifier = Modifier.height(12.dp))

          listOf(
            Triple("Academy Student", "0% - 9%", "Beginning the Study Way"),
            Triple("Genin", "10% - 24%", "Official Leaf Shinobi"),
            Triple("Chunin", "25% - 49%", "Battle-Ready Student"),
            Triple("Special Jonin", "50% - 69%", "Computer Science Specialist"),
            Triple("Jonin", "70% - 89%", "Master of Plus Two Science"),
            Triple("Hokage", "90% - 100%", "Supreme Study Dojo Legend")
          ).forEach { (rTitle, range, desc) ->
            val isCurrent = rank.title == rTitle
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(10.dp)
                  .clip(CircleShape)
                  .background(if (isCurrent) NarutoOrange else MaterialTheme.colorScheme.outline)
              )
              Spacer(modifier = Modifier.width(10.dp))
              Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text(
                    text = rTitle,
                    style = MaterialTheme.typography.bodyMedium.copy(
                      fontWeight = if (isCurrent) FontWeight.Black else FontWeight.Normal
                    ),
                    color = if (isCurrent) NarutoOrange else MaterialTheme.colorScheme.onSurface
                  )
                  if (isCurrent) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                      shape = RoundedCornerShape(4.dp),
                      color = NarutoOrange.copy(alpha = 0.2f)
                    ) {
                      Text(
                        text = "YOU ARE HERE",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold),
                        color = NarutoOrange,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                      )
                    }
                  }
                }
                Text(
                  text = "$range • $desc",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }
        }
      }
    }

    item { Spacer(modifier = Modifier.height(20.dp)) }

    // Data Management Card (Backup/Restore)
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "Data Management",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "Sync your ninja progress across devices using manual backup files.",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Spacer(modifier = Modifier.height(16.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            Button(
              onClick = { exportLauncher.launch("study_dojo_backup_${System.currentTimeMillis()}.json") },
              modifier = Modifier
                .weight(1f)
                .testTag("export_backup_button"),
              shape = RoundedCornerShape(12.dp),
              colors = ButtonDefaults.buttonColors(containerColor = NarutoOrange)
            ) {
              Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("Export", fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
              onClick = { importLauncher.launch(arrayOf("application/json")) },
              modifier = Modifier
                .weight(1f)
                .testTag("import_backup_button"),
              shape = RoundedCornerShape(12.dp)
            ) {
              Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("Restore", fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }

    item { Spacer(modifier = Modifier.height(20.dp)) }

    // Settings Card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "Dojo Settings",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface
          )
          Spacer(modifier = Modifier.height(12.dp))

          // Dark Theme Toggle
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = if (uiState.isDarkMode) Icons.Default.DarkMode else Icons.Default.LightMode,
                contentDescription = null,
                tint = NarutoOrange
              )
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text(
                  text = "Dark / Light Mode",
                  style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                )
                Text(
                  text = if (uiState.isDarkMode) "Shinobi Night Mode Active" else "Ivory Scroll Mode Active",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }

            Switch(
              checked = uiState.isDarkMode,
              onCheckedChange = { onToggleDarkMode() },
              colors = SwitchDefaults.colors(checkedThumbColor = NarutoOrange, checkedTrackColor = NarutoOrange.copy(alpha = 0.5f)),
              modifier = Modifier.testTag("settings_dark_mode_switch")
            )
          }
        }
      }
    }
  }
}

private suspend fun saveJsonToUri(contentResolver: ContentResolver, uri: Uri, json: String): Boolean = withContext(Dispatchers.IO) {
  try {
    contentResolver.openOutputStream(uri)?.use { outputStream ->
      OutputStreamWriter(outputStream).use { writer ->
        writer.write(json)
      }
    }
    true
  } catch (e: Exception) {
    false
  }
}

private suspend fun readJsonFromUri(contentResolver: ContentResolver, uri: Uri): String? = withContext(Dispatchers.IO) {
  try {
    contentResolver.openInputStream(uri)?.use { inputStream ->
      BufferedReader(InputStreamReader(inputStream)).use { reader ->
        reader.readText()
      }
    }
  } catch (e: Exception) {
    null
  }
}
