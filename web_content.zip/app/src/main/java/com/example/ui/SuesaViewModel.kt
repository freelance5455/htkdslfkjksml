package com.example.ui

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.ConversationEntity
import com.example.data.local.SuesaDatabase
import com.example.data.local.SuesaRepository
import com.example.data.remote.ChatTurn
import com.example.data.remote.GeminiService
import com.example.util.AttachmentHelper
import com.example.util.SelectedAttachment
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

enum class PermissionRequestTarget {
    PHOTO,
    CAMERA,
    FILES
}

data class UiChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val sender: String, // "user" or "suesa"
    val text: String,
    val attachments: List<SelectedAttachment> = emptyList(),
    val persistedBadges: List<Pair<String, String>> = emptyList(),
    val timestamp: Long = System.currentTimeMillis()
)

data class SuesaUiState(
    val currentConversationId: String? = null,
    val messages: List<UiChatMessage> = emptyList(),
    val selectedAttachments: List<SelectedAttachment> = emptyList(),
    val statusText: String = "Hazır",
    val isSending: Boolean = false,
    val showAttachmentSheet: Boolean = false,
    val showSettingsModal: Boolean = false,
    val showSummariesModal: Boolean = false,
    val showCameraModal: Boolean = false,
    val pendingPermissionDialog: PermissionRequestTarget? = null,
    val photoPermissionGranted: Boolean = false,
    val cameraPermissionGranted: Boolean = false,
    val filesPermissionGranted: Boolean = false,
    val customApiKey: String = "",
    // Floating Overlay / Küçük Yüzen Ekran ("Paneli Aç") state
    val isFloatingPanelOpen: Boolean = false,
    val isMiniFloatingWindowMode: Boolean = false,
    val isOverlayBubbleMinimized: Boolean = false,
    val isLiveCameraInOverlay: Boolean = false,
    val isAutoScreenWatchEnabled: Boolean = false,
    val isAnalyzingScreen: Boolean = false,
    val overlayVisionCommentary: String = "Panel hazır! 'Ekranı Gör & Anlat' butonuna basarak ekranda veya kamerada ne olduğunu bana sorabilirsin.",
    val lastCapturedScreenPreview: Bitmap? = null,
    val backgroundWorkspaceScene: Int = 0, // 0 = Sohbet Arka Planı, 1 = Minecraft @Suesa_S Sahnesi, 2 = Kod/Terminal Ekranı, 3 = Notlar/Ödev Ekranı
    val mcBotLastStatus: String = "@Suesa_Sㅤム Bot: Beklemede"
)

class SuesaViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = application.getSharedPreferences("suesa_ai_prefs", Context.MODE_PRIVATE)
    private val repository: SuesaRepository

    private val _uiState = MutableStateFlow(
        SuesaUiState(
            customApiKey = prefs.getString(KEY_API_KEY, "") ?: "",
            photoPermissionGranted = prefs.getBoolean(KEY_PHOTO_PERM, false),
            cameraPermissionGranted = prefs.getBoolean(KEY_CAMERA_PERM, false),
            filesPermissionGranted = prefs.getBoolean(KEY_FILES_PERM, false)
        )
    )
    val uiState: StateFlow<SuesaUiState> = _uiState.asStateFlow()

    val conversations: StateFlow<List<ConversationEntity>>

    private val conversationHistory = mutableListOf<ChatTurn>()

    init {
        val dao = SuesaDatabase.getInstance(application).suesaDao()
        repository = SuesaRepository(dao)
        conversations = repository.allConversations.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    fun setStatus(text: String) {
        _uiState.update { it.copy(statusText = text) }
    }

    fun toggleAttachmentSheet(show: Boolean) {
        _uiState.update { it.copy(showAttachmentSheet = show) }
    }

    fun toggleSettingsModal(show: Boolean) {
        _uiState.update { it.copy(showSettingsModal = show) }
    }

    fun toggleSummariesModal(show: Boolean) {
        _uiState.update { it.copy(showSummariesModal = show) }
    }

    fun toggleCameraModal(show: Boolean) {
        _uiState.update { it.copy(showCameraModal = show) }
    }

    fun saveApiKey(newKey: String) {
        val trimmed = newKey.trim()
        prefs.edit().putString(KEY_API_KEY, trimmed).apply()
        _uiState.update {
            it.copy(
                customApiKey = trimmed,
                showSettingsModal = false,
                statusText = if (trimmed.isNotEmpty()) "API anahtarı kaydedildi" else "Varsayılan API yapılandırması aktif"
            )
        }
    }

    // --- Permission Flow Handlers ---

    fun requestPermissionDialog(target: PermissionRequestTarget) {
        _uiState.update {
            it.copy(
                showAttachmentSheet = false,
                pendingPermissionDialog = target
            )
        }
    }

    fun dismissPermissionDialog() {
        _uiState.update { it.copy(pendingPermissionDialog = null) }
    }

    fun markPermissionGranted(target: PermissionRequestTarget, rememberPermanently: Boolean = true) {
        when (target) {
            PermissionRequestTarget.PHOTO -> {
                if (rememberPermanently) prefs.edit().putBoolean(KEY_PHOTO_PERM, true).apply()
                _uiState.update {
                    it.copy(
                        photoPermissionGranted = true,
                        pendingPermissionDialog = null,
                        statusText = "Fotoğraf erişim izni verildi"
                    )
                }
            }
            PermissionRequestTarget.CAMERA -> {
                if (rememberPermanently) prefs.edit().putBoolean(KEY_CAMERA_PERM, true).apply()
                _uiState.update {
                    it.copy(
                        cameraPermissionGranted = true,
                        pendingPermissionDialog = null,
                        statusText = "Kamera erişim izni verildi"
                    )
                }
            }
            PermissionRequestTarget.FILES -> {
                if (rememberPermanently) prefs.edit().putBoolean(KEY_FILES_PERM, true).apply()
                _uiState.update {
                    it.copy(
                        filesPermissionGranted = true,
                        pendingPermissionDialog = null,
                        statusText = "Dosya erişim izni verildi"
                    )
                }
            }
        }
    }

    fun resetAllPermissionsForTesting() {
        prefs.edit()
            .putBoolean(KEY_PHOTO_PERM, false)
            .putBoolean(KEY_CAMERA_PERM, false)
            .putBoolean(KEY_FILES_PERM, false)
            .apply()
        _uiState.update {
            it.copy(
                photoPermissionGranted = false,
                cameraPermissionGranted = false,
                filesPermissionGranted = false,
                statusText = "İzin tercihleri sıfırlandı (İlk tıklamada tekrar sorulacak)"
            )
        }
    }

    // --- File & Photo & Camera Attachment Handlers ---

    fun handlePickedUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val context = getApplication<Application>()
        viewModelScope.launch {
            setStatus("Dosyalar hazırlanıyor…")
            val added = mutableListOf<SelectedAttachment>()
            for (uri in uris) {
                val res = AttachmentHelper.readUriAsAttachment(context, uri)
                res.onSuccess { attachment ->
                    added.add(attachment)
                }.onFailure { err ->
                    appendLocalSystemMessage(err.message ?: "Dosya okunamadı")
                }
            }
            if (added.isNotEmpty()) {
                _uiState.update { state ->
                    state.copy(
                        selectedAttachments = state.selectedAttachments + added,
                        statusText = "${added.size} dosya eklendi"
                    )
                }
            } else {
                setStatus("Hazır")
            }
        }
    }

    fun handleCapturedBitmap(bitmap: Bitmap, sourceLabel: String = "Kamera") {
        val attachment = AttachmentHelper.fromBitmap(bitmap, sourceLabel)
        _uiState.update { state ->
            state.copy(
                selectedAttachments = state.selectedAttachments + attachment,
                showCameraModal = false,
                statusText = "$sourceLabel fotoğrafı eklendi"
            )
        }
    }

    fun addSampleTextFileAttachment(title: String, content: String) {
        val bytes = content.toByteArray(Charsets.UTF_8)
        val b64 = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
        val attachment = SelectedAttachment(
            name = title,
            mimeType = "text/plain",
            sizeBytes = bytes.size.toLong(),
            base64Data = b64,
            textContent = content
        )
        _uiState.update { state ->
            state.copy(
                selectedAttachments = state.selectedAttachments + attachment,
                statusText = "$title eklendi"
            )
        }
    }

    fun removeSelectedAttachment(id: String) {
        _uiState.update { state ->
            state.copy(selectedAttachments = state.selectedAttachments.filterNot { it.id == id })
        }
    }

    // --- Chat & Conversation Lifecycle ---

    fun startNewChat() {
        conversationHistory.clear()
        _uiState.update {
            it.copy(
                currentConversationId = null,
                messages = emptyList(),
                selectedAttachments = emptyList(),
                statusText = "Yeni sohbet hazır"
            )
        }
    }

    fun restoreConversation(conversationId: String) {
        viewModelScope.launch {
            val savedMessages = repository.getMessagesSnapshot(conversationId)
            conversationHistory.clear()
            val uiMessages = savedMessages.map { entity ->
                val role = if (entity.sender == "suesa") "model" else "user"
                conversationHistory.add(ChatTurn(role = role, text = entity.text))
                UiChatMessage(
                    id = entity.id.toString(),
                    sender = entity.sender,
                    text = entity.text,
                    persistedBadges = AttachmentHelper.parseAttachmentBadges(entity.attachmentsSummaryJson),
                    timestamp = entity.timestamp
                )
            }
            _uiState.update {
                it.copy(
                    currentConversationId = conversationId,
                    messages = uiMessages,
                    showSummariesModal = false,
                    statusText = "Geçmiş sohbet yüklendi"
                )
            }
        }
    }

    fun deleteConversation(conversationId: String) {
        viewModelScope.launch {
            repository.deleteConversation(conversationId)
            if (_uiState.value.currentConversationId == conversationId) {
                startNewChat()
            }
        }
    }

    private suspend fun ensureActiveConversationId(): String {
        val current = _uiState.value.currentConversationId
        if (current != null) return current
        val newId = "${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(5)}"
        repository.ensureConversation(newId)
        _uiState.update { it.copy(currentConversationId = newId) }
        return newId
    }

    private fun appendLocalSystemMessage(text: String) {
        val msg = UiChatMessage(sender = "suesa", text = text)
        _uiState.update { it.copy(messages = it.messages + msg) }
    }

    fun sendMessage(rawText: String) {
        val text = rawText.trim()
        val currentState = _uiState.value
        val files = currentState.selectedAttachments
        if ((text.isEmpty() && files.isEmpty()) || currentState.isSending) return

        val effectiveText = if (text.isEmpty() && files.isNotEmpty()) {
            "Eklediğim dosyaları / görselleri inceleyip ne gördüğünü anlatır mısın?"
        } else {
            text
        }

        viewModelScope.launch {
            val convId = ensureActiveConversationId()
            val userMsg = UiChatMessage(
                sender = "user",
                text = effectiveText,
                attachments = files
            )
            val badgesJson = AttachmentHelper.serializeAttachmentMetadata(files)

            _uiState.update {
                it.copy(
                    messages = it.messages + userMsg,
                    selectedAttachments = emptyList(),
                    isSending = true,
                    statusText = "Suesa cevap hazırlıyor…"
                )
            }

            repository.saveMessageAndUpdateConversation(
                conversationId = convId,
                sender = "user",
                text = effectiveText,
                attachmentsSummaryJson = badgesJson
            )

            val historySnapshot = conversationHistory.toList()
            val result = GeminiService.sendChatMessage(
                history = historySnapshot,
                currentUserText = effectiveText,
                attachments = files,
                customApiKey = _uiState.value.customApiKey,
                onStatusUpdate = { status -> setStatus(status) }
            )

            result.onSuccess { answer ->
                val inlineImgs = files.filter { it.isImage && it.base64Data.isNotBlank() }
                    .map { it.mimeType to it.base64Data }
                conversationHistory.add(
                    ChatTurn(role = "user", text = effectiveText, inlineImages = inlineImgs)
                )
                conversationHistory.add(
                    ChatTurn(role = "model", text = answer)
                )
                val suesaMsg = UiChatMessage(sender = "suesa", text = answer)
                _uiState.update {
                    it.copy(
                        messages = it.messages + suesaMsg,
                        isSending = false,
                        statusText = "Hazır",
                        overlayVisionCommentary = if (it.isFloatingPanelOpen) answer else it.overlayVisionCommentary
                    )
                }
                repository.saveMessageAndUpdateConversation(
                    conversationId = convId,
                    sender = "suesa",
                    text = answer
                )
            }.onFailure { error ->
                val errText = error.message ?: "Şu an bağlantı kurulamadı. Lütfen biraz sonra tekrar dene."
                val errMsg = UiChatMessage(sender = "suesa", text = errText)
                _uiState.update {
                    it.copy(
                        messages = it.messages + errMsg,
                        isSending = false,
                        statusText = "Hazır"
                    )
                }
            }
        }
    }

    // --- Floating Overlay Panel ("Paneli Aç" / Küçük Yüzen Ekran) Handlers ---

    fun openFloatingPanel() {
        _uiState.update {
            it.copy(
                showAttachmentSheet = false,
                isFloatingPanelOpen = true,
                isMiniFloatingWindowMode = true,
                isOverlayBubbleMinimized = false,
                statusText = "Yüzen Suesa Paneli (Overlay) aktif"
            )
        }
    }

    fun closeFloatingPanel() {
        _uiState.update {
            it.copy(
                isFloatingPanelOpen = false,
                isMiniFloatingWindowMode = false,
                isOverlayBubbleMinimized = false,
                isLiveCameraInOverlay = false,
                isAutoScreenWatchEnabled = false,
                statusText = "Hazır"
            )
        }
    }

    fun toggleMiniFloatingWindowMode() {
        _uiState.update {
            it.copy(isMiniFloatingWindowMode = !it.isMiniFloatingWindowMode)
        }
    }

    fun setOverlayBubbleMinimized(minimized: Boolean) {
        _uiState.update {
            it.copy(isOverlayBubbleMinimized = minimized)
        }
    }

    fun toggleLiveCameraInOverlay(enabled: Boolean) {
        _uiState.update {
            it.copy(
                isLiveCameraInOverlay = enabled,
                statusText = if (enabled) "Canlı kamera görüşü panelde açıldı" else "Canlı kamera görüşü kapatıldı"
            )
        }
    }

    fun toggleAutoScreenWatch(enabled: Boolean) {
        _uiState.update {
            it.copy(
                isAutoScreenWatchEnabled = enabled,
                statusText = if (enabled) "Otomatik ekran izleme aktif" else "Otomatik ekran izleme kapalı"
            )
        }
    }

    fun cycleBackgroundWorkspaceScene(sceneIndex: Int? = null) {
        _uiState.update { state ->
            val next = sceneIndex ?: ((state.backgroundWorkspaceScene + 1) % 4)
            state.copy(backgroundWorkspaceScene = next)
        }
    }

    fun analyzeScreenWithSuesa(
        capturedBitmap: Bitmap,
        customQuestion: String? = null,
        alsoAddToChat: Boolean = true
    ) {
        if (_uiState.value.isAnalyzingScreen) return
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isAnalyzingScreen = true,
                    lastCapturedScreenPreview = capturedBitmap,
                    statusText = "Suesa ekranı inceliyor…",
                    overlayVisionCommentary = "Ekranındaki görüntüyü inceliyorum, bir saniye…"
                )
            }

            val result = GeminiService.analyzeScreenOrVision(
                screenBitmap = capturedBitmap,
                userQuestion = customQuestion,
                customApiKey = _uiState.value.customApiKey,
                onStatusUpdate = { status -> setStatus(status) }
            )

            result.onSuccess { commentary ->
                _uiState.update {
                    it.copy(
                        isAnalyzingScreen = false,
                        overlayVisionCommentary = commentary,
                        statusText = "Ekran analizi tamamlandı"
                    )
                }
                if (alsoAddToChat) {
                    val convId = ensureActiveConversationId()
                    val screenAttachment = AttachmentHelper.fromBitmap(capturedBitmap, "EkranGoruntusu")
                    val promptLabel = customQuestion?.takeIf { it.isNotBlank() }
                        ?: "🖥️ [Yüzen Panel Ekran Analizi]: Ekranda ne görüyorsun?"
                    val userMsg = UiChatMessage(
                        sender = "user",
                        text = promptLabel,
                        attachments = listOf(screenAttachment)
                    )
                    val suesaMsg = UiChatMessage(
                        sender = "suesa",
                        text = commentary
                    )
                    _uiState.update { state ->
                        state.copy(messages = state.messages + userMsg + suesaMsg)
                    }
                    repository.saveMessageAndUpdateConversation(
                        conversationId = convId,
                        sender = "user",
                        text = promptLabel,
                        attachmentsSummaryJson = AttachmentHelper.serializeAttachmentMetadata(listOf(screenAttachment))
                    )
                    repository.saveMessageAndUpdateConversation(
                        conversationId = convId,
                        sender = "suesa",
                        text = commentary
                    )
                }
            }.onFailure { err ->
                val msg = err.message ?: "Ekran analiz edilemedi."
                _uiState.update {
                    it.copy(
                        isAnalyzingScreen = false,
                        overlayVisionCommentary = msg,
                        statusText = "Hazır"
                    )
                }
            }
        }
    }

    fun sendMinecraftOverlayCommand(cmdKey: String) {
        val cmdMap = mapOf(
            "follow" to ("/suesa/follow" to "Seni takip etmeye başladı 🏃"),
            "stop" to ("/suesa/stop" to "Olduğu yerde durdu 🛑"),
            "come" to ("/suesa/come" to "Yanına geliyor 📍"),
            "wood" to ("/suesa/wood" to "Yakındaki ağaçları kırıp odun topluyor 🪓"),
            "stone" to ("/suesa/stone" to "Taş ve maden kazmaya başladı ⛏️"),
            "status" to ("/suesa/status" to "Can: 20/20 | Konum: Aktif | Envanter hazır 📊")
        )
        val (bridgePath, desc) = cmdMap[cmdKey] ?: ("/suesa/$cmdKey" to "Komut gönderildi")
        _uiState.update {
            it.copy(
                mcBotLastStatus = "@Suesa_Sㅤム [$bridgePath]: $desc",
                overlayVisionCommentary = "Minecraft Komutu Gönderildi ($bridgePath): $desc",
                statusText = "MC Komutu: $bridgePath"
            )
        }
    }

    companion object {
        private const val KEY_API_KEY = "suesa_gemini_api_key"
        private const val KEY_PHOTO_PERM = "suesa_photo_perm_granted"
        private const val KEY_CAMERA_PERM = "suesa_camera_perm_granted"
        private const val KEY_FILES_PERM = "suesa_files_perm_granted"
    }
}
