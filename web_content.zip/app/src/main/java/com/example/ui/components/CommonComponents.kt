package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Campaign
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.DesignServices
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Flag
import androidx.compose.material.icons.rounded.InstallMobile
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.model.ProjectCategory
import com.example.data.model.ProjectStatus
import com.example.data.model.ProjectWithStats
import com.example.data.model.TaskPriority
import com.example.data.model.TaskStatus
import com.example.data.model.TaskWithMeta
import com.example.ui.theme.AmberTertiaryDark
import com.example.ui.theme.PriorityHighColor
import com.example.ui.theme.PriorityLowColor
import com.example.ui.theme.PriorityMediumColor
import com.example.ui.theme.PriorityUrgentColor
import com.example.ui.theme.ProjectAccentColors
import com.example.ui.theme.StatusDoneColor
import com.example.ui.theme.StatusInProgressColor
import com.example.ui.theme.StatusTodoColor
import com.example.ui.viewmodel.DayActivity
import com.example.util.formatDurationPersian
import com.example.util.formatRelativeDateFa
import com.example.util.isOverdue
import com.example.util.toPersianDigits
import java.util.Calendar

fun projectAccentColor(index: Int): Color =
    ProjectAccentColors[index.coerceIn(0, ProjectAccentColors.lastIndex)]

fun ProjectCategory.icon(): ImageVector = when (this) {
    ProjectCategory.DEVELOPMENT -> Icons.Rounded.Code
    ProjectCategory.DESIGN -> Icons.Rounded.DesignServices
    ProjectCategory.MARKETING -> Icons.Rounded.Campaign
    ProjectCategory.BUSINESS -> Icons.Rounded.TrendingUp
    ProjectCategory.PERSONAL -> Icons.Rounded.Person
}

fun TaskPriority.color(): Color = when (this) {
    TaskPriority.URGENT -> PriorityUrgentColor
    TaskPriority.HIGH -> PriorityHighColor
    TaskPriority.MEDIUM -> PriorityMediumColor
    TaskPriority.LOW -> PriorityLowColor
}

fun TaskStatus.color(): Color = when (this) {
    TaskStatus.TODO -> StatusTodoColor
    TaskStatus.IN_PROGRESS -> StatusInProgressColor
    TaskStatus.DONE -> StatusDoneColor
}

@Composable
fun WorkspaceHeroBanner(
    ownerName: String,
    activeProjectsCount: Int,
    pendingTasksCount: Int,
    completionPercent: Int,
    activeStreakDays: Int,
    onEditOwnerName: () -> Unit,
    onNewProjectClick: () -> Unit,
    onOpenTemplatesClick: () -> Unit,
    onOpenAppDownloadCenter: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "hero_glow")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.12f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3600),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val greeting = remember {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        when (hour) {
            in 5..11 -> "صبح بخیر! آماده فتح هدف‌های امروز؟"
            in 12..17 -> "عصر بخیر! پروژه‌ها در مسیر پیشرفتند"
            else -> "شب بخیر! جمع‌بندی هوشمندانه پروژه‌ها"
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color(0xFF17153B),
                        Color(0xFF2E236C),
                        Color(0xFF0F172A)
                    )
                )
            )
    ) {
        Canvas(modifier = Modifier.matchParentSize()) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0x55818CF8), Color.Transparent),
                    center = Offset(size.width * 0.14f, size.height * 0.18f),
                    radius = size.width * 0.48f * pulse
                ),
                radius = size.width * 0.48f * pulse,
                center = Offset(size.width * 0.14f, size.height * 0.18f)
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0x4434D399), Color.Transparent),
                    center = Offset(size.width * 0.88f, size.height * 0.88f),
                    radius = size.width * 0.42f * (2f - pulse)
                ),
                radius = size.width * 0.42f * (2f - pulse),
                center = Offset(size.width * 0.88f, size.height * 0.88f)
            )
            drawCircle(
                color = Color(0x1CFFFFFF),
                radius = size.height * 0.65f,
                center = Offset(size.width * 0.12f, size.height * 0.5f),
                style = Stroke(width = 1.5.dp.toPx())
            )
            drawCircle(
                color = Color(0x10FFFFFF),
                radius = size.height * 0.98f,
                center = Offset(size.width * 0.12f, size.height * 0.5f),
                style = Stroke(width = 1.dp.toPx())
            )
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    onClick = onEditOwnerName,
                    color = Color(0x28FFFFFF),
                    shape = RoundedCornerShape(50),
                    border = BorderStroke(1.dp, Color(0x38FFFFFF)),
                    modifier = Modifier.testTag("hero_owner_badge")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Person,
                            contentDescription = "پروفایل شخصی",
                            tint = Color(0xFFE0E7FF),
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = ownerName.ifBlank { "فضای کاری شخصی" },
                            style = MaterialTheme.typography.labelMedium,
                            color = Color(0xFFE0E7FF),
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Icon(
                            imageVector = Icons.Rounded.Edit,
                            contentDescription = "ویرایش نام",
                            tint = Color(0xFFC7D2FE),
                            modifier = Modifier.size(12.dp)
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (activeStreakDays > 0) {
                        Surface(
                            color = Color(0x33F59E0B),
                            shape = RoundedCornerShape(50),
                            border = BorderStroke(1.dp, Color(0x66F59E0B))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.LocalFireDepartment,
                                    contentDescription = "استریک روزانه",
                                    tint = Color(0xFFFCD34D),
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = "${activeStreakDays.toPersianDigits()} روز",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color(0xFFFDE68A),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Surface(
                        color = Color(0x2834D399),
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(1.dp, Color(0x5534D399))
                    ) {
                        Text(
                            text = "${completionPercent.toPersianDigits()}٪ تکمیل",
                            style = MaterialTheme.typography.labelMedium,
                            color = Color(0xFF6EE7B7),
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = greeting,
                    style = MaterialTheme.typography.headlineSmall,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "${activeProjectsCount.toPersianDigits()} پروژه فعال  •  ${pendingTasksCount.toPersianDigits()} تسک باز  •  ذخیره شخصی روی موبایل",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFFC7D2FE)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    onClick = onNewProjectClick,
                    color = Color(0xFF34D399),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("hero_new_project_button")
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Add,
                            contentDescription = "پروژه جدید",
                            tint = Color(0xFF022C22),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = "پروژه جدید",
                            style = MaterialTheme.typography.labelLarge,
                            color = Color(0xFF022C22),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Surface(
                    onClick = onOpenTemplatesClick,
                    color = Color(0x26FFFFFF),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, Color(0x44FFFFFF)),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("hero_templates_button")
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.AutoAwesome,
                            contentDescription = "قالب آماده",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = "قالب آماده",
                            style = MaterialTheme.typography.labelLarge,
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            Surface(
                onClick = onOpenAppDownloadCenter,
                color = Color(0x1E818CF8),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, Color(0x55818CF8)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("hero_download_apk_button")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.InstallMobile,
                            contentDescription = "دانلود APK و نسخه دسکتاپ",
                            tint = Color(0xFFA5B4FC),
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "بخش دانلود مستقیم APK و نسخه دسکتاپ",
                            style = MaterialTheme.typography.labelLarge,
                            color = Color(0xFFE0E7FF),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                        contentDescription = null,
                        tint = Color(0xFFA5B4FC),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun QuickActionTile(
    icon: ImageVector,
    title: String,
    subtitle: String,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    Card(
        onClick = onClick,
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = modifier.then(if (testTag.isNotEmpty()) Modifier.testTag(testTag) else Modifier)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Surface(
                color = accent.copy(alpha = 0.15f),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.size(42.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = accent,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun EmptyProjectsIllustration(modifier: Modifier = Modifier) {
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val tertiary = MaterialTheme.colorScheme.tertiary
    val surface = MaterialTheme.colorScheme.surfaceVariant

    Canvas(modifier = modifier.size(180.dp)) {
        val w = size.width
        val h = size.height
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(primary.copy(alpha = 0.22f), Color.Transparent),
                center = Offset(w * 0.5f, h * 0.5f),
                radius = w * 0.48f
            ),
            radius = w * 0.48f,
            center = Offset(w * 0.5f, h * 0.5f)
        )

        drawRoundRect(
            color = surface,
            topLeft = Offset(w * 0.16f, h * 0.20f),
            size = Size(w * 0.54f, h * 0.58f),
            cornerRadius = CornerRadius(18.dp.toPx())
        )

        drawRoundRect(
            brush = Brush.linearGradient(
                colors = listOf(primary.copy(alpha = 0.92f), primary.copy(alpha = 0.72f))
            ),
            topLeft = Offset(w * 0.28f, h * 0.28f),
            size = Size(w * 0.56f, h * 0.52f),
            cornerRadius = CornerRadius(18.dp.toPx())
        )

        drawRoundRect(
            color = Color.White.copy(alpha = 0.9f),
            topLeft = Offset(w * 0.36f, h * 0.39f),
            size = Size(w * 0.32f, h * 0.055f),
            cornerRadius = CornerRadius(6.dp.toPx())
        )
        drawRoundRect(
            color = Color.White.copy(alpha = 0.55f),
            topLeft = Offset(w * 0.36f, h * 0.49f),
            size = Size(w * 0.40f, h * 0.045f),
            cornerRadius = CornerRadius(6.dp.toPx())
        )
        drawRoundRect(
            color = Color.White.copy(alpha = 0.4f),
            topLeft = Offset(w * 0.36f, h * 0.58f),
            size = Size(w * 0.24f, h * 0.045f),
            cornerRadius = CornerRadius(6.dp.toPx())
        )

        drawCircle(
            color = secondary,
            radius = w * 0.11f,
            center = Offset(w * 0.76f, h * 0.28f)
        )
        drawCircle(
            color = tertiary,
            radius = w * 0.055f,
            center = Offset(w * 0.22f, h * 0.72f)
        )
    }
}

@Composable
fun CompletionRing(
    progress: Float,
    ringSize: Dp = 84.dp,
    strokeWidth: Dp = 9.dp,
    accentColor: Color = MaterialTheme.colorScheme.secondary,
    modifier: Modifier = Modifier
) {
    val animatedProgress by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "ring_progress"
    )
    val trackColor = MaterialTheme.colorScheme.surfaceVariant

    Box(
        modifier = modifier.size(ringSize),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val stroke = strokeWidth.toPx()
            drawArc(
                color = trackColor,
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )
            drawArc(
                color = accentColor,
                startAngle = -90f,
                sweepAngle = 360f * animatedProgress,
                useCenter = false,
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )
        }
        Text(
            text = "${(animatedProgress * 100).toInt().toPersianDigits()}٪",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun WeeklyProductivityChart(
    days: List<DayActivity>,
    modifier: Modifier = Modifier
) {
    val maxVal = (days.maxOfOrNull { it.completedCount } ?: 1).coerceAtLeast(1)
    val primary = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary
    val track = MaterialTheme.colorScheme.surfaceVariant

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(104.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            days.forEachIndexed { idx, day ->
                val ratio by animateFloatAsState(
                    targetValue = if (day.completedCount == 0) 0.08f else (day.completedCount.toFloat() / maxVal.toFloat()).coerceIn(0.15f, 1f),
                    animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
                    label = "bar_$idx"
                )
                val isToday = idx == days.lastIndex
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Bottom
                ) {
                    Text(
                        text = day.completedCount.toPersianDigits(),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isToday) secondary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .width(20.dp)
                            .height(72.dp)
                            .clip(RoundedCornerShape(9.dp))
                            .background(track),
                        contentAlignment = Alignment.BottomCenter
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(72.dp * ratio)
                                .clip(RoundedCornerShape(9.dp))
                                .background(
                                    Brush.verticalGradient(
                                        colors = if (isToday) {
                                            listOf(secondary, secondary.copy(alpha = 0.65f))
                                        } else {
                                            listOf(primary, primary.copy(alpha = 0.55f))
                                        }
                                    )
                                )
                        )
                    }
                }
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            days.forEachIndexed { idx, day ->
                val isToday = idx == days.lastIndex
                Box(
                    modifier = Modifier.weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = day.dayLabel,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal,
                        color = if (isToday) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun PriorityPill(priority: TaskPriority, modifier: Modifier = Modifier) {
    val color = priority.color()
    Surface(
        color = color.copy(alpha = 0.14f),
        shape = RoundedCornerShape(50),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Text(
                text = priority.labelFa,
                style = MaterialTheme.typography.labelSmall,
                color = color,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun StatusPill(status: TaskStatus, modifier: Modifier = Modifier) {
    val color = status.color()
    Surface(
        color = color.copy(alpha = 0.14f),
        shape = RoundedCornerShape(50),
        modifier = modifier
    ) {
        Text(
            text = status.labelFa,
            style = MaterialTheme.typography.labelSmall,
            color = color,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun ProjectCard(
    item: ProjectWithStats,
    onClick: () -> Unit,
    onTogglePin: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = projectAccentColor(item.project.colorIndex)
    val category = ProjectCategory.fromName(item.project.category)
    val status = ProjectStatus.fromName(item.project.status)

    Card(
        onClick = onClick,
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = modifier
            .fillMaxWidth()
            .testTag("project_card_${item.project.id}")
    ) {
        Column {
            // Top Accent Bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(5.dp)
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(accent, accent.copy(alpha = 0.45f))
                        )
                    )
            )

            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Surface(
                            color = accent.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = category.icon(),
                                    contentDescription = category.labelFa,
                                    tint = accent,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = item.project.title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${category.labelFa}  •  ${status.labelFa}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ProjectHealthBadge(item = item, status = status)
                        IconButton(
                            onClick = onTogglePin,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("pin_project_${item.project.id}")
                        ) {
                            Icon(
                                imageVector = if (item.project.isPinned) Icons.Rounded.PushPin else Icons.Outlined.PushPin,
                                contentDescription = if (item.project.isPinned) "برداشتن سنجاق" else "سنجاق پروژه",
                                tint = if (item.project.isPinned) accent else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                if (item.project.description.isNotBlank()) {
                    Text(
                        text = item.project.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                if (item.project.budgetLabel.isNotBlank()) {
                    Surface(
                        color = accent.copy(alpha = 0.1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = "هدف / بودجه: ${item.project.budgetLabel}",
                            style = MaterialTheme.typography.labelSmall,
                            color = accent,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${item.doneTasks.toPersianDigits()} از ${item.totalTasks.toPersianDigits()} تسک  •  ${item.doneStoryPoints.toPersianDigits()}/${item.totalStoryPoints.toPersianDigits()} امتیاز",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "${(item.progress * 100).toInt().toPersianDigits()}٪",
                            style = MaterialTheme.typography.labelLarge,
                            color = accent,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    LinearProgressIndicator(
                        progress = { item.progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(50)),
                        color = accent,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (item.totalMilestones > 0) {
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(50)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Flag,
                                        contentDescription = "نقاط عطف",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Text(
                                        text = "${item.completedMilestones.toPersianDigits()}/${item.totalMilestones.toPersianDigits()}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        if (item.totalFocusMinutes > 0) {
                            Surface(
                                color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.65f),
                                shape = RoundedCornerShape(50)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Timer,
                                        contentDescription = "تمرکز",
                                        tint = MaterialTheme.colorScheme.onSecondaryContainer,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Text(
                                        text = formatDurationPersian(item.totalFocusMinutes),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSecondaryContainer
                                    )
                                }
                            }
                        }

                        if (item.project.targetDateMillis != null) {
                            val overdue = isOverdue(item.project.targetDateMillis) && status != ProjectStatus.COMPLETED
                            Surface(
                                color = if (overdue) PriorityUrgentColor.copy(alpha = 0.14f) else MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(50)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Schedule,
                                        contentDescription = "موعد",
                                        tint = if (overdue) PriorityUrgentColor else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Text(
                                        text = formatRelativeDateFa(item.project.targetDateMillis),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (overdue) PriorityUrgentColor else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "باز کردن",
                            style = MaterialTheme.typography.labelMedium,
                            color = accent,
                            fontWeight = FontWeight.Bold
                        )
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                            contentDescription = null,
                            tint = accent,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TaskCard(
    item: TaskWithMeta,
    showProjectBadge: Boolean = true,
    onClick: () -> Unit,
    onToggleDone: () -> Unit,
    onAdvanceStatus: (() -> Unit)? = null,
    onToggleBookmark: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current
    val task = item.task
    val status = TaskStatus.fromName(task.status)
    val priority = TaskPriority.fromName(task.priority)
    val isDone = status == TaskStatus.DONE
    val projectColor = projectAccentColor(item.projectColorIndex)

    Card(
        onClick = onClick,
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(
            width = 1.dp,
            color = if (isDone) MaterialTheme.colorScheme.outline.copy(alpha = 0.55f) else MaterialTheme.colorScheme.outline
        ),
        modifier = modifier
            .fillMaxWidth()
            .testTag("task_card_${task.id}")
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                IconButton(
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        onToggleDone()
                    },
                    modifier = Modifier
                        .size(36.dp)
                        .minimumInteractiveComponentSize()
                        .testTag("toggle_task_${task.id}")
                ) {
                    Icon(
                        imageVector = if (isDone) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                        contentDescription = if (isDone) "انجام شده" else "تکمیل تسک",
                        tint = if (isDone) StatusDoneColor else priority.color(),
                        modifier = Modifier.size(22.dp)
                    )
                }

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = task.title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = if (isDone) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                        textDecoration = if (isDone) TextDecoration.LineThrough else TextDecoration.None,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (task.description.isNotBlank()) {
                        Text(
                            text = task.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Column(
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    PriorityPill(priority = priority)
                    if (onToggleBookmark != null) {
                        IconButton(
                            onClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                onToggleBookmark()
                            },
                            modifier = Modifier
                                .size(30.dp)
                                .minimumInteractiveComponentSize()
                        ) {
                            Icon(
                                imageVector = if (task.bookmarked) Icons.Rounded.Star else Icons.Outlined.StarOutline,
                                contentDescription = "نشانه‌گذاری",
                                tint = if (task.bookmarked) AmberTertiaryDark else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            if (item.subtasks.isNotEmpty()) {
                val subProgress = item.completedSubtasksCount.toFloat() / item.subtasks.size.toFloat()
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    LinearProgressIndicator(
                        progress = { subProgress },
                        modifier = Modifier
                            .weight(1f)
                            .height(5.dp)
                            .clip(RoundedCornerShape(50)),
                        color = MaterialTheme.colorScheme.secondary,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                    Text(
                        text = "${item.completedSubtasksCount.toPersianDigits()}/${item.subtasks.size.toPersianDigits()}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    if (showProjectBadge) {
                        Surface(
                            color = projectColor.copy(alpha = 0.14f),
                            shape = RoundedCornerShape(50)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(projectColor)
                                )
                                Text(
                                    text = item.projectTitle,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = projectColor,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    if (task.assigneeName.isNotBlank()) {
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(50)
                        ) {
                            Text(
                                text = task.assigneeName,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                            )
                        }
                    }

                    if (task.tag.isNotBlank()) {
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(50)
                        ) {
                            Text(
                                text = task.tag,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                            )
                        }
                    }

                    if (task.dueDateMillis != null) {
                        val overdue = isOverdue(task.dueDateMillis) && !isDone
                        Text(
                            text = formatRelativeDateFa(task.dueDateMillis),
                            style = MaterialTheme.typography.labelSmall,
                            color = if (overdue) PriorityUrgentColor else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                        shape = RoundedCornerShape(50)
                    ) {
                        Text(
                            text = "${task.storyPoints.toPersianDigits()} ام",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                        )
                    }

                    if (onAdvanceStatus != null && status != TaskStatus.DONE) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(50),
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .clickable {
                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    onAdvanceStatus()
                                }
                                .testTag("advance_task_${task.id}")
                        ) {
                            Text(
                                text = if (status == TaskStatus.TODO) "شروع" else "تکمیل",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProjectHealthBadge(
    item: ProjectWithStats,
    status: ProjectStatus,
    modifier: Modifier = Modifier
) {
    val target = item.project.targetDateMillis
    val threeDaysMs = 3 * 86_400_000L
    val (label, color) = when {
        status == ProjectStatus.COMPLETED -> "تکمیل" to StatusDoneColor
        status == ProjectStatus.ON_HOLD -> "متوقف" to PriorityMediumColor
        target != null && isOverdue(target) -> "تأخیر" to PriorityUrgentColor
        target != null && (target - System.currentTimeMillis()) <= threeDaysMs && item.progress < 0.6f ->
            "حساس" to PriorityHighColor
        else -> "سالم" to StatusDoneColor
    }

    Surface(
        color = color.copy(alpha = 0.14f),
        shape = RoundedCornerShape(50),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = color,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
