package com.example.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.AirtelGatewayConfig
import com.example.localization.AppLang
import com.example.localization.SjsStrings
import com.example.model.*
import com.example.ui.theme.*
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Locale

fun categoryIcon(category: ServiceCategory): ImageVector = when (category) {
    ServiceCategory.SECURITY_GUARDS -> Icons.Filled.Security
    ServiceCategory.CCTV_INSTALLATION -> Icons.Filled.Videocam
    ServiceCategory.ELECTRIC_FENCE -> Icons.Filled.Bolt
    ServiceCategory.ALARM_SYSTEMS -> Icons.Filled.NotificationsActive
    ServiceCategory.ACCESS_CONTROL -> Icons.Filled.Badge
    ServiceCategory.GPS_TRACKING -> Icons.Filled.GpsFixed
    ServiceCategory.FIRE_DETECTION -> Icons.Filled.LocalFireDepartment
    ServiceCategory.SECURITY_CONSULTATION -> Icons.Filled.SupportAgent
    ServiceCategory.EQUIPMENT_SUPPLY -> Icons.Filled.Inventory2
    ServiceCategory.SECURITY_MAINTENANCE -> Icons.Filled.Build
}

object PhotoCodec {
    fun uriToCompressedBase64(context: Context, uri: Uri, maxDim: Int = 420): String? {
        return try {
            val stream = context.contentResolver.openInputStream(uri) ?: return null
            val original = BitmapFactory.decodeStream(stream)
            stream.close()
            if (original == null) return null
            val ratio = minOf(maxDim.toFloat() / original.width, maxDim.toFloat() / original.height, 1f)
            val w = (original.width * ratio).toInt().coerceAtLeast(1)
            val h = (original.height * ratio).toInt().coerceAtLeast(1)
            val scaled = Bitmap.createScaledBitmap(original, w, h, true)
            val out = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 68, out)
            Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        } catch (_: Exception) {
            null
        }
    }

    fun decodeBitmap(base64: String?): Bitmap? {
        if (base64.isNullOrBlank()) return null
        return try {
            val bytes = Base64.decode(base64, Base64.DEFAULT)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (_: Exception) {
            null
        }
    }
}

@Composable
fun Base64Image(
    base64: String?,
    contentDescription: String,
    modifier: Modifier = Modifier,
    fallbackResId: Int = R.drawable.img_security_ops
) {
    val bitmap = remember(base64) { PhotoCodec.decodeBitmap(base64) }
    if (bitmap != null) {
        Image(
            bitmap = bitmap.asImageBitmap(),
            contentDescription = contentDescription,
            modifier = modifier,
            contentScale = ContentScale.Crop
        )
    } else {
        Image(
            painter = painterResource(id = fallbackResId),
            contentDescription = contentDescription,
            modifier = modifier,
            contentScale = ContentScale.Crop
        )
    }
}

@Composable
fun SmartJonesTopBar(
    lang: AppLang,
    activeRole: ActiveAppRole,
    onToggleLang: () -> Unit,
    onRoleBadgeClick: () -> Unit
) {
    Surface(
        color = NavyDeep,
        contentColor = PureWhite,
        shadowElevation = 4.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_brand_logo),
                    contentDescription = "Smart Jones Security Logo",
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(10.dp)),
                    contentScale = ContentScale.Crop
                )
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(
                        text = "SMART JONES",
                        style = MaterialTheme.typography.titleMedium,
                        color = PureWhite,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "SECURITY • TANZANIA",
                        style = MaterialTheme.typography.labelSmall,
                        color = OrangeBright,
                        maxLines = 1
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val roleLabel = when (activeRole) {
                    ActiveAppRole.CUSTOMER -> SjsStrings.t(lang, "Mteja", "Customer")
                    ActiveAppRole.PROVIDER -> SjsStrings.t(lang, "Kampuni", "Provider")
                    ActiveAppRole.ADMIN -> "Admin"
                }
                Surface(
                    color = OrangeBrand,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .testTag("role_badge_button")
                        .clickable(onClick = onRoleBadgeClick)
                        .minimumInteractiveComponentSize()
                ) {
                    Text(
                        text = roleLabel,
                        style = MaterialTheme.typography.labelMedium,
                        color = PureWhite,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }

                Surface(
                    color = NavyElevated,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .testTag("language_toggle_button")
                        .clickable(onClick = onToggleLang)
                        .minimumInteractiveComponentSize()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Translate, contentDescription = "Language", tint = OrangeBright, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = if (lang == AppLang.SW) "SW" else "EN",
                            style = MaterialTheme.typography.labelMedium,
                            color = PureWhite
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun VerifiedBadgeChip(lang: AppLang, verified: Boolean) {
    if (verified) {
        Surface(
            color = VerifiedGreenContainer,
            shape = RoundedCornerShape(8.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Verified, contentDescription = "Verified", tint = VerifiedGreen, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(4.dp))
                Text(
                    text = SjsStrings.t(lang, "Imethibitishwa", "Verified"),
                    style = MaterialTheme.typography.labelMedium,
                    color = VerifiedGreen
                )
            }
        }
    } else {
        Surface(
            color = WarningAmberContainer,
            shape = RoundedCornerShape(8.dp)
        ) {
            Text(
                text = SjsStrings.t(lang, "Inasubiri Uhakiki", "Pending Verification"),
                style = MaterialTheme.typography.labelMedium,
                color = WarningAmber,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }
}

@Composable
fun OrderLifecycleStepper(status: OrderStatus, lang: AppLang) {
    val activeStep = status.stepIndex
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        if (status == OrderStatus.CANCELLED || status == OrderStatus.DISPUTED) {
            Surface(
                color = ErrorRedContainer,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Warning, contentDescription = null, tint = ErrorRed, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = SjsStrings.orderStatusLabel(status, lang),
                        style = MaterialTheme.typography.titleSmall,
                        color = ErrorRed
                    )
                }
            }
        } else {
            LinearProgressIndicator(
                progress = { (activeStep / 10f).coerceIn(0.1f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = OrangeBrand,
                trackColor = SurfaceVariantLight
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = SjsStrings.orderStatusLabel(status, lang),
                    style = MaterialTheme.typography.labelMedium,
                    color = NavyDeep
                )
                Text(
                    text = "$activeStep / 10",
                    style = MaterialTheme.typography.labelSmall,
                    color = SlateGrey
                )
            }
        }
    }
}

@Composable
fun AirtelPaymentDialog(
    lang: AppLang,
    title: String,
    amountTzs: Long,
    defaultPhone: String,
    pendingPayment: PaymentTransaction?,
    isBusy: Boolean,
    onInitiate: (phone: String) -> Unit,
    onVerifySandboxCallback: (PaymentTransaction) -> Unit,
    onDismiss: () -> Unit
) {
    var phone by remember(defaultPhone) { mutableStateOf(defaultPhone.ifBlank { "078" }) }
    val isProd = AirtelGatewayConfig.isProductionBackendConfigured

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Payments, contentDescription = null, tint = OrangeBrand)
                Spacer(Modifier.width(8.dp))
                Text(title, style = MaterialTheme.typography.titleLarge)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Surface(
                    color = if (isProd) VerifiedGreenContainer else WarningAmberContainer,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (isProd) {
                            SjsStrings.t(lang, "AIRTEL MONEY LIVE API", "AIRTEL MONEY LIVE API")
                        } else {
                            SjsStrings.t(
                                lang,
                                "SANDBOX TEST MODE — Hakuna pesa halisi inayokatwa (API haijaunganishwa)",
                                "SANDBOX TEST MODE — No real money transferred (Airtel API credentials pending)"
                            )
                        },
                        style = MaterialTheme.typography.labelMedium,
                        color = if (isProd) VerifiedGreen else WarningAmber,
                        modifier = Modifier.padding(10.dp)
                    )
                }

                Card(colors = CardDefaults.cardColors(containerColor = NavyDeep)) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = SjsStrings.t(lang, "Namba ya Mpokeaji (Admin Airtel Money)", "Recipient Admin Airtel Money"),
                            style = MaterialTheme.typography.bodySmall,
                            color = BorderGrey
                        )
                        Text(
                            text = MarketplaceConstants.ADMIN_AIRTEL_NUMBER,
                            style = MaterialTheme.typography.headlineSmall,
                            color = OrangeBright
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = TzsFormatter.format(amountTzs),
                            style = MaterialTheme.typography.titleLarge,
                            color = PureWhite
                        )
                    }
                }

                if (pendingPayment == null) {
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text(SjsStrings.t(lang, "Namba yako ya Airtel Money", "Your Airtel Money Number")) },
                        placeholder = { Text("078XXXXXXX") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("airtel_phone_input")
                    )
                    Text(
                        text = SjsStrings.t(
                            lang,
                            "Malipo huthibitishwa na seva/webhook pekee — si kwa screenshot au uthibitisho wa mdomo.",
                            "Payments are verified strictly via backend callback/webhook — never by screenshot alone."
                        ),
                        style = MaterialTheme.typography.bodySmall,
                        color = SlateGrey
                    )
                } else {
                    Surface(
                        color = SurfaceVariantLight,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Ref: ${pendingPayment.transactionRef}", style = MaterialTheme.typography.labelSmall)
                            Text("Receipt: ${pendingPayment.receiptNumber}", style = MaterialTheme.typography.labelSmall)
                            Text("Status: ${pendingPayment.status}", style = MaterialTheme.typography.labelMedium, color = OrangeBrand)
                            Text(pendingPayment.gatewayMessage, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (pendingPayment == null) {
                Button(
                    onClick = { onInitiate(phone) },
                    enabled = !isBusy && phone.trim().length >= 9,
                    colors = ButtonDefaults.buttonColors(containerColor = OrangeBrand),
                    modifier = Modifier.testTag("initiate_airtel_button")
                ) {
                    Text(SjsStrings.t(lang, "Anzisha Malipo", "Initiate Payment"))
                }
            } else if (pendingPayment.mode == "SANDBOX" && pendingPayment.statusEnum() != PaymentStatus.VERIFIED) {
                Button(
                    onClick = { onVerifySandboxCallback(pendingPayment) },
                    enabled = !isBusy,
                    colors = ButtonDefaults.buttonColors(containerColor = VerifiedGreen),
                    modifier = Modifier.testTag("verify_sandbox_webhook_button")
                ) {
                    Text(SjsStrings.t(lang, "Thibitisha Webhook (Sandbox)", "Verify Sandbox Webhook"))
                }
            } else {
                Button(onClick = onDismiss) {
                    Text(SjsStrings.t(lang, "Funga", "Close"))
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(SjsStrings.t(lang, "Ghairi", "Cancel"))
            }
        }
    )
}

@Composable
fun DigitalReceiptDialog(
    payment: PaymentTransaction,
    lang: AppLang,
    onDismiss: () -> Unit
) {
    val dateFmt = remember { SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()) }
    val dateText = payment.createdAt?.toDate()?.let { dateFmt.format(it) } ?: "Pending"
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.ReceiptLong, contentDescription = null, tint = NavyDeep)
                Spacer(Modifier.width(8.dp))
                Text(SjsStrings.t(lang, "Risiti ya Kidijitali", "Digital Receipt"))
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("SMART JONES SECURITY TANZANIA", style = MaterialTheme.typography.labelLarge, color = NavyDeep)
                HorizontalDivider()
                ReceiptRow(SjsStrings.t(lang, "Namba ya Risiti", "Receipt No"), payment.receiptNumber)
                ReceiptRow(SjsStrings.t(lang, "Rejea", "Transaction Ref"), payment.transactionRef)
                ReceiptRow(SjsStrings.t(lang, "Mlipaji", "Payer"), "${payment.payerName} (${payment.payerPhone})")
                ReceiptRow(SjsStrings.t(lang, "Airtel Money Admin", "Admin Number"), payment.recipientNumber)
                ReceiptRow(SjsStrings.t(lang, "Kiasi", "Amount"), TzsFormatter.format(payment.amountTzs))
                ReceiptRow(SjsStrings.t(lang, "Kamisheni (5%)", "Platform Fee"), TzsFormatter.format(payment.commissionTzs))
                ReceiptRow(SjsStrings.t(lang, "Hali", "Status"), payment.status)
                ReceiptRow(SjsStrings.t(lang, "Njia", "Mode"), payment.mode)
                ReceiptRow(SjsStrings.t(lang, "Tarehe", "Date"), dateText)
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text(SjsStrings.t(lang, "Sawa", "Done"))
            }
        }
    )
}

@Composable
private fun ReceiptRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = SlateGrey)
        Text(value, style = MaterialTheme.typography.labelMedium, color = DarkGrey)
    }
}
