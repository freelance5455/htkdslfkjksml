package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.AppLanguage
import com.example.data.model.UserProfile

@Composable
fun AiFirebaseNoticeBanner(modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.tertiaryContainer
        )
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Filled.Info,
                contentDescription = "AI mode notice",
                tint = MaterialTheme.colorScheme.onTertiaryContainer,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = stringResource(R.string.ai_firebase_notice),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onTertiaryContainer
            )
        }
    }
}

@Composable
fun DataModeToggleChip(
    isDataFreeMode: Boolean,
    dataLabel: String,
    dataFreeLabel: String,
    onToggle: (Boolean) -> Unit
) {
    FilterChip(
        selected = isDataFreeMode,
        onClick = { onToggle(!isDataFreeMode) },
        modifier = Modifier.testTag("data_mode_chip"),
        label = {
            Text(
                text = if (isDataFreeMode) dataFreeLabel else dataLabel,
                style = MaterialTheme.typography.labelMedium
            )
        },
        leadingIcon = {
            Icon(
                imageVector = if (isDataFreeMode) Icons.Filled.CloudOff else Icons.Filled.Wifi,
                contentDescription = if (isDataFreeMode) "Data-Free Offline Mode" else "Data Mode",
                modifier = Modifier.size(16.dp)
            )
        }
    )
}

@Composable
fun BiometricLockScreen(
    profile: UserProfile,
    biometricAvailable: Boolean,
    onPinUnlockSuccess: () -> Unit,
    onUnlockClick: () -> Unit,
    onResetPinAndUnlock: (String) -> Unit,
    errorMessage: String?
) {
    var pinInput by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf<String?>(null) }
    var showForgotPinDialog by remember { mutableStateOf(false) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .widthIn(max = 480.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = if (profile.pinCode.isNotBlank()) Icons.Filled.Lock else Icons.Filled.Fingerprint,
                contentDescription = "Haven login lock icon",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(68.dp)
            )
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = if (profile.name.isNotBlank()) "Welcome back, ${profile.name}" else stringResource(R.string.biometric_lock_title),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = stringResource(R.string.biometric_lock_subtitle),
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (profile.pinCode.isNotBlank()) {
                Spacer(modifier = Modifier.height(18.dp))
                OutlinedTextField(
                    value = pinInput,
                    onValueChange = { pinInput = it.filter { ch -> ch.isDigit() }.take(6); pinError = null },
                    label = { Text("Enter Your 4–6 Digit Privacy PIN") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("lock_pin_input")
                )
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = {
                        if (pinInput == profile.pinCode) {
                            onPinUnlockSuccess()
                        } else {
                            pinError = "Incorrect PIN. Try again or tap Forgot PIN below."
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(50.dp).testTag("unlock_with_pin_button")
                ) {
                    Icon(Icons.Filled.LockOpen, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Log In / Unlock with PIN")
                }
                TextButton(
                    onClick = { showForgotPinDialog = true },
                    modifier = Modifier.testTag("lock_forgot_pin_button")
                ) {
                    Text("Forgot PIN? Send OTP to masked phone/email")
                }
            }

            val shownErr = pinError ?: errorMessage
            if (!shownErr.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = shownErr,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                    textAlign = TextAlign.Center
                )
            }

            if (profile.biometricLockEnabled && biometricAvailable) {
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = onUnlockClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("unlock_biometric_button")
                ) {
                    Icon(Icons.Filled.Fingerprint, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Unlock with Biometrics / Device PIN")
                }
            }
        }
    }

    if (showForgotPinDialog) {
        ForgotPinResetDialog(
            profile = profile,
            onPinResetSuccess = { newPin ->
                showForgotPinDialog = false
                onResetPinAndUnlock(newPin)
            },
            onDismiss = { showForgotPinDialog = false }
        )
    }
}

@Composable
fun DndPermissionDialog(
    onOpenSettings: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Enable Sleep Quiet Access") },
        text = {
            Text(
                "To turn other apps and notifications down when you sleep, Android asks you to grant Do Not Disturb access to Haven once in Settings."
            )
        },
        confirmButton = {
            Button(
                onClick = {
                    onDismiss()
                    onOpenSettings()
                },
                modifier = Modifier.testTag("open_dnd_settings_button")
            ) {
                Text("Open Settings")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Later")
            }
        }
    )
}

@Composable
fun LanguageBadgeChip(
    language: AppLanguage,
    onClick: () -> Unit
) {
    FilterChip(
        selected = false,
        onClick = onClick,
        modifier = Modifier.testTag("language_badge_chip"),
        label = { Text(language.flagLabel) },
        leadingIcon = {
            Icon(
                imageVector = Icons.Filled.Public,
                contentDescription = "Language ${language.nativeName}",
                modifier = Modifier.size(16.dp)
            )
        }
    )
}
