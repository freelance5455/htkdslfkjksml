package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun KpiStatTile(
    label: String,
    value: String,
    accentColor: Color,
    containerColor: Color,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = containerColor,
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.25f)),
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = label.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = accentColor.copy(alpha = 0.85f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                color = accentColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
fun EmptyStateCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
    ) {
        Column(
            modifier = Modifier.padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(28.dp),
                )
            }
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center,
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            if (actionLabel != null && onAction != null) {
                Spacer(Modifier.height(4.dp))
                Button(onClick = onAction, shape = RoundedCornerShape(12.dp)) {
                    Text(actionLabel)
                }
            }
        }
    }
}

@Composable
fun SchoolEmblemView(
    logoBitmap: Bitmap?,
    schoolName: String,
    size: Dp,
    circular: Boolean,
) {
    if (logoBitmap != null) {
        val shape = if (circular) CircleShape else RoundedCornerShape(12.dp)
        Image(
            bitmap = logoBitmap.asImageBitmap(),
            contentDescription = "School Logo",
            modifier = Modifier
                .size(size)
                .clip(shape)
                .border(1.dp, Color(0xFFCBD5E1), shape),
            contentScale = if (circular) ContentScale.Crop else ContentScale.Fit,
        )
    } else {
        DefaultSchoolStampCanvas(schoolName = schoolName, size = size)
    }
}

@Composable
fun DefaultSchoolStampCanvas(
    schoolName: String,
    size: Dp,
) {
    Box(
        modifier = Modifier.size(size),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val r = this.size.minDimension / 2f
            val c = Offset(this.size.width / 2f, this.size.height / 2f)
            val stampBlue = Color(0xFF1D4ED8)
            val stampFill = Color(0xFFEFF6FF)

            drawCircle(color = stampFill, radius = r * 0.96f, center = c)
            drawCircle(color = stampBlue, radius = r * 0.96f, center = c, style = Stroke(width = 2.4f))
            drawCircle(color = stampBlue, radius = r * 0.87f, center = c, style = Stroke(width = 1.0f))
            drawCircle(color = stampBlue, radius = r * 0.56f, center = c, style = Stroke(width = 1.4f))

            // Open book crest in center
            val bw = r * 0.34f
            val bh = r * 0.22f
            val bookPath = Path().apply {
                moveTo(c.x - bw, c.y - bh * 0.5f)
                quadraticTo(c.x - bw * 0.5f, c.y - bh, c.x, c.y - bh * 0.35f)
                quadraticTo(c.x + bw * 0.5f, c.y - bh, c.x + bw, c.y - bh * 0.5f)
                lineTo(c.x + bw, c.y + bh * 0.65f)
                quadraticTo(c.x + bw * 0.5f, c.y + bh * 0.25f, c.x, c.y + bh * 0.7f)
                quadraticTo(c.x - bw * 0.5f, c.y + bh * 0.25f, c.x - bw, c.y + bh * 0.65f)
                close()
            }
            drawPath(bookPath, color = stampBlue, style = Stroke(width = 1.8f))
            drawLine(
                color = stampBlue,
                start = Offset(c.x, c.y - bh * 0.35f),
                end = Offset(c.x, c.y + bh * 0.7f),
                strokeWidth = 1.6f,
            )
        }
        Text(
            text = schoolName.take(14).uppercase(),
            fontSize = (size.value * 0.085f).coerceIn(5.5f, 8.5f).sp,
            fontWeight = FontWeight.ExtraBold,
            color = Color(0xFF1E40AF),
            maxLines = 1,
            modifier = Modifier.align(Alignment.TopCenter).padding(top = size * 0.13f),
        )
        Text(
            text = "★ ACADEMIC ★",
            fontSize = (size.value * 0.075f).coerceIn(5f, 7.5f).sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF1E40AF),
            maxLines = 1,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = size * 0.12f),
        )
    }
}

@Composable
fun AddStudentDialog(
    className: String,
    onDismiss: () -> Unit,
    onAdd: (name: String, idNo: String, conduct: String) -> Unit,
) {
    var name by remember { mutableStateOf("") }
    var idNo by remember { mutableStateOf("") }
    var conduct by remember { mutableStateOf("38") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Student to $className", style = MaterialTheme.typography.titleMedium) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Full Name") },
                    placeholder = { Text("e.g. MUGISHA ERIC") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("new_student_name_input"),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = idNo,
                        onValueChange = { idNo = it },
                        label = { Text("ID No.") },
                        placeholder = { Text("Optional") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                    )
                    OutlinedTextField(
                        value = conduct,
                        onValueChange = { conduct = it },
                        label = { Text("Conduct") },
                        placeholder = { Text("38") },
                        singleLine = true,
                        modifier = Modifier.weight(0.8f),
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onAdd(name, idNo, conduct)
                        onDismiss()
                    }
                },
                enabled = name.isNotBlank(),
                modifier = Modifier.testTag("confirm_add_student_button"),
            ) {
                Text("Add Student")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
    )
}

@Composable
fun BulkPasteStudentsDialog(
    className: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
) {
    var rawText by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Bulk Add Students ($className)", style = MaterialTheme.typography.titleMedium) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Paste student names below (one student per line):",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                OutlinedTextField(
                    value = rawText,
                    onValueChange = { rawText = it },
                    minLines = 5,
                    maxLines = 9,
                    placeholder = { Text("KAMALI JEAN\nUWIMANA MARIE\nMUGABO PAUL") },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (rawText.isNotBlank()) {
                        onConfirm(rawText)
                        onDismiss()
                    }
                },
                enabled = rawText.isNotBlank(),
            ) {
                Text("Add All")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
    )
}

@Composable
fun CreateClassDialog(
    activeClassName: String?,
    onDismiss: () -> Unit,
    onCreate: (name: String, copySubjects: Boolean) -> Unit,
) {
    var className by remember { mutableStateOf("") }
    var copySubjects by remember { mutableStateOf(true) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create New Class", style = MaterialTheme.typography.titleMedium) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = className,
                    onValueChange = { className = it },
                    label = { Text("Class Name (e.g. P5, P6, S1)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                if (!activeClassName.isNullOrBlank()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = copySubjects, onCheckedChange = { copySubjects = it })
                        Text(
                            text = "Copy subjects & weights from $activeClassName",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (className.isNotBlank()) {
                        onCreate(className, copySubjects)
                        onDismiss()
                    }
                },
                enabled = className.isNotBlank(),
            ) {
                Text("Create")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
    )
}
