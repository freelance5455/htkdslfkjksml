package com.example.ui

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ads.AdMobManager
import com.example.data.DailyChallenges
import com.example.data.QUIZ_ITEMS
import com.example.notification.DailyReminderManager
import com.example.ui.components.AdRewardTarget
import com.example.ui.components.DailyChallengeDialog
import com.example.ui.components.HintBar
import com.example.ui.components.KeyboardPool
import com.example.ui.components.LeaderboardDialog
import com.example.ui.components.LetterSlots
import com.example.ui.components.LevelsDialog
import com.example.ui.components.ProfileDialog
import com.example.ui.components.RewardedAdDialog
import com.example.ui.components.TasksDialog
import com.example.ui.components.TopStatsBar
import com.example.ui.components.VictoryDialog
import com.example.ui.components.ZoomViewer
import com.example.ui.theme.GameAmber
import com.example.ui.theme.GameAmberBright
import com.example.ui.theme.GameDarkBackground
import com.example.ui.theme.GameEmerald
import com.example.ui.theme.GameOrange
import com.example.ui.theme.GameRose
import com.example.ui.theme.GameSurfaceDark
import com.example.ui.theme.GameSurfaceElevated
import com.example.ui.theme.GameViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.GameViewModel

@Composable
fun GuessTheImageApp(
    viewModel: GameViewModel = viewModel(),
    openDailyOnLaunch: Boolean = false,
    onDailyOpened: () -> Unit = {}
) {
    val context = LocalContext.current
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val scrollState = rememberScrollState()
    var activeAdRewardTarget by remember { mutableStateOf<AdRewardTarget?>(null) }

    val handleRequestRewardedAd: (AdRewardTarget) -> Unit = { target ->
        val activity = context as? Activity
        if (activity != null && AdMobManager.isAdLoaded()) {
            AdMobManager.showRewardedAd(
                activity = activity,
                onUserEarnedReward = { _, _ ->
                    when (target) {
                        AdRewardTarget.HINT -> viewModel.requestHint(viaAd = true)
                        AdRewardTarget.REVEAL_LETTER -> viewModel.revealOneLetter(viaAd = true)
                        AdRewardTarget.REMOVE_WRONG -> viewModel.removeThreeWrongLetters(viaAd = true)
                        AdRewardTarget.COINS_BONUS -> viewModel.addAdRewardCoins(50)
                    }
                },
                onFallbackToSimulatedAd = {
                    activeAdRewardTarget = target
                }
            )
        } else {
            activeAdRewardTarget = target
        }
    }

    // Handle opening Daily Challenge from push notification
    LaunchedEffect(openDailyOnLaunch) {
        if (openDailyOnLaunch) {
            viewModel.setShowDailyDialog(true)
            onDailyOpened()
        }
    }

    // Android 13+ Notification Permission Launcher
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        val permissionLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.RequestPermission()
        ) { isGranted ->
            if (isGranted) {
                DailyReminderManager.scheduleDailyReminder(context)
            }
        }

        LaunchedEffect(Unit) {
            val permissionCheck = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            )
            if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
                permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    val levelItems = QUIZ_ITEMS.filter { it.level == state.currentItem.level }
    val solvedInLevel = levelItems.count { state.solvedIds.contains(it.id) }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("guess_the_image_screen"),
        containerColor = GameDarkBackground,
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            TopStatsBar(
                score = state.userStats.score,
                coins = state.userStats.coins,
                streak = state.userStats.streak,
                currentLevel = state.userStats.currentLevel,
                dailyStreak = state.userStats.dailyStreakDays,
                dailyMultiplierLabel = state.dailyMultiplierLabel,
                unclaimedTasksCount = state.unclaimedTasksCount,
                avatar = state.userStats.avatar,
                playerName = state.userStats.playerName,
                profileTheme = state.userStats.profileTheme,
                onOpenProfile = { viewModel.setShowProfileDialog(true) },
                onOpenLevels = { viewModel.setShowLevelsDialog(true) },
                onOpenDaily = { viewModel.setShowDailyDialog(true) },
                onOpenTasks = { viewModel.setShowTasksDialog(true) },
                onOpenLeaderboard = { viewModel.setShowLeaderboardDialog(true) }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 600.dp)
                    .verticalScroll(scrollState)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Daily Challenge Active Banner
                if (state.isDailyMode) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        color = Color(0xFF28133C),
                        border = androidx.compose.foundation.BorderStroke(1.dp, GameViolet)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("🌟", fontSize = 18.sp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "DAILY CHALLENGE ACTIVE",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Color(0xFFF5D0FE)
                                    )
                                    Text(
                                        text = "Streak Multiplier: ${state.dailyMultiplierLabel} • Scaled Rewards",
                                        fontSize = 11.sp,
                                        color = GameAmberBright,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            OutlinedButton(
                                onClick = { viewModel.nextPuzzle() },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.height(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Exit Daily",
                                    tint = TextSecondary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Exit", fontSize = 11.sp, color = TextSecondary)
                            }
                        }
                    }
                }

                // Category & Difficulty Pill Row
                val difficultyColor = when (state.currentItem.difficulty.lowercase()) {
                    "easy" -> GameEmerald
                    "medium" -> GameAmber
                    "hard" -> GameOrange
                    "very hard" -> Color(0xFFA855F7)
                    "extreme" -> GameRose
                    "grandmaster" -> Color(0xFFFFD700)
                    else -> GameAmber
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Category Tag
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = GameSurfaceDark,
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF26334D))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Category,
                                contentDescription = null,
                                tint = GameAmber,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = state.currentItem.categoryLabel,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }

                    // Difficulty & Solved Tag
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = difficultyColor.copy(alpha = 0.15f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, difficultyColor.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "⚡ ${state.currentItem.difficulty}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    color = difficultyColor
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = GameSurfaceDark,
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF26334D))
                        ) {
                            Text(
                                text = if (state.isDailyMode) "Daily Special" else "Lvl ${state.currentItem.level} • $solvedInLevel/${levelItems.size}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextSecondary,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                            )
                        }
                    }
                }

                // Interactive Zoom Image Viewport
                ZoomViewer(
                    item = state.currentItem,
                    zoomStage = state.zoomStage,
                    onZoomOut = { viewModel.onZoomOut() },
                    isRevealed = state.isRevealed,
                    scoreBonus = viewModel.getScoreBonusForCurrentStage()
                )

                // Letter Slots
                LetterSlots(
                    placedLetters = state.placedLetters,
                    isRevealed = state.isRevealed,
                    isWrongShake = state.isWrongShake,
                    onRemoveLetter = { index -> viewModel.onPlacedSlotClicked(index) }
                )

                if (state.isRevealed) {
                    // Action controls when revealed
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { viewModel.setShowLevelsDialog(true) },
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Text("Levels Map", fontSize = 13.sp, color = TextSecondary, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { viewModel.nextPuzzle() },
                            modifier = Modifier
                                .weight(1.4f)
                                .height(50.dp)
                                .testTag("main_next_image_button"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = GameAmber,
                                contentColor = Color(0xFF0F172A)
                            )
                        ) {
                            Text("Next Image", fontSize = 14.sp, fontWeight = FontWeight.Black)
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                } else {
                    // Keyboard Letter Pool
                    KeyboardPool(
                        tiles = state.keyboardTiles,
                        onTileClick = { tile -> viewModel.onKeyboardTileClicked(tile) },
                        onBackspace = { viewModel.onBackspace() },
                        onClearAll = { viewModel.clearAllPlacedSlots() }
                    )

                    // Hints & Subtle Clue System
                    HintBar(
                        score = state.userStats.score,
                        coins = state.userStats.coins,
                        isSubtleClueUnlocked = state.isSubtleClueUnlocked,
                        onUnlockSubtleClue = { viewModel.unlockSubtleClue() },
                        subtleClueFeedback = state.subtleClueFeedback,
                        onRevealLetter = { viewModel.revealOneLetter() },
                        onRemoveWrong = { viewModel.removeThreeWrongLetters() },
                        onGetHint = { viewModel.requestHint() },
                        onRequestRewardedAd = handleRequestRewardedAd,
                        activeClueText = state.activeClueText,
                        categoryLabel = state.currentItem.categoryLabel
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    // Victory Celebration Dialog
    state.victorySummary?.let { summary ->
        VictoryDialog(
            item = state.currentItem,
            summary = summary,
            onNextImage = {
                viewModel.dismissVictoryDialog()
                viewModel.nextPuzzle()
            },
            onGoToLevels = {
                viewModel.dismissVictoryDialog()
                viewModel.setShowLevelsDialog(true)
            },
            onDismiss = { viewModel.dismissVictoryDialog() }
        )
    }

    // Tasks & Quests Dialog
    if (state.showTasksDialog) {
        TasksDialog(
            dailyTasks = state.dailyTasks,
            achievements = state.achievements,
            onClaimTask = { task -> viewModel.claimTaskReward(task) },
            onDismiss = { viewModel.setShowTasksDialog(false) }
        )
    }

    // Levels Dialog
    if (state.showLevelsDialog) {
        LevelsDialog(
            currentLevel = state.userStats.currentLevel,
            unlockedLevel = state.userStats.unlockedLevel,
            score = state.userStats.score,
            totalSolved = state.solvedIds.size,
            allItems = QUIZ_ITEMS,
            solvedIds = state.solvedIds,
            onSelectLevel = { lvl -> viewModel.selectLevel(lvl) },
            onDismiss = { viewModel.setShowLevelsDialog(false) }
        )
    }

    // Daily Challenge Dialog
    if (state.showDailyDialog) {
        DailyChallengeDialog(
            dailyItem = DailyChallenges.getTodayDailyItem(),
            isCompletedToday = state.isDailyCompletedToday,
            streakDays = state.userStats.dailyStreakDays,
            multiplierLabel = state.dailyMultiplierLabel,
            dailyHistory = state.userStats.dailyHistory,
            highestStreak = state.userStats.highestDailyStreak,
            isReminderEnabled = state.isDailyReminderEnabled,
            onToggleReminder = { viewModel.toggleDailyReminder(it) },
            onTestReminder = { viewModel.triggerTestReminder() },
            onPlayDaily = { viewModel.playDailyChallenge() },
            onDismiss = { viewModel.setShowDailyDialog(false) }
        )
    }

    // Leaderboard Dialog
    if (state.showLeaderboardDialog) {
        val acc = if (state.userStats.totalGuesses > 0) {
            (state.userStats.correctGuesses * 100) / state.userStats.totalGuesses
        } else 100

        LeaderboardDialog(
            entries = state.leaderboardEntries,
            currentScore = state.userStats.score,
            currentLevel = state.userStats.unlockedLevel,
            accuracy = acc,
            streak = state.userStats.bestStreak,
            onSubmitScore = { name -> viewModel.submitLeaderboardScore(name) },
            onDismiss = { viewModel.setShowLeaderboardDialog(false) }
        )
    }

    // Profile & Customization Dialog
    if (state.showProfileDialog) {
        ProfileDialog(
            userStats = state.userStats,
            onSaveProfile = { name, avatar, title, theme ->
                viewModel.updateProfile(name, avatar, title, theme)
            },
            onSaveAllProgress = {
                viewModel.saveAllProgressNow()
            },
            lastSavedTime = state.lastSavedTimestamp,
            onDismiss = { viewModel.setShowProfileDialog(false) }
        )
    }

    // Rewarded Ad Dialog (AdMob Video Ad Player)
    activeAdRewardTarget?.let { target ->
        RewardedAdDialog(
            target = target,
            onRewardEarned = {
                when (target) {
                    AdRewardTarget.HINT -> viewModel.requestHint(viaAd = true)
                    AdRewardTarget.REVEAL_LETTER -> viewModel.revealOneLetter(viaAd = true)
                    AdRewardTarget.REMOVE_WRONG -> viewModel.removeThreeWrongLetters(viaAd = true)
                    AdRewardTarget.COINS_BONUS -> viewModel.addAdRewardCoins(50)
                }
            },
            onDismiss = { activeAdRewardTarget = null }
        )
    }
}
