package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.XtraCyanGlow
import com.example.ui.theme.XtraCyanPrimary
import com.example.ui.theme.XtraElectricBlue
import kotlin.math.sin

@Composable
fun SoundWaveVisualizer(
    isActive: Boolean,
    audioRms: Float,
    modifier: Modifier = Modifier,
    height: Dp = 48.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "waveAnim")

    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
    ) {
        val barCount = 28
        val spacing = 4.dp.toPx()
        val totalSpacing = spacing * (barCount - 1)
        val barWidth = (size.width - totalSpacing) / barCount
        val maxHeight = size.height

        val gradient = Brush.verticalGradient(
            colors = listOf(
                XtraCyanPrimary,
                XtraCyanGlow,
                XtraElectricBlue
            )
        )

        for (i in 0 until barCount) {
            val normalizedIdx = i.toFloat() / barCount
            // Bell curve window so bars are higher in the center
            val bellWindow = sin(normalizedIdx * Math.PI).toFloat()

            val dynamicFactor = if (isActive) {
                val wave = (sin(phase + normalizedIdx * 4) + 1f) / 2f
                val rmsFactor = (audioRms * 1.5f).coerceIn(0.15f, 1f)
                (0.2f + 0.8f * wave * rmsFactor) * bellWindow
            } else {
                0.06f * bellWindow
            }

            val barHeight = (maxHeight * dynamicFactor).coerceAtLeast(4.dp.toPx())
            val x = i * (barWidth + spacing)
            val y = (maxHeight - barHeight) / 2f

            drawRoundRect(
                brush = gradient,
                topLeft = Offset(x, y),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx()),
                alpha = if (isActive) 0.95f else 0.35f
            )
        }
    }
}
