package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SufiLanguage
import com.example.ui.theme.GoldLuster
import com.example.ui.theme.GoldLusterBright
import com.example.ui.theme.TerracottaDark

/**
 * TasbeehPeaceCounter:
 * Minimal sacred pill displaying the moments of peace / reflection completed.
 */
@Composable
fun TasbeehPeaceCounter(
    peaceMomentsCount: Int,
    language: SufiLanguage,
    onTapCounter: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(TerracottaDark.copy(alpha = 0.65f))
            .border(1.dp, GoldLuster.copy(alpha = 0.45f), RoundedCornerShape(20.dp))
            .clickable { onTapCounter() }
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .testTag("peace_counter_pill"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Text(
            text = "📿",
            fontSize = 13.sp
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = if (language == SufiLanguage.MALAYALAM)
                "$peaceMomentsCount സാന്ത്വന നിമിഷങ്ങൾ"
            else
                "$peaceMomentsCount Moments of Serenity",
            style = MaterialTheme.typography.labelSmall,
            fontFamily = FontFamily.Serif,
            color = GoldLusterBright,
            fontWeight = FontWeight.Medium,
            fontSize = 11.sp,
            letterSpacing = 0.8.sp
        )
    }
}
