package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Today
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MainTab
import com.example.data.model.TimetableFilter
import com.example.ui.MainUiState
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BrandIndigo
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.RoseFocus
import com.example.ui.theme.VioletAccent
import com.example.util.DateTimeUtils

import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.ui.unit.Dp

@Composable
fun TopPlatformHeader(
    uiState: MainUiState,
    onAddLessonClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onPrintClick: () -> Unit,
    onToggleThemeClick: () -> Unit,
    onTimerPillClick: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
        tonalElevation = 2.dp,
        shadowElevation = 2.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            val showExpandedActions = maxWidth >= 520.dp
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(BrandIndigo, Color(0xFF6366F1), VioletAccent)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.School,
                            contentDescription = "شعار منصة الثانوية",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "منصة الثانوية العامة",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "منظم الدروس والمناهج والواجبات",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    AnimatedVisibility(visible = uiState.pomodoro.isRunning) {
                        Surface(
                            onClick = onTimerPillClick,
                            color = RoseFocus.copy(alpha = 0.14f),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, RoseFocus.copy(alpha = 0.4f)),
                            modifier = Modifier
                                .testTag("header_timer_pill")
                                .minimumInteractiveComponentSize()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Timer,
                                    contentDescription = "المؤقت يعمل",
                                    tint = RoseFocus,
                                    modifier = Modifier.size(15.dp)
                                )
                                Text(
                                    text = DateTimeUtils.formatCountdownTimer(uiState.pomodoro.remainingSeconds),
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Black,
                                    color = RoseFocus
                                )
                            }
                        }
                    }

                    Button(
                        onClick = onAddLessonClick,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BrandIndigo,
                            contentColor = Color.White
                        ),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(
                            horizontal = if (showExpandedActions) 12.dp else 10.dp,
                            vertical = 8.dp
                        ),
                        modifier = Modifier
                            .testTag("header_add_lesson_button")
                            .minimumInteractiveComponentSize()
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Add,
                            contentDescription = "إضافة درس",
                            modifier = Modifier.size(18.dp)
                        )
                        if (showExpandedActions) {
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "إضافة درس",
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }

                    FilledTonalIconButton(
                        onClick = onSettingsClick,
                        modifier = Modifier.testTag("header_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Tune,
                            contentDescription = "الإعدادات والنسخ الاحتياطي"
                        )
                    }

                    if (showExpandedActions) {
                        FilledTonalIconButton(
                            onClick = onPrintClick,
                            modifier = Modifier.testTag("header_print_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Print,
                                contentDescription = "طباعة الجدول"
                            )
                        }
                    }

                    FilledTonalIconButton(
                        onClick = onToggleThemeClick,
                        colors = IconButtonDefaults.filledTonalIconButtonColors(
                            contentColor = if (uiState.isDarkTheme) Color(0xFFFACC15) else AmberWarning
                        ),
                        modifier = Modifier.testTag("header_theme_button")
                    ) {
                        Icon(
                            imageVector = if (uiState.isDarkTheme) Icons.Filled.LightMode else Icons.Filled.DarkMode,
                            contentDescription = "تبديل الوضع الليلي"
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CountdownMotivationBanner(
    uiState: MainUiState,
    onNextQuoteClick: () -> Unit,
    onEditExamDateClick: () -> Unit,
    isWide: Boolean
) {
    val gradientColors = if (uiState.isDarkTheme) {
        listOf(Color(0xFF312E81), Color(0xFF3730A3), Color(0xFF0F172A))
    } else {
        listOf(BrandIndigo, Color(0xFF4338CA), VioletAccent)
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.horizontalGradient(gradientColors))
            .padding(20.dp)
    ) {
        if (isWide) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                BannerQuoteColumn(
                    dateText = uiState.todayArabicDate,
                    quote = uiState.currentQuote,
                    onNextQuoteClick = onNextQuoteClick,
                    modifier = Modifier
                        .weight(1f)
                        .padding(end = 16.dp)
                )
                ExamCountdownCard(
                    examDate = uiState.examDate,
                    days = uiState.countdownDays,
                    hours = uiState.countdownHours,
                    onClick = onEditExamDateClick
                )
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                BannerQuoteColumn(
                    dateText = uiState.todayArabicDate,
                    quote = uiState.currentQuote,
                    onNextQuoteClick = onNextQuoteClick
                )
                ExamCountdownCard(
                    examDate = uiState.examDate,
                    days = uiState.countdownDays,
                    hours = uiState.countdownHours,
                    onClick = onEditExamDateClick,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun BannerQuoteColumn(
    dateText: String,
    quote: String,
    onNextQuoteClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                color = Color.White.copy(alpha = 0.16f),
                shape = CircleShape
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.CalendarToday,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(13.dp)
                    )
                    Text(
                        text = dateText,
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White
                    )
                }
            }

            Surface(
                onClick = onNextQuoteClick,
                color = Color.White.copy(alpha = 0.12f),
                shape = CircleShape,
                modifier = Modifier.testTag("next_quote_button")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.AutoAwesome,
                        contentDescription = "عبارة تحفيزية جديدة",
                        tint = Color(0xFFFDE68A),
                        modifier = Modifier.size(13.dp)
                    )
                    Text(
                        text = "عبارة جديدة",
                        style = MaterialTheme.typography.labelMedium,
                        color = Color.White
                    )
                }
            }
        }

        Text(
            text = quote,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.ExtraBold,
            color = Color.White,
            lineHeight = 22.sp
        )
    }
}

@Composable
private fun ExamCountdownCard(
    examDate: String,
    days: Long,
    hours: Long,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        color = Color.Black.copy(alpha = 0.28f),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.16f)),
        modifier = modifier.testTag("exam_countdown_card")
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.padding(end = 12.dp)) {
                Text(
                    text = "العد التنازلي للامتحانات",
                    style = MaterialTheme.typography.labelMedium,
                    color = Color(0xFFE0E7FF)
                )
                Text(
                    text = examDate,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFFC7D2FE)
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CountdownUnitBox(value = days.toString(), unit = "يوم")
                CountdownUnitBox(value = hours.toString(), unit = "ساعة")
            }
        }
    }
}

@Composable
private fun CountdownUnitBox(value: String, unit: String) {
    Surface(
        color = Color.White.copy(alpha = 0.16f),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black,
                color = Color.White
            )
            Text(
                text = unit,
                style = MaterialTheme.typography.labelSmall,
                color = Color(0xFFE0E7FF)
            )
        }
    }
}

@Composable
fun StatsDashboardGrid(
    uiState: MainUiState,
    isWide: Boolean,
    onStatClick: (MainTab, TimetableFilter?) -> Unit
) {
    val todayLessons = uiState.lessons.filter { it.day == uiState.todayDayName }
    val attendedToday = todayLessons.count { it.attended }

    val totalSyllabus = uiState.tracks.sumOf { it.lessons.size }
    val doneSyllabus = uiState.tracks.sumOf { t -> t.lessons.count { it.completed } }
    val syllabusPct = if (totalSyllabus > 0) (doneSyllabus * 100 / totalSyllabus) else 0

    val pendingTasks = uiState.tasks.count { !it.completed }

    if (isWide) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            StatKpiCard(
                title = "دروس اليوم",
                value = todayLessons.size.toString(),
                subtitle = "$attendedToday تم حضورها",
                accent = BrandIndigo,
                icon = Icons.Filled.Today,
                onClick = { onStatClick(MainTab.TIMETABLE, TimetableFilter.TODAY) },
                modifier = Modifier.weight(1f).testTag("stat_today_lessons")
            )
            StatKpiCard(
                title = "حصص الأسبوع",
                value = uiState.lessons.size.toString(),
                subtitle = "إجمالي الجدول",
                accent = Color(0xFF6366F1),
                icon = Icons.AutoMirrored.Filled.MenuBook,
                onClick = { onStatClick(MainTab.TIMETABLE, TimetableFilter.ALL) },
                modifier = Modifier.weight(1f).testTag("stat_total_lessons")
            )
            StatSyllabusCard(
                pct = syllabusPct,
                onClick = { onStatClick(MainTab.TRACKS, null) },
                modifier = Modifier.weight(1f).testTag("stat_syllabus")
            )
            StatKpiCard(
                title = "الواجبات المتبقية",
                value = pendingTasks.toString(),
                subtitle = "${uiState.focusStats.minutes} د تركيز اليوم",
                accent = AmberWarning,
                icon = Icons.Filled.Checklist,
                onClick = { onStatClick(MainTab.TASKS, null) },
                modifier = Modifier.weight(1f).testTag("stat_pending_tasks")
            )
        }
    } else {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatKpiCard(
                    title = "دروس اليوم",
                    value = todayLessons.size.toString(),
                    subtitle = "$attendedToday تم حضورها",
                    accent = BrandIndigo,
                    icon = Icons.Filled.Today,
                    onClick = { onStatClick(MainTab.TIMETABLE, TimetableFilter.TODAY) },
                    modifier = Modifier.weight(1f).testTag("stat_today_lessons")
                )
                StatKpiCard(
                    title = "حصص الأسبوع",
                    value = uiState.lessons.size.toString(),
                    subtitle = "إجمالي الجدول",
                    accent = Color(0xFF6366F1),
                    icon = Icons.AutoMirrored.Filled.MenuBook,
                    onClick = { onStatClick(MainTab.TIMETABLE, TimetableFilter.ALL) },
                    modifier = Modifier.weight(1f).testTag("stat_total_lessons")
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatSyllabusCard(
                    pct = syllabusPct,
                    onClick = { onStatClick(MainTab.TRACKS, null) },
                    modifier = Modifier.weight(1f).testTag("stat_syllabus")
                )
                StatKpiCard(
                    title = "الواجبات المتبقية",
                    value = pendingTasks.toString(),
                    subtitle = "${uiState.focusStats.minutes} د تركيز اليوم",
                    accent = AmberWarning,
                    icon = Icons.Filled.Checklist,
                    onClick = { onStatClick(MainTab.TASKS, null) },
                    modifier = Modifier.weight(1f).testTag("stat_pending_tasks")
                )
            }
        }
    }
}

@Composable
private fun StatKpiCard(
    title: String,
    value: String,
    subtitle: String,
    accent: Color,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = value,
                    style = MaterialTheme.typography.headlineMedium,
                    color = accent,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(accent.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = accent,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}

@Composable
private fun StatSyllabusCard(
    pct: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 8.dp)
            ) {
                Text(
                    text = "إنجاز المناهج",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
                Text(
                    text = "$pct%",
                    style = MaterialTheme.typography.headlineMedium,
                    color = EmeraldSuccess,
                    fontWeight = FontWeight.Black
                )
                Spacer(modifier = Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { (pct / 100f).coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(CircleShape),
                    color = EmeraldSuccess,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
            }
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(EmeraldSuccess.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.ShowChart,
                    contentDescription = "إنجاز المناهج",
                    tint = EmeraldSuccess,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}
