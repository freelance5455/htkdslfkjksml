package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Airport
import com.example.ui.navigation.Screen

@Composable
fun AtcDrawer(
  currentScreen: Screen,
  selectedAirport: Airport?,
  onNavigateTo: (Screen) -> Unit,
  onCloseDrawer: () -> Unit,
  modifier: Modifier = Modifier
) {
  ModalDrawerSheet(
    modifier = modifier.widthIn(max = 320.dp).testTag("atc_navigation_drawer"),
    drawerContainerColor = MaterialTheme.colorScheme.surface,
    drawerContentColor = MaterialTheme.colorScheme.onSurface
  ) {
    // Drawer Header (Ocean Blue)
    Surface(
      color = com.example.ui.theme.OceanBlue,
      modifier = Modifier.fillMaxWidth()
    ) {
      Column(modifier = Modifier.padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.AirplanemodeActive,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(28.dp)
          )
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = "ATC Aviation Weather",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = Color.White
            )
            Text(
              text = "Operational Aviation Weather Console",
              style = MaterialTheme.typography.labelSmall,
              color = Color(0xFFBAE6FD)
            )
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (selectedAirport != null) {
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(10.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Column {
                Text(
                  text = "${selectedAirport.icao} / ${selectedAirport.iata}",
                  style = MaterialTheme.typography.titleSmall,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.primary
                )
                Text(
                  text = selectedAirport.nameEn.ifBlank { selectedAirport.nameFa },
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
              Surface(
                shape = RoundedCornerShape(4.dp),
                color = MaterialTheme.colorScheme.secondaryContainer
              ) {
                Text(
                  text = selectedAirport.countryEn.ifBlank { selectedAirport.countryFa },
                  style = MaterialTheme.typography.labelSmall,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
              }
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    // Navigation Items
    LazyColumn(
      modifier = Modifier.weight(1f).padding(horizontal = 12.dp)
    ) {
      items(Screen.values()) { screen ->
        val isSelected = currentScreen == screen
        NavigationDrawerItem(
          icon = {
            Icon(
              imageVector = screen.icon,
              contentDescription = null,
              tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
            )
          },
          label = {
            Column {
              Text(
                text = screen.titleFa,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = screen.titleEn,
                style = MaterialTheme.typography.labelSmall,
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          },
          selected = isSelected,
          onClick = {
            onNavigateTo(screen)
            onCloseDrawer()
          },
          shape = RoundedCornerShape(10.dp),
          colors = NavigationDrawerItemDefaults.colors(
            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
            unselectedContainerColor = Color.Transparent
          ),
          modifier = Modifier.padding(vertical = 2.dp).testTag("drawer_item_${screen.route}")
        )
      }
    }

    Divider(modifier = Modifier.padding(horizontal = 16.dp))

    // Operational Notice Footer
    Text(
      text = "Operational Console v1.0 • ICAO Annex 3 / Doc 10066",
      style = MaterialTheme.typography.labelSmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
      modifier = Modifier.padding(16.dp)
    )
  }
}
