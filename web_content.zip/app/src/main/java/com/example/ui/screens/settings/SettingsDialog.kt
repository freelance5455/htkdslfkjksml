package com.example.ui.screens.settings

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.DirectionsBike
import androidx.compose.material.icons.filled.OfflinePin
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserProfile
import com.example.ui.theme.DexterCyanPrimary
import com.example.ui.theme.DexterEmeraldSecondary
import com.example.ui.theme.DexterSurface
import com.example.ui.theme.DexterSurfaceVariant

@Composable
fun SettingsDialog(
    userProfile: UserProfile,
    onDismiss: () -> Unit,
    onSave: (name: String, defaultRate: Double, vehicleNumber: String) -> Unit
) {
    var name by remember { mutableStateOf(userProfile.agentName) }
    var rateText by remember { mutableStateOf(userProfile.defaultRate.toInt().toString()) }
    var vehicleNumber by remember { mutableStateOf(userProfile.vehicleNumber) }

    val rateDouble = rateText.toDoubleOrNull() ?: 14.0

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DexterSurface,
        shape = RoundedCornerShape(24.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Default.Tune,
                    contentDescription = null,
                    tint = DexterCyanPrimary,
                    modifier = Modifier.padding(end = 8.dp)
                )
                Text(
                    text = "Agent & Rate Settings",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Rate Setting Input (Highlighted)
                Column {
                    OutlinedTextField(
                        value = rateText,
                        onValueChange = { rateText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        label = { Text("Default Rate Per Delivery (₹)") },
                        supportingText = { Text("Applied to all new daily entries", color = Color(0xFF64748B)) },
                        leadingIcon = { Icon(Icons.Default.CurrencyRupee, contentDescription = "Default Rate", tint = DexterEmeraldSecondary) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = DexterEmeraldSecondary,
                            unfocusedBorderColor = Color(0xFF334155),
                            focusedContainerColor = DexterSurfaceVariant,
                            unfocusedContainerColor = DexterSurfaceVariant
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().testTag("settings_default_rate_input")
                    )

                    // Quick Rate Chips
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(12, 14, 16, 18, 20).forEach { presetRate ->
                            val isSelected = rateDouble.toInt() == presetRate
                            FilterChip(
                                selected = isSelected,
                                onClick = { rateText = presetRate.toString() },
                                label = { Text("₹$presetRate", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = DexterEmeraldSecondary,
                                    selectedLabelColor = Color(0xFF003822),
                                    containerColor = DexterSurfaceVariant,
                                    labelColor = Color(0xFF94A3B8)
                                ),
                                border = BorderStroke(1.dp, if (isSelected) DexterEmeraldSecondary else Color(0xFF334155))
                            )
                        }
                    }
                }

                // Agent Name Input
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Agent Name") },
                    leadingIcon = { Icon(Icons.Default.Badge, contentDescription = "Agent Name", tint = DexterCyanPrimary) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = DexterCyanPrimary,
                        unfocusedBorderColor = Color(0xFF334155),
                        focusedContainerColor = DexterSurfaceVariant,
                        unfocusedContainerColor = DexterSurfaceVariant
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                // Vehicle Number
                OutlinedTextField(
                    value = vehicleNumber,
                    onValueChange = { vehicleNumber = it },
                    label = { Text("Vehicle Registration No. (Optional)") },
                    leadingIcon = { Icon(Icons.Default.DirectionsBike, contentDescription = "Vehicle", tint = DexterCyanPrimary) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = DexterCyanPrimary,
                        unfocusedBorderColor = Color(0xFF334155),
                        focusedContainerColor = DexterSurfaceVariant,
                        unfocusedContainerColor = DexterSurfaceVariant
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                // Offline Notice
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFF0C243B),
                    border = BorderStroke(1.dp, DexterCyanPrimary.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(12.dp)
                    ) {
                        Icon(
                            Icons.Default.OfflinePin,
                            contentDescription = null,
                            tint = DexterCyanPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "100% Offline Mode: All calculations, cycles and entries operate locally with zero latency.",
                            fontSize = 11.sp,
                            color = Color(0xFFBAE6FD)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(name, rateDouble, vehicleNumber)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = DexterCyanPrimary,
                    contentColor = Color(0xFF001E2E)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("save_settings_button")
            ) {
                Text("Save Settings", fontWeight = FontWeight.ExtraBold)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Color(0xFF475569))
            ) {
                Text("Cancel", color = Color(0xFF94A3B8))
            }
        }
    )
}
