package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.outlined.Reply
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.ArkPost
import com.example.data.model.PostComment
import com.example.data.model.UserProfile
import com.example.ui.components.ArkAvatarBadge
import com.example.ui.components.formatPostTimestamp
import com.example.ui.theme.ArkThemeTokens

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommentBottomSheet(
    post: ArkPost,
    comments: List<PostComment>,
    currentUser: UserProfile,
    onDismiss: () -> Unit,
    onAddComment: (text: String, parentCommentId: String?, replyToUsername: String?) -> Unit,
    onLikeComment: (commentId: String) -> Unit,
    onDeleteComment: (commentId: String) -> Unit,
    onReportComment: (commentId: String) -> Unit,
    onToggleCommentsDisabled: (Boolean) -> Unit,
    onEditComment: (commentId: String, newText: String) -> Unit = { _, _ -> },
    onOpenUserProfile: (String) -> Unit = {}
) {
    val colors = ArkThemeTokens.colors
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val isPostOwner = post.authorId == currentUser.userId

    var input by remember { mutableStateOf("") }
    var replyingTo by remember { mutableStateOf<PostComment?>(null) }
    var sortTop by remember { mutableStateOf(false) }
    var editingCommentId by remember { mutableStateOf<String?>(null) }
    var editDraftText by remember { mutableStateOf("") }

    val orderedComments = remember(comments, sortTop) {
        if (sortTop) {
            comments.sortedWith(
                compareByDescending<PostComment> { it.likeCount }
                    .thenByDescending { it.createdAt?.seconds ?: 0L }
            )
        } else {
            comments.sortedByDescending { it.createdAt?.seconds ?: 0L }
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = colors.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .padding(bottom = 18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Comments (${comments.size})",
                    style = MaterialTheme.typography.titleLarge,
                    color = colors.ink
                )
                if (isPostOwner) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (post.commentsDisabled) "Locked" else "Open",
                            style = MaterialTheme.typography.labelMedium,
                            color = if (post.commentsDisabled) colors.coral else colors.success
                        )
                        Spacer(Modifier.width(6.dp))
                        Switch(
                            checked = !post.commentsDisabled,
                            onCheckedChange = { open -> onToggleCommentsDisabled(!open) }
                        )
                    }
                }
            }

            if (comments.size > 1) {
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = !sortTop,
                        onClick = { sortTop = false },
                        label = { Text("Newest") }
                    )
                    FilterChip(
                        selected = sortTop,
                        onClick = { sortTop = true },
                        label = { Text("Top") }
                    )
                }
            }

            Spacer(Modifier.height(8.dp))
            HorizontalDivider(color = colors.hairline)
            Spacer(Modifier.height(8.dp))

            if (orderedComments.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (post.commentsDisabled) {
                            "Comments are turned off for this post."
                        } else {
                            "No comments yet. Start the conversation!"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = colors.ink2
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 360.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(orderedComments, key = { it.id }) { comment ->
                        val isReply = !comment.parentCommentId.isNullOrBlank()
                        val isAuthor = comment.authorId == currentUser.userId
                        val canDelete = isAuthor || isPostOwner
                        val isEditingThis = editingCommentId == comment.id

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(start = if (isReply) 28.dp else 0.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            ArkAvatarBadge(
                                avatarPreset = comment.authorAvatar,
                                username = comment.authorUsername,
                                size = if (isReply) 28.dp else 34.dp,
                                modifier = Modifier.clickable(enabled = comment.authorId.isNotBlank()) {
                                    onDismiss()
                                    onOpenUserProfile(comment.authorId)
                                }
                            )
                            Spacer(Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "@${comment.authorUsername}",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = colors.ink,
                                        modifier = Modifier.clickable(enabled = comment.authorId.isNotBlank()) {
                                            onDismiss()
                                            onOpenUserProfile(comment.authorId)
                                        }
                                    )
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        text = formatPostTimestamp(comment.createdAt) + if (comment.isEdited) " • edited" else "",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = colors.ink3
                                    )
                                }
                                if (!comment.replyToUsername.isNullOrBlank()) {
                                    Text(
                                        text = "Replying to @${comment.replyToUsername}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = colors.accent
                                    )
                                }
                                if (isEditingThis) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        OutlinedTextField(
                                            value = editDraftText,
                                            onValueChange = { editDraftText = it.take(400) },
                                            singleLine = true,
                                            modifier = Modifier.weight(1f)
                                        )
                                        IconButton(
                                            enabled = editDraftText.trim().isNotBlank(),
                                            onClick = {
                                                onEditComment(comment.id, editDraftText)
                                                editingCommentId = null
                                            }
                                        ) {
                                            Icon(Icons.Default.Check, contentDescription = "Save comment edit", tint = colors.success)
                                        }
                                        IconButton(onClick = { editingCommentId = null }) {
                                            Icon(Icons.Default.Close, contentDescription = "Cancel comment edit")
                                        }
                                    }
                                } else {
                                    Text(
                                        text = comment.text,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = colors.ink
                                    )
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    TextButton(onClick = { onLikeComment(comment.id) }) {
                                        Icon(
                                            Icons.Default.Favorite,
                                            contentDescription = "Like comment",
                                            tint = if (comment.likeCount > 0L) colors.coral else colors.ink2,
                                            modifier = Modifier.size(15.dp)
                                        )
                                        Spacer(Modifier.width(4.dp))
                                        Text("${comment.likeCount}", style = MaterialTheme.typography.labelSmall)
                                    }
                                    if (!post.commentsDisabled) {
                                        TextButton(onClick = { replyingTo = comment }) {
                                            Icon(Icons.AutoMirrored.Outlined.Reply, contentDescription = "Reply", modifier = Modifier.size(15.dp))
                                            Spacer(Modifier.width(4.dp))
                                            Text("Reply", style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                    if (isAuthor && !isEditingThis) {
                                        IconButton(
                                            onClick = {
                                                editingCommentId = comment.id
                                                editDraftText = comment.text
                                            },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(Icons.Default.Edit, contentDescription = "Edit comment", tint = colors.ink2, modifier = Modifier.size(15.dp))
                                        }
                                    }
                                    if (canDelete) {
                                        IconButton(
                                            onClick = { onDeleteComment(comment.id) },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = "Delete comment", tint = colors.coral, modifier = Modifier.size(15.dp))
                                        }
                                    } else {
                                        IconButton(
                                            onClick = { onReportComment(comment.id) },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(Icons.Default.Flag, contentDescription = "Report comment", tint = colors.ink2, modifier = Modifier.size(15.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            if (post.commentsDisabled) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = colors.coral.copy(alpha = 0.14f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = colors.coral)
                        Spacer(Modifier.width(8.dp))
                        Text("Commenting is restricted by the post owner.", style = MaterialTheme.typography.bodySmall, color = colors.coral)
                    }
                }
            } else {
                if (replyingTo != null) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Replying to @${replyingTo!!.authorUsername}",
                            style = MaterialTheme.typography.labelMedium,
                            color = colors.accent
                        )
                        IconButton(onClick = { replyingTo = null }, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Cancel reply", modifier = Modifier.size(16.dp))
                        }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it.take(400) },
                        placeholder = { Text("Add a friendly comment...") },
                        singleLine = true,
                        modifier = Modifier.weight(1f).testTag("comment_input_field")
                    )
                    Spacer(Modifier.width(8.dp))
                    IconButton(
                        enabled = input.trim().isNotBlank(),
                        onClick = {
                            onAddComment(
                                input,
                                replyingTo?.id,
                                replyingTo?.authorUsername
                            )
                            input = ""
                            replyingTo = null
                        },
                        modifier = Modifier.testTag("send_comment_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Post comment", tint = colors.accent)
                    }
                }
            }
        }
    }
}
