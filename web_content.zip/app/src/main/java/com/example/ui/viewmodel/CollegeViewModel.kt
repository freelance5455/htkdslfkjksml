package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.CollegeRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed class Screen {
    object Home : Screen()
    object TeacherDirectory : Screen()
    object BatchManagement : Screen()
    object ComplaintRegistration : Screen()
    object ComplaintStatus : Screen()
    object NoticeBoard : Screen()
    object HolidayCalendar : Screen()
    object ClinicalDuty : Screen()
    object AdminDashboard : Screen()
    object HtmlAppView : Screen()
}

class CollegeViewModel(application: Application) : AndroidViewModel(application) {
    val repository = CollegeRepository(application.applicationContext)

    // Current navigation screen
    private val _currentScreen = MutableStateFlow<Screen>(Screen.Home)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    // Current User Session & Role
    private val _currentUser = MutableStateFlow(
        CurrentUserSession(
            userId = "user_guest",
            role = UserRole.STUDENT,
            name = "Student User",
            phone = "+91 98765 43210",
            email = "student@gnmtc-sgnr.edu.in",
            batch = "Batch 2024-25"
        )
    )
    val currentUser: StateFlow<CurrentUserSession> = _currentUser.asStateFlow()

    // Selected Batch for Batch & Clinical views
    private val _selectedBatch = MutableStateFlow(CollegeRepository.BATCHES[1]) // "Batch 2024-25"
    val selectedBatch: StateFlow<String> = _selectedBatch.asStateFlow()

    // Data streams
    val teachers: StateFlow<List<Teacher>> = repository.observeTeachers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notices: StateFlow<List<Notice>> = repository.observeNotices()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val holidays: StateFlow<List<Holiday>> = repository.observeHolidays()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allComplaints: StateFlow<List<Complaint>> = repository.observeAllComplaints()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Batch-dependent streams
    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val batchStudents: StateFlow<List<StudentPublic>> = _selectedBatch
        .flatMapLatest { repository.observeStudentsByBatch(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val batchCoordinator: StateFlow<BatchCoordinator?> = _selectedBatch
        .flatMapLatest { repository.observeCoordinator(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val batchSubjects: StateFlow<List<Subject>> = _selectedBatch
        .flatMapLatest { repository.observeSubjectsByBatch(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Selected Subject for Syllabus
    private val _selectedSubjectId = MutableStateFlow("")
    val selectedSubjectId: StateFlow<String> = _selectedSubjectId.asStateFlow()

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val batchLectures: StateFlow<List<SyllabusLecture>> = combine(_selectedBatch, _selectedSubjectId) { batch, subject ->
        Pair(batch, subject)
    }.flatMapLatest { (batch, subject) ->
        repository.observeLectures(batch, subject)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val batchAttendanceRecords: StateFlow<List<AttendanceRecord>> = _selectedBatch
        .flatMapLatest { repository.observeAttendanceRecords(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val batchClinicalRosters: StateFlow<List<ClinicalRoster>> = _selectedBatch
        .flatMapLatest { repository.observeClinicalRosters(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Complaint status lookup state
    private val _trackedComplaint = MutableStateFlow<Complaint?>(null)
    val trackedComplaint: StateFlow<Complaint?> = _trackedComplaint.asStateFlow()

    private val _isLookingUpComplaint = MutableStateFlow(false)
    val isLookingUpComplaint: StateFlow<Boolean> = _isLookingUpComplaint.asStateFlow()

    private val _complaintLookupError = MutableStateFlow<String?>(null)
    val complaintLookupError: StateFlow<String?> = _complaintLookupError.asStateFlow()

    // Sensitive student record modal state
    private val _viewingPrivateStudent = MutableStateFlow<StudentPrivate?>(null)
    val viewingPrivateStudent: StateFlow<StudentPrivate?> = _viewingPrivateStudent.asStateFlow()

    // Operation status message for snackbars
    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    init {
        viewModelScope.launch {
            repository.seedInitialDataIfEmpty()
        }
    }

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
    }

    fun selectBatch(batch: String) {
        _selectedBatch.value = batch
        _selectedSubjectId.value = ""
    }

    fun selectSubject(subjectId: String) {
        _selectedSubjectId.value = subjectId
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    // Role Switching & Auth
    fun switchRole(role: UserRole, customName: String = "", customPhone: String = "") {
        when (role) {
            UserRole.STUDENT -> {
                _currentUser.value = CurrentUserSession(
                    userId = "std_01",
                    role = UserRole.STUDENT,
                    name = if (customName.isNotBlank()) customName else "Amanpreet Kaur",
                    phone = if (customPhone.isNotBlank()) customPhone else "+91 98281 11223",
                    email = "amanpreet@gnmtc-sgnr.edu.in",
                    batch = _selectedBatch.value
                )
                _statusMessage.value = "Switched to Student view (विद्यार्थी मोड)"
            }
            UserRole.TEACHER -> {
                _currentUser.value = CurrentUserSession(
                    userId = "t_sunita",
                    role = UserRole.TEACHER,
                    name = if (customName.isNotBlank()) customName else "Mrs. Sunita Verma (Faculty)",
                    phone = if (customPhone.isNotBlank()) customPhone else "+91 98290 65432",
                    email = "sunita.verma@gnmtc-sgnr.edu.in",
                    batch = _selectedBatch.value
                )
                _statusMessage.value = "Teacher authenticated (फैकल्टी लॉगिन सफल)"
            }
            UserRole.ADMIN -> {
                _currentUser.value = CurrentUserSession(
                    userId = "admin_super",
                    role = UserRole.ADMIN,
                    name = if (customName.isNotBlank()) customName else "Dr. S. K. Sharma (Principal / Admin)",
                    phone = if (customPhone.isNotBlank()) customPhone else "+91 94140 12345",
                    email = "principal@gnmtc-sgnr.edu.in",
                    batch = _selectedBatch.value
                )
                _statusMessage.value = "Administrator authenticated (प्रशासक नियंत्रण सक्रिय)"
            }
        }
    }

    fun verifyAdminLogin(adminId: String, password: String): Boolean {
        if (adminId.trim().equals("GNMTC26", ignoreCase = true) && password.trim() == "GNMTC2026") {
            switchRole(UserRole.ADMIN, customName = "Dr. S. K. Sharma (Principal / Admin)")
            return true
        }
        return false
    }

    fun logout() {
        _currentUser.value = CurrentUserSession(
            userId = "guest",
            role = UserRole.STUDENT,
            name = "Guest User",
            phone = "",
            email = "",
            batch = CollegeRepository.BATCHES[1]
        )
        _statusMessage.value = "Logged out successfully"
        _currentScreen.value = Screen.Home
    }

    // Complaint operations
    fun submitComplaint(
        studentName: String,
        mobileNumber: String,
        batch: String,
        description: String,
        onSuccess: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            val result = repository.registerComplaint(studentName, mobileNumber, batch, description)
            if (result.isSuccess) {
                val code = result.getOrNull() ?: "0000"
                _statusMessage.value = "Complaint submitted with code $code"
                onSuccess(code)
            } else {
                val error = result.exceptionOrNull()?.localizedMessage ?: "Failed to submit"
                _statusMessage.value = error
                onError(error)
            }
        }
    }

    fun lookupComplaint(code: String) {
        if (code.length != 4) {
            _complaintLookupError.value = "Please enter a valid 4-digit code (e.g. 1024)"
            _trackedComplaint.value = null
            return
        }
        viewModelScope.launch {
            _isLookingUpComplaint.value = true
            _complaintLookupError.value = null
            val complaint = repository.getComplaintByTrackingCode(code)
            _isLookingUpComplaint.value = false
            if (complaint != null) {
                _trackedComplaint.value = complaint
            } else {
                _complaintLookupError.value = "No complaint found with code '$code'. Please verify the number."
                _trackedComplaint.value = null
            }
        }
    }

    fun updateComplaintStatus(complaintId: String, newStatus: String, note: String) {
        viewModelScope.launch {
            val res = repository.updateComplaintStatus(complaintId, newStatus, note)
            if (res.isSuccess) {
                _statusMessage.value = "Complaint status updated to $newStatus"
            }
        }
    }

    // Private Student Data (Admin only)
    fun fetchPrivateStudent(studentId: String) {
        viewModelScope.launch {
            val data = repository.getPrivateStudentRecord(studentId)
            _viewingPrivateStudent.value = data
        }
    }

    fun closePrivateStudentModal() {
        _viewingPrivateStudent.value = null
    }

    // Teacher CRUD
    fun saveTeacher(teacher: Teacher) {
        viewModelScope.launch {
            val res = repository.saveTeacher(teacher)
            if (res.isSuccess) {
                _statusMessage.value = "Teacher record saved successfully"
            }
        }
    }

    fun deleteTeacher(teacherId: String) {
        viewModelScope.launch {
            val res = repository.deleteTeacher(teacherId)
            if (res.isSuccess) {
                _statusMessage.value = "Teacher profile removed"
            }
        }
    }

    // Coordinator Save
    fun saveCoordinator(coordinator: BatchCoordinator) {
        viewModelScope.launch {
            val res = repository.saveCoordinator(coordinator)
            if (res.isSuccess) {
                _statusMessage.value = "Batch Coordinator details updated"
            }
        }
    }

    // Student Save
    fun saveStudent(publicInfo: StudentPublic, privateInfo: StudentPrivate?) {
        viewModelScope.launch {
            val res = repository.saveStudent(publicInfo, privateInfo)
            if (res.isSuccess) {
                _statusMessage.value = "Student record saved"
            }
        }
    }

    // Syllabus CRUD
    fun saveLecture(lecture: SyllabusLecture) {
        viewModelScope.launch {
            val res = repository.saveSyllabusLecture(lecture)
            if (res.isSuccess) {
                _statusMessage.value = "Lecture topic recorded"
            }
        }
    }

    fun toggleLectureStatus(lecture: SyllabusLecture) {
        viewModelScope.launch {
            val res = repository.toggleLectureCompletion(lecture.id, lecture.isCompleted)
            if (res.isSuccess) {
                val newStatus = if (!lecture.isCompleted) "Completed" else "Pending"
                _statusMessage.value = "Marked topic as $newStatus"
            }
        }
    }

    // Attendance Save
    fun markStudentAttendance(batchId: String, studentId: String, studentName: String, date: String, status: String) {
        viewModelScope.launch {
            val record = AttendanceRecord(
                id = "${batchId}_${studentId}_${date.replace("-", "")}",
                batchId = batchId,
                subjectId = _selectedSubjectId.value,
                studentId = studentId,
                studentName = studentName,
                date = date,
                status = status,
                markedBy = _currentUser.value.name
            )
            val res = repository.markAttendance(record)
            if (res.isSuccess) {
                _statusMessage.value = "Attendance saved for $studentName ($status)"
            }
        }
    }

    // Clinical Duty
    fun markClinicalAttendance(batchId: String, studentId: String, studentName: String, date: String, status: String, hospital: String) {
        viewModelScope.launch {
            val record = ClinicalDutyAttendance(
                id = "clin_${batchId}_${studentId}_${date.replace("-", "")}",
                batchId = batchId,
                studentId = studentId,
                studentName = studentName,
                date = date,
                hospitalLocation = hospital,
                status = status,
                markedBy = _currentUser.value.name
            )
            val res = repository.markClinicalAttendance(record)
            if (res.isSuccess) {
                _statusMessage.value = "Clinical attendance marked: $status for $studentName"
            }
        }
    }

    fun saveClinicalRoster(roster: ClinicalRoster) {
        viewModelScope.launch {
            val res = repository.saveClinicalRoster(roster)
            if (res.isSuccess) {
                _statusMessage.value = "Clinical Duty roster updated"
            }
        }
    }

    // Notice CRUD
    fun saveNotice(notice: Notice) {
        viewModelScope.launch {
            val res = repository.saveNotice(notice)
            if (res.isSuccess) {
                _statusMessage.value = "Notice published"
            }
        }
    }

    fun deleteNotice(noticeId: String) {
        viewModelScope.launch {
            val res = repository.deleteNotice(noticeId)
            if (res.isSuccess) {
                _statusMessage.value = "Notice deleted"
            }
        }
    }

    // Holiday CRUD
    fun saveHoliday(holiday: Holiday) {
        viewModelScope.launch {
            val res = repository.saveHoliday(holiday)
            if (res.isSuccess) {
                _statusMessage.value = "Holiday saved to calendar"
            }
        }
    }
}
