package com.example.ui.components

import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AestheticBlack
import com.example.ui.theme.BorderGrey
import com.example.ui.theme.CardGrey
import com.example.ui.theme.DeepPink
import com.example.ui.theme.KawaiiPink
import com.example.ui.theme.PastelPinkBg
import com.example.ui.theme.PastelPinkContainer
import com.example.ui.theme.PureWhite
import com.example.ui.theme.TextGrey
import com.example.util.PaymentSecurityManager
import com.example.util.PaymentSecurityManager.VerificationResult
import com.example.util.QrCodeGenerator
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun VipPaymentDialog(
    isVipActive: Boolean,
    onActivateVip: () -> Unit,
    onOpenPrivacy: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    // Dialog state
    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Pay & QR, 1 = Verify & Unlock
    var utrInput by remember { mutableStateOf("") }
    var keyInput by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var pendingInfo by remember { mutableStateOf(PaymentSecurityManager.getPendingVerification(context)) }
    var activationSuccess by remember { mutableStateOf(false) }

    val creatorEmail = PaymentSecurityManager.OFFICIAL_SUPPORT_EMAIL // a46350272@gmail.com

    // UPI payload: Encodes QR payment without displaying text UPI ID or personal name
    val upiPayload = "upi://pay?pa=avinashchaurasiya@fam&pn=StudyTimerVIP&am=199&cu=INR&tn=StudyTimerVIP2Months"

    // Generate QR with pure black modules and pretty pink background
    val qrImageBitmap = remember(upiPayload) {
        QrCodeGenerator.generateQrCodeBitmap(
            content = upiPayload,
            width = 460,
            height = 460,
            moduleColor = android.graphics.Color.parseColor("#000000"), // solid black QR
            backgroundColor = android.graphics.Color.parseColor("#FFF0F5") // pretty pink
        )
    }

    val scrollState = rememberScrollState()

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = PureWhite,
        shape = RoundedCornerShape(28.dp),
        modifier = Modifier.testTag("vip_payment_dialog"),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "👑", fontSize = 24.sp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Study VIP Pass",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = AestheticBlack
                        )
                        Text(
                            text = "₹199 for 2 Months • Protected Access",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = DeepPink
                        )
                    }
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = TextGrey)
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(scrollState),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (isVipActive || activationSuccess) {
                    // Active VIP State
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(vertical = 16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(PastelPinkContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("✨", fontSize = 32.sp)
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "VIP Membership Active! ⭐",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = AestheticBlack
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Your 2-Month VIP Pass is verified and active for 60 days. Enjoy all holographic stickers, unlimited soundscapes, study reports, and streak shield.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextGrey,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = CardGrey,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Security, contentDescription = null, tint = DeepPink, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Status: Authenticated & Encrypted in Local Storage",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                    color = AestheticBlack
                                )
                            }
                        }
                    }
                } else {
                    // Navigation Tabs: [1. Scan & Pay] | [2. Verify & Unlock]
                    TabRow(
                        selectedTabIndex = selectedTab,
                        containerColor = CardGrey,
                        contentColor = AestheticBlack,
                        indicator = { tabPositions ->
                            TabRowDefaults.SecondaryIndicator(
                                Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                                color = DeepPink,
                                height = 3.dp
                            )
                        },
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .fillMaxWidth()
                    ) {
                        Tab(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0; errorMessage = null },
                            text = {
                                Text(
                                    "1. Scan & Pay ₹199",
                                    fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 12.sp,
                                    color = if (selectedTab == 0) DeepPink else TextGrey
                                )
                            }
                        )
                        Tab(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1; errorMessage = null },
                            text = {
                                Text(
                                    "2. Verify Payment 🛡️",
                                    fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 12.sp,
                                    color = if (selectedTab == 1) DeepPink else TextGrey
                                )
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    if (selectedTab == 0) {
                        // TAB 0: SCAN & PAY ₹199
                        // Limited Time Discount Banner
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = PastelPinkContainer,
                            border = androidx.compose.foundation.BorderStroke(1.dp, KawaiiPink.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("🏷️", fontSize = 20.sp)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Special Student Deal • Save 60%",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = DeepPink
                                    )
                                    Text(
                                        text = "Pay ₹199 (Original ₹499) for 60 days of VIP focus!",
                                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                        color = AestheticBlack
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // QR Code Card in Pastel Light Pink (NO UPI ID or Name displayed)
                        Card(
                            shape = RoundedCornerShape(22.dp),
                            colors = CardDefaults.cardColors(containerColor = PastelPinkBg),
                            border = androidx.compose.foundation.BorderStroke(2.dp, BorderGrey),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(16.dp)
                            ) {
                                Text(
                                    text = "Scan & Pay ₹199",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = AestheticBlack
                                )
                                Text(
                                    text = "Use any UPI app (GPay / PhonePe / Paytm / BHIM)",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                    color = TextGrey
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                // The Clean Pretty Pink QR Box with Solid Black QR
                                Box(
                                    modifier = Modifier
                                        .size(208.dp)
                                        .shadow(3.dp, RoundedCornerShape(20.dp))
                                        .clip(RoundedCornerShape(20.dp))
                                        .background(PastelPinkBg)
                                        .border(2.5.dp, KawaiiPink.copy(alpha = 0.5f), RoundedCornerShape(20.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (qrImageBitmap != null) {
                                        Image(
                                            bitmap = qrImageBitmap,
                                            contentDescription = "Scan QR Code for payment",
                                            modifier = Modifier.size(196.dp)
                                        )
                                    } else {
                                        Text("Generating QR...", color = TextGrey)
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = PureWhite,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderGrey)
                                ) {
                                    Text(
                                        text = "Official 2-Month Pass • ₹199 Only",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        ),
                                        color = DeepPink,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Direct Email Verification Notice with creator email
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = PureWhite,
                            border = androidx.compose.foundation.BorderStroke(1.dp, BorderGrey),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Email, contentDescription = null, tint = DeepPink, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Official Proof Submission Email",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                        color = AestheticBlack
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "After paying ₹199, email your payment screenshot / UTR to get your VIP Activation Code:",
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                    color = TextGrey
                                )
                                Spacer(modifier = Modifier.height(8.dp))

                                // Tap to Copy Email Chip
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = CardGrey,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            clipboardManager.setText(AnnotatedString(creatorEmail))
                                            Toast.makeText(context, "Email copied: $creatorEmail 📋", Toast.LENGTH_SHORT).show()
                                        }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = creatorEmail,
                                            style = MaterialTheme.typography.labelMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                fontFamily = FontFamily.Monospace
                                            ),
                                            color = AestheticBlack
                                        )
                                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = DeepPink, modifier = Modifier.size(16.dp))
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Button(
                                    onClick = {
                                        val intent = PaymentSecurityManager.createBuyerProofEmailIntent("", "")
                                        try {
                                            context.startActivity(Intent.createChooser(intent, "Email Payment Proof"))
                                        } catch (_: Exception) {
                                            clipboardManager.setText(AnnotatedString(creatorEmail))
                                            Toast.makeText(context, "Email copied: $creatorEmail", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = AestheticBlack,
                                        contentColor = PureWhite
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(42.dp)
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(14.dp), tint = PureWhite)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Email Payment Proof to Creator ✉️", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = { selectedTab = 1 },
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DeepPink,
                                contentColor = PureWhite
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                        ) {
                            Text("I Have Paid • Verify & Enter Key ➔", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }

                    } else {
                        // TAB 1: VERIFY PAYMENT & SECURE UNLOCK
                        // Error banner if any
                        if (errorMessage != null) {
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = Color(0xFFFEF2F2),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF87171)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = errorMessage ?: "",
                                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                        color = Color(0xFF991B1B)
                                    )
                                }
                            }
                        }

                        // Pending Status Display if already submitted
                        if (pendingInfo != null) {
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = PastelPinkContainer),
                                border = androidx.compose.foundation.BorderStroke(1.5.dp, DeepPink.copy(alpha = 0.7f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 14.dp)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "⏳ Verification Pending",
                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                            color = DeepPink
                                        )
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = PureWhite
                                        ) {
                                            Text(
                                                text = "UNDER REVIEW",
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 9.sp
                                                ),
                                                color = DeepPink,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "Order Ref: ${pendingInfo?.orderId}",
                                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold),
                                        color = AestheticBlack
                                    )
                                    Text(
                                        text = "Submitted UTR: ${pendingInfo?.utr}",
                                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                                        color = TextGrey
                                    )
                                    val formattedTime = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
                                        .format(Date(pendingInfo?.timestamp ?: System.currentTimeMillis()))
                                    Text(
                                        text = "Time: $formattedTime",
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                        color = TextGrey
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "Send your screenshot & UTR to $creatorEmail. Once verified against bank credits, you will receive your VIP Activation Code.",
                                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp, lineHeight = 14.sp),
                                        color = AestheticBlack
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))

                                    // Action to email proof directly to creator
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        OutlinedButton(
                                            onClick = {
                                                val proof = "Order: ${pendingInfo?.orderId}\nUTR: ${pendingInfo?.utr}\nAmount: ₹199"
                                                clipboardManager.setText(AnnotatedString(proof))
                                                Toast.makeText(context, "Details copied! 📋", Toast.LENGTH_SHORT).show()
                                            },
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Copy Ref", fontSize = 11.sp)
                                        }
                                        Button(
                                            onClick = {
                                                val intent = PaymentSecurityManager.createBuyerProofEmailIntent(
                                                    pendingInfo?.orderId ?: "",
                                                    pendingInfo?.utr ?: ""
                                                )
                                                try {
                                                    context.startActivity(Intent.createChooser(intent, "Email Proof to Creator"))
                                                } catch (_: Exception) {
                                                    clipboardManager.setText(AnnotatedString(creatorEmail))
                                                    Toast.makeText(context, "Copied creator email: $creatorEmail", Toast.LENGTH_SHORT).show()
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = AestheticBlack),
                                            shape = RoundedCornerShape(12.dp),
                                            modifier = Modifier.weight(1.3f)
                                        ) {
                                            Icon(Icons.Default.Email, contentDescription = null, modifier = Modifier.size(14.dp), tint = PureWhite)
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Email to Creator", fontSize = 11.sp, color = PureWhite)
                                        }
                                    }
                                }
                            }
                        }

                        // Option 1: 12-Digit Bank UTR Submission (Security Protected)
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = PureWhite,
                            border = androidx.compose.foundation.BorderStroke(1.dp, BorderGrey),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Security, contentDescription = null, tint = DeepPink, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "1. Submit Bank UTR (Strict Verification)",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                        color = AestheticBlack
                                    )
                                }
                                Text(
                                    text = "Requires authentic 12-digit transaction reference number from your bank or UPI receipt.",
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                    color = TextGrey
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                OutlinedTextField(
                                    value = utrInput,
                                    onValueChange = {
                                        if (it.length <= 12 && it.all { char -> char.isDigit() }) {
                                            utrInput = it
                                            errorMessage = null
                                        }
                                    },
                                    label = { Text("12-Digit UPI Ref / UTR No.") },
                                    placeholder = { Text("e.g. 428172918239") },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    trailingIcon = {
                                        Text("${utrInput.length}/12", fontSize = 11.sp, color = if (utrInput.length == 12) DeepPink else TextGrey)
                                    },
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("utr_input_field"),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = DeepPink,
                                        unfocusedBorderColor = BorderGrey,
                                        focusedLabelColor = DeepPink,
                                        unfocusedLabelColor = TextGrey,
                                        focusedTextColor = AestheticBlack,
                                        unfocusedTextColor = AestheticBlack
                                    )
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                Button(
                                    onClick = {
                                        val result = PaymentSecurityManager.submitUtrForVerification(context, utrInput)
                                        when (result) {
                                            is VerificationResult.UtrPending -> {
                                                pendingInfo = PaymentSecurityManager.getPendingVerification(context)
                                                errorMessage = null
                                                val submittedUtr = utrInput
                                                utrInput = ""
                                                Toast.makeText(context, "UTR Submitted! Status is Under Review ⏳", Toast.LENGTH_LONG).show()

                                                // Offer to email proof directly
                                                val intent = PaymentSecurityManager.createBuyerProofEmailIntent(result.orderId, submittedUtr)
                                                try {
                                                    context.startActivity(Intent.createChooser(intent, "Email Proof to $creatorEmail"))
                                                } catch (_: Exception) {
                                                    // handled
                                                }
                                            }
                                            is VerificationResult.Error -> {
                                                errorMessage = result.message
                                            }
                                            is VerificationResult.Success -> {
                                                activationSuccess = true
                                                onActivateVip()
                                            }
                                        }
                                    },
                                    enabled = utrInput.length == 12,
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = AestheticBlack,
                                        contentColor = PureWhite
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(44.dp)
                                        .testTag("submit_utr_for_verification_btn")
                                ) {
                                    Text("Submit UTR for Bank Verification 🛡️", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Option 2: Instant Unlock with VIP Activation Key
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = PureWhite,
                            border = androidx.compose.foundation.BorderStroke(1.dp, BorderGrey),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Lock, contentDescription = null, tint = DeepPink, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "2. Instant Unlock with VIP Key / Voucher",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                        color = AestheticBlack
                                    )
                                }
                                Text(
                                    text = "Received your VIP activation key from the creator ($creatorEmail)? Enter it below:",
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                    color = TextGrey
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                OutlinedTextField(
                                    value = keyInput,
                                    onValueChange = {
                                        keyInput = it
                                        errorMessage = null
                                    },
                                    label = { Text("VIP Activation Key / Passcode") },
                                    placeholder = { Text("e.g. VIP-XXXX-XXXX or Passcode") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("vip_key_input_field"),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = DeepPink,
                                        unfocusedBorderColor = BorderGrey,
                                        focusedLabelColor = DeepPink,
                                        unfocusedLabelColor = TextGrey,
                                        focusedTextColor = AestheticBlack,
                                        unfocusedTextColor = AestheticBlack
                                    )
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                Button(
                                    onClick = {
                                        val result = PaymentSecurityManager.verifyActivationKey(context, keyInput)
                                        when (result) {
                                            is VerificationResult.Success -> {
                                                activationSuccess = true
                                                errorMessage = null
                                                onActivateVip()
                                                Toast.makeText(context, result.message, Toast.LENGTH_LONG).show()
                                            }
                                            is VerificationResult.Error -> {
                                                errorMessage = result.message
                                            }
                                            is VerificationResult.UtrPending -> {
                                                // Not applicable for key
                                            }
                                        }
                                    },
                                    enabled = keyInput.isNotBlank(),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = DeepPink,
                                        contentColor = PureWhite
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(44.dp)
                                        .testTag("verify_key_btn")
                                ) {
                                    Text("Verify & Activate VIP Key ✨", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // VIP Features List
                    Column(
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        VipFeatureRow(emoji = "🎀", title = "All 10+ Holographic Stationery Stickers", subtitle = "Unlock all cute companions immediately")
                        VipFeatureRow(emoji = "🛡️", title = "Study Streak Shield", subtitle = "Rest days won't reset your hard-earned streak")
                        VipFeatureRow(emoji = "📊", title = "Export Detailed Study Reports", subtitle = "Download PDF / CSV logs for parents & school")
                        VipFeatureRow(emoji = "🎧", title = "All Binaural & Rain Soundscapes", subtitle = "Unlimited peaceful focus audio")
                        VipFeatureRow(emoji = "🚫", title = "Zero Interruptions & Ad-Free", subtitle = "Clean, peaceful study environment forever")
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Privacy & Billing Transparency Link
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = TextGrey, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Privacy Disclaimers & Billing Terms",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = TextGrey
                            ),
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .clickable { onOpenPrivacy() }
                                .padding(4.dp)
                        )
                    }
                }
            }
        },
        confirmButton = {
            if (isVipActive || activationSuccess) {
                Button(
                    onClick = onDismiss,
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AestheticBlack, contentColor = PureWhite),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Enjoy VIP Benefits! ⭐", fontWeight = FontWeight.Bold)
                }
            }
        }
    )
}

@Composable
private fun VipFeatureRow(emoji: String, title: String, subtitle: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(PureWhite)
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(PastelPinkBg),
            contentAlignment = Alignment.Center
        ) {
            Text(emoji, fontSize = 16.sp)
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                color = AestheticBlack
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                color = TextGrey
            )
        }
    }
}
