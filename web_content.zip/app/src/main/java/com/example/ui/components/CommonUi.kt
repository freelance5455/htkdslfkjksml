package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.*
import com.example.ui.theme.*

@Composable
fun IgnisLogoBadge(
    modifier: Modifier = Modifier,
    size: Int = 36
) {
    Box(
        modifier = modifier
            .size(size.dp)
            .clip(RoundedCornerShape((size / 3).dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(IgnisOrangePrimary, IgnisFlameCrimson)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Filled.Bolt,
            contentDescription = "Ignis Logo",
            tint = Color.White,
            modifier = Modifier.size((size * 0.65).dp)
        )
    }
}

@Composable
fun IgnisTopAppBar(
    currentRole: UserRole,
    approxLocation: String,
    unreadNotifications: Int,
    onLocationClick: () -> Unit,
    onNotificationClick: () -> Unit,
    onRoleSelect: (UserRole) -> Unit,
    modifier: Modifier = Modifier
) {
    var showRoleMenu by remember { mutableStateOf(false) }

    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Logo & Name
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    IgnisLogoBadge(size = 34)
                    Column {
                        Text(
                            text = "IGNIS",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.5.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                        Text(
                            text = "Marketplace Ecosystem",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 10.sp
                            )
                        )
                    }
                }

                // Actions: Role Switcher & Notifications
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Role Switcher Pill
                    Box {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = when (currentRole) {
                                UserRole.CONSUMER -> Color(0xFFFFEDE7)
                                UserRole.SELLER -> Color(0xFFE0F2FE)
                                UserRole.DELIVERY_PARTNER -> Color(0xFFECFDF5)
                            },
                            border = BorderStroke(
                                1.dp,
                                when (currentRole) {
                                    UserRole.CONSUMER -> IgnisOrangePrimary
                                    UserRole.SELLER -> IgnisTechBlue
                                    UserRole.DELIVERY_PARTNER -> IgnisEmerald
                                }
                            ),
                            modifier = Modifier
                                .testTag("role_switcher_button")
                                .clip(RoundedCornerShape(20.dp))
                                .clickable { showRoleMenu = true }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = when (currentRole) {
                                        UserRole.CONSUMER -> Icons.Filled.ShoppingBag
                                        UserRole.SELLER -> Icons.Filled.Storefront
                                        UserRole.DELIVERY_PARTNER -> Icons.Filled.TwoWheeler
                                    },
                                    contentDescription = "Role",
                                    tint = when (currentRole) {
                                        UserRole.CONSUMER -> IgnisOrangePrimary
                                        UserRole.SELLER -> IgnisTechBlue
                                        UserRole.DELIVERY_PARTNER -> IgnisEmerald
                                    },
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = currentRole.label.substringBefore(" /"),
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = when (currentRole) {
                                            UserRole.CONSUMER -> IgnisOrangeDark
                                            UserRole.SELLER -> Color(0xFF0369A1)
                                            UserRole.DELIVERY_PARTNER -> Color(0xFF065F46)
                                        }
                                    )
                                )
                                Icon(
                                    imageVector = Icons.Filled.ArrowDropDown,
                                    contentDescription = "Switch Role",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = showRoleMenu,
                            onDismissRequest = { showRoleMenu = false }
                        ) {
                            Text(
                                text = "Switch Perspective",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                            )
                            HorizontalDivider()
                            UserRole.values().forEach { role ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(
                                                text = role.label,
                                                fontWeight = if (role == currentRole) FontWeight.Bold else FontWeight.Normal,
                                                color = if (role == currentRole) IgnisOrangePrimary else MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = role.description,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    },
                                    leadingIcon = {
                                        Icon(
                                            imageVector = when (role) {
                                                UserRole.CONSUMER -> Icons.Filled.ShoppingBag
                                                UserRole.SELLER -> Icons.Filled.Storefront
                                                UserRole.DELIVERY_PARTNER -> Icons.Filled.TwoWheeler
                                            },
                                            contentDescription = null,
                                            tint = if (role == currentRole) IgnisOrangePrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    },
                                    onClick = {
                                        onRoleSelect(role)
                                        showRoleMenu = false
                                    }
                                )
                            }
                        }
                    }

                    // Notification Button
                    IconButton(
                        onClick = onNotificationClick,
                        modifier = Modifier
                            .testTag("notification_button")
                            .size(40.dp)
                    ) {
                        BadgedBox(
                            badge = {
                                if (unreadNotifications > 0) {
                                    Badge(
                                        containerColor = IgnisFlameCrimson,
                                        contentColor = Color.White
                                    ) {
                                        Text("$unreadNotifications")
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Notifications,
                                contentDescription = "Notifications",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            // Location Bar
            Spacer(modifier = Modifier.height(6.dp))
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onLocationClick() }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.LocationOn,
                        contentDescription = "Location",
                        tint = IgnisOrangePrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = approxLocation,
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Medium
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = "Change",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = IgnisOrangePrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun OrderStatusBadge(
    status: OrderStatus,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, icon) = when (status) {
        OrderStatus.ORDER_PLACED -> Triple(Color(0xFFE2E8F0), Color(0xFF334155), Icons.Filled.Receipt)
        OrderStatus.SELLER_CONFIRMED -> Triple(Color(0xFFE0F2FE), Color(0xFF0369A1), Icons.Filled.CheckCircle)
        OrderStatus.DELIVERY_REQUESTED -> Triple(Color(0xFFFEF3C7), Color(0xFFB45309), Icons.Filled.NearMe)
        OrderStatus.DELIVERY_ASSIGNED -> Triple(Color(0xFFEDE9FE), Color(0xFF6D28D9), Icons.Filled.TwoWheeler)
        OrderStatus.PICKED_UP -> Triple(Color(0xFFFFEDD5), Color(0xFFC2410C), Icons.Filled.Inventory)
        OrderStatus.ON_THE_WAY -> Triple(Color(0xFFFFECE5), IgnisOrangePrimary, Icons.Filled.DirectionsRun)
        OrderStatus.DELIVERED, OrderStatus.COMPLETED -> Triple(Color(0xFFD1FAE5), Color(0xFF047857), Icons.Filled.TaskAlt)
        OrderStatus.CANCELLED -> Triple(Color(0xFFFFE4E6), Color(0xFFBE123C), Icons.Filled.Cancel)
    }

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(16.dp),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = textColor,
                modifier = Modifier.size(14.dp)
            )
            Text(
                text = status.label,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = textColor,
                    fontWeight = FontWeight.Bold
                )
            )
        }
    }
}

@Composable
fun ProductCard(
    product: Product,
    onProductClick: (Product) -> Unit,
    onAddToCart: (Product) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("product_card_${product.id}")
            .clickable { onProductClick(product) },
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .background(Color(0xFF1E293B))
            ) {
                AsyncImage(
                    model = product.imageUrl,
                    contentDescription = product.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Innovation Tag
                if (product.isInnovation) {
                    Surface(
                        color = IgnisOrangePrimary,
                        shape = RoundedCornerShape(bottomEnd = 12.dp),
                        modifier = Modifier.align(Alignment.TopStart)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Bolt,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                text = "INNOVATION",
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 9.sp
                                )
                            )
                        }
                    }
                }

                // Distance Badge
                Surface(
                    color = Color.Black.copy(alpha = 0.65f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp)
                ) {
                    Text(
                        text = "${product.distanceKm} km away",
                        color = Color.White,
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                Text(
                    text = product.sellerName,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = product.name,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "$${"%.2f".format(product.price)}",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                color = IgnisOrangePrimary
                            )
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Star,
                                contentDescription = null,
                                tint = IgnisAmber,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = "${product.rating} (${product.reviewCount})",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                    }

                    IconButton(
                        onClick = { onAddToCart(product) },
                        modifier = Modifier
                            .testTag("add_to_cart_${product.id}")
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(IgnisOrangePrimary)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AddShoppingCart,
                            contentDescription = "Add to Cart",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LocationExplanationDialog(
    onDismiss: () -> Unit,
    onGrant: () -> Unit,
    onDeny: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.MyLocation,
                    contentDescription = null,
                    tint = IgnisOrangePrimary
                )
                Text(
                    text = "Location Access in Ignis",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Ignis uses your approximate location strictly to power local ecosystem matching:",
                    style = MaterialTheme.typography.bodyMedium
                )

                listOf(
                    Icons.Filled.Storefront to "Find nearby innovative sellers & makers",
                    Icons.Filled.TwoWheeler to "Connect with eligible local delivery partners",
                    Icons.Filled.Straighten to "Calculate exact delivery distances & routes",
                    Icons.Filled.Speed to "Optimize 5-30 km local marketplace dispatch"
                ).forEach { (icon, reason) ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = IgnisOrangePrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = reason,
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }
                }

                Text(
                    text = "Your exact street coordinates are never published publicly.",
                    style = MaterialTheme.typography.labelSmall.copy(color = IgnisTechBlue, fontWeight = FontWeight.SemiBold)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onGrant,
                colors = ButtonDefaults.buttonColors(containerColor = IgnisOrangePrimary)
            ) {
                Text("Allow Location")
            }
        },
        dismissButton = {
            TextButton(onClick = onDeny) {
                Text("Continue with Limited Location")
            }
        }
    )
}
