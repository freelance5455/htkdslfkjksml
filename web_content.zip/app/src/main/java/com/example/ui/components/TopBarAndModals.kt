package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.UserRole
import com.example.ui.theme.*
import com.example.ui.viewmodel.CollegeViewModel
import com.example.ui.viewmodel.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CollegeTopAppBar(
    viewModel: CollegeViewModel,
    onOpenRoleDialog: () -> Unit
) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    val screenTitle = when (currentScreen) {
        Screen.Home -> "GNMTC SGNR"
        Screen.TeacherDirectory -> "Know Your Teacher (शिक्षक परिचय)"
        Screen.BatchManagement -> "Batch Management (बैच प्रबंधन)"
        Screen.ComplaintRegistration -> "Register Complaint (शिकायत दर्ज)"
        Screen.ComplaintStatus -> "Track Complaint (शिकायत की स्थिति)"
        Screen.NoticeBoard -> "Notice Board (सूचना पट्ट)"
        Screen.HolidayCalendar -> "Holiday Calendar (अवकाश कैलेंडर)"
        Screen.ClinicalDuty -> "Clinical Duty (क्लिनिकल ड्यूटी)"
        Screen.AdminDashboard -> "Admin Portal (प्रशासक पोर्टल)"
        Screen.HtmlAppView -> "GNMTC SGNR (HTML Web Version)"
    }

    TopAppBar(
        title = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = screenTitle,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                if (currentScreen == Screen.Home) {
                    Text(
                        text = "Govt. Nursing & Midwifery Training Centre",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        ),
                        maxLines = 1
                    )
                }
            }
        },
        navigationIcon = {
            if (currentScreen != Screen.Home) {
                IconButton(onClick = { viewModel.navigateTo(Screen.Home) }) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back to Home",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            } else {
                Box(
                    modifier = Modifier
                        .padding(start = 12.dp, end = 6.dp)
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(NursingGreenContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.LocalHospital,
                        contentDescription = "GNMTC Logo",
                        tint = NursingGreenPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        },
        actions = {
            // HTML Web Version toggle button
            IconButton(
                onClick = {
                    if (currentScreen == Screen.HtmlAppView) {
                        viewModel.navigateTo(Screen.Home)
                    } else {
                        viewModel.navigateTo(Screen.HtmlAppView)
                    }
                }
            ) {
                Icon(
                    imageVector = Icons.Default.Public,
                    contentDescription = "Switch to HTML Web View",
                    tint = NursingGreenPrimary
                )
            }

            // Role Badge Pill
            AssistChip(
                onClick = onOpenRoleDialog,
                label = {
                    Text(
                        text = currentUser.role.label,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = when (currentUser.role) {
                            UserRole.STUDENT -> Icons.Default.School
                            UserRole.TEACHER -> Icons.Default.Person
                            UserRole.ADMIN -> Icons.Default.AdminPanelSettings
                        },
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = when (currentUser.role) {
                            UserRole.STUDENT -> NursingGreenPrimary
                            UserRole.TEACHER -> ClinicalBlueSecondary
                            UserRole.ADMIN -> Color(0xFFD97706)
                        }
                    )
                },
                modifier = Modifier.padding(end = 8.dp),
                colors = AssistChipDefaults.assistChipColors(
                    containerColor = when (currentUser.role) {
                        UserRole.STUDENT -> NursingGreenContainer
                        UserRole.TEACHER -> ClinicalBlueContainer
                        UserRole.ADMIN -> Color(0xFFFEF3C7)
                    }
                )
            )
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.surface,
            titleContentColor = MaterialTheme.colorScheme.onSurface
        )
    )
}

@Composable
fun RoleSwitcherDialog(
    viewModel: CollegeViewModel,
    onDismiss: () -> Unit
) {
    val currentUser by viewModel.currentUser.collectAsState()
    var selectedRole by remember { mutableStateOf(currentUser.role) }
    var phoneInput by remember { mutableStateOf("+91 94140 12345") }
    var otpInput by remember { mutableStateOf("123456") }
    var adminIdInput by remember { mutableStateOf("GNMTC26") }
    var passwordInput by remember { mutableStateOf("GNMTC2026") }
    var passwordVisible by remember { mutableStateOf(false) }
    var loginError by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = NursingGreenPrimary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "User Login & Role (उपयोगकर्ता लॉगिन)",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Select your role to access role-based features at GNMTC SGNR:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
                Spacer(modifier = Modifier.height(12.dp))

                // Role Options
                UserRole.values().forEach { role ->
                    val isSelected = selectedRole == role
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .clickable {
                                selectedRole = role
                                loginError = null
                            },
                        color = if (isSelected) NursingGreenContainer else MaterialTheme.colorScheme.surfaceVariant,
                        tonalElevation = if (isSelected) 2.dp else 0.dp
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = {
                                    selectedRole = role
                                    loginError = null
                                },
                                colors = RadioButtonDefaults.colors(selectedColor = NursingGreenPrimary)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = role.label,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = role.hindiLabel,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider()
                Spacer(modifier = Modifier.height(12.dp))

                if (selectedRole == UserRole.ADMIN) {
                    Text(
                        text = "Administrator Credentials (प्रशासक क्रेडेंशियल्स):",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = adminIdInput,
                        onValueChange = {
                            adminIdInput = it
                            loginError = null
                        },
                        label = { Text("Admin ID") },
                        placeholder = { Text("GNMTC26") },
                        leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null, tint = NursingGreenPrimary) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = passwordInput,
                        onValueChange = {
                            passwordInput = it
                            loginError = null
                        },
                        label = { Text("Admin Password") },
                        placeholder = { Text("GNMTC2026") },
                        leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = NursingGreenPrimary) },
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = "Toggle password visibility"
                                )
                            }
                        },
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    loginError?.let { err ->
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = err,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Admin Access: ID GNMTC26 / Password GNMTC2026",
                        style = MaterialTheme.typography.labelSmall.copy(color = ClinicalBlueSecondary)
                    )
                } else {
                    Text(
                        text = "Phone Number OTP Verification (फ़ोन ओटीपी):",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = phoneInput,
                        onValueChange = { phoneInput = it },
                        label = { Text("Mobile Number") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = otpInput,
                        onValueChange = { otpInput = it },
                        label = { Text("6-Digit OTP (Default: 123456)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (selectedRole == UserRole.ADMIN) {
                        val success = viewModel.verifyAdminLogin(adminIdInput, passwordInput)
                        if (success) {
                            onDismiss()
                        } else {
                            loginError = "Invalid credentials. Use Admin ID: GNMTC26 and Password: GNMTC2026."
                        }
                    } else {
                        viewModel.switchRole(selectedRole, customPhone = phoneInput)
                        onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = NursingGreenPrimary)
            ) {
                Text("Confirm Login")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
