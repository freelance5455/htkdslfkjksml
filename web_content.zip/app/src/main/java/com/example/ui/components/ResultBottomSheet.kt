package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SheetState
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.ui.layout.ContentScale
import com.example.model.ParsedQr
import com.example.model.QrCategory
import com.example.model.UrlMetadata
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.EmeraldTertiary
import com.example.ui.theme.VioletSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultBottomSheet(
    result: ParsedQr,
    urlMetadata: UrlMetadata? = null,
    onDismiss: () -> Unit,
    onCopy: (String) -> Unit,
    onOpenUrlRequest: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var isFavorite by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        containerColor = MaterialTheme.colorScheme.surface,
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(vertical = 12.dp)
                    .width(42.dp)
                    .height(5.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.outlineVariant)
            )
        },
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .padding(bottom = 32.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Header Row: Type Badge + Dismiss button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Category Chip Badge
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(getCategoryColor(result.category).copy(alpha = 0.16f))
                        .border(1.dp, getCategoryColor(result.category).copy(alpha = 0.35f), RoundedCornerShape(20.dp))
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = getCategoryIcon(result.category),
                        contentDescription = null,
                        tint = getCategoryColor(result.category),
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = result.category.displayName,
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = getCategoryColor(result.category)
                        )
                    )
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Title & Subtitle
            if (result.category == QrCategory.URL) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White)
                            .border(1.dp, Color(0x33000000), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        val fav = urlMetadata?.faviconUrl ?: "https://www.google.com/s2/favicons?sz=128&domain=${result.title}"
                        AsyncImage(
                            model = ImageRequest.Builder(context)
                                .data(fav)
                                .crossfade(true)
                                .build(),
                            contentDescription = "Website Favicon",
                            modifier = Modifier.size(30.dp),
                            contentScale = ContentScale.Fit
                        )
                    }

                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        val displayTitle = urlMetadata?.title ?: result.title
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = displayTitle,
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f, fill = false)
                            )
                            if (urlMetadata?.isLoading == true) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(14.dp),
                                    strokeWidth = 2.dp,
                                    color = CyanPrimary
                                )
                            }
                        }
                        Text(
                            text = result.title, // Domain host
                            style = MaterialTheme.typography.labelMedium,
                            color = CyanPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = result.subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = result.title,
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = result.subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Structured Details Card (if Wi-Fi, Contact, etc. has details)
            if (result.extraDetails.isNotEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        result.extraDetails.forEach { (key, value) ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = key,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = value,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(start = 12.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Raw Content preview card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                )
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Content",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = result.displayContent,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 6,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Primary Smart Action Button
            Button(
                onClick = {
                    executeSmartAction(context, result, onOpenUrlRequest)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("primary_qr_action_button"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = CyanPrimary,
                    contentColor = Color(0xFF00363D)
                )
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = getCategoryActionIcon(result.category),
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = result.primaryActionLabel,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }

            // Quick Actions Row: Copy, Share, Scan Again
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FilledTonalButton(
                    onClick = { onCopy(result.rawText) },
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .testTag("copy_qr_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Copy")
                }

                FilledTonalButton(
                    onClick = { shareContent(context, result.rawText) },
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .testTag("share_qr_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "Share",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Share")
                }

                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .weight(1f)
                        .height(46.dp)
                        .testTag("scan_again_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Scan Again",
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Again")
                }
            }
        }
    }
}

private fun getCategoryIcon(category: QrCategory): ImageVector {
    return when (category) {
        QrCategory.URL -> Icons.Default.Language
        QrCategory.WIFI -> Icons.Default.Wifi
        QrCategory.CONTACT -> Icons.Default.Person
        QrCategory.EMAIL -> Icons.Default.Email
        QrCategory.PHONE -> Icons.Default.Call
        QrCategory.SMS -> Icons.Default.Sms
        QrCategory.LOCATION -> Icons.Default.LocationOn
        QrCategory.PAYMENT -> Icons.Default.Payment
        else -> Icons.Default.TextFields
    }
}

private fun getCategoryColor(category: QrCategory): Color {
    return when (category) {
        QrCategory.URL -> CyanPrimary
        QrCategory.WIFI -> EmeraldTertiary
        QrCategory.CONTACT -> VioletSecondary
        QrCategory.EMAIL -> Color(0xFF38BDF8)
        QrCategory.PHONE -> Color(0xFF4ADE80)
        QrCategory.SMS -> Color(0xFFF472B6)
        QrCategory.LOCATION -> Color(0xFFFBBF24)
        QrCategory.PAYMENT -> Color(0xFF34D399)
        else -> Color(0xFF94A3B8)
    }
}

private fun getCategoryActionIcon(category: QrCategory): ImageVector {
    return when (category) {
        QrCategory.URL -> Icons.AutoMirrored.Filled.ArrowForward
        QrCategory.WIFI -> Icons.Default.Wifi
        QrCategory.CONTACT -> Icons.Default.Person
        QrCategory.EMAIL -> Icons.Default.Email
        QrCategory.PHONE -> Icons.Default.Call
        QrCategory.SMS -> Icons.Default.Sms
        QrCategory.LOCATION -> Icons.Default.LocationOn
        QrCategory.PAYMENT -> Icons.Default.Payment
        else -> Icons.Default.ContentCopy
    }
}

private fun executeSmartAction(
    context: Context,
    result: ParsedQr,
    onOpenUrlRequest: (String) -> Unit
) {
    try {
        when (result.category) {
            QrCategory.URL -> {
                val url = result.actionableUri ?: result.rawText
                onOpenUrlRequest(url)
            }
            QrCategory.WIFI -> {
                // Open system Wi-Fi settings or copy password
                val pass = result.extraDetails["Password"]
                if (!pass.isNullOrBlank()) {
                    val clip = android.content.ClipData.newPlainText("Wi-Fi Password", pass)
                    (context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(clip)
                    Toast.makeText(context, "Wi-Fi password copied! Opening Wi-Fi settings...", Toast.LENGTH_SHORT).show()
                }
                val intent = Intent(android.provider.Settings.ACTION_WIFI_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            }
            QrCategory.CONTACT -> {
                val name = result.extraDetails["Name"] ?: ""
                val phone = result.extraDetails["Phone"] ?: ""
                val email = result.extraDetails["Email"] ?: ""
                val intent = Intent(Intent.ACTION_INSERT).apply {
                    type = ContactsContract.Contacts.CONTENT_TYPE
                    putExtra(ContactsContract.Intents.Insert.NAME, name)
                    putExtra(ContactsContract.Intents.Insert.PHONE, phone)
                    putExtra(ContactsContract.Intents.Insert.EMAIL, email)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            }
            QrCategory.PHONE -> {
                val uri = result.actionableUri ?: "tel:${result.rawText}"
                val intent = Intent(Intent.ACTION_DIAL, Uri.parse(uri)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            }
            QrCategory.SMS -> {
                val uri = result.actionableUri ?: "smsto:${result.extraDetails["Recipient"] ?: ""}"
                val intent = Intent(Intent.ACTION_SENDTO, Uri.parse(uri)).apply {
                    result.extraDetails["Message"]?.let { putExtra("sms_body", it) }
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            }
            QrCategory.EMAIL -> {
                val uri = result.actionableUri ?: "mailto:"
                val intent = Intent(Intent.ACTION_SENDTO, Uri.parse(uri)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            }
            QrCategory.LOCATION -> {
                val uri = result.actionableUri ?: "geo:0,0?q=${Uri.encode(result.rawText)}"
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uri)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            }
            QrCategory.PAYMENT -> {
                val uri = result.actionableUri ?: result.rawText
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uri)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            }
            else -> {
                val clip = android.content.ClipData.newPlainText("Scanned Text", result.rawText)
                (context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(clip)
                Toast.makeText(context, "Text copied to clipboard", Toast.LENGTH_SHORT).show()
            }
        }
    } catch (_: Exception) {
        // Fallback: copy to clipboard
        val clip = android.content.ClipData.newPlainText("Scanned Content", result.rawText)
        (context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(clip)
        Toast.makeText(context, "Copied content to clipboard", Toast.LENGTH_SHORT).show()
    }
}

private fun shareContent(context: Context, text: String) {
    try {
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, text)
            type = "text/plain"
        }
        val shareIntent = Intent.createChooser(sendIntent, "Share QR Code Content")
        shareIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(shareIntent)
    } catch (_: Exception) {
        Toast.makeText(context, "Could not open share menu", Toast.LENGTH_SHORT).show()
    }
}
