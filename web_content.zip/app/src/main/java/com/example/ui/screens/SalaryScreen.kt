package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Mosque
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.entity.SalaryEntity
import com.example.ui.components.ConfirmDialog
import com.example.ui.components.DatePickerHelper
import com.example.ui.components.Elevated3DCard
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.IncomeGreenLight
import com.example.ui.theme.IslamicEmerald
import com.example.ui.theme.IslamicGold
import com.example.ui.theme.IslamicGreenDark
import com.example.ui.theme.IslamicGreenPrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.util.BanglaHelper
import com.example.ui.viewmodel.FinanceViewModel

@Composable
fun SalaryScreen(
    viewModel: FinanceViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val salaries by viewModel.allSalaries.collectAsStateWithLifecycle()

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val institutions = listOf("মাদরাসা", "মসজিদ")
    val selectedInstitution = institutions[selectedTabIndex]

    var selectedYear by remember { mutableIntStateOf(BanglaHelper.getCurrentYear()) }

    // Dialog form state
    var showEditDialog by remember { mutableStateOf(false) }
    var activeMonthIndex by remember { mutableIntStateOf(1) }
    var activeMonthName by remember { mutableStateOf("জানুয়ারি") }
    var inputAmount by remember { mutableStateOf("") }
    var inputDate by remember { mutableStateOf(BanglaHelper.getTodayIso()) }
    var inputDesc by remember { mutableStateOf("") }
    var inputIsPaid by remember { mutableStateOf(true) }

    // Duplicate alert state
    var duplicateAlertEntity by remember { mutableStateOf<SalaryEntity?>(null) }
    var deleteCandidate by remember { mutableStateOf<SalaryEntity?>(null) }

    val institutionSalaries = remember(salaries, selectedInstitution, selectedYear) {
        salaries.filter { it.institution == selectedInstitution && it.year == selectedYear }
    }

    val totalPaid = remember(institutionSalaries) {
        institutionSalaries.filter { it.isPaid }.sumOf { it.amount }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .imePadding()
    ) {
        // Institution Selector Tabs (মাদরাসার বেতন vs মসজিদের বেতন)
        ScrollableTabRow(
            selectedTabIndex = selectedTabIndex,
            containerColor = Color.Transparent,
            contentColor = IslamicGreenPrimary,
            edgePadding = 16.dp,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                    color = IslamicGreenPrimary,
                    height = 3.dp
                )
            }
        ) {
            institutions.forEachIndexed { index, name ->
                Tab(
                    selected = selectedTabIndex == index,
                    onClick = { selectedTabIndex = index },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (index == 0) Icons.Default.School else Icons.Default.Mosque,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "$name বেতন",
                                fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 15.sp
                            )
                        }
                    },
                    modifier = Modifier.testTag("salary_tab_$index")
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Year Selector & Total Summary Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = "বছর: ", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
                listOf(selectedYear - 1, selectedYear, selectedYear + 1).forEach { year ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (selectedYear == year) IslamicGreenPrimary else Color(0xFFE5E7EB),
                        modifier = Modifier
                            .padding(horizontal = 4.dp)
                            .clickable { selectedYear = year }
                    ) {
                        Text(
                            text = BanglaHelper.toBanglaDigits(year),
                            color = if (selectedYear == year) Color.White else TextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Text(
                text = "মোট প্রাপ্ত: ${BanglaHelper.formatCurrency(totalPaid)}",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = IncomeGreen
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 12 Months List (জানুয়ারি to ডিসেম্বর)
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(12) { index ->
                val monthIndex = index + 1
                val monthName = BanglaHelper.BANGLA_MONTHS[index]
                val record = institutionSalaries.find { it.monthIndex == monthIndex }

                Elevated3DCard(
                    modifier = Modifier.fillMaxWidth(),
                    elevation = 2f
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Month Name Badge
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    if (record?.isPaid == true) IncomeGreenLight else Color(0xFFF3F4F6)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = monthName.take(3),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (record?.isPaid == true) IncomeGreen else Color(0xFF4B5563)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = monthName,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                if (record != null) {
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = if (record.isPaid) Color(0xFFDCFCE7) else Color(0xFFFEF3C7)
                                    ) {
                                        Text(
                                            text = if (record.isPaid) "পরিশোধিত" else "বকেয়া",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (record.isPaid) Color(0xFF15803D) else Color(0xFFB45309),
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }

                            if (record != null) {
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "টাকা: " + BanglaHelper.formatCurrency(record.amount) +
                                            " • তারিখ: " + BanglaHelper.formatBanglaDate(record.date),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color(0xFF4B5563)
                                )
                                if (record.description.isNotBlank()) {
                                    Text(
                                        text = record.description,
                                        fontSize = 11.sp,
                                        color = Color(0xFF6B7280)
                                    )
                                }
                            } else {
                                Text(
                                    text = "বেতন যোগ করা হয়নি",
                                    fontSize = 12.sp,
                                    color = Color(0xFF9CA3AF)
                                )
                            }
                        }

                        // Action Button (বেতন যোগ / সম্পাদনা / মুছুন)
                        if (record != null) {
                            Row {
                                IconButton(
                                    onClick = {
                                        activeMonthIndex = monthIndex
                                        activeMonthName = monthName
                                        inputAmount = if (record.amount % 1.0 == 0.0) record.amount.toLong().toString() else record.amount.toString()
                                        inputDate = record.date
                                        inputDesc = record.description
                                        inputIsPaid = record.isPaid
                                        showEditDialog = true
                                    },
                                    modifier = Modifier.size(34.dp)
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = "সম্পাদনা", tint = IslamicGreenPrimary, modifier = Modifier.size(18.dp))
                                }
                                IconButton(
                                    onClick = { deleteCandidate = record },
                                    modifier = Modifier.size(34.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "মুছুন", tint = ExpenseRed, modifier = Modifier.size(18.dp))
                                }
                            }
                        } else {
                            Button(
                                onClick = {
                                    activeMonthIndex = monthIndex
                                    activeMonthName = monthName
                                    inputAmount = ""
                                    inputDate = BanglaHelper.getTodayIso()
                                    inputDesc = ""
                                    inputIsPaid = true
                                    showEditDialog = true
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = IslamicGreenPrimary),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier
                                    .height(32.dp)
                                    .testTag("add_salary_month_$monthIndex")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("বেতন যোগ", fontSize = 11.sp, color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }

    // Salary Add / Edit Dialog
    if (showEditDialog) {
        AlertDialog(
            onDismissRequest = { showEditDialog = false },
            title = {
                Text(
                    text = "$selectedInstitution বেতন ($activeMonthName, ${BanglaHelper.toBanglaDigits(selectedYear)})",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // Amount Input
                    Text(text = "টাকার পরিমাণ", fontSize = 12.sp, color = Color(0xFF4B5563))
                    OutlinedTextField(
                        value = inputAmount,
                        onValueChange = { inputAmount = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("salary_amount_input"),
                        placeholder = { Text("যেমন: ১২০০০ বা 12000") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = IslamicGreenPrimary,
                            unfocusedBorderColor = BorderSubtle
                        )
                    )

                    // Date Picker
                    Text(text = "তারিখ", fontSize = 12.sp, color = Color(0xFF4B5563))
                    Elevated3DCard(
                        modifier = Modifier.fillMaxWidth(),
                        elevation = 1f,
                        onClick = {
                            DatePickerHelper.showDatePicker(context, inputDate) { newDate ->
                                inputDate = newDate
                            }
                        }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = BanglaHelper.formatBanglaDate(inputDate),
                                fontSize = 14.sp,
                                color = TextPrimary
                            )
                            Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = IslamicGreenPrimary)
                        }
                    }

                    // Description
                    Text(text = "বিবরণ", fontSize = 12.sp, color = Color(0xFF4B5563))
                    OutlinedTextField(
                        value = inputDesc,
                        onValueChange = { inputDesc = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("যেমন: নিয়মিত মাসিক বেতন") },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = IslamicGreenPrimary,
                            unfocusedBorderColor = BorderSubtle
                        )
                    )

                    // Paid Checkbox
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = inputIsPaid,
                            onCheckedChange = { inputIsPaid = it },
                            colors = CheckboxDefaults.colors(checkedColor = IslamicGreenPrimary)
                        )
                        Text(text = "বেতন পরিশোধিত হয়েছে (Paid)", fontSize = 13.sp, color = TextPrimary)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val parsed = BanglaHelper.parseAmount(inputAmount)
                        if (parsed == null || parsed <= 0.0) {
                            Toast.makeText(context, "অনুগ্রহ করে সঠিক টাকার পরিমাণ লিখুন", Toast.LENGTH_SHORT).show()
                            return@Button
                        }

                        viewModel.addOrUpdateSalary(
                            institution = selectedInstitution,
                            year = selectedYear,
                            monthIndex = activeMonthIndex,
                            monthName = activeMonthName,
                            amount = parsed,
                            date = inputDate,
                            description = inputDesc,
                            isPaid = inputIsPaid,
                            allowOverwrite = false,
                            onDuplicateFound = { existing ->
                                duplicateAlertEntity = existing
                            },
                            onSuccess = {
                                showEditDialog = false
                            }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = IslamicGreenPrimary),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("salary_dialog_save_button")
                ) {
                    Text("সংরক্ষণ", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showEditDialog = false },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("বাতিল", color = TextPrimary)
                }
            },
            shape = RoundedCornerShape(16.dp),
            containerColor = Color.White
        )
    }

    // Duplicate month salary warning alert as specified in prompt!
    if (duplicateAlertEntity != null) {
        ConfirmDialog(
            title = "সতর্কবার্তা: একই মাসে পূর্ববর্তী রেকর্ড রয়েছে",
            message = "${duplicateAlertEntity!!.monthName} মাসের বেতন পূর্বে ইতিমধ্যে সংরক্ষিত রয়েছে।\nপূর্বে যোগ করা পরিমাণ: ${BanglaHelper.formatCurrency(duplicateAlertEntity!!.amount)}\n\nআপনি কি বর্তমান তথ্য দিয়ে এটি সংশোধন (Edit / Overwrite) করতে চান?",
            confirmText = "হ্যাঁ, সংশোধন করুন",
            dismissText = "না, বাতিল",
            isDanger = false,
            onConfirm = {
                val parsed = BanglaHelper.parseAmount(inputAmount) ?: duplicateAlertEntity!!.amount
                viewModel.addOrUpdateSalary(
                    institution = selectedInstitution,
                    year = selectedYear,
                    monthIndex = activeMonthIndex,
                    monthName = activeMonthName,
                    amount = parsed,
                    date = inputDate,
                    description = inputDesc,
                    isPaid = inputIsPaid,
                    allowOverwrite = true,
                    onSuccess = {
                        duplicateAlertEntity = null
                        showEditDialog = false
                    }
                )
            },
            onDismiss = {
                duplicateAlertEntity = null
            }
        )
    }

    // Delete confirmation
    if (deleteCandidate != null) {
        ConfirmDialog(
            title = "বেতনের হিসাব মুছে ফেলবেন?",
            message = "আপনি কি নিশ্চিতভাবে ${deleteCandidate!!.monthName} মাসের বেতন মুছে ফেলতে চান?\nপরিমাণ: ${BanglaHelper.formatCurrency(deleteCandidate!!.amount)}",
            confirmText = "মুছে ফেলুন",
            dismissText = "বাতিল",
            isDanger = true,
            onConfirm = {
                viewModel.deleteSalary(deleteCandidate!!.id)
                deleteCandidate = null
            },
            onDismiss = {
                deleteCandidate = null
            }
        )
    }
}
