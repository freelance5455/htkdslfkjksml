package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import android.widget.Toast
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionStatus
import com.example.data.model.TransactionType
import com.example.ui.components.DecimalSliderField
import com.example.ui.components.FinancialInputField
import com.example.ui.components.ProfitLossBadge
import com.example.ui.components.TransactionStatusBadge
import com.example.ui.viewmodel.BusinessViewModel
import com.example.util.DateUtils
import com.example.util.FinancialMath
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BillPaymentScreen(
    viewModel: BusinessViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val allTransactions by viewModel.allTransactions.collectAsStateWithLifecycle()
    val billTransactions = remember(allTransactions) {
        allTransactions.filter { it.type == TransactionType.BILL_PAYMENT.name }
    }

    // Consolidated bill payment totals
    val consolidatedTotals = remember(billTransactions) {
        var totalVolume = 0.0
        var totalPlatformFees = 0.0
        var totalServiceCharges = 0.0
        var totalCustomerCharges = 0.0
        var totalCommission = 0.0
        var totalOtherCosts = 0.0
        var totalGross = 0.0
        var totalNet = 0.0

        billTransactions.forEach {
            totalVolume += it.amount
            totalPlatformFees += it.platformFeeAmount
            totalServiceCharges += it.serviceChargeAmount
            totalCustomerCharges += it.customerPayoutOrCharge
            totalCommission += it.commissionAmount
            totalOtherCosts += it.otherCosts
            totalGross += it.grossProfit
            totalNet += it.netProfit
        }

        ConsolidatedBillTotals(
            totalVolume = totalVolume,
            totalPlatformFees = totalPlatformFees,
            totalServiceCharges = totalServiceCharges,
            totalCustomerCharges = totalCustomerCharges,
            totalCommission = totalCommission,
            totalOtherCosts = totalOtherCosts,
            totalGross = totalGross,
            totalNet = totalNet,
            count = billTransactions.size
        )
    }

    var isCalculatorExpanded by remember { mutableStateOf(true) }

    // Calculator inputs
    var billAmountText by remember { mutableStateOf("100000") }
    var isManualFee by remember { mutableStateOf(false) }
    var platformFeePercentText by remember(settings) {
        mutableStateOf(String.format(Locale.US, "%.2f", settings.defaultBillPlatformFeePercent))
    }
    var manualPlatformFeeText by remember { mutableStateOf("1500.00") }
    var serviceChargePercentText by remember(settings) {
        mutableStateOf(String.format(Locale.US, "%.2f", settings.defaultBillServiceChargePercent))
    }
    var commissionPercentText by remember(settings) {
        mutableStateOf(String.format(Locale.US, "%.2f", settings.defaultBillCommissionPercent))
    }
    var otherCostsText by remember { mutableStateOf("0.00") }
    var txIdText by remember { mutableStateOf("") }
    var notesText by remember { mutableStateOf("") }
    var statusText by remember { mutableStateOf(TransactionStatus.COMPLETED.name) }
    var isStatusExpanded by remember { mutableStateOf(false) }

    // Validation
    val amountValidation by remember(billAmountText) {
        derivedStateOf { FinancialMath.validateAmount(billAmountText, "Bill Amount") }
    }
    val platformFeeValidation by remember(platformFeePercentText, isManualFee, manualPlatformFeeText) {
        derivedStateOf {
            if (isManualFee) {
                FinancialMath.validateCharge(manualPlatformFeeText, "Platform Fee Amount")
            } else {
                FinancialMath.validatePercentage(platformFeePercentText, "Platform Fee %", 0.0, 50.0)
            }
        }
    }
    val serviceChargeValidation by remember(serviceChargePercentText) {
        derivedStateOf { FinancialMath.validatePercentage(serviceChargePercentText, "Service Charge %", 0.0, 50.0) }
    }
    val commissionValidation by remember(commissionPercentText) {
        derivedStateOf { FinancialMath.validatePercentage(commissionPercentText, "Commission %", 0.0, 20.0) }
    }
    val otherCostsValidation by remember(otherCostsText) {
        derivedStateOf { FinancialMath.validateCharge(otherCostsText, "Other Costs") }
    }

    val isFormValid = amountValidation.isValid &&
            platformFeeValidation.isValid &&
            serviceChargeValidation.isValid &&
            commissionValidation.isValid &&
            otherCostsValidation.isValid

    // Live calculation
    val liveCalculation by remember(
        billAmountText, isManualFee, platformFeePercentText, manualPlatformFeeText,
        serviceChargePercentText, commissionPercentText, otherCostsText
    ) {
        derivedStateOf {
            val amt = FinancialMath.parseDoubleOrNull(billAmountText) ?: 0.0
            val pFeePct = FinancialMath.parseDoubleOrNull(platformFeePercentText) ?: 0.0
            val manPFee = FinancialMath.parseDoubleOrNull(manualPlatformFeeText) ?: 0.0
            val servPct = FinancialMath.parseDoubleOrNull(serviceChargePercentText) ?: 0.0
            val commPct = FinancialMath.parseDoubleOrNull(commissionPercentText) ?: 0.0
            val other = FinancialMath.parseDoubleOrNull(otherCostsText) ?: 0.0

            FinancialMath.calculateBillPayment(
                billAmount = amt,
                platformFeePercent = pFeePct,
                isManualFee = isManualFee,
                manualPlatformFee = manPFee,
                serviceChargePercent = servPct,
                commissionPercent = commPct,
                otherCosts = other
            )
        }
    }

    var transactionToDelete by remember { mutableStateOf<TransactionEntity?>(null) }
    var transactionToEdit by remember { mutableStateOf<TransactionEntity?>(null) }
    var isRecordsExpanded by remember { mutableStateOf(true) }
    var showClearAllBillDialog by remember { mutableStateOf(false) }

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text(
                            text = "Bill Payment Calculator",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Text(
                            text = "Card bill processing, service charge & commission",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    OutlinedButton(
                        onClick = { isCalculatorExpanded = !isCalculatorExpanded },
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(
                            imageVector = if (isCalculatorExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = null
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (isCalculatorExpanded) "Collapse" else "Expand")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
            }

            if (isCalculatorExpanded) {
                item {
                    ElevatedCard(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("bill_payment_calculator_card")
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "CALCULATOR INPUTS",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.secondary,
                                letterSpacing = 1.sp
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            FinancialInputField(
                                value = billAmountText,
                                onValueChange = { billAmountText = it },
                                label = "Bill Amount (₹)",
                                placeholder = "100000.00",
                                prefixText = "₹",
                                validationResult = amountValidation,
                                testTag = "bill_amount_input"
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Fee Mode Selector: Percentage vs Manual
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                FilterChip(
                                    selected = !isManualFee,
                                    onClick = { isManualFee = false },
                                    label = { Text("Auto Platform Fee %", fontSize = 12.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer
                                    )
                                )
                                FilterChip(
                                    selected = isManualFee,
                                    onClick = { isManualFee = true },
                                    label = { Text("Manual Fee Entry (₹)", fontSize = 12.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MaterialTheme.colorScheme.secondaryContainer
                                    )
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            if (!isManualFee) {
                                DecimalSliderField(
                                    valueText = platformFeePercentText,
                                    onValueChange = { platformFeePercentText = it },
                                    label = "Platform Fee",
                                    rangeMin = 0.0f,
                                    rangeMax = 6.0f,
                                    presets = listOf(0.5, 1.0, 1.25, 1.5, 1.75, 2.0),
                                    suffix = "%",
                                    validationResult = platformFeeValidation,
                                    testTag = "bill_platform_fee_slider"
                                )
                            } else {
                                FinancialInputField(
                                    value = manualPlatformFeeText,
                                    onValueChange = { manualPlatformFeeText = it },
                                    label = "Actual Platform Fee Amount (₹)",
                                    placeholder = "1500.00",
                                    prefixText = "₹",
                                    validationResult = platformFeeValidation,
                                    testTag = "manual_platform_fee_input"
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Service Charge % Slider & Field
                            DecimalSliderField(
                                valueText = serviceChargePercentText,
                                onValueChange = { serviceChargePercentText = it },
                                label = "Bill Payment Service Charge",
                                rangeMin = 0.0f,
                                rangeMax = 6.0f,
                                presets = listOf(0.5, 1.0, 1.25, 1.5, 1.75, 2.0),
                                suffix = "%",
                                validationResult = serviceChargeValidation,
                                testTag = "bill_service_charge_slider"
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Commission Received % Slider & Field
                            DecimalSliderField(
                                valueText = commissionPercentText,
                                onValueChange = { commissionPercentText = it },
                                label = "Commission Received (on Bill Amount)",
                                rangeMin = 0.0f,
                                rangeMax = 3.0f,
                                presets = listOf(0.1, 0.2, 0.3, 0.5, 1.0),
                                suffix = "%",
                                validationResult = commissionValidation,
                                testTag = "bill_commission_slider"
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Other Transaction Costs
                            FinancialInputField(
                                value = otherCostsText,
                                onValueChange = { otherCostsText = it },
                                label = "Other Transaction Costs (₹)",
                                placeholder = "0.00",
                                prefixText = "₹",
                                validationResult = otherCostsValidation,
                                testTag = "bill_other_costs_input"
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                OutlinedTextField(
                                    value = txIdText,
                                    onValueChange = { txIdText = it },
                                    label = { Text("Tx ID (Optional)") },
                                    placeholder = { Text("Auto-generated") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.weight(1.2f)
                                )

                                ExposedDropdownMenuBox(
                                    expanded = isStatusExpanded,
                                    onExpandedChange = { isStatusExpanded = !isStatusExpanded },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    OutlinedTextField(
                                        value = statusText,
                                        onValueChange = {},
                                        readOnly = true,
                                        label = { Text("Status") },
                                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = isStatusExpanded) },
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.menuAnchor()
                                    )
                                    ExposedDropdownMenu(
                                        expanded = isStatusExpanded,
                                        onDismissRequest = { isStatusExpanded = false }
                                    ) {
                                        TransactionStatus.entries.forEach { st ->
                                            DropdownMenuItem(
                                                text = { Text(st.name) },
                                                onClick = {
                                                    statusText = st.name
                                                    isStatusExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = notesText,
                                onValueChange = { notesText = it },
                                label = { Text("Customer Name / Card Bill Notes") },
                                placeholder = { Text("e.g. SBI SimplyCLICK Bill, Jane") },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // Live Calculation Card
                            Card(
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text(
                                        text = "LIVE CALCULATION BREAKDOWN",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.secondary
                                    )

                                    Spacer(modifier = Modifier.height(8.dp))

                                    ResultLine(
                                        label = "Platform Fee (${liveCalculation.platformFeePercent}%)",
                                        value = FinancialMath.formatInr(liveCalculation.platformFeeAmount)
                                    )
                                    ResultLine(
                                        label = "Service Charge (${liveCalculation.serviceChargePercent}%)",
                                        value = FinancialMath.formatInr(liveCalculation.serviceChargeAmount)
                                    )
                                    ResultLine(
                                        label = "Commission Received (${liveCalculation.commissionPercent}%)",
                                        value = FinancialMath.formatInr(liveCalculation.commissionAmount)
                                    )

                                    HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))

                                    ResultLine(
                                        label = "Total Customer Charge (${liveCalculation.totalCustomerChargePercent}%)",
                                        value = FinancialMath.formatInr(liveCalculation.totalCustomerCharge),
                                        isBold = true,
                                        color = MaterialTheme.colorScheme.secondary
                                    )

                                    ResultLine(
                                        label = "Estimated Gross Profit",
                                        value = FinancialMath.formatInr(liveCalculation.grossProfit),
                                        isBold = true
                                    )

                                    ResultLine(
                                        label = "Estimated Net Profit",
                                        value = FinancialMath.formatInr(liveCalculation.netProfit),
                                        isBold = true,
                                        color = if (liveCalculation.netProfit >= 0) Color(0xFF0D652D) else Color(0xFFC5221F)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Helper note reminding user that nothing is saved until they click Save to Dashboard
                            Text(
                                text = "Notice: Nothing is saved to your business records until you click 'Save to Dashboard'.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )

                            // Action buttons: Reset Values & Save to Dashboard
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        billAmountText = ""
                                        isManualFee = false
                                        platformFeePercentText = String.format(Locale.US, "%.2f", settings.defaultBillPlatformFeePercent)
                                        manualPlatformFeeText = "0.00"
                                        serviceChargePercentText = String.format(Locale.US, "%.2f", settings.defaultBillServiceChargePercent)
                                        commissionPercentText = String.format(Locale.US, "%.2f", settings.defaultBillCommissionPercent)
                                        otherCostsText = "0.00"
                                        txIdText = ""
                                        notesText = ""
                                        statusText = TransactionStatus.COMPLETED.name
                                        Toast.makeText(context, "Bill payment values reset", Toast.LENGTH_SHORT).show()
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("reset_bill_button")
                                ) {
                                    Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Reset Values")
                                }

                                Button(
                                    onClick = {
                                        if (isFormValid) {
                                            val amt = FinancialMath.parseDoubleOrNull(billAmountText) ?: 0.0
                                            val pFee = FinancialMath.parseDoubleOrNull(platformFeePercentText) ?: 1.5
                                            val manFee = FinancialMath.parseDoubleOrNull(manualPlatformFeeText) ?: 0.0
                                            val serv = FinancialMath.parseDoubleOrNull(serviceChargePercentText) ?: 1.5
                                            val comm = FinancialMath.parseDoubleOrNull(commissionPercentText) ?: 0.2
                                            val other = FinancialMath.parseDoubleOrNull(otherCostsText) ?: 0.0

                                            viewModel.addBillPaymentTransaction(
                                                amount = amt,
                                                platformFeePercent = pFee,
                                                isManualFee = isManualFee,
                                                manualPlatformFee = manFee,
                                                serviceChargePercent = serv,
                                                commissionPercent = comm,
                                                otherCosts = other,
                                                txId = txIdText,
                                                status = statusText,
                                                notes = notesText
                                            )
                                            Toast.makeText(context, "Bill payment saved to Dashboard!", Toast.LENGTH_SHORT).show()
                                            txIdText = ""
                                            notesText = ""
                                        }
                                    },
                                    enabled = isFormValid,
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                    modifier = Modifier
                                        .weight(1.3f)
                                        .testTag("save_to_dashboard_bill_button")
                                ) {
                                    Icon(Icons.Default.Dashboard, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Save to Dashboard")
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }
            }

            // Consolidated Totals Banner
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "CONSOLIDATED BILL PAYMENT SUMMARY",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.secondary
                            )
                            Text(
                                text = "${consolidatedTotals.count} Transactions",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text("Total Bill Volume", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(FinancialMath.formatInr(consolidatedTotals.totalVolume), fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text("Customer Charges", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(FinancialMath.formatInr(consolidatedTotals.totalCustomerCharges), fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text("Platform Fees", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(FinancialMath.formatInr(consolidatedTotals.totalPlatformFees), fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text("Service Charges", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(FinancialMath.formatInr(consolidatedTotals.totalServiceCharges), fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text("Commission Received", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(FinancialMath.formatInr(consolidatedTotals.totalCommission), fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text("Total Net Profit", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                ProfitLossBadge(amount = consolidatedTotals.totalNet, label = "Net")
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Saved Transactions Header with Collapse/Expand and Clear All
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text(
                            text = "Saved Bill Payments (${billTransactions.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isRecordsExpanded) "Showing list of records" else "List view collapsed",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp
                        )
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (billTransactions.isNotEmpty()) {
                            OutlinedButton(
                                onClick = { showClearAllBillDialog = true },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f)),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                modifier = Modifier.testTag("clear_all_bills_button")
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Clear All", fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
                            }
                        }

                        OutlinedButton(
                            onClick = { isRecordsExpanded = !isRecordsExpanded },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("toggle_bill_records_button")
                        ) {
                            Icon(
                                imageVector = if (isRecordsExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                contentDescription = if (isRecordsExpanded) "Collapse" else "Expand",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isRecordsExpanded) "Collapse" else "Expand", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                if (!isRecordsExpanded) {
                    Card(
                        onClick = { isRecordsExpanded = true },
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp)
                        ) {
                            Text(
                                "Bill payment records collapsed (${billTransactions.size} records)",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                "Expand View",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            if (isRecordsExpanded) {
                if (billTransactions.isEmpty()) {
                    item {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 16.dp)
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Receipt,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(36.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("No bill payment transactions recorded yet")
                                Text(
                                    "Enter amounts in the calculator above and click 'Save to Dashboard'.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                } else {
                    items(billTransactions, key = { it.id }) { tx ->
                        BillTransactionCard(
                            transaction = tx,
                            onDuplicate = { viewModel.duplicateTransaction(tx) },
                            onEdit = { transactionToEdit = tx },
                            onDelete = { transactionToDelete = tx }
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }

    // Delete single confirmation dialog
    transactionToDelete?.let { tx ->
        AlertDialog(
            onDismissRequest = { transactionToDelete = null },
            title = { Text("Delete Bill Payment Record") },
            text = { Text("Are you sure you want to delete bill payment ${tx.txId} for ${FinancialMath.formatInr(tx.amount)}? This action cannot be undone.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteTransaction(tx.id)
                        transactionToDelete = null
                        Toast.makeText(context, "Bill payment record deleted successfully", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("confirm_delete_bill_button")
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { transactionToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Clear all bill payments confirmation dialog
    if (showClearAllBillDialog) {
        AlertDialog(
            onDismissRequest = { showClearAllBillDialog = false },
            title = { Text("Delete All Bill Payment Records?") },
            text = { Text("This will permanently delete all ${billTransactions.size} saved bill payment records. Are you sure?") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteTransactionsByType(TransactionType.BILL_PAYMENT.name)
                        showClearAllBillDialog = false
                        Toast.makeText(context, "All bill payment records deleted", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.testTag("confirm_clear_all_bills_button")
                ) {
                    Text("Delete All Records")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showClearAllBillDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Edit Transaction Dialog
    transactionToEdit?.let { tx ->
        EditBillDialog(
            transaction = tx,
            onDismiss = { transactionToEdit = null },
            onSave = { updated ->
                viewModel.updateTransaction(updated)
                transactionToEdit = null
                Toast.makeText(context, "Bill payment transaction updated", Toast.LENGTH_SHORT).show()
            }
        )
    }
}

data class ConsolidatedBillTotals(
    val totalVolume: Double,
    val totalPlatformFees: Double,
    val totalServiceCharges: Double,
    val totalCustomerCharges: Double,
    val totalCommission: Double,
    val totalOtherCosts: Double,
    val totalGross: Double,
    val totalNet: Double,
    val count: Int
)

@Composable
fun BillTransactionCard(
    transaction: TransactionEntity,
    onDuplicate: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
        ),
        modifier = modifier
            .fillMaxWidth()
            .testTag("bill_tx_card_${transaction.id}")
            .clickable { onEdit() }
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(
                        text = transaction.txId,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = DateUtils.formatDateTime(transaction.timestamp),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp
                    )
                }

                TransactionStatusBadge(transaction.status)
            }

            if (transaction.notes.isNotBlank()) {
                Text(
                    text = transaction.notes,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 6.dp))

            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text("Bill Amount", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(FinancialMath.formatInr(transaction.amount), fontWeight = FontWeight.Bold)
                }
                Column {
                    Text("Customer Charge", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(FinancialMath.formatInr(transaction.customerPayoutOrCharge), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                }
                Column {
                    Text("Net Profit", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    ProfitLossBadge(amount = transaction.netProfit, label = "Net")
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Service: ${FinancialMath.formatInr(transaction.serviceChargeAmount)} (${transaction.serviceChargePercent}%) • Comm: ${FinancialMath.formatInr(transaction.commissionAmount)} (${transaction.commissionPercent}%) • Plat Fee: ${FinancialMath.formatInr(transaction.platformFeeAmount)}",
                style = MaterialTheme.typography.bodySmall,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(8.dp))

            // Dedicated, prominent action buttons for Edit and Delete
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedButton(
                    onClick = onEdit,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("edit_tx_btn_${transaction.id}")
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Edit", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }

                OutlinedButton(
                    onClick = onDelete,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.error
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.6f)),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("delete_tx_btn_${transaction.id}")
                ) {
                    Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(15.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Delete", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.error)
                }

                OutlinedButton(
                    onClick = onDuplicate,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("duplicate_tx_btn_${transaction.id}")
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Copy", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun EditBillDialog(
    transaction: TransactionEntity,
    onDismiss: () -> Unit,
    onSave: (TransactionEntity) -> Unit
) {
    var amountText by remember(transaction.id) { mutableStateOf(transaction.amount.toString()) }
    var platformFeeText by remember(transaction.id) { mutableStateOf(transaction.platformFeePercent.toString()) }
    var serviceChargeText by remember(transaction.id) { mutableStateOf(transaction.serviceChargePercent.toString()) }
    var commissionText by remember(transaction.id) { mutableStateOf(transaction.commissionPercent.toString()) }
    var otherCostsText by remember(transaction.id) { mutableStateOf(transaction.otherCosts.toString()) }
    var notesText by remember(transaction.id) { mutableStateOf(transaction.notes) }
    var statusText by remember(transaction.id) { mutableStateOf(transaction.status) }

    val amountValidation = FinancialMath.validateAmount(amountText, "Bill Amount")
    val pFeeValidation = FinancialMath.validatePercentage(platformFeeText, "Platform Fee %")
    val servValidation = FinancialMath.validatePercentage(serviceChargeText, "Service Charge %")
    val commValidation = FinancialMath.validatePercentage(commissionText, "Commission %")

    val isValid = amountValidation.isValid && pFeeValidation.isValid && servValidation.isValid && commValidation.isValid

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Bill Payment: ${transaction.txId}") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                FinancialInputField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = "Bill Amount",
                    validationResult = amountValidation
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FinancialInputField(
                        value = platformFeeText,
                        onValueChange = { platformFeeText = it },
                        label = "Platform Fee %",
                        prefixText = null,
                        suffixText = "%",
                        validationResult = pFeeValidation,
                        modifier = Modifier.weight(1f)
                    )
                    FinancialInputField(
                        value = serviceChargeText,
                        onValueChange = { serviceChargeText = it },
                        label = "Service Charge %",
                        prefixText = null,
                        suffixText = "%",
                        validationResult = servValidation,
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FinancialInputField(
                        value = commissionText,
                        onValueChange = { commissionText = it },
                        label = "Commission %",
                        prefixText = null,
                        suffixText = "%",
                        validationResult = commValidation,
                        modifier = Modifier.weight(1f)
                    )
                    FinancialInputField(
                        value = otherCostsText,
                        onValueChange = { otherCostsText = it },
                        label = "Other Costs",
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it },
                    label = { Text("Notes") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (isValid) {
                        val amt = FinancialMath.parseDoubleOrNull(amountText) ?: transaction.amount
                        val pFee = FinancialMath.parseDoubleOrNull(platformFeeText) ?: transaction.platformFeePercent
                        val serv = FinancialMath.parseDoubleOrNull(serviceChargeText) ?: transaction.serviceChargePercent
                        val comm = FinancialMath.parseDoubleOrNull(commissionText) ?: transaction.commissionPercent
                        val other = FinancialMath.parseDoubleOrNull(otherCostsText) ?: transaction.otherCosts

                        val calc = FinancialMath.calculateBillPayment(
                            billAmount = amt,
                            platformFeePercent = pFee,
                            isManualFee = false,
                            manualPlatformFee = 0.0,
                            serviceChargePercent = serv,
                            commissionPercent = comm,
                            otherCosts = other
                        )

                        val updated = transaction.copy(
                            amount = calc.billAmount,
                            platformFeePercent = calc.platformFeePercent,
                            platformFeeAmount = calc.platformFeeAmount,
                            serviceChargePercent = calc.serviceChargePercent,
                            serviceChargeAmount = calc.serviceChargeAmount,
                            commissionPercent = calc.commissionPercent,
                            commissionAmount = calc.commissionAmount,
                            customerPayoutOrCharge = calc.totalCustomerCharge,
                            grossProfit = calc.grossProfit,
                            netProfit = calc.netProfit,
                            otherCosts = calc.otherCosts,
                            notes = notesText,
                            status = statusText
                        )
                        onSave(updated)
                    }
                },
                enabled = isValid,
                modifier = Modifier.testTag("save_edit_transaction_button")
            ) {
                Text("Save Changes")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
