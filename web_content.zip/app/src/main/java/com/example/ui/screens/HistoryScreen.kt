package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.Auction
import com.example.data.model.AuctionStatus
import com.example.data.model.UiState
import com.example.data.model.UserBidRecord
import com.example.ui.components.BidderNumberChip
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.LotImageDisplay
import com.example.ui.theme.MonoFontFamily
import com.example.ui.theme.UrgentCrimson
import com.example.ui.theme.UrgentCrimsonContainer
import com.example.util.calculateCommission
import com.example.util.formatNaira
import com.example.util.formatTimestamp

@Composable
fun HistoryScreen(
    auctionsState: UiState<List<Auction>>,
    myBidRecordsState: UiState<List<UserBidRecord>>,
    nowMillis: Long,
    currentUserId: String,
    onOpenAuction: (String) -> Unit
) {
    var selectedSegment by remember { mutableIntStateOf(0) }
    val allAuctions = (auctionsState as? UiState.Success)?.data ?: emptyList()
    val auctionMap = remember(allAuctions) { allAuctions.associateBy { it.id } }
    val myRecords = (myBidRecordsState as? UiState.Success)?.data ?: emptyList()

    val completedAuctions = remember(allAuctions, nowMillis) {
        allAuctions.filter {
            val st = it.effectiveStatus(nowMillis)
            st == AuctionStatus.ENDED || st == AuctionStatus.SETTLED || st == AuctionStatus.CANCELLED
        }
    }

    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Auction History",
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        SegmentedButton(
                            selected = selectedSegment == 0,
                            onClick = { selectedSegment = 0 },
                            shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2),
                            modifier = Modifier.testTag("history_tab_my_bids")
                        ) {
                            Text("My Bids (${myRecords.size})")
                        }
                        SegmentedButton(
                            selected = selectedSegment == 1,
                            onClick = { selectedSegment = 1 },
                            shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2),
                            modifier = Modifier.testTag("history_tab_archive")
                        ) {
                            Text("Completed (${completedAuctions.size})")
                        }
                    }
                }
            }

            if (selectedSegment == 0) {
                if (myRecords.isEmpty()) {
                    item {
                        EmptyStateCard(
                            title = "No Bid History Yet",
                            subtitle = "Bids you place on live auctions appear here with real-time Leading, Outbid, and Won badges."
                        )
                    }
                } else {
                    items(myRecords, key = { it.auctionId }) { rec ->
                        val lot = auctionMap[rec.auctionId]
                        val status = lot?.effectiveStatus(nowMillis) ?: AuctionStatus.ACTIVE
                        val isLeading = lot?.highestBidderId == currentUserId

                        val (badgeText, badgeBg, badgeFg) = when {
                            status == AuctionStatus.SETTLED && isLeading ->
                                Triple("WON & SETTLED", MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.onPrimaryContainer)
                            status == AuctionStatus.ENDED && isLeading ->
                                Triple("WON • PAY NOW", MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.onSecondaryContainer)
                            status == AuctionStatus.ACTIVE && isLeading ->
                                Triple("LEADING BID", MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.onPrimaryContainer)
                            status == AuctionStatus.ENDED || status == AuctionStatus.SETTLED ->
                                Triple("CLOSED", MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.colorScheme.onSurfaceVariant)
                            else ->
                                Triple("OUTBID", UrgentCrimsonContainer, UrgentCrimson)
                        }

                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onOpenAuction(rec.auctionId) }
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                LotImageDisplay(
                                    imageSpec = lot?.imageItems?.firstOrNull() ?: rec.imageItem,
                                    contentDescription = rec.auctionTitle,
                                    modifier = Modifier
                                        .size(72.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                )
                                Column(
                                    modifier = Modifier.weight(1f),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Surface(color = badgeBg, shape = RoundedCornerShape(50.dp)) {
                                        Text(
                                            text = badgeText,
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = badgeFg,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                        )
                                    }
                                    Text(
                                        text = rec.auctionTitle,
                                        style = MaterialTheme.typography.titleSmall,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "My Max: ${formatNaira(rec.myHighestBid)} • Current: ${formatNaira(lot?.currentBid ?: rec.myHighestBid)}",
                                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = MonoFontFamily),
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                if (completedAuctions.isEmpty()) {
                    item {
                        EmptyStateCard(
                            title = "No Completed Auctions Yet",
                            subtitle = "Ended and settled lots with verified winning bidder numbers and 3% commission records will appear here."
                        )
                    }
                } else {
                    items(completedAuctions, key = { it.id }) { lot ->
                        val commission = if (lot.commissionAmount > 0L) {
                            lot.commissionAmount
                        } else if (lot.bidCount > 0L) {
                            calculateCommission(lot.currentBid)
                        } else 0L

                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onOpenAuction(lot.id) }
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    LotImageDisplay(
                                        imageSpec = lot.imageItems.firstOrNull(),
                                        contentDescription = lot.title,
                                        modifier = Modifier
                                            .size(64.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                    )
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = lot.title,
                                            style = MaterialTheme.typography.titleSmall,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "Hammer: ${formatNaira(if (lot.bidCount > 0L) lot.currentBid else 0L)} (${lot.bidCount} bids)",
                                            style = MaterialTheme.typography.bodyMedium.copy(fontFamily = MonoFontFamily),
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            text = "Status: ${lot.status} • Closed ${formatTimestamp(lot.endsAt)}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    if (lot.highestBidderNumber.isNotBlank()) {
                                        BidderNumberChip(
                                            bidderNumber = lot.highestBidderNumber,
                                            isLeadingMe = lot.highestBidderId == currentUserId
                                        )
                                    } else {
                                        Text(
                                            text = "Unsold (0 bids)",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    if (commission > 0L) {
                                        Text(
                                            text = "3% Fee: ${formatNaira(commission)}",
                                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
                                            color = MaterialTheme.colorScheme.secondary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
