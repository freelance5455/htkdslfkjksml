package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Drafts
import androidx.compose.material.icons.filled.DynamicFeed
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PersonPin
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.ArkPost
import com.example.data.model.PostDraft
import com.example.ui.components.EmptyStateGlassCard
import com.example.ui.components.FeedPostCard
import com.example.ui.components.GlowingPillButton
import com.example.ui.components.LiquidGlassCard
import com.example.ui.components.UserBadgeChip
import com.example.ui.theme.ArkExtendedColors
import com.example.util.rememberDecodedImageBitmap

fun LazyListScope.profilePostsItems(
    posts: List<ArkPost>,
    currentUserId: String,
    myReactions: Map<String, String>,
    myPollVotes: Map<String, Int>,
    bookmarkedIds: Set<String>,
    emptyTitle: String,
    emptySubtitle: String,
    isSavedTab: Boolean,
    onCreatePost: () -> Unit,
    onReaction: (ArkPost, String) -> Unit,
    onOpenComments: (ArkPost) -> Unit,
    onSharePost: (ArkPost) -> Unit,
    onToggleBookmark: (String) -> Unit,
    onVotePoll: (String, Int) -> Unit,
    onEditCaption: (ArkPost) -> Unit,
    onToggleCommentsDisabled: (ArkPost) -> Unit,
    onDeletePost: (String) -> Unit,
    onOpenMedia: (ArkPost, Int) -> Unit,
    onOpenUserProfile: (String) -> Unit = {},
    onHashtagClick: (String) -> Unit = {},
    onOpenLikers: (ArkPost) -> Unit = {}
) {
    if (posts.isEmpty()) {
        item(key = if (isSavedTab) "saved_empty" else "my_posts_empty") {
            EmptyStateGlassCard(
                icon = if (isSavedTab) Icons.Default.Bookmark else Icons.Default.DynamicFeed,
                title = emptyTitle,
                subtitle = emptySubtitle,
                actionLabel = if (isSavedTab) null else "Create Post",
                onAction = if (isSavedTab) null else onCreatePost
            )
        }
    } else {
        items(posts, key = { "${if (isSavedTab) "saved" else "mine"}_${it.id}" }) { post ->
            FeedPostCard(
                post = post,
                currentUserId = currentUserId,
                myReaction = myReactions[post.id],
                myPollVote = myPollVotes[post.id],
                isBookmarked = bookmarkedIds.contains(post.id),
                onReaction = { react -> onReaction(post, react) },
                onOpenComments = { onOpenComments(post) },
                onShare = { onSharePost(post) },
                onToggleBookmark = { onToggleBookmark(post.id) },
                onVotePoll = { idx -> onVotePoll(post.id, idx) },
                onEditCaption = { onEditCaption(post) },
                onToggleCommentsDisabled = { onToggleCommentsDisabled(post) },
                onDeletePost = { onDeletePost(post.id) },
                onHidePost = {},
                onMuteAuthor = {},
                onReportPost = {},
                onOpenMedia = { page -> onOpenMedia(post, page) },
                onOpenUserProfile = onOpenUserProfile,
                onHashtagClick = onHashtagClick,
                onOpenLikers = { onOpenLikers(post) }
            )
        }
    }
}

fun LazyListScope.profileMediaGridItems(
    posts: List<ArkPost>,
    colors: ArkExtendedColors,
    onOpenMedia: (ArkPost, Int) -> Unit,
    onCreatePost: (() -> Unit)? = null,
    onOpenPostComments: (ArkPost) -> Unit = {}
) {
    if (posts.isEmpty()) {
        item(key = "media_empty") {
            EmptyStateGlassCard(
                icon = Icons.Default.PhotoLibrary,
                title = "No Posts Yet",
                subtitle = "Photos, short videos, and squad milestones appear in your grid.",
                actionLabel = if (onCreatePost != null) "Share Moment" else null,
                onAction = onCreatePost
            )
        }
    } else {
        val rows = posts.chunked(3)
        items(rows.size, key = { "media_row_$it" }) { rowIdx ->
            val rowPosts = rows[rowIdx]
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                rowPosts.forEach { post ->
                    val b64 = post.imageBase64List.firstOrNull() ?: post.videoThumbnailBase64
                    val isVideo = post.postType == "video"
                    val isCarousel = post.imageBase64List.size > 1
                    val bmp = rememberDecodedImageBitmap(b64)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(colors.surfaceSecondary)
                            .clickable {
                                if (b64 != null) onOpenMedia(post, 0) else onOpenPostComments(post)
                            }
                    ) {
                        if (bmp != null) {
                            Image(
                                bitmap = bmp,
                                contentDescription = post.altTexts.firstOrNull()?.takeIf { it.isNotBlank() } ?: "Shared post media",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Column(
                                modifier = Modifier.fillMaxSize().padding(8.dp),
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = post.caption.ifBlank { post.pollQuestion ?: post.metaGameName ?: post.category },
                                    style = MaterialTheme.typography.labelSmall,
                                    color = colors.ink,
                                    maxLines = 4
                                )
                            }
                        }
                        if (isVideo) {
                            Icon(
                                Icons.Default.PlayCircle,
                                contentDescription = "Video clip",
                                tint = Color.White,
                                modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).size(22.dp)
                            )
                        } else if (isCarousel) {
                            Icon(
                                Icons.Default.Collections,
                                contentDescription = "Multiple photos",
                                tint = Color.White,
                                modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).size(18.dp)
                            )
                        }
                    }
                }
                repeat(3 - rowPosts.size) {
                    Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

fun LazyListScope.profileTaggedItems(
    taggedPosts: List<ArkPost>,
    pendingTags: List<ArkPost>,
    isOwnProfile: Boolean,
    colors: ArkExtendedColors,
    onApproveTag: (String) -> Unit,
    onDeclineTag: (String) -> Unit,
    onOpenMedia: (ArkPost, Int) -> Unit,
    onOpenComments: (ArkPost) -> Unit
) {
    if (isOwnProfile && pendingTags.isNotEmpty()) {
        item(key = "pending_tags_header") {
            Text(
                "Pending Tag Review (${pendingTags.size})",
                style = MaterialTheme.typography.titleSmall,
                color = colors.accent
            )
        }
        items(pendingTags, key = { "ptag_${it.id}" }) { post ->
            LiquidGlassCard(
                modifier = Modifier.fillMaxWidth(),
                accentColor = colors.accent
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("@${post.authorUsername} tagged you", style = MaterialTheme.typography.titleSmall, color = colors.ink)
                        if (post.caption.isNotBlank()) {
                            Text(post.caption, style = MaterialTheme.typography.bodySmall, color = colors.ink2, maxLines = 2)
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OutlinedButton(onClick = { onDeclineTag(post.id) }) {
                            Icon(Icons.Default.Close, contentDescription = "Decline tag", modifier = Modifier.size(16.dp))
                        }
                        GlowingPillButton(
                            text = "Approve",
                            icon = Icons.Default.Check,
                            onClick = { onApproveTag(post.id) }
                        )
                    }
                }
            }
        }
    }

    if (taggedPosts.isEmpty() && (!isOwnProfile || pendingTags.isEmpty())) {
        item(key = "tagged_empty") {
            EmptyStateGlassCard(
                icon = Icons.Default.PersonPin,
                title = "No Tagged Posts",
                subtitle = "Photos and squad memories where you are tagged appear here."
            )
        }
    } else if (taggedPosts.isNotEmpty()) {
        profileMediaGridItems(
            posts = taggedPosts,
            colors = colors,
            onOpenMedia = onOpenMedia,
            onOpenPostComments = onOpenComments
        )
    }
}

fun LazyListScope.profileDraftsItems(
    drafts: List<PostDraft>,
    colors: ArkExtendedColors,
    onOpenDraft: (PostDraft) -> Unit,
    onDeleteDraft: (String) -> Unit,
    onCreatePost: () -> Unit
) {
    if (drafts.isEmpty()) {
        item(key = "drafts_empty") {
            EmptyStateGlassCard(
                icon = Icons.Default.Drafts,
                title = "No Saved Drafts",
                subtitle = "Tap Draft in the Create Post editor anytime to save unfinished posts privately.",
                actionLabel = "New Draft",
                onAction = onCreatePost
            )
        }
    } else {
        items(drafts, key = { "draft_${it.id}" }) { draft ->
            LiquidGlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("profile_draft_${draft.id}"),
                accentColor = colors.gold,
                onClick = { onOpenDraft(draft) }
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            UserBadgeChip(label = draft.postType.uppercase(), accent = colors.gold)
                            Spacer(Modifier.width(6.dp))
                            Text(draft.visibility, style = MaterialTheme.typography.labelSmall, color = colors.accent)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = draft.caption.ifBlank { draft.pollQuestion.ifBlank { "(Media Draft)" } },
                            style = MaterialTheme.typography.bodyMedium,
                            color = colors.ink,
                            maxLines = 2
                        )
                    }
                    Row {
                        IconButton(onClick = { onOpenDraft(draft) }) {
                            Icon(Icons.Default.Edit, contentDescription = "Resume draft", tint = colors.accent)
                        }
                        IconButton(onClick = { onDeleteDraft(draft.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete draft", tint = colors.coral)
                        }
                    }
                }
            }
        }
    }
}
