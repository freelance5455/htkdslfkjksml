package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.InterFontFamily
import com.example.ui.theme.LocalXireColors

@Composable
fun OnboardingOverlay(
    onComplete: (name: String, age: Int) -> Unit
) {
    val xireColors = LocalXireColors.current
    var name by remember { mutableStateOf("") }
    var ageText by remember { mutableStateOf("") }
    var nameError by remember { mutableStateOf(false) }
    var ageError by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .safeDrawingPadding()
            .padding(horizontal = 24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 440.dp)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            XireLogo(size = 92.dp, spin = true)

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Welcome to XIRE AI",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Your private, on-device assistant.",
                fontFamily = InterFontFamily,
                fontSize = 15.sp,
                color = xireColors.muted,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(24.dp))

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Column {
                    Text(
                        text = "Your name",
                        fontFamily = InterFontFamily,
                        fontSize = 13.sp,
                        color = xireColors.muted,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    OutlinedTextField(
                        value = name,
                        onValueChange = {
                            if (it.length <= 40) {
                                name = it
                                nameError = false
                            }
                        },
                        placeholder = { Text("Name", fontFamily = InterFontFamily) },
                        singleLine = true,
                        isError = nameError,
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = xireColors.card,
                            unfocusedContainerColor = xireColors.card,
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = xireColors.border
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("onboarding_name_input")
                    )
                }

                Column {
                    Text(
                        text = "Your age",
                        fontFamily = InterFontFamily,
                        fontSize = 13.sp,
                        color = xireColors.muted,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    OutlinedTextField(
                        value = ageText,
                        onValueChange = { raw ->
                            val digits = raw.filter { it.isDigit() }.take(3)
                            ageText = digits
                            ageError = false
                        },
                        placeholder = { Text("Age", fontFamily = InterFontFamily) },
                        singleLine = true,
                        isError = ageError,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = xireColors.card,
                            unfocusedContainerColor = xireColors.card,
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = xireColors.border
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("onboarding_age_input")
                    )
                }
            }

            Spacer(modifier = Modifier.height(22.dp))

            Button(
                onClick = {
                    val trimmed = name.trim()
                    val parsedAge = ageText.toIntOrNull() ?: 0
                    val badName = trimmed.isEmpty()
                    val badAge = parsedAge !in 1..120
                    nameError = badName
                    ageError = badAge
                    if (!badName && !badAge) {
                        onComplete(trimmed, parsedAge)
                    }
                },
                shape = RoundedCornerShape(999.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("onboarding_start_button")
            ) {
                Text(
                    text = "Get started",
                    fontFamily = InterFontFamily,
                    fontSize = 15.sp
                )
            }
        }
    }
}
