package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AddBusiness
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.MarkEmailRead
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.SeedData
import com.example.data.model.Invite

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WorkspaceSetupScreen(
    userEmail: String,
    isLoading: Boolean,
    errorMessage: String?,
    pendingInvite: Invite?,
    onCheckInvite: (String) -> Unit,
    onAcceptInvite: (String, Invite) -> Unit,
    onJoinWithPin: (schoolId: String, role: String, classId: String, pin: String) -> Unit,
    onCreateWorkspace: (schoolCode: String) -> Unit,
    onSignOut: () -> Unit,
    modifier: Modifier = Modifier
) {
    var schoolCode by remember { mutableStateOf(SeedData.DEFAULT_SCHOOL_ID) }
    var selectedRole by remember { mutableStateOf("class") }
    var selectedClassId by remember { mutableStateOf("c1") }
    var customClassId by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var showCreateMode by remember { mutableStateOf(false) }
    var newSchoolCode by remember { mutableStateOf("") }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .safeDrawingPadding()
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 500.dp)
                .verticalScroll(rememberScrollState()),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Default.School,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Column {
                            Text(
                                text = "مدرسہ کنکشن · Join Madrasah",
                                style = MaterialTheme.typography.titleLarge
                            )
                            Text(
                                text = userEmail,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    IconButton(
                        onClick = onSignOut,
                        modifier = Modifier.testTag("setup_sign_out_button")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.Logout,
                            contentDescription = "Sign Out"
                        )
                    }
                }

                if (pendingInvite != null) {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = MaterialTheme.shapes.medium,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.MarkEmailRead, contentDescription = null)
                                Text(
                                    text = "آپ کو ایڈمن کی جانب سے دعوت موصول ہوئی ہے!",
                                    style = MaterialTheme.typography.titleMedium
                                )
                            }
                            Text(
                                text = if (pendingInvite.role == "admin") "Role: Admin" else "Class: ${pendingInvite.classId}",
                                style = MaterialTheme.typography.bodySmall
                            )
                            Button(
                                onClick = { onAcceptInvite(schoolCode, pendingInvite) },
                                enabled = !isLoading,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("accept_invite_button")
                            ) {
                                Text("شامل ہوں · Join Immediately")
                            }
                        }
                    }
                }

                if (!showCreateMode) {
                    OutlinedTextField(
                        value = schoolCode,
                        onValueChange = {
                            schoolCode = it
                            onCheckInvite(it)
                        },
                        label = { Text("Madrasah Code (مدرسہ کوڈ)") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("school_code_input")
                    )

                    Text(
                        text = "اپنا کردار منتخب کریں · Select Role / Class",
                        style = MaterialTheme.typography.labelLarge
                    )

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        FilterChip(
                            selected = selectedRole == "class" && selectedClassId == "c1",
                            onClick = { selectedRole = "class"; selectedClassId = "c1" },
                            label = { Text("صدیق اکبر (Class 1)") },
                            modifier = Modifier.testTag("role_c1_chip")
                        )
                        FilterChip(
                            selected = selectedRole == "class" && selectedClassId == "c2",
                            onClick = { selectedRole = "class"; selectedClassId = "c2" },
                            label = { Text("فاروق اعظم (Class 2)") },
                            modifier = Modifier.testTag("role_c2_chip")
                        )
                        FilterChip(
                            selected = selectedRole == "admin",
                            onClick = { selectedRole = "admin" },
                            label = { Text("ایڈمن (Admin)") },
                            modifier = Modifier.testTag("role_admin_chip")
                        )
                        FilterChip(
                            selected = selectedRole == "class" && selectedClassId == "other",
                            onClick = { selectedRole = "class"; selectedClassId = "other" },
                            label = { Text("Other Class ID") },
                            modifier = Modifier.testTag("role_other_chip")
                        )
                    }

                    if (selectedRole == "class" && selectedClassId == "other") {
                        OutlinedTextField(
                            value = customClassId,
                            onValueChange = { customClassId = it },
                            label = { Text("Class ID (e.g. c3)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    OutlinedTextField(
                        value = pin,
                        onValueChange = { pin = it },
                        label = { Text("PIN کوڈ درج کریں (e.g. 1111, 2222, 1234)") },
                        leadingIcon = { Icon(Icons.Default.Key, contentDescription = null) },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("pin_input")
                    )

                    Button(
                        onClick = {
                            val cid = if (selectedClassId == "other") customClassId.trim() else selectedClassId
                            onJoinWithPin(schoolCode, selectedRole, cid, pin)
                        },
                        enabled = !isLoading && pin.isNotBlank(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("join_school_button")
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text("لاگ اِن کریں · Connect Online")
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    OutlinedButton(
                        onClick = { showCreateMode = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("switch_to_create_workspace_button")
                    ) {
                        Icon(Icons.Default.AddBusiness, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.size(8.dp))
                        Text("نیا مدرسہ ورک اسپیس بنائیں · Create New Madrasah")
                    }
                } else {
                    Text(
                        text = "اپنا نیا آن لائن مدرسہ ورک اسپیس بنائیں (ابتدائی طلبہ و کلاسز خودکار شامل ہوں گی):",
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Start
                    )
                    OutlinedTextField(
                        value = newSchoolCode,
                        onValueChange = { newSchoolCode = it },
                        label = { Text("Unique Madrasah Code (e.g. almustafa_2)") },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("new_school_code_input")
                    )
                    Button(
                        onClick = { onCreateWorkspace(newSchoolCode) },
                        enabled = !isLoading && newSchoolCode.trim().length >= 3,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("create_workspace_button")
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text("ورک اسپیس بنائیں · Create & Seed")
                        }
                    }
                    OutlinedButton(
                        onClick = { showCreateMode = false },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("واپس جائیں · Back to Join")
                    }
                }

                if (!errorMessage.isNullOrBlank()) {
                    Text(
                        text = errorMessage,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}
