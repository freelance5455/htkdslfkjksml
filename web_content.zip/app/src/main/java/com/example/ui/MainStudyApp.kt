package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.outlined.MenuBook
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.StatsScreen
import com.example.ui.screens.SubjectsScreen
import com.example.ui.screens.TimerScreen
import com.example.ui.theme.AestheticBlack
import com.example.ui.theme.DeepPink
import com.example.ui.theme.PastelPinkBg
import com.example.ui.theme.PastelPinkContainer
import com.example.ui.theme.PureWhite
import com.example.ui.theme.TextGrey

enum class StudyTab(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    TIMER("Timer", Icons.Filled.Timer, Icons.Outlined.Timer),
    SUBJECTS("Subjects", Icons.AutoMirrored.Filled.MenuBook, Icons.AutoMirrored.Outlined.MenuBook),
    STATS("Stats", Icons.Filled.BarChart, Icons.Outlined.BarChart),
    SETTINGS("Settings", Icons.Filled.Settings, Icons.Outlined.Settings)
}

@Composable
fun MainStudyApp(
    viewModel: StudyViewModel,
    modifier: Modifier = Modifier
) {
    var currentTab by remember { mutableStateOf(StudyTab.TIMER) }

    val timerState by viewModel.timerState.collectAsStateWithLifecycle()
    val settingsState by viewModel.settingsState.collectAsStateWithLifecycle()
    val subjects by viewModel.subjects.collectAsStateWithLifecycle()
    val sessions by viewModel.allSessions.collectAsStateWithLifecycle()

    // Back handling: If on secondary tab, back brings user to Timer
    if (currentTab != StudyTab.TIMER) {
        BackHandler {
            currentTab = StudyTab.TIMER
        }
    }

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = PureWhite,
                tonalElevation = 4.dp,
                windowInsets = WindowInsets.navigationBars,
                modifier = Modifier.testTag("main_navigation_bar")
            ) {
                StudyTab.values().forEach { tab ->
                    val isSelected = currentTab == tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentTab = tab },
                        icon = {
                            Icon(
                                imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                contentDescription = tab.title
                            )
                        },
                        label = {
                            Text(
                                text = tab.title,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 11.sp
                                )
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = DeepPink,
                            selectedTextColor = DeepPink,
                            indicatorColor = PastelPinkContainer,
                            unselectedIconColor = TextGrey,
                            unselectedTextColor = TextGrey
                        ),
                        modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                    )
                }
            }
        },
        containerColor = PastelPinkBg,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        when (currentTab) {
            StudyTab.TIMER -> {
                TimerScreen(
                    timerState = timerState,
                    settings = settingsState,
                    subjects = subjects,
                    sessions = sessions,
                    onStartTimer = { viewModel.startTimer() },
                    onPauseTimer = { viewModel.pauseTimer() },
                    onResetTimer = { viewModel.resetTimer() },
                    onSelectMode = { mode -> viewModel.setMode(mode) },
                    onAdjustTime = { deltaMin -> viewModel.adjustTime(deltaMin) },
                    onSelectSubject = { subject -> viewModel.selectSubject(subject) },
                    onAddSubject = { name, icon, color, goal ->
                        viewModel.addSubject(name, icon, color, goal)
                    },
                    onSetAmbientSound = { sound -> viewModel.setAmbientSound(sound) },
                    onCompleteEarly = { viewModel.completeSessionEarly() },
                    onDismissRewardSticker = { viewModel.dismissUnlockedSticker() },
                    onSelectActiveSticker = { id -> viewModel.setActiveSticker(id) },
                    onActivateVip = { viewModel.activateVip() },
                    modifier = Modifier.padding(innerPadding)
                )
            }
            StudyTab.SUBJECTS -> {
                SubjectsScreen(
                    subjects = subjects,
                    sessions = sessions,
                    onAddSubject = { name, icon, color, goal ->
                        viewModel.addSubject(name, icon, color, goal)
                    },
                    onUpdateSubject = { subject -> viewModel.updateSubject(subject) },
                    onDeleteSubject = { subject -> viewModel.deleteSubject(subject) },
                    onStartFocusSubject = { subject ->
                        viewModel.selectSubject(subject)
                        currentTab = StudyTab.TIMER
                    },
                    modifier = Modifier.padding(innerPadding)
                )
            }
            StudyTab.STATS -> {
                StatsScreen(
                    subjects = subjects,
                    sessions = sessions,
                    dailyGoalMinutes = settingsState.dailyGoalMinutes,
                    onDeleteSession = { id -> viewModel.deleteSession(id) },
                    onAddManualSession = { subject, duration, notes ->
                        viewModel.addManualSession(subject, duration, notes)
                    },
                    modifier = Modifier.padding(innerPadding)
                )
            }
            StudyTab.SETTINGS -> {
                SettingsScreen(
                    settings = settingsState,
                    onSaveSettings = { focus, shortBreak, longBreak, interval, goal, sound, vib ->
                        viewModel.updateSettings(focus, shortBreak, longBreak, interval, goal, sound, vib)
                    },
                    onToggleAutoNotifications = { viewModel.toggleAutoNotifications(it) },
                    onTriggerTestNotification = { viewModel.triggerTestAutoNotification() },
                    onActivateVip = { viewModel.activateVip() },
                    modifier = Modifier.padding(innerPadding)
                )
            }
        }
    }
}
