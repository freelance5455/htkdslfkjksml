package com.example.ui.components.tools

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DailyPanchang
import com.example.ui.theme.PanchakBadge
import java.util.Calendar
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun VastuCompassTool() {
    val context = LocalContext.current
    var azimuthDegree by remember { mutableFloatStateOf(0f) }

    DisposableEffect(Unit) {
        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
            ?: sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION)

        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                if (event == null) return
                if (event.sensor.type == Sensor.TYPE_ROTATION_VECTOR) {
                    val rotationMatrix = FloatArray(9)
                    SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
                    val orientation = FloatArray(3)
                    SensorManager.getOrientation(rotationMatrix, orientation)
                    val degree = Math.toDegrees(orientation[0].toDouble()).toFloat()
                    azimuthDegree = (degree + 360) % 360
                } else if (event.sensor.type == Sensor.TYPE_ORIENTATION) {
                    azimuthDegree = (event.values[0] + 360) % 360
                }
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }

        if (rotationSensor != null) {
            sensorManager.registerListener(listener, rotationSensor, SensorManager.SENSOR_DELAY_UI)
        }

        onDispose {
            sensorManager.unregisterListener(listener)
        }
    }

    val smoothDegree by animateFloatAsState(
        targetValue = azimuthDegree,
        animationSpec = tween(durationMillis = 250),
        label = "compass_smooth"
    )

    val currentDirectionInfo = remember(smoothDegree.roundToInt()) {
        getVastuDirectionInfo(smoothDegree)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFAFAFA)),
                border = BorderStroke(1.dp, Color(0xFFE0E0E0)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "🧭 डिजिटल वास्तु कंपास (Live Compass)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                    Text(
                        text = "घर, ऑफिस या भूखंड की दिशा एवं वास्तु प्रभाव",
                        fontSize = 11.5.sp,
                        color = Color(0xFF555555)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Box(
                        modifier = Modifier.size(230.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CompassDialCanvas(rotationDegree = -smoothDegree)
                        CompassNeedleOverlay()
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "${smoothDegree.roundToInt()}°",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color.Black)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = currentDirectionInfo.nameHindi,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, Color(0xFFE0E0E0)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "🏠 वर्तमान दिशा का प्रभाव (${currentDirectionInfo.nameHindi}):",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                    Text(
                        text = "अधिष्ठाता देवता: ${currentDirectionInfo.rulingLord}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFFD84315)
                    )
                    Text(
                        text = "श्रेष्ठ निर्माण: ${currentDirectionInfo.suitableFor}",
                        fontSize = 12.sp,
                        color = Color(0xFF2E7D32),
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "वर्जित निर्माण: ${currentDirectionInfo.avoidFor}",
                        fontSize = 12.sp,
                        color = Color(0xFFC2185B),
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        item { Spacer(modifier = Modifier.height(20.dp)) }
    }
}

@Composable
private fun CompassDialCanvas(rotationDegree: Float) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val radius = size.width / 2f - 8.dp.toPx()

        rotate(degrees = rotationDegree, pivot = center) {
            drawCircle(color = Color(0xFFF7F7F7), radius = radius, center = center)
            drawCircle(color = Color(0xFF000000), radius = radius, center = center, style = Stroke(width = 3.dp.toPx()))
            drawCircle(color = Color(0xFFE0E0E0), radius = radius * 0.72f, center = center, style = Stroke(width = 1.dp.toPx()))

            for (i in 0 until 360 step 15) {
                val angleRad = Math.toRadians(i.toDouble() - 90.0)
                val isMajor = i % 45 == 0
                val tickLen = if (isMajor) 14.dp.toPx() else 7.dp.toPx()
                val startX = (center.x + (radius - tickLen) * Math.cos(angleRad)).toFloat()
                val startY = (center.y + (radius - tickLen) * Math.sin(angleRad)).toFloat()
                val endX = (center.x + radius * Math.cos(angleRad)).toFloat()
                val endY = (center.y + radius * Math.sin(angleRad)).toFloat()

                drawLine(
                    color = if (i == 0) Color(0xFFD32F2F) else if (isMajor) Color.Black else Color.Gray,
                    start = Offset(startX, startY),
                    end = Offset(endX, endY),
                    strokeWidth = if (isMajor) 2.5f else 1.2f
                )
            }
        }
    }
}

@Composable
private fun CompassNeedleOverlay() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val needleLength = size.width / 2f - 24.dp.toPx()
        val needleWidth = 10.dp.toPx()

        val northPath = Path().apply {
            moveTo(center.x, center.y - needleLength)
            lineTo(center.x + needleWidth, center.y)
            lineTo(center.x - needleWidth, center.y)
            close()
        }
        drawPath(path = northPath, color = Color(0xFFD32F2F))

        val southPath = Path().apply {
            moveTo(center.x, center.y + needleLength)
            lineTo(center.x + needleWidth, center.y)
            lineTo(center.x - needleWidth, center.y)
            close()
        }
        drawPath(path = southPath, color = Color(0xFF212121))

        drawCircle(color = Color.White, radius = 7.dp.toPx(), center = center)
        drawCircle(color = Color.Black, radius = 4.dp.toPx(), center = center)
    }
}

data class VastuDirectionData(
    val nameHindi: String,
    val rulingLord: String,
    val suitableFor: String,
    val avoidFor: String
)

fun getVastuDirectionInfo(degree: Float): VastuDirectionData {
    val d = (degree % 360 + 360) % 360
    return when {
        d >= 337.5 || d < 22.5 -> VastuDirectionData("उत्तर दिशा (North)", "कुबेर देव (धन)", "तिजोरी, मुख्य द्वार, बैठक, खुला स्थान", "भारी कचरा, सीढ़ियां")
        d in 22.5..<67.5 -> VastuDirectionData("ईशान कोण (North-East)", "भगवान शिव व बृहस्पति", "पूजा घर, मंदिर, ध्यान कक्ष, जल स्रोत", "शौचालय, भारी सामान, रसोई")
        d in 67.5..<112.5 -> VastuDirectionData("पूर्व दिशा (East)", "सूर्य देव व इंद्र", "मुख्य द्वार, अध्ययन कक्ष, खिड़कियां", "कचरा, भारी निर्माण")
        d in 112.5..<157.5 -> VastuDirectionData("आग्नेय कोण (South-East)", "अग्नि देव व शुक्र", "रसोईघर (Kitchen), विद्युत उपकरण", "जल स्रोत, मुख्य शयनकक्ष")
        d in 157.5..<202.5 -> VastuDirectionData("दक्षिण दिशा (South)", "यम देव व मंगल", "भारी सामान, शयनकक्ष, सीढ़ियां", "खुला गड्ढा, बोरवेल")
        d in 202.5..<247.5 -> VastuDirectionData("नैऋत्य कोण (South-West)", "राहु व पितृ देव", "मास्टर बेडरूम, तिजोरी", "मंदिर, भूमिगत जल, मुख्य द्वार")
        d in 247.5..<292.5 -> VastuDirectionData("पश्चिम दिशा (West)", "वरुण देव व शनि", "भोजन कक्ष, बच्चों का कमरा, टैंक", "पूजा घर")
        else -> VastuDirectionData("वायव्य कोण (North-West)", "वायु देव व चंद्र", "अतिथि कक्ष, वाहन, भंडार गृह", "मास्टर बेडरूम")
    }
}

@Composable
fun JapaMalaCounterTool() {
    val context = LocalContext.current
    var currentBead by remember { mutableIntStateOf(0) }
    var completedMalas by remember { mutableIntStateOf(0) }
    var isVibrateEnabled by remember { mutableStateOf(true) }
    var isSoundEnabled by remember { mutableStateOf(true) }

    val mantras = listOf(
        "गायत्री मंत्र" to "ॐ भूर्भुवः स्वः तत्सवितुर्वरेण्यं भर्गो देवस्य धीमहि धियो यो नः प्रचोदयात्॥",
        "महामृत्युंजय मंत्र" to "ॐ त्र्यम्बकं यजामहे सुगन्धिं पुष्टिवर्धनम्। उर्वारुकमिव बन्धनान् मृत्योर्मुक्षीय मामृतात्॥",
        "ॐ नमः शिवाय" to "ॐ नमः शिवाय॥",
        "हरे कृष्ण" to "हरे कृष्ण हरे कृष्ण कृष्ण कृष्ण हरे हरे। हरे राम हरे राम राम राम हरे हरे॥"
    )
    var selectedMantraIndex by remember { mutableIntStateOf(0) }

    fun triggerVibration(isFullMala: Boolean) {
        if (!isVibrateEnabled) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                val vibrator = vibratorManager.defaultVibrator
                if (isFullMala) {
                    vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 150, 100, 250), -1))
                } else {
                    vibrator.vibrate(VibrationEffect.createOneShot(35, VibrationEffect.DEFAULT_AMPLITUDE))
                }
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (isFullMala) vibrator.vibrate(300) else vibrator.vibrate(35)
            }
        } catch (_: Exception) {}
    }

    fun incrementBead() {
        if (currentBead >= 107) {
            currentBead = 0
            completedMalas++
            triggerVibration(isFullMala = true)
        } else {
            currentBead++
            triggerVibration(isFullMala = false)
        }
        if (isSoundEnabled) {
            try {
                ToneGenerator(AudioManager.STREAM_MUSIC, 60).startTone(ToneGenerator.TONE_PROP_BEEP, 50)
            } catch (_: Exception) {}
        }
    }

    LazyColumn(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF8E1)),
                border = BorderStroke(1.dp, Color(0xFFFFD54F)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(text = "📿 पावन जाप मंत्र:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Color(0xFFD84315))
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(mantras.indices.toList()) { index ->
                            FilterChip(
                                selected = selectedMantraIndex == index,
                                onClick = { selectedMantraIndex = index },
                                label = { Text(mantras[index].first, fontSize = 11.sp) }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = mantras[selectedMantraIndex].second, fontWeight = FontWeight.Bold, fontSize = 12.5.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                }
            }
        }

        item {
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, Color(0xFFE0E0E0))) {
                Column(modifier = Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "पूर्ण माला: $completedMalas माला", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Row {
                            IconButton(onClick = { isVibrateEnabled = !isVibrateEnabled }) {
                                Icon(imageVector = Icons.Default.Vibration, contentDescription = "Vibrate", tint = if (isVibrateEnabled) Color.Black else Color.LightGray)
                            }
                            IconButton(onClick = { isSoundEnabled = !isSoundEnabled }) {
                                Icon(imageVector = Icons.Default.VolumeUp, contentDescription = "Sound", tint = if (isSoundEnabled) Color.Black else Color.LightGray)
                            }
                            IconButton(onClick = { currentBead = 0; completedMalas = 0 }) {
                                Icon(imageVector = Icons.Default.Refresh, contentDescription = "Reset")
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Box(
                        modifier = Modifier
                            .size(190.dp)
                            .clip(CircleShape)
                            .background(Brush.radialGradient(listOf(Color(0xFF2C2C2C), Color(0xFF000000))))
                            .clickable { incrementBead() },
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "$currentBead", fontSize = 52.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                            Text(text = "/ 108 मनके", fontSize = 13.sp, color = Color(0xFFFFD54F), fontWeight = FontWeight.Bold)
                            Text(text = "👆 स्पर्श करें (Tap)", fontSize = 10.5.sp, color = Color.LightGray)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = "कुल जाप: ${(completedMalas * 108) + currentBead} बार", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun HoraChakraTool(currentPanchang: DailyPanchang) {
    val dayOfWeek = currentPanchang.dayOfWeek
    val horaSequence = listOf("सूर्य", "शुक्र", "बुध", "चंद्र", "शनि", "बृहस्पति (गुरु)", "मंगल")

    val dayLordIndex = when {
        dayOfWeek.contains("रवि") -> 0
        dayOfWeek.contains("सोम") -> 3
        dayOfWeek.contains("मंगल") -> 6
        dayOfWeek.contains("बुध") -> 2
        dayOfWeek.contains("गुरु") || dayOfWeek.contains("बृहस्पति") -> 5
        dayOfWeek.contains("शुक्र") -> 1
        else -> 4
    }

    val dayHoras = remember(dayLordIndex) {
        (0 until 12).map { i ->
            val pIndex = (dayLordIndex + i) % 7
            val startH = 6 + i
            val timeStr = String.format(Locale.US, "%02d:00 से %02d:00", startH, startH + 1)
            Triple(timeStr, horaSequence[pIndex], "शुभ मांगलिक कार्य")
        }
    }

    LazyColumn(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text(text = "⭐ आज का दिन होरा चक्र (${currentPanchang.dayOfWeek}):", fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        items(dayHoras) { (time, planet, work) ->
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFFFAFAFA)), border = BorderStroke(1.dp, Color(0xFFE8E8E8)), shape = RoundedCornerShape(8.dp)) {
                Row(modifier = Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text(text = "$time: $planet होरा", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text(text = "फल: $work", fontSize = 10.5.sp, color = Color.Gray)
                    }
                    Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(Color.Black).padding(horizontal = 6.dp, vertical = 2.dp)) {
                        Text(text = "शुभ", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GunMilanTool() {
    val rashis = listOf("मेष (Aries)", "वृषभ (Taurus)", "मिथुन (Gemini)", "कर्क (Cancer)", "सिंह (Leo)", "कन्या (Virgo)", "तुला (Libra)", "वृश्चिक (Scorpio)", "धनु (Sagittarius)", "मकर (Capricorn)", "कुंभ (Aquarius)", "मीन (Pisces)")
    var boyRashiIndex by remember { mutableIntStateOf(0) }
    var girlRashiIndex by remember { mutableIntStateOf(4) }

    val score = remember(boyRashiIndex, girlRashiIndex) {
        if (boyRashiIndex == girlRashiIndex) 32 else (18 + ((boyRashiIndex * 3 + girlRashiIndex * 5) % 15))
    }

    LazyColumn(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White), border = BorderStroke(1.dp, Color(0xFFE0E0E0)), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(text = "💑 36 गुण मिलान (Kundali Matching)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                    Text(text = "वर की राशि चुनें:", fontSize = 11.5.sp, color = Color(0xFF1565C0), fontWeight = FontWeight.Bold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        items(rashis.indices.toList()) { i ->
                            FilterChip(selected = boyRashiIndex == i, onClick = { boyRashiIndex = i }, label = { Text(rashis[i].take(4), fontSize = 10.sp) })
                        }
                    }
                    Text(text = "कन्या की राशि चुनें:", fontSize = 11.5.sp, color = Color(0xFFC2185B), fontWeight = FontWeight.Bold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        items(rashis.indices.toList()) { i ->
                            FilterChip(selected = girlRashiIndex == i, onClick = { girlRashiIndex = i }, label = { Text(rashis[i].take(4), fontSize = 10.sp) })
                        }
                    }
                }
            }
        }

        item {
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)), shape = RoundedCornerShape(12.dp)) {
                Column(modifier = Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "कुल गुण मिलान स्कोर", fontSize = 12.sp, color = Color(0xFF2E7D32))
                    Text(text = "$score / 36", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF1B5E20))
                    Text(text = if (score >= 28) "उत्कृष्ट मिलान (विवाह हेतु अति शुभ)" else if (score >= 18) "मध्यम मिलान (विवाह योग्य)" else "विचारणीय मिलान", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1B5E20))
                }
            }
        }
    }
}

@Composable
fun DishaShoolTool(currentPanchang: DailyPanchang) {
    val dayOfWeek = currentPanchang.dayOfWeek
    val (dir, remedy) = when {
        dayOfWeek.contains("रवि") -> "पश्चिम (West)" to "पान या घी खाकर निकलें"
        dayOfWeek.contains("सोम") -> "पूर्व (East)" to "दर्पण (शीशा) देखकर प्रस्थान करें"
        dayOfWeek.contains("मंगल") -> "उत्तर (North)" to "गुड़ या धनिया खाकर निकलें"
        dayOfWeek.contains("बुध") -> "उत्तर (North)" to "तिल या धनिया खाकर निकलें"
        dayOfWeek.contains("गुरु") -> "दक्षिण (South)" to "दही या पीली सरसों खाकर निकलें"
        dayOfWeek.contains("शुक्र") -> "पश्चिम (West)" to "जौ या मीठा दूध पीकर निकलें"
        else -> "पूर्व (East)" to "अदरक या काली उड़द खाकर निकलें"
    }

    LazyColumn(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)), border = BorderStroke(1.dp, Color(0xFFD32F2F)), shape = RoundedCornerShape(14.dp)) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(text = "⚠️ आज का दिशा शूल: $dir", fontWeight = FontWeight.Bold, color = Color(0xFFD32F2F), fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = "आज $dir में यात्रा करना वर्जित माना गया है।", fontSize = 12.sp, color = Color.Black)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "✅ परिहार (Remedy): $remedy", fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32), fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun HinduAgeCalculatorTool(currentPanchang: DailyPanchang) {
    var birthYear by remember { mutableIntStateOf(1995) }
    val years = (1950..2026).toList()

    LazyColumn(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, Color(0xFFE0E0E0))) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(text = "🎂 जन्म वर्ष चुनें:", fontWeight = FontWeight.Bold, fontSize = 12.5.sp)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(years) { y ->
                            FilterChip(selected = birthYear == y, onClick = { birthYear = y }, label = { Text("$y", fontSize = 11.sp) })
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    val age = 2026 - birthYear
                    Text(text = "कुल आयु: $age वर्ष", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Color.Black)
                }
            }
        }
    }
}
