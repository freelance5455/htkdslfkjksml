package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.example.R
import com.example.data.SecurityPreferences
import com.example.data.SecuritySettingsSnapshot
import com.example.security.PermissionStatusChecker
import com.example.security.SystemPermissionsState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

sealed interface PinScreenMode {
    data object SetupEnter : PinScreenMode
    data class SetupConfirm(val firstPin: String) : PinScreenMode
    data object Unlock : PinScreenMode
    data object ChangeCurrent : PinScreenMode
    data object ChangeNew : PinScreenMode
    data class ChangeConfirm(val newPin: String) : PinScreenMode
    data object Dashboard : PinScreenMode
}

data class MainUiState(
    val mode: PinScreenMode = PinScreenMode.SetupEnter,
    val enteredDigits: String = "",
    val errorMessage: String? = null,
    val permissions: SystemPermissionsState = SystemPermissionsState(),
    val settings: SecuritySettingsSnapshot = SecuritySettingsSnapshot(),
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = SecurityPreferences.getInstance(application)
    private var awaitingSystemPermissionReturn = false

    private val _uiState = MutableStateFlow(
        MainUiState(
            mode = if (prefs.hasPin()) PinScreenMode.Unlock else PinScreenMode.SetupEnter,
            permissions = PermissionStatusChecker.getPermissionsState(application),
            settings = prefs.settingsFlow.value,
        ),
    )
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    fun refreshState() {
        val context = getApplication<Application>()
        _uiState.update { state ->
            state.copy(
                permissions = PermissionStatusChecker.getPermissionsState(context),
                settings = prefs.settingsFlow.value,
            )
        }
        awaitingSystemPermissionReturn = false
    }

    fun markAwaitingSystemPermissionReturn() {
        awaitingSystemPermissionReturn = true
    }

    fun onAppBackgrounded() {
        if (awaitingSystemPermissionReturn) return
        if (prefs.hasPin() && _uiState.value.mode == PinScreenMode.Dashboard) {
            _uiState.update {
                it.copy(
                    mode = PinScreenMode.Unlock,
                    enteredDigits = "",
                    errorMessage = null,
                )
            }
        }
    }

    fun onDigitPressed(digit: Char) {
        if (!digit.isDigit()) return
        val current = _uiState.value
        if (current.enteredDigits.length >= 6) return

        val updatedDigits = current.enteredDigits + digit
        _uiState.update { it.copy(enteredDigits = updatedDigits, errorMessage = null) }

        if (updatedDigits.length == 6) {
            processCompletePin(updatedDigits, current.mode)
        }
    }

    fun onBackspace() {
        _uiState.update { state ->
            if (state.enteredDigits.isEmpty()) state
            else state.copy(
                enteredDigits = state.enteredDigits.dropLast(1),
                errorMessage = null,
            )
        }
    }

    fun onClearDigits() {
        _uiState.update { it.copy(enteredDigits = "", errorMessage = null) }
    }

    fun startChangePin() {
        _uiState.update {
            it.copy(
                mode = PinScreenMode.ChangeCurrent,
                enteredDigits = "",
                errorMessage = null,
            )
        }
    }

    fun cancelChangePin() {
        _uiState.update {
            it.copy(
                mode = PinScreenMode.Dashboard,
                enteredDigits = "",
                errorMessage = null,
            )
        }
    }

    fun lockDashboard() {
        if (prefs.hasPin()) {
            prefs.clearTemporaryAccess()
            _uiState.update {
                it.copy(
                    mode = PinScreenMode.Unlock,
                    enteredDigits = "",
                    errorMessage = null,
                )
            }
        }
    }

    fun setMasterProtection(enabled: Boolean) {
        prefs.setMasterProtectionEnabled(enabled)
        refreshState()
    }

    fun setPowerRule(enabled: Boolean) {
        prefs.setProtectPowerAndReboot(enabled)
        refreshState()
    }

    fun setAdminRule(enabled: Boolean) {
        prefs.setProtectAccessibilityAndAdmin(enabled)
        refreshState()
    }

    fun setDesktopRule(enabled: Boolean) {
        prefs.setProtectDesktopSettings(enabled)
        refreshState()
    }

    private fun processCompletePin(pin: String, mode: PinScreenMode) {
        val context = getApplication<Application>()
        when (mode) {
            PinScreenMode.SetupEnter -> {
                _uiState.update {
                    it.copy(
                        mode = PinScreenMode.SetupConfirm(pin),
                        enteredDigits = "",
                        errorMessage = null,
                    )
                }
            }

            is PinScreenMode.SetupConfirm -> {
                if (pin == mode.firstPin) {
                    prefs.savePin(pin)
                    _uiState.update {
                        it.copy(
                            mode = PinScreenMode.Dashboard,
                            enteredDigits = "",
                            errorMessage = null,
                            settings = prefs.settingsFlow.value,
                            permissions = PermissionStatusChecker.getPermissionsState(context),
                        )
                    }
                } else {
                    _uiState.update {
                        it.copy(
                            mode = PinScreenMode.SetupEnter,
                            enteredDigits = "",
                            errorMessage = context.getString(R.string.pin_mismatch_error),
                        )
                    }
                }
            }

            PinScreenMode.Unlock -> {
                if (prefs.verifyPin(pin)) {
                    _uiState.update {
                        it.copy(
                            mode = PinScreenMode.Dashboard,
                            enteredDigits = "",
                            errorMessage = null,
                            settings = prefs.settingsFlow.value,
                            permissions = PermissionStatusChecker.getPermissionsState(context),
                        )
                    }
                } else {
                    _uiState.update {
                        it.copy(
                            enteredDigits = "",
                            errorMessage = context.getString(R.string.pin_incorrect_error),
                        )
                    }
                }
            }

            PinScreenMode.ChangeCurrent -> {
                if (prefs.verifyPin(pin)) {
                    _uiState.update {
                        it.copy(
                            mode = PinScreenMode.ChangeNew,
                            enteredDigits = "",
                            errorMessage = null,
                        )
                    }
                } else {
                    _uiState.update {
                        it.copy(
                            enteredDigits = "",
                            errorMessage = context.getString(R.string.pin_incorrect_error),
                        )
                    }
                }
            }

            PinScreenMode.ChangeNew -> {
                _uiState.update {
                    it.copy(
                        mode = PinScreenMode.ChangeConfirm(pin),
                        enteredDigits = "",
                        errorMessage = null,
                    )
                }
            }

            is PinScreenMode.ChangeConfirm -> {
                if (pin == mode.newPin) {
                    prefs.savePin(pin)
                    _uiState.update {
                        it.copy(
                            mode = PinScreenMode.Dashboard,
                            enteredDigits = "",
                            errorMessage = null,
                            settings = prefs.settingsFlow.value,
                        )
                    }
                } else {
                    _uiState.update {
                        it.copy(
                            mode = PinScreenMode.ChangeNew,
                            enteredDigits = "",
                            errorMessage = context.getString(R.string.pin_mismatch_error),
                        )
                    }
                }
            }

            PinScreenMode.Dashboard -> Unit
        }
    }
}
