package com.example.ui

import android.app.Application
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import android.text.TextUtils
import androidx.lifecycle.AndroidViewModel
import com.example.data.InterceptionLog
import com.example.data.SecurityPreferences
import com.example.receiver.AntiTheftAdminReceiver
import com.example.service.AntiTheftAccessibilityService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class AppGateState {
    FIRST_TIME_CREATE_PIN,
    FIRST_TIME_CONFIRM_PIN,
    APP_LOCKED_ENTER_PIN,
    UNLOCKED_MAIN_DASHBOARD,
    CHANGE_PIN_OLD,
    CHANGE_PIN_NEW,
    CHANGE_PIN_CONFIRM
}

data class MainUiState(
    val gateState: AppGateState = AppGateState.APP_LOCKED_ENTER_PIN,
    val isAccessibilityEnabled: Boolean = false,
    val isDeviceAdminEnabled: Boolean = false,
    val isOverlayPermissionGranted: Boolean = false,
    val isBatteryOptimizationIgnored: Boolean = false,
    val isPowerProtected: Boolean = true,
    val isMemoryProtected: Boolean = true,
    val isAdminAndAccessibilityProtected: Boolean = true,
    val isDesktopProtected: Boolean = true,
    val interceptionLogs: List<InterceptionLog> = emptyList(),
    val errorMessage: String? = null,
    val statusMessage: String? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = SecurityPreferences.getInstance(application)
    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    private var tempNewPin: String = ""

    init {
        checkInitialGate()
        refreshStatus()
    }

    fun checkInitialGate() {
        if (!prefs.isPinSet) {
            _uiState.value = _uiState.value.copy(gateState = AppGateState.FIRST_TIME_CREATE_PIN)
        } else {
            _uiState.value = _uiState.value.copy(gateState = AppGateState.APP_LOCKED_ENTER_PIN)
        }
    }

    fun refreshStatus() {
        val context = getApplication<Application>()
        _uiState.value = _uiState.value.copy(
            isAccessibilityEnabled = checkAccessibilityEnabled(context),
            isDeviceAdminEnabled = checkDeviceAdminEnabled(context),
            isOverlayPermissionGranted = Settings.canDrawOverlays(context),
            isBatteryOptimizationIgnored = checkBatteryIgnored(context),
            isPowerProtected = prefs.isPowerProtected,
            isMemoryProtected = prefs.isMemoryProtected,
            isAdminAndAccessibilityProtected = prefs.isAdminAndAccessibilityProtected,
            isDesktopProtected = prefs.isDesktopProtected,
            interceptionLogs = prefs.getInterceptionLogs()
        )
    }

    // PIN Gate Handlers
    fun onFirstTimeCreatePin(pin: String) {
        if (pin.length == 6) {
            tempNewPin = pin
            _uiState.value = _uiState.value.copy(
                gateState = AppGateState.FIRST_TIME_CONFIRM_PIN,
                errorMessage = null
            )
        }
    }

    fun onFirstTimeConfirmPin(pin: String) {
        if (pin == tempNewPin) {
            prefs.setPin(pin)
            tempNewPin = ""
            _uiState.value = _uiState.value.copy(
                gateState = AppGateState.UNLOCKED_MAIN_DASHBOARD,
                errorMessage = null,
                statusMessage = "¡PIN de 6 dígitos establecido correctamente!"
            )
            refreshStatus()
        } else {
            _uiState.value = _uiState.value.copy(
                errorMessage = "Los PIN no coinciden. Intenta de nuevo."
            )
        }
    }

    fun onUnlockPinEntered(pin: String) {
        if (prefs.verifyPin(pin)) {
            _uiState.value = _uiState.value.copy(
                gateState = AppGateState.UNLOCKED_MAIN_DASHBOARD,
                errorMessage = null
            )
            refreshStatus()
        } else {
            _uiState.value = _uiState.value.copy(
                errorMessage = "PIN incorrecto. Reintenta."
            )
        }
    }

    fun startChangePin() {
        _uiState.value = _uiState.value.copy(
            gateState = AppGateState.CHANGE_PIN_OLD,
            errorMessage = null
        )
    }

    fun onChangePinOldEntered(pin: String) {
        if (prefs.verifyPin(pin)) {
            _uiState.value = _uiState.value.copy(
                gateState = AppGateState.CHANGE_PIN_NEW,
                errorMessage = null
            )
        } else {
            _uiState.value = _uiState.value.copy(
                errorMessage = "PIN actual incorrecto"
            )
        }
    }

    fun onChangePinNewEntered(pin: String) {
        tempNewPin = pin
        _uiState.value = _uiState.value.copy(
            gateState = AppGateState.CHANGE_PIN_CONFIRM,
            errorMessage = null
        )
    }

    fun onChangePinConfirmEntered(pin: String) {
        if (pin == tempNewPin) {
            prefs.setPin(pin)
            tempNewPin = ""
            _uiState.value = _uiState.value.copy(
                gateState = AppGateState.UNLOCKED_MAIN_DASHBOARD,
                errorMessage = null,
                statusMessage = "PIN modificado exitosamente."
            )
        } else {
            _uiState.value = _uiState.value.copy(
                errorMessage = "Los nuevos PIN no coinciden"
            )
        }
    }

    fun cancelChangePin() {
        tempNewPin = ""
        _uiState.value = _uiState.value.copy(
            gateState = AppGateState.UNLOCKED_MAIN_DASHBOARD,
            errorMessage = null
        )
    }

    // Protection Toggles
    fun togglePowerProtection(enabled: Boolean) {
        prefs.isPowerProtected = enabled
        _uiState.value = _uiState.value.copy(isPowerProtected = enabled)
    }

    fun toggleMemoryProtection(enabled: Boolean) {
        prefs.isMemoryProtected = enabled
        _uiState.value = _uiState.value.copy(isMemoryProtected = enabled)
    }

    fun toggleAdminAccessibilityProtection(enabled: Boolean) {
        prefs.isAdminAndAccessibilityProtected = enabled
        _uiState.value = _uiState.value.copy(isAdminAndAccessibilityProtected = enabled)
    }

    fun toggleDesktopProtection(enabled: Boolean) {
        prefs.isDesktopProtected = enabled
        _uiState.value = _uiState.value.copy(isDesktopProtected = enabled)
    }

    fun clearLogs() {
        prefs.clearLogs()
        _uiState.value = _uiState.value.copy(interceptionLogs = emptyList())
    }

    fun clearStatusMessage() {
        _uiState.value = _uiState.value.copy(statusMessage = null)
    }

    fun clearErrorMessage() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }

    // Permission Navigation helpers (grant setup access window so TecnoGuard doesn't self-intercept)
    fun preparePermissionNavigation() {
        prefs.grantSetupNavigationAccess(45)
    }

    fun getDeviceAdminIntent(): Intent {
        val component = ComponentName(getApplication(), AntiTheftAdminReceiver::class.java)
        return Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, component)
            putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Activa la protección de administrador para evitar que un ladrón desinstale TecnoGuard."
            )
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    fun getAccessibilitySettingsIntent(): Intent {
        return Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    fun getOverlayPermissionIntent(): Intent {
        val context = getApplication<Application>()
        return Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        ).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    fun getBatteryOptimizationIntent(): Intent {
        val context = getApplication<Application>()
        return Intent(
            Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
            Uri.parse("package:${context.packageName}")
        ).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }

    // Helper checkers
    private fun checkAccessibilityEnabled(context: Context): Boolean {
        if (AntiTheftAccessibilityService.isServiceRunning) return true
        val expectedServiceName = "${context.packageName}/${AntiTheftAccessibilityService::class.java.canonicalName}"
        val settingValue = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(settingValue)
        while (splitter.hasNext()) {
            val service = splitter.next()
            if (service.equals(expectedServiceName, ignoreCase = true) ||
                service.contains(AntiTheftAccessibilityService::class.java.simpleName)
            ) {
                return true
            }
        }
        return false
    }

    private fun checkDeviceAdminEnabled(context: Context): Boolean {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as? DevicePolicyManager
        val component = ComponentName(context, AntiTheftAdminReceiver::class.java)
        return dpm?.isAdminActive(component) == true
    }

    private fun checkBatteryIgnored(context: Context): Boolean {
        val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        return pm?.isIgnoringBatteryOptimizations(context.packageName) ?: false
    }
}
