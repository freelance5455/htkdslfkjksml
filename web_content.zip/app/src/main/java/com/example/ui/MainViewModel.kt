package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AppConfig
import com.example.data.model.BedrockPlayer
import com.example.data.model.ServerStatus
import com.example.data.model.VoiceChannel
import com.example.data.model.VoiceUser
import com.example.data.repository.ServerRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class MainUiState(
    val config: AppConfig = AppConfig(),
    val serverStatus: ServerStatus = ServerStatus(),
    val isLoading: Boolean = false,
    val isActionLoading: Boolean = false,
    val feedbackMessage: String? = null,
    val selectedTab: Int = 0, // 0: Estado, 1: Canales Voz, 2: Bedrock Bridge, 3: Archivos
    val currentVoiceChannelId: String? = null,
    val isMuted: Boolean = false,
    val isSpeaking: Boolean = false,
    val voiceChannels: List<VoiceChannel> = listOf(
        VoiceChannel("general", "General / Spawn", "🏰"),
        VoiceChannel("afk", "AFK / Ausente", "💤"),
        VoiceChannel("cueva", "Cueva & Minería", "⛏️"),
        VoiceChannel("base", "Base Principal", "🛡️"),
        VoiceChannel("nether", "Expedición Nether", "🔥")
    ),
    val voiceUsers: List<VoiceUser> = emptyList(),
    val bedrockPlayers: List<BedrockPlayer> = emptyList(),
    val consoleLogs: List<String> = listOf("--- Consola iniciada para CHAUFALAND ---"),
    val showGamerTagDialog: Boolean = false,
    val showAdminDialog: Boolean = false,
    val isAdminAuthenticated: Boolean = false
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ServerRepository(application)
    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    init {
        loadInitialData()
        startPeriodicRefresh()
    }

    private fun loadInitialData() {
        val config = repository.getConfig()
        val needsGamerTag = config.gamerTag.isBlank()
        _uiState.update {
            it.copy(
                config = config,
                showGamerTagDialog = needsGamerTag
            )
        }
        refreshServerStatus()
    }

    fun selectTab(index: Int) {
        _uiState.update { it.copy(selectedTab = index) }
    }

    fun dismissFeedback() {
        _uiState.update { it.copy(feedbackMessage = null) }
    }

    fun setGamerTag(gamerTag: String) {
        if (gamerTag.isBlank()) return
        val updated = _uiState.value.config.copy(gamerTag = gamerTag.trim())
        repository.saveConfig(updated)
        _uiState.update {
            it.copy(
                config = updated,
                showGamerTagDialog = false,
                feedbackMessage = "¡Bienvenido a CHAUFALAND, ${gamerTag.trim()}!"
            )
        }
        refreshServerStatus()
    }

    fun promptChangeGamerTag() {
        _uiState.update { it.copy(showGamerTagDialog = true) }
    }

    fun openAdminModal() {
        _uiState.update { it.copy(showAdminDialog = true) }
    }

    fun closeAdminModal() {
        _uiState.update { it.copy(showAdminDialog = false) }
    }

    fun verifyAdminPassword(password: String): Boolean {
        if (password == "JuancitoChen23") {
            _uiState.update { it.copy(isAdminAuthenticated = true) }
            return true
        }
        return false
    }

    fun saveAdminConfig(updated: AppConfig) {
        repository.saveConfig(updated)
        _uiState.update {
            it.copy(
                config = updated,
                showAdminDialog = false,
                feedbackMessage = "Configuración de CHAUFALAND guardada correctamente."
            )
        }
        refreshServerStatus()
    }

    fun refreshServerStatus() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val currentConfig = _uiState.value.config
            val result = repository.fetchStatus(currentConfig)
            result.onSuccess { status ->
                _uiState.update { state ->
                    state.copy(
                        serverStatus = status,
                        isLoading = false
                    )
                }
            }.onFailure { err ->
                _uiState.update { state ->
                    state.copy(
                        isLoading = false,
                        feedbackMessage = "Aviso de conexión: ${err.message}"
                    )
                }
            }
        }
    }

    private fun startPeriodicRefresh() {
        viewModelScope.launch {
            while (true) {
                delay(12000)
                val currentConfig = _uiState.value.config
                val result = repository.fetchStatus(currentConfig)
                result.onSuccess { status ->
                    _uiState.update { it.copy(serverStatus = status) }
                }
            }
        }
    }

    /* Acciones de Servidor (Exaroton) */
    fun executeServerAction(action: String) {
        val config = _uiState.value.config
        if (config.exarotonApiToken.isBlank() || config.exarotonServerId.isBlank()) {
            _uiState.update {
                it.copy(feedbackMessage = "Configura el API Token y Server ID de Exaroton en el Panel Admin.")
            }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isActionLoading = true) }
            val res = repository.executeExarotonAction(config.exarotonApiToken, config.exarotonServerId, action)
            res.onSuccess { msg ->
                _uiState.update {
                    it.copy(
                        isActionLoading = false,
                        feedbackMessage = "Acción '$action' enviada a Exaroton.",
                        consoleLogs = it.consoleLogs + "[Exaroton] Acción solicitada: $action"
                    )
                }
                delay(2000)
                refreshServerStatus()
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isActionLoading = false,
                        feedbackMessage = "Error en Exaroton: ${err.message}"
                    )
                }
            }
        }
    }

    fun sendConsoleCommand(cmd: String) {
        if (cmd.isBlank()) return
        val config = _uiState.value.config
        if (config.exarotonApiToken.isBlank() || config.exarotonServerId.isBlank()) {
            _uiState.update {
                it.copy(
                    feedbackMessage = "Configura Exaroton en el panel admin para enviar comandos.",
                    consoleLogs = it.consoleLogs + "> $cmd" + "[Error] Sin credenciales de Exaroton."
                )
            }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(consoleLogs = it.consoleLogs + "> $cmd") }
            val res = repository.sendExarotonCommand(config.exarotonApiToken, config.exarotonServerId, cmd)
            res.onSuccess {
                _uiState.update {
                    it.copy(consoleLogs = it.consoleLogs + "[OK] Comando ejecutado.")
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(consoleLogs = it.consoleLogs + "[Error] ${err.message}")
                }
            }
        }
    }

    /* Módulo Chat de Voz WebRTC */
    fun joinVoiceChannel(channelId: String) {
        val myTag = _uiState.value.config.gamerTag
        if (myTag.isBlank()) {
            promptChangeGamerTag()
            return
        }

        val myUser = VoiceUser(
            gamerTag = myTag,
            channelId = channelId,
            isMuted = _uiState.value.isMuted,
            isSpeaking = false
        )

        _uiState.update { state ->
            val remaining = state.voiceUsers.filter { it.gamerTag != myTag }
            state.copy(
                currentVoiceChannelId = channelId,
                voiceUsers = remaining + myUser,
                feedbackMessage = "Conectado a canal de voz."
            )
        }
    }

    fun leaveVoiceChannel() {
        val myTag = _uiState.value.config.gamerTag
        _uiState.update { state ->
            state.copy(
                currentVoiceChannelId = null,
                voiceUsers = state.voiceUsers.filter { it.gamerTag != myTag },
                isSpeaking = false,
                feedbackMessage = "Llamada desconectada."
            )
        }
    }

    fun toggleMute() {
        _uiState.update { state ->
            val newMute = !state.isMuted
            val myTag = state.config.gamerTag
            val updatedUsers = state.voiceUsers.map { user ->
                if (user.gamerTag == myTag) user.copy(isMuted = newMute, isSpeaking = if (newMute) false else user.isSpeaking) else user
            }
            state.copy(
                isMuted = newMute,
                isSpeaking = if (newMute) false else state.isSpeaking,
                voiceUsers = updatedUsers
            )
        }
    }
}
