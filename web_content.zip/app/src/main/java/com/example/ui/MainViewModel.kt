package com.example.ui

import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.NexusDatabase
import com.example.data.model.AiEngineType
import com.example.data.model.AppSettings
import com.example.data.model.AssistantPersona
import com.example.data.model.ChatMessage
import com.example.data.model.ConversationSession
import com.example.data.model.GeminiModelOption
import com.example.data.model.MessageRole
import com.example.data.model.VoicePreset
import com.example.data.repository.ChatRepository
import com.example.data.repository.SettingsRepository
import com.example.engine.AiEngineCoordinator
import com.example.speech.SpeechRecognizerManager
import com.example.speech.TextToSpeechManager
import com.example.ui.components.OrbState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = NexusDatabase.getInstance(application)
    val chatRepository = ChatRepository(db.chatDao())
    val settingsRepository = SettingsRepository(application)
    val engineCoordinator = AiEngineCoordinator(application)
    val speechManager = SpeechRecognizerManager(application)
    val ttsManager = TextToSpeechManager(application)

    private val connectivityManager =
        application.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager

    private val _isOnline = MutableStateFlow(checkCurrentNetwork())
    val isOnline: StateFlow<Boolean> = _isOnline.asStateFlow()

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            _isOnline.value = true
            engineCoordinator.refreshNetworkStatus()
        }

        override fun onLost(network: Network) {
            _isOnline.value = checkCurrentNetwork()
            engineCoordinator.refreshNetworkStatus()
        }

        override fun onCapabilitiesChanged(network: Network, capabilities: NetworkCapabilities) {
            _isOnline.value = capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            engineCoordinator.refreshNetworkStatus()
        }
    }

    val settings: StateFlow<AppSettings> = settingsRepository.settings

    val allSessions: StateFlow<List<ConversationSession>> = chatRepository.allSessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentSessionId = MutableStateFlow<Long?>(null)
    val currentSessionId: StateFlow<Long?> = _currentSessionId.asStateFlow()

    val currentMessages: StateFlow<List<ChatMessage>> = _currentSessionId.flatMapLatest { sessionId ->
        if (sessionId != null) {
            chatRepository.getMessagesForSession(sessionId)
        } else {
            MutableStateFlow(emptyList())
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _streamingResponse = MutableStateFlow("")
    val streamingResponse: StateFlow<String> = _streamingResponse.asStateFlow()

    private val _lastVoiceResponse = MutableStateFlow("")
    val lastVoiceResponse: StateFlow<String> = _lastVoiceResponse.asStateFlow()

    private val _statusText = MutableStateFlow("Готов к диалогу")
    val statusText: StateFlow<String> = _statusText.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private var lastPrompt: String? = null
    private var currentInferenceJob: Job? = null

    val orbState: StateFlow<OrbState> = combine(
        speechManager.isListening,
        _isGenerating,
        ttsManager.isSpeaking
    ) { listening, generating, speaking ->
        when {
            listening -> OrbState.LISTENING
            generating -> OrbState.THINKING
            speaking -> OrbState.SPEAKING
            else -> OrbState.IDLE
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), OrbState.IDLE)

    init {
        try {
            connectivityManager?.registerDefaultNetworkCallback(networkCallback)
        } catch (_: Exception) {
        }

        viewModelScope.launch {
            val count = chatRepository.getTotalMessageCount()
            if (count == 0) {
                val newId = chatRepository.createNewSession("Первый диалог с NEXUS")
                _currentSessionId.value = newId

                val welcome = ChatMessage(
                    sessionId = newId,
                    role = MessageRole.ASSISTANT,
                    content = "Приветствую! Я — NEXUS AI, объединённый интеллектуальный ассистент с подключением к интернету. Я объединяю аналитику, программирование, науку, творческий синтез и собственный стиль NEXUS. Помню весь контекст нашей беседы и готов общаться голосом или текстом на русском языке. Чем могу помочь?",
                    engineUsed = "NEXUS Omni-AI (Gemini 3.8 Flash)",
                    latencyMs = 15,
                    tokensCount = 46
                )
                chatRepository.saveMessage(welcome)
                _lastVoiceResponse.value = welcome.content
            } else {
                val latestSessionId = chatRepository.getOrCreateLatestSession()
                _currentSessionId.value = latestSessionId
                val existingMessages = chatRepository.getMessagesList(latestSessionId)
                val lastAssistant = existingMessages.lastOrNull { it.role == MessageRole.ASSISTANT }
                if (lastAssistant != null) {
                    _lastVoiceResponse.value = lastAssistant.content
                }
            }
        }
    }

    private fun checkCurrentNetwork(): Boolean {
        val cm = connectivityManager ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    fun selectSession(sessionId: Long) {
        _currentSessionId.value = sessionId
        _errorMessage.value = null
    }

    fun startNewChat() {
        stopGeneration()
        viewModelScope.launch {
            val count = (allSessions.value.size) + 1
            val newId = chatRepository.createNewSession("Диалог #$count")
            _currentSessionId.value = newId
            _streamingResponse.value = ""
            _errorMessage.value = null
            ttsManager.stop()
        }
    }

    fun deleteSession(sessionId: Long) {
        viewModelScope.launch {
            chatRepository.deleteSession(sessionId)
            if (_currentSessionId.value == sessionId) {
                val remaining = allSessions.value.filter { it.id != sessionId }
                if (remaining.isNotEmpty()) {
                    _currentSessionId.value = remaining.first().id
                } else {
                    startNewChat()
                }
            }
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            chatRepository.deleteAllHistory()
            startNewChat()
        }
    }

    fun clearError() {
        _errorMessage.value = null
    }

    fun retryLastMessage() {
        val prompt = lastPrompt
        if (!prompt.isNullOrBlank()) {
            _errorMessage.value = null
            sendMessage(prompt)
        }
    }

    fun stopGeneration() {
        if (!_isGenerating.value) return
        val partial = _streamingResponse.value.trim()
        val sessionId = _currentSessionId.value
        currentInferenceJob?.cancel()
        currentInferenceJob = null
        _isGenerating.value = false
        _streamingResponse.value = ""
        _statusText.value = "Генерация остановлена"

        if (partial.isNotBlank() && sessionId != null) {
            viewModelScope.launch {
                val msg = ChatMessage(
                    sessionId = sessionId,
                    role = MessageRole.ASSISTANT,
                    content = "$partial\n\n*(остановлено пользователем)*",
                    engineUsed = settings.value.engineType.title,
                    latencyMs = 0,
                    tokensCount = partial.split(Regex("\\s+")).size
                )
                chatRepository.saveMessage(msg)
            }
        }
    }

    fun sendMessage(text: String, isFromVoice: Boolean = false) {
        val prompt = text.trim()
        if (prompt.isBlank() || _isGenerating.value) return

        ttsManager.stop()
        speechManager.stopListening()
        _errorMessage.value = null
        lastPrompt = prompt

        viewModelScope.launch {
            val sessionId = _currentSessionId.value ?: chatRepository.getOrCreateLatestSession().also {
                _currentSessionId.value = it
            }

            val previousHistory = chatRepository.getMessagesList(sessionId)

            val userMsg = ChatMessage(
                sessionId = sessionId,
                role = MessageRole.USER,
                content = prompt
            )
            chatRepository.saveMessage(userMsg)

            _isGenerating.value = true
            _streamingResponse.value = ""
            _statusText.value = if (settings.value.engineType.isOffline) {
                "Локальный расчёт..."
            } else {
                "Синтез ответа Omni-AI..."
            }

            val currentSettings = settings.value

            currentInferenceJob = launch {
                try {
                    val result = engineCoordinator.generate(
                        prompt = prompt,
                        history = previousHistory,
                        persona = currentSettings.persona,
                        assistantName = currentSettings.assistantName,
                        enginePreference = currentSettings.engineType,
                        modelName = currentSettings.effectiveGeminiModelId(),
                        onTokenStream = { tokenChunk ->
                            _streamingResponse.value = tokenChunk
                        }
                    )

                    val assistantMsg = ChatMessage(
                        sessionId = sessionId,
                        role = MessageRole.ASSISTANT,
                        content = result.text,
                        engineUsed = result.engineName,
                        latencyMs = result.latencyMs,
                        tokensCount = result.tokensCount
                    )
                    chatRepository.saveMessage(assistantMsg)
                    _lastVoiceResponse.value = result.text

                    if (currentSettings.autoTts || isFromVoice) {
                        _statusText.value = "Отвечаю голосом..."
                        ttsManager.speak(
                            text = result.text,
                            rate = currentSettings.voiceSpeed,
                            pitch = currentSettings.voicePitch,
                            selectedVoiceName = currentSettings.selectedVoiceName,
                            preferFemale = currentSettings.voicePreset.preferFemale
                        )
                    } else {
                        _statusText.value = "Готов к диалогу"
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    val errorDetail = e.localizedMessage ?: "Не удалось получить ответ"
                    _errorMessage.value = errorDetail
                    _statusText.value = "Ошибка генерации"

                    val errorMsg = ChatMessage(
                        sessionId = sessionId,
                        role = MessageRole.ASSISTANT,
                        content = "⚠️ $errorDetail",
                        engineUsed = "Ошибка",
                        latencyMs = 0
                    )
                    chatRepository.saveMessage(errorMsg)
                } finally {
                    _isGenerating.value = false
                    _streamingResponse.value = ""
                }
            }
        }
    }

    fun toggleVoiceListening() {
        if (speechManager.isListening.value) {
            speechManager.stopListening()
            _statusText.value = "Готов к диалогу"
        } else {
            ttsManager.stop()
            _statusText.value = "Слушаю вас..."
            speechManager.startListening { recognizedText ->
                if (recognizedText.isNotBlank()) {
                    sendMessage(recognizedText, isFromVoice = true)
                }
            }
        }
    }

    fun speakText(text: String) {
        val currentSettings = settings.value
        ttsManager.speak(
            text = text,
            rate = currentSettings.voiceSpeed,
            pitch = currentSettings.voicePitch,
            selectedVoiceName = currentSettings.selectedVoiceName,
            preferFemale = currentSettings.voicePreset.preferFemale
        )
    }

    fun stopSpeaking() {
        ttsManager.stop()
        _statusText.value = "Готов к диалогу"
    }

    fun updateAssistantName(name: String) = settingsRepository.updateAssistantName(name)
    fun updatePersona(persona: AssistantPersona) = settingsRepository.updatePersona(persona)
    fun updateEngineType(engine: AiEngineType) = settingsRepository.updateEngineType(engine)
    fun updateGeminiModel(model: GeminiModelOption) = settingsRepository.updateGeminiModel(model)
    fun updateCustomGeminiModelId(modelId: String) = settingsRepository.updateCustomGeminiModelId(modelId)
    fun updateVoicePreset(preset: VoicePreset) {
        settingsRepository.updateVoicePreset(preset)
        ttsManager.applyVoiceSelection("", preset.preferFemale)
    }
    fun updateSelectedVoiceName(voiceName: String) {
        settingsRepository.updateSelectedVoiceName(voiceName)
        ttsManager.applyVoiceSelection(voiceName, settings.value.voicePreset.preferFemale)
    }
    fun refreshDeviceVoices() = ttsManager.refreshVoices()
    fun updateVoiceSpeed(speed: Float) = settingsRepository.updateVoiceSpeed(speed)
    fun updateVoicePitch(pitch: Float) = settingsRepository.updateVoicePitch(pitch)
    fun updateAutoTts(enabled: Boolean) = settingsRepository.updateAutoTts(enabled)
    fun updateQuantization(q: String) = settingsRepository.updateQuantization(q)
    fun updateGgufPath(path: String) = settingsRepository.updateGgufPath(path)

    override fun onCleared() {
        super.onCleared()
        try {
            connectivityManager?.unregisterNetworkCallback(networkCallback)
        } catch (_: Exception) {
        }
        speechManager.stopListening()
        ttsManager.destroy()
    }
}
