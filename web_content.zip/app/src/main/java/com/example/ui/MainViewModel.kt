package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.PanchangDatabase
import com.example.data.ReminderEntity
import com.example.data.ReminderRepository
import com.example.localization.PanchangStrings
import com.example.model.AppLanguage
import com.example.model.CalendarThemeOption
import com.example.model.DailyPanchang
import com.example.notification.NotificationHelper
import com.example.panchang.VedicPanchangCalculator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ReminderRepository

    init {
        val db = PanchangDatabase.getDatabase(application)
        repository = ReminderRepository(db.reminderDao())
    }

    val reminders: StateFlow<List<ReminderEntity>> = repository.allReminders
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _selectedDate = MutableStateFlow<Calendar>(Calendar.getInstance())
    val selectedDate: StateFlow<Calendar> = _selectedDate.asStateFlow()

    private val _viewMonth = MutableStateFlow<Calendar>(Calendar.getInstance())
    val viewMonth: StateFlow<Calendar> = _viewMonth.asStateFlow()

    private val _currentPanchang = MutableStateFlow<DailyPanchang>(
        VedicPanchangCalculator.calculatePanchang(Calendar.getInstance())
    )
    val currentPanchang: StateFlow<DailyPanchang> = _currentPanchang.asStateFlow()

    private val _selectedTheme = MutableStateFlow(CalendarThemeOption.SHVET_SHYAM)
    val selectedTheme: StateFlow<CalendarThemeOption> = _selectedTheme.asStateFlow()

    private val _selectedLanguage = MutableStateFlow(AppLanguage.HINDI)
    val selectedLanguage: StateFlow<AppLanguage> = _selectedLanguage.asStateFlow()

    private val _selectedMuhuratCategory = MutableStateFlow<com.example.model.MuhuratCategory?>(null)
    val selectedMuhuratCategory: StateFlow<com.example.model.MuhuratCategory?> = _selectedMuhuratCategory.asStateFlow()

    private val _selectedTab = MutableStateFlow(0)
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    private val _showAddReminderDialog = MutableStateFlow(false)
    val showAddReminderDialog: StateFlow<Boolean> = _showAddReminderDialog.asStateFlow()

    private val _showThemeDialog = MutableStateFlow(false)
    val showThemeDialog: StateFlow<Boolean> = _showThemeDialog.asStateFlow()

    private val _showLanguageDialog = MutableStateFlow(false)
    val showLanguageDialog: StateFlow<Boolean> = _showLanguageDialog.asStateFlow()

    fun selectDate(calendar: Calendar) {
        val newCal = calendar.clone() as Calendar
        _selectedDate.value = newCal
        _currentPanchang.value = VedicPanchangCalculator.calculatePanchang(newCal)
    }

    fun changeMonth(offset: Int) {
        val cal = _viewMonth.value.clone() as Calendar
        cal.add(Calendar.MONTH, offset)
        _viewMonth.value = cal
    }

    fun selectMonthYear(year: Int, monthIndex: Int) {
        val cal = _viewMonth.value.clone() as Calendar
        cal.set(Calendar.YEAR, year)
        cal.set(Calendar.MONTH, monthIndex)
        cal.set(Calendar.DAY_OF_MONTH, 1)
        _viewMonth.value = cal
        selectDate(cal)
    }

    fun jumpToToday() {
        val today = Calendar.getInstance()
        _viewMonth.value = today.clone() as Calendar
        selectDate(today)
    }

    fun setTab(index: Int) {
        _selectedTab.value = index
    }

    fun openMuhuratCategory(category: com.example.model.MuhuratCategory?) {
        _selectedMuhuratCategory.value = category
        _selectedTab.value = 2 // Tab 2 is Muhurat
    }

    fun setMuhuratCategory(category: com.example.model.MuhuratCategory?) {
        _selectedMuhuratCategory.value = category
    }

    fun setTheme(theme: CalendarThemeOption) {
        _selectedTheme.value = theme
    }

    fun setLanguage(lang: AppLanguage) {
        _selectedLanguage.value = lang
    }

    fun setShowAddReminderDialog(show: Boolean) {
        _showAddReminderDialog.value = show
    }

    fun setShowThemeDialog(show: Boolean) {
        _showThemeDialog.value = show
    }

    fun setShowLanguageDialog(show: Boolean) {
        _showLanguageDialog.value = show
    }

    fun addReminder(
        title: String,
        description: String,
        targetDate: String,
        timeHour: Int = 7,
        timeMinute: Int = 0,
        category: String = "PERSONAL",
        context: Context
    ) {
        viewModelScope.launch {
            val reminder = ReminderEntity(
                title = title,
                description = description,
                targetDate = targetDate,
                timeHour = timeHour,
                timeMinute = timeMinute,
                category = category,
                isEnabled = true
            )
            val id = repository.insert(reminder)
            NotificationHelper.scheduleReminder(context, reminder.copy(id = id))
            _showAddReminderDialog.value = false
        }
    }

    fun toggleReminder(reminder: ReminderEntity, context: Context) {
        viewModelScope.launch {
            val updated = reminder.copy(isEnabled = !reminder.isEnabled)
            repository.update(updated)
            if (updated.isEnabled) {
                NotificationHelper.scheduleReminder(context, updated)
            } else {
                NotificationHelper.cancelReminder(context, reminder.id)
            }
        }
    }

    fun deleteReminder(reminder: ReminderEntity, context: Context) {
        viewModelScope.launch {
            NotificationHelper.cancelReminder(context, reminder.id)
            repository.delete(reminder)
        }
    }

    fun sendTestNotification(context: Context) {
        val lang = _selectedLanguage.value
        val panchang = _currentPanchang.value
        val title = "ॐ ${PanchangStrings.get(lang, "app_title")}: ${panchang.tithiName}"
        val message = "आज ${panchang.hinduMonth}, ${panchang.paksha.name}। राहुकाल: ${panchang.rahuKaal}। अभिजीत: ${panchang.abhijitMuhurat}"
        NotificationHelper.showNotification(
            context = context,
            title = title,
            message = message
        )
    }

    fun quickAddVratReminder(vratName: String, dateStr: String, context: Context) {
        viewModelScope.launch {
            val reminder = ReminderEntity(
                title = vratName,
                description = "पवित्र वैदिक व्रत एवं पूजा का दिन। प्रातः स्नानादि कर संकल्प लें।",
                targetDate = dateStr,
                timeHour = 6,
                timeMinute = 30,
                category = "VRAT",
                isEnabled = true
            )
            val id = repository.insert(reminder)
            NotificationHelper.scheduleReminder(context, reminder.copy(id = id))
        }
    }
}
