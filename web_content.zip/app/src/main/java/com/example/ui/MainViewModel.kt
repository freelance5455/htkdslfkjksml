package com.example.ui

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.HifzRepository
import com.example.data.SeedData
import com.example.data.model.ClassReportStatus
import com.example.data.model.DailyReport
import com.example.data.model.DailyReportSnapshot
import com.example.data.model.HifzClass
import com.example.data.model.Invite
import com.example.data.model.MonthlyStudentSummary
import com.example.data.model.MonthlySummaryResult
import com.example.data.model.School
import com.example.data.model.SchoolMember
import com.example.data.model.Student
import com.example.data.model.StudentRowData
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Locale

enum class SyncIndicatorState { LIVE_SYNCED, SYNCING, CACHED_OFFLINE, ERROR }

enum class AttendanceFilter { ALL, PRESENT, ABSENT }

data class MainSessionUiState(
    val userProfile: UserProfile? = null,
    val school: School? = null,
    val member: SchoolMember? = null,
    val classes: List<HifzClass> = emptyList(),
    val students: List<Student> = emptyList(),
    val selectedClassId: String = "",
    val selectedDate: String = SeedData.todayIso(),
    val rows: Map<String, StudentRowData> = emptyMap(),
    val sotd: String = "",
    val syncState: SyncIndicatorState = SyncIndicatorState.LIVE_SYNCED,
    val classStatuses: List<ClassReportStatus> = emptyList(),
    val toastMessage: String? = null,
    val errorMessage: String? = null,
    val isBootstrapping: Boolean = false,
    val needsWorkspaceSetup: Boolean = false
)

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(
    private val repository: HifzRepository,
    private val currentUserId: String,
    private val currentUserEmail: String
) : ViewModel() {

    private val _selectedSchoolIdOverride = MutableStateFlow<String?>(null)
    private val _selectedClassId = MutableStateFlow("")
    private val _selectedDate = MutableStateFlow(SeedData.todayIso())
    private val _summaryClassId = MutableStateFlow("")
    private val _summaryYearMonth = MutableStateFlow(SeedData.todayIso().substring(0, 7))
    private val _adminClassId = MutableStateFlow("")

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _attendanceFilter = MutableStateFlow(AttendanceFilter.ALL)
    val attendanceFilter: StateFlow<AttendanceFilter> = _attendanceFilter.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    private val _errorMessage = MutableStateFlow<String?>(null)
    private val _isBootstrapping = MutableStateFlow(false)
    private val _pendingInvite = MutableStateFlow<Invite?>(null)
    val pendingInvite: StateFlow<Invite?> = _pendingInvite.asStateFlow()

    // Optimistic local state for zero-lag typing & checkbox toggling
    private val _optimisticRows = MutableStateFlow<Map<String, StudentRowData>?>(null)
    private val _optimisticSotd = MutableStateFlow<String?>(null)
    private val _isLocalDirty = MutableStateFlow(false)
    private var currentDocExists = false
    private var currentActiveClassAndDate: Pair<String, String> = "" to ""
    private var debounceSaveJob: Job? = null

    // Admin cached secrets & backup
    private val _adminPin = MutableStateFlow("")
    val adminPin: StateFlow<String> = _adminPin.asStateFlow()

    private val _classPins = MutableStateFlow<Map<String, String>>(emptyMap())
    val classPins: StateFlow<Map<String, String>> = _classPins.asStateFlow()

    private val _backupJson = MutableStateFlow("")
    val backupJson: StateFlow<String> = _backupJson.asStateFlow()

    private val userProfileState: StateFlow<UiState<UserProfile?>> =
        repository.observeUserProfile(currentUserId)
            .unwrapFirestoreErrors("observeUserProfile")
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    private val activeSchoolIdFlow: Flow<String?> = combine(
        userProfileState,
        _selectedSchoolIdOverride
    ) { profileState, overrideId ->
        overrideId ?: (profileState as? UiState.Success)?.data?.activeSchoolId?.takeIf { it.isNotBlank() }
    }

    private val schoolFlow: Flow<School?> = activeSchoolIdFlow.flatMapLatest { sid ->
        if (sid.isNullOrBlank()) flowOf(null)
        else repository.observeSchool(sid).catch { emitIfNonCancel(it, null) }
    }

    private val memberFlow: Flow<SchoolMember?> = activeSchoolIdFlow.flatMapLatest { sid ->
        if (sid.isNullOrBlank()) flowOf(null)
        else repository.observeMember(sid, currentUserId).catch { emitIfNonCancel(it, null) }
    }

    private val classesFlow: Flow<List<HifzClass>> = combine(
        activeSchoolIdFlow,
        memberFlow
    ) { sid, member -> sid to member }.flatMapLatest { (sid, member) ->
        if (sid.isNullOrBlank() || member == null) {
            flowOf(emptyList())
        } else if (member.role == "admin") {
            repository.observeClasses(sid).catch { emitIfNonCancel(it, emptyList()) }
        } else if (member.classId.isNotBlank()) {
            repository.observeSingleClass(sid, member.classId)
                .map { cls -> listOfNotNull(cls) }
                .catch { emitIfNonCancel(it, emptyList()) }
        } else {
            flowOf(emptyList())
        }
    }

    private val effectiveClassIdFlow: Flow<String> = combine(
        memberFlow,
        schoolFlow,
        classesFlow,
        _selectedClassId
    ) { member, school, classes, manualId ->
        when {
            member == null -> ""
            member.role == "class" && member.classId.isNotBlank() -> member.classId
            manualId.isNotBlank() && classes.any { it.id == manualId } -> manualId
            school != null && classes.any { it.id == school.activeClassId } -> school.activeClassId
            else -> classes.firstOrNull()?.id ?: ""
        }
    }

    private val studentsFlow: Flow<List<Student>> = combine(
        activeSchoolIdFlow,
        effectiveClassIdFlow
    ) { sid, cid -> sid to cid }.flatMapLatest { (sid, cid) ->
        if (sid.isNullOrBlank() || cid.isBlank()) flowOf(emptyList())
        else repository.observeStudents(sid, cid).catch { emitIfNonCancel(it, emptyList()) }
    }

    private val dailySnapshotFlow: Flow<DailyReportSnapshot?> = combine(
        activeSchoolIdFlow,
        effectiveClassIdFlow,
        _selectedDate
    ) { sid, cid, date -> Triple(sid, cid, date) }.flatMapLatest { (sid, cid, date) ->
        if (sid.isNullOrBlank() || cid.isBlank() || date.isBlank()) flowOf(null)
        else repository.observeDailyReport(sid, cid, date)
            .map<DailyReportSnapshot, DailyReportSnapshot?> { it }
            .catch { emitIfNonCancel(it, null) }
    }

    private val classStatusesFlow: Flow<List<ClassReportStatus>> = combine(
        activeSchoolIdFlow,
        memberFlow,
        classesFlow,
        _selectedDate
    ) { sid, member, classes, date ->
        Triple(sid, member, classes to date)
    }.flatMapLatest { (sid, member, pair) ->
        val (classes, date) = pair
        if (sid.isNullOrBlank() || member?.role != "admin" || classes.isEmpty()) {
            flowOf(emptyList())
        } else {
            val perClassFlows = classes.map { cls ->
                combine(
                    repository.observeDailyReport(sid, cls.id, date)
                        .map<DailyReportSnapshot, DailyReportSnapshot?> { it }
                        .catch { emitIfNonCancel(it, null) },
                    repository.observeStudents(sid, cls.id).catch { emitIfNonCancel(it, emptyList()) }
                ) { snap, stuList ->
                    val rep = snap?.report
                    val timeFmt = rep?.updatedAt?.toDate()?.let {
                        SimpleDateFormat("HH:mm", Locale.US).format(it)
                    } ?: ""
                    val presCount = rep?.parsedRows()?.values?.count { it.isPresent } ?: 0
                    ClassReportStatus(
                        classId = cls.id,
                        className = cls.name,
                        hasReport = rep != null && (rep.rows.isNotEmpty() || rep.sotd.isNotBlank()),
                        updatedTimeText = timeFmt,
                        presentCount = presCount,
                        totalStudents = stuList.size
                    )
                }
            }
            combine(perClassFlows) { arr -> arr.toList() }
        }
    }

    val uiState: StateFlow<MainSessionUiState> = combine(
        listOf(
            userProfileState,
            schoolFlow,
            memberFlow,
            classesFlow,
            studentsFlow,
            effectiveClassIdFlow,
            _selectedDate,
            dailySnapshotFlow,
            _optimisticRows,
            _optimisticSotd,
            _isLocalDirty,
            classStatusesFlow,
            _toastMessage,
            _errorMessage,
            _isBootstrapping
        )
    ) { arr ->
        @Suppress("UNCHECKED_CAST")
        val profState = arr[0] as UiState<UserProfile?>
        val school = arr[1] as School?
        val member = arr[2] as SchoolMember?
        @Suppress("UNCHECKED_CAST")
        val classes = arr[3] as List<HifzClass>
        @Suppress("UNCHECKED_CAST")
        val students = arr[4] as List<Student>
        val cid = arr[5] as String
        val date = arr[6] as String
        val snap = arr[7] as DailyReportSnapshot?
        @Suppress("UNCHECKED_CAST")
        val optRows = arr[8] as Map<String, StudentRowData>?
        val optSotd = arr[9] as String?
        val dirty = arr[10] as Boolean
        @Suppress("UNCHECKED_CAST")
        val statuses = arr[11] as List<ClassReportStatus>
        val toast = arr[12] as String?
        val err = arr[13] as String?
        val bootstrapping = arr[14] as Boolean

        val profile = (profState as? UiState.Success)?.data
        val isLoadingProfile = profState is UiState.Loading

        val key = cid to date
        if (key != currentActiveClassAndDate) {
            currentActiveClassAndDate = key
            currentDocExists = snap?.report != null
        } else if (snap != null) {
            currentDocExists = snap.report != null
        }

        val remoteRows = snap?.report?.parsedRows() ?: emptyMap()
        val remoteSotd = snap?.report?.sotd ?: ""
        val displayedRows = if (dirty && optRows != null) optRows else remoteRows
        val displayedSotd = if (dirty && optSotd != null) optSotd else remoteSotd

        val syncStatus = when {
            dirty || snap?.hasPendingWrites == true -> SyncIndicatorState.SYNCING
            snap?.fromCache == true -> SyncIndicatorState.CACHED_OFFLINE
            else -> SyncIndicatorState.LIVE_SYNCED
        }

        val needsSetup = !isLoadingProfile && !bootstrapping &&
            (profile == null || profile.activeSchoolId.isBlank() || (school != null && member == null))

        MainSessionUiState(
            userProfile = profile,
            school = school,
            member = member,
            classes = classes,
            students = students,
            selectedClassId = cid,
            selectedDate = date,
            rows = displayedRows,
            sotd = displayedSotd,
            syncState = syncStatus,
            classStatuses = statuses,
            toastMessage = toast,
            errorMessage = err,
            isBootstrapping = isLoadingProfile || bootstrapping,
            needsWorkspaceSetup = needsSetup
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), MainSessionUiState(isBootstrapping = true))

    // Monthly Summary State
    val summaryClassId: StateFlow<String> = combine(
        effectiveClassIdFlow,
        _summaryClassId
    ) { eff, manual -> manual.ifBlank { eff } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), "")

    val summaryYearMonth: StateFlow<String> = _summaryYearMonth.asStateFlow()

    val monthlySummaryState: StateFlow<UiState<MonthlySummaryResult>> = combine(
        activeSchoolIdFlow,
        summaryClassId,
        _summaryYearMonth,
        classesFlow
    ) { sid, cid, ym, classes -> Triple(sid, cid to ym, classes) }
        .flatMapLatest { (sid, pair, classes) ->
            val (cid, ym) = pair
            if (sid.isNullOrBlank() || cid.isBlank() || ym.length != 7) {
                flowOf(UiState.Loading)
            } else {
                combine(
                    repository.observeStudents(sid, cid),
                    repository.observeMonthReports(sid, cid, ym)
                ) { stuList, reports ->
                    computeMonthlySummary(
                        yearMonth = ym,
                        classId = cid,
                        className = classes.firstOrNull { it.id == cid }?.name ?: cid,
                        students = stuList,
                        reports = reports
                    )
                }.flowOn(Dispatchers.Default)
                    .unwrapFirestoreErrors("observeMonthlySummary")
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UiState.Loading)

    // Admin Panel Streams
    val adminSelectedClassId: StateFlow<String> = combine(
        effectiveClassIdFlow,
        _adminClassId,
        classesFlow
    ) { eff, manual, classes ->
        if (manual.isNotBlank() && classes.any { it.id == manual }) manual
        else eff.ifBlank { classes.firstOrNull()?.id ?: "" }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), "")

    val adminStudents: StateFlow<List<Student>> = combine(
        activeSchoolIdFlow,
        adminSelectedClassId
    ) { sid, cid -> sid to cid }.flatMapLatest { (sid, cid) ->
        if (sid.isNullOrBlank() || cid.isBlank()) flowOf(emptyList())
        else repository.observeStudents(sid, cid).catch { emitIfNonCancel(it, emptyList()) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val adminSavedDates: StateFlow<List<String>> = combine(
        activeSchoolIdFlow,
        adminSelectedClassId
    ) { sid, cid -> sid to cid }.flatMapLatest { (sid, cid) ->
        if (sid.isNullOrBlank() || cid.isBlank()) flowOf(emptyList())
        else repository.observeAllReportDates(sid, cid).catch { emitIfNonCancel(it, emptyList()) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val adminInvites: StateFlow<List<Invite>> = combine(
        activeSchoolIdFlow,
        memberFlow
    ) { sid, member -> sid to member }.flatMapLatest { (sid, member) ->
        if (sid.isNullOrBlank() || member?.role != "admin") flowOf(emptyList())
        else repository.observeInvites(sid).catch { emitIfNonCancel(it, emptyList()) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    init {
        viewModelScope.launch {
            if (currentUserEmail.equals(SeedData.BOOTSTRAPPED_ADMIN_EMAIL, ignoreCase = true)) {
                _isBootstrapping.value = true
                repository.ensureBootstrappedAdminSchool()
                    .onSuccess { sid -> _selectedSchoolIdOverride.value = sid }
                    .onFailure { e -> _errorMessage.value = e.localizedMessage }
                _isBootstrapping.value = false
            } else {
                checkPendingInvite(SeedData.DEFAULT_SCHOOL_ID)
            }
        }
    }

    fun checkPendingInvite(schoolId: String) {
        viewModelScope.launch {
            _pendingInvite.value = repository.getMyPendingInvite(schoolId.trim().lowercase(Locale.US))
        }
    }

    fun acceptPendingInvite(schoolId: String, invite: Invite) {
        viewModelScope.launch {
            _isBootstrapping.value = true
            repository.joinSchoolWithInvite(schoolId, invite)
                .onSuccess {
                    _selectedSchoolIdOverride.value = schoolId
                    _pendingInvite.value = null
                    showToast("خوش آمدید ✓")
                }
                .onFailure { _errorMessage.value = it.localizedMessage ?: "Failed to join" }
            _isBootstrapping.value = false
        }
    }

    fun joinSchoolWithPin(schoolId: String, role: String, classId: String, pin: String) {
        val cleanSchool = schoolId.trim().lowercase(Locale.US).ifBlank { SeedData.DEFAULT_SCHOOL_ID }
        viewModelScope.launch {
            _isBootstrapping.value = true
            _errorMessage.value = null
            repository.joinSchoolWithPin(cleanSchool, role, classId, pin)
                .onSuccess {
                    _selectedSchoolIdOverride.value = cleanSchool
                    showToast("لاگ اِن کامیاب ✓")
                }
                .onFailure { e ->
                    val msg = if (e is FirebaseFirestoreException && e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED) {
                        "غلط PIN یا مدرسہ کوڈ · Invalid PIN or Madrasah code"
                    } else {
                        e.localizedMessage ?: "Join failed"
                    }
                    _errorMessage.value = msg
                }
            _isBootstrapping.value = false
        }
    }

    fun createNewWorkspace(schoolCode: String) {
        viewModelScope.launch {
            _isBootstrapping.value = true
            _errorMessage.value = null
            repository.createCustomSchoolWorkspace(schoolCode)
                .onSuccess { sid ->
                    _selectedSchoolIdOverride.value = sid
                    showToast("نیا مدرسہ ورک اسپیس تیار ✓")
                }
                .onFailure { e -> _errorMessage.value = e.localizedMessage ?: "Failed to create workspace" }
            _isBootstrapping.value = false
        }
    }

    fun switchClass(classId: String) {
        val state = uiState.value
        if (state.member?.role != "admin" || classId == state.selectedClassId) return
        flushPendingSaveImmediately()
        _isLocalDirty.value = false
        _optimisticRows.value = null
        _optimisticSotd.value = null
        _selectedClassId.value = classId
        val sid = state.school?.id ?: return
        viewModelScope.launch { repository.updateActiveClass(sid, classId) }
    }

    fun selectDate(dateIso: String) {
        if (dateIso == _selectedDate.value) return
        flushPendingSaveImmediately()
        _isLocalDirty.value = false
        _optimisticRows.value = null
        _optimisticSotd.value = null
        _selectedDate.value = dateIso
    }

    fun setSearchQuery(q: String) { _searchQuery.value = q }
    fun setAttendanceFilter(f: AttendanceFilter) { _attendanceFilter.value = f }

    fun updateAttendance(studentNum: Long, field: String, checked: Boolean) {
        val state = uiState.value
        val key = studentNum.toString()
        val updatedRows = state.rows.toMutableMap()
        val existingRow = updatedRows[key] ?: StudentRowData()
        val newRow = if (field == "a1") existingRow.copy(a1 = checked) else existingRow.copy(a2 = checked)
        updatedRows[key] = newRow
        applyOptimisticAndScheduleSave(state, updatedRows, state.sotd, delayMs = 100L)
    }

    fun updateStudentTextField(studentNum: Long, fieldKey: String, value: String) {
        val state = uiState.value
        val key = studentNum.toString()
        val updatedRows = state.rows.toMutableMap()
        val existingRow = updatedRows[key] ?: StudentRowData()
        updatedRows[key] = existingRow.withTextField(fieldKey, value)
        val delayMs = if (fieldKey == "td") 100L else 450L
        applyOptimisticAndScheduleSave(state, updatedRows, state.sotd, delayMs = delayMs)
    }

    fun updateStudentOfTheDay(studentNumStr: String) {
        val state = uiState.value
        applyOptimisticAndScheduleSave(state, state.rows, studentNumStr, delayMs = 100L)
    }

    fun markAllPresent(firstTime: Boolean) {
        val state = uiState.value
        if (state.students.isEmpty()) return
        val updatedRows = state.rows.toMutableMap()
        state.students.forEach { st ->
            val key = st.studentNum.toString()
            val cur = updatedRows[key] ?: StudentRowData()
            updatedRows[key] = if (firstTime) cur.copy(a1 = true) else cur.copy(a2 = true)
        }
        applyOptimisticAndScheduleSave(state, updatedRows, state.sotd, delayMs = 100L)
        showToast("سب طلبہ حاضر ✓")
    }

    private fun applyOptimisticAndScheduleSave(
        snapshotState: MainSessionUiState,
        newRows: Map<String, StudentRowData>,
        newSotd: String,
        delayMs: Long
    ) {
        val sid = snapshotState.school?.id ?: return
        val cid = snapshotState.selectedClassId.takeIf { it.isNotBlank() } ?: return
        val date = snapshotState.selectedDate
        val existsAtEdit = currentDocExists

        _optimisticRows.value = newRows
        _optimisticSotd.value = newSotd
        _isLocalDirty.value = true

        debounceSaveJob?.cancel()
        debounceSaveJob = viewModelScope.launch {
            delay(delayMs)
            repository.saveDailyReport(
                schoolId = sid,
                classId = cid,
                dateIso = date,
                sotd = newSotd,
                rows = newRows,
                documentAlreadyExists = existsAtEdit
            ).onSuccess {
                currentDocExists = true
                _isLocalDirty.value = false
                showToast("محفوظ ✓")
            }.onFailure { e ->
                _isLocalDirty.value = false
                _errorMessage.value = e.localizedMessage ?: "Sync error"
            }
        }
    }

    private fun flushPendingSaveImmediately() {
        val job = debounceSaveJob ?: return
        if (!job.isActive) return
        job.cancel()
        val state = uiState.value
        val sid = state.school?.id ?: return
        val cid = state.selectedClassId.takeIf { it.isNotBlank() } ?: return
        val date = state.selectedDate
        val rows = _optimisticRows.value ?: state.rows
        val sotd = _optimisticSotd.value ?: state.sotd
        val exists = currentDocExists
        viewModelScope.launch {
            repository.saveDailyReport(sid, cid, date, sotd, rows, exists)
        }
    }

    // Monthly Summary controls
    fun setSummaryClassId(cid: String) { _summaryClassId.value = cid }
    fun setSummaryYearMonth(ym: String) { _summaryYearMonth.value = ym }

    // Admin controls
    fun loadAdminSecrets() {
        val sid = uiState.value.school?.id ?: return
        viewModelScope.launch {
            _adminPin.value = repository.getAdminPin(sid) ?: ""
            _classPins.value = repository.getClassPins(sid)
        }
    }

    fun selectAdminClass(cid: String) { _adminClassId.value = cid }

    fun saveHeading(title: String, centre: String) {
        val sid = uiState.value.school?.id ?: return
        viewModelScope.launch {
            repository.updateSchoolHeading(sid, title, centre)
                .onSuccess { showToast("سرخی محفوظ ہو گئی ✓") }
                .onFailure { _errorMessage.value = it.localizedMessage }
        }
    }

    fun addClass(name: String) {
        val state = uiState.value
        val sid = state.school?.id ?: return
        val nextNum = state.school.nextClassNum
        val sortOrder = (state.classes.maxOfOrNull { it.sortOrder } ?: -1L) + 1L
        viewModelScope.launch {
            repository.addClass(sid, name, nextNum, sortOrder)
                .onSuccess { newCid ->
                    _adminClassId.value = newCid
                    loadAdminSecrets()
                    showToast("کلاس شامل ہو گئی ✓")
                }
                .onFailure { _errorMessage.value = it.localizedMessage }
        }
    }

    fun renameClass(classId: String, name: String) {
        val sid = uiState.value.school?.id ?: return
        viewModelScope.launch {
            repository.renameClass(sid, classId, name)
                .onFailure { _errorMessage.value = it.localizedMessage }
        }
    }

    fun updateClassPin(classId: String, pin: String) {
        val sid = uiState.value.school?.id ?: return
        viewModelScope.launch {
            repository.updateClassPin(sid, classId, pin)
                .onSuccess {
                    _classPins.value = _classPins.value + (classId to pin.trim())
                    showToast("PIN محفوظ ✓")
                }
                .onFailure { _errorMessage.value = it.localizedMessage }
        }
    }

    fun deleteClass(classId: String) {
        val state = uiState.value
        val sid = state.school?.id ?: return
        if (state.classes.size < 2) {
            showToast("کم از کم ایک کلاس رہنا ضروری ہے")
            return
        }
        viewModelScope.launch {
            repository.deleteClass(sid, classId)
                .onSuccess {
                    val remaining = state.classes.firstOrNull { it.id != classId }?.id ?: ""
                    _adminClassId.value = remaining
                    if (state.selectedClassId == classId) _selectedClassId.value = remaining
                    showToast("کلاس حذف ہو گئی")
                }
                .onFailure { _errorMessage.value = it.localizedMessage }
        }
    }

    fun addStudent(name: String) {
        val state = uiState.value
        val cid = adminSelectedClassId.value.takeIf { it.isNotBlank() } ?: return
        addStudentProfileForClass(
            classId = cid,
            currentStudents = adminStudents.value,
            name = name,
            fatherName = "",
            guardianPhone = "",
            currentPara = "",
            notes = ""
        )
    }

    fun addStudentProfileForCurrentClass(
        name: String,
        fatherName: String,
        guardianPhone: String,
        currentPara: String,
        notes: String
    ) {
        val state = uiState.value
        val cid = state.selectedClassId.takeIf { it.isNotBlank() } ?: return
        addStudentProfileForClass(
            classId = cid,
            currentStudents = state.students,
            name = name,
            fatherName = fatherName,
            guardianPhone = guardianPhone,
            currentPara = currentPara,
            notes = notes
        )
    }

    private fun addStudentProfileForClass(
        classId: String,
        currentStudents: List<Student>,
        name: String,
        fatherName: String,
        guardianPhone: String,
        currentPara: String,
        notes: String
    ) {
        val state = uiState.value
        val sid = state.school?.id ?: return
        val cls = state.classes.firstOrNull { it.id == classId } ?: return
        val nextNum = (currentStudents.maxOfOrNull { it.studentNum } ?: 0L) + 1L
        val nextId = maxOf(cls.nextStudentId, nextNum)
        val sortOrder = (currentStudents.maxOfOrNull { it.sortOrder } ?: -1L) + 1L
        viewModelScope.launch {
            repository.addStudent(
                schoolId = sid,
                classId = classId,
                name = name,
                nextStudentNum = nextId,
                sortOrder = sortOrder,
                fatherName = fatherName,
                guardianPhone = guardianPhone,
                currentPara = currentPara,
                notes = notes
            )
                .onSuccess { showToast("طالب علم کا پروفائل شامل ہو گیا ✓") }
                .onFailure { _errorMessage.value = it.localizedMessage }
        }
    }

    fun renameStudent(studentId: String, name: String) {
        val sid = uiState.value.school?.id ?: return
        val cid = adminSelectedClassId.value.takeIf { it.isNotBlank() } ?: return
        viewModelScope.launch {
            repository.renameStudent(sid, cid, studentId, name)
                .onFailure { _errorMessage.value = it.localizedMessage }
        }
    }

    fun updateStudentProfileForCurrentClass(
        studentId: String,
        name: String,
        fatherName: String,
        guardianPhone: String,
        currentPara: String,
        notes: String
    ) {
        val state = uiState.value
        val sid = state.school?.id ?: return
        val cid = state.selectedClassId.takeIf { it.isNotBlank() } ?: return
        viewModelScope.launch {
            repository.updateStudentProfile(
                schoolId = sid,
                classId = cid,
                studentId = studentId,
                name = name,
                fatherName = fatherName,
                guardianPhone = guardianPhone,
                currentPara = currentPara,
                notes = notes
            )
                .onSuccess { showToast("پروفائل اپ ڈیٹ ہو گیا ✓") }
                .onFailure { _errorMessage.value = it.localizedMessage }
        }
    }

    fun moveStudent(index: Int, delta: Int) {
        val list = adminStudents.value
        val cid = adminSelectedClassId.value.takeIf { it.isNotBlank() } ?: return
        moveStudentInList(cid, list, index, delta)
    }

    fun moveStudentForCurrentClass(index: Int, delta: Int) {
        val state = uiState.value
        val cid = state.selectedClassId.takeIf { it.isNotBlank() } ?: return
        moveStudentInList(cid, state.students, index, delta)
    }

    private fun moveStudentInList(classId: String, list: List<Student>, index: Int, delta: Int) {
        val target = index + delta
        if (index !in list.indices || target !in list.indices) return
        val sid = uiState.value.school?.id ?: return
        viewModelScope.launch {
            repository.swapStudentsOrder(sid, classId, list[index], list[target])
                .onFailure { _errorMessage.value = it.localizedMessage }
        }
    }

    fun deleteStudent(studentId: String) {
        val sid = uiState.value.school?.id ?: return
        val cid = adminSelectedClassId.value.takeIf { it.isNotBlank() } ?: return
        viewModelScope.launch {
            repository.deleteStudent(sid, cid, studentId)
                .onSuccess { showToast("طالب علم حذف") }
                .onFailure { _errorMessage.value = it.localizedMessage }
        }
    }

    fun deleteStudentForCurrentClass(studentId: String) {
        val state = uiState.value
        val sid = state.school?.id ?: return
        val cid = state.selectedClassId.takeIf { it.isNotBlank() } ?: return
        viewModelScope.launch {
            repository.deleteStudent(sid, cid, studentId)
                .onSuccess { showToast("طالب علم کا پروفائل حذف ہو گیا ✓") }
                .onFailure { _errorMessage.value = it.localizedMessage }
        }
    }

    fun deleteSavedSheet(dateIso: String) {
        val sid = uiState.value.school?.id ?: return
        val cid = adminSelectedClassId.value.takeIf { it.isNotBlank() } ?: return
        viewModelScope.launch {
            repository.deleteDailyReport(sid, cid, dateIso)
                .onSuccess { showToast("شیٹ حذف ہو گئی") }
                .onFailure { _errorMessage.value = it.localizedMessage }
        }
    }

    fun openSavedSheet(dateIso: String) {
        val cid = adminSelectedClassId.value
        if (cid.isNotBlank()) _selectedClassId.value = cid
        _selectedDate.value = dateIso
    }

    fun updateAdminPin(newPin: String) {
        val sid = uiState.value.school?.id ?: return
        viewModelScope.launch {
            repository.updateAdminPin(sid, newPin)
                .onSuccess {
                    _adminPin.value = newPin.trim()
                    showToast("ایڈمن PIN تبدیل ✓")
                }
                .onFailure { _errorMessage.value = it.localizedMessage }
        }
    }

    fun addInvite(email: String, role: String, classId: String) {
        val sid = uiState.value.school?.id ?: return
        viewModelScope.launch {
            repository.addInvite(sid, email, role, classId)
                .onSuccess { showToast("دعوت شامل ✓") }
                .onFailure { _errorMessage.value = it.localizedMessage }
        }
    }

    fun removeInvite(email: String) {
        val sid = uiState.value.school?.id ?: return
        viewModelScope.launch {
            repository.removeInvite(sid, email)
                .onFailure { _errorMessage.value = it.localizedMessage }
        }
    }

    fun exportBackup() {
        val state = uiState.value
        val sid = state.school?.id ?: return
        val school = state.school
        viewModelScope.launch {
            repository.exportBackupJson(sid, school, state.classes)
                .onSuccess { json ->
                    _backupJson.value = json
                    showToast("بیک اپ تیار ✓")
                }
                .onFailure { _errorMessage.value = it.localizedMessage }
        }
    }

    fun clearToast() { _toastMessage.value = null }
    fun clearError() { _errorMessage.value = null }
    fun showToast(msg: String) { _toastMessage.value = msg }

    private fun computeMonthlySummary(
        yearMonth: String,
        classId: String,
        className: String,
        students: List<Student>,
        reports: List<DailyReport>
    ): MonthlySummaryResult {
        var workingDays = 0
        val statsMap = students.associate { st ->
            st.studentNum to MonthlyAcc(name = st.name, studentNum = st.studentNum)
        }.toMutableMap()

        reports.forEach { report ->
            val parsed = report.parsedRows()
            val anyPresent = parsed.values.any { it.isPresent }
            if (anyPresent) workingDays++
            students.forEach { st ->
                val key = st.studentNum.toString()
                val row = parsed[key] ?: StudentRowData()
                val acc = statsMap[st.studentNum] ?: return@forEach
                if (anyPresent && row.isPresent) acc.present++
                val linesVal = SeedData.parseNumeric(row.sl)
                if (linesVal > 0) {
                    acc.totalLines += linesVal
                    acc.lineDays++
                }
                acc.sabqiMistakes += SeedData.parseNumeric(row.sqm)
                acc.manzilMistakes += SeedData.parseNumeric(row.mm)
                if (row.sp.isNotBlank()) acc.latestPara = row.sp.trim()
                if (report.sotd.isNotBlank() && report.sotd == key) acc.sotdCount++
            }
        }

        val list = students.mapNotNull { st ->
            val acc = statsMap[st.studentNum] ?: return@mapNotNull null
            val avg = if (acc.lineDays > 0) kotlin.math.round((acc.totalLines / acc.lineDays) * 10.0) / 10.0 else 0.0
            MonthlyStudentSummary(
                studentNum = acc.studentNum,
                name = acc.name,
                presentDays = acc.present,
                absentDays = (workingDays - acc.present).coerceAtLeast(0),
                totalSabaqLines = acc.totalLines,
                dailyAvgLines = avg,
                sabqiMistakes = acc.sabqiMistakes,
                manzilMistakes = acc.manzilMistakes,
                latestSabaqPara = acc.latestPara,
                sotdCount = acc.sotdCount
            )
        }
        return MonthlySummaryResult(
            yearMonth = yearMonth,
            classId = classId,
            className = className,
            recordedSheetsCount = reports.size,
            workingDaysCount = workingDays,
            students = list
        )
    }

    private class MonthlyAcc(
        val studentNum: Long,
        val name: String,
        var present: Int = 0,
        var totalLines: Double = 0.0,
        var lineDays: Int = 0,
        var sabqiMistakes: Double = 0.0,
        var manzilMistakes: Double = 0.0,
        var latestPara: String = "",
        var sotdCount: Int = 0
    )

    private fun <T> Flow<T>.unwrapFirestoreErrors(tagOp: String): Flow<UiState<T>> =
        this.map<T, UiState<T>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val root = firestoreError ?: error
                Log.w("MainVM", "Error in $tagOp", root)
                emit(UiState.Error(root.message ?: "Failed to load data"))
            }

    private suspend fun <T> kotlinx.coroutines.flow.FlowCollector<T>.emitIfNonCancel(
        error: Throwable,
        fallback: T
    ) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        Log.w("MainVM", "Flow warning: ${(firestoreError ?: error).message}")
        emit(fallback)
    }
}
