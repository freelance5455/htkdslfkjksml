package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.GeminiApiClient
import com.example.data.local.AppDatabase
import com.example.data.local.ChatMessage
import com.example.data.local.ChatSession
import com.example.data.local.CreationItem
import com.example.data.local.PreferencesManager
import com.example.data.repository.ChatRepository
import com.example.data.repository.CreationRepository
import com.example.ui.util.FileUtils
import com.example.ui.util.SpeechHelper
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppScreen {
    CHAT,
    CREATION,
    SETTINGS
}

enum class CreationTab {
    IMAGE,
    VIDEO
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application)
    private val dao = database.appDao()
    private val apiClient = GeminiApiClient()
    val preferencesManager = PreferencesManager(application)

    private val chatRepository = ChatRepository(application, dao, apiClient, preferencesManager)
    private val creationRepository = CreationRepository(application, dao, apiClient, preferencesManager)
    val speechHelper = SpeechHelper(application)

    // Current Screen
    private val _currentScreen = MutableStateFlow(AppScreen.CHAT)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    // Active Session & Messages
    private val _activeSession = MutableStateFlow<ChatSession?>(null)
    val activeSession: StateFlow<ChatSession?> = _activeSession.asStateFlow()

    val allSessions: StateFlow<List<ChatSession>> = chatRepository.allSessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private var messagesObservationJob: Job? = null

    // Chat Input State
    val chatInputText = MutableStateFlow("")
    val attachedImageUri = MutableStateFlow<Uri?>(null)
    val attachedFileUri = MutableStateFlow<Uri?>(null)
    val attachedFileName = MutableStateFlow<String?>(null)

    val isChatGenerating = MutableStateFlow(false)
    val chatErrorMessage = MutableStateFlow<String?>(null)

    // Delete session dialog
    val sessionToDelete = MutableStateFlow<ChatSession?>(null)

    // Creation State
    val creationTab = MutableStateFlow(CreationTab.IMAGE)
    val imagePrompt = MutableStateFlow("")
    val imageInputUri = MutableStateFlow<Uri?>(null)
    val imageAspectRatio = MutableStateFlow("1:1")
    val imageStyle = MutableStateFlow("Varsayılan")

    val videoPrompt = MutableStateFlow("")
    val videoInputUri = MutableStateFlow<Uri?>(null)
    val videoAspectRatio = MutableStateFlow("16:9")

    val isCreatingMedia = MutableStateFlow(false)
    val creationStatusText = MutableStateFlow("")
    val latestCreation = MutableStateFlow<CreationItem?>(null)
    val creationErrorMessage = MutableStateFlow<String?>(null)

    val allCreations: StateFlow<List<CreationItem>> = creationRepository.allCreations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Settings State
    val settingsApiKey = MutableStateFlow(preferencesManager.getCustomApiKey())
    val settingsTtsAutoSpeak = MutableStateFlow(preferencesManager.isTtsAutoSpeakEnabled())
    val settingsSpeechRate = MutableStateFlow(preferencesManager.getSpeechRate())
    val isTestingApi = MutableStateFlow(false)
    val apiTestMessage = MutableStateFlow<String?>(null)
    val apiTestSuccess = MutableStateFlow<Boolean?>(null)

    init {
        // Initialize or load active session
        viewModelScope.launch {
            val savedSessionId = preferencesManager.getActiveSessionId()
            val session = chatRepository.getOrCreateSession(if (savedSessionId > 0) savedSessionId else null)
            selectSession(session)
        }
    }

    fun navigateTo(screen: AppScreen) {
        _currentScreen.value = screen
    }

    fun selectSession(session: ChatSession) {
        _activeSession.value = session
        preferencesManager.setActiveSessionId(session.id)
        observeMessages(session.id)
        _currentScreen.value = AppScreen.CHAT
    }

    fun createNewSession() {
        viewModelScope.launch {
            val newSession = chatRepository.createNewSession()
            selectSession(newSession)
            clearChatAttachments()
            chatInputText.value = ""
        }
    }

    private fun observeMessages(sessionId: Long) {
        messagesObservationJob?.cancel()
        messagesObservationJob = viewModelScope.launch {
            chatRepository.getMessagesForSession(sessionId).collect { list ->
                _messages.value = list
            }
        }
    }

    fun confirmDeleteSession(session: ChatSession) {
        sessionToDelete.value = session
    }

    fun executeDeleteSession() {
        val target = sessionToDelete.value ?: return
        viewModelScope.launch {
            chatRepository.deleteSession(target.id)
            sessionToDelete.value = null
            if (_activeSession.value?.id == target.id) {
                val remaining = allSessions.value.filter { it.id != target.id }
                if (remaining.isNotEmpty()) {
                    selectSession(remaining.first())
                } else {
                    createNewSession()
                }
            }
        }
    }

    fun setAttachedImage(uri: Uri?) {
        attachedImageUri.value = uri
        if (uri != null) {
            // clear file if image is attached
            attachedFileUri.value = null
            attachedFileName.value = null
        }
    }

    fun setAttachedFile(uri: Uri?) {
        attachedFileUri.value = uri
        if (uri != null) {
            attachedFileName.value = FileUtils.getFileName(getApplication(), uri)
            // clear image if file attached
            attachedImageUri.value = null
        } else {
            attachedFileName.value = null
        }
    }

    fun clearChatAttachments() {
        attachedImageUri.value = null
        attachedFileUri.value = null
        attachedFileName.value = null
    }

    fun sendMessage() {
        val text = chatInputText.value.trim()
        val img = attachedImageUri.value
        val file = attachedFileUri.value
        val currentSession = _activeSession.value ?: return

        if (text.isEmpty() && img == null && file == null) {
            return
        }

        chatInputText.value = ""
        clearChatAttachments()
        isChatGenerating.value = true
        chatErrorMessage.value = null

        viewModelScope.launch {
            val result = chatRepository.sendMessage(
                sessionId = currentSession.id,
                text = text,
                imageUri = img,
                fileUri = file
            )

            isChatGenerating.value = false

            if (result.isSuccess) {
                val assistantMsg = result.getOrNull()
                if (assistantMsg != null && preferencesManager.isTtsAutoSpeakEnabled()) {
                    speechHelper.speak(assistantMsg.content, preferencesManager.getSpeechRate())
                }
            } else {
                chatErrorMessage.value = result.exceptionOrNull()?.message
            }
        }
    }

    // Voice recognition
    fun toggleVoiceListening() {
        if (speechHelper.isListening.value) {
            speechHelper.stopListening()
        } else {
            speechHelper.startListening(
                onResult = { recognizedText ->
                    if (recognizedText.isNotBlank()) {
                        val current = chatInputText.value
                        chatInputText.value = if (current.isBlank()) recognizedText else "$current $recognizedText"
                    }
                },
                onError = { error ->
                    chatErrorMessage.value = error
                }
            )
        }
    }

    // Creation: Generate Image
    fun generateImage() {
        val prompt = imagePrompt.value.trim()
        if (prompt.isBlank()) {
            creationErrorMessage.value = "Lütfen oluşturmak istediğiniz görseli tarif eden bir metin yazın."
            return
        }

        isCreatingMedia.value = true
        creationErrorMessage.value = null
        creationStatusText.value = "Suesa AI görseli oluşturuyor, lütfen bekleyin..."

        viewModelScope.launch {
            val result = creationRepository.generateImage(
                prompt = prompt,
                inputImageUri = imageInputUri.value,
                aspectRatio = imageAspectRatio.value,
                style = imageStyle.value
            )

            isCreatingMedia.value = false
            creationStatusText.value = ""

            if (result.isSuccess) {
                latestCreation.value = result.getOrNull()
            } else {
                creationErrorMessage.value = result.exceptionOrNull()?.message
                    ?: "Görsel oluşturulamadı. Lütfen tekrar deneyin."
            }
        }
    }

    // Creation: Generate Video
    fun generateVideo() {
        val prompt = videoPrompt.value.trim()
        if (prompt.isBlank()) {
            creationErrorMessage.value = "Lütfen oluşturmak istediğiniz videoyu tarif eden bir metin yazın."
            return
        }

        isCreatingMedia.value = true
        creationErrorMessage.value = null
        creationStatusText.value = "Video hazırlanıyor, bu işlem biraz zaman alabilir..."

        viewModelScope.launch {
            val result = creationRepository.generateVideo(
                prompt = prompt,
                inputImageUri = videoInputUri.value,
                aspectRatio = videoAspectRatio.value
            )

            isCreatingMedia.value = false
            creationStatusText.value = ""

            if (result.isSuccess) {
                latestCreation.value = result.getOrNull()
            } else {
                creationErrorMessage.value = result.exceptionOrNull()?.message
                    ?: "Video oluşturma işlemi gerçekleştirilemedi."
            }
        }
    }

    fun saveCreationToGallery(creation: CreationItem, onComplete: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            try {
                val uri = Uri.parse(creation.mediaUri)
                val inputStream = getApplication<Application>().contentResolver.openInputStream(uri)
                val bytes = inputStream?.readBytes()
                inputStream?.close()

                if (bytes != null) {
                    val saved = FileUtils.saveImageToGallery(getApplication(), bytes)
                    if (saved != null) {
                        onComplete(true, "Görsel başarıyla galeriye kaydedildi.")
                    } else {
                        onComplete(false, "Kayıt işlemi başarısız oldu.")
                    }
                } else {
                    onComplete(false, "Medya dosyası okunamadı.")
                }
            } catch (e: Exception) {
                onComplete(false, "Hata: ${e.message}")
            }
        }
    }

    fun deleteCreation(id: Long) {
        viewModelScope.launch {
            creationRepository.deleteCreation(id)
            if (latestCreation.value?.id == id) {
                latestCreation.value = null
            }
        }
    }

    // Settings actions
    fun saveCustomApiKey(key: String) {
        preferencesManager.setCustomApiKey(key)
        settingsApiKey.value = key
    }

    fun testApiConnection() {
        val key = settingsApiKey.value.trim().ifEmpty { preferencesManager.getEffectiveApiKey() }
        if (key.isBlank()) {
            apiTestMessage.value = "Lütfen geçerli bir Gemini API anahtarı girin."
            apiTestSuccess.value = false
            return
        }

        isTestingApi.value = true
        apiTestMessage.value = null
        apiTestSuccess.value = null

        viewModelScope.launch {
            val result = apiClient.testConnection(key)
            isTestingApi.value = false
            if (result.isSuccess) {
                apiTestSuccess.value = true
                apiTestMessage.value = result.getOrNull() ?: "Bağlantı başarılı!"
            } else {
                apiTestSuccess.value = false
                apiTestMessage.value = result.exceptionOrNull()?.message ?: "Bağlantı hatası."
            }
        }
    }

    fun setTtsAutoSpeak(enabled: Boolean) {
        preferencesManager.setTtsAutoSpeakEnabled(enabled)
        settingsTtsAutoSpeak.value = enabled
    }

    fun setSpeechRate(rate: Float) {
        preferencesManager.setSpeechRate(rate)
        settingsSpeechRate.value = rate
    }

    fun clearAllHistory(onComplete: () -> Unit) {
        viewModelScope.launch {
            chatRepository.deleteAllHistory()
            createNewSession()
            onComplete()
        }
    }

    override fun onCleared() {
        super.onCleared()
        speechHelper.release()
    }
}
