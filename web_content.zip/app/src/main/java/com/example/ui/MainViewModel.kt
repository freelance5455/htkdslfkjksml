package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.OmniVoiceApp
import com.example.data.model.ProjectEntity
import com.example.data.model.ScriptPreset
import com.example.player.PlaybackState
import com.example.tts.AudioStitcher
import com.example.tts.TextChunker
import com.example.tts.model.VoiceInfo
import com.example.tts.queue.QueueProgressState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale

data class StudioUiState(
    val currentProjectId: Long = 0L,
    val projectTitle: String = "Untitled Script",
    val scriptText: String = "",
    val availableVoices: List<VoiceInfo> = emptyList(),
    val selectedVoice: VoiceInfo? = null,
    val selectedLanguage: String = "All Languages",
    val speechSpeed: Float = 1.0f,
    val pitch: Float = 1.0f,
    val pauseBetweenSentencesMs: Int = 250,
    val currentAudioFile: File? = null,
    val isVoicePreviewPlaying: Boolean = false,
    val isInitializingTts: Boolean = true,
    val userNotice: String? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as OmniVoiceApp
    private val repository = app.projectRepository
    private val ttsEngine = app.systemTtsEngine
    private val queueManager = app.ttsQueueManager
    private val audioPlayer = app.audioPlayerManager

    val allProjects: StateFlow<List<ProjectEntity>> = repository.allProjects
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val queueState: StateFlow<QueueProgressState> = queueManager.queueState
    val playbackState: StateFlow<PlaybackState> = audioPlayer.playbackState

    private val _uiState = MutableStateFlow(StudioUiState())
    val uiState: StateFlow<StudioUiState> = _uiState.asStateFlow()

    init {
        initializeTtsEngine()
        listenToQueueCompletion()
    }

    private fun initializeTtsEngine() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isInitializingTts = true)
            ttsEngine.initialize()
            val voices = ttsEngine.getAvailableVoices()
            val defaultLocale = Locale.getDefault()
            val matchingVoice = voices.find { it.localeTag == defaultLocale.toLanguageTag() }
                ?: voices.find { it.localeTag.startsWith("en") }
                ?: voices.firstOrNull()

            _uiState.value = _uiState.value.copy(
                availableVoices = voices,
                selectedVoice = matchingVoice,
                isInitializingTts = false
            )
        }
    }

    private fun listenToQueueCompletion() {
        viewModelScope.launch {
            queueState.collect { state ->
                if (state.completedMasterFile != null && state.completedMasterFile != _uiState.value.currentAudioFile) {
                    val file = state.completedMasterFile
                    _uiState.value = _uiState.value.copy(currentAudioFile = file)
                    audioPlayer.loadFile(file, autoPlay = true)
                    saveCurrentProject()
                }
            }
        }
    }

    fun updateScriptText(text: String) {
        _uiState.value = _uiState.value.copy(scriptText = text)
    }

    fun updateTitle(title: String) {
        _uiState.value = _uiState.value.copy(projectTitle = title)
    }

    fun setSpeed(speed: Float) {
        _uiState.value = _uiState.value.copy(speechSpeed = speed)
    }

    fun setPitch(pitch: Float) {
        _uiState.value = _uiState.value.copy(pitch = pitch)
    }

    fun setPause(pauseMs: Int) {
        _uiState.value = _uiState.value.copy(pauseBetweenSentencesMs = pauseMs)
    }

    fun selectVoice(voice: VoiceInfo) {
        _uiState.value = _uiState.value.copy(selectedVoice = voice)
    }

    fun selectLanguage(lang: String) {
        _uiState.value = _uiState.value.copy(selectedLanguage = lang)
    }

    fun loadPreset(preset: ScriptPreset) {
        _uiState.value = _uiState.value.copy(
            projectTitle = preset.title,
            scriptText = preset.script
        )
    }

    fun clearScript() {
        _uiState.value = _uiState.value.copy(
            scriptText = "",
            currentAudioFile = null
        )
        audioPlayer.release()
    }

    fun previewSelectedVoice() {
        val voice = _uiState.value.selectedVoice ?: return
        if (_uiState.value.isVoicePreviewPlaying) {
            ttsEngine.stopPreview()
            _uiState.value = _uiState.value.copy(isVoicePreviewPlaying = false)
            return
        }

        _uiState.value = _uiState.value.copy(isVoicePreviewPlaying = true)
        val previewSample = _uiState.value.scriptText.take(100).ifBlank {
            "OmniVoice speech synthesis preview. Crisp studio audio generated for your script."
        }
        ttsEngine.previewVoice(
            text = previewSample,
            voice = voice,
            speed = _uiState.value.speechSpeed,
            pitch = _uiState.value.pitch,
            onDone = {
                _uiState.value = _uiState.value.copy(isVoicePreviewPlaying = false)
            }
        )
    }

    fun stopVoicePreview() {
        ttsEngine.stopPreview()
        _uiState.value = _uiState.value.copy(isVoicePreviewPlaying = false)
    }

    fun generateSpeech() {
        val text = _uiState.value.scriptText.trim()
        if (text.isEmpty()) {
            _uiState.value = _uiState.value.copy(userNotice = "Please enter or paste a script first")
            return
        }
        val voice = _uiState.value.selectedVoice ?: run {
            _uiState.value = _uiState.value.copy(userNotice = "No voice selected")
            return
        }

        stopVoicePreview()
        audioPlayer.pause()

        val chunks = TextChunker.chunkText(text)
        if (chunks.isEmpty()) {
            _uiState.value = _uiState.value.copy(userNotice = "Text does not contain valid sentences")
            return
        }

        val projectDir = File(app.filesDir, "audio_projects").apply { mkdirs() }
        val safeTitle = _uiState.value.projectTitle.replace(Regex("[^a-zA-Z0-9_]"), "_").take(30)
        val masterFile = File(projectDir, "${safeTitle}_${System.currentTimeMillis()}.wav")

        queueManager.startQueue(
            chunks = chunks,
            engine = ttsEngine,
            voice = voice,
            speed = _uiState.value.speechSpeed,
            pitch = _uiState.value.pitch,
            pauseBetweenChunksMs = _uiState.value.pauseBetweenSentencesMs,
            outputFile = masterFile
        )
    }

    fun retryFailedChunk(chunkIndex: Int) {
        queueManager.retryFailedChunk(chunkIndex)
    }

    fun cancelGeneration() {
        queueManager.cancelQueue()
    }

    fun dismissNotice() {
        _uiState.value = _uiState.value.copy(userNotice = null)
    }

    fun createNewProject() {
        audioPlayer.release()
        queueManager.resetState()
        _uiState.value = _uiState.value.copy(
            currentProjectId = 0L,
            projectTitle = "New Script Project",
            scriptText = "",
            currentAudioFile = null
        )
    }

    fun loadProject(project: ProjectEntity) {
        audioPlayer.release()
        queueManager.resetState()

        val matchingVoice = _uiState.value.availableVoices.find { it.id == project.voiceName }
            ?: _uiState.value.selectedVoice

        val audioFile = project.audioFilePath?.let { File(it) }?.takeIf { it.exists() }

        _uiState.value = _uiState.value.copy(
            currentProjectId = project.id,
            projectTitle = project.title,
            scriptText = project.scriptText,
            selectedVoice = matchingVoice,
            speechSpeed = project.speechSpeed,
            pitch = project.pitch,
            pauseBetweenSentencesMs = project.pauseBetweenSentencesMs,
            currentAudioFile = audioFile
        )

        audioFile?.let { audioPlayer.loadFile(it, autoPlay = false) }
    }

    fun saveCurrentProject() {
        viewModelScope.launch {
            val state = _uiState.value
            val words = TextChunker.countWords(state.scriptText)
            val chars = TextChunker.countCharacters(state.scriptText)
            val duration = state.currentAudioFile?.let { AudioStitcher.getAudioDurationMs(it) } ?: 0L

            val entity = ProjectEntity(
                id = state.currentProjectId,
                title = state.projectTitle.ifBlank { "Untitled Script" },
                scriptText = state.scriptText,
                voiceName = state.selectedVoice?.id ?: "",
                voiceLocale = state.selectedVoice?.localeTag ?: "en-US",
                speechSpeed = state.speechSpeed,
                pitch = state.pitch,
                pauseBetweenSentencesMs = state.pauseBetweenSentencesMs,
                audioFilePath = state.currentAudioFile?.absolutePath,
                audioDurationMs = duration,
                wordCount = words,
                characterCount = chars,
                updatedAt = System.currentTimeMillis()
            )

            val savedId = repository.saveOrUpdateProject(entity)
            if (state.currentProjectId == 0L) {
                _uiState.value = _uiState.value.copy(currentProjectId = savedId)
            }
        }
    }

    fun deleteProject(project: ProjectEntity) {
        viewModelScope.launch {
            if (_uiState.value.currentProjectId == project.id) {
                createNewProject()
            }
            repository.deleteProject(project)
        }
    }

    fun deleteCurrentAudio() {
        val file = _uiState.value.currentAudioFile
        if (file != null && file.exists()) {
            file.delete()
        }
        audioPlayer.release()
        _uiState.value = _uiState.value.copy(currentAudioFile = null)
        saveCurrentProject()
    }

    // Audio Player Passthroughs
    fun togglePlayPause() = audioPlayer.togglePlayPause()
    fun seekTo(positionMs: Long) = audioPlayer.seekTo(positionMs)
    fun seekBy(deltaMs: Long) = audioPlayer.seekBy(deltaMs)
    fun setPlayerVolume(vol: Float) = audioPlayer.setVolume(vol)

    override fun onCleared() {
        super.onCleared()
        audioPlayer.release()
        ttsEngine.shutdown()
    }

    class Factory(private val app: Application) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return MainViewModel(app) as T
        }
    }
}
