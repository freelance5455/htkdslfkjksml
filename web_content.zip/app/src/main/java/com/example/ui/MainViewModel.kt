package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.MemberEntity
import com.example.data.local.ProgramEntity
import com.example.data.remote.SheetSyncManager
import com.example.data.repository.MemberRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    private val repository = MemberRepository(database.memberDao(), database.committeeDao(), application)
    private val programDao = database.programDao()
    private val syncManager = SheetSyncManager()

    val allMembers: StateFlow<List<MemberEntity>> = repository.allMembers
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allPrograms: StateFlow<List<ProgramEntity>> = programDao.getAllPrograms()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val currentView = MutableStateFlow("form") // "form", "programs", or "list" (Admin panel)
    val activeFormTab = MutableStateFlow("leader") // "leader" or "worker"

    val searchQuery = MutableStateFlow("")
    val currentTypeFilter = MutableStateFlow("all") // "all", "leader", "worker"

    val filteredRecords: StateFlow<List<MemberEntity>> = combine(
        allMembers,
        searchQuery,
        currentTypeFilter
    ) { members, query, typeFilter ->
        members.filter { item ->
            val matchesType = when (typeFilter) {
                "leader" -> item.type == "leader"
                "worker" -> item.type == "worker"
                else -> true
            }

            val q = query.trim().lowercase()
            val matchesQuery = if (q.isBlank()) true else {
                if (item.type == "leader") {
                    item.union.lowercase().contains(q) ||
                    item.ward.lowercase().contains(q) ||
                    item.sovapotiName.lowercase().contains(q) ||
                    item.sovapotiMobile.contains(q) ||
                    item.secretaryName.lowercase().contains(q) ||
                    item.secretaryMobile.contains(q) ||
                    item.otherName.lowercase().contains(q) ||
                    item.otherMobile.contains(q) ||
                    item.otherDesignation.lowercase().contains(q)
                } else {
                    item.union.lowercase().contains(q) ||
                    item.ward.lowercase().contains(q) ||
                    item.workerName.lowercase().contains(q) ||
                    item.workerDesignation.lowercase().contains(q) ||
                    item.workerMobile.contains(q)
                }
            }

            matchesType && matchesQuery
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _isAdminLoggedIn = MutableStateFlow(false)
    val isAdminLoggedIn: StateFlow<Boolean> = _isAdminLoggedIn.asStateFlow()

    private val _alertMessage = MutableStateFlow<Pair<String, String>?>(null) // message to type ("success" / "danger")
    val alertMessage: StateFlow<Pair<String, String>?> = _alertMessage.asStateFlow()

    private val _webhookUrl = MutableStateFlow(repository.getWebhookUrl())
    val webhookUrl: StateFlow<String> = _webhookUrl.asStateFlow()

    private val _isSyncing = MutableStateFlow(false)
    val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    init {
        viewModelScope.launch {
            if (programDao.getCount() == 0) {
                seedInitialPrograms()
            }
        }
    }

    private suspend fun seedInitialPrograms() {
        val samplePrograms = listOf(
            ProgramEntity(
                title = "ঐতিহাসিক ৭ই মার্চ উদযাপন ও আলোচনা সভা",
                unit = "চারঘাট উপজেলা ছাত্রলীগ",
                date = "৭ মার্চ, ২০২৬",
                time = "বিকাল ৩:৩০ টা",
                location = "চারঘাট পাইলট উচ্চ বিদ্যালয় প্রাঙ্গণ",
                description = "জাতির পিতা বঙ্গবন্ধু শেখ মুজিবুর রহমানের ঐতিহাসিক ৭ই মার্চের ভাষণের তাৎপর্য শীর্ষক আলোচনা সভা, চিত্রাঙ্কন প্রতিযোগিতা ও বিশেষ র‍্যালি অনুষ্ঠিত হয়েছে।",
                photoUri = "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800",
                videoUri = "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
                status = "সম্পন্ন",
                authorName = "চারঘাট উপজেলা ছাত্রলীগ"
            ),
            ProgramEntity(
                title = "উপজেলাব্যাপী ফলজ ও বনজ বৃক্ষরোপণ কর্মসূচি",
                unit = "চারঘাট পৌরসভা ছাত্রলীগ",
                date = "১৬ মে, ২০২৬",
                time = "সকাল ১০:০০ টা",
                location = "চারঘাট পদ্মা নদীর তীর ও পৌর এলাকা",
                description = "পরিবেশ সংরক্ষণ ও সবুজায়নের লক্ষ্যে চারঘাট পৌরসভা ছাত্রলীগের উদ্যোগে ৫ শতাধিক বিভিন্ন ফলজ, বনজ ও ওষধি গাছের চারা রোপণ ও বিতরণ করা হয়েছে।",
                photoUri = "https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=800",
                videoUri = "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
                status = "সম্পন্ন",
                authorName = "চারঘাট পৌরসভা"
            ),
            ProgramEntity(
                title = "বিনামূল্যে রক্তের গ্রুপ নির্ণয় ও স্বেচ্ছায় রক্তদান ক্যাম্প",
                unit = "ইউসুফপুর ইউনিয়ন ছাত্রলীগ",
                date = "আসন্ন আগামী শুক্রবার",
                time = "সকাল ৯:০০ টা থেকে বিকাল ৪:০০ টা",
                location = "ইউসুফপুর ইউনিয়ন পরিষদ প্রাঙ্গণ",
                description = "উপজেলার সর্বস্তরের সাধারণ শিক্ষার্থী ও নাগরিকদের জন্য বিনামূল্যে রক্তের গ্রুপ পরীক্ষা ও জরুরি রক্তের প্রয়োজনে ডোনার তালিকাভুক্তি কর্মসূচি।",
                photoUri = "https://images.unsplash.com/photo-1615461066841-6116e61058f4?w=800",
                videoUri = "",
                status = "আসন্ন",
                authorName = "ইউসুফপুর ইউনিয়ন"
            )
        )
        samplePrograms.forEach { programDao.insertProgram(it) }
    }

    fun refreshData(onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            _isRefreshing.value = true
            kotlinx.coroutines.delay(650)
            _isRefreshing.value = false
            showAlert("তথ্য সফলভাবে রিফ্রেশ ও সিঙ্ক হয়েছে!", "success")
            onComplete()
        }
    }

    fun showAlert(message: String, type: String = "success") {
        _alertMessage.value = Pair(message, type)
    }

    fun clearAlert() {
        _alertMessage.value = null
    }

    fun verifyAdminPassword(password: String): Boolean {
        val ok = password.trim() == repository.getAdminPin()
        if (ok) {
            _isAdminLoggedIn.value = true
            currentView.value = "list"
            showAlert("এডমিন হিসেবে সফলভাবে লগইন করেছেন!", "success")
        }
        return ok
    }

    fun logoutAdmin() {
        _isAdminLoggedIn.value = false
        currentView.value = "form"
        showAlert("আপনি এডমিন প্যানেল থেকে লগআউট হয়েছেন।", "success")
    }

    fun changeAdminPin(newPin: String) {
        if (newPin.isNotBlank()) {
            repository.setAdminPin(newPin)
            showAlert("এডমিন পাসওয়ার্ড সফলভাবে পরিবর্তন করা হয়েছে!", "success")
        }
    }

    fun saveWebhookUrl(url: String) {
        repository.setWebhookUrl(url)
        _webhookUrl.value = url.trim()
        showAlert("গুগল শিট URL সেভ করা হয়েছে!", "success")
    }

    fun testWebhook(url: String) {
        viewModelScope.launch {
            _isSyncing.value = true
            val result = syncManager.testConnection(url)
            _isSyncing.value = false
            result.onSuccess { msg ->
                showAlert(msg, "success")
            }.onFailure { err ->
                showAlert("কানেকশন টেস্ট ব্যর্থ: ${err.message}", "danger")
            }
        }
    }

    fun insertMember(member: MemberEntity) {
        viewModelScope.launch {
            val id = repository.insertMember(member)
            val url = _webhookUrl.value
            if (url.isNotBlank()) {
                val memberWithId = member.copy(id = id)
                syncManager.syncMember(url, memberWithId)
                repository.markSynced(id, true)
            }
            showAlert("আপনার তথ্য সফলভাবে জমা নেওয়া হয়েছে!", "success")
        }
    }

    fun deleteRecord(member: MemberEntity) {
        viewModelScope.launch {
            repository.deleteMember(member)
            showAlert("তথ্যটি সফলভাবে মুছে ফেলা হয়েছে!", "danger")
        }
    }

    fun insertProgram(program: ProgramEntity) {
        viewModelScope.launch {
            programDao.insertProgram(program)
            showAlert("কর্মসূচি ও মিডিয়া সফলভাবে যুক্ত হয়েছে!", "success")
        }
    }

    fun deleteProgram(program: ProgramEntity) {
        viewModelScope.launch {
            programDao.deleteProgram(program)
            showAlert("কর্মসূচি মুছে ফেলা হয়েছে!", "danger")
        }
    }

    fun loadSampleData() {
        viewModelScope.launch {
            repository.loadSampleData()
            showAlert("নমুনা ডাটা লোড করা হয়েছে!", "success")
        }
    }

    fun clearAllData() {
        viewModelScope.launch {
            repository.clearAll()
            showAlert("সকল তথ্য মুছে ফেলা হয়েছে!", "danger")
        }
    }

    fun getCsvContent(): String {
        return repository.generateCsv(allMembers.value)
    }

    fun getFilteredCsvContent(): String {
        return repository.generateCsv(filteredRecords.value)
    }
}
