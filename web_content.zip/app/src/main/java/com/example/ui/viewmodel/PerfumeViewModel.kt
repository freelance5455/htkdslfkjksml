package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.model.MesVendasResumo
import com.example.data.model.Perfume
import com.example.data.model.ProdutoAgrupado
import com.example.data.model.Venda
import com.example.data.repository.PerfumeRepository
import com.example.util.ValidadeNivel
import com.example.util.ValidadeUtil
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class MainTab(val titulo: String) {
    ESTOQUE("📦 Estoque"),
    VENDAS("🛒 Frente de Caixa"),
    ALERTAS("⏰ Validade")
}

enum class StockFilter(val label: String) {
    TODOS("Todos"),
    BAIXO_ESTOQUE("Estoque Baixo (≤2)"),
    A_VENCER("Vencem em 6 meses"),
    VENCIDOS("Vencidos")
}

enum class ScannerTarget {
    CADASTRO,
    VENDA
}

class PerfumeViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application, viewModelScope)
    private val repository = PerfumeRepository(database.perfumeDao(), database.vendaDao())

    // Tabs & Navigation
    private val _currentTab = MutableStateFlow(MainTab.ESTOQUE)
    val currentTab: StateFlow<MainTab> = _currentTab.asStateFlow()

    fun selectTab(tab: MainTab) {
        _currentTab.value = tab
    }

    // Search & Filter
    val searchQuery = MutableStateFlow("")
    val selectedFilter = MutableStateFlow(StockFilter.TODOS)

    val allPerfumes: StateFlow<List<Perfume>> = searchQuery
        .flatMapLatest { query -> repository.searchPerfumes(query) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Produtos agrupados por código EAN (somando quantidade total e mantendo a lista de lotes/validades)
    val produtosAgrupados: StateFlow<List<ProdutoAgrupado>> = allPerfumes.combine(MutableStateFlow(Unit)) { list, _ ->
        list.groupBy { it.codigo.trim() }.map { (codigo, lotes) ->
            val primeiro = lotes.first()
            val estoqueTotal = lotes.sumOf { it.estoque }
            val lotesOrdenados = lotes.sortedBy { it.validade }
            val maisCritico = lotesOrdenados.firstOrNull()
            ProdutoAgrupado(
                codigo = codigo,
                nome = primeiro.nome,
                marca = primeiro.marca,
                precoVenda = primeiro.venda,
                custo = primeiro.custo,
                estoqueTotal = estoqueTotal,
                lotes = lotesOrdenados,
                loteMaisCritico = maisCritico,
                statusMaisCritico = maisCritico?.let { ValidadeUtil.calcularValidade(it.validade) }
            )
        }.sortedBy { it.nome }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredProdutosAgrupados: StateFlow<List<ProdutoAgrupado>> = combine(
        produtosAgrupados,
        selectedFilter
    ) { agrupados, filter ->
        when (filter) {
            StockFilter.TODOS -> agrupados
            StockFilter.BAIXO_ESTOQUE -> agrupados.filter { it.estoqueTotal <= 2 }
            StockFilter.A_VENCER -> agrupados.filter { it.temLoteAlerta }
            StockFilter.VENCIDOS -> agrupados.filter { it.temLoteVencido }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Alertas individuais por lote de produto
    val vencidosList: StateFlow<List<Perfume>> = allPerfumes.combine(MutableStateFlow(Unit)) { list, _ ->
        list.filter { ValidadeUtil.calcularValidade(it.validade).nivel == ValidadeNivel.VENCIDO }
            .sortedBy { it.validade }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val aVencerList: StateFlow<List<Perfume>> = allPerfumes.combine(MutableStateFlow(Unit)) { list, _ ->
        list.filter { ValidadeUtil.calcularValidade(it.validade).nivel == ValidadeNivel.A_VENCER_6_MESES }
            .sortedBy { it.validade }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalAlertasCount: StateFlow<Int> = combine(vencidosList, aVencerList) { venc, aVenc ->
        venc.size + aVenc.size
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // Sales Data
    val allVendas: StateFlow<List<Venda>> = repository.allVendas
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalVendasValor: StateFlow<Double?> = repository.totalVendasValor
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalVendasCount: StateFlow<Int> = repository.totalVendasCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // CONTROLE DE VENDAS MÊS A MÊS
    private val sdfAnoMes = SimpleDateFormat("yyyy-MM", Locale.getDefault())
    private val sdfRotuloMes = SimpleDateFormat("MMMM 'de' yyyy", Locale("pt", "BR"))

    val mesSelecionado = MutableStateFlow("TODOS")

    val mesesDisponiveis: StateFlow<List<String>> = allVendas.combine(MutableStateFlow(Unit)) { vendas, _ ->
        val meses = vendas.map { sdfAnoMes.format(Date(it.dataHora)) }.distinct().sortedDescending()
        listOf("TODOS") + meses
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), listOf("TODOS"))

    val vendasFiltradasPorMes: StateFlow<List<Venda>> = combine(allVendas, mesSelecionado) { vendas, mes ->
        if (mes == "TODOS") {
            vendas
        } else {
            vendas.filter { sdfAnoMes.format(Date(it.dataHora)) == mes }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val resumoMensalList: StateFlow<List<MesVendasResumo>> = allVendas.combine(MutableStateFlow(Unit)) { vendas, _ ->
        vendas.groupBy { sdfAnoMes.format(Date(it.dataHora)) }
            .map { (anoMes, lista) ->
                val dataAmostra = lista.firstOrNull()?.dataHora ?: System.currentTimeMillis()
                val rotulo = sdfRotuloMes.format(Date(dataAmostra)).replaceFirstChar { it.uppercase() }
                MesVendasResumo(
                    chaveAnoMes = anoMes,
                    rotuloFormatado = rotulo,
                    totalFaturado = lista.sumOf { it.total },
                    totalLucro = lista.sumOf { it.lucro },
                    totalItensVendidos = lista.sumOf { it.quantidade },
                    totalTransacoes = lista.size
                )
            }.sortedByDescending { it.chaveAnoMes }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val kpiMesSelecionado: StateFlow<MesVendasResumo?> = combine(
        vendasFiltradasPorMes,
        mesSelecionado
    ) { vendas, mes ->
        if (vendas.isEmpty()) null
        else {
            val rotulo = if (mes == "TODOS") "Geral (Todos os Meses)"
            else sdfRotuloMes.format(Date(vendas.first().dataHora)).replaceFirstChar { it.uppercase() }
            MesVendasResumo(
                chaveAnoMes = mes,
                rotuloFormatado = rotulo,
                totalFaturado = vendas.sumOf { it.total },
                totalLucro = vendas.sumOf { it.lucro },
                totalItensVendidos = vendas.sumOf { it.quantidade },
                totalTransacoes = vendas.size
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // PDV / Frente de Caixa State
    val vendaCodigo = MutableStateFlow("")
    val vendaQuantidade = MutableStateFlow(1)
    val vendaLoteSelecionadoId = MutableStateFlow<Long?>(null)

    // Produto agrupado selecionado na venda
    val vendaProdutoEncontrado: StateFlow<ProdutoAgrupado?> = combine(vendaCodigo, produtosAgrupados) { cod, list ->
        if (cod.isBlank()) null else list.find { it.codigo.equals(cod.trim(), ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Lotes disponíveis para o produto digitado/bipado
    val lotesDoProdutoVenda: StateFlow<List<Perfume>> = combine(vendaCodigo, allPerfumes) { cod, perfumes ->
        if (cod.isBlank()) emptyList()
        else perfumes.filter { it.codigo.equals(cod.trim(), ignoreCase = true) && it.estoque > 0 }
            .sortedBy { it.validade }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _vendaFeedback = MutableStateFlow<String?>(null)
    val vendaFeedback: StateFlow<String?> = _vendaFeedback.asStateFlow()

    private val _isVendaError = MutableStateFlow(false)
    val isVendaError: StateFlow<Boolean> = _isVendaError.asStateFlow()

    fun updateVendaCodigo(codigo: String) {
        vendaCodigo.value = codigo
        _vendaFeedback.value = null
        vendaLoteSelecionadoId.value = null // Reseta para auto-selecionar o lote mais próximo
    }

    fun selectVendaLote(loteId: Long?) {
        vendaLoteSelecionadoId.value = loteId
    }

    fun updateVendaQuantidade(qtd: Int) {
        vendaQuantidade.value = qtd.coerceAtLeast(1)
    }

    fun finalizarVenda() {
        val codigo = vendaCodigo.value.trim()
        val qtd = vendaQuantidade.value
        val loteId = vendaLoteSelecionadoId.value

        if (codigo.isBlank()) {
            _vendaFeedback.value = "Digite ou bipe o código do perfume"
            _isVendaError.value = true
            return
        }

        viewModelScope.launch {
            val result = repository.realizarVenda(codigo, qtd, loteId)
            result.onSuccess { venda ->
                val valDesc = if (venda.validadeVendida.isNotBlank()) " (Validade: ${venda.validadeVendida})" else ""
                _vendaFeedback.value = "Venda confirmada! Baixa de ${venda.quantidade} un. em ${venda.perfumeNome}$valDesc."
                _isVendaError.value = false
                vendaCodigo.value = ""
                vendaQuantidade.value = 1
                vendaLoteSelecionadoId.value = null
            }.onFailure { err ->
                _vendaFeedback.value = err.message ?: "Erro ao registrar venda"
                _isVendaError.value = true
            }
        }
    }

    fun clearVendaFeedback() {
        _vendaFeedback.value = null
    }

    // EDIÇÃO E CANCELAMENTO DE VENDAS
    private val _isEditVendaModalOpen = MutableStateFlow(false)
    val isEditVendaModalOpen: StateFlow<Boolean> = _isEditVendaModalOpen.asStateFlow()

    private val _vendaSendoEditada = MutableStateFlow<Venda?>(null)
    val vendaSendoEditada: StateFlow<Venda?> = _vendaSendoEditada.asStateFlow()

    fun abrirEdicaoVenda(venda: Venda) {
        _vendaSendoEditada.value = venda
        _isEditVendaModalOpen.value = true
    }

    fun fecharEdicaoVenda() {
        _isEditVendaModalOpen.value = false
        _vendaSendoEditada.value = null
    }

    fun salvarEdicaoVenda(vendaId: Long, novaQtd: Int, novoPreco: Double) {
        viewModelScope.launch {
            val res = repository.editarVenda(vendaId, novaQtd, novoPreco)
            res.onSuccess {
                _vendaFeedback.value = "Venda #${vendaId} corrigida com sucesso! Estoque do lote ajustado."
                _isVendaError.value = false
                fecharEdicaoVenda()
            }.onFailure { err ->
                _vendaFeedback.value = err.message ?: "Erro ao editar venda"
                _isVendaError.value = true
            }
        }
    }

    fun cancelarVenda(vendaId: Long) {
        viewModelScope.launch {
            val res = repository.cancelarVenda(vendaId)
            res.onSuccess {
                _vendaFeedback.value = "Venda #${vendaId} cancelada! Itens estornados ao estoque do lote."
                _isVendaError.value = false
                fecharEdicaoVenda()
            }.onFailure { err ->
                _vendaFeedback.value = err.message ?: "Erro ao cancelar venda"
                _isVendaError.value = true
            }
        }
    }

    // Modal Add / Edit Perfume ou Novo Lote
    private val _isAddEditModalOpen = MutableStateFlow(false)
    val isAddEditModalOpen: StateFlow<Boolean> = _isAddEditModalOpen.asStateFlow()

    private val _editingPerfume = MutableStateFlow<Perfume?>(null)
    val editingPerfume: StateFlow<Perfume?> = _editingPerfume.asStateFlow()

    fun openAddPerfume(codigoPreenchido: String? = null) {
        _editingPerfume.value = null
        if (!codigoPreenchido.isNullOrBlank()) {
            _scannedCodeForCadastro.value = codigoPreenchido
        }
        _isAddEditModalOpen.value = true
    }

    fun openEditPerfume(perfume: Perfume) {
        _editingPerfume.value = perfume
        _isAddEditModalOpen.value = true
    }

    fun closeAddEditModal() {
        _isAddEditModalOpen.value = false
        _editingPerfume.value = null
    }

    fun savePerfume(
        id: Long = 0,
        codigo: String,
        nome: String,
        marca: String,
        custo: Double,
        venda: Double,
        estoque: Int,
        validade: String,
        numeroLote: String = ""
    ) {
        viewModelScope.launch {
            val item = Perfume(
                id = id,
                codigo = codigo.trim(),
                nome = nome.trim(),
                marca = marca.trim(),
                custo = custo,
                venda = venda,
                estoque = estoque.coerceAtLeast(0),
                validade = validade.trim(),
                numeroLote = numeroLote.trim()
            )
            repository.savePerfume(item)
            closeAddEditModal()
        }
    }

    fun deletePerfumeLote(id: Long) {
        viewModelScope.launch {
            repository.deletePerfume(id)
        }
    }

    fun adjustStock(id: Long, delta: Int) {
        viewModelScope.launch {
            repository.adjustStock(id, delta)
        }
    }

    // Barcode Scanner Modal
    private val _isScannerOpen = MutableStateFlow(false)
    val isScannerOpen: StateFlow<Boolean> = _isScannerOpen.asStateFlow()

    private val _scannerTarget = MutableStateFlow(ScannerTarget.VENDA)
    val scannerTarget: StateFlow<ScannerTarget> = _scannerTarget.asStateFlow()

    private val _scannedCodeForCadastro = MutableStateFlow<String?>(null)
    val scannedCodeForCadastro: StateFlow<String?> = _scannedCodeForCadastro.asStateFlow()

    fun openScanner(target: ScannerTarget) {
        _scannerTarget.value = target
        _isScannerOpen.value = true
    }

    fun closeScanner() {
        _isScannerOpen.value = false
    }

    fun onBarcodeScanned(code: String) {
        when (_scannerTarget.value) {
            ScannerTarget.VENDA -> {
                updateVendaCodigo(code)
            }
            ScannerTarget.CADASTRO -> {
                _scannedCodeForCadastro.value = code
            }
        }
        closeScanner()
    }

    fun clearScannedCodeForCadastro() {
        _scannedCodeForCadastro.value = null
    }

    fun resetToDefaults() {
        viewModelScope.launch {
            repository.resetInitialData()
        }
    }
}
