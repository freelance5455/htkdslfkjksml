package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AiEngineType
import com.example.data.model.AssistantPersona
import com.example.data.model.GeminiModelOption
import com.example.data.model.VoicePreset
import com.example.speech.AiVoicesCatalog
import com.example.ui.MainViewModel
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NexusBackground
import com.example.ui.theme.NexusBorder
import com.example.ui.theme.NexusCodeBackground
import com.example.ui.theme.NexusCyan
import com.example.ui.theme.NexusCyanDark
import com.example.ui.theme.NexusEmerald
import com.example.ui.theme.NexusSurface
import com.example.ui.theme.NexusSurfaceVariant
import com.example.ui.theme.NexusTextPrimary
import com.example.ui.theme.NexusTextSecondary
import com.example.ui.theme.NexusTextTertiary
import com.example.ui.theme.NexusViolet
import com.example.ui.theme.NexusVioletLight
import com.example.ui.theme.SpaceGroteskFontFamily

@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val availableVoices by viewModel.ttsManager.availableVoices.collectAsStateWithLifecycle()
    val activeVoiceLabel by viewModel.ttsManager.activeVoiceLabel.collectAsStateWithLifecycle()

    var nameInput by remember(settings.assistantName) { mutableStateOf(settings.assistantName) }
    var customModelInput by remember(settings.customGeminiModelId) { mutableStateOf(settings.customGeminiModelId) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NexusBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // ChatGPT / Claude Style Settings Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(44.dp)
                    .testTag("settings_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Назад",
                    tint = NexusTextPrimary
                )
            }
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "Настройки",
                fontFamily = SpaceGroteskFontFamily,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                color = NexusTextPrimary
            )
        }

        HorizontalDivider(thickness = 0.8.dp, color = NexusBorder)

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 700.dp)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 18.dp, vertical = 16.dp)
            ) {
                // SECTION 1: PROFILE & PERSONA
                SettingsSectionHeader("ПРОФИЛЬ И ПЕРСОНАЛИЗАЦИЯ")
                SettingsGroupContainer {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Имя ассистента",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = NexusTextSecondary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = nameInput,
                            onValueChange = {
                                nameInput = it
                                viewModel.updateAssistantName(it)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("assistant_name_input"),
                            shape = RoundedCornerShape(12.dp),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = NexusCodeBackground,
                                unfocusedContainerColor = NexusCodeBackground,
                                focusedBorderColor = NexusCyan,
                                unfocusedBorderColor = NexusBorder,
                                focusedTextColor = NexusTextPrimary,
                                unfocusedTextColor = NexusTextPrimary
                            ),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("NEXUS", "Алиса", "Аврора", "Гелиос").forEach { preset ->
                                val isCurrent = nameInput == preset
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (isCurrent) NexusCyanDark else NexusSurfaceVariant)
                                        .border(
                                            0.8.dp,
                                            if (isCurrent) NexusCyan else NexusBorder,
                                            RoundedCornerShape(10.dp)
                                        )
                                        .clickable {
                                            nameInput = preset
                                            viewModel.updateAssistantName(preset)
                                        }
                                        .padding(horizontal = 11.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = preset,
                                        fontSize = 12.sp,
                                        color = if (isCurrent) NexusVioletLight else NexusTextSecondary
                                    )
                                }
                            }
                        }
                    }

                    HorizontalDivider(thickness = 0.8.dp, color = NexusBorder)

                    AssistantPersona.values().forEachIndexed { idx, persona ->
                        val isSelected = settings.persona == persona
                        SettingsRadioRow(
                            title = persona.title,
                            subtitle = persona.description,
                            selected = isSelected,
                            onClick = { viewModel.updatePersona(persona) }
                        )
                        if (idx < AssistantPersona.values().lastIndex) {
                            HorizontalDivider(thickness = 0.8.dp, color = NexusBorder)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(22.dp))

                // SECTION 2: GEMINI MODEL & ENGINE MODE
                SettingsSectionHeader("МОДЕЛЬ GEMINI И АВТОНОМНОСТЬ")
                SettingsGroupContainer {
                    GeminiModelOption.values().forEachIndexed { idx, modelOption ->
                        val isSelected = settings.geminiModel == modelOption
                        SettingsRadioRow(
                            title = modelOption.title,
                            subtitle = modelOption.description,
                            badge = modelOption.badge,
                            selected = isSelected,
                            onClick = { viewModel.updateGeminiModel(modelOption) }
                        )
                        if (idx < GeminiModelOption.values().lastIndex || settings.geminiModel == GeminiModelOption.CUSTOM) {
                            HorizontalDivider(thickness = 0.8.dp, color = NexusBorder)
                        }
                    }

                    AnimatedVisibility(visible = settings.geminiModel == GeminiModelOption.CUSTOM) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "Свой идентификатор модели:",
                                fontSize = 12.sp,
                                color = NexusTextSecondary
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = customModelInput,
                                onValueChange = {
                                    customModelInput = it
                                    viewModel.updateCustomGeminiModelId(it)
                                },
                                placeholder = {
                                    Text(
                                        text = "Например: gemini-3.8-flash",
                                        fontSize = 12.sp,
                                        color = NexusTextTertiary
                                    )
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("custom_gemini_model_input"),
                                shape = RoundedCornerShape(12.dp),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = NexusCodeBackground,
                                    unfocusedContainerColor = NexusCodeBackground,
                                    focusedBorderColor = NexusCyan,
                                    unfocusedBorderColor = NexusBorder,
                                    focusedTextColor = NexusTextPrimary,
                                    unfocusedTextColor = NexusTextPrimary
                                ),
                                singleLine = true
                            )
                        }
                    }

                    HorizontalDivider(thickness = 0.8.dp, color = NexusBorder)

                    AiEngineType.values().forEachIndexed { idx, engine ->
                        val isSelected = settings.engineType == engine
                        SettingsRadioRow(
                            title = engine.title,
                            subtitle = engine.subtitle,
                            badge = if (engine.isOffline) "ОФЛАЙН" else "ОНЛАЙН",
                            selected = isSelected,
                            onClick = { viewModel.updateEngineType(engine) }
                        )
                        if (idx < AiEngineType.values().lastIndex) {
                            HorizontalDivider(thickness = 0.8.dp, color = NexusBorder)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(22.dp))

                // SECTION 3: VOICE ASSISTANT & TTS
                SettingsSectionHeader("ГОЛОСОВОЙ ПОМОЩНИК И ОЗВУЧИВАНИЕ")
                SettingsGroupContainer {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Активный голос",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = NexusTextPrimary
                            )
                            Text(
                                text = activeVoiceLabel,
                                fontSize = 12.sp,
                                color = NexusEmerald
                            )
                        }
                        IconButton(
                            onClick = {
                                viewModel.speakText("Привет! Я ${settings.assistantName}. Голос настроен и готов к работе.")
                            },
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(NexusCyanDark)
                                .testTag("test_voice_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Тест речи",
                                tint = NexusVioletLight,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    HorizontalDivider(thickness = 0.8.dp, color = NexusBorder)

                    VoicePreset.values().forEachIndexed { idx, preset ->
                        val isSelected = settings.voicePreset == preset
                        SettingsRadioRow(
                            title = preset.title,
                            subtitle = preset.description,
                            selected = isSelected,
                            onClick = { viewModel.updateVoicePreset(preset) }
                        )
                        if (idx < VoicePreset.values().lastIndex) {
                            HorizontalDivider(thickness = 0.8.dp, color = NexusBorder)
                        }
                    }

                    HorizontalDivider(thickness = 0.8.dp, color = NexusBorder)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Нейросетевой голос Gemini AI",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = NexusTextPrimary
                            )
                            Text(
                                text = "Облачный голос (при задержке >3с — мгновенный локальный)",
                                fontSize = 11.5.sp,
                                color = NexusTextTertiary
                            )
                        }
                        Switch(
                            checked = settings.useAiNeuralVoice,
                            onCheckedChange = { viewModel.updateUseAiNeuralVoice(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = NexusVioletLight,
                                checkedTrackColor = NexusCyanDark,
                                uncheckedTrackColor = NexusSurfaceVariant
                            )
                        )
                    }

                    AnimatedVisibility(visible = settings.useAiNeuralVoice) {
                        Column {
                            HorizontalDivider(thickness = 0.8.dp, color = NexusBorder)
                            AiVoicesCatalog.voices.forEachIndexed { idx, aiVoice ->
                                val isSelected = settings.aiTtsVoiceId == aiVoice.id
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { viewModel.updateAiTtsVoiceId(aiVoice.id) }
                                        .padding(horizontal = 16.dp, vertical = 11.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = aiVoice.title,
                                            fontSize = 13.sp,
                                            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                                            color = if (isSelected) NexusVioletLight else NexusTextPrimary
                                        )
                                        Text(
                                            text = aiVoice.style,
                                            fontSize = 11.sp,
                                            color = NexusTextTertiary
                                        )
                                    }
                                    IconButton(
                                        onClick = {
                                            viewModel.updateAiTtsVoiceId(aiVoice.id)
                                            viewModel.speakText(
                                                "Привет! Это звучит нейросетевой голос.",
                                                forceNeural = true
                                            )
                                        },
                                        modifier = Modifier.size(34.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                            contentDescription = "Прослушать голос",
                                            tint = if (isSelected) NexusCyan else NexusTextSecondary,
                                            modifier = Modifier.size(17.dp)
                                        )
                                    }
                                }
                                if (idx < AiVoicesCatalog.voices.lastIndex) {
                                    HorizontalDivider(thickness = 0.8.dp, color = NexusBorder)
                                }
                            }
                        }
                    }

                    HorizontalDivider(thickness = 0.8.dp, color = NexusBorder)

                    // System device voices
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Системные голоса (${availableVoices.size})",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = NexusTextSecondary
                        )
                        IconButton(
                            onClick = { viewModel.refreshDeviceVoices() },
                            modifier = Modifier.size(30.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Обновить голоса",
                                tint = NexusCyan,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    val isAutoVoice = settings.selectedVoiceName.isBlank()
                    SettingsRadioRow(
                        title = "Автовыбор под профиль «${settings.voicePreset.title.substringBefore(" (")}»",
                        subtitle = "Автоматический системный голос устройства",
                        selected = isAutoVoice,
                        onClick = { viewModel.updateSelectedVoiceName("") }
                    )

                    availableVoices.take(8).forEach { voice ->
                        HorizontalDivider(thickness = 0.8.dp, color = NexusBorder)
                        val isVoiceSelected = settings.selectedVoiceName == voice.name
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.updateSelectedVoiceName(voice.name) }
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = voice.displayName,
                                    fontSize = 13.sp,
                                    fontWeight = if (isVoiceSelected) FontWeight.SemiBold else FontWeight.Normal,
                                    color = if (isVoiceSelected) NexusVioletLight else NexusTextPrimary
                                )
                                Text(
                                    text = "${voice.localeTag} • ${voice.name}",
                                    fontSize = 10.5.sp,
                                    fontFamily = JetBrainsMonoFontFamily,
                                    color = NexusTextTertiary
                                )
                            }
                            IconButton(
                                onClick = {
                                    viewModel.updateSelectedVoiceName(voice.name)
                                    viewModel.speakText("Проверка выбранного системного голоса.")
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                    contentDescription = "Прослушать системный голос",
                                    tint = NexusCyan,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    HorizontalDivider(thickness = 0.8.dp, color = NexusBorder)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Авто-озвучивание ответов",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                color = NexusTextPrimary
                            )
                            Text(
                                text = "Озвучивать ответы сразу после генерации",
                                fontSize = 11.5.sp,
                                color = NexusTextTertiary
                            )
                        }
                        Switch(
                            checked = settings.autoTts,
                            onCheckedChange = { viewModel.updateAutoTts(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = NexusVioletLight,
                                checkedTrackColor = NexusCyanDark,
                                uncheckedTrackColor = NexusSurfaceVariant
                            )
                        )
                    }

                    HorizontalDivider(thickness = 0.8.dp, color = NexusBorder)

                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Скорость речи: ${String.format("%.1fx", settings.voiceSpeed)}",
                            fontSize = 12.5.sp,
                            color = NexusTextSecondary
                        )
                        Slider(
                            value = settings.voiceSpeed,
                            onValueChange = { viewModel.updateVoiceSpeed(it) },
                            valueRange = 0.5f..2.0f,
                            steps = 14,
                            colors = SliderDefaults.colors(
                                thumbColor = NexusCyan,
                                activeTrackColor = NexusCyan,
                                inactiveTrackColor = NexusBorder
                            )
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Высота тона: ${String.format("%.2fx", settings.voicePitch)}",
                            fontSize = 12.5.sp,
                            color = NexusTextSecondary
                        )
                        Slider(
                            value = settings.voicePitch,
                            onValueChange = { viewModel.updateVoicePitch(it) },
                            valueRange = 0.5f..1.5f,
                            steps = 19,
                            colors = SliderDefaults.colors(
                                thumbColor = NexusViolet,
                                activeTrackColor = NexusViolet,
                                inactiveTrackColor = NexusBorder
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(22.dp))

                // SECTION 4: SYSTEM INFO
                SettingsSectionHeader("О СИСТЕМЕ И УСТРОЙСТВЕ")
                SettingsGroupContainer {
                    val infoRows = listOf(
                        "Модель ИИ" to settings.effectiveGeminiModelTitle(),
                        "Голосовой профиль" to settings.voicePreset.title.substringBefore(" ("),
                        "Офлайн-движок" to "NEXUS Neural (Helio G100)",
                        "Оперативная память" to "8 ГБ LPDDR4X"
                    )
                    infoRows.forEachIndexed { idx, (label, value) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = label, fontSize = 13.sp, color = NexusTextSecondary)
                            Text(
                                text = value,
                                fontSize = 12.5.sp,
                                fontFamily = JetBrainsMonoFontFamily,
                                color = NexusTextPrimary
                            )
                        }
                        if (idx < infoRows.lastIndex) {
                            HorizontalDivider(thickness = 0.8.dp, color = NexusBorder)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun SettingsSectionHeader(title: String) {
    Text(
        text = title,
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
        color = NexusTextTertiary,
        modifier = Modifier.padding(start = 6.dp, bottom = 8.dp)
    )
}

@Composable
private fun SettingsGroupContainer(content: @Composable () -> Unit) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = NexusSurface,
        border = BorderStroke(0.8.dp, NexusBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            content()
        }
    }
}

@Composable
private fun SettingsRadioRow(
    title: String,
    subtitle: String,
    badge: String? = null,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = title,
                    fontSize = 14.sp,
                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                    color = if (selected) NexusVioletLight else NexusTextPrimary
                )
                if (badge != null) {
                    Text(
                        text = badge,
                        fontSize = 9.5.sp,
                        fontFamily = JetBrainsMonoFontFamily,
                        color = NexusTextSecondary,
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(NexusSurfaceVariant)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                fontSize = 11.5.sp,
                color = NexusTextSecondary
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        if (selected) {
            Icon(
                imageVector = Icons.Default.Check,
                contentDescription = null,
                tint = NexusCyan,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}
