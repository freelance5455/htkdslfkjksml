package com.example.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.VoiceLanguage
import com.example.ui.theme.XtraAlertRed
import com.example.ui.theme.XtraCardBorder
import com.example.ui.theme.XtraCardDark
import com.example.ui.theme.XtraCyanGlow
import com.example.ui.theme.XtraCyanPrimary
import com.example.ui.theme.XtraDarkNavyBg
import com.example.ui.theme.XtraNeonGreen
import com.example.ui.theme.XtraSurfaceDark
import com.example.ui.theme.XtraTextHigh
import com.example.ui.theme.XtraTextMed
import com.example.ui.theme.XtraWarningGold
import com.example.viewmodel.MainViewModel

@Composable
fun SettingsScreen(viewModel: MainViewModel) {
    val selectedLanguage by viewModel.selectedLanguage.collectAsState()
    val speechSpeed by viewModel.speechSpeed.collectAsState()
    val speechPitch by viewModel.speechPitch.collectAsState()

    val scrollState = rememberScrollState()

    // Permission request launchers
    val micPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) viewModel.voiceManager.speak("Microphone access authorized.")
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) viewModel.voiceManager.speak("Camera access authorized.")
    }

    val contactsPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) viewModel.voiceManager.speak("Contacts access authorized.")
    }

    val callPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) viewModel.voiceManager.speak("Call phone permission authorized.")
    }

    val smsPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) viewModel.voiceManager.speak("SMS permission authorized.")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(XtraDarkNavyBg)
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("settings_screen")
    ) {
        // Header
        Column {
            Text(
                text = "SYSTEM CONFIGURATION & PRIVACY",
                color = XtraCyanGlow,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )
            Text(
                text = "Settings & Security",
                color = XtraTextHigh,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 1. Language Selection Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = XtraCardDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, XtraCardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Language,
                        contentDescription = null,
                        tint = XtraCyanPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "VOICE & ASSISTANT LANGUAGE",
                        color = XtraCyanPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    VoiceLanguage.values().forEach { lang ->
                        val isSelected = selectedLanguage == lang
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) XtraCyanPrimary.copy(alpha = 0.2f) else XtraSurfaceDark,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) XtraCyanPrimary else XtraCardBorder
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { viewModel.setLanguage(lang) }
                                .testTag("lang_btn_${lang.name}")
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(vertical = 12.dp, horizontal = 4.dp)
                            ) {
                                Text(
                                    text = lang.displayName,
                                    color = if (isSelected) XtraCyanPrimary else XtraTextHigh,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                if (isSelected) {
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        tint = XtraCyanPrimary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 2. Voice Synthesizer Controls
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = XtraCardDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, XtraCardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.RecordVoiceOver,
                            contentDescription = null,
                            tint = XtraCyanPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "VOICE SYNTHESIS & ACOUSTICS",
                            color = XtraCyanPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            viewModel.voiceManager.speak("Systems operational. This is XTRA, your personal assistant.")
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("test_voice_button")
                    ) {
                        Icon(imageVector = Icons.Default.VolumeUp, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Test", fontSize = 11.sp, color = XtraCyanPrimary)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Speech Speed
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = "Speaking Rate (Speed)", color = XtraTextMed, fontSize = 12.sp)
                    Text(text = "${String.format("%.1f", speechSpeed)}x", color = XtraCyanGlow, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                }
                Slider(
                    value = speechSpeed,
                    onValueChange = { viewModel.setSpeechSpeed(it) },
                    valueRange = 0.6f..1.8f,
                    colors = SliderDefaults.colors(
                        thumbColor = XtraCyanPrimary,
                        activeTrackColor = XtraCyanPrimary
                    )
                )

                // Speech Pitch
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = "Synthesizer Pitch", color = XtraTextMed, fontSize = 12.sp)
                    Text(text = "${String.format("%.2f", speechPitch)}x", color = XtraCyanGlow, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                }
                Slider(
                    value = speechPitch,
                    onValueChange = { viewModel.setSpeechPitch(it) },
                    valueRange = 0.7f..1.5f,
                    colors = SliderDefaults.colors(
                        thumbColor = XtraCyanPrimary,
                        activeTrackColor = XtraCyanPrimary
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 3. Security and Permission Authorizations Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = XtraCardDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, XtraCardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = XtraCyanPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "PERMISSIONS & PRIVACY SAFEGUARDS",
                        color = XtraCyanPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "XTRA follows zero-trust security. We explain why each permission is required and never access hardware without authorization.",
                    color = XtraTextMed,
                    fontSize = 12.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                val permissionItems = listOf(
                    Triple("Microphone", "Required for continuous 'Hey XTRA' wake-word and speech-to-text recognition.") {
                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    },
                    Triple("Camera", "Required for torch flashlight hardware control and AI vision photo scanning.") {
                        cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                    },
                    Triple("Contacts", "Required to search and display contact names before making calls or sending messages.") {
                        contactsPermissionLauncher.launch(Manifest.permission.READ_CONTACTS)
                    },
                    Triple("Direct Calls", "Required to place verified phone calls upon your explicit confirmation.") {
                        callPermissionLauncher.launch(Manifest.permission.CALL_PHONE)
                    },
                    Triple("SMS Messaging", "Required to send and read text messages with user approval.") {
                        smsPermissionLauncher.launch(Manifest.permission.SEND_SMS)
                    }
                )

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    permissionItems.forEach { (permName, explanation, onAuthorize) ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = XtraSurfaceDark,
                            border = androidx.compose.foundation.BorderStroke(1.dp, XtraCardBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.padding(10.dp)
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = permName,
                                        color = XtraTextHigh,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = explanation,
                                        color = XtraTextMed,
                                        fontSize = 11.sp,
                                        lineHeight = 15.sp
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                OutlinedButton(
                                    onClick = onAuthorize,
                                    shape = RoundedCornerShape(8.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, XtraCyanPrimary.copy(alpha = 0.6f))
                                ) {
                                    Text("Authorize", fontSize = 11.sp, color = XtraCyanGlow)
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 4. Clear History & Privacy Wipe
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = XtraCardDark,
            border = androidx.compose.foundation.BorderStroke(1.dp, XtraAlertRed.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.padding(16.dp)
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Wipe Conversation Memory",
                        color = XtraTextHigh,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Clears all chat logs, voice transcripts, and cached queries.",
                        color = XtraTextMed,
                        fontSize = 11.sp
                    )
                }

                Button(
                    onClick = { viewModel.clearChatHistory() },
                    colors = ButtonDefaults.buttonColors(containerColor = XtraAlertRed),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("wipe_memory_button")
                ) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Wipe", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}
