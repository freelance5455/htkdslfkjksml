package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.ui.components.ConfirmDialog
import com.example.ui.components.Elevated3DCard
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.DepositBlue
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.ExpenseRedLight
import com.example.ui.theme.IslamicEmerald
import com.example.ui.theme.IslamicGold
import com.example.ui.theme.IslamicGreenDark
import com.example.ui.theme.IslamicGreenPrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.viewmodel.FinanceViewModel
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    viewModel: FinanceViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    var showClearDataDialog by remember { mutableStateOf(false) }
    var showBackupDialog by remember { mutableStateOf(false) }
    var backupJsonText by remember { mutableStateOf("") }
    var showRestoreDialog by remember { mutableStateOf(false) }
    var restoreInputJson by remember { mutableStateOf("") }

    // Photo Picker Launcher
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.updateProfilePhoto(uri.toString())
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Profile Section Card
        item {
            Elevated3DCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("settings_profile_card"),
                elevation = 3f
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(90.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFE8F5EE))
                            .clickable {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            }
                            .testTag("profile_image_picker"),
                        contentAlignment = Alignment.Center
                    ) {
                        if (!settings?.profileImageUri.isNullOrBlank()) {
                            AsyncImage(
                                model = settings?.profileImageUri,
                                contentDescription = "প্রোফাইল ছবি",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(90.dp)
                                    .clip(CircleShape)
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                tint = IslamicGreenPrimary,
                                modifier = Modifier.size(50.dp)
                            )
                        }

                        // Small camera badge
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(IslamicGreenPrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = "ছবি বাছুন",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "প্রোফাইল ছবি পরিবর্তন",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "গ্যালারি থেকে আপনার ছবি যোগ করুন",
                        fontSize = 12.sp,
                        color = Color(0xFF6B7280)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = IslamicGreenPrimary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("change_photo_button")
                    ) {
                        Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("ছবি পরিবর্তন করুন", color = Color.White)
                    }
                }
            }
        }

        // Backup and Restore Section
        item {
            Text(
                text = "ডাটা ব্যাকআপ ও রিস্টোর",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        item {
            Elevated3DCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("settings_backup_card"),
                elevation = 2f,
                onClick = {
                    scope.launch {
                        backupJsonText = viewModel.getBackupData()
                        showBackupDialog = true
                    }
                }
            ) {
                SettingsActionRow(
                    title = "ব্যাকআপ নেওয়া",
                    subtitle = "সব হিসাবের ডাটা সুরক্ষিত ব্যাকআপ ফাইল হিসেবে রাখুন",
                    icon = Icons.Default.Backup,
                    iconTint = DepositBlue,
                    iconBg = Color(0xFFEFF6FF)
                )
            }
        }

        item {
            Elevated3DCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("settings_restore_card"),
                elevation = 2f,
                onClick = {
                    restoreInputJson = ""
                    showRestoreDialog = true
                }
            ) {
                SettingsActionRow(
                    title = "রিস্টোর করা",
                    subtitle = "আগের সংরক্ষিত ডাটা ফিরিয়ে আনুন",
                    icon = Icons.Default.Restore,
                    iconTint = IslamicEmerald,
                    iconBg = Color(0xFFECFDF5)
                )
            }
        }

        // Danger Zone: Reset all data
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "ডাটা রিসেট",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = ExpenseRed
            )
        }

        item {
            Elevated3DCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("settings_clear_card"),
                elevation = 2f,
                borderColor = ExpenseRed.copy(alpha = 0.3f),
                onClick = { showClearDataDialog = true }
            ) {
                SettingsActionRow(
                    title = "সব ডাটা মুছে ফেলা",
                    subtitle = "সমস্ত আয়, খরচ, জমা ও ঋণের রেকর্ড স্থায়ীভাবে পরিষ্কার করুন",
                    icon = Icons.Default.DeleteForever,
                    iconTint = ExpenseRed,
                    iconBg = ExpenseRedLight
                )
            }
        }

        // App Information
        item {
            Spacer(modifier = Modifier.height(10.dp))
            Elevated3DCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "নিজের হিসাব",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = IslamicGreenPrimary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "সংস্করণ ১.০.০ • নিরাপদ অফলাইন খতিয়ান",
                        fontSize = 12.sp,
                        color = Color(0xFF6B7280)
                    )
                }
            }
        }
    }

    // Clear All Confirmation Dialog
    if (showClearDataDialog) {
        ConfirmDialog(
            title = "সব ডাটা মুছে ফেলতে চান?",
            message = "সতর্কতা: এটি নিশ্চিত করলে আপনার সমস্ত সংরক্ষিত আয়, খরচ, জমা, ঋণ ও বেতনের হিসাব স্থায়ীভাবে মুছে যাবে। এটি আর ফিরিয়ে আনা সম্ভব হবে না!",
            confirmText = "হ্যাঁ, মুছে ফেলুন",
            dismissText = "বাতিল",
            isDanger = true,
            onConfirm = {
                viewModel.clearAllData()
                showClearDataDialog = false
            },
            onDismiss = {
                showClearDataDialog = false
            }
        )
    }

    // Backup Viewer / Copy Dialog
    if (showBackupDialog) {
        AlertDialog(
            onDismissRequest = { showBackupDialog = false },
            title = {
                Text(
                    text = "ডাটা ব্যাকআপ সফল হয়েছে",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "আপনার ডাটা সুরক্ষিত রাখতে নিচের কোডটি কপি করে নিরাপদ স্থানে সংরক্ষণ করুন:",
                        fontSize = 13.sp,
                        color = Color(0xFF4B5563)
                    )
                    OutlinedTextField(
                        value = backupJsonText,
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp),
                        shape = RoundedCornerShape(8.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("NijerHisabBackup", backupJsonText)
                        clipboard.setPrimaryClip(clip)
                        Toast.makeText(context, "ব্যাকআপ ক্লিপবোর্ডে কপি করা হয়েছে", Toast.LENGTH_SHORT).show()
                        showBackupDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = IslamicGreenPrimary),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("কপি করুন", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showBackupDialog = false },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("বন্ধ করুন", color = TextPrimary)
                }
            },
            shape = RoundedCornerShape(16.dp),
            containerColor = Color.White
        )
    }

    // Restore Dialog
    if (showRestoreDialog) {
        AlertDialog(
            onDismissRequest = { showRestoreDialog = false },
            title = {
                Text(
                    text = "ব্যাকআপ রিস্টোর করুন",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "পূর্ববর্তী ব্যাকআপের টেক্সট কোড নিচে পেস্ট করুন:",
                        fontSize = 13.sp,
                        color = Color(0xFF4B5563)
                    )
                    OutlinedTextField(
                        value = restoreInputJson,
                        onValueChange = { restoreInputJson = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp)
                            .testTag("restore_json_input"),
                        placeholder = { Text("ব্যাকআপ কোড পেস্ট করুন...", fontSize = 12.sp) },
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp),
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = IslamicGreenPrimary,
                            unfocusedBorderColor = BorderSubtle
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (restoreInputJson.trim().isBlank()) {
                            Toast.makeText(context, "অনুগ্রহ করে ব্যাকআপ কোড লিখুন", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        scope.launch {
                            val success = viewModel.restoreData(restoreInputJson.trim())
                            if (success) {
                                showRestoreDialog = false
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = IslamicGreenPrimary),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("restore_confirm_button")
                ) {
                    Text("রিস্টোর করুন", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showRestoreDialog = false },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("বাতিল", color = TextPrimary)
                }
            },
            shape = RoundedCornerShape(16.dp),
            containerColor = Color.White
        )
    }
}

@Composable
fun SettingsActionRow(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconTint: Color,
    iconBg: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(iconBg),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = iconTint,
                modifier = Modifier.size(22.dp)
            )
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                fontSize = 12.sp,
                color = Color(0xFF6B7280)
            )
        }
    }
}
