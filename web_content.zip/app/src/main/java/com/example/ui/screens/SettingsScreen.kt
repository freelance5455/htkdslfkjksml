package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.BusinessSettings
import com.example.ui.components.DecimalSliderField
import com.example.ui.components.FinancialInputField
import com.example.ui.viewmodel.BusinessViewModel
import com.example.util.BackupManager
import com.example.util.FinancialMath
import java.util.Locale

@Composable
fun SettingsScreen(
    viewModel: BusinessViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentSettings by viewModel.settings.collectAsStateWithLifecycle()
    val allTransactions by viewModel.allTransactions.collectAsStateWithLifecycle()
    val allExpenses by viewModel.allExpenses.collectAsStateWithLifecycle()

    var businessName by remember(currentSettings) { mutableStateOf(currentSettings.businessName) }

    // Withdrawal Defaults
    var wPlatformFeeText by remember(currentSettings) {
        mutableStateOf(String.format(Locale.US, "%.2f", currentSettings.defaultWithdrawalPlatformFeePercent))
    }
    var wCommissionText by remember(currentSettings) {
        mutableStateOf(String.format(Locale.US, "%.2f", currentSettings.defaultWithdrawalCommissionPercent))
    }
    var wTxChargeText by remember(currentSettings) {
        mutableStateOf(String.format(Locale.US, "%.2f", currentSettings.defaultWithdrawalTransactionCharge))
    }
    var wRetainChargeAsIncome by remember(currentSettings) {
        mutableStateOf(currentSettings.defaultWithdrawalRetainChargeAsIncome)
    }

    // Bill Defaults
    var bPlatformFeeText by remember(currentSettings) {
        mutableStateOf(String.format(Locale.US, "%.2f", currentSettings.defaultBillPlatformFeePercent))
    }
    var bServiceChargeText by remember(currentSettings) {
        mutableStateOf(String.format(Locale.US, "%.2f", currentSettings.defaultBillServiceChargePercent))
    }
    var bCommissionText by remember(currentSettings) {
        mutableStateOf(String.format(Locale.US, "%.2f", currentSettings.defaultBillCommissionPercent))
    }

    // Tax Settings
    var isGstEnabled by remember(currentSettings) { mutableStateOf(currentSettings.isGstEnabled) }
    var gstRateText by remember(currentSettings) {
        mutableStateOf(String.format(Locale.US, "%.2f", currentSettings.defaultGstRatePercent))
    }
    var isItcEnabled by remember(currentSettings) { mutableStateOf(currentSettings.isInputTaxCreditEnabled) }

    // Modals
    var showRestoreDialog by remember { mutableStateOf(false) }
    var restoreJsonText by remember { mutableStateOf("") }
    var showResetDialog by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Text(
            text = "Settings & Configuration",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = "Default percentages, charges, accounting rules & backups",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Business Identity
        OutlinedTextField(
            value = businessName,
            onValueChange = { businessName = it },
            label = { Text("Business / Firm Name") },
            shape = RoundedCornerShape(12.dp),
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("business_name_input")
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Withdrawal Defaults Card
        ElevatedCard(
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "WITHDRAWAL DEFAULTS",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                DecimalSliderField(
                    valueText = wPlatformFeeText,
                    onValueChange = { wPlatformFeeText = it },
                    label = "Default Platform Fee %",
                    rangeMin = 0.0f,
                    rangeMax = 5.0f,
                    presets = listOf(0.5, 1.0, 1.25, 1.5, 1.75, 2.0)
                )

                Spacer(modifier = Modifier.height(10.dp))

                DecimalSliderField(
                    valueText = wCommissionText,
                    onValueChange = { wCommissionText = it },
                    label = "Default Commission Received %",
                    rangeMin = 0.0f,
                    rangeMax = 3.0f,
                    presets = listOf(0.1, 0.2, 0.3, 0.5, 1.0)
                )

                Spacer(modifier = Modifier.height(10.dp))

                FinancialInputField(
                    value = wTxChargeText,
                    onValueChange = { wTxChargeText = it },
                    label = "Default Transaction Charge (₹)",
                    placeholder = "20.00"
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Retain Tx Charge as Income",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = if (wRetainChargeAsIncome)
                                "Default: Charge is retained as business gross profit"
                            else
                                "Third-party: Charge is paid out to third party gateway",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp
                        )
                    }
                    Switch(
                        checked = wRetainChargeAsIncome,
                        onCheckedChange = { wRetainChargeAsIncome = it }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Bill Payment Defaults Card
        ElevatedCard(
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "BILL PAYMENT DEFAULTS",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                DecimalSliderField(
                    valueText = bPlatformFeeText,
                    onValueChange = { bPlatformFeeText = it },
                    label = "Default Platform Fee %",
                    rangeMin = 0.0f,
                    rangeMax = 5.0f,
                    presets = listOf(0.5, 1.0, 1.25, 1.5, 1.75, 2.0)
                )

                Spacer(modifier = Modifier.height(10.dp))

                DecimalSliderField(
                    valueText = bServiceChargeText,
                    onValueChange = { bServiceChargeText = it },
                    label = "Default Service Charge %",
                    rangeMin = 0.0f,
                    rangeMax = 5.0f,
                    presets = listOf(0.5, 1.0, 1.25, 1.5, 1.75, 2.0)
                )

                Spacer(modifier = Modifier.height(10.dp))

                DecimalSliderField(
                    valueText = bCommissionText,
                    onValueChange = { bCommissionText = it },
                    label = "Default Commission % (on Bill Amount)",
                    rangeMin = 0.0f,
                    rangeMax = 3.0f,
                    presets = listOf(0.1, 0.2, 0.3, 0.5, 1.0)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Tax Settings Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "GST & TAX CONFIGURATION",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Enable GST Estimations", style = MaterialTheme.typography.bodyMedium)
                    Switch(checked = isGstEnabled, onCheckedChange = { isGstEnabled = it })
                }

                if (isGstEnabled) {
                    Spacer(modifier = Modifier.height(8.dp))
                    DecimalSliderField(
                        valueText = gstRateText,
                        onValueChange = { gstRateText = it },
                        label = "Applicable GST Rate",
                        rangeMin = 0.0f,
                        rangeMax = 28.0f,
                        presets = listOf(5.0, 12.0, 18.0, 28.0)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Input Tax Credit (ITC)", style = MaterialTheme.typography.bodyMedium)
                            Text(
                                "Offset GST on eligible business operating expenses",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 11.sp
                            )
                        }
                        Switch(checked = isItcEnabled, onCheckedChange = { isItcEnabled = it })
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Save Settings Button
        Button(
            onClick = {
                val updated = currentSettings.copy(
                    businessName = businessName,
                    defaultWithdrawalPlatformFeePercent = FinancialMath.parseDoubleOrNull(wPlatformFeeText) ?: 1.5,
                    defaultWithdrawalCommissionPercent = FinancialMath.parseDoubleOrNull(wCommissionText) ?: 0.2,
                    defaultWithdrawalTransactionCharge = FinancialMath.parseDoubleOrNull(wTxChargeText) ?: 20.0,
                    defaultWithdrawalRetainChargeAsIncome = wRetainChargeAsIncome,
                    defaultBillPlatformFeePercent = FinancialMath.parseDoubleOrNull(bPlatformFeeText) ?: 1.5,
                    defaultBillServiceChargePercent = FinancialMath.parseDoubleOrNull(bServiceChargeText) ?: 1.5,
                    defaultBillCommissionPercent = FinancialMath.parseDoubleOrNull(bCommissionText) ?: 0.2,
                    isGstEnabled = isGstEnabled,
                    defaultGstRatePercent = FinancialMath.parseDoubleOrNull(gstRateText) ?: 18.0,
                    isInputTaxCreditEnabled = isItcEnabled
                )
                viewModel.updateSettings(updated)
                Toast.makeText(context, "Settings saved successfully", Toast.LENGTH_SHORT).show()
            },
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("save_settings_button")
        ) {
            Icon(Icons.Default.Save, contentDescription = null)
            Spacer(modifier = Modifier.width(6.dp))
            Text("Save Default Settings")
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Backup & Restore Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "DATA BACKUP, RESTORE & PRIVACY",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "All database records are stored 100% locally on this device. You can create encrypted JSON backups anytime.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedButton(
                        onClick = {
                            val backupJson = BackupManager.generateBackupJson(currentSettings, allTransactions, allExpenses)
                            val sendIntent = Intent().apply {
                                action = Intent.ACTION_SEND
                                putExtra(Intent.EXTRA_TEXT, backupJson)
                                putExtra(Intent.EXTRA_SUBJECT, "BizCalc_Backup_${System.currentTimeMillis()}.json")
                                type = "application/json"
                            }
                            context.startActivity(Intent.createChooser(sendIntent, "Save or Export Backup JSON"))
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("export_backup_button")
                    ) {
                        Icon(Icons.Default.Backup, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Export JSON", fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = { showRestoreDialog = true },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("restore_backup_button")
                    ) {
                        Icon(Icons.Default.Upload, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Import JSON", fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                HorizontalDivider()

                Spacer(modifier = Modifier.height(8.dp))

                TextButton(
                    onClick = { showResetDialog = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.DeleteForever, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Clear All Data & Reset Database", color = MaterialTheme.colorScheme.error)
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }

    if (showRestoreDialog) {
        AlertDialog(
            onDismissRequest = { showRestoreDialog = false },
            title = { Text("Restore From Backup JSON") },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "Paste your exported JSON backup text below to restore your transactions and settings:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = restoreJsonText,
                        onValueChange = { restoreJsonText = it },
                        placeholder = { Text("Paste JSON here...") },
                        maxLines = 6,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.restoreBackup(restoreJsonText) { success, msg ->
                            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                            if (success) {
                                showRestoreDialog = false
                                restoreJsonText = ""
                            }
                        }
                    },
                    enabled = restoreJsonText.isNotBlank()
                ) {
                    Text("Restore")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRestoreDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("Clear All Business Data") },
            text = { Text("Are you sure you want to permanently clear all transaction history and expenses? This action cannot be reversed.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearAllData()
                        showResetDialog = false
                        Toast.makeText(context, "All database records cleared", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Permanently Clear")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
