package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AiEngineType
import com.example.data.model.AssistantPersona
import com.example.data.model.GeminiModelOption
import com.example.data.model.VoicePreset
import com.example.speech.AiVoicesCatalog
import com.example.ui.MainViewModel
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NexusBackground
import com.example.ui.theme.NexusBorder
import com.example.ui.theme.NexusCyan
import com.example.ui.theme.NexusCyanDark
import com.example.ui.theme.NexusEmerald
import com.example.ui.theme.NexusObsidianBackdrop
import com.example.ui.theme.NexusSurface
import com.example.ui.theme.NexusSurfaceElevated
import com.example.ui.theme.NexusSurfaceVariant
import com.example.ui.theme.NexusTextPrimary
import com.example.ui.theme.NexusTextSecondary
import com.example.ui.theme.NexusTextTertiary
import com.example.ui.theme.NexusViolet
import com.example.ui.theme.NexusVioletDark
import com.example.ui.theme.NexusVioletLight

@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val availableVoices by viewModel.ttsManager.availableVoices.collectAsStateWithLifecycle()
    val activeVoiceLabel by viewModel.ttsManager.activeVoiceLabel.collectAsStateWithLifecycle()

    var nameInput by remember(settings.assistantName) { mutableStateOf(settings.assistantName) }
    var customModelInput by remember(settings.customGeminiModelId) { mutableStateOf(settings.customGeminiModelId) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NexusObsidianBackdrop)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = "Настройки ассистента",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = NexusTextPrimary
        )
        Text(
            text = "Персонализация, новые версии Gemini и голоса озвучивания",
            fontSize = 12.sp,
            color = NexusTextTertiary
        )

        Spacer(modifier = Modifier.height(20.dp))

        // 1. Assistant Name
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = NexusSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, NexusBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = null,
                        tint = NexusCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Имя ассистента",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NexusTextPrimary
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = nameInput,
                    onValueChange = {
                        nameInput = it
                        viewModel.updateAssistantName(it)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("assistant_name_input"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = NexusSurfaceVariant,
                        unfocusedContainerColor = NexusSurfaceVariant,
                        focusedBorderColor = NexusCyan,
                        unfocusedBorderColor = NexusBorder,
                        focusedTextColor = NexusTextPrimary,
                        unfocusedTextColor = NexusTextPrimary
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("NEXUS", "Алиса", "Аврора", "Гелиос").forEach { preset ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(NexusSurfaceElevated)
                                .border(1.dp, NexusBorder, RoundedCornerShape(8.dp))
                                .clickable {
                                    nameInput = preset
                                    viewModel.updateAssistantName(preset)
                                }
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Text(text = preset, fontSize = 11.sp, color = NexusCyan)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 2. Newer Gemini Models Selection
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = NexusSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, NexusBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = NexusCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Версия Gemini (Новые модели)",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NexusTextPrimary
                    )
                }
                Text(
                    text = "Выбирайте новейшие поколения Gemini 3.x и Gemini 4",
                    fontSize = 11.sp,
                    color = NexusTextTertiary
                )

                Spacer(modifier = Modifier.height(10.dp))

                GeminiModelOption.values().forEach { modelOption ->
                    val isSelected = settings.geminiModel == modelOption
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) NexusSurfaceElevated else NexusSurfaceVariant)
                            .border(
                                1.dp,
                                if (isSelected) NexusCyan else NexusBorder,
                                RoundedCornerShape(12.dp)
                            )
                            .clickable { viewModel.updateGeminiModel(modelOption) }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .clip(CircleShape)
                                .background(if (isSelected) NexusCyan else NexusBorder),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = NexusBackground,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = modelOption.title,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isSelected) NexusCyan else NexusTextPrimary
                                )
                                Text(
                                    text = modelOption.badge,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = JetBrainsMonoFontFamily,
                                    color = if (modelOption == GeminiModelOption.GEMINI_4_ARGON) NexusVioletLight else NexusEmerald,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(
                                            if (modelOption == GeminiModelOption.GEMINI_4_ARGON)
                                                NexusVioletDark.copy(alpha = 0.5f)
                                            else NexusCyanDark.copy(alpha = 0.45f)
                                        )
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = modelOption.description,
                                fontSize = 11.sp,
                                color = NexusTextSecondary
                            )
                        }
                    }
                }

                AnimatedVisibility(visible = settings.geminiModel == GeminiModelOption.CUSTOM) {
                    Column(modifier = Modifier.padding(top = 8.dp)) {
                        Text(
                            text = "Идентификатор новой модели Gemini:",
                            fontSize = 11.sp,
                            color = NexusTextSecondary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = customModelInput,
                            onValueChange = {
                                customModelInput = it
                                viewModel.updateCustomGeminiModelId(it)
                            },
                            placeholder = {
                                Text(
                                    text = "Например: gemini-3.8-flash или gemini-4-argon",
                                    fontSize = 12.sp,
                                    color = NexusTextTertiary
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("custom_gemini_model_input"),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = NexusBackground,
                                unfocusedContainerColor = NexusBackground,
                                focusedBorderColor = NexusCyan,
                                unfocusedBorderColor = NexusBorder,
                                focusedTextColor = NexusTextPrimary,
                                unfocusedTextColor = NexusTextPrimary
                            ),
                            singleLine = true
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 3. Voice Profiles (Alisa, Max, Cyber, Announcer) & Device Voices
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = NexusSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, NexusBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.RecordVoiceOver,
                            contentDescription = null,
                            tint = NexusCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Голос и синтез речи (TTS)",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = NexusTextPrimary
                        )
                    }

                    IconButton(
                        onClick = {
                            viewModel.speakText("Привет! Я ${settings.assistantName}. Голос настроен и готов к общению.")
                        },
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(NexusSurfaceElevated)
                            .testTag("test_voice_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Тест речи",
                            tint = NexusCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Активный голос: $activeVoiceLabel",
                    fontSize = 11.sp,
                    color = NexusEmerald
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Voice Presets (Alisa, Max, Cyber, etc.)
                Text(
                    text = "Голосовые профили:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = NexusTextSecondary
                )
                Spacer(modifier = Modifier.height(6.dp))

                VoicePreset.values().forEach { preset ->
                    val isSelected = settings.voicePreset == preset
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) NexusSurfaceElevated else NexusSurfaceVariant)
                            .border(
                                1.dp,
                                if (isSelected) NexusViolet else NexusBorder,
                                RoundedCornerShape(12.dp)
                            )
                            .clickable { viewModel.updateVoicePreset(preset) }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(18.dp)
                                .clip(CircleShape)
                                .background(if (isSelected) NexusViolet else NexusBorder),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = NexusTextPrimary,
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = preset.title,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isSelected) NexusVioletLight else NexusTextPrimary
                            )
                            Text(
                                text = preset.description,
                                fontSize = 11.sp,
                                color = NexusTextSecondary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Gemini Neural TTS Toggle & Voice Picker
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Нейросетевой голос Gemini AI",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = NexusTextPrimary
                        )
                        Text(
                            text = "Живая естественная речь (gemini-3.1-flash-tts). Офлайн — системный TTS",
                            fontSize = 11.sp,
                            color = NexusTextTertiary
                        )
                    }
                    Switch(
                        checked = settings.useAiNeuralVoice,
                        onCheckedChange = { viewModel.updateUseAiNeuralVoice(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = NexusEmerald,
                            checkedTrackColor = NexusCyanDark,
                            uncheckedTrackColor = NexusSurfaceVariant
                        )
                    )
                }

                AnimatedVisibility(visible = settings.useAiNeuralVoice) {
                    Column(modifier = Modifier.padding(top = 8.dp)) {
                        Text(
                            text = "Нейро-голоса Gemini (онлайн):",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = NexusTextSecondary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        AiVoicesCatalog.voices.forEach { aiVoice ->
                            val isSelected = settings.aiTtsVoiceId == aiVoice.id
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSelected) NexusSurfaceElevated else NexusSurfaceVariant)
                                    .border(
                                        1.dp,
                                        if (isSelected) NexusEmerald else NexusBorder,
                                        RoundedCornerShape(10.dp)
                                    )
                                    .clickable { viewModel.updateAiTtsVoiceId(aiVoice.id) }
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = aiVoice.title,
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                                        color = if (isSelected) NexusEmerald else NexusTextPrimary
                                    )
                                    Text(
                                        text = aiVoice.style,
                                        fontSize = 10.sp,
                                        color = NexusTextTertiary
                                    )
                                }
                                IconButton(
                                    onClick = {
                                        viewModel.updateAiTtsVoiceId(aiVoice.id)
                                        viewModel.speakText(
                                            "Привет! Я ${settings.assistantName}. Это звучит нейросетевой голос.",
                                            forceNeural = true
                                        )
                                    },
                                    modifier = Modifier.size(30.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.VolumeUp,
                                        contentDescription = "Прослушать нейро-голос",
                                        tint = NexusEmerald,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Available System TTS Voices
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Доступные голоса устройства (${availableVoices.size}):",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NexusTextSecondary
                    )
                    IconButton(
                        onClick = { viewModel.refreshDeviceVoices() },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Обновить голоса",
                            tint = NexusCyan,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Auto voice option
                val isAutoVoice = settings.selectedVoiceName.isBlank()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isAutoVoice) NexusSurfaceElevated else NexusSurfaceVariant)
                        .border(1.dp, if (isAutoVoice) NexusCyan else NexusBorder, RoundedCornerShape(10.dp))
                        .clickable { viewModel.updateSelectedVoiceName("") }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Автовыбор под профиль «${settings.voicePreset.title}»",
                        fontSize = 12.sp,
                        fontWeight = if (isAutoVoice) FontWeight.SemiBold else FontWeight.Normal,
                        color = if (isAutoVoice) NexusCyan else NexusTextPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    if (isAutoVoice) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = NexusCyan,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                availableVoices.take(12).forEach { voice ->
                    val isVoiceSelected = settings.selectedVoiceName == voice.name
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isVoiceSelected) NexusSurfaceElevated else NexusSurfaceVariant)
                            .border(
                                1.dp,
                                if (isVoiceSelected) NexusCyan else NexusBorder,
                                RoundedCornerShape(10.dp)
                            )
                            .clickable { viewModel.updateSelectedVoiceName(voice.name) }
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = voice.displayName,
                                fontSize = 12.sp,
                                fontWeight = if (isVoiceSelected) FontWeight.SemiBold else FontWeight.Normal,
                                color = if (isVoiceSelected) NexusCyan else NexusTextPrimary
                            )
                            Text(
                                text = "${voice.localeTag} • ${voice.name}",
                                fontSize = 10.sp,
                                fontFamily = JetBrainsMonoFontFamily,
                                color = NexusTextTertiary
                            )
                        }
                        IconButton(
                            onClick = {
                                viewModel.updateSelectedVoiceName(voice.name)
                                viewModel.speakText("Привет! Это проверка выбранного голоса для ${settings.assistantName}.")
                            },
                            modifier = Modifier.size(30.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = "Прослушать голос",
                                tint = NexusCyan,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                if (availableVoices.isEmpty()) {
                    Text(
                        text = "Системные голоса ещё загружаются или используется голос Android по умолчанию. Установите дополнительные русские голоса (Google / RHVoice / Яндекс) в настройках синтеза речи телефона.",
                        fontSize = 11.sp,
                        color = NexusTextTertiary,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Auto TTS toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Авто-озвучивание ответов",
                            fontSize = 13.sp,
                            color = NexusTextPrimary
                        )
                        Text(
                            text = "Воспроизводить ответы голосом автоматически",
                            fontSize = 11.sp,
                            color = NexusTextTertiary
                        )
                    }
                    Switch(
                        checked = settings.autoTts,
                        onCheckedChange = { viewModel.updateAutoTts(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = NexusCyan,
                            checkedTrackColor = NexusCyanDark,
                            uncheckedTrackColor = NexusSurfaceVariant
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Speed Slider
                Text(
                    text = "Скорость речи: ${String.format("%.1fx", settings.voiceSpeed)}",
                    fontSize = 12.sp,
                    color = NexusTextSecondary
                )
                Slider(
                    value = settings.voiceSpeed,
                    onValueChange = { viewModel.updateVoiceSpeed(it) },
                    valueRange = 0.5f..2.0f,
                    steps = 14,
                    colors = SliderDefaults.colors(
                        thumbColor = NexusCyan,
                        activeTrackColor = NexusCyan,
                        inactiveTrackColor = NexusBorder
                    )
                )

                // Pitch Slider
                Text(
                    text = "Высота тона: ${String.format("%.2fx", settings.voicePitch)}",
                    fontSize = 12.sp,
                    color = NexusTextSecondary
                )
                Slider(
                    value = settings.voicePitch,
                    onValueChange = { viewModel.updateVoicePitch(it) },
                    valueRange = 0.5f..1.5f,
                    steps = 19,
                    colors = SliderDefaults.colors(
                        thumbColor = NexusViolet,
                        activeTrackColor = NexusViolet,
                        inactiveTrackColor = NexusBorder
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 4. Persona Selection
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = NexusSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, NexusBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Поведение и стиль общения",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = NexusTextPrimary
                )
                Text(
                    text = "Определяет тон, глубину рассуждений и лексику модели",
                    fontSize = 11.sp,
                    color = NexusTextTertiary
                )

                Spacer(modifier = Modifier.height(12.dp))

                AssistantPersona.values().forEach { persona ->
                    val isSelected = settings.persona == persona
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) NexusSurfaceElevated else NexusSurfaceVariant)
                            .border(
                                1.dp,
                                if (isSelected) NexusCyan else NexusBorder,
                                RoundedCornerShape(12.dp)
                            )
                            .clickable { viewModel.updatePersona(persona) }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .clip(CircleShape)
                                .background(if (isSelected) NexusCyan else NexusBorder),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = NexusBackground,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = persona.title,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isSelected) NexusCyan else NexusTextPrimary
                            )
                            Text(
                                text = persona.description,
                                fontSize = 11.sp,
                                color = NexusTextSecondary
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 5. AI Model Engine Selection (Online / Auto / Offline)
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = NexusSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, NexusBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Memory,
                        contentDescription = null,
                        tint = NexusEmerald,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Режим работы и автономность",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NexusTextPrimary
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                AiEngineType.values().forEach { engine ->
                    val isSelected = settings.engineType == engine
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) NexusSurfaceElevated else NexusSurfaceVariant)
                            .border(
                                1.dp,
                                if (isSelected) NexusEmerald else NexusBorder,
                                RoundedCornerShape(12.dp)
                            )
                            .clickable { viewModel.updateEngineType(engine) }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .clip(CircleShape)
                                .background(if (isSelected) NexusEmerald else NexusBorder),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = NexusBackground,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = engine.title,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isSelected) NexusEmerald else NexusTextPrimary
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (engine.isOffline) "100% ОФЛАЙН" else "ОНЛАЙН",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (engine.isOffline) NexusEmerald else NexusCyan
                                )
                            }
                            Text(
                                text = engine.subtitle,
                                fontSize = 11.sp,
                                color = NexusTextSecondary
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 6. Hardware Info & Optimization
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = NexusSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, NexusBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = null,
                        tint = NexusEmerald,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Аппаратная оптимизация устройства",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NexusTextPrimary
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                val infoRows = listOf(
                    "Выбранная модель ИИ" to settings.effectiveGeminiModelTitle(),
                    "Голосовой профиль" to settings.voicePreset.title,
                    "Офлайн-режим ИИ" to "NEXUS Neural (Helio G100 Ultra)",
                    "Оперативная память" to "8 ГБ LPDDR4X",
                    "Память диалога" to "Контекст последних 24 реплик",
                    "Распознавание речи" to "Android SpeechRecognizer (ru-RU)",
                    "Хранилище истории" to "SQLite / Room Database (локально)"
                )

                infoRows.forEach { (label, value) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = label, fontSize = 12.sp, color = NexusTextTertiary)
                        Text(
                            text = value,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = NexusTextPrimary
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
