package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bedtime
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.StorageStats
import com.example.ui.dialogs.CleanStorageDialog
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkError
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.OnEmeraldContainer
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.util.TimeUtils

@Composable
fun SettingsScreen(
    storageStats: StorageStats?,
    sleepTimerRemainingSeconds: Long?,
    onRefreshStorage: () -> Unit,
    onCleanStorage: () -> Unit,
    onOpenSleepTimer: () -> Unit,
    onImportPlaylist: (Uri) -> Unit,
    modifier: Modifier = Modifier
) {
    var showCleanDialog by remember { mutableStateOf(false) }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            onImportPlaylist(uri)
        }
    }

    LaunchedEffect(Unit) {
        onRefreshStorage()
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(horizontal = 16.dp)
            .testTag("settings_screen"),
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Settings",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        // Storage Management Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Storage, contentDescription = null, tint = EmeraldPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("App Storage Management", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (storageStats != null) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Imported Songs (${storageStats.songsCount}):", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                            Text(TimeUtils.formatBytes(storageStats.musicFilesSizeBytes), color = TextPrimary, fontWeight = FontWeight.Medium)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Artwork Cache:", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                            Text(TimeUtils.formatBytes(storageStats.artworkFilesSizeBytes), color = TextPrimary, fontWeight = FontWeight.Medium)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Unreferenced Files:", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                            Text("${storageStats.orphanedFilesCount} (${TimeUtils.formatBytes(storageStats.orphanedFilesSizeBytes)})", color = if (storageStats.orphanedFilesCount > 0) DarkError else TextPrimary, fontWeight = FontWeight.Medium)
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        if (storageStats.orphanedFilesCount > 0) {
                            Button(
                                onClick = { showCleanDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = DarkError, contentColor = DarkBackground),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.CleaningServices, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Clean ${storageStats.orphanedFilesCount} Unused Files (${TimeUtils.formatBytes(storageStats.orphanedFilesSizeBytes)})")
                            }
                        } else {
                            OutlinedButton(
                                onClick = onRefreshStorage,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Storage is optimized (Tap to recheck)", color = EmeraldPrimary)
                            }
                        }
                    } else {
                        Text("Loading storage information...", color = TextSecondary, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        // Playback & Sleep Timer Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Bedtime, contentDescription = null, tint = EmeraldPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Sleep Timer", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (sleepTimerRemainingSeconds != null) {
                        Text(
                            "Timer active: ${TimeUtils.formatSecondsRemaining(sleepTimerRemainingSeconds)} remaining until pause",
                            color = EmeraldPrimary,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    } else {
                        Text(
                            "Automatically stop playback after a set duration.",
                            color = TextSecondary,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = onOpenSleepTimer,
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary, contentColor = DarkBackground),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (sleepTimerRemainingSeconds != null) "Adjust or Turn Off Timer" else "Set Sleep Timer")
                    }
                }
            }
        }

        // Hardware Controls Notice Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.VolumeUp, contentDescription = null, tint = EmeraldPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Hardware Controls & Audio Focus", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        "• Bluetooth & Headset Controls: Full support for Play/Pause, Next Track, and Previous Track buttons on Bluetooth headphones and wired headsets.\n\n" +
                        "• Audio Becoming Noisy: Music pauses automatically when headphones or Bluetooth devices disconnect.\n\n" +
                        "• Audio Focus: Automatically ducks or pauses during phone calls and navigation directions.\n\n" +
                        "• Volume Buttons: Volume rockers adjust media stream volume naturally. (Background hijacking of volume keys for track skipping is restricted by Android OS for accessibility and battery safety).",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }

        // Data & Playlists Transfer Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.FileDownload, contentDescription = null, tint = EmeraldPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Playlist Transfer", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        "Import playlists exported in standard JSON format. Playlists match songs in your active library by file content hash or title/artist.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedButton(
                        onClick = { importLauncher.launch(arrayOf("application/json")) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Import Playlist JSON", color = EmeraldPrimary)
                    }
                }
            }
        }

        // About & Privacy
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = EmeraldPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Privacy & Offline Guarantee", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        "Local Music Player is 100% offline. All audio files, artwork, playlists, and listening statistics are stored locally on your device in private app storage. No analytics, tracking, or cloud uploads.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }
    }

    if (showCleanDialog && storageStats != null) {
        CleanStorageDialog(
            orphanCount = storageStats.orphanedFilesCount,
            orphanBytes = storageStats.orphanedFilesSizeBytes,
            onDismiss = { showCleanDialog = false },
            onConfirm = {
                onCleanStorage()
                showCleanDialog = false
            }
        )
    }
}
