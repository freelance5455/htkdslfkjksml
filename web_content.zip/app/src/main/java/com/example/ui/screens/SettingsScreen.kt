package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AiEngineType
import com.example.data.model.AssistantPersona
import com.example.ui.MainViewModel
import com.example.ui.theme.NexusBackground
import com.example.ui.theme.NexusBorder
import com.example.ui.theme.NexusCyan
import com.example.ui.theme.NexusCyanDark
import com.example.ui.theme.NexusEmerald
import com.example.ui.theme.NexusEmeraldDim
import com.example.ui.theme.NexusSurface
import com.example.ui.theme.NexusSurfaceElevated
import com.example.ui.theme.NexusSurfaceVariant
import com.example.ui.theme.NexusTextPrimary
import com.example.ui.theme.NexusTextSecondary
import com.example.ui.theme.NexusTextTertiary
import com.example.ui.theme.NexusViolet

@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val isTtsAvailable by viewModel.ttsManager.isLanguageAvailable.collectAsStateWithLifecycle()

    var nameInput by remember(settings.assistantName) { mutableStateOf(settings.assistantName) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NexusBackground)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Title
        Text(
            text = "Настройки ассистента",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = NexusTextPrimary
        )
        Text(
            text = "Персонализация, поведение, голосовой синтез и нейросеть",
            fontSize = 12.sp,
            color = NexusTextTertiary
        )

        Spacer(modifier = Modifier.height(20.dp))

        // 1. Assistant Name
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = NexusSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, NexusBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = null,
                        tint = NexusCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Имя ассистента",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NexusTextPrimary
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = nameInput,
                    onValueChange = {
                        nameInput = it
                        viewModel.updateAssistantName(it)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("assistant_name_input"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = NexusSurfaceVariant,
                        unfocusedContainerColor = NexusSurfaceVariant,
                        focusedBorderColor = NexusCyan,
                        unfocusedBorderColor = NexusBorder,
                        focusedTextColor = NexusTextPrimary,
                        unfocusedTextColor = NexusTextPrimary
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Name presets
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("NEXUS", "Аврора", "Кибер", "Гелиос").forEach { preset ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(NexusSurfaceElevated)
                                .border(1.dp, NexusBorder, RoundedCornerShape(8.dp))
                                .clickable {
                                    nameInput = preset
                                    viewModel.updateAssistantName(preset)
                                }
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Text(text = preset, fontSize = 11.sp, color = NexusCyan)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 2. Persona Selection
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = NexusSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, NexusBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Поведение и стиль общения",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = NexusTextPrimary
                )
                Text(
                    text = "Определяет тон, глубину рассуждений и лексику модели",
                    fontSize = 11.sp,
                    color = NexusTextTertiary
                )

                Spacer(modifier = Modifier.height(12.dp))

                AssistantPersona.values().forEach { persona ->
                    val isSelected = settings.persona == persona
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) NexusSurfaceElevated else NexusSurfaceVariant)
                            .border(
                                1.dp,
                                if (isSelected) NexusCyan else NexusBorder,
                                RoundedCornerShape(12.dp)
                            )
                            .clickable { viewModel.updatePersona(persona) }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .clip(CircleShape)
                                .background(if (isSelected) NexusCyan else NexusBorder),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = NexusBackground,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = persona.title,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isSelected) NexusCyan else NexusTextPrimary
                            )
                            Text(
                                text = persona.description,
                                fontSize = 11.sp,
                                color = NexusTextSecondary
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 3. AI Model Engine Selection
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = NexusSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, NexusBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Memory,
                        contentDescription = null,
                        tint = NexusEmerald,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Модель ИИ и автономность",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NexusTextPrimary
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                AiEngineType.values().forEach { engine ->
                    val isSelected = settings.engineType == engine
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) NexusSurfaceElevated else NexusSurfaceVariant)
                            .border(
                                1.dp,
                                if (isSelected) NexusEmerald else NexusBorder,
                                RoundedCornerShape(12.dp)
                            )
                            .clickable { viewModel.updateEngineType(engine) }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .clip(CircleShape)
                                .background(if (isSelected) NexusEmerald else NexusBorder),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = NexusBackground,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = engine.title,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isSelected) NexusEmerald else NexusTextPrimary
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (engine.isOffline) "100% ОФЛАЙН" else "ОНЛАЙН",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (engine.isOffline) NexusEmerald else NexusCyan
                                )
                            }
                            Text(
                                text = engine.subtitle,
                                fontSize = 11.sp,
                                color = NexusTextSecondary
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 4. Voice & Speech Synthesis (TTS)
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = NexusSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, NexusBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.RecordVoiceOver,
                            contentDescription = null,
                            tint = NexusCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Синтез речи (TTS ru-RU)",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = NexusTextPrimary
                        )
                    }

                    // Test Voice button
                    IconButton(
                        onClick = {
                            viewModel.speakText("Привет! Это проверка голоса ассистента ${settings.assistantName}. Скорость и высота тона настроены.")
                        },
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(NexusSurfaceElevated)
                            .testTag("test_voice_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Тест речи",
                            tint = NexusCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Auto TTS toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Авто-озвучивание ответов",
                            fontSize = 13.sp,
                            color = NexusTextPrimary
                        )
                        Text(
                            text = "Воспроизводить ответы голосом автоматически",
                            fontSize = 11.sp,
                            color = NexusTextTertiary
                        )
                    }
                    Switch(
                        checked = settings.autoTts,
                        onCheckedChange = { viewModel.updateAutoTts(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = NexusCyan,
                            checkedTrackColor = NexusCyanDark,
                            uncheckedTrackColor = NexusSurfaceVariant
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Speed Slider
                Text(
                    text = "Скорость речи: ${String.format("%.1fx", settings.voiceSpeed)}",
                    fontSize = 12.sp,
                    color = NexusTextSecondary
                )
                Slider(
                    value = settings.voiceSpeed,
                    onValueChange = { viewModel.updateVoiceSpeed(it) },
                    valueRange = 0.5f..2.0f,
                    steps = 14,
                    colors = SliderDefaults.colors(
                        thumbColor = NexusCyan,
                        activeTrackColor = NexusCyan,
                        inactiveTrackColor = NexusBorder
                    )
                )

                // Pitch Slider
                Text(
                    text = "Высота тона: ${String.format("%.1fx", settings.voicePitch)}",
                    fontSize = 12.sp,
                    color = NexusTextSecondary
                )
                Slider(
                    value = settings.voicePitch,
                    onValueChange = { viewModel.updateVoicePitch(it) },
                    valueRange = 0.5f..1.5f,
                    steps = 10,
                    colors = SliderDefaults.colors(
                        thumbColor = NexusViolet,
                        activeTrackColor = NexusViolet,
                        inactiveTrackColor = NexusBorder
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 5. Hardware Info & Optimization
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = NexusSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, NexusBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = null,
                        tint = NexusEmerald,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Аппаратная оптимизация устройства",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NexusTextPrimary
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                val infoRows = listOf(
                    "Основная модель ИИ" to "Google Gemini 3.8 Flash (Облако)",
                    "Офлайн-режим ИИ" to "NEXUS Neural (Helio G100 Ultra)",
                    "Оперативная память" to "8 ГБ LPDDR4X",
                    "Память диалога" to "Контекст последних 20 реплик",
                    "Распознавание речи" to "Android SpeechRecognizer (ru-RU)",
                    "Синтез речи (TTS)" to "Android TTS (Русский язык активен)",
                    "Хранилище истории" to "SQLite / Room Database (локально)"
                )

                infoRows.forEach { (label, value) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = label, fontSize = 12.sp, color = NexusTextTertiary)
                        Text(
                            text = value,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = NexusTextPrimary
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
