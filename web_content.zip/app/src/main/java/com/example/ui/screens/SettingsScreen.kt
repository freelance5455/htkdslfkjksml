package com.example.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.SettingsUiState
import com.example.ui.components.PrivacyPolicyDialog
import com.example.ui.components.VipPaymentDialog
import com.example.util.PaymentSecurityManager
import com.example.ui.theme.AestheticBlack
import com.example.ui.theme.BorderGrey
import com.example.ui.theme.CardGrey
import com.example.ui.theme.DeepPink
import com.example.ui.theme.KawaiiPink
import com.example.ui.theme.PastelPinkBg
import com.example.ui.theme.PastelPinkContainer
import com.example.ui.theme.PureWhite
import com.example.ui.theme.TextGrey

@Composable
fun SettingsScreen(
    settings: SettingsUiState,
    onSaveSettings: (focus: Int, shortBreak: Int, longBreak: Int, interval: Int, goal: Int, sound: Boolean, vib: Boolean) -> Unit,
    onToggleAutoNotifications: (Boolean) -> Unit = {},
    onTriggerTestNotification: () -> Unit = {},
    onActivateVip: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    var focusMin by remember { mutableFloatStateOf(settings.focusMinutes.toFloat()) }
    var shortBreakMin by remember { mutableFloatStateOf(settings.shortBreakMinutes.toFloat()) }
    var longBreakMin by remember { mutableFloatStateOf(settings.longBreakMinutes.toFloat()) }
    var longInterval by remember { mutableIntStateOf(settings.longBreakInterval) }
    var dailyGoalMin by remember { mutableFloatStateOf(settings.dailyGoalMinutes.toFloat()) }
    var soundEnabled by remember { mutableStateOf(settings.soundEnabled) }
    var vibrationEnabled by remember { mutableStateOf(settings.vibrationEnabled) }

    var showVipDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }
    val creatorEmail = PaymentSecurityManager.OFFICIAL_SUPPORT_EMAIL

    fun commit() {
        onSaveSettings(
            focusMin.toInt(),
            shortBreakMin.toInt(),
            longBreakMin.toInt(),
            longInterval,
            dailyGoalMin.toInt(),
            soundEnabled,
            vibrationEnabled
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(PastelPinkBg)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Column {
                Text(
                    text = "⚙️ Preferences & VIP",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = (-0.5).sp
                    ),
                    color = AestheticBlack
                )
                Text(
                    text = "Timer settings, exclusive perks, and privacy guarantees",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextGrey
                )
            }
        }

        // VIP Membership Promotion Card
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = PastelPinkContainer),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, KawaiiPink.copy(alpha = 0.6f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("vip_pass_settings_card")
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("👑", fontSize = 24.sp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = if (settings.isVipActive) "VIP Status: Active ⭐" else "Study VIP Pass (₹199 / 2 Mo)",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = AestheticBlack
                                )
                                Text(
                                    text = if (settings.isVipActive) "60-day access active" else "Special 60% student discount",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                                    color = DeepPink
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = PureWhite,
                            border = androidx.compose.foundation.BorderStroke(1.dp, BorderGrey)
                        ) {
                            Text(
                                text = if (settings.isVipActive) "PRO" else "₹199",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = DeepPink,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Scan our clean pastel QR code to unlock holographic stationery stickers, streak shield, PDF exports, and binaural audio.",
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp, lineHeight = 17.sp),
                        color = AestheticBlack
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = { showVipDialog = true },
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AestheticBlack,
                            contentColor = PureWhite
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (settings.isVipActive) "View VIP Perks 🌸" else "Unlock VIP for ₹199 (Scan QR) ✨",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Auto Notification & Motivational Alerts
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderGrey),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Notifications, contentDescription = null, tint = DeepPink, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Auto Study Reminders",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = AestheticBlack
                                )
                                Text(
                                    text = "Cute motivational nudges & streak protection",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextGrey
                                )
                            }
                        }

                        Switch(
                            checked = settings.autoNotificationsEnabled,
                            onCheckedChange = { isEnabled ->
                                onToggleAutoNotifications(isEnabled)
                                Toast.makeText(
                                    context,
                                    if (isEnabled) "Auto notifications enabled 🌸" else "Notifications paused",
                                    Toast.LENGTH_SHORT
                                ).show()
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = PureWhite, checkedTrackColor = DeepPink)
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            onTriggerTestNotification()
                            Toast.makeText(context, "Sent cute test notification! Check status bar 🔔", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(14.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, BorderGrey),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = AestheticBlack),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("test_auto_notification_btn")
                    ) {
                        Text("Send Test Motivational Notification ✨", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold))
                    }
                }
            }
        }

        // Pomodoro Lengths Card
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderGrey),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text(
                        text = "⏱️ Timer Intervals",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = AestheticBlack
                    )

                    // Focus duration slider
                    Column {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Focus Session:", style = MaterialTheme.typography.bodyMedium, color = TextGrey)
                            Text("${focusMin.toInt()} min", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = DeepPink)
                        }
                        Slider(
                            value = focusMin,
                            onValueChange = { focusMin = it; commit() },
                            valueRange = 5f..90f,
                            steps = 16,
                            colors = SliderDefaults.colors(thumbColor = DeepPink, activeTrackColor = KawaiiPink, inactiveTrackColor = CardGrey),
                            modifier = Modifier.testTag("focus_slider")
                        )
                    }

                    // Short break duration
                    Column {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Short Break:", style = MaterialTheme.typography.bodyMedium, color = TextGrey)
                            Text("${shortBreakMin.toInt()} min", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = DeepPink)
                        }
                        Slider(
                            value = shortBreakMin,
                            onValueChange = { shortBreakMin = it; commit() },
                            valueRange = 1f..30f,
                            steps = 28,
                            colors = SliderDefaults.colors(thumbColor = DeepPink, activeTrackColor = KawaiiPink, inactiveTrackColor = CardGrey)
                        )
                    }

                    // Long break duration
                    Column {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Long Break:", style = MaterialTheme.typography.bodyMedium, color = TextGrey)
                            Text("${longBreakMin.toInt()} min", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = DeepPink)
                        }
                        Slider(
                            value = longBreakMin,
                            onValueChange = { longBreakMin = it; commit() },
                            valueRange = 5f..60f,
                            steps = 10,
                            colors = SliderDefaults.colors(thumbColor = DeepPink, activeTrackColor = KawaiiPink, inactiveTrackColor = CardGrey)
                        )
                    }

                    // Interval cycles stepper
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Long Break Interval", style = MaterialTheme.typography.bodyMedium, color = AestheticBlack)
                            Text("Cycles before a long break", style = MaterialTheme.typography.labelSmall, color = TextGrey)
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(2, 3, 4, 5).forEach { num ->
                                val isSelected = longInterval == num
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isSelected) AestheticBlack else CardGrey,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable {
                                            longInterval = num
                                            commit()
                                        }
                                ) {
                                    Text(
                                        text = "$num",
                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                        color = if (isSelected) PureWhite else TextGrey,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Daily Target Goal Card
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderGrey),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "🎯 Daily Target Focus",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = AestheticBlack
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        val hours = dailyGoalMin.toInt() / 60
                        val mins = dailyGoalMin.toInt() % 60
                        Text("Target Goal:", style = MaterialTheme.typography.bodyMedium, color = TextGrey)
                        Text(
                            if (mins == 0) "${hours}h 00m" else "${hours}h ${mins}m",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                            color = DeepPink
                        )
                    }

                    Slider(
                        value = dailyGoalMin,
                        onValueChange = { dailyGoalMin = it; commit() },
                        valueRange = 30f..480f,
                        steps = 14,
                        colors = SliderDefaults.colors(thumbColor = DeepPink, activeTrackColor = KawaiiPink, inactiveTrackColor = CardGrey),
                        modifier = Modifier.testTag("daily_goal_slider")
                    )
                }
            }
        }

        // Sound & Haptic Alerts Card
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderGrey),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(
                        text = "🔔 Feedback & Haptics",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = AestheticBlack
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Completion Chime", style = MaterialTheme.typography.bodyMedium, color = AestheticBlack)
                            Text("Plays a gentle chime when session finishes", style = MaterialTheme.typography.labelSmall, color = TextGrey)
                        }
                        Switch(
                            checked = soundEnabled,
                            onCheckedChange = {
                                soundEnabled = it
                                commit()
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = PureWhite, checkedTrackColor = DeepPink)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Haptic Feedback", style = MaterialTheme.typography.bodyMedium, color = AestheticBlack)
                            Text("Gentle vibration on start and finish", style = MaterialTheme.typography.labelSmall, color = TextGrey)
                        }
                        Switch(
                            checked = vibrationEnabled,
                            onCheckedChange = {
                                vibrationEnabled = it
                                commit()
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = PureWhite, checkedTrackColor = DeepPink)
                        )
                    }
                }
            }
        }

        // Privacy & Disclaimers Card
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderGrey),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = DeepPink, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Privacy & Legal Disclaimers", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = AestheticBlack)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Your data stays 100% on your device with local Room database encryption. Zero ads, zero tracking, no cloud telemetry.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextGrey,
                        lineHeight = 18.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedButton(
                        onClick = { showPrivacyDialog = true },
                        shape = RoundedCornerShape(14.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, BorderGrey),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = AestheticBlack),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Read Full Privacy Statement 🔒", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold))
                    }
                }
            }
        }

        // Official Verification Email & Creator Code Portal
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = PureWhite),
                border = androidx.compose.foundation.BorderStroke(1.dp, BorderGrey),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Email, contentDescription = null, tint = DeepPink, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "VIP Support & Proof Verification",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = AestheticBlack
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Official email to submit ₹199 payment screenshots, bank UTRs, and receive VIP Activation Keys:",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextGrey,
                        lineHeight = 17.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Tap-to-copy email chip
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = CardGrey,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                clipboardManager.setText(AnnotatedString(creatorEmail))
                                Toast.makeText(context, "Copied: $creatorEmail 📋", Toast.LENGTH_SHORT).show()
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = creatorEmail,
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace
                                ),
                                color = AestheticBlack
                            )
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = DeepPink, modifier = Modifier.size(16.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            val intent = PaymentSecurityManager.createBuyerProofEmailIntent("", "")
                            try {
                                context.startActivity(Intent.createChooser(intent, "Email Support"))
                            } catch (_: Exception) {
                                clipboardManager.setText(AnnotatedString(creatorEmail))
                                Toast.makeText(context, "Copied email: $creatorEmail", Toast.LENGTH_SHORT).show()
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = DeepPink),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Email, contentDescription = null, tint = PureWhite, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("✉️ Email Payment Proof", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PureWhite)
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showVipDialog) {
        VipPaymentDialog(
            isVipActive = settings.isVipActive,
            onActivateVip = {
                onActivateVip()
                showVipDialog = false
            },
            onOpenPrivacy = {
                showVipDialog = false
                showPrivacyDialog = true
            },
            onDismiss = { showVipDialog = false }
        )
    }

    if (showPrivacyDialog) {
        PrivacyPolicyDialog(
            onDismiss = { showPrivacyDialog = false }
        )
    }
}
