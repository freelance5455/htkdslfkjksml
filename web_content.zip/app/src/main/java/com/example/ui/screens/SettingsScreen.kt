package com.example.ui.screens

import android.graphics.BitmapFactory
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.UserSettingsState
import com.example.data.model.BrowserViewMode
import com.example.data.model.SortField
import com.example.ui.theme.AccentPreset
import com.example.ui.theme.AnimationMode
import com.example.ui.theme.DynamicImageColorExtractor
import com.example.ui.theme.LocalAnimationSpecs
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    settings: UserSettingsState,
    onSetThemeMode: (ThemeMode) -> Unit,
    onSetAmoledBlack: (Boolean) -> Unit,
    onSetAccentPreset: (AccentPreset) -> Unit,
    onSetDynamicImageSeed: (Int) -> Unit,
    onSetAnimationMode: (AnimationMode) -> Unit,
    onSetDefaultView: (BrowserViewMode) -> Unit,
    onSetSort: (SortField, Boolean) -> Unit,
    onSetShowHidden: (Boolean) -> Unit,
    onSetShowExtensions: (Boolean) -> Unit,
    onSetAutoEmptyTrash: (Boolean) -> Unit,
    onSetLanguage: (String) -> Unit,
    onOpenPermissions: () -> Unit,
    onOpenTrash: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val animSpecs = LocalAnimationSpecs.current

    var animPreviewToggled by remember { mutableStateOf(false) }
    var showLanguageMenu by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val seed = withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(uri)?.use { stream ->
                        val bmp = BitmapFactory.decodeStream(stream)
                        bmp?.let { DynamicImageColorExtractor.extractSeedArgb(it) }
                    }
                }
                if (seed != null) {
                    onSetDynamicImageSeed(seed)
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My Files settings", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("settings_back_button")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. APPEARANCE (Theme Mode, AMOLED, 8 Accent Palettes + Dynamic Image)
            item {
                SettingsGroupCard(title = "Appearance") {
                    Text("Theme mode", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ThemeMode.entries.forEach { mode ->
                            FilterChip(
                                selected = settings.themeMode == mode,
                                onClick = { onSetThemeMode(mode) },
                                label = { Text(mode.label) },
                                modifier = Modifier.testTag("theme_mode_${mode.name.lowercase()}")
                            )
                        }
                    }

                    SettingsToggleRow(
                        title = "AMOLED pure black",
                        subtitle = "Use #000000 background in Dark mode to save OLED battery",
                        checked = settings.amoledBlack,
                        onCheckedChange = onSetAmoledBlack
                    )

                    HorizontalDivider()
                    Text("Accent color palette", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        AccentPreset.entries.filter { it != AccentPreset.DYNAMIC_IMAGE }.forEach { preset ->
                            val selected = settings.accentPreset == preset
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(preset.primaryLight)
                                    .border(
                                        width = if (selected) 3.dp else 0.dp,
                                        color = if (selected) MaterialTheme.colorScheme.onSurface else Color.Transparent,
                                        shape = CircleShape
                                    )
                                    .clickable { onSetAccentPreset(preset) }
                                    .testTag("accent_${preset.name.lowercase()}")
                            ) {
                                if (selected) {
                                    Icon(Icons.Filled.Check, contentDescription = preset.label, tint = Color.White, modifier = Modifier.size(20.dp))
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.ColorLens, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text("Dynamic palette from image", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                Text(
                                    if (settings.accentPreset == AccentPreset.DYNAMIC_IMAGE) "Active • Custom image seed applied" else "Generate theme colors from any photo",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        FilledTonalButton(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            modifier = Modifier.testTag("dynamic_image_palette_button")
                        ) {
                            Icon(Icons.Filled.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Pick Image")
                        }
                    }
                }
            }

            // 2. ANIMATIONS (Off / Medium / High Radio List + Interactive Live Preview)
            item {
                SettingsGroupCard(title = "Animations") {
                    if (settings.reducedMotionSuggested) {
                        Text(
                            "System reduced motion detected — Off mode was suggested initially.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    AnimationMode.entries.forEach { mode ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .clickable { onSetAnimationMode(mode) }
                                .padding(vertical = 6.dp)
                                .testTag("anim_mode_${mode.name.lowercase()}"),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = settings.animationMode == mode,
                                onClick = { onSetAnimationMode(mode) }
                            )
                            Spacer(Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(mode.label, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    mode.subtitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    // Live Interactive Preview Box reading LocalAnimationSpecs
                    val previewScale by animateFloatAsState(
                        targetValue = if (animPreviewToggled) 1.06f else 1f,
                        animationSpec = animSpecs.floatSpec(),
                        label = "preview_scale"
                    )
                    val previewBar by animateFloatAsState(
                        targetValue = if (animPreviewToggled) 0.86f else 0.34f,
                        animationSpec = animSpecs.progressSpec(),
                        label = "preview_bar"
                    )

                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .scale(previewScale)
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "Live Motion Preview (${settings.animationMode.name})",
                                    style = MaterialTheme.typography.labelLarge
                                )
                                FilledTonalButton(
                                    onClick = { animPreviewToggled = !animPreviewToggled },
                                    modifier = Modifier.testTag("test_animation_preview_button")
                                ) {
                                    Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("Preview")
                                }
                            }
                            LinearProgressIndicator(
                                progress = { previewBar },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                            )
                        }
                    }
                }
            }

            // 3. VIEW OPTIONS
            item {
                SettingsGroupCard(title = "View options") {
                    Text("Default browser view", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        BrowserViewMode.entries.forEach { vm ->
                            FilterChip(
                                selected = settings.viewMode == vm,
                                onClick = { onSetDefaultView(vm) },
                                label = { Text(vm.label) }
                            )
                        }
                    }

                    Text("Default sort field", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SortField.entries.forEach { sf ->
                            FilterChip(
                                selected = settings.sortField == sf,
                                onClick = { onSetSort(sf, settings.sortAscending) },
                                label = { Text(sf.label) }
                            )
                        }
                    }

                    SettingsToggleRow(
                        title = "Show hidden files",
                        subtitle = "Display dotfiles (starting with .) and hidden items",
                        checked = settings.showHiddenFiles,
                        onCheckedChange = onSetShowHidden
                    )

                    SettingsToggleRow(
                        title = "Show file extensions",
                        subtitle = "Display suffixes like .pdf, .apk, .jpg in file lists",
                        checked = settings.showFileExtensions,
                        onCheckedChange = onSetShowExtensions
                    )
                }
            }

            // 4. PERMISSIONS & STORAGE / TRASH
            item {
                SettingsGroupCard(title = "Permissions, Storage & Trash") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .clickable(onClick = onOpenPermissions)
                            .padding(vertical = 10.dp)
                            .testTag("settings_open_permissions_row"),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Permissions & Access", style = MaterialTheme.typography.titleSmall)
                            Text(
                                "Manage SAF folders, Camera, Microphone, Notifications & USB",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Icon(Icons.Filled.ChevronRight, contentDescription = null)
                    }

                    HorizontalDivider()

                    SettingsToggleRow(
                        title = "Auto-empty Trash after 30 days",
                        subtitle = "Automatically purge Recycle bin items older than 30 days",
                        checked = settings.autoEmptyTrash30Days,
                        onCheckedChange = onSetAutoEmptyTrash
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .clickable(onClick = onOpenTrash)
                            .padding(vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Open Trash / Recycle bin", style = MaterialTheme.typography.titleSmall)
                        Icon(Icons.Filled.ChevronRight, contentDescription = null)
                    }
                }
            }

            // 5. LANGUAGE & ABOUT
            item {
                SettingsGroupCard(title = "General & About") {
                    Box {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .clickable { showLanguageMenu = true }
                                .padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Language", style = MaterialTheme.typography.titleSmall)
                                Text(
                                    settings.languageLabel,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Icon(Icons.Filled.ChevronRight, contentDescription = null)
                        }
                        DropdownMenu(
                            expanded = showLanguageMenu,
                            onDismissRequest = { showLanguageMenu = false }
                        ) {
                            listOf(
                                "English (United States)",
                                "한국어 (Korean)",
                                "Español (Estados Unidos)",
                                "Deutsch (Deutschland)",
                                "日本語 (Japanese)"
                            ).forEach { lang ->
                                DropdownMenuItem(
                                    text = { Text(lang) },
                                    onClick = {
                                        showLanguageMenu = false
                                        onSetLanguage(lang)
                                    }
                                )
                            }
                        }
                    }

                    HorizontalDivider()

                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("About My Files", style = MaterialTheme.typography.titleSmall)
                        Text(
                            "Version 1.0.0 • One UI 7 Style • Powered by Android SAF, Media3 & Firebase Gemini AI Logic",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsGroupCard(
    title: String,
    content: @Composable () -> Unit
) {
    Column(
        modifier = Modifier
            .widthIn(max = 640.dp)
            .fillMaxWidth()
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(start = 8.dp, bottom = 8.dp)
        )
        Card(
            shape = RoundedCornerShape(26.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                content()
            }
        }
    }
}

@Composable
private fun SettingsToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
