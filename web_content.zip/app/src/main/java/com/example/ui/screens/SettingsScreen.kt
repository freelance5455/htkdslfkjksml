package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Gesture
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.HapticProfile
import com.example.data.KeyboardLanguage
import com.example.data.VelvetSettings
import com.example.ui.VelvetMainViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    viewModel: VelvetMainViewModel,
    settings: VelvetSettings,
    hasMicPermission: Boolean,
    onRequestMicPermission: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currentView = LocalView.current

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Personalization & Engine",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )

        // 1. Multi-Language Support
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Language,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Column {
                        Text(
                            text = "Languages & Layouts",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Tap to add/remove languages. Tap 🌐 on the keyboard to switch.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    KeyboardLanguage.entries.forEach { lang ->
                        val enabled = lang in settings.enabledLanguages
                        FilterChip(
                            selected = enabled,
                            onClick = { viewModel.toggleLanguageEnabled(lang) },
                            label = {
                                Text(
                                    text = if (settings.activeLanguage == lang) "${lang.nativeName} (Active)"
                                    else lang.nativeName
                                )
                            },
                            modifier = Modifier.testTag("lang_chip_${lang.id}")
                        )
                    }
                }

                if (settings.enabledLanguages.size > 1) {
                    Text(
                        text = "Active Layout:",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        settings.enabledLanguages.forEach { lang ->
                            FilterChip(
                                selected = settings.activeLanguage == lang,
                                onClick = { viewModel.setActiveLanguage(lang) },
                                label = { Text(lang.shortCode) }
                            )
                        }
                    }
                }
            }
        }

        // 2. iOS-Style Haptics Section
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .padding(end = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Vibration,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "iOS Taptic Haptics",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    FilledTonalButton(
                        onClick = { viewModel.testCurrentHaptic(currentView) },
                        contentPadding = PaddingValues(horizontal = 12.dp),
                        modifier = Modifier.testTag("test_haptic_button")
                    ) {
                        Text("Test Feel")
                    }
                }

                HapticProfile.entries.forEach { profile ->
                    val selected = settings.hapticProfile == profile
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .border(
                                width = if (selected) 1.5.dp else 0.5.dp,
                                color = if (selected) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.outline.copy(alpha = 0.25f),
                                shape = RoundedCornerShape(14.dp)
                            )
                            .clickable { viewModel.setHapticProfile(profile, currentView) }
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                            .testTag("haptic_option_${profile.id}"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selected,
                            onClick = { viewModel.setHapticProfile(profile, currentView) }
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = profile.label,
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = profile.description,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                SettingSwitchRow(
                    title = "Soft Key Click Sound",
                    subtitle = "Pair tactile haptics with a subtle mechanical tap sound",
                    checked = settings.keySoundEnabled,
                    onCheckedChange = viewModel::setKeySoundEnabled,
                    testTag = "switch_key_sound"
                )
            }
        }

        // 3. Adaptive Slang & Smart Predictions
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(bottom = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Psychology,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Adaptive Slang & Vocabulary",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                SettingSwitchRow(
                    title = "Adapt to My Slang & Style",
                    subtitle = "Learn your frequent slang, shortcuts, and phrasing automatically",
                    checked = settings.adaptToSlangEnabled,
                    onCheckedChange = viewModel::setAdaptToSlangEnabled,
                    testTag = "switch_adapt_slang"
                )

                if (settings.learnedWords.isNotEmpty()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Learned words (${settings.learnedWords.size}):",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        TextButton(onClick = { viewModel.clearLearnedSlang() }) {
                            Text("Reset")
                        }
                    }
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        settings.learnedWords.entries
                            .sortedByDescending { it.value }
                            .take(10)
                            .forEach { (word, count) ->
                                AssistChip(
                                    onClick = {},
                                    label = { Text("$word ($count)") }
                                )
                            }
                    }
                }
            }
        }

        // 4. Clipboard & Motion
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(bottom = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentPaste,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Clipboard & Feel",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                SettingSwitchRow(
                    title = "Clipboard History Manager",
                    subtitle = "Save copied text for 1-tap pasting & pinning in the keyboard",
                    checked = settings.clipboardHistoryEnabled,
                    onCheckedChange = viewModel::setClipboardHistoryEnabled,
                    testTag = "switch_clipboard"
                )
                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                SettingSwitchRow(
                    title = "Alive Motion & Organic Glow",
                    subtitle = "Subtle drifting botanical light & lively spring key feedback",
                    checked = settings.aliveMotionEnabled,
                    onCheckedChange = viewModel::setAliveMotionEnabled,
                    testTag = "switch_alive_motion"
                )
                Column(modifier = Modifier.padding(top = 6.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Key Height Scale", style = MaterialTheme.typography.bodyMedium)
                        Text("${(settings.keyHeightScale * 100).toInt()}%", color = MaterialTheme.colorScheme.primary)
                    }
                    Slider(
                        value = settings.keyHeightScale,
                        onValueChange = { viewModel.setKeyHeightScale(it) },
                        valueRange = 0.85f..1.20f
                    )
                }
            }
        }

        // 5. Typing, Swipe & Predictions
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(bottom = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Gesture,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Swipe & Word Predictions",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                SettingSwitchRow(
                    title = "Swipe-to-Type Glide",
                    subtitle = "Fast sub-2ms swipe decoding with luminous trail",
                    checked = settings.swipeTypingEnabled,
                    onCheckedChange = viewModel::setSwipeTypingEnabled,
                    testTag = "switch_swipe_typing"
                )
                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                SettingSwitchRow(
                    title = "iOS QuickType Predictions",
                    subtitle = "3-slot top prediction bar",
                    checked = settings.predictionsEnabled,
                    onCheckedChange = viewModel::setPredictionsEnabled,
                    testTag = "switch_predictions"
                )
                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                SettingSwitchRow(
                    title = "Key Preview Bubbles",
                    subtitle = "Floating iOS character pop-ups on tap",
                    checked = settings.keyPopupEnabled,
                    onCheckedChange = viewModel::setKeyPopupEnabled,
                    testTag = "switch_key_popup"
                )
                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                SettingSwitchRow(
                    title = "Auto-Capitalization",
                    subtitle = "Capitalize first letter of sentences",
                    checked = settings.autoCapitalizeEnabled,
                    onCheckedChange = viewModel::setAutoCapitalizeEnabled,
                    testTag = "switch_auto_cap"
                )
                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                SettingSwitchRow(
                    title = "Double-Space Period",
                    subtitle = "Double-tap Spacebar to insert '. '",
                    checked = settings.doubleSpacePeriodEnabled,
                    onCheckedChange = viewModel::setDoubleSpacePeriodEnabled,
                    testTag = "switch_double_space"
                )
            }
        }

        // 6. Velvet AI Voice & Writing
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(bottom = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Velvet AI Voice & Writing",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                SettingSwitchRow(
                    title = "Remove Verbal Starters",
                    subtitle = "Strip 'um', 'uh', 'like', 'so basically' & self-corrections",
                    checked = settings.aiRemoveStartersEnabled,
                    onCheckedChange = viewModel::setAiRemoveStartersEnabled,
                    testTag = "switch_ai_starters"
                )
                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                SettingSwitchRow(
                    title = "Automatic ? & ! Punctuation",
                    subtitle = "Add question marks and exclamation points for clarity",
                    checked = settings.aiAutoPunctuationEnabled,
                    onCheckedChange = viewModel::setAiAutoPunctuationEnabled,
                    testTag = "switch_ai_punctuation"
                )
                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                SettingSwitchRow(
                    title = "Pure AI Mic (No Google Popup)",
                    subtitle = "Record directly to Gemini AI voice engine instead of device speech service",
                    checked = settings.pureAiVoiceEnabled,
                    onCheckedChange = viewModel::setPureAiVoiceEnabled,
                    testTag = "switch_pure_ai_voice"
                )
                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                SettingSwitchRow(
                    title = "AI Contextual Next-Word Boost",
                    subtitle = "Smart next-word suggestions tailored to your slang",
                    checked = settings.aiSmartPredictEnabled,
                    onCheckedChange = viewModel::setAiSmartPredictEnabled,
                    testTag = "switch_ai_predict"
                )
                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = null,
                            tint = if (hasMicPermission) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(20.dp)
                        )
                        Column {
                            Text("Microphone Access", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                            Text(
                                text = if (hasMicPermission) "Ready for inline Velvet AI voice"
                                else "Permission required for voice dictation",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    if (!hasMicPermission) {
                        FilledTonalButton(onClick = onRequestMicPermission) {
                            Text("Allow")
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
    }
}

@Composable
private fun SettingSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(end = 12.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(testTag)
        )
    }
}
