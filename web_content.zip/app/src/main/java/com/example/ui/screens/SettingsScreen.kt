package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainViewModel
import com.example.ui.components.SuesaHeader
import com.example.ui.theme.AccentError
import com.example.ui.theme.AccentSuccess
import com.example.ui.theme.PurpleDark
import com.example.ui.theme.PurpleLight
import com.example.ui.theme.PurplePrimary
import com.example.ui.theme.SuesaBackground
import com.example.ui.theme.SuesaCardBorder
import com.example.ui.theme.SuesaSurface
import com.example.ui.theme.SuesaSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    onOpenDrawer: () -> Unit,
    onBackToChat: () -> Unit
) {
    BackHandler {
        onBackToChat()
    }

    val context = LocalContext.current
    val apiKey by viewModel.settingsApiKey.collectAsStateWithLifecycle()
    val ttsAutoSpeak by viewModel.settingsTtsAutoSpeak.collectAsStateWithLifecycle()
    val speechRate by viewModel.settingsSpeechRate.collectAsStateWithLifecycle()
    val isTestingApi by viewModel.isTestingApi.collectAsStateWithLifecycle()
    val apiTestMessage by viewModel.apiTestMessage.collectAsStateWithLifecycle()
    val apiTestSuccess by viewModel.apiTestSuccess.collectAsStateWithLifecycle()

    var showClearHistoryDialog by remember { mutableStateOf(false) }
    var passwordVisible by remember { mutableStateOf(false) }

    // Permissions check states
    var hasCameraPerm by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    var hasAudioPerm by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }

    val cameraPermLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPerm = granted
        val msg = if (granted) "Kamera izni verildi." else "Kamera izni reddedildi."
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
    }

    val audioPermLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasAudioPerm = granted
        val msg = if (granted) "Mikrofon izni verildi." else "Mikrofon izni reddedildi."
        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SuesaBackground)
            .statusBarsPadding()
    ) {
        // Header
        SuesaHeader(
            title = "Ayarlar",
            onMenuClick = onOpenDrawer
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // ==================== SECTION: GEMINI API ====================
            SettingsSectionHeader(title = "GEMINI API AYARLARI", icon = Icons.Default.Key)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(SuesaSurface)
                    .border(1.dp, SuesaCardBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Özel API Anahtarı",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "İsteğe bağlı olarak kendi Google Gemini API anahtarınızı girebilirsiniz. Anahtarınız yalnızca cihazınızda güvenli olarak saklanır.",
                        color = TextSecondary,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )

                    OutlinedTextField(
                        value = apiKey,
                        onValueChange = { viewModel.settingsApiKey.value = it },
                        placeholder = { Text("AIzaSy...", color = TextMuted) },
                        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = if (passwordVisible) "Gizle" else "Göster",
                                    tint = TextMuted
                                )
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(SuesaSurfaceVariant)
                            .testTag("api_key_input"),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = SuesaSurfaceVariant,
                            unfocusedContainerColor = SuesaSurfaceVariant,
                            focusedIndicatorColor = PurplePrimary,
                            unfocusedIndicatorColor = SuesaCardBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        singleLine = true
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Kaydet butonu
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Brush.linearGradient(listOf(PurpleDark, PurplePrimary)))
                                .clickable {
                                    viewModel.saveCustomApiKey(apiKey)
                                    Toast.makeText(context, "API anahtarı kaydedildi.", Toast.LENGTH_SHORT).show()
                                }
                                .padding(vertical = 10.dp)
                                .testTag("save_api_key_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Kaydet",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        // Test Et butonu
                        Box(
                            modifier = Modifier
                                .weight(1.3f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(SuesaSurfaceVariant)
                                .border(1.dp, SuesaCardBorder, RoundedCornerShape(10.dp))
                                .clickable(enabled = !isTestingApi) {
                                    viewModel.testApiConnection()
                                }
                                .padding(vertical = 10.dp)
                                .testTag("test_api_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isTestingApi) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        color = PurpleLight,
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Test ediliyor...",
                                        color = TextSecondary,
                                        fontSize = 12.sp
                                    )
                                }
                            } else {
                                Text(
                                    text = "Bağlantıyı Test Et",
                                    color = PurpleLight,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    // Test result banner
                    if (apiTestMessage != null) {
                        val isSuccess = apiTestSuccess == true
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSuccess) Color(0xFF14291B) else Color(0xFF2A1515))
                                .border(
                                    1.dp,
                                    if (isSuccess) AccentSuccess.copy(alpha = 0.5f) else AccentError.copy(alpha = 0.5f),
                                    RoundedCornerShape(10.dp)
                                )
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (isSuccess) Icons.Default.CheckCircle else Icons.Default.Error,
                                contentDescription = if (isSuccess) "Başarılı" else "Hata",
                                tint = if (isSuccess) AccentSuccess else AccentError,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = apiTestMessage ?: "",
                                color = if (isSuccess) AccentSuccess else Color(0xFFFFD4D4),
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            // ==================== SECTION: SES VE KONUŞMA ====================
            SettingsSectionHeader(title = "SES VE KONUŞMA AYARLARI", icon = Icons.AutoMirrored.Filled.VolumeUp)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(SuesaSurface)
                    .border(1.dp, SuesaCardBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    // TTS Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Sohbet Yanıtlarını Sesli Oku",
                                color = TextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Suesa'nın her cevabı otomatik seslendirilsin.",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }

                        Switch(
                            checked = ttsAutoSpeak,
                            onCheckedChange = { viewModel.setTtsAutoSpeak(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = PurplePrimary,
                                uncheckedThumbColor = TextMuted,
                                uncheckedTrackColor = SuesaSurfaceVariant
                            ),
                            modifier = Modifier.testTag("tts_auto_speak_switch")
                        )
                    }

                    // Speech Rate Slider
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Konuşma Hızı",
                                color = TextPrimary,
                                fontSize = 14.sp
                            )
                            Text(
                                text = String.format("%.1fx", speechRate),
                                color = PurpleLight,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Slider(
                            value = speechRate,
                            onValueChange = { viewModel.setSpeechRate(it) },
                            valueRange = 0.7f..1.5f,
                            steps = 7,
                            colors = SliderDefaults.colors(
                                thumbColor = PurplePrimary,
                                activeTrackColor = PurplePrimary,
                                inactiveTrackColor = SuesaSurfaceVariant
                            ),
                            modifier = Modifier.testTag("speech_rate_slider")
                        )
                    }

                    // Test Sesi Butonu
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(SuesaSurfaceVariant)
                            .border(1.dp, SuesaCardBorder, RoundedCornerShape(10.dp))
                            .clickable {
                                viewModel.speechHelper.speak(
                                    "Merhaba! Ben Suesa AI, Türkçe sesli asistanınızım.",
                                    speechRate
                                )
                            }
                            .padding(vertical = 10.dp)
                            .testTag("test_voice_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Sesi Test Et",
                            color = PurpleLight,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // ==================== SECTION: İZİNLER ====================
            SettingsSectionHeader(title = "UYGULAMA İZİNLERİ", icon = Icons.Default.Security)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(SuesaSurface)
                    .border(1.dp, SuesaCardBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    // Kamera İzni
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.PhotoCamera,
                                contentDescription = "Kamera",
                                tint = PurpleLight,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Kamera İzni", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                Text(
                                    text = if (hasCameraPerm) "İzin Verildi" else "İzin Verilmedi",
                                    color = if (hasCameraPerm) AccentSuccess else AccentError,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        if (!hasCameraPerm) {
                            TextButton(onClick = { cameraPermLauncher.launch(Manifest.permission.CAMERA) }) {
                                Text("İzin İste", color = PurpleLight, fontSize = 13.sp)
                            }
                        } else {
                            Icon(Icons.Default.Check, contentDescription = "Aktif", tint = AccentSuccess, modifier = Modifier.size(20.dp))
                        }
                    }

                    // Mikrofon İzni
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = "Mikrofon",
                                tint = PurpleLight,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Mikrofon İzni", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                Text(
                                    text = if (hasAudioPerm) "İzin Verildi" else "İzin Verilmedi",
                                    color = if (hasAudioPerm) AccentSuccess else AccentError,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        if (!hasAudioPerm) {
                            TextButton(onClick = { audioPermLauncher.launch(Manifest.permission.RECORD_AUDIO) }) {
                                Text("İzin İste", color = PurpleLight, fontSize = 13.sp)
                            }
                        } else {
                            Icon(Icons.Default.Check, contentDescription = "Aktif", tint = AccentSuccess, modifier = Modifier.size(20.dp))
                        }
                    }
                }
            }

            // ==================== SECTION: GEÇMİŞ VE VERİ ====================
            SettingsSectionHeader(title = "VERİ VE GEÇMİŞ", icon = Icons.Default.DeleteSweep)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(SuesaSurface)
                    .border(1.dp, SuesaCardBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Sohbet Verileri",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Tüm sohbet geçmişinizi ve mesaj kayıtlarını kalıcı olarak silebilirsiniz.",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF2A1515))
                            .border(1.dp, AccentError.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                            .clickable { showClearHistoryDialog = true }
                            .padding(vertical = 11.dp)
                            .testTag("clear_all_history_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Tüm Sohbet Geçmişini Temizle",
                            color = AccentError,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // ==================== SECTION: HAKKINDA ====================
            SettingsSectionHeader(title = "UYGULAMA HAKKINDA", icon = Icons.Default.Info)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(SuesaSurface)
                    .border(1.dp, SuesaCardBorder, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Uygulama Adı", color = TextSecondary, fontSize = 13.sp)
                        Text("Suesa AI", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Sürüm", color = TextSecondary, fontSize = 13.sp)
                        Text("1.0.0", color = TextPrimary, fontSize = 13.sp)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Yapay Zekâ Motoru", color = TextSecondary, fontSize = 13.sp)
                        Text("Google Gemini", color = PurpleLight, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Gizlilik: Sohbetleriniz ve görselleriniz cihazınızda yerel Room veritabanında güvenle tutulur. Dış sunuculara sadece yapay zekâ istekleri iletilir.",
                        color = TextMuted,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    // Clear History Dialog
    if (showClearHistoryDialog) {
        AlertDialog(
            onDismissRequest = { showClearHistoryDialog = false },
            title = {
                Text(
                    text = "Tüm Geçmişi Temizle",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Text(
                    text = "Tüm sohbet geçmişiniz silinecektir. Bu işlem geri alınamaz. Emin misiniz?",
                    color = TextSecondary,
                    fontSize = 14.sp
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.clearAllHistory {
                            showClearHistoryDialog = false
                            Toast.makeText(context, "Tüm sohbet geçmişi temizlendi.", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = AccentError),
                    modifier = Modifier.testTag("confirm_clear_history_button")
                ) {
                    Text("Temizle", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showClearHistoryDialog = false },
                    colors = ButtonDefaults.textButtonColors(contentColor = TextSecondary)
                ) {
                    Text("İptal")
                }
            },
            containerColor = SuesaSurface,
            shape = RoundedCornerShape(16.dp)
        )
    }
}

@Composable
fun SettingsSectionHeader(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = PurplePrimary,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = title,
            color = PurpleLight,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
    }
}
