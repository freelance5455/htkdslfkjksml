package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppConfig

@Composable
fun AdminDialog(
    config: AppConfig,
    isAuthenticated: Boolean,
    onVerifyPassword: (String) -> Boolean,
    onSaveConfig: (AppConfig) -> Unit,
    onDismiss: () -> Unit
) {
    var password by remember { mutableStateOf("") }
    var passwordError by remember { mutableStateOf(false) }

    // Campos de configuración
    var activeServerType by remember { mutableStateOf(config.activeServerType) }
    var exarotonToken by remember { mutableStateOf(config.exarotonApiToken) }
    var exarotonServerId by remember { mutableStateOf(config.exarotonServerId) }
    var aternosIp by remember { mutableStateOf(config.aternosServerIp) }
    var bedrockWsUrl by remember { mutableStateOf(config.bedrockWsUrl) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1C2028),
        shape = RoundedCornerShape(16.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = "🔒 ", fontSize = 20.sp)
                Text(
                    text = "Panel de Control Admin",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = Color(0xFFE63946)
                )
            }
        },
        text = {
            if (!isAuthenticated) {
                // PANTALLA DE ACCESO RESTRINGIDO (CLAVE JuancitoChen23)
                Column {
                    Text(
                        text = "Acceso restringido para el creador. Ingresa la clave secreta de administración:",
                        fontSize = 13.sp,
                        color = Color(0xFFA0AEC0)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = password,
                        onValueChange = {
                            password = it
                            passwordError = false
                        },
                        placeholder = { Text("Clave secreta...", fontSize = 13.sp) },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        isError = passwordError,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFE63946),
                            unfocusedBorderColor = Color(0xFF333A47),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().testTag("admin_password_input")
                    )

                    if (passwordError) {
                        Text(
                            text = "Clave secreta incorrecta.",
                            color = Color(0xFFE74C3C),
                            fontSize = 11.sp,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            } else {
                // PANTALLA DE CONFIGURACIÓN DE SERVIDOR EN TIEMPO REAL
                Column {
                    Text(
                        text = "CONFIGURACIÓN EN TIEMPO REAL",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFA0AEC0)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Selector de tipo de servidor (Exaroton vs Aternos)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF14181F))
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (activeServerType == "exaroton") Color(0xFFFFB703) else Color.Transparent)
                                .clickable { activeServerType = "exaroton" }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Exaroton",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (activeServerType == "exaroton") Color.Black else Color.White
                            )
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (activeServerType == "aternos") Color(0xFFFFB703) else Color.Transparent)
                                .clickable { activeServerType = "aternos" }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Aternos / IP",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (activeServerType == "aternos") Color.Black else Color.White
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (activeServerType == "exaroton") {
                        OutlinedTextField(
                            value = exarotonToken,
                            onValueChange = { exarotonToken = it },
                            label = { Text("Exaroton API Token", fontSize = 11.sp) },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFFFFB703),
                                unfocusedBorderColor = Color(0xFF333A47),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth().testTag("admin_exaroton_token")
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = exarotonServerId,
                            onValueChange = { exarotonServerId = it },
                            label = { Text("Exaroton Server ID", fontSize = 11.sp) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFFFFB703),
                                unfocusedBorderColor = Color(0xFF333A47),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth().testTag("admin_exaroton_id")
                        )
                    } else {
                        OutlinedTextField(
                            value = aternosIp,
                            onValueChange = { aternosIp = it },
                            label = { Text("IP de Servidor Aternos / Java / Bedrock", fontSize = 11.sp) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFFFFB703),
                                unfocusedBorderColor = Color(0xFF333A47),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth().testTag("admin_aternos_ip")
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = bedrockWsUrl,
                        onValueChange = { bedrockWsUrl = it },
                        label = { Text("URL WebSocket Puente Bedrock", fontSize = 11.sp) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFFFB703),
                            unfocusedBorderColor = Color(0xFF333A47),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().testTag("admin_bedrock_ws_url")
                    )
                }
            }
        },
        confirmButton = {
            if (!isAuthenticated) {
                Button(
                    onClick = {
                        val ok = onVerifyPassword(password.trim())
                        if (!ok) passwordError = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE63946)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("btn_admin_login")
                ) {
                    Text("Ingresar", color = Color.White, fontWeight = FontWeight.Bold)
                }
            } else {
                Button(
                    onClick = {
                        val updated = config.copy(
                            activeServerType = activeServerType,
                            exarotonApiToken = exarotonToken.trim(),
                            exarotonServerId = exarotonServerId.trim(),
                            aternosServerIp = aternosIp.trim(),
                            bedrockWsUrl = bedrockWsUrl.trim()
                        )
                        onSaveConfig(updated)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB703)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("btn_save_admin_config")
                ) {
                    Text("Guardar", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Cancelar", color = Color(0xFFA0AEC0))
            }
        }
    )
}
