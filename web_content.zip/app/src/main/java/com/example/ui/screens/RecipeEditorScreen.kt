package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.engine.RecipeParser
import com.example.viewmodel.MotionForgeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecipeEditorScreen(
  viewModel: MotionForgeViewModel,
  onBack: () -> Unit,
  onNavigateToPreview: () -> Unit
) {
  val validationResult by viewModel.validationResult.collectAsState()
  val sampleRecipes = remember { RecipeParser.getSampleRecipes() }
  var codeText by remember { mutableStateOf(sampleRecipes.values.first()) }
  var statusMessage by remember { mutableStateOf("") }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("I Have Code / Recipe Editor") },
        navigationIcon = {
          IconButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = null)
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
      )
    }
  ) { padding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(padding)
        .background(MaterialTheme.colorScheme.background)
        .padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      Text(
        text = "Paste your ChatGPT / AI generated animation recipe below:",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      OutlinedTextField(
        value = codeText,
        onValueChange = { codeText = it },
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f),
        textStyle = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurface),
        shape = RoundedCornerShape(12.dp),
        colors = OutlinedTextFieldDefaults.colors(
          focusedBorderColor = MaterialTheme.colorScheme.primary,
          unfocusedBorderColor = MaterialTheme.colorScheme.outline
        )
      )

      validationResult?.let { res ->
        Card(
          modifier = Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(
            containerColor = if (res.isValid) Color(0xFF1B3B2B) else Color(0xFF3B1B1B)
          )
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = if (res.isValid) Icons.Default.CheckCircle else Icons.Default.Error,
                contentDescription = null,
                tint = if (res.isValid) Color(0xFF4CAF50) else Color(0xFFF44336)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = if (res.isValid) "Recipe Validated Successfully" else "Validation Errors Found",
                fontWeight = FontWeight.Bold,
                color = Color.White
              )
            }
            if (res.errors.isNotEmpty()) {
              Spacer(modifier = Modifier.height(4.dp))
              res.errors.forEach { err ->
                Text(text = "• $err", style = MaterialTheme.typography.bodySmall, color = Color(0xFFFF8A80))
              }
            }
            if (res.warnings.isNotEmpty()) {
              Spacer(modifier = Modifier.height(4.dp))
              res.warnings.forEach { warn ->
                Text(text = "• $warn", style = MaterialTheme.typography.bodySmall, color = Color(0xFFFFD54F))
              }
            }
          }
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Button(
          onClick = {
            viewModel.loadRecipeJson(codeText)
            statusMessage = "Recipe parsed and loaded!"
          },
          modifier = Modifier.weight(1f),
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
        ) {
          Icon(Icons.Default.Check, contentDescription = null)
          Spacer(modifier = Modifier.width(4.dp))
          Text("Validate & Build")
        }

        Button(
          onClick = {
            viewModel.loadRecipeJson(codeText)
            onNavigateToPreview()
          },
          modifier = Modifier.weight(1f),
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
          Icon(Icons.Default.PlayArrow, contentDescription = null)
          Spacer(modifier = Modifier.width(4.dp))
          Text("Generate & Preview")
        }
      }

      if (statusMessage.isNotEmpty()) {
        Text(
          text = statusMessage,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.primary
        )
      }
    }
  }
}
