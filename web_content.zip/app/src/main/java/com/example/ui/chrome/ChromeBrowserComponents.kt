package com.example.ui.chrome

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BrowserTab
import com.example.model.DisplayResolution
import com.example.ui.xp.WindowsXpTheme

@Composable
fun ChromeBrowserHeader(
    tabs: List<BrowserTab>,
    activeTabId: String,
    onSelectTab: (String) -> Unit,
    onCloseTab: (String) -> Unit,
    onNewTab: () -> Unit,
    onToggleBrowserMode: () -> Unit,
    isWidescreen16x9: Boolean = true,
    displayResolution: DisplayResolution = DisplayResolution.RES_1080P_FHD,
    onToggleWidescreen: () -> Unit = {},
    onOpenResolutionDialog: () -> Unit = {},
    onRotateScreen: () -> Unit = {},
    canGoBack: Boolean,
    canGoForward: Boolean,
    isLoading: Boolean,
    progress: Int,
    currentUrl: String,
    isSecure: Boolean,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onRefresh: () -> Unit,
    onStop: () -> Unit,
    onHome: () -> Unit,
    onNavigate: (String) -> Unit,
    onOpenFlashSettings: () -> Unit,
    onOpenEraSites: () -> Unit,
    onOpenWayback: () -> Unit,
    onToggleCrt: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFFDEE1E6))
    ) {
        // Tab Strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp, start = 6.dp, end = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Scrollable tabs
            Row(
                modifier = Modifier
                    .weight(1f)
                    .horizontalScroll(rememberScrollState()),
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                tabs.forEach { tab ->
                    val isActive = tab.id == activeTabId
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                            .background(if (isActive) Color(0xFFFFFFFF) else Color(0xFFCED4DA))
                            .clickable { onSelectTab(tab.id) }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                            .width(140.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Public,
                            contentDescription = null,
                            tint = if (isActive) Color(0xFF1A73E8) else Color.Gray,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = tab.title.ifBlank { "New Tab" },
                            fontSize = 11.sp,
                            fontWeight = if (isActive) FontWeight.SemiBold else FontWeight.Normal,
                            color = Color(0xFF202124),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        if (tabs.size > 1) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close tab",
                                tint = Color.Gray,
                                modifier = Modifier
                                    .size(14.dp)
                                    .clickable { onCloseTab(tab.id) }
                            )
                        }
                    }
                }

                // New Tab button '+'
                IconButton(
                    onClick = onNewTab,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "New Tab",
                        tint = Color(0xFF444746),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            // Resolution Badge (1080p FHD default)
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (displayResolution == DisplayResolution.RES_1080P_FHD) Color(0xFF1B5E20) else Color(0xFF0058EE))
                    .clickable { onOpenResolutionDialog() }
                    .padding(horizontal = 6.dp, vertical = 4.dp)
                    .testTag("chrome_resolution_button"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = displayResolution.shortLabel,
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.width(3.dp))

            // 16:9 Widescreen Toggle Button
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (isWidescreen16x9) Color(0xFF1B5E20) else Color(0xFF455A64))
                    .clickable { onToggleWidescreen() }
                    .padding(horizontal = 6.dp, vertical = 4.dp)
                    .testTag("chrome_toggle_16x9_button"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isWidescreen16x9) "16:9 ON" else "16:9 OFF",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.width(3.dp))

            // Rotate button
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF37474F))
                    .clickable { onRotateScreen() }
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "⤾ Rotate",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.width(3.dp))

            // Switch to Windows XP Mode Button
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF0058EE))
                    .clickable { onToggleBrowserMode() }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                    .testTag("switch_to_xp_button"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.SwapHoriz,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(3.dp))
                Text(
                    text = "XP IE6 Mode",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Chrome Toolbar: Navigation + Omnibox
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .padding(horizontal = 6.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                enabled = canGoBack,
                modifier = Modifier.size(30.dp)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = if (canGoBack) Color(0xFF1F1F1F) else Color(0xFFB0B0B0),
                    modifier = Modifier.size(18.dp)
                )
            }

            IconButton(
                onClick = onForward,
                enabled = canGoForward,
                modifier = Modifier.size(30.dp)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = "Forward",
                    tint = if (canGoForward) Color(0xFF1F1F1F) else Color(0xFFB0B0B0),
                    modifier = Modifier.size(18.dp)
                )
            }

            IconButton(
                onClick = if (isLoading) onStop else onRefresh,
                modifier = Modifier.size(30.dp)
            ) {
                Icon(
                    imageVector = if (isLoading) Icons.Default.Stop else Icons.Default.Refresh,
                    contentDescription = if (isLoading) "Stop" else "Reload",
                    tint = Color(0xFF1F1F1F),
                    modifier = Modifier.size(18.dp)
                )
            }

            IconButton(
                onClick = onHome,
                modifier = Modifier.size(30.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Home,
                    contentDescription = "Home",
                    tint = Color(0xFF1F1F1F),
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(4.dp))

            // Omnibox
            var omniboxText by remember(currentUrl) { mutableStateOf(currentUrl) }

            Row(
                modifier = Modifier
                    .weight(1f)
                    .height(34.dp)
                    .clip(RoundedCornerShape(17.dp))
                    .background(Color(0xFFF1F3F4))
                    .padding(horizontal = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (isSecure) Icons.Default.Lock else Icons.Default.Public,
                    contentDescription = null,
                    tint = if (isSecure) Color(0xFF1E8E3E) else Color(0xFF5F6368),
                    modifier = Modifier.size(14.dp)
                )

                Spacer(modifier = Modifier.width(6.dp))

                BasicTextField(
                    value = omniboxText,
                    onValueChange = { omniboxText = it },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    textStyle = TextStyle(
                        fontSize = 13.sp,
                        color = Color(0xFF202124)
                    ),
                    cursorBrush = SolidColor(Color(0xFF1A73E8)),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { onNavigate(omniboxText) })
                )

                // Adobe Flash Active Chip in Omnibox
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(WindowsXpTheme.FlashRed)
                        .clickable { onOpenFlashSettings() }
                        .padding(horizontal = 5.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "Flash 10",
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.width(4.dp))

                Icon(
                    imageVector = Icons.Default.StarBorder,
                    contentDescription = "Bookmark",
                    tint = Color(0xFF5F6368),
                    modifier = Modifier.size(16.dp)
                )
            }

            // Chrome 3-dots Menu
            var menuExpanded by remember { mutableStateOf(false) }
            Box {
                IconButton(
                    onClick = { menuExpanded = true },
                    modifier = Modifier.size(30.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "Menu",
                        tint = Color(0xFF5F6368),
                        modifier = Modifier.size(18.dp)
                    )
                }

                DropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("New tab") },
                        onClick = { menuExpanded = false; onNewTab() }
                    )
                    DropdownMenuItem(
                        text = { Text("Era Sites Directory...") },
                        onClick = { menuExpanded = false; onOpenEraSites() }
                    )
                    DropdownMenuItem(
                        text = { Text("Wayback Machine Time Travel...") },
                        onClick = { menuExpanded = false; onOpenWayback() }
                    )
                    DropdownMenuItem(
                        text = { Text("Adobe Flash Player v10 Settings...") },
                        onClick = { menuExpanded = false; onOpenFlashSettings() }
                    )
                    DropdownMenuItem(
                        text = { Text("Display Resolution (${displayResolution.shortLabel})...") },
                        onClick = { menuExpanded = false; onOpenResolutionDialog() }
                    )
                    DropdownMenuItem(
                        text = { Text(if (isWidescreen16x9) "✓ 16:9 Widescreen Ratio" else "16:9 Widescreen Ratio") },
                        onClick = { menuExpanded = false; onToggleWidescreen() }
                    )
                    DropdownMenuItem(
                        text = { Text("Rotate Screen to 16:9 Landscape") },
                        onClick = { menuExpanded = false; onRotateScreen() }
                    )
                    DropdownMenuItem(
                        text = { Text("Toggle Retro CRT Monitor Filter") },
                        onClick = { menuExpanded = false; onToggleCrt() }
                    )
                }
            }
        }

        // Loading Progress bar
        if (isLoading) {
            LinearProgressIndicator(
                progress = { progress / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp),
                color = Color(0xFF1A73E8),
                trackColor = Color(0xFFE8EAED)
            )
        }
    }
}
