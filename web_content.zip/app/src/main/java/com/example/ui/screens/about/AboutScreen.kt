package com.example.ui.screens.about

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DataSourceStatus
import com.example.data.model.SourceConnectionState
import com.example.ui.components.OperationalDisclaimerCard
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusRed
import com.example.ui.theme.StatusYellow
import com.example.ui.viewmodel.WeatherViewModel

@Composable
fun AboutScreen(
  viewModel: WeatherViewModel,
  modifier: Modifier = Modifier
) {
  val dataSources by viewModel.dataSourcesStatus.collectAsState()

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp)
      .testTag("about_screen"),
    verticalArrangement = Arrangement.spacedBy(14.dp),
    contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
  ) {
    // Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "درباره سامانه و وضعیت منابع داده (Data Sources)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "ATC Aviation Weather • استانداردهای ICAO & WMO",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        IconButton(onClick = { viewModel.loadDataSourcesStatus() }) {
          Icon(Icons.Default.Refresh, contentDescription = "بررسی مجدد منابع", tint = MaterialTheme.colorScheme.primary)
        }
      }
    }

    // Security & Direct Architecture Note
    item {
      Surface(
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Text(
            text = "سیاست امنیت و اتصال داده‌ها (API Security Architecture)",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
          )
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "این برنامه مستقیماً به سرویس‌های عمومی و معتبر بین‌المللی OPMET متصل است. هیچ کلید محرمانه‌ای درون بسته APK هاردکد نشده است. برای اتصال به سامانه‌های نیازمند احراز هویت نظیر WIFS یا پورتال‌های اختصاصی ایکائو و AIS، معماری امن سروری و لایه واسط تعریف شده است.",
            style = MaterialTheme.typography.bodySmall,
            lineHeight = 20.sp,
            color = MaterialTheme.colorScheme.onSurface
          )
        }
      }
    }

    // Sources List
    item {
      Text(
        text = "وضعیت زنده اتصال منابع هواشناسی هوانوردی",
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold
      )
    }

    items(dataSources) { source ->
      DataSourceCard(source = source)
    }

    // Integration Verification Summary
    item {
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Text(
            text = "گزارش وضعیت صحت‌سنجی یکپارچه‌سازی محصولات جوی",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.height(10.dp))

          ProductVerificationRow("METAR / SPECI", "تایید شده — متصل به AviationWeather.gov OPMET زنده برای فرودگاه‌های ایران و جهان", true)
          ProductVerificationRow("TAF", "تایید شده — متصل به فید رسمی پیش‌بینی تف بین‌المللی", true)
          ProductVerificationRow("SIGMET", "تایید شده — دریافت زنده پدیده‌های حاد جوی جهانی و منطقه‌ای", true)
          ProductVerificationRow("WIND ALOFT", "تایید شده — دریافت مدل پیش‌بینی عددی چندترازی سطوح فوقانی از SFC تا FL450", true)
          ProductVerificationRow("SNOWTAM / GRF", "منبع عمومی فاقد احراز هویت رایگان نیست؛ لایه تحلیل و ثبت استاندارد Doc 10066 فعال است", false)
        }
      }
    }

    item { OperationalDisclaimerCard() }
  }
}

@Composable
private fun DataSourceCard(source: DataSourceStatus) {
  val (statusColor, statusLabel) = when (source.state) {
    SourceConnectionState.CONNECTED -> Pair(StatusGreen, "SOURCE CONNECTED (متصل)")
    SourceConnectionState.AUTHENTICATION_REQUIRED -> Pair(StatusYellow, "AUTHENTICATION REQUIRED (نیازمند احراز هویت)")
    SourceConnectionState.NOT_CONFIGURED -> Pair(Color.Gray, "SOURCE NOT CONFIGURED (پیکربندی نشده)")
    SourceConnectionState.UNAVAILABLE -> Pair(StatusRed, "SOURCE UNAVAILABLE (غیرفعال)")
    SourceConnectionState.NO_CURRENT_DATA -> Pair(StatusYellow, "NO CURRENT DATA (بدون داده حاضر)")
  }

  Card(
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    border = CardDefaults.outlinedCardBorder(),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(text = source.nameFa, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
          Text(text = source.nameEn, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Surface(shape = RoundedCornerShape(4.dp), color = statusColor.copy(alpha = 0.2f)) {
          Text(
            text = statusLabel,
            color = statusColor,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      Text(text = source.descriptionFa, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)

      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text(text = source.officialUrl, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
        if (source.lastCheckedUtc.isNotBlank()) {
          Text(text = source.lastCheckedUtc, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
      }
    }
  }
}

@Composable
private fun ProductVerificationRow(product: String, detail: String, isOk: Boolean) {
  Row(
    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Icon(
      imageVector = if (isOk) Icons.Default.CheckCircle else Icons.Default.Info,
      contentDescription = null,
      tint = if (isOk) StatusGreen else StatusYellow,
      modifier = Modifier.size(18.dp)
    )
    Spacer(modifier = Modifier.width(8.dp))
    Column {
      Text(text = product, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
      Text(text = detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
  }
  Divider(modifier = Modifier.padding(vertical = 4.dp))
}
