package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.MetallicSilver
import com.example.ui.theme.StudioDivider
import com.example.ui.theme.StudioSurfaceVariant

@Composable
fun PlaybackWaveformBar(
    peaks: List<Float>,
    progress: Float, // 0.0 .. 1.0
    onSeek: (Float) -> Unit,
    modifier: Modifier = Modifier,
    height: Dp = 48.dp
) {
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
            .pointerInput(peaks) {
                detectTapGestures { offset ->
                    val fraction = (offset.x / size.width).coerceIn(0f, 1f)
                    onSeek(fraction)
                }
            }
    ) {
        val totalWidth = size.width
        val totalHeight = size.height
        val midY = totalHeight / 2f

        val barCount = if (peaks.isNotEmpty()) peaks.size else 40
        val barSpacing = 2.dp.toPx()
        val barWidth = ((totalWidth - ((barCount - 1) * barSpacing)) / barCount).coerceAtLeast(2.dp.toPx())

        for (i in 0 until barCount) {
            val peak = if (i < peaks.size) peaks[i] else 0.2f
            val barHeight = (peak * totalHeight * 0.9f).coerceIn(4.dp.toPx(), totalHeight)
            val left = i * (barWidth + barSpacing)
            val top = midY - (barHeight / 2f)

            val barProgressFraction = (left + (barWidth / 2f)) / totalWidth
            val isPlayed = barProgressFraction <= progress

            val barColor = if (isPlayed) {
                EmeraldPrimary
            } else {
                StudioSurfaceVariant
            }

            drawRoundRect(
                color = barColor,
                topLeft = Offset(left, top),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
            )
        }

        // Draw Scrubber Playhead Line
        val headX = (progress * totalWidth).coerceIn(0f, totalWidth)
        drawLine(
            color = EmeraldLight,
            start = Offset(headX, 0f),
            end = Offset(headX, totalHeight),
            strokeWidth = 2.dp.toPx()
        )
        drawCircle(
            color = EmeraldLight,
            radius = 4.dp.toPx(),
            center = Offset(headX, 4.dp.toPx())
        )
    }
}
