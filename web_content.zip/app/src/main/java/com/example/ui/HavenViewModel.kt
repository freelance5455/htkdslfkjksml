package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.AiRepository
import com.example.data.ai.LocalPlaceholderAiRepository
import com.example.data.local.AppDatabase
import com.example.data.local.CareLogEntity
import com.example.data.local.CycleLogEntity
import com.example.data.local.DiaryEntryEntity
import com.example.data.local.EmergencyContactEntity
import com.example.data.local.HavenRepository
import com.example.data.local.HormoneCheckEntity
import com.example.data.local.LearnContentProvider
import com.example.data.local.ReminderScheduleEntity
import com.example.data.local.SosMessageEntity
import com.example.data.local.UserPreferencesRepository
import com.example.data.local.VitalityLogEntity
import com.example.data.model.AppLanguage
import com.example.data.model.CareCategory
import com.example.data.model.ChatMessage
import com.example.data.model.DailyHormoneCycleLog
import com.example.data.model.HormoneCycleMapper
import com.example.data.model.MoodType
import com.example.data.model.PhoneCommandResult
import com.example.data.model.UserProfile
import com.example.system.EmergencySosIntentHelper
import com.example.system.PhoneControlManager
import com.example.system.ReminderNotificationManager
import com.example.system.SosTriggerAction
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HavenViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getInstance(application)
    private val repository = HavenRepository(database.havenDao())
    private val prefsRepo = UserPreferencesRepository(application)
    private val aiRepository: AiRepository = LocalPlaceholderAiRepository()
    val phoneControl = PhoneControlManager(application)
    val sosIntentHelper = EmergencySosIntentHelper(application)
    val reminderManager = ReminderNotificationManager(application)

    private val todayEpochDay: Long
        get() = System.currentTimeMillis() / 86_400_000L

    val userProfile: StateFlow<UserProfile> = prefsRepo.userProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UserProfile())

    val todayCareLogs: StateFlow<List<CareLogEntity>> = repository.observeCareLogsForDay(todayEpochDay)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val reminderSchedules: StateFlow<List<ReminderScheduleEntity>> = repository.observeReminderSchedules()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val diaryEntries: StateFlow<List<DiaryEntryEntity>> = repository.observeDiaryEntries()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val cycleLogs: StateFlow<List<CycleLogEntity>> = repository.observeCycleLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val vitalityLogs: StateFlow<List<VitalityLogEntity>> = repository.observeVitalityLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val hormoneChecks: StateFlow<List<HormoneCheckEntity>> = repository.observeHormoneChecks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val dailyHormoneCycleLogs: StateFlow<List<DailyHormoneCycleLog>> =
        combine(hormoneChecks, cycleLogs) { hormones, cycles ->
            HormoneCycleMapper.fromEntities(hormones, cycles)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val emergencyContacts: StateFlow<List<EmergencyContactEntity>> = repository.observeEmergencyContacts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val sosMessages: StateFlow<List<SosMessageEntity>> = repository.observeSosMessages()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    private val _chatMessages = MutableStateFlow(
        listOf(
            ChatMessage(
                id = "welcome",
                isFromUser = false,
                text = "Hey there! I'm your Pillow of Strength. Tell me anything on your heart—stress, school, body changes, friendships, or how you feel today. Zero ads, zero judgment.",
                isPlaceholderSample = true
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isAiThinking = MutableStateFlow(false)
    val isAiThinking: StateFlow<Boolean> = _isAiThinking.asStateFlow()

    private val _selectedMood = MutableStateFlow(MoodType.CALM)
    val selectedMood: StateFlow<MoodType> = _selectedMood.asStateFlow()

    private val _statusBannerMessage = MutableStateFlow<String?>(null)
    val statusBannerMessage: StateFlow<String?> = _statusBannerMessage.asStateFlow()

    private val _needsDndAccessDialog = MutableStateFlow(false)
    val needsDndAccessDialog: StateFlow<Boolean> = _needsDndAccessDialog.asStateFlow()

    private val _isUnlocked = MutableStateFlow(true)
    val isUnlocked: StateFlow<Boolean> = _isUnlocked.asStateFlow()

    private val _tutorMessages = MutableStateFlow(
        listOf(
            ChatMessage(
                id = "tutor_welcome",
                isFromUser = false,
                text = LearnContentProvider.tutorGreeting(AppLanguage.EN),
                isPlaceholderSample = true
            )
        )
    )
    val tutorMessages: StateFlow<List<ChatMessage>> = _tutorMessages.asStateFlow()

    private val _learnedFactsCount = MutableStateFlow(0)
    val learnedFactsCount: StateFlow<Int> = _learnedFactsCount.asStateFlow()

    private val _quizStreak = MutableStateFlow(0)
    val quizStreak: StateFlow<Int> = _quizStreak.asStateFlow()

    init {
        viewModelScope.launch {
            repository.ensureDefaultReminders()
            val profile = prefsRepo.userProfile.first()
            if (profile.biometricLockEnabled) {
                _isUnlocked.value = false
            }
        }
    }

    fun markUnlocked() {
        _isUnlocked.value = true
    }

    fun lockApp() {
        _isUnlocked.value = false
    }

    fun clearStatusBanner() {
        _statusBannerMessage.value = null
    }

    fun dismissDndDialog() {
        _needsDndAccessDialog.value = false
    }

    fun saveUserProfile(profile: UserProfile) {
        viewModelScope.launch {
            prefsRepo.saveProfile(profile)
            _statusBannerMessage.value = "Profile saved securely on your device."
        }
    }

    fun toggleDataFreeMode(enabled: Boolean) {
        viewModelScope.launch {
            prefsRepo.updateDataFreeMode(enabled)
            _statusBannerMessage.value = if (enabled) {
                "Data-Free Mode ON: Everything runs 100% offline."
            } else {
                "Data Mode ON: Ready for sync & sharing."
            }
        }
    }

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch {
            prefsRepo.updateLanguage(language)
        }
    }

    fun toggleBiometricLock(enabled: Boolean) {
        viewModelScope.launch {
            prefsRepo.updateBiometricLock(enabled)
            _statusBannerMessage.value = if (enabled) {
                "Biometric privacy lock enabled."
            } else {
                "Biometric privacy lock turned off."
            }
        }
    }

    fun logCareAction(category: CareCategory, count: Int = 1, note: String = "") {
        viewModelScope.launch {
            repository.logCare(category, todayEpochDay, count, note)
            _statusBannerMessage.value = "Logged ${category.name.lowercase().replace('_', ' ')}!"
        }
    }

    fun updateReminder(category: CareCategory, hour: Int, minute: Int, enabled: Boolean) {
        viewModelScope.launch {
            repository.upsertReminderSchedule(
                ReminderScheduleEntity(
                    categoryKey = category.key,
                    hour = hour,
                    minute = minute,
                    enabled = enabled
                )
            )
            reminderManager.scheduleDailyReminder(category, hour, minute, enabled)
            _statusBannerMessage.value = if (enabled) {
                "Reminder set for %02d:%02d".format(hour, minute)
            } else {
                "Reminder paused"
            }
        }
    }

    fun toggleSleepQuietMode(enable: Boolean) {
        viewModelScope.launch {
            when (val result = phoneControl.setSleepQuietMode(enable)) {
                is PhoneCommandResult.Success -> {
                    prefsRepo.updateSleepQuietMode(enable)
                    if (enable) {
                        repository.logCare(CareCategory.SLEEP, todayEpochDay, 1, "Sleep Quiet Mode")
                    }
                    _statusBannerMessage.value = result.feedback
                }
                is PhoneCommandResult.NeedsPermission -> {
                    _needsDndAccessDialog.value = true
                    _statusBannerMessage.value = result.feedback
                }
                is PhoneCommandResult.Info -> {
                    _statusBannerMessage.value = result.feedback
                }
            }
        }
    }

    fun executePhoneCommand(rawCommand: String) {
        val cmd = rawCommand.trim()
        if (cmd.isBlank()) return
        val lower = cmd.lowercase()
        val contacts = emergencyContacts.value
        val profile = userProfile.value

        when {
            "sleep" in lower || "dnd" in lower || "quiet" in lower || "turn apps down" in lower || "night" in lower -> {
                val turnOff = "off" in lower || "stop" in lower || "wake" in lower
                toggleSleepQuietMode(!turnOff)
            }
            "alarm" in lower || "wake" in lower -> {
                val timeMatch = Regex("(\\d{1,2})[:.](\\d{2})").find(lower)
                val hour = timeMatch?.groupValues?.get(1)?.toIntOrNull()?.coerceIn(0, 23) ?: 6
                val min = timeMatch?.groupValues?.get(2)?.toIntOrNull()?.coerceIn(0, 59) ?: 30
                val res = phoneControl.setWakeUpAlarm(hour, min)
                _statusBannerMessage.value = when (res) {
                    is PhoneCommandResult.Success -> res.feedback
                    is PhoneCommandResult.NeedsPermission -> res.feedback
                    is PhoneCommandResult.Info -> res.feedback
                }
            }
            "fresh air" in lower || "timer" in lower -> {
                val res = phoneControl.startFreshAirTimer(15)
                _statusBannerMessage.value = (res as? PhoneCommandResult.Success)?.feedback
                    ?: (res as? PhoneCommandResult.Info)?.feedback
            }
            "mute" in lower -> {
                val res = phoneControl.muteMediaVolume()
                _statusBannerMessage.value = (res as? PhoneCommandResult.Success)?.feedback
            }
            "volume down" in lower || "quieter" in lower || "lower" in lower -> {
                val res = phoneControl.adjustVolume(increase = false)
                _statusBannerMessage.value = (res as? PhoneCommandResult.Success)?.feedback
            }
            "volume up" in lower || "louder" in lower -> {
                val res = phoneControl.adjustVolume(increase = true)
                _statusBannerMessage.value = (res as? PhoneCommandResult.Success)?.feedback
            }
            "call" in lower -> {
                val matchedContact = contacts.firstOrNull { it.name.lowercase() in lower }
                val digits = Regex("\\d{3,}").find(lower)?.value
                val target = matchedContact?.phone ?: digits ?: profile.emergencyAuthorityNumber
                val res = phoneControl.dialNumber(target)
                _statusBannerMessage.value = (res as? PhoneCommandResult.Success)?.feedback
                    ?: (res as? PhoneCommandResult.Info)?.feedback
            }
            "whatsapp" in lower || "message" in lower || "text" in lower || "sms" in lower -> {
                val matchedContact = contacts.firstOrNull { it.name.lowercase() in lower }
                val targetPhone = matchedContact?.phone ?: ""
                val msg = "Hey, reaching out from Haven!"
                val res = if ("whatsapp" in lower) {
                    phoneControl.sendWhatsAppOrShare(targetPhone, msg)
                } else {
                    phoneControl.sendSms(targetPhone, msg)
                }
                _statusBannerMessage.value = (res as? PhoneCommandResult.Success)?.feedback
                    ?: (res as? PhoneCommandResult.Info)?.feedback
            }
            "water" in lower -> logCareAction(CareCategory.DRINK_WATER)
            "pee" in lower -> logCareAction(CareCategory.PEE)
            "poop" in lower -> logCareAction(CareCategory.POOP)
            "eat" in lower || "meal" in lower || "food" in lower -> logCareAction(CareCategory.EAT_MEAL)
            "bath" in lower || "shower" in lower -> logCareAction(CareCategory.BATH)
            "exercise" in lower || "workout" in lower -> logCareAction(CareCategory.EXERCISE, 15)
            else -> {
                _statusBannerMessage.value =
                    "Try: 'Sleep mode', 'Alarm 6:30', 'Volume down', 'Fresh air timer', 'Call Mom', 'Message Alex', or 'Log water'."
            }
        }
    }

    fun selectMood(mood: MoodType) {
        _selectedMood.value = mood
    }

    fun sendPillowMessage(text: String) {
        val trimmed = text.trim()
        if (trimmed.isBlank()) return
        val userMsg = ChatMessage(
            id = UUID.randomUUID().toString(),
            isFromUser = true,
            text = trimmed
        )
        _chatMessages.value = _chatMessages.value + userMsg
        _isAiThinking.value = true

        viewModelScope.launch {
            val reply = aiRepository.chatWithPillowOfStrength(
                userMessage = trimmed,
                currentMood = _selectedMood.value,
                profile = userProfile.value,
                history = _chatMessages.value
            )
            _chatMessages.value = _chatMessages.value + ChatMessage(
                id = UUID.randomUUID().toString(),
                isFromUser = false,
                text = reply.text,
                isPlaceholderSample = reply.isPlaceholderSample
            )
            _isAiThinking.value = false
        }
    }

    fun saveDiaryEntry(title: String, content: String, mood: MoodType, energy: Int, isVoiceTyped: Boolean) {
        if (content.isBlank()) return
        viewModelScope.launch {
            _isAiThinking.value = true
            val analysis = aiRepository.analyzeDiaryEntryAndSupport(
                content = content.trim(),
                selectedMood = mood,
                profile = userProfile.value
            )
            repository.saveDiaryEntry(
                title = title.ifBlank { "${analysis.suggestedMood.label} Reflection" },
                content = content.trim(),
                moodKey = analysis.suggestedMood.key,
                energyScore = energy,
                isVoiceTyped = isVoiceTyped,
                detectedCue = analysis.detectedCue,
                aiSupportResponse = analysis.supportiveResponse
            )
            _selectedMood.value = analysis.suggestedMood
            _isAiThinking.value = false
            _statusBannerMessage.value = "Diary saved • Cue recognized: ${analysis.detectedCue}"
        }
    }

    fun deleteDiaryEntry(id: Int) {
        viewModelScope.launch { repository.deleteDiaryEntry(id) }
    }

    fun markFactLearned() {
        _learnedFactsCount.value += 1
    }

    fun recordQuizAnswer(correct: Boolean) {
        if (correct) _quizStreak.value += 1
    }

    fun askTutorTshenoloMaseko(question: String, subject: String) {
        val trimmed = question.trim()
        if (trimmed.isBlank()) return
        _tutorMessages.value = _tutorMessages.value + ChatMessage(
            id = UUID.randomUUID().toString(),
            isFromUser = true,
            text = "[$subject] $trimmed"
        )
        _isAiThinking.value = true
        viewModelScope.launch {
            val reply = aiRepository.askTutorTshenoloMaseko(trimmed, subject, userProfile.value)
            _tutorMessages.value = _tutorMessages.value + ChatMessage(
                id = UUID.randomUUID().toString(),
                isFromUser = false,
                text = reply.text,
                isPlaceholderSample = reply.isPlaceholderSample
            )
            _isAiThinking.value = false
        }
    }

    fun logPeriodStartToday(flowLevel: String, crampsLevel: Int, symptoms: String, notes: String) {
        viewModelScope.launch {
            prefsRepo.updateLastPeriodDay(todayEpochDay)
            repository.logCycleDay(todayEpochDay, flowLevel, crampsLevel, symptoms, notes)
            _statusBannerMessage.value = "Cycle day logged."
        }
    }

    fun logBoysVitality(
        workoutMinutes: Int,
        workoutType: String,
        proteinMeals: Int,
        hydrationAndZincDone: Boolean,
        sleepHours: Float,
        notes: String
    ) {
        viewModelScope.launch {
            repository.logVitality(
                epochDay = todayEpochDay,
                workoutMinutes = workoutMinutes,
                workoutType = workoutType,
                proteinMeals = proteinMeals,
                hydrationAndZincDone = hydrationAndZincDone,
                sleepHours = sleepHours,
                notes = notes
            )
            if (workoutMinutes > 0) {
                repository.logCare(CareCategory.EXERCISE, todayEpochDay, workoutMinutes, workoutType)
            }
            _statusBannerMessage.value = "Fitness & vitality log saved!"
        }
    }

    fun runHormoneCheck(
        energy: Int,
        moodBalance: Int,
        skinClarity: Int,
        sleepQuality: Int,
        stressCalm: Int,
        dailySymptoms: String = ""
    ) {
        viewModelScope.launch {
            _isAiThinking.value = true
            val reply = aiRepository.analyzeHormoneBalance(
                energy = energy,
                moodBalance = moodBalance,
                skinClarity = skinClarity,
                sleepQuality = sleepQuality,
                stressCalm = stressCalm,
                profile = userProfile.value
            )
            repository.saveHormoneCheck(
                HormoneCheckEntity(
                    energyScore = energy,
                    moodBalanceScore = moodBalance,
                    skinClarityScore = skinClarity,
                    sleepQualityScore = sleepQuality,
                    stressCalmScore = stressCalm,
                    dailySymptoms = dailySymptoms,
                    insightSummary = reply.text
                )
            )
            _isAiThinking.value = false
            _statusBannerMessage.value = "Hormone & wellness check-in saved."
        }
    }

    fun addEmergencyContact(name: String, phone: String, relationship: String) {
        if (name.isBlank() || phone.isBlank()) return
        viewModelScope.launch {
            repository.addEmergencyContact(name.trim(), phone.trim(), relationship.trim())
            _statusBannerMessage.value = "Added $name to trusted SOS contacts."
        }
    }

    fun deleteEmergencyContact(id: Int) {
        viewModelScope.launch { repository.deleteEmergencyContact(id) }
    }

    fun activateSosTrigger(
        action: SosTriggerAction,
        customMessage: String = ""
    ) {
        viewModelScope.launch {
            val location = phoneControl.getBestLastKnownLocationText()
            val profile = userProfile.value
            val contactsList = emergencyContacts.value
            val messageSummary = customMessage.ifBlank { EmergencySosIntentHelper.DEFAULT_SOS_BODY }

            val channelLabel = when (action) {
                SosTriggerAction.CALL_AUTHORITY -> "Emergency Call (${profile.emergencyAuthorityNumber})"
                SosTriggerAction.SEND_PRECONFIGURED_SMS -> "Pre-Configured SOS SMS"
                SosTriggerAction.WHATSAPP_OR_SHARE -> "WhatsApp / Share"
            }

            repository.logSosMessage(
                SosMessageEntity(
                    recipientName = if (action == SosTriggerAction.CALL_AUTHORITY) {
                        "Authority (${profile.emergencyAuthorityNumber})"
                    } else {
                        contactsList.joinToString { it.name }.ifBlank { "Trusted Contacts" }
                    },
                    recipientPhone = if (action == SosTriggerAction.CALL_AUTHORITY) {
                        profile.emergencyAuthorityNumber
                    } else {
                        contactsList.joinToString(";") { it.phone }
                    },
                    messageText = messageSummary,
                    locationSummary = location,
                    channel = channelLabel,
                    status = "SOS Trigger Activated"
                )
            )

            val res = sosIntentHelper.activateSosTrigger(
                action = action,
                profile = profile,
                contacts = contactsList,
                locationText = location,
                customMessage = customMessage
            )
            _statusBannerMessage.value = (res as? PhoneCommandResult.Success)?.feedback
                ?: (res as? PhoneCommandResult.Info)?.feedback
        }
    }

    fun dispatchSosMessage(
        contact: EmergencyContactEntity?,
        customMessage: String,
        channel: String
    ) {
        viewModelScope.launch {
            val location = phoneControl.getBestLastKnownLocationText()
            val profile = userProfile.value
            val fullPayload = sosIntentHelper.buildPreConfiguredSosMessage(
                profile = profile,
                locationText = location,
                customReason = customMessage
            )
            val recipientName = contact?.name ?: "Trusted Contacts"
            val recipientPhone = contact?.phone ?: ""

            repository.logSosMessage(
                SosMessageEntity(
                    recipientName = recipientName,
                    recipientPhone = recipientPhone,
                    messageText = customMessage.ifBlank { "Urgent SOS Help Needed" },
                    locationSummary = location,
                    channel = channel,
                    status = "Dispatched ($channel)"
                )
            )

            val res = when (channel) {
                "WhatsApp" -> {
                    val intent = sosIntentHelper.buildWhatsAppOrShareIntent(recipientPhone, fullPayload)
                    try {
                        getApplication<Application>().startActivity(intent)
                        PhoneCommandResult.Success("Opening WhatsApp / share sheet.")
                    } catch (_: Exception) {
                        sosIntentHelper.sendPreConfiguredSosSms(listOfNotNull(contact), fullPayload)
                    }
                }
                else -> sosIntentHelper.sendPreConfiguredSosSms(listOfNotNull(contact), fullPayload)
            }
            _statusBannerMessage.value = (res as? PhoneCommandResult.Success)?.feedback
                ?: (res as? PhoneCommandResult.Info)?.feedback
        }
    }

    fun backupToEmail() {
        val profile = userProfile.value
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        val body = buildString {
            appendLine("=== HAVEN TEEN WELLNESS BACKUP ===")
            appendLine("Generated: ${dateFormat.format(Date())}")
            appendLine("Name: ${profile.name.ifBlank { "Not set" }} | Age: ${profile.age} | Gender: ${profile.gender.label}")
            appendLine("Language: ${profile.language.nativeName}")
            appendLine("Emergency Number: ${profile.emergencyAuthorityNumber} | Blood: ${profile.bloodType} | Allergies: ${profile.allergies}")
            appendLine()
            appendLine("--- TODAY CARE LOGS (${todayCareLogs.value.size}) ---")
            todayCareLogs.value.take(25).forEach {
                appendLine("• ${it.categoryKey} (+${it.countAdded}) ${it.note}")
            }
            appendLine()
            appendLine("--- DIARY ENTRIES (${diaryEntries.value.size}) ---")
            diaryEntries.value.take(20).forEach {
                appendLine("[${dateFormat.format(Date(it.timestamp))}] (${it.moodKey}, Energy ${it.energyScore}/5) ${it.title}: ${it.content}")
            }
            appendLine()
            appendLine("--- HORMONE CHECKS (${hormoneChecks.value.size}) ---")
            hormoneChecks.value.take(5).forEach {
                appendLine("[${dateFormat.format(Date(it.timestamp))}] Energy:${it.energyScore} Mood:${it.moodBalanceScore} Sleep:${it.sleepQualityScore} StressCalm:${it.stressCalmScore}")
            }
        }

        val res = phoneControl.sendBackupEmail(
            recipientEmail = profile.backupEmail,
            subject = "Haven Wellness & Diary Backup (${dateFormat.format(Date())})",
            body = body
        )
        _statusBannerMessage.value = (res as? PhoneCommandResult.Success)?.feedback
            ?: (res as? PhoneCommandResult.Info)?.feedback
    }
}
