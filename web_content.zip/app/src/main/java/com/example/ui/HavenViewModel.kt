package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.AiRepository
import com.example.data.ai.LocalPlaceholderAiRepository
import com.example.data.local.AppDatabase
import com.example.data.local.CareLogEntity
import com.example.data.local.CycleLogEntity
import com.example.data.local.DiaryEntryEntity
import com.example.data.local.EmergencyContactEntity
import com.example.data.local.HavenRepository
import com.example.data.local.HormoneCheckEntity
import com.example.data.local.LearnContentProvider
import com.example.data.local.ReminderScheduleEntity
import com.example.data.local.SosMessageEntity
import com.example.data.local.UserPreferencesRepository
import com.example.data.local.VitalityLogEntity
import com.example.data.model.AiResultType
import com.example.data.model.AiSpaceResult
import com.example.data.model.AppLanguage
import com.example.data.model.CareCategory
import com.example.data.model.ChatMessage
import com.example.data.model.DailyHormoneCycleLog
import com.example.data.model.HavenAward
import com.example.data.model.HormoneCycleMapper
import com.example.data.model.MoodType
import com.example.data.model.PhoneCommandResult
import com.example.data.model.SUBSCRIPTION_AIRTIME_NUMBER
import com.example.data.model.SubscriptionPlan
import com.example.data.model.UserProfile
import com.example.ui.components.computeHavenAwards
import com.example.system.EmergencySosIntentHelper
import com.example.system.OtpChannel
import com.example.system.OtpDeliveryService
import com.example.system.PhoneControlManager
import com.example.system.ReminderNotificationManager
import com.example.system.SosTriggerAction
import com.example.system.SubscriptionWebSyncResult
import com.example.system.SubscriptionWebSyncService
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HavenViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getInstance(application)
    private val repository = HavenRepository(database.havenDao())
    private val prefsRepo = UserPreferencesRepository(application)
    private val aiRepository: AiRepository = LocalPlaceholderAiRepository()
    val phoneControl = PhoneControlManager(application)
    val sosIntentHelper = EmergencySosIntentHelper(application)
    val reminderManager = ReminderNotificationManager(application)
    val otpService = OtpDeliveryService(application)
    val subscriptionWebSync = SubscriptionWebSyncService(application)

    private val todayEpochDay: Long
        get() = System.currentTimeMillis() / 86_400_000L

    val userProfile: StateFlow<UserProfile> = prefsRepo.userProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), UserProfile())

    val todayCareLogs: StateFlow<List<CareLogEntity>> = repository.observeCareLogsForDay(todayEpochDay)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val reminderSchedules: StateFlow<List<ReminderScheduleEntity>> = repository.observeReminderSchedules()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val diaryEntries: StateFlow<List<DiaryEntryEntity>> = repository.observeDiaryEntries()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val cycleLogs: StateFlow<List<CycleLogEntity>> = repository.observeCycleLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val vitalityLogs: StateFlow<List<VitalityLogEntity>> = repository.observeVitalityLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val hormoneChecks: StateFlow<List<HormoneCheckEntity>> = repository.observeHormoneChecks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val dailyHormoneCycleLogs: StateFlow<List<DailyHormoneCycleLog>> =
        combine(hormoneChecks, cycleLogs) { hormones, cycles ->
            HormoneCycleMapper.fromEntities(hormones, cycles)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val emergencyContacts: StateFlow<List<EmergencyContactEntity>> = repository.observeEmergencyContacts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    val sosMessages: StateFlow<List<SosMessageEntity>> = repository.observeSosMessages()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    private val _calendarEvents = MutableStateFlow<List<String>>(emptyList())
    val calendarEvents: StateFlow<List<String>> = _calendarEvents.asStateFlow()

    private val _aiSpaceResults = MutableStateFlow<List<AiSpaceResult>>(emptyList())
    val aiSpaceResults: StateFlow<List<AiSpaceResult>> = _aiSpaceResults.asStateFlow()

    private val _chatMessages = MutableStateFlow(
        listOf(
            ChatMessage(
                id = "welcome",
                isFromUser = false,
                text = "Hey there! I'm your Pillow of Strength. Tell me anything on your heart—stress, school, body changes, friendships, or how you feel today. Zero ads, zero judgment.",
                isPlaceholderSample = true
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isAiThinking = MutableStateFlow(false)
    val isAiThinking: StateFlow<Boolean> = _isAiThinking.asStateFlow()

    private val _selectedMood = MutableStateFlow(MoodType.CALM)
    val selectedMood: StateFlow<MoodType> = _selectedMood.asStateFlow()

    private val _statusBannerMessage = MutableStateFlow<String?>(null)
    val statusBannerMessage: StateFlow<String?> = _statusBannerMessage.asStateFlow()

    private val _needsDndAccessDialog = MutableStateFlow(false)
    val needsDndAccessDialog: StateFlow<Boolean> = _needsDndAccessDialog.asStateFlow()

    private val _isUnlocked = MutableStateFlow(true)
    val isUnlocked: StateFlow<Boolean> = _isUnlocked.asStateFlow()

    private val _showSubscribeDialog = MutableStateFlow(false)
    val showSubscribeDialog: StateFlow<Boolean> = _showSubscribeDialog.asStateFlow()

    private val _isSyncingSubscription = MutableStateFlow(false)
    val isSyncingSubscription: StateFlow<Boolean> = _isSyncingSubscription.asStateFlow()

    private val _subscriptionSyncMessage = MutableStateFlow<String?>(null)
    val subscriptionSyncMessage: StateFlow<String?> = _subscriptionSyncMessage.asStateFlow()

    private var pendingWebSubscriptionIdentifier: String = ""

    private val _tutorMessages = MutableStateFlow(
        listOf(
            ChatMessage(
                id = "tutor_welcome",
                isFromUser = false,
                text = LearnContentProvider.tutorGreeting(AppLanguage.EN),
                isPlaceholderSample = true
            )
        )
    )
    val tutorMessages: StateFlow<List<ChatMessage>> = _tutorMessages.asStateFlow()

    private val _learnedFactsCount = MutableStateFlow(0)
    val learnedFactsCount: StateFlow<Int> = _learnedFactsCount.asStateFlow()

    private val _quizStreak = MutableStateFlow(0)
    val quizStreak: StateFlow<Int> = _quizStreak.asStateFlow()

    val awards: StateFlow<List<HavenAward>> = combine(
        userProfile,
        todayCareLogs,
        diaryEntries,
        combine(hormoneChecks, cycleLogs, vitalityLogs, emergencyContacts) { h, c, v, e ->
            Quad(h, c, v, e)
        },
        combine(_learnedFactsCount, _quizStreak) { f, q -> f to q }
    ) { profile, care, diary, wellnessSafety, learnPair ->
        computeHavenAwards(
            profile = profile,
            todayCareLogs = care,
            diaryEntries = diary,
            hormoneChecks = wellnessSafety.first,
            cycleLogs = wellnessSafety.second,
            vitalityLogs = wellnessSafety.third,
            contacts = wellnessSafety.fourth,
            learnedFactsCount = learnPair.first,
            quizStreak = learnPair.second
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), emptyList())

    init {
        viewModelScope.launch {
            repository.ensureDefaultReminders()
            refreshCalendarEvents()
            val profile = prefsRepo.userProfile.first()
            if (profile.biometricLockEnabled || profile.pinCode.isNotBlank()) {
                _isUnlocked.value = false
            }
        }
    }

    fun markUnlocked() {
        _isUnlocked.value = true
    }

    fun lockApp() {
        _isUnlocked.value = false
    }

    fun resetPinAndUnlock(newPin: String) {
        val clean = newPin.filter { it.isDigit() }.take(6)
        if (clean.length < 4) return
        viewModelScope.launch {
            prefsRepo.updatePinCode(clean)
            prefsRepo.updateLoggedIn(true)
            _isUnlocked.value = true
            _statusBannerMessage.value = "New Privacy PIN saved! Haven unlocked."
        }
    }

    fun openSubscribeDialog() {
        _subscriptionSyncMessage.value = null
        _showSubscribeDialog.value = true
    }

    fun dismissSubscribeDialog() {
        _showSubscribeDialog.value = false
    }

    fun openSubscriptionWebsite(subscriberIdentifier: String, plan: SubscriptionPlan) {
        val clean = subscriberIdentifier.trim()
        val isEmail = clean.contains("@") && clean.contains(".")
        val isPhone = clean.count { it.isDigit() } >= 6
        if (!isEmail && !isPhone) {
            _subscriptionSyncMessage.value = "Please enter your email address or phone number before opening the subscription website."
            return
        }
        viewModelScope.launch {
            val current = prefsRepo.userProfile.first()
            val updated = if (isEmail) current.copy(backupEmail = clean) else current.copy(phoneNumber = clean)
            prefsRepo.saveProfile(updated)
            pendingWebSubscriptionIdentifier = clean

            val opened = subscriptionWebSync.openSubscribeWebsite(
                subscriberIdentifier = clean,
                plan = plan,
                userName = current.name,
                isDataFreeMode = current.isDataFreeMode
            )
            if (opened) {
                val masked = if (isEmail) OtpDeliveryService.maskEmail(clean) else OtpDeliveryService.maskPhone(clean)
                _subscriptionSyncMessage.value =
                    "Opened haven-rand-subscribe.lovable.app for $masked. Complete subscribing on the web, then return or tap Sync Status."
            } else {
                _subscriptionSyncMessage.value =
                    "Turn off No-Data Limited Mode (or open haven-rand-subscribe.lovable.app) to subscribe online."
            }
        }
    }

    fun syncSubscriptionWithWeb(
        subscriberIdentifier: String,
        plan: SubscriptionPlan,
        confirmationCode: String = ""
    ) {
        val clean = subscriberIdentifier.trim()
        val isEmail = clean.contains("@") && clean.contains(".")
        val isPhone = clean.count { it.isDigit() } >= 6
        if (!isEmail && !isPhone) {
            _subscriptionSyncMessage.value = "Enter your email address or phone number to verify your subscription."
            return
        }
        _isSyncingSubscription.value = true
        viewModelScope.launch {
            val current = prefsRepo.userProfile.first()
            val updatedIdentity = if (isEmail) current.copy(backupEmail = clean) else current.copy(phoneNumber = clean)
            prefsRepo.saveProfile(updatedIdentity)

            val result = subscriptionWebSync.syncWithWeb(
                subscriberIdentifier = clean,
                confirmationCode = confirmationCode,
                isDataFreeMode = current.isDataFreeMode
            )
            _isSyncingSubscription.value = false

            when (result) {
                is SubscriptionWebSyncResult.ActiveOnWeb -> {
                    val chosenPlan = SubscriptionPlan.entries.firstOrNull { it.id == result.planId } ?: plan
                    prefsRepo.saveProfile(
                        updatedIdentity.copy(
                            isSubscribed = true,
                            subscriptionPlanId = chosenPlan.id,
                            subscriptionMethod = result.method,
                            subscriptionReference = result.reference,
                            subscriptionExpiresAtMillis = result.expiresAtMillis
                        )
                    )
                    pendingWebSubscriptionIdentifier = ""
                    _showSubscribeDialog.value = false
                    _statusBannerMessage.value = result.message
                }
                is SubscriptionWebSyncResult.NotSubscribedYet -> {
                    _subscriptionSyncMessage.value = result.message
                }
                is SubscriptionWebSyncResult.WebEndpointUnavailable -> {
                    val trimmedRef = confirmationCode.trim()
                    if (trimmedRef.length >= 5) {
                        subscriptionWebSync.notifyWebActivation(clean, plan, trimmedRef)
                        val expiresAt = System.currentTimeMillis() + plan.durationDays * 86_400_000L
                        prefsRepo.saveProfile(
                            updatedIdentity.copy(
                                isSubscribed = true,
                                subscriptionPlanId = plan.id,
                                subscriptionMethod = "Haven Web Subscription",
                                subscriptionReference = trimmedRef,
                                subscriptionExpiresAtMillis = expiresAt
                            )
                        )
                        pendingWebSubscriptionIdentifier = ""
                        _showSubscribeDialog.value = false
                        _statusBannerMessage.value =
                            "Haven Plus (${plan.label}) synced & unlocked! Enjoy Fast AI, Voice Control & Phone AI ⚡"
                    } else {
                        _subscriptionSyncMessage.value = result.message
                    }
                }
                is SubscriptionWebSyncResult.OfflineOrError -> {
                    _subscriptionSyncMessage.value = result.message
                }
            }
        }
    }

    fun checkPendingWebSubscriptionOnResume() {
        val pending = pendingWebSubscriptionIdentifier.trim()
        if (pending.isBlank()) return
        viewModelScope.launch {
            val current = prefsRepo.userProfile.first()
            if (current.hasActiveSubscription || current.isDataFreeMode) return@launch
            val result = subscriptionWebSync.syncWithWeb(
                subscriberIdentifier = pending,
                confirmationCode = "",
                isDataFreeMode = false
            )
            if (result is SubscriptionWebSyncResult.ActiveOnWeb) {
                val chosenPlan = SubscriptionPlan.entries.firstOrNull { it.id == result.planId } ?: SubscriptionPlan.MONTHLY
                prefsRepo.saveProfile(
                    current.copy(
                        isSubscribed = true,
                        subscriptionPlanId = chosenPlan.id,
                        subscriptionMethod = result.method,
                        subscriptionReference = result.reference,
                        subscriptionExpiresAtMillis = result.expiresAtMillis
                    )
                )
                pendingWebSubscriptionIdentifier = ""
                _showSubscribeDialog.value = false
                _statusBannerMessage.value = result.message
            }
        }
    }

    fun handleSubscriptionDeepLink(uri: Uri?) {
        if (uri == null) return
        if (uri.scheme != "haven" || uri.host != "subscribe") return
        val status = uri.getQueryParameter("status")?.lowercase().orEmpty()
        val subscribedParam = uri.getQueryParameter("subscribed")?.lowercase().orEmpty()
        val active = status in listOf("active", "paid", "subscribed", "success") || subscribedParam == "true"
        if (!active) return

        val planId = uri.getQueryParameter("plan") ?: SubscriptionPlan.MONTHLY.id
        val chosenPlan = SubscriptionPlan.entries.firstOrNull { it.id == planId } ?: SubscriptionPlan.MONTHLY
        val emailParam = uri.getQueryParameter("email").orEmpty().trim()
        val phoneParam = uri.getQueryParameter("phone").orEmpty().trim()
        val identifier = uri.getQueryParameter("identifier").orEmpty().trim()
        val ref = uri.getQueryParameter("ref").orEmpty().ifBlank { "web-callback" }

        viewModelScope.launch {
            val current = prefsRepo.userProfile.first()
            val expiresAt = System.currentTimeMillis() + chosenPlan.durationDays * 86_400_000L
            prefsRepo.saveProfile(
                current.copy(
                    backupEmail = emailParam.ifBlank { if (identifier.contains("@")) identifier else current.backupEmail },
                    phoneNumber = phoneParam.ifBlank { if (!identifier.contains("@") && identifier.isNotBlank()) identifier else current.phoneNumber },
                    isSubscribed = true,
                    subscriptionPlanId = chosenPlan.id,
                    subscriptionMethod = "Haven Web Verified",
                    subscriptionReference = ref,
                    subscriptionExpiresAtMillis = expiresAt
                )
            )
            pendingWebSubscriptionIdentifier = ""
            _showSubscribeDialog.value = false
            _statusBannerMessage.value =
                "Welcome to Haven Plus (${chosenPlan.label})! Confirmed from haven-rand-subscribe.lovable.app ⚡"
        }
    }

    fun launchAirtimeTransferHelper(plan: SubscriptionPlan) {
        phoneControl.dialNumber(SUBSCRIPTION_AIRTIME_NUMBER)
        _statusBannerMessage.value =
            "Complete ${plan.priceLabel} airtime billing (Vodacom *135# • MTN *136*3# • Telkom *180# • Cell C *147#), then enter your ref."
    }

    fun activateSubscriptionWithAirtime(plan: SubscriptionPlan, senderOrRef: String, subscriberIdentifier: String = "") {
        viewModelScope.launch {
            val expiresAt = System.currentTimeMillis() + plan.durationDays * 86_400_000L
            val current = prefsRepo.userProfile.first()
            val cleanId = subscriberIdentifier.trim().ifBlank { current.backupEmail.ifBlank { current.phoneNumber } }
            val updated = current.copy(
                backupEmail = if (cleanId.contains("@")) cleanId else current.backupEmail,
                phoneNumber = if (!cleanId.contains("@") && cleanId.isNotBlank()) cleanId else current.phoneNumber,
                isSubscribed = true,
                subscriptionPlanId = plan.id,
                subscriptionMethod = "Airtime Billing",
                subscriptionReference = senderOrRef.trim(),
                subscriptionExpiresAtMillis = expiresAt
            )
            prefsRepo.saveProfile(updated)
            if (cleanId.isNotBlank()) {
                subscriptionWebSync.notifyWebActivation(cleanId, plan, senderOrRef.trim())
            }
            _showSubscribeDialog.value = false
            _statusBannerMessage.value =
                "Haven Plus (${plan.label}) unlocked! Fast AI Mode & Voice Control are now open ⚡"
        }
    }

    fun activateSubscriptionWithOneForYou(plan: SubscriptionPlan, voucherPin: String, subscriberIdentifier: String = "") {
        viewModelScope.launch {
            val cleanPin = voucherPin.filter { it.isDigit() }
            val current = prefsRepo.userProfile.first()
            val cleanId = subscriberIdentifier.trim().ifBlank { current.backupEmail.ifBlank { current.phoneNumber } }
            val smsBody = "Haven Plus ${plan.priceLabel} | 1ForYou PIN: $cleanPin | User: ${current.name.ifBlank { "Member" }}"
            phoneControl.sendSms(SUBSCRIPTION_AIRTIME_NUMBER, smsBody)
            val expiresAt = System.currentTimeMillis() + plan.durationDays * 86_400_000L
            prefsRepo.saveProfile(
                current.copy(
                    backupEmail = if (cleanId.contains("@")) cleanId else current.backupEmail,
                    phoneNumber = if (!cleanId.contains("@") && cleanId.isNotBlank()) cleanId else current.phoneNumber,
                    isSubscribed = true,
                    subscriptionPlanId = plan.id,
                    subscriptionMethod = "1ForYou Voucher",
                    subscriptionReference = "****${cleanPin.takeLast(4)}",
                    subscriptionExpiresAtMillis = expiresAt
                )
            )
            if (cleanId.isNotBlank()) {
                subscriptionWebSync.notifyWebActivation(cleanId, plan, "****${cleanPin.takeLast(4)}")
            }
            _showSubscribeDialog.value = false
            _statusBannerMessage.value =
                "1ForYou voucher processed! Fast AI Mode & Voice Control unlocked ⚡"
        }
    }

    fun logout() {
        viewModelScope.launch {
            prefsRepo.updateLoggedIn(false)
            _statusBannerMessage.value = "Signed out safely."
        }
    }

    fun clearStatusBanner() {
        _statusBannerMessage.value = null
    }

    fun dismissDndDialog() {
        _needsDndAccessDialog.value = false
    }

    fun saveUserProfile(profile: UserProfile) {
        viewModelScope.launch {
            prefsRepo.saveProfile(profile)
            _statusBannerMessage.value = "Profile saved securely on your device."
        }
    }

    fun toggleDataFreeMode(enabled: Boolean) {
        viewModelScope.launch {
            prefsRepo.updateDataFreeMode(enabled)
            _statusBannerMessage.value = if (enabled) {
                "Data-Free Mode ON: Everything runs 100% offline."
            } else {
                "Data Mode ON: Ready for sync & sharing."
            }
        }
    }

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch {
            prefsRepo.updateLanguage(language)
        }
    }

    fun toggleBiometricLock(enabled: Boolean) {
        viewModelScope.launch {
            prefsRepo.updateBiometricLock(enabled)
            _statusBannerMessage.value = if (enabled) {
                "Biometric privacy lock enabled."
            } else {
                "Biometric privacy lock turned off."
            }
        }
    }

    fun logCareAction(category: CareCategory, count: Int = 1, note: String = "") {
        viewModelScope.launch {
            repository.logCare(category, todayEpochDay, count, note)
            _statusBannerMessage.value = "Logged ${category.name.lowercase().replace('_', ' ')}!"
        }
    }

    fun updateReminder(category: CareCategory, hour: Int, minute: Int, enabled: Boolean) {
        viewModelScope.launch {
            repository.upsertReminderSchedule(
                ReminderScheduleEntity(
                    categoryKey = category.key,
                    hour = hour,
                    minute = minute,
                    enabled = enabled
                )
            )
            reminderManager.scheduleDailyReminder(category, hour, minute, enabled)
            _statusBannerMessage.value = if (enabled) {
                "Reminder set for %02d:%02d".format(hour, minute)
            } else {
                "Reminder paused"
            }
        }
    }

    fun toggleSleepQuietMode(enable: Boolean) {
        viewModelScope.launch {
            when (val result = phoneControl.setSleepQuietMode(enable)) {
                is PhoneCommandResult.Success -> {
                    prefsRepo.updateSleepQuietMode(enable)
                    if (enable) {
                        repository.logCare(CareCategory.SLEEP, todayEpochDay, 1, "Sleep Quiet Mode")
                    }
                    _statusBannerMessage.value = result.feedback
                }
                is PhoneCommandResult.NeedsPermission -> {
                    _needsDndAccessDialog.value = true
                    _statusBannerMessage.value = result.feedback
                }
                is PhoneCommandResult.Info -> {
                    _statusBannerMessage.value = result.feedback
                }
            }
        }
    }

    fun executePhoneCommand(rawCommand: String) {
        val cmd = rawCommand.trim()
        if (cmd.isBlank()) return
        val lower = cmd.lowercase()
        val contacts = emergencyContacts.value
        val profile = userProfile.value

        when {
            "sleep" in lower || "dnd" in lower || "quiet" in lower || "turn apps down" in lower || "night" in lower -> {
                val turnOff = "off" in lower || "stop" in lower || "wake" in lower
                toggleSleepQuietMode(!turnOff)
            }
            "alarm" in lower || "wake" in lower -> {
                val timeMatch = Regex("(\\d{1,2})[:.](\\d{2})").find(lower)
                val hour = timeMatch?.groupValues?.get(1)?.toIntOrNull()?.coerceIn(0, 23) ?: 6
                val min = timeMatch?.groupValues?.get(2)?.toIntOrNull()?.coerceIn(0, 59) ?: 30
                val res = phoneControl.setWakeUpAlarm(hour, min)
                _statusBannerMessage.value = when (res) {
                    is PhoneCommandResult.Success -> res.feedback
                    is PhoneCommandResult.NeedsPermission -> res.feedback
                    is PhoneCommandResult.Info -> res.feedback
                }
            }
            "fresh air" in lower || "timer" in lower -> {
                val res = phoneControl.startFreshAirTimer(15)
                _statusBannerMessage.value = (res as? PhoneCommandResult.Success)?.feedback
                    ?: (res as? PhoneCommandResult.Info)?.feedback
            }
            "mute" in lower -> {
                val res = phoneControl.muteMediaVolume()
                _statusBannerMessage.value = (res as? PhoneCommandResult.Success)?.feedback
            }
            "volume down" in lower || "quieter" in lower || "lower" in lower -> {
                val res = phoneControl.adjustVolume(increase = false)
                _statusBannerMessage.value = (res as? PhoneCommandResult.Success)?.feedback
            }
            "volume up" in lower || "louder" in lower -> {
                val res = phoneControl.adjustVolume(increase = true)
                _statusBannerMessage.value = (res as? PhoneCommandResult.Success)?.feedback
            }
            "call" in lower -> {
                val matchedContact = contacts.firstOrNull { it.name.lowercase() in lower }
                val digits = Regex("\\d{3,}").find(lower)?.value
                val target = matchedContact?.phone ?: digits ?: profile.emergencyAuthorityNumber
                val res = phoneControl.dialNumber(target)
                _statusBannerMessage.value = (res as? PhoneCommandResult.Success)?.feedback
                    ?: (res as? PhoneCommandResult.Info)?.feedback
            }
            "whatsapp" in lower || "message" in lower || "text" in lower || "sms" in lower -> {
                val matchedContact = contacts.firstOrNull { it.name.lowercase() in lower }
                val targetPhone = matchedContact?.phone ?: ""
                val msg = "Hey, reaching out from Haven!"
                val res = if ("whatsapp" in lower) {
                    phoneControl.sendWhatsAppOrShare(targetPhone, msg)
                } else {
                    phoneControl.sendSms(targetPhone, msg)
                }
                _statusBannerMessage.value = (res as? PhoneCommandResult.Success)?.feedback
                    ?: (res as? PhoneCommandResult.Info)?.feedback
            }
            "water" in lower -> logCareAction(CareCategory.DRINK_WATER)
            "pee" in lower -> logCareAction(CareCategory.PEE)
            "poop" in lower -> logCareAction(CareCategory.POOP)
            "eat" in lower || "meal" in lower || "food" in lower -> logCareAction(CareCategory.EAT_MEAL)
            "bath" in lower || "shower" in lower -> logCareAction(CareCategory.BATH)
            "exercise" in lower || "workout" in lower -> logCareAction(CareCategory.EXERCISE, 15)
            else -> {
                _statusBannerMessage.value =
                    "Try: 'Sleep mode', 'Alarm 6:30', 'Volume down', 'Fresh air timer', 'Call Mom', 'Message Alex', or 'Log water'."
            }
        }
    }

    fun refreshCalendarEvents() {
        _calendarEvents.value = phoneControl.readTodayCalendarEvents()
    }

    fun addCalendarReminder(title: String, hour: Int, minute: Int) {
        val cleanTitle = title.trim().ifBlank { "Haven Wellness Check" }
        val res = phoneControl.addCalendarEvent(cleanTitle, hour, minute)
        refreshCalendarEvents()
        _statusBannerMessage.value = when (res) {
            is PhoneCommandResult.Success -> res.feedback
            is PhoneCommandResult.NeedsPermission -> res.feedback
            is PhoneCommandResult.Info -> res.feedback
        }
    }

    fun triggerWakeUpNow() {
        viewModelScope.launch {
            val profile = userProfile.value
            repository.logCare(CareCategory.WAKE_UP, todayEpochDay, 1, "Wake Up button")
            if (profile.sleepQuietModeActive) {
                if (phoneControl.hasDndPolicyAccess()) {
                    phoneControl.setSleepQuietMode(false)
                }
                prefsRepo.updateSleepQuietMode(false)
            }
            refreshCalendarEvents()
            val name = profile.name.ifBlank { "Friend" }
            _statusBannerMessage.value = "Good morning, $name! Wake Up logged & Sleep Quiet Mode turned off ☀️"
        }
    }

    fun openHavenWebsite() {
        val res = phoneControl.openHavenWebsite(userProfile.value.isDataFreeMode)
        _statusBannerMessage.value = when (res) {
            is PhoneCommandResult.Success -> res.feedback
            is PhoneCommandResult.Info -> res.feedback
            is PhoneCommandResult.NeedsPermission -> res.feedback
        }
    }

    fun askPersonalAiSpace(prompt: String, resultType: AiResultType) {
        val trimmed = prompt.trim()
        if (trimmed.isBlank()) return
        if (resultType == AiResultType.PHONE_COMMAND && !userProfile.value.hasActiveSubscription) {
            _showSubscribeDialog.value = true
            _statusBannerMessage.value =
                "AI Phone & Voice Control require Haven Plus (from R5/wk via Airtime or 1ForYou Voucher)."
            return
        }
        _isAiThinking.value = true
        viewModelScope.launch {
            if (resultType == AiResultType.PHONE_COMMAND) {
                executePhoneCommand(trimmed)
            }
            val cal = phoneControl.readTodayCalendarEvents()
            _calendarEvents.value = cal
            val result = aiRepository.generateAiSpaceResult(
                prompt = trimmed,
                resultType = resultType,
                profile = userProfile.value,
                calendarEvents = cal
            )
            _aiSpaceResults.value = listOf(result) + _aiSpaceResults.value
            _isAiThinking.value = false
        }
    }

    fun selectMood(mood: MoodType) {
        _selectedMood.value = mood
    }

    fun sendPillowMessage(text: String) {
        val trimmed = text.trim()
        if (trimmed.isBlank()) return
        val userMsg = ChatMessage(
            id = UUID.randomUUID().toString(),
            isFromUser = true,
            text = trimmed
        )
        _chatMessages.value = _chatMessages.value + userMsg
        _isAiThinking.value = true

        viewModelScope.launch {
            val reply = aiRepository.chatWithPillowOfStrength(
                userMessage = trimmed,
                currentMood = _selectedMood.value,
                profile = userProfile.value,
                history = _chatMessages.value
            )
            _chatMessages.value = _chatMessages.value + ChatMessage(
                id = UUID.randomUUID().toString(),
                isFromUser = false,
                text = reply.text,
                isPlaceholderSample = reply.isPlaceholderSample
            )
            _isAiThinking.value = false
        }
    }

    fun saveDiaryEntry(title: String, content: String, mood: MoodType, energy: Int, isVoiceTyped: Boolean) {
        if (content.isBlank()) return
        viewModelScope.launch {
            _isAiThinking.value = true
            val analysis = aiRepository.analyzeDiaryEntryAndSupport(
                content = content.trim(),
                selectedMood = mood,
                profile = userProfile.value
            )
            repository.saveDiaryEntry(
                title = title.ifBlank { "${analysis.suggestedMood.label} Reflection" },
                content = content.trim(),
                moodKey = analysis.suggestedMood.key,
                energyScore = energy,
                isVoiceTyped = isVoiceTyped,
                detectedCue = analysis.detectedCue,
                aiSupportResponse = analysis.supportiveResponse
            )
            _selectedMood.value = analysis.suggestedMood
            _isAiThinking.value = false
            _statusBannerMessage.value = "Diary saved • Cue recognized: ${analysis.detectedCue}"
        }
    }

    fun deleteDiaryEntry(id: Int) {
        viewModelScope.launch { repository.deleteDiaryEntry(id) }
    }

    fun markFactLearned() {
        _learnedFactsCount.value += 1
    }

    fun recordQuizAnswer(correct: Boolean) {
        if (correct) _quizStreak.value += 1
    }

    fun askTutorTshenoloMaseko(question: String, subject: String) {
        val trimmed = question.trim()
        if (trimmed.isBlank()) return
        _tutorMessages.value = _tutorMessages.value + ChatMessage(
            id = UUID.randomUUID().toString(),
            isFromUser = true,
            text = "[$subject] $trimmed"
        )
        _isAiThinking.value = true
        viewModelScope.launch {
            val reply = aiRepository.askTutorTshenoloMaseko(trimmed, subject, userProfile.value)
            _tutorMessages.value = _tutorMessages.value + ChatMessage(
                id = UUID.randomUUID().toString(),
                isFromUser = false,
                text = reply.text,
                isPlaceholderSample = reply.isPlaceholderSample
            )
            _isAiThinking.value = false
        }
    }

    fun logPeriodStartToday(flowLevel: String, crampsLevel: Int, symptoms: String, notes: String) {
        viewModelScope.launch {
            prefsRepo.updateLastPeriodDay(todayEpochDay)
            repository.logCycleDay(todayEpochDay, flowLevel, crampsLevel, symptoms, notes)
            _statusBannerMessage.value = "Cycle day logged."
        }
    }

    fun logBoysVitality(
        workoutMinutes: Int,
        workoutType: String,
        proteinMeals: Int,
        hydrationAndZincDone: Boolean,
        sleepHours: Float,
        notes: String
    ) {
        viewModelScope.launch {
            repository.logVitality(
                epochDay = todayEpochDay,
                workoutMinutes = workoutMinutes,
                workoutType = workoutType,
                proteinMeals = proteinMeals,
                hydrationAndZincDone = hydrationAndZincDone,
                sleepHours = sleepHours,
                notes = notes
            )
            if (workoutMinutes > 0) {
                repository.logCare(CareCategory.EXERCISE, todayEpochDay, workoutMinutes, workoutType)
            }
            _statusBannerMessage.value = "Fitness & vitality log saved!"
        }
    }

    fun runHormoneCheck(
        energy: Int,
        moodBalance: Int,
        skinClarity: Int,
        sleepQuality: Int,
        stressCalm: Int,
        dailySymptoms: String = ""
    ) {
        viewModelScope.launch {
            _isAiThinking.value = true
            val reply = aiRepository.analyzeHormoneBalance(
                energy = energy,
                moodBalance = moodBalance,
                skinClarity = skinClarity,
                sleepQuality = sleepQuality,
                stressCalm = stressCalm,
                profile = userProfile.value
            )
            repository.saveHormoneCheck(
                HormoneCheckEntity(
                    energyScore = energy,
                    moodBalanceScore = moodBalance,
                    skinClarityScore = skinClarity,
                    sleepQualityScore = sleepQuality,
                    stressCalmScore = stressCalm,
                    dailySymptoms = dailySymptoms,
                    insightSummary = reply.text
                )
            )
            _isAiThinking.value = false
            _statusBannerMessage.value = "Hormone & wellness check-in saved."
        }
    }

    fun addEmergencyContact(name: String, phone: String, relationship: String) {
        if (name.isBlank() || phone.isBlank()) return
        viewModelScope.launch {
            repository.addEmergencyContact(name.trim(), phone.trim(), relationship.trim())
            _statusBannerMessage.value = "Added $name to trusted SOS contacts."
        }
    }

    fun deleteEmergencyContact(id: Int) {
        viewModelScope.launch { repository.deleteEmergencyContact(id) }
    }

    fun activateSosTrigger(
        action: SosTriggerAction,
        customMessage: String = ""
    ) {
        viewModelScope.launch {
            val location = phoneControl.getBestLastKnownLocationText()
            val profile = userProfile.value
            val contactsList = emergencyContacts.value
            val messageSummary = customMessage.ifBlank { EmergencySosIntentHelper.DEFAULT_SOS_BODY }

            val channelLabel = when (action) {
                SosTriggerAction.CALL_AUTHORITY -> "Emergency Call (${profile.emergencyAuthorityNumber})"
                SosTriggerAction.SEND_PRECONFIGURED_SMS -> "Pre-Configured SOS SMS"
                SosTriggerAction.WHATSAPP_OR_SHARE -> "WhatsApp / Share"
            }

            repository.logSosMessage(
                SosMessageEntity(
                    recipientName = if (action == SosTriggerAction.CALL_AUTHORITY) {
                        "Authority (${profile.emergencyAuthorityNumber})"
                    } else {
                        contactsList.joinToString { it.name }.ifBlank { "Trusted Contacts" }
                    },
                    recipientPhone = if (action == SosTriggerAction.CALL_AUTHORITY) {
                        profile.emergencyAuthorityNumber
                    } else {
                        contactsList.joinToString(";") { it.phone }
                    },
                    messageText = messageSummary,
                    locationSummary = location,
                    channel = channelLabel,
                    status = "SOS Trigger Activated"
                )
            )

            val res = when {
                action == SosTriggerAction.WHATSAPP_OR_SHARE && profile.isDataFreeMode -> {
                    sosIntentHelper.sendPreConfiguredSosSms(
                        contactsList,
                        sosIntentHelper.buildPreConfiguredSosMessage(profile, location, customMessage)
                    ).also {
                        _statusBannerMessage.value = "No-Data Limited Mode: switched WhatsApp web share to offline SOS SMS."
                    }
                }
                else -> sosIntentHelper.activateSosTrigger(
                    action = action,
                    profile = profile,
                    contacts = contactsList,
                    locationText = location,
                    customMessage = customMessage
                )
            }
            if (!(action == SosTriggerAction.WHATSAPP_OR_SHARE && profile.isDataFreeMode)) {
                _statusBannerMessage.value = (res as? PhoneCommandResult.Success)?.feedback
                    ?: (res as? PhoneCommandResult.Info)?.feedback
            }
        }
    }

    fun dispatchSosMessage(
        contact: EmergencyContactEntity?,
        customMessage: String,
        channel: String
    ) {
        viewModelScope.launch {
            val location = phoneControl.getBestLastKnownLocationText()
            val profile = userProfile.value
            val fullPayload = sosIntentHelper.buildPreConfiguredSosMessage(
                profile = profile,
                locationText = location,
                customReason = customMessage
            )
            val recipientName = contact?.name ?: "Trusted Contacts"
            val recipientPhone = contact?.phone ?: ""

            repository.logSosMessage(
                SosMessageEntity(
                    recipientName = recipientName,
                    recipientPhone = recipientPhone,
                    messageText = customMessage.ifBlank { "Urgent SOS Help Needed" },
                    locationSummary = location,
                    channel = channel,
                    status = "Dispatched ($channel)"
                )
            )

            val res = when {
                channel == "WhatsApp" && profile.isDataFreeMode -> {
                    sosIntentHelper.sendPreConfiguredSosSms(listOfNotNull(contact), fullPayload)
                    PhoneCommandResult.Info("No-Data Limited Mode: WhatsApp web paused—opening offline SMS instead.")
                }
                channel == "WhatsApp" -> {
                    val intent = sosIntentHelper.buildWhatsAppOrShareIntent(recipientPhone, fullPayload)
                    try {
                        getApplication<Application>().startActivity(intent)
                        PhoneCommandResult.Success("Opening WhatsApp / share sheet.")
                    } catch (_: Exception) {
                        sosIntentHelper.sendPreConfiguredSosSms(listOfNotNull(contact), fullPayload)
                    }
                }
                else -> sosIntentHelper.sendPreConfiguredSosSms(listOfNotNull(contact), fullPayload)
            }
            _statusBannerMessage.value = (res as? PhoneCommandResult.Success)?.feedback
                ?: (res as? PhoneCommandResult.Info)?.feedback
        }
    }

    fun backupToEmail() {
        val profile = userProfile.value
        if (profile.isDataFreeMode) {
            _statusBannerMessage.value =
                "No-Data Limited Mode: remote email sending paused. Turn off Data-Free Mode when you have data to send."
            return
        }
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        val body = buildString {
            appendLine("=== HAVEN TEEN WELLNESS BACKUP ===")
            appendLine("Generated: ${dateFormat.format(Date())}")
            appendLine("Name: ${profile.name.ifBlank { "Not set" }} | Age: ${profile.age} | Gender: ${profile.gender.label}")
            appendLine("Country: ${profile.countryCode} | ID: ${profile.idNumber} | Language: ${profile.language.nativeName}")
            appendLine("Emergency Number: ${profile.emergencyAuthorityNumber} | Blood: ${profile.bloodType} | Allergies: ${profile.allergies}")
            appendLine()
            appendLine("--- TODAY CARE LOGS (${todayCareLogs.value.size}) ---")
            todayCareLogs.value.take(25).forEach {
                appendLine("• ${it.categoryKey} (+${it.countAdded}) ${it.note}")
            }
            appendLine()
            appendLine("--- DIARY ENTRIES (${diaryEntries.value.size}) ---")
            diaryEntries.value.take(20).forEach {
                appendLine("[${dateFormat.format(Date(it.timestamp))}] (${it.moodKey}, Energy ${it.energyScore}/5) ${it.title}: ${it.content}")
            }
            appendLine()
            appendLine("--- HORMONE CHECKS (${hormoneChecks.value.size}) ---")
            hormoneChecks.value.take(5).forEach {
                appendLine("[${dateFormat.format(Date(it.timestamp))}] Energy:${it.energyScore} Mood:${it.moodBalanceScore} Sleep:${it.sleepQualityScore} StressCalm:${it.stressCalmScore}")
            }
        }

        val res = phoneControl.sendBackupEmail(
            recipientEmail = profile.backupEmail,
            subject = "Haven Wellness & Diary Backup (${dateFormat.format(Date())})",
            body = body
        )
        _statusBannerMessage.value = (res as? PhoneCommandResult.Success)?.feedback
            ?: (res as? PhoneCommandResult.Info)?.feedback
    }
}

private data class Quad<A, B, C, D>(
    val first: A,
    val second: B,
    val third: C,
    val fourth: D
)
