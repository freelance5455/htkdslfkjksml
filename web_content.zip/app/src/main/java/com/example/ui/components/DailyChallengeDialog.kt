package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.launch
import androidx.compose.ui.window.DialogProperties
import com.example.data.DailyChallenges
import com.example.data.getTimeUntilNextDaily
import com.example.model.DailyRecord
import com.example.model.QuizItem
import com.example.ui.theme.GameAmber
import com.example.ui.theme.GameAmberBright
import com.example.ui.theme.GameBorder
import com.example.ui.theme.GameCyan
import com.example.ui.theme.GameDarkBackground
import com.example.ui.theme.GameEmerald
import com.example.ui.theme.GameOrange
import com.example.ui.theme.GameRose
import com.example.ui.theme.GameSurfaceDark
import com.example.ui.theme.GameSurfaceElevated
import com.example.ui.theme.GameViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class CalendarDayItem(
    val dateStr: String,
    val dayOfWeek: String,
    val dayOfMonth: Int,
    val isToday: Boolean,
    val isCompleted: Boolean,
    val record: DailyRecord?
)

data class StreakMilestone(
    val day: Int,
    val label: String,
    val multiplier: String,
    val title: String,
    val isGrandJackpot: Boolean = false
)

private val SEVEN_DAY_MILESTONES = listOf(
    StreakMilestone(1, "D1", "1.15x", "Bronze Spark"),
    StreakMilestone(2, "D2", "1.30x", "Silver Flame"),
    StreakMilestone(3, "D3", "1.45x", "Golden Blaze"),
    StreakMilestone(4, "D4", "1.55x", "Rising Star"),
    StreakMilestone(5, "D5", "1.65x", "Platinum Fire"),
    StreakMilestone(6, "D6", "1.80x", "Master Flame"),
    StreakMilestone(7, "D7", "2.00x", "Inferno Crown", isGrandJackpot = true)
)

@Composable
fun DailyChallengeDialog(
    dailyItem: QuizItem,
    isCompletedToday: Boolean,
    streakDays: Int,
    multiplierLabel: String,
    dailyHistory: Map<String, DailyRecord> = emptyMap(),
    highestStreak: Int = streakDays,
    isReminderEnabled: Boolean = true,
    onToggleReminder: (Boolean) -> Unit = {},
    onTestReminder: () -> Unit = {},
    onPlayDaily: () -> Unit,
    onDismiss: () -> Unit
) {
    val dateString = DailyChallenges.getTodayDateString()
    val scrollState = rememberScrollState()
    var selectedTab by remember { mutableIntStateOf(0) } // 0: 7-Day Path, 1: Calendar View
    var selectedCalendarDay by remember { mutableStateOf<CalendarDayItem?>(null) }

    // Calculate 7-day goal progress
    val clampedStreak = streakDays.coerceAtMost(7)
    val goalProgressTarget = (clampedStreak / 7f).coerceIn(0f, 1f)
    val animatedProgress by animateFloatAsState(
        targetValue = goalProgressTarget,
        animationSpec = tween(durationMillis = 600),
        label = "7_day_progress"
    )
    val daysRemaining = (7 - streakDays).coerceAtLeast(0)

    // Build calendar days for the past 7 days
    val past7Days = remember(dailyHistory, isCompletedToday) {
        getPast7CalendarDays(dailyHistory, isCompletedToday)
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .heightIn(max = 720.dp)
                .padding(vertical = 12.dp)
                .clip(RoundedCornerShape(28.dp))
                .border(2.dp, GameViolet.copy(alpha = 0.5f), RoundedCornerShape(28.dp))
                .testTag("daily_challenge_dialog"),
            color = GameDarkBackground
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(scrollState)
                    .padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = Color(0xFF2C124D),
                            modifier = Modifier.size(34.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.CalendarToday,
                                    contentDescription = null,
                                    tint = Color(0xFFE879F9),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "DAILY CHALLENGE",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                            Text(
                                text = DailyChallenges.formatDailyDate(dateString),
                                fontSize = 11.sp,
                                color = TextSecondary,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = TextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // 7-DAY STREAK GOAL HERO CARD
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    color = Color(0xFF1E1033),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF581C87))
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Title & Streak Stats
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.LocalFireDepartment,
                                    contentDescription = null,
                                    tint = GameOrange,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(
                                        text = "$streakDays-DAY STREAK",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "Best Streak: $highestStreak Days",
                                        fontSize = 10.sp,
                                        color = TextSecondary
                                    )
                                }
                            }

                            // 7-Day Target Pill
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (streakDays >= 7) GameAmber.copy(alpha = 0.2f) else Color(0xFF331B54),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (streakDays >= 7) GameAmberBright else Color(0xFF6B21A8)
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.EmojiEvents,
                                        contentDescription = null,
                                        tint = if (streakDays >= 7) GameAmberBright else Color(0xFFF0ABFC),
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "Goal: 7 Days",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (streakDays >= 7) GameAmberBright else Color(0xFFF5D0FE)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Progress Bar Header
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "7-Day Goal Progress",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextSecondary
                            )
                            Text(
                                text = "$clampedStreak / 7 Days (${(clampedStreak * 100) / 7}%)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = GameAmberBright
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // Visual Custom Progress Bar with Glowing Milestones
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(12.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF0F0A1C))
                                .border(1.dp, Color(0xFF3B1861), RoundedCornerShape(6.dp))
                                .testTag("streak_progress_bar")
                        ) {
                            // Filled Progress
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(animatedProgress)
                                    .fillMaxHeight()
                                    .background(
                                        Brush.horizontalGradient(
                                            listOf(GameOrange, GameAmber, GameAmberBright)
                                        )
                                    )
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Motivational Streak Status message
                        Text(
                            text = when {
                                streakDays >= 7 -> "🏆 7-Day Goal Accomplished! Maximum 2.0x Inferno Multiplier Active!"
                                streakDays == 0 -> "Complete today's puzzle to ignite your 7-day streak towards 2.0x boost!"
                                daysRemaining == 1 -> "⚡ Only 1 more day left to reach the 7-Day Inferno Jackpot (+150 🪙)!"
                                else -> "🔥 $daysRemaining more days until the 7-Day Inferno Crown (2.0x Multiplier)!"
                            },
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (streakDays >= 7) GameAmberBright else Color(0xFFF5D0FE),
                            textAlign = TextAlign.Center
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // VIEW SELECTOR (Milestone Path vs Calendar View)
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = GameSurfaceDark,
                    border = androidx.compose.foundation.BorderStroke(1.dp, GameBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(3.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        TabButton(
                            title = "7-Day Path",
                            icon = Icons.Default.Timeline,
                            isSelected = selectedTab == 0,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("streak_tab_path"),
                            onClick = { selectedTab = 0 }
                        )

                        TabButton(
                            title = "Calendar View",
                            icon = Icons.Default.CalendarMonth,
                            isSelected = selectedTab == 1,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("streak_tab_calendar"),
                            onClick = { selectedTab = 1 }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // TAB CONTENT
                if (selectedTab == 0) {
                    // TAB 0: 7-DAY MILESTONE STEP LADDER
                    SevenDayMilestonePath(
                        streakDays = streakDays,
                        clampedStreak = clampedStreak
                    )
                } else {
                    // TAB 1: 7-DAY CALENDAR VIEW STRIP
                    SevenDayCalendarStrip(
                        days = past7Days,
                        selectedDay = selectedCalendarDay,
                        onSelectDay = { selectedCalendarDay = it }
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // TODAY'S PUZZLE CARD
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    color = GameSurfaceDark,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isCompletedToday) GameEmerald.copy(alpha = 0.5f) else Color(0xFF2C3953)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (isCompletedToday) GameEmerald.copy(alpha = 0.2f) else Color(0xFF23163C)
                                )
                                .border(
                                    1.dp,
                                    if (isCompletedToday) GameEmerald else Color(0xFF6B21A8),
                                    RoundedCornerShape(12.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isCompletedToday) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = GameEmerald,
                                    modifier = Modifier.size(24.dp)
                                )
                            } else {
                                Text("🎯", fontSize = 20.sp)
                            }
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = if (isCompletedToday) "Today's Puzzle Solved!" else "Today's Daily Mystery",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                            Text(
                                text = if (isCompletedToday) "Streak recorded for today" else "Category: ${dailyItem.categoryLabel} • ${dailyItem.difficulty}",
                                fontSize = 11.sp,
                                color = if (isCompletedToday) GameEmerald else TextSecondary
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = GameAmber.copy(alpha = 0.18f)
                            ) {
                                Text(
                                    text = "+150 🪙",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    color = GameAmberBright,
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Mult: $multiplierLabel",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFF5D0FE)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Reset timer countdown
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Schedule,
                        contentDescription = null,
                        tint = TextMuted,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "New challenge resets in ${getTimeUntilNextDaily()}",
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // 5:00 PM PUSH NOTIFICATION REMINDER CARD
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("daily_reminder_card"),
                    shape = RoundedCornerShape(16.dp),
                    color = GameSurfaceElevated,
                    border = androidx.compose.foundation.BorderStroke(1.dp, GameViolet.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = GameAmber.copy(alpha = 0.15f),
                                    modifier = Modifier.size(34.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.NotificationsActive,
                                            contentDescription = "Daily Reminder",
                                            tint = GameAmberBright,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "5:00 PM Daily Reminder",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = if (isReminderEnabled) "Active • Alerts at 5:00 PM if unsolved" else "Disabled • No alert will be sent",
                                        fontSize = 11.sp,
                                        color = if (isReminderEnabled) GameEmerald else TextMuted
                                    )
                                }
                            }
                            Switch(
                                checked = isReminderEnabled,
                                onCheckedChange = onToggleReminder,
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = GameAmberBright,
                                    checkedTrackColor = GameViolet
                                ),
                                modifier = Modifier.testTag("daily_reminder_switch")
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (isCompletedToday) "✅ Today's challenge solved! Streak is secure." else "⚠️ Unsolved! Alert triggers at 5:00 PM.",
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Medium,
                                color = if (isCompletedToday) GameEmerald else Color(0xFFFBBF24),
                                modifier = Modifier.weight(1f)
                            )

                            OutlinedButton(
                                onClick = onTestReminder,
                                modifier = Modifier
                                    .height(28.dp)
                                    .testTag("btn_test_reminder"),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = Color(0xFFF5D0FE)
                                ),
                                border = androidx.compose.foundation.BorderStroke(1.dp, GameViolet.copy(alpha = 0.6f))
                            ) {
                                Text("Test Alert", fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Play / Replay Action Button
                Button(
                    onClick = {
                        onPlayDaily()
                        onDismiss()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("play_daily_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isCompletedToday) Color(0xFF222F47) else GameViolet,
                        contentColor = Color.White
                    )
                ) {
                    Text(
                        text = if (isCompletedToday) "Replay Daily Challenge" else "Play Today's Challenge",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun TabButton(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(11.dp))
            .clickable { onClick() },
        color = if (isSelected) Color(0xFF291547) else Color.Transparent,
        border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, GameViolet) else null
    ) {
        Row(
            modifier = Modifier.padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) Color(0xFFE879F9) else TextSecondary,
                modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) Color.White else TextSecondary
            )
        }
    }
}

@Composable
private fun SevenDayMilestonePath(
    streakDays: Int,
    clampedStreak: Int
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = GameSurfaceDark,
        border = androidx.compose.foundation.BorderStroke(1.dp, GameBorder)
    ) {
        Column(
            modifier = Modifier.padding(12.dp)
        ) {
            Text(
                text = "7-Day Streak Multiplier Roadmap",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                text = "Each day adds to your score multiplier up to 2.0x on Day 7",
                fontSize = 10.sp,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 7 Steps Displayed in a visual grid/row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SEVEN_DAY_MILESTONES.forEach { milestone ->
                    val isReached = streakDays >= milestone.day
                    val isCurrentTarget = (streakDays + 1) == milestone.day

                    MilestoneNode(
                        milestone = milestone,
                        isReached = isReached,
                        isCurrentTarget = isCurrentTarget
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Day 7 Grand Reward Highlight Card
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                color = if (streakDays >= 7) Color(0xFF2C1802) else Color(0xFF1B1429),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (streakDays >= 7) GameAmberBright else Color(0xFF581C87)
                )
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("👑", fontSize = 18.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Day 7 Grand Inferno Jackpot",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = if (streakDays >= 7) GameAmberBright else Color.White
                            )
                            Text(
                                text = "Unlocks 2.0x Double Points + 150 🪙 Bonus",
                                fontSize = 10.sp,
                                color = if (streakDays >= 7) GameAmber else TextSecondary
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (streakDays >= 7) GameEmerald.copy(alpha = 0.2f) else Color(0xFF331E52)
                    ) {
                        Text(
                            text = if (streakDays >= 7) "ACTIVE" else "LOCKED",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Black,
                            color = if (streakDays >= 7) GameEmerald else Color(0xFFD8B4FE),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MilestoneNode(
    milestone: StreakMilestone,
    isReached: Boolean,
    isCurrentTarget: Boolean
) {
    val borderColor = when {
        isReached -> GameAmberBright
        isCurrentTarget -> Color(0xFFE879F9)
        else -> Color(0xFF2A364F)
    }

    val bgColor = when {
        isReached -> Color(0xFF301E06)
        isCurrentTarget -> Color(0xFF2D124D)
        else -> Color(0xFF141C2B)
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.testTag("day_step_${milestone.day}")
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(bgColor)
                .border(1.5.dp, borderColor, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            when {
                isReached -> {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Reached",
                        tint = GameAmberBright,
                        modifier = Modifier.size(16.dp)
                    )
                }
                isCurrentTarget -> {
                    Text("🎯", fontSize = 12.sp)
                }
                milestone.isGrandJackpot -> {
                    Text("👑", fontSize = 13.sp)
                }
                else -> {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Locked",
                        tint = TextMuted,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(3.dp))

        Text(
            text = milestone.label,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = if (isReached || isCurrentTarget) Color.White else TextMuted
        )

        Text(
            text = milestone.multiplier,
            fontSize = 8.sp,
            fontWeight = FontWeight.Bold,
            color = if (isReached) GameAmberBright else if (isCurrentTarget) Color(0xFFF5D0FE) else TextMuted
        )
    }
}

@Composable
private fun SevenDayCalendarStrip(
    days: List<CalendarDayItem>,
    selectedDay: CalendarDayItem?,
    onSelectDay: (CalendarDayItem) -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = GameSurfaceDark,
        border = androidx.compose.foundation.BorderStroke(1.dp, GameBorder)
    ) {
        Column(
            modifier = Modifier.padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Past 7 Days History",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Text(
                    text = "Tap a day for details",
                    fontSize = 10.sp,
                    color = TextSecondary
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Calendar Strip Row of 7 Days
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                days.forEach { dayItem ->
                    CalendarDayCell(
                        dayItem = dayItem,
                        isSelected = selectedDay?.dateStr == dayItem.dateStr,
                        onClick = { onSelectDay(dayItem) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Details of selected or today's day
            val activeDay = selectedDay ?: days.lastOrNull()
            if (activeDay != null) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF161E2E),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF26334D))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "${activeDay.dayOfWeek} (${activeDay.dateStr})",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = if (activeDay.isCompleted) {
                                    val pts = activeDay.record?.scoreEarned ?: 1200
                                    val stage = activeDay.record?.zoomStage ?: 1
                                    "Completed at Stage $stage • +$pts PTS"
                                } else if (activeDay.isToday) {
                                    "Ready to solve today!"
                                } else {
                                    "Missed daily challenge"
                                },
                                fontSize = 10.sp,
                                color = if (activeDay.isCompleted) GameEmerald else if (activeDay.isToday) GameAmberBright else TextMuted
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (activeDay.isCompleted) GameEmerald.copy(alpha = 0.2f) else if (activeDay.isToday) GameAmber.copy(alpha = 0.2f) else Color(0xFF222B3D)
                        ) {
                            Text(
                                text = if (activeDay.isCompleted) "✓ SOLVED" else if (activeDay.isToday) "TODAY" else "MISSED",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Black,
                                color = if (activeDay.isCompleted) GameEmerald else if (activeDay.isToday) GameAmberBright else TextMuted,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CalendarDayCell(
    dayItem: CalendarDayItem,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val popScale = remember { Animatable(1f) }

    // Sparkling animation for completed calendar cells
    val infiniteTransition = rememberInfiniteTransition(label = "cellSparkle")
    val sparkleAlpha by if (dayItem.isCompleted) {
        infiniteTransition.animateFloat(
            initialValue = 0.35f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(1200, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "sparkleAlpha"
        )
    } else {
        remember { mutableStateOf(0f) }
    }

    val sparkleScale by if (dayItem.isCompleted) {
        infiniteTransition.animateFloat(
            initialValue = 0.75f,
            targetValue = 1.3f,
            animationSpec = infiniteRepeatable(
                animation = tween(1400, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "sparkleScale"
        )
    } else {
        remember { mutableStateOf(1f) }
    }

    val borderColor = when {
        isSelected -> GameAmberBright
        dayItem.isToday -> Color(0xFFE879F9)
        dayItem.isCompleted -> GameEmerald.copy(alpha = (0.55f + sparkleAlpha * 0.45f).coerceIn(0.55f, 1f))
        else -> Color(0xFF26334D)
    }

    val bgColor = when {
        isSelected -> Color(0xFF2C1F0A)
        dayItem.isToday -> Color(0xFF291345)
        dayItem.isCompleted -> Color(0xFF09291C)
        else -> Color(0xFF131A26)
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .scale(popScale.value)
            .clip(RoundedCornerShape(10.dp))
            .clickable {
                coroutineScope.launch {
                    popScale.animateTo(1.22f, animationSpec = tween(90, easing = FastOutSlowInEasing))
                    popScale.animateTo(0.92f, animationSpec = tween(70, easing = FastOutSlowInEasing))
                    popScale.animateTo(1f, animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy))
                }
                onClick()
            }
            .testTag(if (dayItem.isToday) "calendar_day_today" else "calendar_day_${dayItem.dayOfMonth}")
    ) {
        Text(
            text = dayItem.dayOfWeek,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = if (dayItem.isToday) Color(0xFFF5D0FE) else TextSecondary
        )

        Spacer(modifier = Modifier.height(3.dp))

        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(bgColor)
                .border(
                    if (dayItem.isCompleted) 1.5.dp else 1.2.dp,
                    borderColor,
                    RoundedCornerShape(10.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            // Sparkle effect star in corner for completed cells
            if (dayItem.isCompleted) {
                Text(
                    text = "✦",
                    fontSize = 8.sp,
                    color = Color(0xFFFDE047).copy(alpha = sparkleAlpha),
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 1.dp, end = 2.dp)
                        .scale(sparkleScale)
                )
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "${dayItem.dayOfMonth}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    color = if (dayItem.isCompleted) GameEmerald else if (dayItem.isToday) Color.White else TextSecondary
                )
                if (dayItem.isCompleted) {
                    Box(
                        modifier = Modifier
                            .size(4.dp)
                            .clip(CircleShape)
                            .background(GameEmerald)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(2.dp))

        Text(
            text = if (dayItem.isCompleted) "✓" else if (dayItem.isToday) "•" else "-",
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = if (dayItem.isCompleted) GameEmerald else if (dayItem.isToday) GameAmberBright else TextMuted
        )
    }
}

private fun getPast7CalendarDays(
    dailyHistory: Map<String, DailyRecord>,
    isCompletedToday: Boolean
): List<CalendarDayItem> {
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val dayFormat = SimpleDateFormat("EEE", Locale.US)
    val list = mutableListOf<CalendarDayItem>()

    for (i in 6 downTo 0) {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -i)
        val dateStr = sdf.format(cal.time)
        val isToday = (i == 0)
        val record = dailyHistory[dateStr]
        val completed = if (isToday) (isCompletedToday || (record?.solved == true)) else (record?.solved == true)

        list.add(
            CalendarDayItem(
                dateStr = dateStr,
                dayOfWeek = if (isToday) "Today" else dayFormat.format(cal.time),
                dayOfMonth = cal.get(Calendar.DAY_OF_MONTH),
                isToday = isToday,
                isCompleted = completed,
                record = record
            )
        )
    }
    return list
}
