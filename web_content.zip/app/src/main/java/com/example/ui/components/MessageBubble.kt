package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ChatMessage
import com.example.data.model.MessageRole
import com.example.ui.theme.InterFontFamily
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NexusBorder
import com.example.ui.theme.NexusCodeBackground
import com.example.ui.theme.NexusCyan
import com.example.ui.theme.NexusCyanDark
import com.example.ui.theme.NexusSurface
import com.example.ui.theme.NexusSurfaceElevated
import com.example.ui.theme.NexusSurfaceVariant
import com.example.ui.theme.NexusTextPrimary
import com.example.ui.theme.NexusTextSecondary
import com.example.ui.theme.NexusTextTertiary
import com.example.ui.theme.NexusVioletLight
import com.example.ui.theme.SpaceGroteskFontFamily

@Composable
fun MessageBubble(
    message: ChatMessage,
    assistantName: String,
    onSpeakClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isUser = message.role == MessageRole.USER
    val isSystem = message.role == MessageRole.SYSTEM

    if (isSystem) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = message.content,
                color = NexusTextTertiary,
                fontSize = 12.sp,
                modifier = Modifier
                    .background(NexusSurfaceVariant.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                    .padding(horizontal = 12.dp, vertical = 5.dp)
            )
        }
        return
    }

    if (isUser) {
        // ChatGPT / Claude style compact right-aligned dark-violet pill without avatar clutter
        Box(
            modifier = modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            contentAlignment = Alignment.CenterEnd
        ) {
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = NexusSurfaceElevated,
                modifier = Modifier
                    .widthIn(max = 310.dp)
                    .testTag("user_message_bubble")
            ) {
                Text(
                    text = message.content,
                    color = NexusTextPrimary,
                    fontFamily = InterFontFamily,
                    fontSize = 15.sp,
                    lineHeight = 22.sp,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 11.dp)
                )
            }
        }
        return
    }

    // ChatGPT / Claude style borderless full-width editorial prose for Assistant responses
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp)
            .testTag("assistant_message_bubble")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(NexusCyanDark)
                    .border(0.8.dp, NexusCyan.copy(alpha = 0.45f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = assistantName,
                    tint = NexusVioletLight,
                    modifier = Modifier.size(13.dp)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = assistantName,
                color = NexusTextPrimary,
                fontSize = 13.5.sp,
                fontFamily = SpaceGroteskFontFamily,
                fontWeight = FontWeight.SemiBold
            )

            val isOffline = message.engineUsed.contains("On-Device", ignoreCase = true) ||
                message.engineUsed.contains("Local", ignoreCase = true) ||
                message.engineUsed.contains("Офлайн", ignoreCase = true)

            if (isOffline || message.latencyMs > 0) {
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isOffline) "Офлайн" else "${message.latencyMs} мс",
                    fontSize = 11.sp,
                    fontFamily = JetBrainsMonoFontFamily,
                    color = NexusTextTertiary
                )
            }
        }

        Column(modifier = Modifier.fillMaxWidth()) {
            RenderFormattedMarkdown(
                content = message.content,
                onCopyCode = { code ->
                    copyToClipboard(context, code, "Код скопирован")
                }
            )

            if (!message.isStreaming && message.content.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    IconButton(
                        onClick = { copyToClipboard(context, message.content, "Текст скопирован") },
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("copy_message_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Копировать",
                            tint = NexusTextTertiary,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    IconButton(
                        onClick = { onSpeakClick(message.content) },
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("speak_message_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = "Озвучить",
                            tint = NexusTextTertiary,
                            modifier = Modifier.size(17.dp)
                        )
                    }
                }
            }
        }
    }
}

private fun copyToClipboard(context: Context, text: String, toastMsg: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText("Nexus Content", text)
    clipboard.setPrimaryClip(clip)
    Toast.makeText(context, toastMsg, Toast.LENGTH_SHORT).show()
}

@Composable
private fun RenderFormattedMarkdown(
    content: String,
    onCopyCode: (String) -> Unit
) {
    val parts = remember(content) { content.split("```") }
    parts.forEachIndexed { index, part ->
        if (index % 2 == 1) {
            val lines = part.trim().lines()
            val firstLine = lines.firstOrNull()?.trim().orEmpty()
            val hasLang = firstLine.isNotEmpty() && firstLine.length <= 16 && !firstLine.contains(" ")
            val lang = if (hasLang) firstLine else "code"
            val codeBody = if (hasLang) lines.drop(1).joinToString("\n") else part.trim()

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = NexusCodeBackground,
                border = BorderStroke(0.8.dp, NexusBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(NexusSurface.copy(alpha = 0.85f))
                            .padding(horizontal = 12.dp, vertical = 7.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = lang.lowercase(),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = NexusTextSecondary,
                            fontFamily = JetBrainsMonoFontFamily
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .clickable { onCopyCode(codeBody) }
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Копировать код",
                                tint = NexusTextSecondary,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Копировать",
                                fontSize = 11.sp,
                                color = NexusTextSecondary,
                                fontFamily = InterFontFamily
                            )
                        }
                    }

                    Text(
                        text = codeBody,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 12.5.sp,
                        color = NexusTextPrimary,
                        lineHeight = 19.sp,
                        modifier = Modifier
                            .horizontalScroll(rememberScrollState())
                            .padding(12.dp)
                    )
                }
            }
        } else {
            if (part.isNotBlank()) {
                val annotated = remember(part) { parseInlineMarkdown(part.trim()) }
                Text(
                    text = annotated,
                    color = NexusTextPrimary,
                    fontFamily = InterFontFamily,
                    fontSize = 15.5.sp,
                    lineHeight = 23.sp
                )
            }
        }
    }
}

private fun parseInlineMarkdown(rawText: String): AnnotatedString {
    return buildAnnotatedString {
        val lines = rawText.lines()
        lines.forEachIndexed { lineIdx, rawLine ->
            val trimmed = rawLine.trimStart()
            when {
                trimmed.startsWith("### ") -> {
                    withStyle(
                        SpanStyle(
                            color = NexusTextPrimary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 16.sp,
                            fontFamily = SpaceGroteskFontFamily
                        )
                    ) {
                        appendInlineStyles(trimmed.removePrefix("### "))
                    }
                }
                trimmed.startsWith("## ") -> {
                    withStyle(
                        SpanStyle(
                            color = NexusTextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            fontFamily = SpaceGroteskFontFamily
                        )
                    ) {
                        appendInlineStyles(trimmed.removePrefix("## "))
                    }
                }
                trimmed.startsWith("# ") -> {
                    withStyle(
                        SpanStyle(
                            color = NexusVioletLight,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            fontFamily = SpaceGroteskFontFamily
                        )
                    ) {
                        appendInlineStyles(trimmed.removePrefix("# "))
                    }
                }
                trimmed.startsWith("- ") || trimmed.startsWith("* ") -> {
                    withStyle(SpanStyle(color = NexusCyan, fontWeight = FontWeight.Bold)) {
                        append("  •  ")
                    }
                    appendInlineStyles(trimmed.drop(2))
                }
                else -> {
                    appendInlineStyles(rawLine)
                }
            }
            if (lineIdx < lines.lastIndex) {
                append("\n")
            }
        }
    }
}

private fun AnnotatedString.Builder.appendInlineStyles(text: String) {
    var i = 0
    while (i < text.length) {
        when {
            text.startsWith("**", i) -> {
                val end = text.indexOf("**", i + 2)
                if (end != -1) {
                    withStyle(SpanStyle(fontWeight = FontWeight.SemiBold, color = NexusTextPrimary)) {
                        append(text.substring(i + 2, end))
                    }
                    i = end + 2
                } else {
                    append(text[i])
                    i++
                }
            }
            text[i] == '`' -> {
                val end = text.indexOf('`', i + 1)
                if (end != -1) {
                    withStyle(
                        SpanStyle(
                            fontFamily = JetBrainsMonoFontFamily,
                            background = NexusSurfaceVariant,
                            color = NexusVioletLight,
                            fontSize = 13.5.sp
                        )
                    ) {
                        append(" ${text.substring(i + 1, end)} ")
                    }
                    i = end + 1
                } else {
                    append(text[i])
                    i++
                }
            }
            text[i] == '*' && (i + 1 < text.length && text[i + 1] != '*') -> {
                val end = text.indexOf('*', i + 1)
                if (end != -1 && end > i + 1) {
                    withStyle(SpanStyle(fontStyle = FontStyle.Italic, color = NexusTextSecondary)) {
                        append(text.substring(i + 1, end))
                    }
                    i = end + 1
                } else {
                    append(text[i])
                    i++
                }
            }
            else -> {
                append(text[i])
                i++
            }
        }
    }
}
