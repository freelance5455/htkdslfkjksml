package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ChatMessage
import com.example.data.model.MessageRole
import com.example.ui.theme.InterFontFamily
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NexusBackground
import com.example.ui.theme.NexusBorder
import com.example.ui.theme.NexusCodeBackground
import com.example.ui.theme.NexusCyan
import com.example.ui.theme.NexusCyanDark
import com.example.ui.theme.NexusEmerald
import com.example.ui.theme.NexusEmeraldDim
import com.example.ui.theme.NexusSurface
import com.example.ui.theme.NexusSurfaceElevated
import com.example.ui.theme.NexusSurfaceVariant
import com.example.ui.theme.NexusTextPrimary
import com.example.ui.theme.NexusTextSecondary
import com.example.ui.theme.NexusTextTertiary
import com.example.ui.theme.NexusVioletLight
import com.example.ui.theme.SpaceGroteskFontFamily
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MessageBubble(
    message: ChatMessage,
    assistantName: String,
    onSpeakClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isUser = message.role == MessageRole.USER
    val isSystem = message.role == MessageRole.SYSTEM

    if (isSystem) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = message.content,
                color = NexusTextTertiary,
                fontSize = 12.sp,
                modifier = Modifier
                    .background(NexusSurfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 12.dp, vertical = 4.dp)
            )
        }
        return
    }

    val bubbleAlignment = if (isUser) Alignment.End else Alignment.Start
    val bubbleBackground = if (isUser) NexusSurfaceElevated else NexusSurface
    val bubbleBorder = if (isUser) NexusCyan.copy(alpha = 0.35f) else NexusBorder

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalAlignment = bubbleAlignment
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(if (isUser) 0.88f else 0.95f),
            horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
        ) {
            if (!isUser) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(NexusCyanDark)
                        .border(1.dp, NexusCyan.copy(alpha = 0.5f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = "Nexus Avatar",
                        tint = NexusCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
            }

            Column(modifier = Modifier.weight(1f, fill = false)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(bottom = 4.dp)
                ) {
                    Text(
                        text = if (isUser) "Вы" else assistantName,
                        color = if (isUser) NexusCyan else NexusTextPrimary,
                        fontSize = 12.sp,
                        fontFamily = SpaceGroteskFontFamily,
                        fontWeight = FontWeight.SemiBold
                    )

                    if (!isUser) {
                        Spacer(modifier = Modifier.width(6.dp))
                        val isOffline = message.engineUsed.contains("On-Device", ignoreCase = true) ||
                            message.engineUsed.contains("Local", ignoreCase = true) ||
                            message.engineUsed.contains("Офлайн", ignoreCase = true)

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .background(
                                    if (isOffline) NexusEmeraldDim.copy(alpha = 0.3f) else NexusCyanDark.copy(alpha = 0.45f),
                                    RoundedCornerShape(6.dp)
                                )
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Icon(
                                imageVector = if (isOffline) Icons.Default.Memory else Icons.Default.Cloud,
                                contentDescription = null,
                                tint = if (isOffline) NexusEmerald else NexusCyan,
                                modifier = Modifier.size(10.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = if (isOffline) "ОФЛАЙН (G100)" else "OMNI-AI • СЕТЬ",
                                fontSize = 9.sp,
                                fontFamily = JetBrainsMonoFontFamily,
                                fontWeight = FontWeight.Bold,
                                color = if (isOffline) NexusEmerald else NexusCyan
                            )
                        }

                        if (message.latencyMs > 0) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${message.latencyMs}мс",
                                fontSize = 10.sp,
                                fontFamily = JetBrainsMonoFontFamily,
                                color = NexusTextTertiary
                            )
                        }
                    }
                }

                Surface(
                    shape = RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (isUser) 16.dp else 4.dp,
                        bottomEnd = if (isUser) 4.dp else 16.dp
                    ),
                    color = bubbleBackground,
                    border = androidx.compose.foundation.BorderStroke(1.dp, bubbleBorder),
                    modifier = Modifier.testTag(if (isUser) "user_message_bubble" else "assistant_message_bubble")
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        RenderFormattedMarkdown(
                            content = message.content,
                            onCopyCode = { code ->
                                copyToClipboard(context, code, "Код скопирован")
                            }
                        )

                        if (!isUser && !message.isStreaming && message.content.isNotBlank()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val timeFormat = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
                                Text(
                                    text = timeFormat.format(Date(message.timestamp)),
                                    fontSize = 10.sp,
                                    fontFamily = JetBrainsMonoFontFamily,
                                    color = NexusTextTertiary
                                )
                                Spacer(modifier = Modifier.width(8.dp))

                                IconButton(
                                    onClick = { onSpeakClick(message.content) },
                                    modifier = Modifier.size(32.dp).testTag("speak_message_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.VolumeUp,
                                        contentDescription = "Озвучить",
                                        tint = NexusCyan,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }

                                IconButton(
                                    onClick = { copyToClipboard(context, message.content, "Текст скопирован") },
                                    modifier = Modifier.size(32.dp).testTag("copy_message_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ContentCopy,
                                        contentDescription = "Копировать",
                                        tint = NexusTextSecondary,
                                        modifier = Modifier.size(15.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            if (isUser) {
                Spacer(modifier = Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(NexusSurfaceVariant)
                        .border(1.dp, NexusBorder, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = "User Avatar",
                        tint = NexusCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

private fun copyToClipboard(context: Context, text: String, toastMsg: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText("Nexus Content", text)
    clipboard.setPrimaryClip(clip)
    Toast.makeText(context, toastMsg, Toast.LENGTH_SHORT).show()
}

@Composable
private fun RenderFormattedMarkdown(
    content: String,
    onCopyCode: (String) -> Unit
) {
    val parts = remember(content) { content.split("```") }
    parts.forEachIndexed { index, part ->
        if (index % 2 == 1) {
            val lines = part.trim().lines()
            val firstLine = lines.firstOrNull()?.trim().orEmpty()
            val hasLang = firstLine.isNotEmpty() && firstLine.length <= 16 && !firstLine.contains(" ")
            val lang = if (hasLang) firstLine else "code"
            val codeBody = if (hasLang) lines.drop(1).joinToString("\n") else part.trim()

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(NexusCodeBackground)
                    .border(1.dp, NexusBorder, RoundedCornerShape(10.dp))
            ) {
                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(NexusSurfaceVariant.copy(alpha = 0.6f))
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = lang.uppercase(),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = NexusCyan,
                            fontFamily = JetBrainsMonoFontFamily
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .clickable { onCopyCode(codeBody) }
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Копировать код",
                                tint = NexusTextSecondary,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Копировать",
                                fontSize = 10.sp,
                                color = NexusTextSecondary,
                                fontFamily = InterFontFamily
                            )
                        }
                    }

                    Text(
                        text = codeBody,
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = 12.sp,
                        color = NexusTextPrimary,
                        lineHeight = 18.sp,
                        modifier = Modifier
                            .horizontalScroll(rememberScrollState())
                            .padding(10.dp)
                    )
                }
            }
        } else {
            if (part.isNotBlank()) {
                val annotated = remember(part) { parseInlineMarkdown(part.trim()) }
                Text(
                    text = annotated,
                    color = NexusTextPrimary,
                    fontFamily = InterFontFamily,
                    fontSize = 14.sp,
                    lineHeight = 21.sp
                )
            }
        }
    }
}

private fun parseInlineMarkdown(rawText: String): AnnotatedString {
    return buildAnnotatedString {
        val lines = rawText.lines()
        lines.forEachIndexed { lineIdx, rawLine ->
            val trimmed = rawLine.trimStart()
            when {
                trimmed.startsWith("### ") -> {
                    withStyle(
                        SpanStyle(
                            color = NexusCyan,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            fontFamily = SpaceGroteskFontFamily
                        )
                    ) {
                        appendInlineStyles(trimmed.removePrefix("### "))
                    }
                }
                trimmed.startsWith("## ") -> {
                    withStyle(
                        SpanStyle(
                            color = NexusCyan,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            fontFamily = SpaceGroteskFontFamily
                        )
                    ) {
                        appendInlineStyles(trimmed.removePrefix("## "))
                    }
                }
                trimmed.startsWith("# ") -> {
                    withStyle(
                        SpanStyle(
                            color = NexusVioletLight,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            fontFamily = SpaceGroteskFontFamily
                        )
                    ) {
                        appendInlineStyles(trimmed.removePrefix("# "))
                    }
                }
                trimmed.startsWith("- ") || trimmed.startsWith("* ") -> {
                    withStyle(SpanStyle(color = NexusCyan, fontWeight = FontWeight.Bold)) {
                        append("  •  ")
                    }
                    appendInlineStyles(trimmed.drop(2))
                }
                else -> {
                    appendInlineStyles(rawLine)
                }
            }
            if (lineIdx < lines.lastIndex) {
                append("\n")
            }
        }
    }
}

private fun AnnotatedString.Builder.appendInlineStyles(text: String) {
    var i = 0
    while (i < text.length) {
        when {
            text.startsWith("**", i) -> {
                val end = text.indexOf("**", i + 2)
                if (end != -1) {
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = NexusTextPrimary)) {
                        append(text.substring(i + 2, end))
                    }
                    i = end + 2
                } else {
                    append(text[i])
                    i++
                }
            }
            text[i] == '`' -> {
                val end = text.indexOf('`', i + 1)
                if (end != -1) {
                    withStyle(
                        SpanStyle(
                            fontFamily = JetBrainsMonoFontFamily,
                            background = NexusBackground,
                            color = NexusCyan,
                            fontSize = 13.sp
                        )
                    ) {
                        append(" ${text.substring(i + 1, end)} ")
                    }
                    i = end + 1
                } else {
                    append(text[i])
                    i++
                }
            }
            text[i] == '*' && (i + 1 < text.length && text[i + 1] != '*') -> {
                val end = text.indexOf('*', i + 1)
                if (end != -1 && end > i + 1) {
                    withStyle(SpanStyle(fontStyle = FontStyle.Italic, color = NexusTextSecondary)) {
                        append(text.substring(i + 1, end))
                    }
                    i = end + 1
                } else {
                    append(text[i])
                    i++
                }
            }
            else -> {
                append(text[i])
                i++
            }
        }
    }
}
