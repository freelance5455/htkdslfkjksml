package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.example.ui.screens.pdf.PdfGalleryViewer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.data.db.PdfDocumentRecord
import com.example.data.repository.VaultRepository
import com.example.ui.components.SilverButton
import com.example.ui.components.SlantedShape
import com.example.ui.components.TopBarWithClose
import com.example.ui.theme.AccentRed
import com.example.ui.theme.BlackCharcoal
import com.example.ui.theme.BlackPure
import com.example.ui.theme.SilverDark
import com.example.ui.theme.SilverLight
import com.example.ui.theme.SilverSurface
import com.example.ui.theme.SilverSurfaceVariant
import com.example.util.PdfDocumentHolder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ViewPdfScreen(
    repository: VaultRepository,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val pdfList by repository.allPdfs.collectAsState(initial = emptyList())
    var selectedPdf by remember { mutableStateOf<PdfDocumentRecord?>(null) }
    var pdfToDelete by remember { mutableStateOf<PdfDocumentRecord?>(null) }

    // External PDF importer
    val pdfPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                try {
                    val imported = repository.importFile(uri, "Documents")
                    val file = File(imported.filePath)
                    // Check page count with PdfDocumentHolder
                    var pages = 1
                    try {
                        PdfDocumentHolder(file).use { holder ->
                            pages = holder.pageCount
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                    repository.registerPdf(
                        title = file.nameWithoutExtension,
                        file = file,
                        pageCount = pages
                    )
                    Toast.makeText(context, "PDF imported successfully into vault", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(context, "Error importing PDF: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    if (selectedPdf != null) {
        // Full screen Gallery PDF Viewer
        PdfGalleryViewer(
            pdf = selectedPdf!!,
            onCloseViewer = { selectedPdf = null }
        )
    } else {
        // PDF Library List
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(SilverLight)
        ) {
            // Mandatory X button at top
            TopBarWithClose(
                title = "View PDF Files",
                subtitle = "Gallery & Fullscreen Reader",
                onCloseClick = onBack
            )

            // Import PDF action bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                SilverButton(
                    text = "Import PDF Document",
                    icon = Icons.Default.UploadFile,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_import_external_pdf"),
                    onClick = {
                        pdfPicker.launch(arrayOf("application/pdf"))
                    }
                )
            }

            if (pdfList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(SlantedShape)
                                .background(SilverSurface)
                                .border(BorderStroke(1.5.dp, BlackPure), SlantedShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PictureAsPdf,
                                contentDescription = null,
                                tint = BlackPure,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "No PDF Files Found",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = BlackPure
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Create a new PDF or import existing PDF documents into YM Secret to read them with horizontal gallery swiping.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = SilverDark,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(pdfList, key = { it.id }) { pdfRecord ->
                        PdfRecordCard(
                            pdf = pdfRecord,
                            onOpen = { selectedPdf = pdfRecord },
                            onShare = {
                                val file = File(pdfRecord.filePath)
                                if (file.exists()) {
                                    val uri = FileProvider.getUriForFile(
                                        context,
                                        "${context.packageName}.fileprovider",
                                        file
                                    )
                                    val intent = Intent(Intent.ACTION_SEND).apply {
                                        type = "application/pdf"
                                        putExtra(Intent.EXTRA_STREAM, uri)
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(Intent.createChooser(intent, "Share PDF"))
                                }
                            },
                            onDelete = { pdfToDelete = pdfRecord }
                        )
                    }
                }
            }
        }
    }

    // Delete Confirmation Dialog
    pdfToDelete?.let { pdf ->
        AlertDialog(
            onDismissRequest = { pdfToDelete = null },
            title = {
                Text(
                    text = "Delete PDF Document?",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = BlackPure
                )
            },
            text = {
                Text(
                    text = "Are you sure you want to remove \"${pdf.title}\" from your offline vault?",
                    style = MaterialTheme.typography.bodyMedium,
                    color = BlackCharcoal
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        scope.launch {
                            repository.deletePdf(pdf)
                            pdfToDelete = null
                        }
                    }
                ) {
                    Text("Delete", color = AccentRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { pdfToDelete = null }) {
                    Text("Cancel", color = SilverDark)
                }
            },
            containerColor = SilverLight,
            shape = SlantedShape
        )
    }
}

@Composable
fun PdfRecordCard(
    pdf: PdfDocumentRecord,
    onOpen: () -> Unit,
    onShare: () -> Unit,
    onDelete: () -> Unit
) {
    val formattedDate = remember(pdf.createdAt) {
        val sdf = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())
        sdf.format(Date(pdf.createdAt))
    }
    val formattedSize = remember(pdf.sizeBytes) {
        formatBytes(pdf.sizeBytes)
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(SlantedShape)
            .background(SilverSurface)
            .border(BorderStroke(1.2.dp, BlackPure), SlantedShape)
            .clickable { onOpen() }
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(SlantedShape)
                    .background(SilverSurfaceVariant)
                    .border(BorderStroke(1.dp, BlackPure), SlantedShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PictureAsPdf,
                    contentDescription = null,
                    tint = BlackPure,
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = pdf.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = BlackPure,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "${pdf.pageCount} ${if (pdf.pageCount == 1) "page" else "pages"} • $formattedSize",
                    style = MaterialTheme.typography.labelSmall,
                    color = SilverDark,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = formattedDate,
                    style = MaterialTheme.typography.labelSmall,
                    color = SilverDark
                )
            }

            IconButton(onClick = onShare) {
                Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = "Share",
                    tint = BlackPure,
                    modifier = Modifier.size(20.dp)
                )
            }

            IconButton(onClick = onDelete) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete",
                    tint = AccentRed,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

