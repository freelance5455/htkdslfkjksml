package com.example.ui.screens.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.OperationalDisclaimerCard
import com.example.ui.navigation.Screen
import com.example.ui.theme.StatusYellow
import com.example.ui.viewmodel.WeatherViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
  viewModel: WeatherViewModel,
  onNavigateTo: (Screen) -> Unit,
  modifier: Modifier = Modifier
) {
  val settings by viewModel.appSettings.collectAsState()
  val favorites by viewModel.favorites.collectAsState()

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp)
      .testTag("settings_screen"),
    verticalArrangement = Arrangement.spacedBy(14.dp),
    contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
  ) {
    item {
      Text(
        text = "تنظیمات سامانه (Application Settings)",
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
      )
    }

    // Daylight Aviation Console Info Card
    item {
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.LightMode, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "پوسته دیده‌بان مراقبت پرواز (Daylight Aviation Theme)",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold
            )
          }
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "رابط کاربری استاندارد با پس‌زمینه آبی آسمانی، کارت‌های تفکیک‌شده رنگی و کنتراست ارگونومیک، جهت کاهش خستگی چشم کنترلر و افزایش سرعت تصمیم‌گیری در شیفت‌های عملیاتی فعال است.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }

    // Units
    item {
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Text(text = "واحدهای استاندارد هوانوردی", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.height(8.dp))

          // Wind Speed
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("واحد سرعت باد (Wind Unit)")
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
              FilterChip(selected = settings.windSpeedUnit == "KT", onClick = { viewModel.setWindUnit("KT") }, label = { Text("KT (گره)") })
              FilterChip(selected = settings.windSpeedUnit == "MPS", onClick = { viewModel.setWindUnit("MPS") }, label = { Text("m/s") })
            }
          }

          Divider(modifier = Modifier.padding(vertical = 8.dp))

          // Pressure
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("واحد فشار جوی (Altimeter)")
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
              FilterChip(selected = settings.pressureUnit == "hPa", onClick = { viewModel.setPressureUnit("hPa") }, label = { Text("hPa / QNH") })
              FilterChip(selected = settings.pressureUnit == "inHg", onClick = { viewModel.setPressureUnit("inHg") }, label = { Text("inHg") })
            }
          }

          Divider(modifier = Modifier.padding(vertical = 8.dp))

          // Time Display
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text("نمایش ساعت محلی در کنار UTC")
              Text("ساعت رسمی پیام‌ها همواره UTC می‌باشد", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(
              checked = settings.showLocalTimeAlongsideUtc,
              onCheckedChange = { viewModel.setShowLocalTime(it) }
            )
          }
        }
      }
    }

    // Auto-refresh interval
    item {
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Text(text = "فاصله زمانی به‌روزرسانی خودکار", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.height(8.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            FilterChip(selected = settings.autoRefreshMinutes == 5, onClick = { viewModel.setRefreshInterval(5) }, label = { Text("۵ دقیقه") })
            FilterChip(selected = settings.autoRefreshMinutes == 15, onClick = { viewModel.setRefreshInterval(15) }, label = { Text("۱۵ دقیقه") })
            FilterChip(selected = settings.autoRefreshMinutes == 30, onClick = { viewModel.setRefreshInterval(30) }, label = { Text("۳۰ دقیقه") })
            FilterChip(selected = settings.autoRefreshMinutes == 0, onClick = { viewModel.setRefreshInterval(0) }, label = { Text("فقط دستی") })
          }
        }
      }
    }

    // Favorites Management
    item {
      Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Text(
            text = "مدیریت فرودگاه‌های برگزیده (${favorites.size} فرودگاه)",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.height(8.dp))
          if (favorites.isEmpty()) {
            Text("هیچ فرودگاهی در لیست برگزیده‌ها قرار ندارد.", style = MaterialTheme.typography.bodySmall)
          } else {
            favorites.forEach { apt ->
              Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(text = "${apt.icao} • ${apt.nameFa}", style = MaterialTheme.typography.bodyMedium)
                IconButton(onClick = { viewModel.toggleFavorite(apt.icao) }) {
                  Icon(Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
                }
              }
              Divider()
            }
          }
        }
      }
    }

    // Shortcut to Data Sources Status
    item {
      Button(
        onClick = { onNavigateTo(Screen.ABOUT) },
        modifier = Modifier.fillMaxWidth()
      ) {
        Text("بررسی وضعیت اتصالات و منابع داده (Data Sources Status)")
      }
    }

    item { OperationalDisclaimerCard() }
  }
}
