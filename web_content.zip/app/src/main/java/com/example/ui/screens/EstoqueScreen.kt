package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.PostAdd
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Perfume
import com.example.data.model.ProdutoAgrupado
import com.example.ui.theme.RosePrimary
import com.example.ui.theme.StatusExpired
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning
import com.example.ui.viewmodel.StockFilter
import com.example.util.CurrencyUtil
import com.example.util.ValidadeUtil

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EstoqueScreen(
    produtosAgrupados: List<ProdutoAgrupado>,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    selectedFilter: StockFilter,
    onFilterChange: (StockFilter) -> Unit,
    onNovoLoteParaProduto: (codigo: String) -> Unit,
    onEditLote: (Perfume) -> Unit,
    onDeleteLote: (Long) -> Unit,
    onAdjustStockLote: (Long, Int) -> Unit,
    onResetDefaults: () -> Unit
) {
    var loteToDelete by remember { mutableStateOf<Perfume?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchChange,
            placeholder = { Text("Buscar por perfume, marca ou código EAN...", fontSize = 13.sp) },
            leadingIcon = {
                Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            },
            trailingIcon = {
                if (searchQuery.isNotBlank()) {
                    IconButton(onClick = { onSearchChange("") }) {
                        Icon(Icons.Default.Clear, contentDescription = "Limpar busca")
                    }
                }
            },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("search_perfumes_input"),
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Filter Chips
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StockFilter.values().forEach { filter ->
                FilterChip(
                    selected = selectedFilter == filter,
                    onClick = { onFilterChange(filter) },
                    label = { Text(filter.label, fontSize = 11.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = RosePrimary,
                        selectedLabelColor = Color.White
                    ),
                    modifier = Modifier.testTag("filter_chip_${filter.name.lowercase()}")
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Inventory Metrics Banner (Total de itens somados e valor)
        val totalProdutosDistintos = produtosAgrupados.size
        val totalUnidadesSomadas = produtosAgrupados.sumOf { it.estoqueTotal }
        val valorTotalEstoque = produtosAgrupados.sumOf { it.precoVenda * it.estoqueTotal }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "TOTAL NO ESTOQUE (SOMADO)",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "$totalUnidadesSomadas un. ($totalProdutosDistintos produtos)",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "VALOR ESTIMADO",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = CurrencyUtil.formatarMoeda(valorTotalEstoque),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = RosePrimary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // List of Grouped Products
        if (produtosAgrupados.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Inventory2,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Nenhum perfume encontrado",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Tente ajustar a busca ou cadastre um novo produto/lote.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = onResetDefaults,
                        colors = ButtonDefaults.buttonColors(containerColor = RosePrimary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("btn_reset_sample_data")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Carregar Perfumes de Exemplo")
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(produtosAgrupados, key = { it.codigo }) { produto ->
                    ProdutoAgrupadoCard(
                        produto = produto,
                        onNovoLote = { onNovoLoteParaProduto(produto.codigo) },
                        onEditLote = onEditLote,
                        onDeleteLote = { lote -> loteToDelete = lote },
                        onAdjustStock = onAdjustStockLote
                    )
                }
                item {
                    Spacer(modifier = Modifier.height(80.dp))
                }
            }
        }
    }

    // Delete Confirmation Dialog for Batch/Lot
    loteToDelete?.let { lote ->
        AlertDialog(
            onDismissRequest = { loteToDelete = null },
            title = { Text("Excluir Lote") },
            text = {
                Text(
                    "Deseja realmente remover o lote de validade '${lote.validade}' (${lote.estoque} un.) de '${lote.nome}'?"
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteLote(lote.id)
                        loteToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusExpired),
                    modifier = Modifier.testTag("confirm_delete_lote_button")
                ) {
                    Text("Excluir Lote")
                }
            },
            dismissButton = {
                TextButton(onClick = { loteToDelete = null }) {
                    Text("Cancelar")
                }
            }
        )
    }
}

@Composable
fun ProdutoAgrupadoCard(
    produto: ProdutoAgrupado,
    onNovoLote: () -> Unit,
    onEditLote: (Perfume) -> Unit,
    onDeleteLote: (Perfume) -> Unit,
    onAdjustStock: (Long, Int) -> Unit
) {
    var isExpanded by remember { mutableStateOf(false) }
    val isLowStock = produto.estoqueTotal <= 2
    val maisCritico = produto.statusMaisCritico

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("produto_card_${produto.codigo}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // EAN & Critial Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.QrCode,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = produto.codigo,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                maisCritico?.let { crit ->
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = crit.corFundo
                    ) {
                        Text(
                            text = "Próx. Venc: ${crit.formatadaBr} (${crit.label})",
                            color = crit.corTexto,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Nome e Marca
            Text(
                text = produto.nome,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = produto.marca,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Preço de venda e QUANTIDADE SOMADA TOTAL
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = CurrencyUtil.formatarMoeda(produto.precoVenda),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 16.sp,
                        color = RosePrimary
                    )
                    Text(
                        text = "Custo: ${CurrencyUtil.formatarMoeda(produto.custo)}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Estoque Total Somado Badge
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isLowStock) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f)
                    else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Estoque Total: ",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${produto.estoqueTotal} un.",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 13.sp,
                            color = if (isLowStock) StatusExpired else RosePrimary
                        )
                        Text(
                            text = " (${produto.totalLotes} ${if (produto.totalLotes == 1) "lote" else "lotes"})",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
            Spacer(modifier = Modifier.height(6.dp))

            // Actions row: Add new batch or expand lot list
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Button to add another lot with new expiration for this product
                TextButton(
                    onClick = onNovoLote,
                    modifier = Modifier.testTag("btn_novo_lote_${produto.codigo}")
                ) {
                    Icon(Icons.Default.PostAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Adicionar Lote", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }

                // Toggle Accordion to see individual lots
                TextButton(
                    onClick = { isExpanded = !isExpanded },
                    modifier = Modifier.testTag("btn_toggle_lotes_${produto.codigo}")
                ) {
                    Text(
                        text = if (isExpanded) "Ocultar Lotes" else "Ver Lotes (${produto.totalLotes})",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = RosePrimary
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null,
                        tint = RosePrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Expanded Lots List
            AnimatedVisibility(visible = isExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                        .padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Lotes & Validades Cadastradas:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    produto.lotes.forEach { lote ->
                        LoteItemRow(
                            lote = lote,
                            onEdit = { onEditLote(lote) },
                            onDelete = { onDeleteLote(lote) },
                            onIncrement = { onAdjustStock(lote.id, 1) },
                            onDecrement = { onAdjustStock(lote.id, -1) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LoteItemRow(
    lote: Perfume,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onIncrement: () -> Unit,
    onDecrement: () -> Unit
) {
    val valInfo = remember(lote.validade) { ValidadeUtil.calcularValidade(lote.validade) }

    Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (lote.numeroLote.isNotBlank()) {
                        Text(
                            text = "${lote.numeroLote} • ",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Text(
                        text = "Validade: ${valInfo.formatadaBr}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = valInfo.corTexto
                    )
                }
                Text(
                    text = valInfo.label,
                    fontSize = 10.sp,
                    color = valInfo.corTexto,
                    fontWeight = FontWeight.Medium
                )
            }

            // Stepper for lot stock
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(6.dp))
                    .padding(horizontal = 2.dp)
            ) {
                IconButton(onClick = onDecrement, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.Remove, contentDescription = "Diminuir", modifier = Modifier.size(12.dp))
                }
                Text(
                    text = "${lote.estoque} un.",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (lote.estoque <= 0) StatusExpired else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                IconButton(onClick = onIncrement, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.Add, contentDescription = "Aumentar", modifier = Modifier.size(12.dp))
                }
            }

            // Edit / Delete Lot
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onEdit, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Edit, contentDescription = "Editar Lote", modifier = Modifier.size(14.dp))
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                    Icon(
                        Icons.Default.DeleteOutline,
                        contentDescription = "Excluir Lote",
                        tint = StatusExpired,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}
