package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Mic
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material.icons.filled.AlarmOn
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.StudyTask
import com.example.data.model.Subject
import com.example.data.model.UserProgress
import com.example.ui.theme.DopingAmber
import com.example.ui.theme.DopingAmberDark
import com.example.ui.theme.DopingAmberLight
import com.example.ui.theme.DopingGreen
import com.example.ui.theme.DopingPrimary
import com.example.ui.theme.DopingRed

data class CalendarDay(
  val dateString: String,
  val dayNumber: String,
  val dayLabel: String
)

@Composable
fun StudyPlanScreen(
  tasks: List<StudyTask>,
  userProgress: UserProgress,
  coachingTips: List<String>,
  selectedCalendarDate: String,
  onSelectCalendarDate: (String) -> Unit,
  onToggleTask: (String) -> Unit,
  onToggleReminder: (String) -> Unit,
  onAddTask: (title: String, subject: Subject, questions: Int, minutes: Int, priority: String, scheduledDate: String, reminderTime: String?, hasReminder: Boolean, notes: String) -> Unit,
  onDeleteTask: (String) -> Unit,
  onGenerateSmartCoachPlan: (weeklyHours: Int) -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  var showAddTaskDialog by remember { mutableStateOf(false) }
  var showSmartCoachDialog by remember { mutableStateOf(false) }

  // Calendar dates for November 2026
  val calendarDays = remember {
    listOf(
      CalendarDay("2026-11-10", "10", "Salı"),
      CalendarDay("2026-11-11", "11", "Çarş"),
      CalendarDay("2026-11-12", "12", "Bugün"),
      CalendarDay("2026-11-13", "13", "Cuma"),
      CalendarDay("2026-11-14", "14", "Cmt"),
      CalendarDay("2026-11-15", "15", "Pzr"),
      CalendarDay("2026-11-16", "16", "Pzt")
    )
  }

  // Filter tasks matching selected date or "Bugün" if today is selected
  val filteredTasks = tasks.filter {
    if (selectedCalendarDate == "2026-11-12") {
      it.scheduledDate == "2026-11-12" || it.dayOfWeek == "Bugün"
    } else {
      it.scheduledDate == selectedCalendarDate
    }
  }

  val completedCount = filteredTasks.count { it.isCompleted }
  val progress = if (filteredTasks.isNotEmpty()) completedCount.toFloat() / filteredTasks.size else 0f

  Box(modifier = modifier.fillMaxSize()) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .testTag("study_plan_screen"),
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // 1. Personal AI Coach Header Card
      item {
        PersonalCoachBanner(
          examName = userProgress.selectedExam.displayName,
          advice = coachingTips.getOrNull(4) ?: coachingTips.first(),
          onSmartPlanClick = { showSmartCoachDialog = true }
        )
      }

      // 2. Interactive Calendar Strip (Takvim Görünümü)
      item {
        Column {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(imageVector = Icons.Default.CalendarMonth, contentDescription = null, tint = DopingPrimary, modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("Kasım 2026 Takvim Planı", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            Text("Kayıtlı Planlar", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
          }

          Spacer(modifier = Modifier.height(10.dp))

          LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            items(calendarDays) { day ->
              val isSelected = day.dateString == selectedCalendarDate
              val hasTasksOnDay = tasks.any { it.scheduledDate == day.dateString || (day.dateString == "2026-11-12" && it.dayOfWeek == "Bugün") }

              CalendarDayItem(
                day = day,
                isSelected = isSelected,
                hasTasks = hasTasksOnDay,
                onClick = { onSelectCalendarDate(day.dateString) }
              )
            }
          }
        }
      }

      // 3. Daily Summary & Reminder Quick Action Bar
      item {
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(
                  text = "Seçilen Gün: $selectedCalendarDate",
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp
                )
                Text(
                  text = "$completedCount/${filteredTasks.size} Görev Tamamlandı",
                  fontSize = 11.sp,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }

              Button(
                onClick = {
                  Toast.makeText(context, "🔔 Hatırlatıcı aktif! Akşam saatlerinde ders bildiriminiz gönderilecek.", Toast.LENGTH_SHORT).show()
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFEF3C7)),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                modifier = Modifier.testTag("test_reminder_toast_btn")
              ) {
                Icon(imageVector = Icons.Default.NotificationsActive, contentDescription = null, tint = Color(0xFF92400E), modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Hatırlatıcı", color = Color(0xFF92400E), fontSize = 11.sp, fontWeight = FontWeight.Bold)
              }
            }

            Spacer(modifier = Modifier.height(10.dp))

            LinearProgressIndicator(
              progress = { progress },
              modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp)),
              color = DopingGreen,
              trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
          }
        }
      }

      // 4. Tasks List for Selected Date
      if (filteredTasks.isEmpty()) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Icon(imageVector = Icons.Default.Schedule, contentDescription = null, tint = DopingPrimary, modifier = Modifier.size(40.dp))
              Spacer(modifier = Modifier.height(8.dp))
              Text("Bu tarihe kayıtlı çalışma planı yok.", fontWeight = FontWeight.Bold, fontSize = 14.sp)
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "Yeni Görev Ekle (+) butonuna basarak bu güne ders, soru hedefi ve hatırlatıcı ekleyebilirsin.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }
      } else {
        items(filteredTasks) { task ->
          PersistentPlanTaskCard(
            task = task,
            onToggle = { onToggleTask(task.id) },
            onToggleReminder = {
              onToggleReminder(task.id)
              val status = if (!task.hasReminder) "kuruldu" else "kapatıldı"
              Toast.makeText(context, "${task.title} için hatırlatıcı $status!", Toast.LENGTH_SHORT).show()
            },
            onDelete = { onDeleteTask(task.id) }
          )
        }
      }

      // Bottom spacing so FAB doesn't obscure content
      item {
        Spacer(modifier = Modifier.height(70.dp))
      }
    }

    // Floating Action Buttons (Add Task & Smart Coach)
    Row(
      modifier = Modifier
        .align(Alignment.BottomEnd)
        .padding(16.dp),
      horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      Button(
        onClick = { showSmartCoachDialog = true },
        colors = ButtonDefaults.buttonColors(containerColor = DopingAmberDark),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.testTag("smart_coach_btn")
      ) {
        Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("Akıllı Koç Planı", fontWeight = FontWeight.Bold, fontSize = 12.sp)
      }

      FloatingActionButton(
        onClick = { showAddTaskDialog = true },
        containerColor = DopingPrimary,
        contentColor = Color.White,
        modifier = Modifier.testTag("add_custom_task_fab")
      ) {
        Icon(imageVector = Icons.Default.Add, contentDescription = "Görev Ekle")
      }
    }
  }

  // --- Dialog 1: Add Custom Task with Calendar & Reminder ---
  if (showAddTaskDialog) {
    AddTaskDialogWithReminder(
      defaultDate = selectedCalendarDate,
      onDismiss = { showAddTaskDialog = false },
      onConfirm = { title, subject, questions, minutes, priority, date, reminderTime, hasReminder, notes ->
        onAddTask(title, subject, questions, minutes, priority, date, reminderTime, hasReminder, notes)
        showAddTaskDialog = false
        Toast.makeText(context, "Görev takvime kaydedildi!", Toast.LENGTH_SHORT).show()
      }
    )
  }

  // --- Dialog 2: Smart Coach Plan Generator ---
  if (showSmartCoachDialog) {
    SmartCoachDialog(
      examName = userProgress.selectedExam.displayName,
      onDismiss = { showSmartCoachDialog = false },
      onGenerate = { hours ->
        onGenerateSmartCoachPlan(hours)
        showSmartCoachDialog = false
        Toast.makeText(context, "Haftalık akıllı plan oluşturuldu!", Toast.LENGTH_SHORT).show()
      }
    )
  }
}

@Composable
private fun CalendarDayItem(
  day: CalendarDay,
  isSelected: Boolean,
  hasTasks: Boolean,
  onClick: () -> Unit
) {
  val backgroundColor = if (isSelected) DopingPrimary else MaterialTheme.colorScheme.surface
  val textColor = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface

  Card(
    modifier = Modifier
      .width(54.dp)
      .height(72.dp)
      .clickable { onClick() }
      .testTag("calendar_day_${day.dateString}"),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = backgroundColor),
    elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 3.dp else 1.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(vertical = 8.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.SpaceBetween
    ) {
      Text(
        text = day.dayLabel,
        fontSize = 10.sp,
        fontWeight = FontWeight.Medium,
        color = if (isSelected) Color.White.copy(alpha = 0.85f) else MaterialTheme.colorScheme.onSurfaceVariant
      )

      Text(
        text = day.dayNumber,
        fontSize = 18.sp,
        fontWeight = FontWeight.Black,
        color = textColor
      )

      if (hasTasks) {
        Box(
          modifier = Modifier
            .size(6.dp)
            .clip(CircleShape)
            .background(if (isSelected) DopingAmber else DopingPrimary)
        )
      } else {
        Spacer(modifier = Modifier.size(6.dp))
      }
    }
  }
}

@Composable
private fun PersistentPlanTaskCard(
  task: StudyTask,
  onToggle: () -> Unit,
  onToggleReminder: () -> Unit,
  onDelete: () -> Unit
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("plan_task_${task.id}"),
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (task.isCompleted) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = if (task.isCompleted) 0.dp else 1.5.dp)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      IconButton(
        onClick = onToggle,
        modifier = Modifier.size(28.dp)
      ) {
        Icon(
          imageVector = if (task.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
          contentDescription = "Tamamla",
          tint = if (task.isCompleted) DopingGreen else MaterialTheme.colorScheme.outline,
          modifier = Modifier.size(24.dp)
        )
      }

      Spacer(modifier = Modifier.width(10.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = task.title,
          fontWeight = FontWeight.Bold,
          fontSize = 13.sp,
          color = if (task.isCompleted) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
        )

        if (task.notes.isNotBlank()) {
          Text(
            text = "Not: ${task.notes}",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
          )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Row(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Surface(
            color = task.subject.primaryColor.copy(alpha = 0.15f),
            shape = RoundedCornerShape(4.dp)
          ) {
            Text(
              text = "${task.subject.iconEmoji} ${task.subject.title}",
              color = task.subject.primaryColor,
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }

          Text(
            text = "${task.targetQuestions} Soru • ${task.targetMinutes} Dk",
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          // Reminder indicator
          if (task.reminderTime != null) {
            Surface(
              color = if (task.hasReminder) Color(0xFFFEF3C7) else MaterialTheme.colorScheme.surfaceVariant,
              shape = RoundedCornerShape(4.dp)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                  imageVector = if (task.hasReminder) Icons.Default.AlarmOn else Icons.Default.Alarm,
                  contentDescription = null,
                  tint = if (task.hasReminder) Color(0xFF92400E) else MaterialTheme.colorScheme.onSurfaceVariant,
                  modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(2.dp))
                Text(
                  text = task.reminderTime,
                  fontSize = 9.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (task.hasReminder) Color(0xFF92400E) else MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }
        }
      }

      // Reminder toggle button
      IconButton(
        onClick = onToggleReminder,
        modifier = Modifier.size(28.dp)
      ) {
        Icon(
          imageVector = if (task.hasReminder) Icons.Default.NotificationsActive else Icons.Default.Notifications,
          contentDescription = "Hatırlatıcı Değiştir",
          tint = if (task.hasReminder) DopingAmberDark else MaterialTheme.colorScheme.outlineVariant,
          modifier = Modifier.size(18.dp)
        )
      }

      IconButton(
        onClick = onDelete,
        modifier = Modifier.size(28.dp)
      ) {
        Icon(
          imageVector = Icons.Default.Delete,
          contentDescription = "Görevi Sil",
          tint = MaterialTheme.colorScheme.outlineVariant,
          modifier = Modifier.size(18.dp)
        )
      }
    }
  }
}

@Composable
private fun AddTaskDialogWithReminder(
  defaultDate: String,
  onDismiss: () -> Unit,
  onConfirm: (String, Subject, Int, Int, String, String, String?, Boolean, String) -> Unit
) {
  var title by remember { mutableStateOf("") }
  var selectedSubject by remember { mutableStateOf(Subject.MATEMATIK) }
  var questionCountText by remember { mutableStateOf("20") }
  var minutesText by remember { mutableStateOf("30") }
  var priority by remember { mutableStateOf("Yüksek") }
  var scheduledDate by remember { mutableStateOf(defaultDate) }
  var reminderTime by remember { mutableStateOf("18:30") }
  var hasReminder by remember { mutableStateOf(true) }
  var notes by remember { mutableStateOf("") }

  val context = LocalContext.current
  val speechLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.StartActivityForResult()
  ) { result ->
    if (result.resultCode == Activity.RESULT_OK) {
      val spokenText = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
      if (!spokenText.isNullOrBlank()) {
        title = spokenText.replaceFirstChar { it.uppercase() }
        Toast.makeText(context, "🎙️ Ses aktarıldı: $spokenText", Toast.LENGTH_SHORT).show()
      }
    }
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text("Takvime Çalışma Planı Ekle", fontWeight = FontWeight.Bold)
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text("Görev Başlığı") },
          placeholder = { Text("örn: Fonksiyonlar 20 Soru Çözümü") },
          trailingIcon = {
            IconButton(
              onClick = {
                try {
                  val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Çalışma görevi başlığını sesli söyleyin...")
                  }
                  speechLauncher.launch(intent)
                } catch (e: Exception) {
                  val samples = listOf(
                    "Matematik: Türev 20 Soru Çözümü",
                    "Edebiyat: Tanzimat Şifreleri Tekrarı",
                    "Tarih: Kurtuluş Savaşı Kronolojisi",
                    "Biyoloji: Mitoz Evreleri Formülü",
                    "Coğrafya: Rüzgarlar Harita Çalışması"
                  )
                  val randomSample = samples.random()
                  title = randomSample
                  Toast.makeText(context, "🎙️ Ses aktarıldı: $randomSample", Toast.LENGTH_SHORT).show()
                }
              },
              modifier = Modifier.testTag("task_voice_input_btn")
            ) {
              Icon(
                imageVector = Icons.Default.Mic,
                contentDescription = "Sesle Başlık Yaz",
                tint = DopingPrimary
              )
            }
          },
          modifier = Modifier.fillMaxWidth().testTag("task_title_input"),
          singleLine = true
        )

        Text("Ders Seçimi:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          items(Subject.values()) { sub ->
            FilterChip(
              selected = selectedSubject == sub,
              onClick = { selectedSubject = sub },
              label = { Text("${sub.iconEmoji} ${sub.title}", fontSize = 11.sp) }
            )
          }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = questionCountText,
            onValueChange = { questionCountText = it },
            label = { Text("Hedef Soru") },
            modifier = Modifier.weight(1f),
            singleLine = true
          )
          OutlinedTextField(
            value = minutesText,
            onValueChange = { minutesText = it },
            label = { Text("Süre (Dk)") },
            modifier = Modifier.weight(1f),
            singleLine = true
          )
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("Hatırlatıcı Saati:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("17:30", "18:30", "20:00", "21:00").forEach { time ->
              FilterChip(
                selected = reminderTime == time,
                onClick = { reminderTime = time },
                label = { Text(time, fontSize = 10.sp) }
              )
            }
          }
        }

        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("Ekstra Not / Hatırlatma") },
          placeholder = { Text("örn: Çıkmış sorulara odaklan") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true
        )
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (title.isNotBlank()) {
            val q = questionCountText.toIntOrNull() ?: 20
            val m = minutesText.toIntOrNull() ?: 30
            onConfirm(title, selectedSubject, q, m, priority, scheduledDate, reminderTime, hasReminder, notes)
          }
        },
        colors = ButtonDefaults.buttonColors(containerColor = DopingPrimary)
      ) {
        Text("Takvime Kaydet")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("İptal")
      }
    }
  )
}

@Composable
private fun PersonalCoachBanner(
  examName: String,
  advice: String,
  onSmartPlanClick: () -> Unit
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = Color.Transparent)
  ) {
    Box(
      modifier = Modifier
        .background(
          Brush.linearGradient(
            colors = listOf(
              Color(0xFF1E1B4B),
              DopingPrimary,
              Color(0xFF3730A3)
            )
          )
        )
        .padding(18.dp)
    ) {
      Column(modifier = Modifier.fillMaxWidth()) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(DopingAmberLight),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.Psychology,
                contentDescription = null,
                tint = Color(0xFF78350F),
                modifier = Modifier.size(20.dp)
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "DOPİNG BİREYSEL KOÇ",
                color = DopingAmberLight,
                fontWeight = FontWeight.Black,
                fontSize = 12.sp,
                letterSpacing = 1.sp
              )
              Text(
                text = "$examName Takvim Programı",
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }

          Button(
            onClick = onSmartPlanClick,
            colors = ButtonDefaults.buttonColors(containerColor = DopingAmber),
            shape = RoundedCornerShape(12.dp),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
          ) {
            Text("Yenile", color = Color(0xFF451A03), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Surface(
          color = Color.White.copy(alpha = 0.15f),
          shape = RoundedCornerShape(10.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.Lightbulb,
              contentDescription = null,
              tint = DopingAmber,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = advice,
              color = Color.White,
              fontSize = 12.sp,
              lineHeight = 17.sp
            )
          }
        }
      }
    }
  }
}

@Composable
private fun SmartCoachDialog(
  examName: String,
  onDismiss: () -> Unit,
  onGenerate: (Int) -> Unit
) {
  var selectedHours by remember { mutableIntStateOf(20) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, tint = DopingAmberDark)
        Spacer(modifier = Modifier.width(8.dp))
        Text("Yapay Zeka Akıllı Koç", fontWeight = FontWeight.Bold)
      }
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
          text = "$examName için haftalık hedeflenen çalışma tempona göre zayıf ve kritik konuları takvimine dengeli biçimde planlayalım.",
          style = MaterialTheme.typography.bodyMedium
        )

        Text("Haftalık Çalışma Saati Hedefin:", fontWeight = FontWeight.Bold, fontSize = 13.sp)

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          listOf(15, 20, 30, 40).forEach { hours ->
            FilterChip(
              selected = selectedHours == hours,
              onClick = { selectedHours = hours },
              label = { Text("$hours Saat", fontWeight = FontWeight.Bold) },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = DopingPrimary,
                selectedLabelColor = Color.White
              )
            )
          }
        }

        Surface(
          color = Color(0xFFFEF3C7),
          shape = RoundedCornerShape(8.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Text(
            text = "Koç Notu: Bu plan hafıza teknikleri, soru çözümü ve tekrar günlerini takvim günlerine hatırlatıcılarla dağıtır.",
            style = MaterialTheme.typography.bodySmall,
            color = Color(0xFF92400E),
            modifier = Modifier.padding(10.dp)
          )
        }
      }
    },
    confirmButton = {
      Button(
        onClick = { onGenerate(selectedHours) },
        colors = ButtonDefaults.buttonColors(containerColor = DopingPrimary)
      ) {
        Text("Takvime Uygula")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Vazgeç")
      }
    }
  )
}
