package com.example.ui.screens.consumer

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.OrderStatusBadge
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrdersScreen(
    orders: List<Order>,
    onAdvanceOrderStage: (String) -> Unit,
    onContactSeller: (sellerId: String, sellerName: String) -> Unit,
    onContactDeliveryPartner: (partnerId: String, partnerName: String) -> Unit,
    onLeaveReview: (Order) -> Unit,
    selectedOrderId: String? = null,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(0) } // 0 = Active Orders, 1 = Past Orders
    var expandedOrderId by remember { mutableStateOf(selectedOrderId ?: orders.firstOrNull()?.id) }

    val activeOrders = orders.filter { it.status != OrderStatus.COMPLETED && it.status != OrderStatus.CANCELLED }
    val pastOrders = orders.filter { it.status == OrderStatus.COMPLETED || it.status == OrderStatus.CANCELLED }
    val displayedOrders = if (selectedTab == 0) activeOrders else pastOrders

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Your Orders & Tracking",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                }
            )
        }
    ) { padding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = IgnisOrangePrimary
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Active Tracking (${activeOrders.size})", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Past Orders (${pastOrders.size})") }
                )
            }

            if (displayedOrders.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Inventory2,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(64.dp)
                        )
                        Text(
                            text = if (selectedTab == 0) "No active orders right now" else "No past orders",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Orders placed with local innovators will appear here with live tracking.",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(displayedOrders) { order ->
                        val isExpanded = expandedOrderId == order.id

                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(18.dp))
                                .clickable { expandedOrderId = if (isExpanded) null else order.id }
                                .testTag("order_card_${order.id}")
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                // Header
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = order.orderNumber,
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = IgnisOrangePrimary
                                            )
                                        )
                                        Text(
                                            text = "From ${order.sellerName}",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        )
                                    }

                                    OrderStatusBadge(status = order.status)
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // Quick details
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "${order.items.size} item(s) • $${"%.2f".format(order.total)}",
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                                    )
                                    Text(
                                        text = if (isExpanded) "Hide details ▲" else "View tracking ▼",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = IgnisOrangePrimary,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }

                                AnimatedVisibility(visible = isExpanded) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(top = 16.dp),
                                        verticalArrangement = Arrangement.spacedBy(14.dp)
                                    ) {
                                        HorizontalDivider()

                                        // 8-Stage Delivery Tracker
                                        Text(
                                            text = "Delivery Lifecycle Stages",
                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                        )

                                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                            OrderStatus.values().filterNot { it == OrderStatus.CANCELLED }.forEachIndexed { idx, stage ->
                                                val isPast = order.status.stepIndex > stage.stepIndex
                                                val isCurrent = order.status == stage
                                                val isFuture = order.status.stepIndex < stage.stepIndex

                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                                ) {
                                                    Box(
                                                        modifier = Modifier
                                                            .size(24.dp)
                                                            .clip(CircleShape)
                                                            .background(
                                                                when {
                                                                    isCurrent -> IgnisOrangePrimary
                                                                    isPast -> IgnisEmerald
                                                                    else -> MaterialTheme.colorScheme.surfaceVariant
                                                                }
                                                            ),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        if (isPast) {
                                                            Icon(Icons.Filled.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                                                        } else if (isCurrent) {
                                                            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color.White))
                                                        } else {
                                                            Text(
                                                                text = "${idx + 1}",
                                                                style = MaterialTheme.typography.labelSmall.copy(
                                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                                    fontSize = 10.sp
                                                                )
                                                            )
                                                        }
                                                    }

                                                    Text(
                                                        text = stage.label,
                                                        style = MaterialTheme.typography.bodySmall.copy(
                                                            fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                                            color = when {
                                                                isCurrent -> IgnisOrangePrimary
                                                                isPast -> MaterialTheme.colorScheme.onSurface
                                                                else -> MaterialTheme.colorScheme.onSurfaceVariant
                                                            }
                                                        )
                                                    )
                                                }
                                            }
                                        }

                                        // Delivery Partner Assigned Card (if assigned)
                                        if (order.deliveryPartnerName != null) {
                                            Surface(
                                                color = Color(0xFFF0FDF4),
                                                shape = RoundedCornerShape(12.dp)
                                            ) {
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(12.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.SpaceBetween
                                                ) {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                    ) {
                                                        Icon(Icons.Filled.TwoWheeler, contentDescription = null, tint = IgnisEmerald)
                                                        Column {
                                                            Text(
                                                                text = order.deliveryPartnerName,
                                                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                                                            )
                                                            Text(
                                                                text = "Ignis Local Courier (Active)",
                                                                style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFF047857))
                                                            )
                                                        }
                                                    }

                                                    Button(
                                                        onClick = { onContactDeliveryPartner(order.deliveryPartnerId ?: "partner", order.deliveryPartnerName) },
                                                        colors = ButtonDefaults.buttonColors(containerColor = IgnisEmerald),
                                                        shape = RoundedCornerShape(10.dp),
                                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                                    ) {
                                                        Icon(Icons.Filled.ChatBubbleOutline, contentDescription = null, modifier = Modifier.size(14.dp))
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text("Chat Partner", fontSize = 12.sp)
                                                    }
                                                }
                                            }
                                        }

                                        // Contact Actions
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            OutlinedButton(
                                                onClick = { onContactSeller(order.sellerId, order.sellerName) },
                                                modifier = Modifier.weight(1f),
                                                shape = RoundedCornerShape(12.dp)
                                            ) {
                                                Icon(Icons.Filled.ChatBubbleOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("Chat Seller")
                                            }

                                            if (order.status == OrderStatus.COMPLETED) {
                                                Button(
                                                    onClick = { onLeaveReview(order) },
                                                    modifier = Modifier.weight(1f),
                                                    shape = RoundedCornerShape(12.dp),
                                                    colors = ButtonDefaults.buttonColors(containerColor = IgnisOrangePrimary)
                                                ) {
                                                    Icon(Icons.Filled.Star, contentDescription = null, modifier = Modifier.size(16.dp))
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text("Rate Order")
                                                }
                                            }
                                        }

                                        // Simulation stage button for testing
                                        if (order.status != OrderStatus.COMPLETED) {
                                            FilledTonalButton(
                                                onClick = { onAdvanceOrderStage(order.id) },
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .testTag("simulate_advance_order_${order.id}"),
                                                shape = RoundedCornerShape(12.dp)
                                            ) {
                                                Icon(Icons.Filled.FastForward, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("Simulate Next Stage → (${getNextStageLabel(order.status)})")
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun getNextStageLabel(status: OrderStatus): String {
    return when (status) {
        OrderStatus.ORDER_PLACED -> "Seller Confirmed"
        OrderStatus.SELLER_CONFIRMED -> "Delivery Requested"
        OrderStatus.DELIVERY_REQUESTED -> "Delivery Assigned"
        OrderStatus.DELIVERY_ASSIGNED -> "Picked Up"
        OrderStatus.PICKED_UP -> "On the Way"
        OrderStatus.ON_THE_WAY -> "Delivered"
        OrderStatus.DELIVERED -> "Completed"
        else -> "Done"
    }
}
