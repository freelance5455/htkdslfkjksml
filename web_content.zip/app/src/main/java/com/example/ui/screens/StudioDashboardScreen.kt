package com.example.ui.screens

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AudioEffectsConfig
import com.example.model.BitDepth
import com.example.model.DelayRangeMode
import com.example.model.RecordingState
import com.example.model.ReverbType
import com.example.ui.components.DeleteConfirmDialog
import com.example.ui.components.MetallicKnob
import com.example.ui.components.MonitorWarningDialog
import com.example.ui.components.RealisticWaveformVisualizer
import com.example.ui.components.SavePresetDialog
import com.example.ui.components.StudioFader
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldGlow
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.LedGreen
import com.example.ui.theme.LedRed
import com.example.ui.theme.LedYellow
import com.example.ui.theme.MetallicGold
import com.example.ui.theme.MetallicGoldLight
import com.example.ui.theme.MetallicSilver
import com.example.ui.theme.StudioBlack
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioDarkBg
import com.example.ui.theme.StudioDivider
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.StudioScreen
import com.example.viewmodel.StudioViewModel
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioDashboardScreen(
    viewModel: StudioViewModel,
    onRequestPermission: () -> Unit,
    modifier: Modifier = Modifier
) {
    val effectsConfig by viewModel.effectsConfig.collectAsState()
    val recordingState by viewModel.recordingState.collectAsState()
    val recordingDurationMs by viewModel.recordingDurationMs.collectAsState()
    val liveWaveform by viewModel.liveWaveform.collectAsState()
    val liveRms by viewModel.liveRmsLevel.collectAsState()
    val livePeak by viewModel.livePeakLevel.collectAsState()
    val hasMicPermission by viewModel.hasMicPermission.collectAsState()
    val delayRangeMode by viewModel.delayRangeMode.collectAsState()
    val presets by viewModel.presets.collectAsState()
    val selectedPresetId by viewModel.selectedPresetId.collectAsState()
    val recordings by viewModel.recordings.collectAsState()
    val showHeadphoneWarning by viewModel.showHeadphoneWarning.collectAsState()

    var showSavePresetDialog by remember { mutableStateOf(false) }

    if (showHeadphoneWarning) {
        MonitorWarningDialog(
            onConfirmEnable = { viewModel.confirmMonitorWithoutHeadset() },
            onDismiss = { viewModel.dismissHeadphoneWarning() }
        )
    }

    if (showSavePresetDialog) {
        SavePresetDialog(
            onSave = { name, subtitle ->
                viewModel.saveCustomPreset(name, subtitle)
                showSavePresetDialog = false
            },
            onDismiss = { showSavePresetDialog = false }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(StudioDarkBg)
    ) {
        // TOP APP HEADER
        StudioTopAppBar(
            recordingsCount = recordings.size,
            selectedBitDepth = effectsConfig.bitDepth,
            onToggleBitDepth = {
                val next = if (effectsConfig.bitDepth == BitDepth.BIT_16) BitDepth.BIT_24 else BitDepth.BIT_16
                viewModel.setBitDepth(next)
            },
            onOpenRecordings = { viewModel.navigateTo(StudioScreen.RECORDINGS) },
            onOpenPresets = { viewModel.navigateTo(StudioScreen.PRESETS) }
        )

        // SCROLLABLE STUDIO CONSOLE BODY
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Permission Alert Banner if not granted
            if (!hasMicPermission) {
                MicPermissionBanner(onRequestPermission = onRequestPermission)
            }

            // REAL-TIME AUDIO VISUALIZER & VU METER
            RealisticWaveformVisualizer(
                waveform = liveWaveform,
                rmsLevel = liveRms,
                peakLevel = livePeak,
                recordingState = recordingState,
                recordingDurationMs = recordingDurationMs
            )

            // PRESETS QUICK SELECTOR ROW
            QuickPresetsRow(
                presets = presets,
                selectedId = selectedPresetId,
                onSelectPreset = { viewModel.applyPreset(it) },
                onSaveNew = { showSavePresetDialog = true }
            )

            // DD-3 ECHO & DELAY CONTROLS CARD
            Dd3EchoSection(
                config = effectsConfig,
                delayMode = delayRangeMode,
                onDelayModeChange = { viewModel.setDelayRangeMode(it) },
                onEchoLevelChange = { viewModel.setEchoLevel(it) },
                onDelayTimeChange = { viewModel.setDelayTimeMs(it) },
                onFeedbackChange = { viewModel.setFeedback(it) },
                onToneDampChange = { viewModel.setToneDamp(it) }
            )

            // REVERB & SPATIAL ACOUSTICS CARD
            ReverbSection(
                config = effectsConfig,
                onReverbTypeChange = { viewModel.setReverbType(it) },
                onReverbLevelChange = { viewModel.setReverbLevel(it) },
                onReverbDecayChange = { viewModel.setReverbDecay(it) }
            )

            // CONSOLE DRY/WET MIXER & LIVE MONITOR CARD
            MixerSection(
                config = effectsConfig,
                onDryChange = { viewModel.setDryLevel(it) },
                onWetChange = { viewModel.setWetLevel(it) },
                onToggleMonitor = { viewModel.toggleLiveMonitor(it) }
            )

            Spacer(modifier = Modifier.height(8.dp))
        }

        // BOTTOM TRANSPORT RECORDING BAR
        StudioTransportBar(
            recordingState = recordingState,
            hasPermission = hasMicPermission,
            onRecordStart = { viewModel.startRecording() },
            onRecordPause = { viewModel.pauseRecording() },
            onRecordResume = { viewModel.resumeRecording() },
            onRecordStop = { viewModel.stopRecording() },
            onRequestPermission = onRequestPermission
        )
    }
}

@Composable
private fun StudioTopAppBar(
    recordingsCount: Int,
    selectedBitDepth: BitDepth,
    onToggleBitDepth: () -> Unit,
    onOpenRecordings: () -> Unit,
    onOpenPresets: () -> Unit
) {
    Surface(
        color = StudioBlack,
        shadowElevation = 4.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Brand & Tagline
            Column {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "DD-3",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 17.sp,
                        color = EmeraldPrimary,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "ECHO STUDIO",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = TextPrimary,
                        letterSpacing = 1.sp
                    )
                }
                Text(
                    text = "Professional Naat Voice Recorder",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }

            // Top Actions: Bit Depth toggle & Library
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Bit Depth Badge Button
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(StudioSurface)
                        .border(1.dp, StudioBorder, RoundedCornerShape(6.dp))
                        .clickable { onToggleBitDepth() }
                        .padding(horizontal = 8.dp, vertical = 5.dp)
                        .testTag("bit_depth_toggle")
                ) {
                    Text(
                        text = if (selectedBitDepth == BitDepth.BIT_24) "24-BIT" else "16-BIT",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = if (selectedBitDepth == BitDepth.BIT_24) MetallicGold else EmeraldPrimary
                    )
                }

                // Presets button
                IconButton(
                    onClick = onOpenPresets,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(StudioSurface)
                        .border(1.dp, StudioBorder, CircleShape)
                        .testTag("nav_presets_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "Manage Presets",
                        tint = TextPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Recordings Library button
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(StudioSurface)
                        .border(1.dp, StudioBorder, RoundedCornerShape(8.dp))
                        .clickable { onOpenRecordings() }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("nav_recordings_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Folder,
                            contentDescription = "Recordings Library",
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "Recordings",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )
                        if (recordingsCount > 0) {
                            Box(
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(EmeraldContainer)
                                    .padding(horizontal = 5.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = "$recordingsCount",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldLight
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MicPermissionBanner(onRequestPermission: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF261D09)),
        shape = RoundedCornerShape(10.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, LedYellow.copy(alpha = 0.6f)),
        modifier = Modifier.fillMaxWidth().testTag("mic_permission_banner")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.MicOff,
                    contentDescription = null,
                    tint = LedYellow,
                    modifier = Modifier.size(24.dp)
                )
                Column {
                    Text(
                        text = "Microphone Access Required",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = TextPrimary
                    )
                    Text(
                        text = "Enable mic to process real-time Naat voice echo and recording.",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }
            }
            Button(
                onClick = onRequestPermission,
                colors = ButtonDefaults.buttonColors(containerColor = LedYellow, contentColor = StudioBlack),
                shape = RoundedCornerShape(6.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                modifier = Modifier.testTag("grant_mic_permission_button")
            ) {
                Text("Enable", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun QuickPresetsRow(
    presets: List<com.example.model.AudioPreset>,
    selectedId: String?,
    onSelectPreset: (com.example.model.AudioPreset) -> Unit,
    onSaveNew: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "NAAT PRESETS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = TextSecondary
            )
            Row(
                modifier = Modifier.clickable { onSaveNew() },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.BookmarkAdd,
                    contentDescription = null,
                    tint = EmeraldPrimary,
                    modifier = Modifier.size(14.dp)
                )
                Text(
                    text = "Save Current",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = EmeraldPrimary
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            presets.forEach { preset ->
                val isSelected = preset.id == selectedId
                val bg = if (isSelected) EmeraldContainer else StudioSurface
                val border = if (isSelected) EmeraldPrimary else StudioBorder
                val textColor = if (isSelected) EmeraldLight else TextPrimary

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(bg)
                        .border(1.dp, border, RoundedCornerShape(8.dp))
                        .clickable { onSelectPreset(preset) }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                        .testTag("preset_chip_${preset.id}")
                ) {
                    Column {
                        Text(
                            text = preset.name,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = textColor
                        )
                        Text(
                            text = "${preset.config.delayTimeMs}ms • ${preset.config.reverbType.displayName}",
                            fontSize = 10.sp,
                            color = TextMuted
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Dd3EchoSection(
    config: AudioEffectsConfig,
    delayMode: DelayRangeMode,
    onDelayModeChange: (DelayRangeMode) -> Unit,
    onEchoLevelChange: (Float) -> Unit,
    onDelayTimeChange: (Int) -> Unit,
    onFeedbackChange: (Float) -> Unit,
    onToneDampChange: (Float) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = StudioSurface),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header: Title and DD-3 Delay Mode Selector
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(EmeraldPrimary)
                    )
                    Text(
                        text = "DD-3 DIGITAL DELAY & ECHO",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = TextPrimary
                    )
                }

                // Range Selector (S, M, L, FREE)
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(StudioBlack)
                        .border(1.dp, StudioBorder, RoundedCornerShape(6.dp))
                        .padding(2.dp),
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    DelayRangeMode.entries.forEach { mode ->
                        val isSel = delayMode == mode
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSel) EmeraldPrimary else Color.Transparent)
                                .clickable { onDelayModeChange(mode) }
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = mode.displayName,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSel) StudioBlack else TextMuted
                            )
                        }
                    }
                }
            }

            // 4 Rotary Studio Hardware Knobs
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                // 1. E.LEVEL (Echo Volume)
                MetallicKnob(
                    label = "E.Level",
                    value = config.echoLevel,
                    valueDisplay = "${(config.echoLevel * 100).roundToInt()}%",
                    onValueChange = onEchoLevelChange,
                    defaultValue = 0.60f,
                    tag = "knob_echo_level"
                )

                // 2. DELAY (Time in ms)
                val delayNorm = ((config.delayTimeMs - 20) / 980f).coerceIn(0f, 1f)
                MetallicKnob(
                    label = "Delay",
                    value = delayNorm,
                    valueDisplay = "${config.delayTimeMs} ms",
                    onValueChange = { norm ->
                        val ms = (20 + (norm * 980)).roundToInt()
                        onDelayTimeChange(ms)
                    },
                    accentColor = MetallicGold,
                    defaultValue = 0.28f,
                    tag = "knob_delay_time"
                )

                // 3. FEEDBACK (Repeats)
                val fbNorm = (config.feedback / 0.90f).coerceIn(0f, 1f)
                MetallicKnob(
                    label = "Feedback",
                    value = fbNorm,
                    valueDisplay = "${(config.feedback * 100).roundToInt()}%",
                    onValueChange = { norm ->
                        val fb = norm * 0.90f
                        onFeedbackChange(fb)
                    },
                    defaultValue = 0.53f,
                    tag = "knob_feedback"
                )

                // 4. TONE (Warm Analog Damping)
                MetallicKnob(
                    label = "Tone",
                    value = config.toneDamp,
                    valueDisplay = if (config.toneDamp < 0.4f) "Warm" else if (config.toneDamp > 0.8f) "Bright" else "Natural",
                    onValueChange = onToneDampChange,
                    defaultValue = 0.65f,
                    tag = "knob_tone"
                )
            }
        }
    }
}

@Composable
private fun ReverbSection(
    config: AudioEffectsConfig,
    onReverbTypeChange: (ReverbType) -> Unit,
    onReverbLevelChange: (Float) -> Unit,
    onReverbDecayChange: (Float) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = StudioSurface),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(MetallicGold)
                    )
                    Text(
                        text = "HALL & STUDIO REVERB",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = TextPrimary
                    )
                }

                Text(
                    text = config.reverbType.description,
                    fontSize = 10.sp,
                    color = TextMuted
                )
            }

            // Reverb Type Selector Tabs
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(StudioBlack)
                    .border(1.dp, StudioBorder, RoundedCornerShape(8.dp))
                    .padding(3.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                ReverbType.entries.forEach { type ->
                    val isSel = config.reverbType == type
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSel) EmeraldPrimary else Color.Transparent)
                            .clickable { onReverbTypeChange(type) }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = type.displayName,
                            fontSize = 11.sp,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSel) StudioBlack else TextSecondary
                        )
                    }
                }
            }

            // Knobs: Reverb Mix & Decay
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                MetallicKnob(
                    label = "Reverb Mix",
                    value = config.reverbLevel,
                    valueDisplay = "${(config.reverbLevel * 100).roundToInt()}%",
                    onValueChange = onReverbLevelChange,
                    defaultValue = 0.35f,
                    tag = "knob_reverb_mix"
                )

                MetallicKnob(
                    label = "Decay Time",
                    value = ((config.reverbDecay - 0.1f) / 0.85f).coerceIn(0f, 1f),
                    valueDisplay = "${(config.reverbDecay * 10).roundToInt() / 2f}s",
                    onValueChange = { norm ->
                        onReverbDecayChange(0.1f + (norm * 0.85f))
                    },
                    accentColor = MetallicGold,
                    defaultValue = 0.65f,
                    tag = "knob_reverb_decay"
                )
            }
        }
    }
}

@Composable
private fun MixerSection(
    config: AudioEffectsConfig,
    onDryChange: (Float) -> Unit,
    onWetChange: (Float) -> Unit,
    onToggleMonitor: (Boolean) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = StudioSurface),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, StudioBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "VOICE CONSOLE MIXING",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    color = TextPrimary
                )

                // Headphone Live Monitoring Toggle
                val isMonitorOn = config.isMonitorEnabled
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isMonitorOn) EmeraldContainer else StudioBlack)
                        .border(1.dp, if (isMonitorOn) EmeraldPrimary else StudioBorder, RoundedCornerShape(8.dp))
                        .clickable { onToggleMonitor(!isMonitorOn) }
                        .padding(horizontal = 8.dp, vertical = 5.dp)
                        .testTag("toggle_live_monitor"),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Headphones,
                        contentDescription = "Headphone Monitor",
                        tint = if (isMonitorOn) EmeraldLight else TextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = if (isMonitorOn) "MONITOR ON" else "MONITOR OFF",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isMonitorOn) EmeraldLight else TextSecondary
                    )
                }
            }

            // Dual Studio Faders: DRY Voice & WET Echo/Reverb
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                StudioFader(
                    label = "Dry Voice",
                    value = config.dryLevel,
                    onValueChange = onDryChange,
                    accentColor = MetallicSilver,
                    tag = "fader_dry_voice"
                )

                // Master Balance Indicator
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "BALANCE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextMuted
                    )
                    Box(
                        modifier = Modifier
                            .width(64.dp)
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(StudioBlack)
                            .border(1.dp, StudioBorder, RoundedCornerShape(3.dp))
                    ) {
                        // Balance dot
                        val wetRatio = (config.wetLevel / (config.dryLevel + config.wetLevel).coerceAtLeast(0.01f)).coerceIn(0f, 1f)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(wetRatio)
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(EmeraldPrimary)
                        )
                    }
                    Text(
                        text = "Vocal : Space",
                        fontSize = 10.sp,
                        color = TextSecondary
                    )
                }

                StudioFader(
                    label = "Wet Echo",
                    value = config.wetLevel,
                    onValueChange = onWetChange,
                    accentColor = EmeraldPrimary,
                    tag = "fader_wet_echo"
                )
            }
        }
    }
}

@Composable
private fun StudioTransportBar(
    recordingState: RecordingState,
    hasPermission: Boolean,
    onRecordStart: () -> Unit,
    onRecordPause: () -> Unit,
    onRecordResume: () -> Unit,
    onRecordStop: () -> Unit,
    onRequestPermission: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseRing by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 16f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse_ring"
    )

    Surface(
        color = StudioBlack,
        shadowElevation = 16.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                when (recordingState) {
                    RecordingState.IDLE -> {
                        // BIG ILLUMINATED RECORD BUTTON
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(68.dp)
                                    .shadow(8.dp, CircleShape)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.radialGradient(
                                            listOf(Color(0xFFFF453A), Color(0xFFB71C1C), Color(0xFF5F0909))
                                        )
                                    )
                                    .border(2.dp, Color(0xFFFF8A80), CircleShape)
                                    .clickable {
                                        if (hasPermission) onRecordStart() else onRequestPermission()
                                    }
                                    .testTag("main_record_button"),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FiberManualRecord,
                                    contentDescription = "Start Recording",
                                    tint = Color.White,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                            Text(
                                text = "START RECORDING",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                color = TextPrimary
                            )
                        }
                    }

                    RecordingState.RECORDING, RecordingState.PAUSED -> {
                        // PAUSE / RESUME BUTTON
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .background(StudioSurfaceElevated)
                                    .border(1.dp, StudioBorder, CircleShape)
                                    .clickable {
                                        if (recordingState == RecordingState.RECORDING) {
                                            onRecordPause()
                                        } else {
                                            onRecordResume()
                                        }
                                    }
                                    .testTag("pause_resume_button"),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (recordingState == RecordingState.RECORDING) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = if (recordingState == RecordingState.RECORDING) "Pause" else "Resume",
                                    tint = if (recordingState == RecordingState.RECORDING) LedYellow else EmeraldPrimary,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                            Text(
                                text = if (recordingState == RecordingState.RECORDING) "PAUSE" else "RESUME",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextSecondary
                            )
                        }

                        // STOP & FINALIZE WAV BUTTON
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(68.dp)
                                    .shadow(8.dp, CircleShape)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.radialGradient(
                                            listOf(EmeraldPrimary, EmeraldDark, Color(0xFF003822))
                                        )
                                    )
                                    .border(2.dp, EmeraldLight, CircleShape)
                                    .clickable { onRecordStop() }
                                    .testTag("stop_recording_button"),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Stop,
                                    contentDescription = "Stop & Save Recording",
                                    tint = StudioBlack,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                            Text(
                                text = "STOP & SAVE",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                color = EmeraldLight
                            )
                        }
                    }
                }
            }
        }
    }
}
