package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SortByAlpha
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.AiModelOption
import com.example.data.model.AiProvider
import com.example.data.model.StudioProject
import com.example.data.repository.ApiHubConfig
import com.example.data.repository.ArchitecturePreset
import com.example.ui.ProjectsUiState
import com.example.ui.SynthesisState
import com.example.ui.WorkspaceFilter
import com.example.ui.WorkspaceSortOrder
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.util.DirectDownloadResult
import com.example.util.ProjectArchiveExporter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.launch

private val REAL_UTILITY_BLUEPRINTS = listOf(
    "Cloud API Token & Latency Cost Estimator" to
        "Build an API token cost and request latency estimator with interactive sliders for daily requests, input/output tokens per call, cache hit rate toggle, and monthly USD cost projection.",
    "Compound Interest & Savings Allocation Tool" to
        "Build a compound savings and asset allocation calculator with initial principal input, monthly contribution slider, annual yield percentage slider, and compounding period selector.",
    "Sprint Velocity & Engineering Capacity Planner" to
        "Build an engineering sprint capacity planner with team size input, sprint days slider, focus factor percentage, and a release readiness checklist."
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StudioDashboardScreen(
    apiConfig: ApiHubConfig,
    promptInput: String,
    isEnhancingPrompt: Boolean,
    searchQuery: String,
    workspaceFilter: WorkspaceFilter,
    workspaceSort: WorkspaceSortOrder,
    synthesisState: SynthesisState,
    projectsState: ProjectsUiState,
    onPromptChange: (String) -> Unit,
    onEnhancePromptClick: () -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onSelectWorkspaceFilter: (WorkspaceFilter) -> Unit,
    onSelectWorkspaceSort: (WorkspaceSortOrder) -> Unit,
    onSelectProvider: (AiProvider) -> Unit,
    onSelectModel: (AiModelOption) -> Unit,
    onSelectArchitecturePreset: (ArchitecturePreset) -> Unit,
    onSynthesizeClick: () -> Unit,
    onOpenProjectInSandbox: (StudioProject) -> Unit,
    onTogglePin: (StudioProject) -> Unit,
    onDeleteProject: (StudioProject) -> Unit,
    onNavigateToApiHub: () -> Unit
) {
    var providerMenuExpanded by remember { mutableStateOf(false) }
    var modelMenuExpanded by remember { mutableStateOf(false) }

    val isSynthesizing = synthesisState is SynthesisState.Synthesizing

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("studio_dashboard_list"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Hero Banner & Active Routing Bar
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                Color(0xFF0F172A),
                                Color(0xFF1E1B4B),
                                Color(0xFF0C4A6E)
                            )
                        )
                    )
                    .border(
                        width = 1.dp,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.3f),
                        shape = RoundedCornerShape(18.dp)
                    )
                    .padding(16.dp)
            ) {
                Canvas(modifier = Modifier.matchParentSize()) {
                    drawCircle(
                        color = Color(0xFF38BDF8).copy(alpha = 0.12f),
                        radius = size.minDimension * 0.45f,
                        center = Offset(size.width * 0.9f, size.height * 0.2f)
                    )
                }

                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "Prompt-to-App Engine",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "PROMPT-TO-APP STUDIO",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Surface(
                            color = if (apiConfig.hasActiveCredential()) {
                                MaterialTheme.colorScheme.tertiaryContainer
                            } else {
                                MaterialTheme.colorScheme.error.copy(alpha = 0.25f)
                            },
                            shape = RoundedCornerShape(50),
                            modifier = Modifier
                                .clickable { onNavigateToApiHub() }
                                .testTag("credential_status_badge")
                        ) {
                            Text(
                                text = if (apiConfig.hasActiveCredential()) "Route Ready" else "Key Needed",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (apiConfig.hasActiveCredential()) {
                                    MaterialTheme.colorScheme.tertiary
                                } else {
                                    MaterialTheme.colorScheme.error
                                },
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Synthesize Native Compose Mini-Tools",
                        style = MaterialTheme.typography.headlineSmall,
                        color = Color.White,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Describe the utility or application you want to build. Requests route dynamically to your active provider and render inside the Live Sandbox.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFCBD5E1),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // 1B. Direct APK & Full App ZIP Download Hub
        item {
            val savedProjects = (projectsState as? ProjectsUiState.Success)?.projects.orEmpty()
            ApkAndFullZipExportCard(projects = savedProjects)
        }

        // 2. Quick Provider, Model & Architecture Preset Routing Bar
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Memory,
                                contentDescription = "Model Router",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Active AI Backend & Architecture",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Text(
                            text = "Configure Keys",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .clickable { onNavigateToApiHub() }
                                .padding(4.dp)
                                .testTag("configure_keys_link")
                        )
                    }

                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = { providerMenuExpanded = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("studio_provider_dropdown_button"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Provider: ${apiConfig.selectedProvider.displayName}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.weight(1f)
                                )
                                Icon(
                                    imageVector = Icons.Default.Tune,
                                    contentDescription = "Change AI provider",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = providerMenuExpanded,
                            onDismissRequest = { providerMenuExpanded = false }
                        ) {
                            AiProvider.entries.forEach { provider ->
                                DropdownMenuItem(
                                    text = {
                                        Column(modifier = Modifier.fillMaxWidth()) {
                                            Text(
                                                text = provider.displayName,
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            Text(
                                                text = provider.vendorSubtitle,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    },
                                    onClick = {
                                        providerMenuExpanded = false
                                        onSelectProvider(provider)
                                    }
                                )
                            }
                        }
                    }

                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = { modelMenuExpanded = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("studio_model_dropdown_button"),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Model: ${apiConfig.selectedModel.displayName} (${apiConfig.selectedModel.contextBadge})",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.weight(1f)
                                )
                                Icon(
                                    imageVector = Icons.Default.Bolt,
                                    contentDescription = "Change AI model",
                                    tint = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = modelMenuExpanded,
                            onDismissRequest = { modelMenuExpanded = false }
                        ) {
                            AiModelOption.forProvider(apiConfig.selectedProvider).forEach { modelOption ->
                                DropdownMenuItem(
                                    text = {
                                        Column(modifier = Modifier.fillMaxWidth()) {
                                            Text(
                                                text = "${modelOption.displayName} • ${modelOption.contextBadge}",
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            Text(
                                                text = modelOption.architectureNote,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    },
                                    onClick = {
                                        modelMenuExpanded = false
                                        onSelectModel(modelOption)
                                    }
                                )
                            }
                        }
                    }

                    Text(
                        text = "Architecture Pattern Preset:",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ArchitecturePreset.entries.forEach { preset ->
                            FilterChip(
                                selected = apiConfig.architecturePreset == preset,
                                onClick = { onSelectArchitecturePreset(preset) },
                                label = {
                                    Text(
                                        text = preset.label,
                                        style = MaterialTheme.typography.labelSmall
                                    )
                                },
                                modifier = Modifier.testTag("arch_preset_${preset.id.lowercase()}")
                            )
                        }
                    }

                    Text(
                        text = "Credential status: ${apiConfig.maskedKeyFor(apiConfig.selectedProvider)} • Temp ${apiConfig.temperature}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // 3. Prompt Specification Input Card + AI Prompt Enhancer
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Application Specification Prompt",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(1f)
                        )
                        if (promptInput.isNotEmpty()) {
                            Text(
                                text = "Clear",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier
                                    .clickable { onPromptChange("") }
                                    .padding(4.dp)
                            )
                        }
                    }

                    OutlinedTextField(
                        value = promptInput,
                        onValueChange = onPromptChange,
                        enabled = !isSynthesizing && !isEnhancingPrompt,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(148.dp)
                            .testTag("prompt_input_field"),
                        placeholder = {
                            Text(
                                text = "Describe the tool, calculator, dashboard, or workflow app you want to synthesize...",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline
                        )
                    )

                    // AI Prompt Enhancer Action Button
                    OutlinedButton(
                        onClick = onEnhancePromptClick,
                        enabled = !isSynthesizing && !isEnhancingPrompt && promptInput.isNotBlank(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("enhance_prompt_button"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        if (isEnhancingPrompt) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Expanding specification with ${apiConfig.selectedModel.displayName}...")
                        } else {
                            Icon(
                                imageVector = Icons.Default.AutoFixHigh,
                                contentDescription = "AI Prompt Enhancer",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Enhance Prompt Specification with AI")
                        }
                    }

                    Text(
                        text = "Quick Utility Blueprints (tap to populate):",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        REAL_UTILITY_BLUEPRINTS.forEachIndexed { idx, (label, fullPrompt) ->
                            AssistChip(
                                onClick = { onPromptChange(fullPrompt) },
                                enabled = !isSynthesizing,
                                label = {
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                },
                                colors = AssistChipDefaults.assistChipColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                                ),
                                modifier = Modifier.testTag("blueprint_chip_$idx")
                            )
                        }
                    }

                    AnimatedVisibility(visible = synthesisState is SynthesisState.Error) {
                        val err = (synthesisState as? SynthesisState.Error)?.message.orEmpty()
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("synthesis_error_banner"),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.15f)
                            )
                        ) {
                            Text(
                                text = err,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp)
                            )
                        }
                    }

                    Button(
                        onClick = onSynthesizeClick,
                        enabled = !isSynthesizing && !isEnhancingPrompt && promptInput.isNotBlank(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("synthesize_app_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        )
                    ) {
                        if (isSynthesizing) {
                            val activeSynth = synthesisState as? SynthesisState.Synthesizing
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Routing to ${activeSynth?.model?.displayName ?: "AI Model"}...",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                        } else {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Synthesize App",
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Synthesize & Launch in Live Sandbox",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // 4. Saved Studio Projects Header + Search, Filter & Sort Controls
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Generated Studio Workspace",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        val count = (projectsState as? ProjectsUiState.Success)?.projects?.size ?: 0
                        Text(
                            text = "$count total",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = onSearchQueryChange,
                        placeholder = {
                            Text(
                                text = "Search workspace by title, prompt, or model...",
                                style = MaterialTheme.typography.bodySmall
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Search projects",
                                modifier = Modifier.size(18.dp)
                            )
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { onSearchQueryChange("") }) {
                                    Icon(
                                        imageVector = Icons.Default.Clear,
                                        contentDescription = "Clear search",
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("workspace_search_input"),
                        shape = RoundedCornerShape(10.dp)
                    )

                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        WorkspaceFilter.entries.forEach { filter ->
                            FilterChip(
                                selected = workspaceFilter == filter,
                                onClick = { onSelectWorkspaceFilter(filter) },
                                label = {
                                    Text(filter.label, style = MaterialTheme.typography.labelSmall)
                                },
                                modifier = Modifier.testTag("workspace_filter_${filter.name.lowercase()}")
                            )
                        }

                        FilterChip(
                            selected = workspaceSort == WorkspaceSortOrder.ALPHABETICAL,
                            onClick = {
                                val next = if (workspaceSort == WorkspaceSortOrder.NEWEST) {
                                    WorkspaceSortOrder.ALPHABETICAL
                                } else {
                                    WorkspaceSortOrder.NEWEST
                                }
                                onSelectWorkspaceSort(next)
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.SortByAlpha,
                                    contentDescription = "Sort projects",
                                    modifier = Modifier.size(14.dp)
                                )
                            },
                            label = {
                                Text(workspaceSort.label, style = MaterialTheme.typography.labelSmall)
                            },
                            modifier = Modifier.testTag("workspace_sort_chip")
                        )
                    }
                }
            }
        }

        // 5. Projects List or Clean Empty State
        when (projectsState) {
            is ProjectsUiState.Loading -> {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                    }
                }
            }

            is ProjectsUiState.Error -> {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Text(
                            text = projectsState.message,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        )
                    }
                }
            }

            is ProjectsUiState.Success -> {
                val filteredProjects = projectsState.projects
                    .filter { proj ->
                        val matchesSearch = searchQuery.isBlank() ||
                            proj.title.contains(searchQuery, ignoreCase = true) ||
                            proj.summary.contains(searchQuery, ignoreCase = true) ||
                            proj.prompt.contains(searchQuery, ignoreCase = true) ||
                            proj.modelId.contains(searchQuery, ignoreCase = true)
                        val matchesFilter = when (workspaceFilter) {
                            WorkspaceFilter.ALL -> true
                            WorkspaceFilter.PINNED -> proj.isPinned
                            WorkspaceFilter.WEBSITES -> proj.isWebsiteProject()
                            WorkspaceFilter.GEMINI -> proj.provider.equals("GEMINI", ignoreCase = true)
                            WorkspaceFilter.OPENAI -> proj.provider.equals("OPENAI", ignoreCase = true)
                            WorkspaceFilter.ANTHROPIC -> proj.provider.equals("ANTHROPIC", ignoreCase = true)
                        }
                        matchesSearch && matchesFilter
                    }
                    .let { list ->
                        when (workspaceSort) {
                            WorkspaceSortOrder.NEWEST -> list
                            WorkspaceSortOrder.ALPHABETICAL -> list.sortedWith(
                                compareByDescending<StudioProject> { it.isPinned }
                                    .thenBy { it.title.lowercase() }
                            )
                        }
                    }

                if (filteredProjects.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("empty_projects_card"),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surface
                            ),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.surfaceVariant),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FolderOpen,
                                        contentDescription = "Empty Workspace",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = if (projectsState.projects.isEmpty()) {
                                        stringResource(R.string.empty_projects_message)
                                    } else {
                                        "No saved projects match your current search or filter criteria."
                                    },
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                } else {
                    items(
                        items = filteredProjects,
                        key = { it.id.ifBlank { it.title + it.prompt.hashCode() } }
                    ) { project ->
                        StudioProjectCard(
                            project = project,
                            onOpenSandbox = { onOpenProjectInSandbox(project) },
                            onTogglePin = { onTogglePin(project) },
                            onDelete = { onDeleteProject(project) }
                        )
                    }
                }
            }
        }

        // 6. Donate Us Section (Custom Supporter Contributions via UPI or Card)
        item {
            DonateUsSectionCard(
                onStatusMessage = {}
            )
        }
    }
}

@Composable
private fun ApkAndFullZipExportCard(
    projects: List<StudioProject>
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var lastSavedDownload by remember { mutableStateOf<DirectDownloadResult?>(null) }
    var exportNotice by remember { mutableStateOf<String?>(null) }
    var isExporting by remember { mutableStateOf(false) }
    var showPhoneGuide by remember { mutableStateOf(false) }

    val customFolderApkLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/vnd.android.package-archive")
    ) { uri ->
        if (uri != null) {
            isExporting = true
            scope.launch {
                val res = ProjectArchiveExporter.exportInstalledStudioApkToUri(context, uri)
                isExporting = false
                res.onSuccess { summary ->
                    lastSavedDownload = DirectDownloadResult(
                        fileName = summary.archiveFileName,
                        displayPath = "Custom Folder/${summary.archiveFileName}",
                        totalBytes = summary.totalBytes.toLong(),
                        contentUri = uri,
                        mimeType = "application/vnd.android.package-archive"
                    )
                    exportNotice = null
                }.onFailure { err ->
                    exportNotice = err.localizedMessage ?: "Failed to save APK."
                }
            }
        }
    }

    val customFolderZipLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null) {
            isExporting = true
            scope.launch {
                val res = ProjectArchiveExporter.exportFullStudioBundleZipToUri(context, projects, uri)
                isExporting = false
                res.onSuccess { summary ->
                    lastSavedDownload = DirectDownloadResult(
                        fileName = summary.archiveFileName,
                        displayPath = "Custom Folder/${summary.archiveFileName}",
                        totalBytes = summary.totalBytes.toLong(),
                        contentUri = uri,
                        mimeType = "application/zip"
                    )
                    exportNotice = null
                }.onFailure { err ->
                    exportNotice = err.localizedMessage ?: "Failed to save Full App ZIP."
                }
            }
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                color = Color(0xFF10B981).copy(alpha = 0.35f),
                shape = RoundedCornerShape(16.dp)
            )
            .testTag("apk_and_full_zip_export_card"),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Android,
                        contentDescription = "Phone-Only Direct Downloads",
                        tint = Color(0xFF10B981),
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "No-Computer Phone Downloads (.APK & .ZIP)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "1-tap direct save into your phone's Downloads/ folder — no PC or Android Studio required",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Primary 1-Tap Direct Save to Phone Downloads Folder Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = {
                        isExporting = true
                        exportNotice = null
                        scope.launch {
                            val res = ProjectArchiveExporter.saveApkDirectlyToDownloads(context)
                            isExporting = false
                            res.onSuccess { saved ->
                                lastSavedDownload = saved
                            }.onFailure { err ->
                                exportNotice = err.localizedMessage ?: "Could not write to Downloads. Try 'Choose Folder' below."
                            }
                        }
                    },
                    enabled = !isExporting,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("save_apk_direct_downloads_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF10B981),
                        contentColor = Color(0xFF052E16)
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = "Save APK to Phone Downloads",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Save .APK",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }

                Button(
                    onClick = {
                        isExporting = true
                        exportNotice = null
                        scope.launch {
                            val res = ProjectArchiveExporter.saveFullZipDirectlyToDownloads(context, projects)
                            isExporting = false
                            res.onSuccess { saved ->
                                lastSavedDownload = saved
                            }.onFailure { err ->
                                exportNotice = err.localizedMessage ?: "Could not write ZIP to Downloads. Try 'Choose Folder' below."
                            }
                        }
                    },
                    enabled = !isExporting,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("save_zip_direct_downloads_button"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.FolderZip,
                        contentDescription = "Save Full ZIP to Phone Downloads",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Save Full .ZIP",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Secondary Fallback: Choose Custom Folder + Phone Guide Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TextButton(
                        onClick = { customFolderApkLauncher.launch("OmniPromptStudio-v1.0-signed.apk") },
                        enabled = !isExporting,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.testTag("download_signed_apk_button")
                    ) {
                        Text(
                            text = "Pick Folder (.APK)",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                    TextButton(
                        onClick = { customFolderZipLauncher.launch("OmniPromptStudio-Full-App-and-APK.zip") },
                        enabled = !isExporting,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.testTag("download_full_app_zip_button")
                    ) {
                        Text(
                            text = "Pick Folder (.ZIP)",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }

                TextButton(
                    onClick = { showPhoneGuide = !showPhoneGuide },
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.testTag("phone_only_guide_toggle")
                ) {
                    Icon(
                        imageVector = Icons.Default.HelpOutline,
                        contentDescription = "Phone Download Guide",
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (showPhoneGuide) "Hide Guide" else "Phone Guide",
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }

            // Saved Confirmation Banner with Monospace Path & 1-Tap Share Button
            AnimatedVisibility(visible = lastSavedDownload != null) {
                val saved = lastSavedDownload
                if (saved != null) {
                    Surface(
                        color = Color(0xFF064E3B).copy(alpha = 0.55f),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = 1.dp,
                                color = Color(0xFF10B981).copy(alpha = 0.5f),
                                shape = RoundedCornerShape(10.dp)
                            )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Saved to Phone Downloads",
                                    tint = Color(0xFF34D399),
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "Saved directly to Phone Downloads!",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF34D399)
                                )
                            }
                            Text(
                                text = "${saved.displayPath} (${saved.totalBytes / 1024} KB)",
                                style = MaterialTheme.typography.bodySmall,
                                fontFamily = JetBrainsMonoFontFamily,
                                color = Color.White
                            )
                            Text(
                                text = "Open your phone's Files / My Files app -> Downloads to install or extract.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFFA7F3D0)
                            )
                            if (saved.contentUri != null) {
                                OutlinedButton(
                                    onClick = {
                                        ProjectArchiveExporter.shareSavedDownloadFile(context, saved)
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("share_saved_download_button"),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Share,
                                        contentDescription = "Share Saved APK or ZIP",
                                        tint = Color(0xFF34D399),
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Share / Open ${saved.fileName} (WhatsApp, Drive, Files)",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color(0xFF34D399)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            if (exportNotice != null) {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.45f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = exportNotice.orEmpty(),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }

            // Collapsible No-Computer Mobile Guide
            AnimatedVisibility(visible = showPhoneGuide) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "How to Get APK & ZIP on a Phone (No PC Needed)",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "1. Inside This App: Tap 'Save .APK' or 'Save Full .ZIP' above. It writes directly to your phone's Downloads/ folder, and you can tap 'Share / Open' to send it to WhatsApp, Google Drive, Telegram, or your Files app.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "2. From Phone Browser (Chrome): Tap the 3-dots menu (⋮) in Chrome -> check 'Desktop site' -> tap the Settings (gear icon) at the top-right of AI Studio -> tap 'Download APK' or 'Export ZIP' directly to your phone.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StudioProjectCard(
    project: StudioProject,
    onOpenSandbox: () -> Unit,
    onTogglePin: () -> Unit,
    onDelete: () -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("MMM d, HH:mm", Locale.US) }
    val timestampLabel = project.createdAt?.toDate()?.let { dateFormat.format(it) }
        ?: dateFormat.format(Date())

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onOpenSandbox() }
            .testTag("project_item_card_${project.id}"),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    val targetTag = if (project.isWebsiteProject()) "WEBSITE" else "ANDROID"
                    Text(
                        text = "$targetTag • ${project.provider} • ${project.modelId}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = timestampLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    IconButton(
                        onClick = onTogglePin,
                        modifier = Modifier.testTag("pin_project_button_${project.id}")
                    ) {
                        Icon(
                            imageVector = if (project.isPinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                            contentDescription = if (project.isPinned) "Unpin project" else "Pin project",
                            tint = if (project.isPinned) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                MaterialTheme.colorScheme.onSurfaceVariant
                            },
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.testTag("delete_project_button_${project.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Delete project",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Text(
                text = project.title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.fillMaxWidth()
            )

            Text(
                text = project.summary,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = onOpenSandbox,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("open_sandbox_button_${project.id}"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = MaterialTheme.colorScheme.primary
                )
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Open Project",
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (project.isWebsiteProject()) {
                        "Launch in Website Maker & Preview"
                    } else {
                        "Launch Live Sandbox & Export Hub"
                    },
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}
