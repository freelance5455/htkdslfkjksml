package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.TrafficGreen
import com.example.ui.theme.TrafficRed
import com.example.ui.theme.TrafficYellow

@Composable
fun TrafficEducationView(
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "دليل إشارات وقواعد المرور والسلامة",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "تعرف على المعاني الدقيقة لكل إشارة ضوئية وقواعد السلامة على الطريق:",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.LightGray
            )
        }

        // RED LIGHT
        item {
            SignalRuleCard(
                title = "الضوء الأحمر (قف تماماً)",
                color = TrafficRed,
                icon = Icons.Default.Warning,
                description = "يُلزم جميع السائقين بالتوقف التام والكامل خلف خط الوقوف أو ممر المشاة. يحظر قطعياً تجاوز الإشارة أثناء إضاءة الضوء الأحمر لأن ذلك يشكل خطراً مميتاً ومخالفة مرورية جسيمة."
            )
        }

        // YELLOW LIGHT
        item {
            SignalRuleCard(
                title = "الضوء الأصفر (استعد للوقوف)",
                color = TrafficYellow,
                icon = Icons.Default.Info,
                description = "يعني التهدئة والتوقف الآمن قبل خط الوقوف. لا يعني زيادة السرعة للتسابق مع الإشارة! الاستثناء الوحيد للعبور هو إذا كان السائق قريباً جداً من خط الوقوف بحيث يشكل التوقف المفاجئ خطراً على المركبات التي خلفه."
            )
        }

        // GREEN LIGHT
        item {
            SignalRuleCard(
                title = "الضوء الأخضر (انطلق بحذر)",
                color = TrafficGreen,
                icon = Icons.Default.Security,
                description = "يسمح بالمرور بشرط التأكد من خلو التقاطع تماماً من أي مركبة متبقية أو مشاة يعبرون. الضوء الأخضر لا يعني الاندفاع بتهور، بل الانطلاق بسلاسة وانتباه."
            )
        }

        // FLASHING SIGNALS
        item {
            SignalRuleCard(
                title = "الإشارات الوماضة (الليل والطوارئ)",
                color = Color(0xFFFF9800),
                icon = Icons.Default.Warning,
                description = "الوميض الأصفر المتقطع: توخ الحذر الشديد وهدئ السرعة مع إعطاء الأولوية لمن في التقاطع.\nالوميض الأحمر المتقطع: يُعامل معاملة إشارة 'قف' الصريحة، يجب التوقف تماماً ثم الانطلاق فقط عند خلو الطريق."
            )
        }

        // PEDESTRIAN RULES
        item {
            SignalRuleCard(
                title = "حقوق وقواعد عبور المشاة",
                color = Color(0xFF00B0FF),
                icon = Icons.Default.AccessibilityNew,
                description = "1. العبور فقط من ممرات المشاة المخصصة (Zebra Crossing).\n2. الضغط على زر طلب العبور والانتظار حتى تضيء الإشارة الخضراء للمشاة.\n3. التأكد من توقف المركبات بصرياً قبل النزول إلى الشارع.\n4. تجنب استخدام الهاتف أو السماعات أثناء العبور."
            )
        }

        // EMERGENCY VEHICLES
        item {
            SignalRuleCard(
                title = "مركبات الطوارئ والإسعاف",
                color = Color(0xFFE91E63),
                icon = Icons.Default.LocalHospital,
                description = "مركبات الإسعاف والإطفاء والشرطة عند تشغيل صفارات الإنذار لها حق الأولوية المطلق. يجب على جميع السائقين إفساح المسار فوراً والانتقال لليمين أو التوقف بأمان."
            )
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun SignalRuleCard(
    title: String,
    color: Color,
    icon: ImageVector,
    description: String,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = Color(0xFF171D27),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.35f)),
        shadowElevation = 4.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(color.copy(alpha = 0.15f))
                        .border(1.dp, color.copy(alpha = 0.5f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = color,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            Text(
                text = description,
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFFCFD8DC),
                lineHeight = 22.sp
            )
        }
    }
}
