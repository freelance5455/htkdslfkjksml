package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.VoiceChannel
import com.example.data.model.VoiceUser
import com.example.ui.ChaufalandViewModel
import com.example.ui.components.MinecraftButton
import com.example.ui.components.MinecraftCard
import com.example.ui.components.PlayerAvatar
import com.example.ui.theme.MinecraftBorder
import com.example.ui.theme.MinecraftDiamond
import com.example.ui.theme.MinecraftEmerald
import com.example.ui.theme.MinecraftGold
import com.example.ui.theme.MinecraftGrass
import com.example.ui.theme.MinecraftRedstone
import com.example.ui.theme.MinecraftSurfaceVariant
import com.example.ui.theme.MinecraftText
import com.example.ui.theme.MinecraftTextDim

@Composable
fun VoiceScreen(viewModel: ChaufalandViewModel, modifier: Modifier = Modifier) {
  val channels = viewModel.voiceChannels
  val currentChannel by viewModel.currentVoiceChannel.collectAsState()
  val isMuted by viewModel.isMuted.collectAsState()
  val isSpeaking by viewModel.isSpeaking.collectAsState()
  val voiceUsers by viewModel.voiceUsers.collectAsState()
  val myGamerTag by viewModel.gamerTag.collectAsState()

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(12.dp)
  ) {
    // BARRA DE ESTADO DE LLAMADA
    MinecraftCard(
      borderColor = if (currentChannel != null) MinecraftEmerald else MinecraftBorder
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          PlayerAvatar(gamerTag = myGamerTag.ifBlank { "Steve" }, size = 42.dp)
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
              text = myGamerTag.ifBlank { "Invitado" },
              color = MinecraftGold,
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold,
              fontFamily = FontFamily.Monospace
            )
            Text(
              text = currentChannel?.let { "Conectado a ${it.name}" } ?: "Sin canal de voz activo",
              color = if (currentChannel != null) MinecraftEmerald else MinecraftTextDim,
              fontSize = 11.sp,
              fontFamily = FontFamily.Monospace
            )
          }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          MinecraftButton(
            text = if (isMuted) "🔇 Muted" else "🎙️ Micro",
            containerColor = if (isMuted) MinecraftRedstone else MinecraftGrass,
            onClick = { viewModel.toggleMute() },
            enabled = currentChannel != null,
            testTag = "btn_voice_mute"
          )

          if (currentChannel != null) {
            MinecraftButton(
              text = "✖ Salir",
              containerColor = Color(0xFF6B1D1D),
              onClick = { viewModel.leaveVoiceChannel() },
              testTag = "btn_voice_disconnect"
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    Text(
      text = "CANALES DE VOZ DISPONIBLES",
      color = MinecraftDiamond,
      fontSize = 12.sp,
      fontWeight = FontWeight.Bold,
      fontFamily = FontFamily.Monospace,
      modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
    )

    // LISTA DE CANALES
    LazyColumn(
      verticalArrangement = Arrangement.spacedBy(10.dp),
      modifier = Modifier.weight(1f)
    ) {
      items(channels) { channel ->
        val isJoined = currentChannel?.id == channel.id
        val usersInThisChannel = voiceUsers.filter { it.channelId == channel.id }

        ChannelCardItem(
          channel = channel,
          isJoined = isJoined,
          users = usersInThisChannel,
          onJoinClick = {
            if (isJoined) {
              viewModel.leaveVoiceChannel()
            } else {
              viewModel.joinVoiceChannel(channel)
            }
          }
        )
      }
    }
  }
}

@Composable
private fun ChannelCardItem(
  channel: VoiceChannel,
  isJoined: Boolean,
  users: List<VoiceUser>,
  onJoinClick: () -> Unit
) {
  MinecraftCard(
    borderColor = if (isJoined) MinecraftEmerald else MinecraftBorder
  ) {
    Column(modifier = Modifier.fillMaxWidth()) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(text = channel.icon, fontSize = 20.sp)
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = channel.name,
            color = if (isJoined) MinecraftEmerald else Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
          )
        }

        MinecraftButton(
          text = if (isJoined) "DESCONECTAR" else "UNIRSE",
          containerColor = if (isJoined) MinecraftRedstone else MinecraftEmerald,
          onClick = onJoinClick,
          modifier = Modifier.height(34.dp),
          testTag = "btn_channel_${channel.id}"
        )
      }

      // Participantes en este canal
      Spacer(modifier = Modifier.height(10.dp))
      if (users.isEmpty()) {
        Text(
          text = "No hay jugadores en este canal actualmente",
          color = MinecraftTextDim,
          fontSize = 11.sp,
          fontFamily = FontFamily.Monospace
        )
      } else {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          users.forEach { user ->
            UserVoiceItemRow(user = user)
          }
        }
      }
    }
  }
}

@Composable
private fun UserVoiceItemRow(user: VoiceUser) {
  val infiniteTransition = rememberInfiniteTransition(label = "pulse")
  val speakingScale by infiniteTransition.animateFloat(
    initialValue = 0.9f,
    targetValue = 1.3f,
    animationSpec = infiniteRepeatable(
      animation = tween(400, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "speakingScale"
  )

  Row(
    modifier = Modifier
      .fillMaxWidth()
      .background(MinecraftSurfaceVariant, RoundedCornerShape(2.dp))
      .border(1.dp, MinecraftBorder, RoundedCornerShape(2.dp))
      .padding(horizontal = 8.dp, vertical = 6.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    PlayerAvatar(gamerTag = user.gamerTag, size = 28.dp)
    Spacer(modifier = Modifier.width(8.dp))
    Text(
      text = user.gamerTag,
      color = Color.White,
      fontSize = 13.sp,
      fontWeight = FontWeight.Bold,
      fontFamily = FontFamily.Monospace,
      modifier = Modifier.weight(1f)
    )

    if (user.isMuted) {
      Text(text = "🔇", fontSize = 14.sp)
    }

    Spacer(modifier = Modifier.width(6.dp))

    // Indicador de voz activa
    Box(
      modifier = Modifier
        .size(12.dp)
        .then(if (user.isSpeaking) Modifier.scale(speakingScale) else Modifier)
        .background(
          if (user.isSpeaking) MinecraftEmerald else Color(0xFF4A3B30),
          CircleShape
        )
        .border(1.dp, Color(0xFF16100B), CircleShape)
    )
  }
}
