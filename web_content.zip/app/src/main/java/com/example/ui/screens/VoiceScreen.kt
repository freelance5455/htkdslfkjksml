package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.VoicePreset
import com.example.ui.MainViewModel
import com.example.ui.components.NexusOrb
import com.example.ui.components.OrbState
import com.example.ui.components.VoiceWaveVisualizer
import com.example.ui.theme.NexusBackground
import com.example.ui.theme.NexusBorder
import com.example.ui.theme.NexusCyan
import com.example.ui.theme.NexusCyanDark
import com.example.ui.theme.NexusEmerald
import com.example.ui.theme.NexusRose
import com.example.ui.theme.NexusSurface
import com.example.ui.theme.NexusSurfaceElevated
import com.example.ui.theme.NexusSurfaceVariant
import com.example.ui.theme.NexusTextPrimary
import com.example.ui.theme.NexusTextSecondary
import com.example.ui.theme.NexusTextTertiary
import com.example.ui.theme.NexusViolet

@Composable
fun VoiceScreen(
    viewModel: MainViewModel,
    onNavigateToChat: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val orbState by viewModel.orbState.collectAsStateWithLifecycle()
    val isListening by viewModel.speechManager.isListening.collectAsStateWithLifecycle()
    val isSpeaking by viewModel.isSpeaking.collectAsStateWithLifecycle()
    val isGenerating by viewModel.isGenerating.collectAsStateWithLifecycle()
    val partialText by viewModel.speechManager.partialText.collectAsStateWithLifecycle()
    val rmsAmplitude by viewModel.speechManager.rmsAmplitude.collectAsStateWithLifecycle()
    val speechError by viewModel.speechManager.errorMessage.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val lastResponse by viewModel.lastVoiceResponse.collectAsStateWithLifecycle()
    val streamingResponse by viewModel.streamingResponse.collectAsStateWithLifecycle()
    val errorMessage by viewModel.errorMessage.collectAsStateWithLifecycle()
    val isOnline by viewModel.isOnline.collectAsStateWithLifecycle()

    var showReaderCard by remember { mutableStateOf(false) }
    var textToRead by remember { mutableStateOf("") }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.toggleVoiceListening()
        }
    }

    fun handleMicClick() {
        val hasPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (hasPermission) {
            viewModel.toggleVoiceListening()
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    val quickQuestions = listOf(
        "Посчитай (154 * 32) / 4",
        "Напиши код на Kotlin",
        "Объясни квантовую суперпозицию",
        "Характеристики Helio G100",
        "Составь план на неделю",
        "Как работает локальный ИИ?"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(NexusBackground)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top status card
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(NexusSurfaceVariant)
                    .border(1.dp, NexusBorder, RoundedCornerShape(20.dp))
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(
                            when (orbState) {
                                OrbState.IDLE -> NexusCyan
                                OrbState.LISTENING -> NexusEmerald
                                OrbState.THINKING -> NexusViolet
                                OrbState.SPEAKING -> NexusCyan
                            }
                        )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = when (orbState) {
                        OrbState.LISTENING -> "Слушаю русскую речь..."
                        OrbState.THINKING -> if (settings.engineType.isOffline) "Локальный инференс (Helio G100)..." else "Синтез ответа (Omni-AI / Интернет)..."
                        OrbState.SPEAKING -> "Озвучивание ответа (TTS)..."
                        OrbState.IDLE -> "NEXUS готов к голосовому диалогу"
                    },
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = NexusTextPrimary
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(if (isOnline) NexusEmerald else NexusRose)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "${if (isOnline) "Интернет" else "Нет сети"} • ${settings.effectiveGeminiModelTitle()} • Голос: ${settings.voicePreset.title}",
                    fontSize = 11.sp,
                    color = NexusTextTertiary,
                    textAlign = TextAlign.Center
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Center Neural Orb with soundwave visualizer
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            NexusOrb(
                state = orbState,
                audioAmplitude = rmsAmplitude,
                size = 230.dp,
                onClick = { handleMicClick() }
            )

            Spacer(modifier = Modifier.height(18.dp))

            VoiceWaveVisualizer(
                isActive = isListening || isSpeaking,
                amplitude = rmsAmplitude,
                modifier = Modifier.padding(horizontal = 24.dp)
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Subtitle text (live transcription or prompt preview)
            if (partialText.isNotBlank()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = NexusSurfaceElevated,
                    border = androidx.compose.foundation.BorderStroke(1.dp, NexusCyan.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "«$partialText»",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = NexusCyan,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            } else if (speechError != null) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = NexusRose.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NexusRose.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = speechError ?: "",
                        fontSize = 13.sp,
                        color = NexusRose,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Error banner if any
        if (errorMessage != null) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = NexusRose.copy(alpha = 0.15f),
                border = androidx.compose.foundation.BorderStroke(1.dp, NexusRose.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
            ) {
                Text(
                    text = errorMessage ?: "",
                    fontSize = 12.sp,
                    color = NexusTextPrimary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(10.dp)
                )
            }
        }

        // Live generating or last answer card
        if ((isGenerating || lastResponse.isNotBlank()) && !isListening) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = NexusSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (isGenerating) NexusCyan.copy(alpha = 0.5f) else NexusBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isGenerating) "Генерация ответа..." else "Ответ ассистента ${settings.assistantName}:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = NexusCyan
                        )
                        Row {
                            if (isGenerating) {
                                IconButton(
                                    onClick = { viewModel.stopGeneration() },
                                    modifier = Modifier.size(32.dp).testTag("stop_voice_generation")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Stop,
                                        contentDescription = "Остановить генерацию",
                                        tint = NexusRose,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            } else if (isSpeaking) {
                                IconButton(
                                    onClick = { viewModel.stopSpeaking() },
                                    modifier = Modifier.size(32.dp).testTag("stop_voice_playback")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Stop,
                                        contentDescription = "Остановить речь",
                                        tint = NexusRose,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            } else if (lastResponse.isNotBlank()) {
                                IconButton(
                                    onClick = { viewModel.speakText(lastResponse) },
                                    modifier = Modifier.size(32.dp).testTag("replay_voice_playback")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.VolumeUp,
                                        contentDescription = "Озвучить",
                                        tint = NexusCyan,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                    val displayText = if (isGenerating && streamingResponse.isNotBlank()) {
                        streamingResponse
                    } else if (isGenerating) {
                        "NEXUS формирует ответ через Gemini с учётом контекста..."
                    } else {
                        lastResponse.take(280) + if (lastResponse.length > 280) "..." else ""
                    }
                    Text(
                        text = displayText,
                        fontSize = 13.sp,
                        color = if (isGenerating && streamingResponse.isBlank()) NexusCyan else NexusTextPrimary,
                        lineHeight = 18.sp
                    )
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        // Quick Text Voice-Over ("Озвучить свой текст") toggle + card
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(NexusSurfaceVariant)
                    .border(
                        1.dp,
                        if (showReaderCard) NexusCyan else NexusBorder,
                        RoundedCornerShape(12.dp)
                    )
                    .clickable { showReaderCard = !showReaderCard }
                    .padding(horizontal = 12.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.RecordVoiceOver,
                        contentDescription = null,
                        tint = NexusCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Озвучить свой текст (${settings.voicePreset.title.substringBefore(" ")})",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NexusTextPrimary
                    )
                }
                Text(
                    text = if (showReaderCard) "Скрыть" else "Открыть",
                    fontSize = 11.sp,
                    color = NexusCyan
                )
            }

            AnimatedVisibility(visible = showReaderCard) {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = NexusSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NexusCyan.copy(alpha = 0.45f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(VoicePreset.values().filter { it != VoicePreset.CUSTOM }) { preset ->
                                val active = settings.voicePreset == preset
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(if (active) NexusCyanDark else NexusSurfaceVariant)
                                        .border(1.dp, if (active) NexusCyan else NexusBorder, RoundedCornerShape(10.dp))
                                        .clickable { viewModel.updateVoicePreset(preset) }
                                        .padding(horizontal = 10.dp, vertical = 5.dp)
                                ) {
                                    Text(
                                        text = preset.title.substringBefore(" ("),
                                        fontSize = 11.sp,
                                        color = if (active) NexusCyan else NexusTextSecondary,
                                        fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = textToRead,
                            onValueChange = { textToRead = it },
                            placeholder = {
                                Text(
                                    text = "Вставьте или введите любой текст для озвучивания...",
                                    fontSize = 12.sp,
                                    color = NexusTextTertiary
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("voice_reader_input"),
                            minLines = 2,
                            maxLines = 4,
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = NexusBackground,
                                unfocusedContainerColor = NexusBackground,
                                focusedBorderColor = NexusCyan,
                                unfocusedBorderColor = NexusBorder,
                                focusedTextColor = NexusTextPrimary,
                                unfocusedTextColor = NexusTextPrimary
                            )
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    if (textToRead.isNotBlank()) {
                                        viewModel.speakText(textToRead)
                                    }
                                },
                                enabled = textToRead.isNotBlank(),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = NexusCyan,
                                    contentColor = NexusBackground
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("voice_reader_play_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VolumeUp,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Озвучить", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            }
                            if (isSpeaking) {
                                Button(
                                    onClick = { viewModel.stopSpeaking() },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = NexusRose.copy(alpha = 0.2f),
                                        contentColor = NexusRose
                                    )
                                ) {
                                    Text("Стоп", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "Быстрые голосовые команды:",
                fontSize = 11.sp,
                color = NexusTextTertiary,
                modifier = Modifier.padding(bottom = 6.dp)
            )
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(quickQuestions) { question ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(NexusSurfaceVariant)
                            .border(1.dp, NexusBorder, RoundedCornerShape(12.dp))
                            .clickable {
                                viewModel.sendMessage(question, isFromVoice = true)
                            }
                            .padding(horizontal = 12.dp, vertical = 7.dp)
                    ) {
                        Text(
                            text = question,
                            fontSize = 12.sp,
                            color = NexusTextSecondary
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Main Voice Action Button & Chat switch
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Button to switch to Chat mode
            IconButton(
                onClick = onNavigateToChat,
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(NexusSurfaceVariant)
                    .border(1.dp, NexusBorder, CircleShape)
                    .testTag("switch_to_chat_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Chat,
                    contentDescription = "Перейти в текстовый чат",
                    tint = NexusCyan,
                    modifier = Modifier.size(24.dp)
                )
            }

            // Big glowing microphone button
            Box(
                modifier = Modifier
                    .size(76.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = if (isListening) listOf(NexusRose, Color(0xFF9F1239))
                            else listOf(NexusCyan, NexusCyanDark)
                        )
                    )
                    .clickable { handleMicClick() }
                    .testTag("main_mic_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isListening) Icons.Default.MicOff else Icons.Default.Mic,
                    contentDescription = if (isListening) "Остановить" else "Говорить",
                    tint = Color.White,
                    modifier = Modifier.size(34.dp)
                )
            }

            // Mute / Stop speech or generation button
            IconButton(
                onClick = {
                    when {
                        isGenerating -> viewModel.stopGeneration()
                        isSpeaking -> viewModel.stopSpeaking()
                        isListening -> viewModel.toggleVoiceListening()
                    }
                },
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(NexusSurfaceVariant)
                    .border(
                        1.dp,
                        if (isSpeaking || isGenerating) NexusRose.copy(alpha = 0.6f) else NexusBorder,
                        CircleShape
                    )
                    .testTag("stop_audio_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Stop,
                    contentDescription = "Остановить",
                    tint = if (isSpeaking || isGenerating) NexusRose else NexusTextTertiary,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}
