package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.localization.AppLang
import com.example.localization.SjsStrings
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.theme.*

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProviderConsoleScreen(
    lang: AppLang,
    myProvider: SecurityProvider?,
    services: List<SecurityServiceListing>,
    providerOrders: List<SecurityOrder>,
    userProfile: UserProfile?,
    isBusy: Boolean,
    onRegisterProvider: (
        companyName: String,
        description: String,
        categories: List<ServiceCategory>,
        locations: List<String>,
        startingPriceTzs: Long,
        businessRegNumber: String,
        securityLicenseNumber: String,
        contactPhone: String,
        revenueModel: RevenueModel,
        logoBase64: String?,
        galleryBase64: List<String>
    ) -> Unit,
    onSwitchRevenueModel: (String, RevenueModel) -> Unit,
    onCreateService: (
        provider: SecurityProvider,
        category: ServiceCategory,
        title: String,
        description: String,
        priceTzs: Long,
        priceUnit: String,
        location: String,
        offerBadge: String?,
        discountPercent: Long
    ) -> Unit,
    onDeleteService: (String) -> Unit,
    onInitiateSubscriptionPayment: (SecurityProvider, String, (PaymentTransaction) -> Unit) -> Unit,
    onVerifySubscriptionPayment: (PaymentTransaction) -> Unit,
    onOpenProviderOrders: () -> Unit
) {
    var showAddServiceDialog by remember { mutableStateOf(false) }
    var showSubscriptionPayDialog by remember { mutableStateOf(false) }
    var pendingSubPayment by remember { mutableStateOf<PaymentTransaction?>(null) }

    if (myProvider == null) {
        ProviderRegistrationForm(
            lang = lang,
            userProfile = userProfile,
            isBusy = isBusy,
            onRegister = onRegisterProvider
        )
        return
    }

    val myServices = remember(services, myProvider.id) {
        services.filter { it.providerId == myProvider.id }
    }
    val daysLeft = myProvider.daysUntilSubscriptionExpiry()
    val showRenewalWarning = myProvider.revenueEnum() == RevenueModel.MONTHLY_SUBSCRIPTION &&
        (daysLeft == null || daysLeft <= 5L)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(OffWhite),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Verification & Company Header
        item {
            Card(colors = CardDefaults.cardColors(containerColor = NavyDeep), shape = RoundedCornerShape(18.dp)) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(myProvider.companyName, style = MaterialTheme.typography.titleLarge, color = PureWhite)
                            Text("BRELA: ${myProvider.businessRegNumber} • ${myProvider.securityLicenseNumber}", style = MaterialTheme.typography.labelSmall, color = BorderGrey)
                        }
                        VerifiedBadgeChip(lang = lang, verified = myProvider.verifiedBadge)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = onOpenProviderOrders,
                            colors = ButtonDefaults.buttonColors(containerColor = OrangeBrand),
                            modifier = Modifier.weight(1f).testTag("provider_view_orders_button")
                        ) {
                            Icon(Icons.Filled.Assignment, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("${SjsStrings.t(lang, "Oda", "Orders")} (${providerOrders.size})")
                        }
                        OutlinedButton(
                            onClick = { showAddServiceDialog = true },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = PureWhite),
                            modifier = Modifier.weight(1f).testTag("provider_add_service_button")
                        ) {
                            Icon(Icons.Filled.Add, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(4.dp))
                            Text(SjsStrings.t(lang, "Weka Huduma", "Add Service"))
                        }
                    }
                }
            }
        }

        // 2. Earnings & Commission Statements
        item {
            Card(colors = CardDefaults.cardColors(containerColor = PureWhite), shape = RoundedCornerShape(18.dp)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = SjsStrings.t(lang, "Mapato & Taarifa ya Kamisheni", "Earnings & Commission Statements"),
                        style = MaterialTheme.typography.titleMedium,
                        color = NavyDeep
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MetricTile(
                            label = SjsStrings.t(lang, "Jumla ya Mapato", "Total Earnings"),
                            value = TzsFormatter.format(myProvider.totalEarningsTzs),
                            color = NavyDeep,
                            modifier = Modifier.weight(1f)
                        )
                        MetricTile(
                            label = SjsStrings.t(lang, "Oda Kamili", "Completed"),
                            value = myProvider.completedOrdersCount.toString(),
                            color = VerifiedGreen,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MetricTile(
                            label = SjsStrings.t(lang, "Kamisheni Inayodaiwa", "Commission Owed (5%)"),
                            value = TzsFormatter.format(myProvider.commissionOwedTzs),
                            color = OrangeBrand,
                            modifier = Modifier.weight(1f)
                        )
                        MetricTile(
                            label = SjsStrings.t(lang, "Kamisheni Iliyolipwa", "Commission Paid"),
                            value = TzsFormatter.format(myProvider.commissionCollectedTzs),
                            color = CharcoalGrey,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // 3. Smart Jones Revenue System (Mutually Exclusive)
        item {
            Card(colors = CardDefaults.cardColors(containerColor = PureWhite), shape = RoundedCornerShape(18.dp)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = SjsStrings.t(lang, "Mfumo wa Malipo ya Jukwaa (Chagua Mmoja)", "Platform Revenue Plan (Select One)"),
                        style = MaterialTheme.typography.titleMedium,
                        color = NavyDeep
                    )
                    Text(
                        text = SjsStrings.t(
                            lang,
                            "Chagua mfumo mmoja pekee. Hautatozwa mifumo yote miwili kwa pamoja.",
                            "Choose strictly one billing model. Never charged both simultaneously."
                        ),
                        style = MaterialTheme.typography.bodySmall,
                        color = SlateGrey
                    )

                    val isCommission = myProvider.revenueEnum() == RevenueModel.COMMISSION
                    Surface(
                        color = if (isCommission) OrangeContainer else SurfaceVariantLight,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().clickable {
                            onSwitchRevenueModel(myProvider.id, RevenueModel.COMMISSION)
                        }
                    ) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = isCommission, onClick = {
                                onSwitchRevenueModel(myProvider.id, RevenueModel.COMMISSION)
                            })
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text(SjsStrings.t(lang, "CHAGUO A: Kamisheni ya 5%", "OPTION A: 5% Commission"), style = MaterialTheme.typography.titleSmall, color = NavyDeep)
                                Text(
                                    SjsStrings.t(lang, "5% kwa kila oda iliyokamilika na kulipwa", "5% of every completed and paid order"),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CharcoalGrey
                                )
                            }
                        }
                    }

                    Surface(
                        color = if (!isCommission) OrangeContainer else SurfaceVariantLight,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().clickable {
                            onSwitchRevenueModel(myProvider.id, RevenueModel.MONTHLY_SUBSCRIPTION)
                        }
                    ) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = !isCommission, onClick = {
                                onSwitchRevenueModel(myProvider.id, RevenueModel.MONTHLY_SUBSCRIPTION)
                            })
                            Spacer(Modifier.width(8.dp))
                            Column(Modifier.weight(1f)) {
                                Text(SjsStrings.t(lang, "CHAGUO B: Ada ya Mwezi (TZS 20,000)", "OPTION B: Monthly Subscription (TZS 20,000)"), style = MaterialTheme.typography.titleSmall, color = NavyDeep)
                                Text(
                                    SjsStrings.t(lang, "0% kamisheni • Pokea oda bila kikomo kwa siku 30", "0% commission • Unlimited orders for 30 days"),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CharcoalGrey
                                )
                            }
                        }
                    }

                    if (!isCommission) {
                        if (showRenewalWarning) {
                            Surface(color = WarningAmberContainer, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = if ((daysLeft ?: 0L) <= 0L) {
                                        SjsStrings.t(
                                            lang,
                                            "Ilani: Usajili wako wa mwezi umeisha. Lipa TZS 20,000 kupokea oda.",
                                            "Renewal Alert: Your monthly subscription has expired. Pay TZS 20,000 to receive orders."
                                        )
                                    } else {
                                        SjsStrings.t(
                                            lang,
                                            "Ilani ya Uhuishaji: Zimebaki siku $daysLeft kabla usajili kuisha.",
                                            "Renewal Reminder: $daysLeft day(s) remaining before subscription expires."
                                        )
                                    },
                                    style = MaterialTheme.typography.labelMedium,
                                    color = WarningAmber,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                        } else {
                            Text(
                                text = SjsStrings.t(lang, "Usajili Hai • Siku $daysLeft zimebaki", "Active Subscription • $daysLeft days remaining"),
                                style = MaterialTheme.typography.labelMedium,
                                color = VerifiedGreen
                            )
                        }

                        Button(
                            onClick = { showSubscriptionPayDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = OrangeBrand),
                            modifier = Modifier.fillMaxWidth().testTag("pay_subscription_button")
                        ) {
                            Icon(Icons.Filled.Payments, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(SjsStrings.t(lang, "Lipa / Huisha TZS 20,000 (Airtel Money)", "Pay / Renew TZS 20,000 (Airtel Money)"))
                        }
                    }
                }
            }
        }

        // 4. My Service Catalog
        item {
            Text(
                text = SjsStrings.t(lang, "Huduma Zangu (${myServices.size})", "My Listed Services (${myServices.size})"),
                style = MaterialTheme.typography.titleLarge,
                color = NavyDeep
            )
        }

        if (myServices.isEmpty()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = PureWhite), modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = SjsStrings.t(lang, "Bado hujaongeza huduma. Bonyeza 'Weka Huduma' kuanza.", "No services listed yet. Tap 'Add Service' to publish pricing."),
                        style = MaterialTheme.typography.bodyMedium,
                        color = SlateGrey,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        } else {
            items(myServices, key = { it.id }) { srv ->
                Card(colors = CardDefaults.cardColors(containerColor = PureWhite), shape = RoundedCornerShape(14.dp)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(srv.title, style = MaterialTheme.typography.titleSmall, color = NavyDeep)
                            Text("${TzsFormatter.format(srv.priceTzs)} (${srv.priceUnit}) • ${srv.location}", style = MaterialTheme.typography.bodySmall, color = OrangeBrand)
                        }
                        IconButton(onClick = { onDeleteService(srv.id) }) {
                            Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete service", tint = ErrorRed)
                        }
                    }
                }
            }
        }
    }

    if (showAddServiceDialog) {
        AddServiceDialog(
            lang = lang,
            isBusy = isBusy,
            onCreate = { cat, title, desc, price, unit, loc, badge, disc ->
                onCreateService(myProvider, cat, title, desc, price, unit, loc, badge, disc)
                showAddServiceDialog = false
            },
            onDismiss = { showAddServiceDialog = false }
        )
    }

    if (showSubscriptionPayDialog) {
        AirtelPaymentDialog(
            lang = lang,
            title = SjsStrings.t(lang, "Usajili wa Mwezi (TZS 20,000)", "Monthly Subscription (TZS 20,000)"),
            amountTzs = MarketplaceConstants.MONTHLY_SUBSCRIPTION_FEE_TZS,
            defaultPhone = myProvider.contactPhone,
            pendingPayment = pendingSubPayment,
            isBusy = isBusy,
            onInitiate = { phone ->
                onInitiateSubscriptionPayment(myProvider, phone) { tx ->
                    pendingSubPayment = tx
                }
            },
            onVerifySandboxCallback = { tx ->
                onVerifySubscriptionPayment(tx)
                showSubscriptionPayDialog = false
                pendingSubPayment = null
            },
            onDismiss = {
                showSubscriptionPayDialog = false
                pendingSubPayment = null
            }
        )
    }
}

@Composable
private fun MetricTile(label: String, value: String, color: androidx.compose.ui.graphics.Color, modifier: Modifier = Modifier) {
    Surface(color = SurfaceVariantLight, shape = RoundedCornerShape(12.dp), modifier = modifier) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, style = MaterialTheme.typography.bodySmall, color = SlateGrey)
            Text(value, style = MaterialTheme.typography.titleSmall, color = color)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ProviderRegistrationForm(
    lang: AppLang,
    userProfile: UserProfile?,
    isBusy: Boolean,
    onRegister: (String, String, List<ServiceCategory>, List<String>, Long, String, String, String, RevenueModel, String?, List<String>) -> Unit
) {
    val context = LocalContext.current
    var companyName by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var brela by remember { mutableStateOf("") }
    var psra by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf(userProfile?.phone ?: "07") }
    var startingPrice by remember { mutableStateOf("250000") }
    var selectedCategories by remember { mutableStateOf(setOf(ServiceCategory.SECURITY_GUARDS)) }
    var selectedLocations by remember { mutableStateOf(setOf("Dar es Salaam")) }
    var revenueModel by remember { mutableStateOf(RevenueModel.COMMISSION) }
    var logoBase64 by remember { mutableStateOf<String?>(null) }
    var galleryBase64 by remember { mutableStateOf<List<String>>(emptyList()) }

    val logoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        uri?.let { logoBase64 = PhotoCodec.uriToCompressedBase64(context, it, maxDim = 320) }
    }
    val galleryPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(3)) { uris ->
        galleryBase64 = uris.mapNotNull { PhotoCodec.uriToCompressedBase64(context, it, maxDim = 360) }.take(3)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(OffWhite),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = NavyDeep), shape = RoundedCornerShape(18.dp)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = SjsStrings.t(lang, "Sajili Kampuni ya Usalama", "Register Your Security Company"),
                        style = MaterialTheme.typography.titleLarge,
                        color = PureWhite
                    )
                    Text(
                        text = SjsStrings.t(
                            lang,
                            "Wasilisha usajili wa BRELA na leseni ya usalama ili kupata beji ya uhakiki kutoka kwa Admin.",
                            "Submit BRELA & security license details to get Admin Verified Badge."
                        ),
                        style = MaterialTheme.typography.bodySmall,
                        color = BorderGrey
                    )
                }
            }
        }

        item {
            Card(colors = CardDefaults.cardColors(containerColor = PureWhite), shape = RoundedCornerShape(18.dp)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = companyName, onValueChange = { companyName = it }, label = { Text(SjsStrings.t(lang, "Jina la Kampuni", "Company Name")) }, singleLine = true, modifier = Modifier.fillMaxWidth().testTag("reg_company_name"))
                    OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text(SjsStrings.t(lang, "Maelezo ya Kampuni (min 10 chars)", "Company Description")) }, minLines = 3, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = brela, onValueChange = { brela = it }, label = { Text("BRELA Registration No.") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = psra, onValueChange = { psra = it }, label = { Text(SjsStrings.t(lang, "Leseni ya Usalama (PSRA)", "Security License No.")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text(SjsStrings.t(lang, "Simu ya Kampuni", "Contact Phone")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = startingPrice, onValueChange = { startingPrice = it.filter { c -> c.isDigit() } }, label = { Text(SjsStrings.t(lang, "Bei ya Kuanzia (TZS)", "Starting Price (TZS)")) }, singleLine = true, modifier = Modifier.fillMaxWidth())

                    Text(SjsStrings.t(lang, "Huduma Mnazotoa", "Service Categories"), style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ServiceCategory.entries.forEach { cat ->
                            val sel = cat in selectedCategories
                            FilterChip(
                                selected = sel,
                                onClick = {
                                    selectedCategories = if (sel && selectedCategories.size > 1) selectedCategories - cat else selectedCategories + cat
                                },
                                label = { Text(SjsStrings.categoryLabel(cat, lang)) }
                            )
                        }
                    }

                    Text(SjsStrings.t(lang, "Mikoa Mnayohudumia", "Service Locations"), style = MaterialTheme.typography.labelLarge)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        MarketplaceConstants.TANZANIA_LOCATIONS.forEach { loc ->
                            val sel = loc in selectedLocations
                            FilterChip(
                                selected = sel,
                                onClick = {
                                    selectedLocations = if (sel && selectedLocations.size > 1) selectedLocations - loc else selectedLocations + loc
                                },
                                label = { Text(loc) }
                            )
                        }
                    }

                    Text(SjsStrings.t(lang, "Chagua Mfumo wa Mapato (Moja tu)", "Revenue Model (Select One)"), style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = revenueModel == RevenueModel.COMMISSION,
                            onClick = { revenueModel = RevenueModel.COMMISSION },
                            label = { Text("5% Commission") }
                        )
                        FilterChip(
                            selected = revenueModel == RevenueModel.MONTHLY_SUBSCRIPTION,
                            onClick = { revenueModel = RevenueModel.MONTHLY_SUBSCRIPTION },
                            label = { Text("TZS 20,000 / Mo") }
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { logoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(if (logoBase64 != null) "Logo ✓" else SjsStrings.t(lang, "Pakia Nembo", "Upload Logo"))
                        }
                        OutlinedButton(
                            onClick = { galleryPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("${SjsStrings.t(lang, "Picha", "Photos")} (${galleryBase64.size}/3)")
                        }
                    }

                    Button(
                        onClick = {
                            onRegister(
                                companyName, description, selectedCategories.toList(), selectedLocations.toList(),
                                startingPrice.toLongOrNull() ?: 0L, brela, psra, phone, revenueModel,
                                logoBase64, galleryBase64
                            )
                        },
                        enabled = !isBusy && companyName.trim().length >= 2 && description.trim().length >= 10 &&
                            brela.trim().length >= 2 && psra.trim().length >= 2 && phone.trim().length >= 6,
                        colors = ButtonDefaults.buttonColors(containerColor = OrangeBrand),
                        modifier = Modifier.fillMaxWidth().height(50.dp).testTag("submit_provider_registration_button")
                    ) {
                        Text(SjsStrings.t(lang, "Wasilisha kwa Uhakiki", "Submit Company for Verification"))
                    }
                }
            }
        }
    }
}

@Composable
private fun AddServiceDialog(
    lang: AppLang,
    isBusy: Boolean,
    onCreate: (ServiceCategory, String, String, Long, String, String, String?, Long) -> Unit,
    onDismiss: () -> Unit
) {
    var category by remember { mutableStateOf(ServiceCategory.SECURITY_GUARDS) }
    var title by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var priceStr by remember { mutableStateOf("") }
    var unit by remember { mutableStateOf("kwa mwezi") }
    var location by remember { mutableStateOf("Dar es Salaam") }
    var offerBadge by remember { mutableStateOf("") }
    var discountStr by remember { mutableStateOf("0") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(SjsStrings.t(lang, "Ongeza Huduma Mpya", "Add Security Service")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ServiceCategory.entries.forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(SjsStrings.categoryLabel(cat, lang)) }
                        )
                    }
                }
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text(SjsStrings.t(lang, "Kichwa cha Huduma", "Service Title")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text(SjsStrings.t(lang, "Maelezo", "Description")) }, minLines = 2, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = priceStr, onValueChange = { priceStr = it.filter { c -> c.isDigit() } }, label = { Text("Bei (TZS)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = unit, onValueChange = { unit = it }, label = { Text(SjsStrings.t(lang, "Kipimo (mf. kwa mwezi)", "Unit")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = location, onValueChange = { location = it }, label = { Text(SjsStrings.t(lang, "Mkoa", "Region")) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = offerBadge, onValueChange = { offerBadge = it }, label = { Text("Offer Badge") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = discountStr, onValueChange = { discountStr = it.filter { c -> c.isDigit() } }, label = { Text("Disc %") }, singleLine = true, modifier = Modifier.width(90.dp))
                }
            }
        },
        confirmButton = {
            val price = priceStr.toLongOrNull() ?: 0L
            Button(
                onClick = {
                    onCreate(category, title, desc, price, unit, location, offerBadge.ifBlank { null }, discountStr.toLongOrNull() ?: 0L)
                },
                enabled = !isBusy && title.trim().length >= 3 && desc.trim().length >= 5 && price >= 1000L,
                colors = ButtonDefaults.buttonColors(containerColor = OrangeBrand)
            ) {
                Text(SjsStrings.t(lang, "Hifadhi", "Publish"))
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(SjsStrings.t(lang, "Ghairi", "Cancel")) } }
    )
}
