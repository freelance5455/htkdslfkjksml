package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.AppLanguage
import com.example.data.model.GenderOption
import com.example.data.model.SexualityOption
import com.example.data.model.UserProfile
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OnboardingScreen(
    initialProfile: UserProfile,
    onCompleteOnboarding: (UserProfile) -> Unit
) {
    var name by remember { mutableStateOf(initialProfile.name) }
    var ageSlider by remember { mutableFloatStateOf(initialProfile.age.toFloat()) }
    var ageVerified by remember { mutableStateOf(false) }
    var selectedGender by remember { mutableStateOf(initialProfile.gender) }
    var selectedSexuality by remember { mutableStateOf(initialProfile.sexuality) }
    var selectedLanguage by remember { mutableStateOf(initialProfile.language) }
    var backupEmail by remember { mutableStateOf(initialProfile.backupEmail) }
    var emergencyNumber by remember { mutableStateOf(initialProfile.emergencyAuthorityNumber) }
    var isDataFree by remember { mutableStateOf(initialProfile.isDataFreeMode) }
    var biometricEnabled by remember { mutableStateOf(initialProfile.biometricLockEnabled) }
    var errorText by remember { mutableStateOf<String?>(null) }

    val ageInt = ageSlider.roundToInt()

    Scaffold { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp)
                .widthIn(max = 600.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_daily_haven),
                contentDescription = "Haven teen wellness banner",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .clip(RoundedCornerShape(24.dp)),
                contentScale = ContentScale.Crop
            )

            Text(
                text = "Welcome to Haven",
                style = MaterialTheme.typography.displaySmall,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "A private, ad-free teen sanctuary for your daily care, feelings, body health, phone control, and safety.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.Shield,
                        contentDescription = "Zero ads privacy badge",
                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "100% Private: No ads, no third-party trackers. Everything stays securely on your phone.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Global Language
            Text("Global Language", style = MaterialTheme.typography.titleMedium)
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                AppLanguage.entries.forEach { lang ->
                    FilterChip(
                        selected = selectedLanguage == lang,
                        onClick = { selectedLanguage = lang },
                        label = { Text(lang.nativeName) }
                    )
                }
            }

            // Name & Backup Email
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Nickname or First Name") },
                leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("onboarding_name_input")
            )

            OutlinedTextField(
                value = backupEmail,
                onValueChange = { backupEmail = it },
                label = { Text("Backup Email (for Diary & Health Exports)") },
                leadingIcon = { Icon(Icons.Filled.Email, contentDescription = null) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("onboarding_email_input")
            )

            // Teen Age Verification (13-19)
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.VerifiedUser, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Teen Age Verification: $ageInt years old",
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                    Slider(
                        value = ageSlider,
                        onValueChange = { ageSlider = it },
                        valueRange = 12f..19f,
                        steps = 6,
                        modifier = Modifier.testTag("age_slider")
                    )
                    if (ageInt < 13) {
                        Text(
                            text = "Haven is designed specifically for teens aged 13–19. Please use with a parent or guardian if under 13.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(top = 4.dp)
                    ) {
                        Checkbox(
                            checked = ageVerified,
                            onCheckedChange = { ageVerified = it },
                            modifier = Modifier.testTag("age_verify_checkbox")
                        )
                        Text(
                            text = "I verify my age ($ageInt) is accurate for teen wellness guidance.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }

            // Gender & Sexuality
            Text("Gender (tailors your health tracker)", style = MaterialTheme.typography.titleMedium)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GenderOption.entries.forEach { gender ->
                    FilterChip(
                        selected = selectedGender == gender,
                        onClick = { selectedGender = gender },
                        modifier = Modifier.testTag("gender_${gender.key}"),
                        label = { Text(gender.label) }
                    )
                }
            }

            Text("Sexuality / Identity (stored privately)", style = MaterialTheme.typography.titleMedium)
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                SexualityOption.entries.forEach { sex ->
                    FilterChip(
                        selected = selectedSexuality == sex,
                        onClick = { selectedSexuality = sex },
                        label = { Text(sex.label) }
                    )
                }
            }

            OutlinedTextField(
                value = emergencyNumber,
                onValueChange = { emergencyNumber = it },
                label = { Text("Local Authority Emergency Number (e.g. 911, 112, 10111)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            // Data / Data-Free + Biometrics
            Card {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.CloudOff, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Data-Free Offline Mode", style = MaterialTheme.typography.titleSmall)
                                Text(
                                    "Works 100% without mobile data",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Switch(
                            checked = isDataFree,
                            onCheckedChange = { isDataFree = it },
                            modifier = Modifier.testTag("onboarding_data_free_switch")
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Fingerprint, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Biometric Privacy Lock", style = MaterialTheme.typography.titleSmall)
                                Text(
                                    "Protect diary, hormone & identity logs",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Switch(
                            checked = biometricEnabled,
                            onCheckedChange = { biometricEnabled = it },
                            modifier = Modifier.testTag("onboarding_biometric_switch")
                        )
                    }
                }
            }

            if (errorText != null) {
                Text(
                    text = errorText!!,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            Button(
                onClick = {
                    when {
                        ageInt < 13 -> errorText = "Age must be between 13 and 19 to continue independently."
                        !ageVerified -> errorText = "Please confirm the age verification checkbox above."
                        else -> {
                            onCompleteOnboarding(
                                initialProfile.copy(
                                    name = name.trim().ifBlank { "Friend" },
                                    age = ageInt,
                                    ageVerified = true,
                                    gender = selectedGender,
                                    sexuality = selectedSexuality,
                                    backupEmail = backupEmail.trim(),
                                    language = selectedLanguage,
                                    isDataFreeMode = isDataFree,
                                    biometricLockEnabled = biometricEnabled,
                                    emergencyAuthorityNumber = emergencyNumber.trim().ifBlank { "112" },
                                    onboardingCompleted = true
                                )
                            )
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("complete_onboarding_button")
            ) {
                Icon(Icons.Filled.CheckCircle, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Enter My Haven")
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
