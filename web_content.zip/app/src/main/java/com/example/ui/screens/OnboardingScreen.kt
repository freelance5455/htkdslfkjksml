package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.data.repository.SampleData
import com.example.ui.components.LocationExplanationDialog
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun OnboardingScreen(
    onFinishOnboarding: (
        name: String,
        role: UserRole,
        age: Int,
        profession: String,
        location: String,
        locationGranted: Boolean
    ) -> Unit
) {
    var step by remember { mutableStateOf(0) }
    var selectedRole by remember { mutableStateOf(UserRole.CONSUMER) }

    // Common fields
    var locationGranted by remember { mutableStateOf(false) }
    var showLocationExplainer by remember { mutableStateOf(false) }
    var locationString by remember { mutableStateOf("Downtown Innovation District, New Tech City") }
    var ageText by remember { mutableStateOf("26") }
    var selectedProfession by remember { mutableStateOf(SampleData.sampleProfessions.first()) }
    var customProfession by remember { mutableStateOf("") }
    var fullName by remember { mutableStateOf("Alex Vance") }
    var email by remember { mutableStateOf("alex@ignis.market") }
    var phone by remember { mutableStateOf("+1 (555) 302-8812") }

    // Role-specific fields
    // Consumer: Interests
    val consumerInterests = remember {
        mutableStateListOf("Electronics", "Gadgets", "Eco-Friendly Products", "Home & Living")
    }

    // Seller: Store name, categories, description, delivery area
    var storeName by remember { mutableStateOf("Vance Innovative Labs") }
    var storeDescription by remember { mutableStateOf("Design studio crafting smart home gadgets and modular everyday accessories.") }
    val sellerCategories = remember { mutableStateListOf("Electronics", "Gadgets", "Creative Products") }
    var deliveryRadiusKm by remember { mutableStateOf("25") }

    // Delivery Partner: Vehicle, experience, area, availability
    var selectedVehicle by remember { mutableStateOf(VehicleType.MOTORCYCLE) }
    var experienceYears by remember { mutableStateOf("3") }
    var approximateArea by remember { mutableStateOf("Metro Downtown & Surrounding Tech Corridors") }
    var isAvailableImmediate by remember { mutableStateOf(true) }

    if (showLocationExplainer) {
        LocationExplanationDialog(
            onDismiss = { showLocationExplainer = false },
            onGrant = {
                locationGranted = true
                locationString = "Downtown Innovation District (~1.8 km radius)"
                showLocationExplainer = false
            },
            onDeny = {
                locationGranted = false
                locationString = "Manual Region (Location permission denied)"
                showLocationExplainer = false
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "IGNIS",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                color = IgnisOrangePrimary
                            )
                        )
                        Text(
                            text = when (step) {
                                0 -> "• Choose Role"
                                1 -> "• Location & Profile"
                                2 -> "• Account Setup"
                                else -> "• Preferences"
                            },
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                },
                navigationIcon = {
                    if (step > 0) {
                        IconButton(onClick = { step-- }) {
                            Icon(imageVector = Icons.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            // Step Progress Indicator
            LinearProgressIndicator(
                progress = { (step + 1) / 4f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = IgnisOrangePrimary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            Spacer(modifier = Modifier.height(20.dp))

            AnimatedContent(
                targetState = step,
                transitionSpec = {
                    if (targetState > initialState) {
                        slideInHorizontally { width -> width } + fadeIn() togetherWith
                                slideOutHorizontally { width -> -width } + fadeOut()
                    } else {
                        slideInHorizontally { width -> -width } + fadeIn() togetherWith
                                slideOutHorizontally { width -> width } + fadeOut()
                    }
                },
                modifier = Modifier.weight(1f),
                label = "onboarding_steps"
            ) { currentStep ->
                when (currentStep) {
                    0 -> RoleSelectionStep(
                        selectedRole = selectedRole,
                        onRoleSelect = { selectedRole = it }
                    )
                    1 -> LocationAndProfileStep(
                        locationGranted = locationGranted,
                        locationString = locationString,
                        onRequestLocation = { showLocationExplainer = true },
                        age = ageText,
                        onAgeChange = { ageText = it },
                        selectedProfession = selectedProfession,
                        onProfessionSelect = { selectedProfession = it },
                        customProfession = customProfession,
                        onCustomProfessionChange = { customProfession = it }
                    )
                    2 -> AccountStep(
                        fullName = fullName,
                        onNameChange = { fullName = it },
                        email = email,
                        onEmailChange = { email = it },
                        phone = phone,
                        onPhoneChange = { phone = it },
                        role = selectedRole
                    )
                    3 -> RoleCustomizationStep(
                        role = selectedRole,
                        consumerInterests = consumerInterests,
                        storeName = storeName,
                        onStoreNameChange = { storeName = it },
                        storeDescription = storeDescription,
                        onStoreDescriptionChange = { storeDescription = it },
                        sellerCategories = sellerCategories,
                        deliveryRadius = deliveryRadiusKm,
                        onDeliveryRadiusChange = { deliveryRadiusKm = it },
                        selectedVehicle = selectedVehicle,
                        onVehicleSelect = { selectedVehicle = it },
                        experienceYears = experienceYears,
                        onExperienceChange = { experienceYears = it },
                        approximateArea = approximateArea,
                        onAreaChange = { approximateArea = it },
                        isAvailableImmediate = isAvailableImmediate,
                        onAvailabilityToggle = { isAvailableImmediate = it }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Navigation Button
            Button(
                onClick = {
                    if (step < 3) {
                        step++
                    } else {
                        val finalProfession = if (selectedProfession == "Other") customProfession else selectedProfession
                        onFinishOnboarding(
                            fullName,
                            selectedRole,
                            ageText.toIntOrNull() ?: 25,
                            finalProfession,
                            locationString,
                            locationGranted
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("onboarding_continue_button"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = IgnisOrangePrimary)
            ) {
                Text(
                    text = if (step == 3) "Enter Ignis Marketplace" else "Continue",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Icon(
                    imageVector = Icons.Filled.ArrowForward,
                    contentDescription = null,
                    tint = Color.White
                )
            }
        }
    }
}

@Composable
private fun RoleSelectionStep(
    selectedRole: UserRole,
    onRoleSelect: (UserRole) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "How will you use Ignis?",
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
        )
        Text(
            text = "Ignis coordinates Consumers, Innovators, and local Delivery Partners in one unified ecosystem.",
            style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
        )

        Spacer(modifier = Modifier.height(8.dp))

        UserRole.values().forEach { role ->
            val isSelected = role == selectedRole
            val (icon, accentColor) = when (role) {
                UserRole.CONSUMER -> Icons.Filled.ShoppingBag to IgnisOrangePrimary
                UserRole.SELLER -> Icons.Filled.Storefront to IgnisTechBlue
                UserRole.DELIVERY_PARTNER -> Icons.Filled.TwoWheeler to IgnisEmerald
            }

            Card(
                shape = RoundedCornerShape(20.dp),
                border = BorderStroke(
                    width = if (isSelected) 2.dp else 1.dp,
                    color = if (isSelected) accentColor else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                ),
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) accentColor.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("role_card_${role.name}")
                    .clip(RoundedCornerShape(20.dp))
                    .clickable { onRoleSelect(role) }
            ) {
                Row(
                    modifier = Modifier.padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(if (isSelected) accentColor else MaterialTheme.colorScheme.surfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = role.label,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) accentColor else MaterialTheme.colorScheme.onSurface
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = role.description,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }

                    RadioButton(
                        selected = isSelected,
                        onClick = { onRoleSelect(role) },
                        colors = RadioButtonDefaults.colors(selectedColor = accentColor)
                    )
                }
            }
        }
    }
}

@Composable
private fun LocationAndProfileStep(
    locationGranted: Boolean,
    locationString: String,
    onRequestLocation: () -> Unit,
    age: String,
    onAgeChange: (String) -> Unit,
    selectedProfession: String,
    onProfessionSelect: (String) -> Unit,
    customProfession: String,
    onCustomProfessionChange: (String) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Text(
                text = "Location & Basic Profile",
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
            )
            Text(
                text = "Ignis connects local innovators and nearby delivery networks.",
                style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
            )
        }

        // Location Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.MyLocation,
                            contentDescription = null,
                            tint = if (locationGranted) IgnisEmerald else IgnisOrangePrimary
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (locationGranted) "Location Access Enabled" else "Device Location Access",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = locationString,
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = onRequestLocation,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (locationGranted) MaterialTheme.colorScheme.surface else IgnisOrangePrimary,
                            contentColor = if (locationGranted) MaterialTheme.colorScheme.onSurface else Color.White
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (locationGranted) "Change Location Permissions" else "Request Location Permission")
                    }
                }
            }
        }

        // Age Input
        item {
            OutlinedTextField(
                value = age,
                onValueChange = onAgeChange,
                label = { Text("Your Age") },
                placeholder = { Text("e.g. 26") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            )
        }

        // Profession Selection
        item {
            Text(
                text = "Profession",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                SampleData.sampleProfessions.forEach { profession ->
                    val isSelected = profession == selectedProfession
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) IgnisOrangePrimary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface,
                        border = BorderStroke(
                            1.dp,
                            if (isSelected) IgnisOrangePrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onProfessionSelect(profession) }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = profession,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) IgnisOrangePrimary else MaterialTheme.colorScheme.onSurface
                                )
                            )
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Filled.Check,
                                    contentDescription = null,
                                    tint = IgnisOrangePrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }

                if (selectedProfession == "Other") {
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = customProfession,
                        onValueChange = onCustomProfessionChange,
                        label = { Text("Enter your profession") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun AccountStep(
    fullName: String,
    onNameChange: (String) -> Unit,
    email: String,
    onEmailChange: (String) -> Unit,
    phone: String,
    onPhoneChange: (String) -> Unit,
    role: UserRole
) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Ignis Account Credentials",
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
        )
        Text(
            text = "Setting up access for ${role.label}. Ready for secure authentication.",
            style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = fullName,
            onValueChange = onNameChange,
            label = { Text("Full Name") },
            leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp)
        )

        OutlinedTextField(
            value = email,
            onValueChange = onEmailChange,
            label = { Text("Email Address") },
            leadingIcon = { Icon(Icons.Filled.Email, contentDescription = null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp)
        )

        OutlinedTextField(
            value = phone,
            onValueChange = onPhoneChange,
            label = { Text("Phone Number") },
            leadingIcon = { Icon(Icons.Filled.Phone, contentDescription = null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp)
        )

        Surface(
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Shield,
                    contentDescription = null,
                    tint = IgnisTechBlue
                )
                Text(
                    text = "Ignis protects buyer and seller contact details. Exact private numbers remain encrypted.",
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RoleCustomizationStep(
    role: UserRole,
    consumerInterests: MutableList<String>,
    storeName: String,
    onStoreNameChange: (String) -> Unit,
    storeDescription: String,
    onStoreDescriptionChange: (String) -> Unit,
    sellerCategories: MutableList<String>,
    deliveryRadius: String,
    onDeliveryRadiusChange: (String) -> Unit,
    selectedVehicle: VehicleType,
    onVehicleSelect: (VehicleType) -> Unit,
    experienceYears: String,
    onExperienceChange: (String) -> Unit,
    approximateArea: String,
    onAreaChange: (String) -> Unit,
    isAvailableImmediate: Boolean,
    onAvailabilityToggle: (Boolean) -> Unit
) {
    when (role) {
        UserRole.CONSUMER -> {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text(
                        text = "What are you interested in?",
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Select categories that inspire you. We'll curate your home feed accordingly.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                }

                item {
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SampleData.sampleCategories.filterNot { it == "All" }.forEach { category ->
                            val isSelected = consumerInterests.contains(category)
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    if (isSelected) consumerInterests.remove(category)
                                    else consumerInterests.add(category)
                                },
                                label = { Text(category) },
                                leadingIcon = if (isSelected) {
                                    { Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                } else null,
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = IgnisOrangePrimary,
                                    selectedLabelColor = Color.White,
                                    selectedLeadingIconColor = Color.White
                                )
                            )
                        }
                    }
                }
            }
        }
        UserRole.SELLER -> {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text(
                        text = "What would you like to sell?",
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Create your storefront & innovation space on Ignis.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                }

                item {
                    OutlinedTextField(
                        value = storeName,
                        onValueChange = onStoreNameChange,
                        label = { Text("Store / Brand Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    )
                }

                item {
                    OutlinedTextField(
                        value = storeDescription,
                        onValueChange = onStoreDescriptionChange,
                        label = { Text("Short Description") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    )
                }

                item {
                    OutlinedTextField(
                        value = deliveryRadius,
                        onValueChange = onDeliveryRadiusChange,
                        label = { Text("Delivery Area Radius (km)") },
                        placeholder = { Text("e.g. 25") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    )
                }

                item {
                    Text(
                        text = "Selling Categories",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SampleData.sampleCategories.filterNot { it == "All" }.forEach { category ->
                            val isSelected = sellerCategories.contains(category)
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    if (isSelected) sellerCategories.remove(category)
                                    else sellerCategories.add(category)
                                },
                                label = { Text(category) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = IgnisTechBlue,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                }
            }
        }
        UserRole.DELIVERY_PARTNER -> {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text(
                        text = "Delivery Partner Setup",
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Receive delivery opportunities from nearby innovative sellers.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                }

                item {
                    Text(
                        text = "Select Vehicle Type",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        VehicleType.values().forEach { vehicle ->
                            val isSelected = vehicle == selectedVehicle
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) IgnisEmerald else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onVehicleSelect(vehicle) }
                            ) {
                                Column(
                                    modifier = Modifier.padding(vertical = 12.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        imageVector = when (vehicle) {
                                            VehicleType.BICYCLE -> Icons.Filled.DirectionsBike
                                            VehicleType.MOTORCYCLE -> Icons.Filled.TwoWheeler
                                            VehicleType.SCOOTER -> Icons.Filled.ElectricScooter
                                            VehicleType.CAR -> Icons.Filled.DirectionsCar
                                            VehicleType.OTHER -> Icons.Filled.LocalShipping
                                        },
                                        contentDescription = null,
                                        tint = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = vehicle.label,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            fontSize = 10.sp
                                        )
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = experienceYears,
                        onValueChange = onExperienceChange,
                        label = { Text("Delivery Experience (Years)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    )
                }

                item {
                    OutlinedTextField(
                        value = approximateArea,
                        onValueChange = onAreaChange,
                        label = { Text("Approximate Delivery Zone") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    )
                }

                item {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "Immediate Availability",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "Make yourself visible to nearby sellers right away",
                                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }
                            Switch(
                                checked = isAvailableImmediate,
                                onCheckedChange = onAvailabilityToggle
                            )
                        }
                    }
                }
            }
        }
    }
}
