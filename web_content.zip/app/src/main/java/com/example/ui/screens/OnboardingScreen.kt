package com.example.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Cake
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.AppLanguage
import com.example.data.model.CountryIdProfile
import com.example.data.model.GenderOption
import com.example.data.model.SexualityOption
import com.example.data.model.UserProfile
import com.example.system.OtpChannel
import com.example.system.OtpDeliveryService
import com.example.system.OtpSendResult
import com.example.ui.components.ForgotPinResetDialog
import com.example.ui.components.FrontCameraFaceVerifierCard
import com.example.ui.components.ProfileAvatarImage
import com.example.ui.components.detectFriendlyLocation
import com.example.ui.components.savePickedPhotoToInternalStorage
import kotlin.math.roundToInt
import kotlin.random.Random
import kotlinx.coroutines.launch

private val STUDENT_GRADES = listOf(
    "Grade 6", "Grade 7", "Grade 8", "Grade 9",
    "Grade 10", "Grade 11", "Grade 12", "College / Uni"
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OnboardingScreen(
    initialProfile: UserProfile,
    onCompleteOnboarding: (UserProfile) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val otpService = remember(context) { OtpDeliveryService(context) }

    var isSignUpMode by remember { mutableStateOf(!initialProfile.onboardingCompleted) }
    var name by remember { mutableStateOf(initialProfile.name) }
    var email by remember { mutableStateOf(initialProfile.backupEmail) }
    var selectedCountry by remember {
        mutableStateOf(CountryIdProfile.fromIso(initialProfile.countryCode))
    }
    var phoneDialPrefix by remember { mutableStateOf(selectedCountry.dialCode) }
    var phoneNumber by remember { mutableStateOf(initialProfile.phoneNumber) }
    var idNumber by remember { mutableStateOf(initialProfile.idNumber) }
    var birthday by remember { mutableStateOf(initialProfile.birthday) }
    var isStudent by remember { mutableStateOf(initialProfile.isStudent) }
    var gradeLevel by remember { mutableStateOf(initialProfile.gradeLevel.ifBlank { "Grade 10" }) }
    var locationText by remember { mutableStateOf(initialProfile.locationText) }
    var photoPath by remember { mutableStateOf(initialProfile.profilePhotoPath) }

    // Step 1: Front camera human verification
    var humanVerified by remember { mutableStateOf(initialProfile.humanVerified) }

    // Step 2: Gmail OR Global Phone OTP state
    var otpChannel by remember { mutableStateOf(OtpChannel.GMAIL_OR_EMAIL) }
    var generatedOtp by remember { mutableStateOf<String?>(null) }
    var isSendingOtp by remember { mutableStateOf(false) }
    var otpStatusDetail by remember { mutableStateOf<String?>(null) }
    var otpAiMessage by remember { mutableStateOf<String?>(null) }
    var isLiveDelivered by remember { mutableStateOf(false) }
    var otpInput by remember { mutableStateOf("") }
    var otpVerified by remember { mutableStateOf(false) }

    var ageSlider by remember { mutableFloatStateOf(initialProfile.age.toFloat()) }
    var ageVerified by remember { mutableStateOf(initialProfile.ageVerified) }
    var selectedGender by remember { mutableStateOf(initialProfile.gender) }
    var selectedSexuality by remember { mutableStateOf(initialProfile.sexuality) }
    var selectedLanguage by remember { mutableStateOf(initialProfile.language) }
    var emergencyNumber by remember { mutableStateOf(initialProfile.emergencyAuthorityNumber) }
    var isDataFree by remember { mutableStateOf(initialProfile.isDataFreeMode) }
    var biometricEnabled by remember { mutableStateOf(initialProfile.biometricLockEnabled) }
    var pinCode by remember { mutableStateOf(initialProfile.pinCode) }
    var loginPinInput by remember { mutableStateOf("") }
    var showForgotPinDialog by remember { mutableStateOf(false) }
    var errorText by remember { mutableStateOf<String?>(null) }

    val ageInt = ageSlider.roundToInt()
    val idValidationError = remember(idNumber, selectedCountry) {
        if (idNumber.isBlank()) null else selectedCountry.validateId(idNumber)
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val saved = savePickedPhotoToInternalStorage(context, uri)
            if (saved != null) {
                photoPath = saved
            }
        }
    }

    val locationPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val granted = results[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            results[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            val detected = detectFriendlyLocation(context)
            locationText = detected
            val inferred = CountryIdProfile.inferFromLocation(detected)
            selectedCountry = inferred
            phoneDialPrefix = inferred.dialCode
        }
    }

    Scaffold { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp)
                .widthIn(max = 600.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_daily_haven),
                contentDescription = "Haven teen wellness banner",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .clip(RoundedCornerShape(24.dp)),
                contentScale = ContentScale.Crop
            )

            Text(
                text = if (isSignUpMode) "Sign Up to Haven" else "Log In to Haven",
                style = MaterialTheme.typography.displaySmall,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Ad-free teen wellness sanctuary with Personal AI, global languages, face verification, Gmail or global phone OTP, and country-smart IDs.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FilterChip(
                    selected = isSignUpMode,
                    onClick = { isSignUpMode = true; errorText = null },
                    modifier = Modifier.testTag("mode_signup_chip"),
                    label = { Text("Sign Up (All Fields)") }
                )
                FilterChip(
                    selected = !isSignUpMode,
                    onClick = { isSignUpMode = false; errorText = null },
                    modifier = Modifier.testTag("mode_login_chip"),
                    label = { Text("Log In (PIN / OTP)") }
                )
            }

            // Returning user PIN Login + Forgot PIN card when in Log In mode
            if (!isSignUpMode) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Quick Log In with Privacy PIN", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        if (initialProfile.onboardingCompleted && initialProfile.pinCode.isNotBlank()) {
                            OutlinedTextField(
                                value = loginPinInput,
                                onValueChange = { loginPinInput = it.filter { ch -> ch.isDigit() }.take(6); errorText = null },
                                label = { Text("Enter Your 4–6 Digit PIN") },
                                visualTransformation = PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("login_pin_input")
                            )
                            Button(
                                onClick = {
                                    if (loginPinInput == initialProfile.pinCode) {
                                        onCompleteOnboarding(
                                            initialProfile.copy(
                                                isLoggedIn = true,
                                                isDataFreeMode = isDataFree
                                            )
                                        )
                                    } else {
                                        errorText = "Incorrect PIN. Use Forgot PIN below to receive an OTP on your masked phone or email."
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().testTag("login_with_pin_button")
                            ) {
                                Text("Log In with PIN")
                            }
                        } else {
                            Text(
                                text = "Use Step 1 & Step 2 below to log in with Face + OTP, or reset your PIN anytime.",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        TextButton(
                            onClick = { showForgotPinDialog = true },
                            modifier = Modifier.testTag("login_forgot_pin_button")
                        ) {
                            Text("Forgot PIN? Send OTP to masked phone or email")
                        }
                    }
                }
            }

            // Data vs No-Data Mode toggle right up front so OTP knows user preference
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.CloudOff, contentDescription = null, tint = MaterialTheme.colorScheme.onTertiaryContainer)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = if (isDataFree) "No-Data Limited Mode ON" else "With Data (Full Features ON)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isDataFree) "Saves data: pauses live remote OTP & external website" else "Live AI OTP, website & web sync ready",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                    Switch(checked = isDataFree, onCheckedChange = { isDataFree = it })
                }
            }

            // Step 1: Fast Front Camera Face Verification
            FrontCameraFaceVerifierCard(
                isVerified = humanVerified,
                onVerified = { _ ->
                    humanVerified = true
                    errorText = null
                }
            )

            // Step 2: Gmail / Email OR Global Phone Number OTP
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (otpVerified) MaterialTheme.colorScheme.primaryContainer
                    else MaterialTheme.colorScheme.surface
                )
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (otpChannel == OtpChannel.GMAIL_OR_EMAIL) Icons.Filled.Email else Icons.Filled.Phone,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (otpVerified) "Step 2: OTP Verified ✓" else "Step 2: AI OTP (Gmail or Any Global Phone)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OtpChannel.entries.forEach { ch ->
                            FilterChip(
                                selected = otpChannel == ch,
                                onClick = {
                                    otpChannel = ch
                                    otpVerified = false
                                    otpStatusDetail = null
                                },
                                modifier = Modifier.testTag("otp_channel_${ch.name.lowercase()}"),
                                label = { Text(ch.label) }
                            )
                        }
                    }

                    if (otpChannel == OtpChannel.GMAIL_OR_EMAIL) {
                        OutlinedTextField(
                            value = email,
                            onValueChange = {
                                email = it
                                otpVerified = false
                            },
                            label = { Text("Gmail / Email Address") },
                            placeholder = { Text("you@gmail.com") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("onboarding_email_input")
                        )
                    } else {
                        Text("Select Country Dial Code", style = MaterialTheme.typography.labelMedium)
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            CountryIdProfile.entries.forEach { c ->
                                FilterChip(
                                    selected = phoneDialPrefix == c.dialCode && selectedCountry == c,
                                    onClick = {
                                        selectedCountry = c
                                        phoneDialPrefix = c.dialCode
                                    },
                                    label = { Text("${c.isoCode} ${c.dialCode}") }
                                )
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = phoneDialPrefix,
                                onValueChange = { phoneDialPrefix = it },
                                label = { Text("Code") },
                                singleLine = true,
                                modifier = Modifier.width(96.dp)
                            )
                            OutlinedTextField(
                                value = phoneNumber,
                                onValueChange = {
                                    phoneNumber = it.filter { ch -> ch.isDigit() || ch == ' ' }
                                    otpVerified = false
                                },
                                label = { Text("Global Phone Number (any country)") },
                                placeholder = { Text("82 123 4567") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                singleLine = true,
                                modifier = Modifier.weight(1f).testTag("onboarding_phone_input")
                            )
                        }
                    }

                    Button(
                        onClick = {
                            val targetRecipient = if (otpChannel == OtpChannel.GMAIL_OR_EMAIL) {
                                email.trim()
                            } else {
                                "${phoneDialPrefix.trim()}${phoneNumber.filter { it.isDigit() }}"
                            }

                            val validRecipient = if (otpChannel == OtpChannel.GMAIL_OR_EMAIL) {
                                targetRecipient.contains("@") && targetRecipient.contains(".")
                            } else {
                                phoneNumber.count { it.isDigit() } >= 6
                            }

                            if (!validRecipient) {
                                errorText = if (otpChannel == OtpChannel.GMAIL_OR_EMAIL) {
                                    "Enter a valid Gmail/email address first."
                                } else {
                                    "Enter a valid global phone number (at least 6 digits)."
                                }
                                return@Button
                            }

                            errorText = null
                            otpVerified = false
                            otpInput = ""
                            isSendingOtp = true
                            val newCode = "%06d".format(Random.nextInt(100000, 999999))
                            generatedOtp = newCode

                            scope.launch {
                                val res = otpService.sendOtp(
                                    channel = otpChannel,
                                    recipient = targetRecipient,
                                    code = newCode,
                                    isDataFreeMode = isDataFree,
                                    languageName = selectedLanguage.nativeName
                                )
                                isSendingOtp = false
                                when (res) {
                                    is OtpSendResult.DeliveredLive -> {
                                        isLiveDelivered = true
                                        otpAiMessage = res.aiNotice
                                        otpStatusDetail = "OTP sent to ${OtpDeliveryService.maskRecipient(otpChannel, targetRecipient)}! Check your inbox/SMS."
                                    }
                                    is OtpSendResult.OfflineOrUnconfigured -> {
                                        isLiveDelivered = false
                                        otpAiMessage = res.aiNotice
                                        if (!isDataFree) {
                                            if (otpChannel == OtpChannel.GMAIL_OR_EMAIL) {
                                                otpService.launchDeviceEmailOtp(targetRecipient, newCode)
                                            } else {
                                                otpService.launchDeviceSmsOtp(targetRecipient, newCode)
                                            }
                                        }
                                        otpStatusDetail = "OTP dispatched to ${OtpDeliveryService.maskRecipient(otpChannel, targetRecipient)}. ${res.reason}"
                                    }
                                    is OtpSendResult.Error -> {
                                        isLiveDelivered = false
                                        errorText = res.message
                                    }
                                }
                            }
                        },
                        enabled = !isSendingOtp,
                        modifier = Modifier.testTag("send_otp_button")
                    ) {
                        if (isSendingOtp) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                        Text(if (generatedOtp == null) "Send AI OTP" else "Resend AI OTP")
                    }

                    generatedOtp?.let { code ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                otpStatusDetail?.let { detail ->
                                    Text(detail, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                }
                                otpAiMessage?.let { aiText ->
                                    Text(aiText, style = MaterialTheme.typography.bodySmall)
                                }
                                if (!isLiveDelivered) {
                                    OutlinedButton(
                                        onClick = {
                                            if (otpChannel == OtpChannel.GMAIL_OR_EMAIL) {
                                                otpService.launchDeviceEmailOtp(email, code)
                                            } else {
                                                val full = "${phoneDialPrefix.trim()}${phoneNumber.filter { it.isDigit() }}"
                                                otpService.launchDeviceSmsOtp(full, code)
                                            }
                                        }
                                    ) {
                                        Text(
                                            if (otpChannel == OtpChannel.GMAIL_OR_EMAIL) "Send via Gmail / Email App"
                                            else "Send via SMS App"
                                        )
                                    }
                                }
                            }
                        }

                        OutlinedTextField(
                            value = otpInput,
                            onValueChange = { otpInput = it.filter { ch -> ch.isDigit() }.take(6) },
                            label = { Text("Enter 6-Digit OTP Code") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("otp_code_input")
                        )
                        Button(
                            onClick = {
                                if (otpInput == code) {
                                    otpVerified = true
                                    errorText = null
                                } else {
                                    errorText = "OTP code does not match."
                                }
                            },
                            modifier = Modifier.testTag("verify_otp_button")
                        ) {
                            Text("Verify OTP Code")
                        }
                    }
                }
            }

            // Step 3: Complete All-Fields Professional Profile + Country ID Rules
            if (isSignUpMode || !initialProfile.onboardingCompleted) {
                Card {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Step 3: Complete Your Profile (All Questions Required)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            ProfileAvatarImage(photoPath = photoPath, displayName = name.ifBlank { "H" }, size = 64.dp)
                            Column(modifier = Modifier.weight(1f)) {
                                OutlinedButton(
                                    onClick = {
                                        photoPickerLauncher.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                    modifier = Modifier.testTag("pick_profile_photo_button")
                                ) {
                                    Icon(Icons.Filled.CameraAlt, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(if (photoPath.isBlank()) "Add Profile Picture" else "Change Photo")
                                }
                                Text(
                                    text = "Unlocks Picture Perfect award (+50 pts)",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it },
                            label = { Text("Full Name or Nickname *") },
                            leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("onboarding_name_input")
                        )

                        // Country / Location ID Format Selector
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Public, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Country / ID Type Rules *", style = MaterialTheme.typography.labelLarge)
                        }
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            CountryIdProfile.entries.forEach { country ->
                                FilterChip(
                                    selected = selectedCountry == country,
                                    onClick = {
                                        selectedCountry = country
                                        phoneDialPrefix = country.dialCode
                                    },
                                    modifier = Modifier.testTag("country_${country.isoCode.lowercase()}"),
                                    label = { Text("${country.countryName} (${country.isoCode})") }
                                )
                            }
                        }

                        val digitCount = idNumber.trim().replace(" ", "").replace("-", "").length
                        OutlinedTextField(
                            value = idNumber,
                            onValueChange = { raw ->
                                val filtered = if (selectedCountry.numericOnly) {
                                    raw.filter { it.isDigit() }.take(selectedCountry.maxLength)
                                } else {
                                    raw.filter { it.isLetterOrDigit() }.take(selectedCountry.maxLength)
                                }
                                idNumber = filtered
                            },
                            label = { Text("${selectedCountry.idTypeName} *") },
                            placeholder = { Text(selectedCountry.formatHint) },
                            supportingText = {
                                val msg = idValidationError
                                    ?: "Underage IDs accepted • Length: $digitCount / ${selectedCountry.maxLength} • ${selectedCountry.formatHint}"
                                Text(msg)
                            },
                            isError = idValidationError != null,
                            leadingIcon = { Icon(Icons.Filled.Badge, contentDescription = null) },
                            keyboardOptions = KeyboardOptions(
                                keyboardType = if (selectedCountry.numericOnly) KeyboardType.Number else KeyboardType.Text
                            ),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("onboarding_id_input")
                        )

                        OutlinedTextField(
                            value = birthday,
                            onValueChange = { birthday = it },
                            label = { Text("Birthday (YYYY-MM-DD) *") },
                            placeholder = { Text("2010-05-14") },
                            leadingIcon = { Icon(Icons.Filled.Cake, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("onboarding_birthday_input")
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.School, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Are you a Student? *", style = MaterialTheme.typography.titleSmall)
                            }
                            Switch(checked = isStudent, onCheckedChange = { isStudent = it })
                        }

                        if (isStudent) {
                            Text("Select Your Grade / Level *", style = MaterialTheme.typography.labelLarge)
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                STUDENT_GRADES.forEach { grade ->
                                    FilterChip(
                                        selected = gradeLevel == grade,
                                        onClick = { gradeLevel = grade },
                                        label = { Text(grade) }
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = locationText,
                            onValueChange = { locationText = it },
                            label = { Text("Your Location (City / Town / Province) *") },
                            leadingIcon = { Icon(Icons.Filled.LocationOn, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("onboarding_location_input")
                        )
                        OutlinedButton(
                            onClick = {
                                locationPermLauncher.launch(
                                    arrayOf(
                                        Manifest.permission.ACCESS_COARSE_LOCATION,
                                        Manifest.permission.ACCESS_FINE_LOCATION
                                    )
                                )
                            },
                            modifier = Modifier.testTag("detect_location_button")
                        ) {
                            Icon(Icons.Filled.MyLocation, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Detect GPS Location")
                        }
                    }
                }

                Text("Language (All 11 South African + Global) *", style = MaterialTheme.typography.titleMedium)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    AppLanguage.entries.forEach { lang ->
                        FilterChip(
                            selected = selectedLanguage == lang,
                            onClick = { selectedLanguage = lang },
                            label = { Text(lang.nativeName) }
                        )
                    }
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.VerifiedUser, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Age: $ageInt years old *", style = MaterialTheme.typography.titleMedium)
                        }
                        Slider(
                            value = ageSlider,
                            onValueChange = { ageSlider = it },
                            valueRange = 12f..19f,
                            steps = 6,
                            modifier = Modifier.testTag("age_slider")
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = ageVerified,
                                onCheckedChange = { ageVerified = it },
                                modifier = Modifier.testTag("age_verify_checkbox")
                            )
                            Text(
                                text = "I confirm my birthday, ID & age ($ageInt) — underage teens welcome. *",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }

                Text("Gender (Boys = Fit Only, Girls = Cycle + Fit) *", style = MaterialTheme.typography.titleMedium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GenderOption.entries.forEach { gender ->
                        FilterChip(
                            selected = selectedGender == gender,
                            onClick = { selectedGender = gender },
                            modifier = Modifier.testTag("gender_${gender.key}"),
                            label = { Text(gender.label) }
                        )
                    }
                }

                Text("Sexuality / Identity *", style = MaterialTheme.typography.titleMedium)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    SexualityOption.entries.forEach { sex ->
                        FilterChip(
                            selected = selectedSexuality == sex,
                            onClick = { selectedSexuality = sex },
                            label = { Text(sex.label) }
                        )
                    }
                }

                OutlinedTextField(
                    value = emergencyNumber,
                    onValueChange = { emergencyNumber = it },
                    label = { Text("Local Authority Emergency Number (e.g. 112, 10111, 911) *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("onboarding_emergency_input")
                )

                OutlinedTextField(
                    value = pinCode,
                    onValueChange = { raw -> pinCode = raw.filter { it.isDigit() }.take(6) },
                    label = { Text("Create 4–6 Digit Privacy PIN *") },
                    placeholder = { Text("e.g. 2580") },
                    supportingText = { Text("Used for quick login & lock protection (recoverable via Forgot PIN OTP)") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("onboarding_pin_input")
                )

                Card {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Fingerprint, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Biometric Privacy Lock", style = MaterialTheme.typography.titleSmall)
                                Text("Protect diary, ID & health logs", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                        Switch(checked = biometricEnabled, onCheckedChange = { biometricEnabled = it })
                    }
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Shield, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Zero Ads & Zero Third-Party Trackers. All personal ID, photo & health data stay private.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            if (errorText != null) {
                Text(
                    text = errorText!!,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Button(
                onClick = {
                    val requireProfileQuestions = isSignUpMode || !initialProfile.onboardingCompleted
                    val idErr = if (requireProfileQuestions) selectedCountry.validateId(idNumber) else null
                    val formattedPhone = if (phoneNumber.isNotBlank()) {
                        "${phoneDialPrefix.trim()}${phoneNumber.filter { it.isDigit() }}"
                    } else {
                        initialProfile.phoneNumber
                    }

                    when {
                        !humanVerified -> errorText = "Please complete Step 1 (Front Camera Human Face Check)."
                        !otpVerified -> errorText = "Please request and verify your 6-digit OTP code in Step 2."
                        requireProfileQuestions && name.isBlank() -> errorText = "Please enter your Name."
                        requireProfileQuestions && idErr != null -> errorText = idErr
                        requireProfileQuestions && birthday.isBlank() -> errorText = "Please enter your Birthday (YYYY-MM-DD)."
                        requireProfileQuestions && locationText.isBlank() -> errorText = "Please enter or detect your Location."
                        requireProfileQuestions && emergencyNumber.isBlank() -> errorText = "Please enter a Local Emergency Number."
                        requireProfileQuestions && pinCode.length < 4 -> errorText = "Please create a 4–6 digit Privacy PIN."
                        requireProfileQuestions && !ageVerified -> errorText = "Please check the age & birthday confirmation box."
                        else -> {
                            onCompleteOnboarding(
                                initialProfile.copy(
                                    name = name.trim().ifBlank { initialProfile.name.ifBlank { "Friend" } },
                                    age = ageInt,
                                    ageVerified = true,
                                    countryCode = selectedCountry.isoCode,
                                    idNumber = idNumber.trim().ifBlank { initialProfile.idNumber },
                                    birthday = birthday.trim().ifBlank { initialProfile.birthday },
                                    isStudent = isStudent,
                                    gradeLevel = if (isStudent) gradeLevel else "Not in school",
                                    locationText = locationText.trim().ifBlank { initialProfile.locationText },
                                    phoneNumber = formattedPhone,
                                    profilePhotoPath = photoPath,
                                    humanVerified = true,
                                    emailOtpVerified = true,
                                    isLoggedIn = true,
                                    gender = selectedGender,
                                    sexuality = selectedSexuality,
                                    backupEmail = email.trim().ifBlank { initialProfile.backupEmail },
                                    language = selectedLanguage,
                                    isDataFreeMode = isDataFree,
                                    biometricLockEnabled = biometricEnabled,
                                    pinCode = pinCode.ifBlank { initialProfile.pinCode },
                                    emergencyAuthorityNumber = emergencyNumber.trim().ifBlank { "112" },
                                    onboardingCompleted = true
                                )
                            )
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("complete_onboarding_button")
            ) {
                Icon(Icons.Filled.CheckCircle, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (isSignUpMode) "Create Account & Enter Haven" else "Log In to Haven")
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showForgotPinDialog) {
        val currentFullPhone = if (phoneNumber.isNotBlank()) {
            "${phoneDialPrefix.trim()}${phoneNumber.filter { it.isDigit() }}"
        } else {
            initialProfile.phoneNumber
        }
        ForgotPinResetDialog(
            profile = initialProfile.copy(isDataFreeMode = isDataFree, language = selectedLanguage),
            fallbackEmail = email,
            fallbackPhone = currentFullPhone,
            onPinResetSuccess = { newPin ->
                showForgotPinDialog = false
                pinCode = newPin
                onCompleteOnboarding(
                    initialProfile.copy(
                        pinCode = newPin,
                        isLoggedIn = true,
                        isDataFreeMode = isDataFree,
                        onboardingCompleted = true
                    )
                )
            },
            onDismiss = { showForgotPinDialog = false }
        )
    }
}
