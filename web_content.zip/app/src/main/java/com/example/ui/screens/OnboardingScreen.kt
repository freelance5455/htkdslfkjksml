package com.example.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Cake
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.AppLanguage
import com.example.data.model.GenderOption
import com.example.data.model.SexualityOption
import com.example.data.model.UserProfile
import com.example.ui.components.ProfileAvatarImage
import com.example.ui.components.detectFriendlyLocation
import com.example.ui.components.savePickedPhotoToInternalStorage
import kotlin.math.roundToInt
import kotlin.random.Random
import kotlinx.coroutines.delay

private val STUDENT_GRADES = listOf(
    "Grade 6", "Grade 7", "Grade 8", "Grade 9",
    "Grade 10", "Grade 11", "Grade 12", "College / Uni"
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OnboardingScreen(
    initialProfile: UserProfile,
    onCompleteOnboarding: (UserProfile) -> Unit
) {
    val context = LocalContext.current

    var isSignUpMode by remember { mutableStateOf(!initialProfile.onboardingCompleted) }
    var name by remember { mutableStateOf(initialProfile.name) }
    var email by remember { mutableStateOf(initialProfile.backupEmail) }
    var idNumber by remember { mutableStateOf(initialProfile.idNumber) }
    var birthday by remember { mutableStateOf(initialProfile.birthday) }
    var isStudent by remember { mutableStateOf(initialProfile.isStudent) }
    var gradeLevel by remember { mutableStateOf(initialProfile.gradeLevel.ifBlank { "Grade 10" }) }
    var locationText by remember { mutableStateOf(initialProfile.locationText) }
    var photoPath by remember { mutableStateOf(initialProfile.profilePhotoPath) }

    // Human verification state
    var challengeA by remember { mutableIntStateOf(Random.nextInt(2, 9)) }
    var challengeB by remember { mutableIntStateOf(Random.nextInt(2, 9)) }
    var humanAnswer by remember { mutableStateOf("") }
    var humanCheckbox by remember { mutableStateOf(false) }
    var humanVerified by remember { mutableStateOf(initialProfile.humanVerified) }

    // Email OTP waiting & verification state
    var generatedOtp by remember { mutableStateOf<String?>(null) }
    var isWaitingForOtp by remember { mutableStateOf(false) }
    var otpWaitSeconds by remember { mutableIntStateOf(0) }
    var otpInput by remember { mutableStateOf("") }
    var otpVerified by remember { mutableStateOf(false) }

    var ageSlider by remember { mutableFloatStateOf(initialProfile.age.toFloat()) }
    var ageVerified by remember { mutableStateOf(initialProfile.ageVerified) }
    var selectedGender by remember { mutableStateOf(initialProfile.gender) }
    var selectedSexuality by remember { mutableStateOf(initialProfile.sexuality) }
    var selectedLanguage by remember { mutableStateOf(initialProfile.language) }
    var emergencyNumber by remember { mutableStateOf(initialProfile.emergencyAuthorityNumber) }
    var isDataFree by remember { mutableStateOf(initialProfile.isDataFreeMode) }
    var biometricEnabled by remember { mutableStateOf(initialProfile.biometricLockEnabled) }
    var errorText by remember { mutableStateOf<String?>(null) }

    val ageInt = ageSlider.roundToInt()

    // Photo picker (Google Play compliant, zero broad storage permissions)
    val photoPickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            val saved = savePickedPhotoToInternalStorage(context, uri)
            if (saved != null) {
                photoPath = saved
            }
        }
    }

    // Location permission launcher
    val locationPermLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val granted = results[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            results[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            locationText = detectFriendlyLocation(context)
        }
    }

    LaunchedEffect(isWaitingForOtp) {
        if (isWaitingForOtp) {
            for (sec in 3 downTo 1) {
                otpWaitSeconds = sec
                delay(1000L)
            }
            generatedOtp = "%06d".format(Random.nextInt(100000, 999999))
            isWaitingForOtp = false
            otpWaitSeconds = 0
        }
    }

    Scaffold { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp)
                .widthIn(max = 600.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_daily_haven),
                contentDescription = "Haven teen wellness banner",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(144.dp)
                    .clip(RoundedCornerShape(24.dp)),
                contentScale = ContentScale.Crop
            )

            Text(
                text = if (isSignUpMode) "Sign Up to Haven" else "Log In to Haven",
                style = MaterialTheme.typography.displaySmall,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "Private, ad-free teen sanctuary with zero third-party trackers. Verify you are human, log in with Email & OTP, and earn awards.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // Sign Up / Log In Mode Switch
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FilterChip(
                    selected = isSignUpMode,
                    onClick = { isSignUpMode = true; errorText = null },
                    modifier = Modifier.testTag("mode_signup_chip"),
                    label = { Text("Sign Up (New Account)") }
                )
                FilterChip(
                    selected = !isSignUpMode,
                    onClick = { isSignUpMode = false; errorText = null },
                    modifier = Modifier.testTag("mode_login_chip"),
                    label = { Text("Log In (Email + OTP)") }
                )
            }

            // 1. Human Verification Card
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (humanVerified) MaterialTheme.colorScheme.primaryContainer
                    else MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (humanVerified) "Human Verified ✓" else "Step 1: Verify You Are Human",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    if (!humanVerified) {
                        Text(
                            text = "Quick human check: What is $challengeA + $challengeB?",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        OutlinedTextField(
                            value = humanAnswer,
                            onValueChange = { humanAnswer = it.filter { ch -> ch.isDigit() } },
                            label = { Text("Your Answer") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("human_answer_input")
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = humanCheckbox,
                                onCheckedChange = { humanCheckbox = it },
                                modifier = Modifier.testTag("human_checkbox")
                            )
                            Text("I am a real person, not a bot.", style = MaterialTheme.typography.bodySmall)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    if (humanAnswer.toIntOrNull() == (challengeA + challengeB) && humanCheckbox) {
                                        humanVerified = true
                                        errorText = null
                                    } else {
                                        errorText = "Please check the math answer and confirm the human checkbox."
                                    }
                                },
                                modifier = Modifier.testTag("verify_human_button")
                            ) {
                                Text("Verify Human")
                            }
                            OutlinedButton(
                                onClick = {
                                    challengeA = Random.nextInt(2, 9)
                                    challengeB = Random.nextInt(2, 9)
                                    humanAnswer = ""
                                }
                            ) {
                                Text("New Question")
                            }
                        }
                    }
                }
            }

            // 2. Email Sign Up / Log In + Wait for OTP
            Card {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Email, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (otpVerified) "Email OTP Verified ✓" else "Step 2: Email & Wait for OTP",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    OutlinedTextField(
                        value = email,
                        onValueChange = {
                            email = it
                            otpVerified = false
                        },
                        label = { Text("Your Email Address") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("onboarding_email_input")
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                if (!email.contains("@") || !email.contains(".")) {
                                    errorText = "Please enter a valid email address first."
                                } else {
                                    errorText = null
                                    otpVerified = false
                                    otpInput = ""
                                    isWaitingForOtp = true
                                }
                            },
                            enabled = !isWaitingForOtp,
                            modifier = Modifier.testTag("send_otp_button")
                        ) {
                            Text(if (generatedOtp == null) "Send OTP" else "Resend OTP")
                        }

                        if (isWaitingForOtp) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Waiting for OTP (${otpWaitSeconds}s)...", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }

                    if (isWaitingForOtp) {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    }

                    generatedOtp?.let { code ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = "Offline On-Device OTP (No Third-Party Server)",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Enter verification code: $code",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        OutlinedTextField(
                            value = otpInput,
                            onValueChange = { otpInput = it.filter { ch -> ch.isDigit() }.take(6) },
                            label = { Text("Enter 6-Digit OTP Code") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("otp_code_input")
                        )
                        Button(
                            onClick = {
                                if (otpInput == code) {
                                    otpVerified = true
                                    errorText = null
                                } else {
                                    errorText = "OTP code does not match. Check the code shown above."
                                }
                            },
                            modifier = Modifier.testTag("verify_otp_button")
                        ) {
                            Text("Verify OTP Code")
                        }
                    }
                }
            }

            // 3. Profile Picture + Identity (ID even if underage, Birthday, Student & Grade, Location)
            if (isSignUpMode || !initialProfile.onboardingCompleted) {
                Card {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Step 3: Profile Photo, ID, Birthday & Location", style = MaterialTheme.typography.titleMedium)

                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            ProfileAvatarImage(photoPath = photoPath, displayName = name.ifBlank { "H" }, size = 64.dp)
                            Column(modifier = Modifier.weight(1f)) {
                                OutlinedButton(
                                    onClick = {
                                        photoPickerLauncher.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                    modifier = Modifier.testTag("pick_profile_photo_button")
                                ) {
                                    Icon(Icons.Filled.CameraAlt, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(if (photoPath.isBlank()) "Add Profile Picture" else "Change Photo")
                                }
                                Text(
                                    text = "Earn the Picture Perfect award (+50 pts)",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it },
                            label = { Text("First Name or Nickname") },
                            leadingIcon = { Icon(Icons.Filled.Person, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("onboarding_name_input")
                        )

                        OutlinedTextField(
                            value = idNumber,
                            onValueChange = { idNumber = it },
                            label = { Text("ID Number (accepted even if underage / School ID)") },
                            leadingIcon = { Icon(Icons.Filled.Badge, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("onboarding_id_input")
                        )

                        OutlinedTextField(
                            value = birthday,
                            onValueChange = { birthday = it },
                            label = { Text("Birthday (e.g. 2010-05-14)") },
                            leadingIcon = { Icon(Icons.Filled.Cake, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("onboarding_birthday_input")
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.School, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Are you a Student?", style = MaterialTheme.typography.titleSmall)
                            }
                            Switch(checked = isStudent, onCheckedChange = { isStudent = it })
                        }

                        if (isStudent) {
                            Text("Select Your Grade / Level", style = MaterialTheme.typography.labelLarge)
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                STUDENT_GRADES.forEach { grade ->
                                    FilterChip(
                                        selected = gradeLevel == grade,
                                        onClick = { gradeLevel = grade },
                                        label = { Text(grade) }
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = locationText,
                            onValueChange = { locationText = it },
                            label = { Text("Your Location (City / Town / Province)") },
                            leadingIcon = { Icon(Icons.Filled.LocationOn, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("onboarding_location_input")
                        )
                        OutlinedButton(
                            onClick = {
                                locationPermLauncher.launch(
                                    arrayOf(
                                        Manifest.permission.ACCESS_COARSE_LOCATION,
                                        Manifest.permission.ACCESS_FINE_LOCATION
                                    )
                                )
                            },
                            modifier = Modifier.testTag("detect_location_button")
                        ) {
                            Icon(Icons.Filled.MyLocation, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Detect Current Location")
                        }
                    }
                }

                // Language Selector (All 11 South African + Global)
                Text("Language (South African & Global)", style = MaterialTheme.typography.titleMedium)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    AppLanguage.entries.forEach { lang ->
                        FilterChip(
                            selected = selectedLanguage == lang,
                            onClick = { selectedLanguage = lang },
                            label = { Text(lang.nativeName) }
                        )
                    }
                }

                // Age slider (supports teens 12-19 including underage ID)
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.VerifiedUser, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Age: $ageInt years old", style = MaterialTheme.typography.titleMedium)
                        }
                        Slider(
                            value = ageSlider,
                            onValueChange = { ageSlider = it },
                            valueRange = 12f..19f,
                            steps = 6,
                            modifier = Modifier.testTag("age_slider")
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = ageVerified,
                                onCheckedChange = { ageVerified = it },
                                modifier = Modifier.testTag("age_verify_checkbox")
                            )
                            Text(
                                text = "I verify my birthday & age ($ageInt) — underage student IDs welcome.",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }

                // Gender & Sexuality
                Text("Gender (tailors your health tracker)", style = MaterialTheme.typography.titleMedium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GenderOption.entries.forEach { gender ->
                        FilterChip(
                            selected = selectedGender == gender,
                            onClick = { selectedGender = gender },
                            modifier = Modifier.testTag("gender_${gender.key}"),
                            label = { Text(gender.label) }
                        )
                    }
                }

                Text("Sexuality / Identity (stored privately)", style = MaterialTheme.typography.titleMedium)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    SexualityOption.entries.forEach { sex ->
                        FilterChip(
                            selected = selectedSexuality == sex,
                            onClick = { selectedSexuality = sex },
                            label = { Text(sex.label) }
                        )
                    }
                }

                OutlinedTextField(
                    value = emergencyNumber,
                    onValueChange = { emergencyNumber = it },
                    label = { Text("Local Authority Emergency Number (e.g. 112, 10111)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Data / Data-Free + Biometrics
                Card {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.CloudOff, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text("Data-Free Offline Mode", style = MaterialTheme.typography.titleSmall)
                                    Text("Works 100% without mobile data", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            Switch(checked = isDataFree, onCheckedChange = { isDataFree = it })
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Fingerprint, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text("Biometric Privacy Lock", style = MaterialTheme.typography.titleSmall)
                                    Text("Protect diary, ID & hormone logs", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            Switch(checked = biometricEnabled, onCheckedChange = { biometricEnabled = it })
                        }
                    }
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Shield, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Zero Ads & Zero Third-Party SDKs. All personal data, ID, photo & awards stay privately on your phone.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }

            if (errorText != null) {
                Text(
                    text = errorText!!,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            Button(
                onClick = {
                    when {
                        !humanVerified -> errorText = "Please complete Step 1 (Human Verification)."
                        !otpVerified -> errorText = "Please request and verify your 6-digit OTP code in Step 2."
                        isSignUpMode && !ageVerified -> errorText = "Please confirm the birthday & age checkbox."
                        else -> {
                            onCompleteOnboarding(
                                initialProfile.copy(
                                    name = name.trim().ifBlank { "Friend" },
                                    age = ageInt,
                                    ageVerified = true,
                                    idNumber = idNumber.trim(),
                                    birthday = birthday.trim(),
                                    isStudent = isStudent,
                                    gradeLevel = if (isStudent) gradeLevel else "Not in school",
                                    locationText = locationText.trim(),
                                    profilePhotoPath = photoPath,
                                    humanVerified = true,
                                    emailOtpVerified = true,
                                    isLoggedIn = true,
                                    gender = selectedGender,
                                    sexuality = selectedSexuality,
                                    backupEmail = email.trim(),
                                    language = selectedLanguage,
                                    isDataFreeMode = isDataFree,
                                    biometricLockEnabled = biometricEnabled,
                                    emergencyAuthorityNumber = emergencyNumber.trim().ifBlank { "112" },
                                    onboardingCompleted = true
                                )
                            )
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("complete_onboarding_button")
            ) {
                Icon(Icons.Filled.CheckCircle, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (isSignUpMode) "Create Account & Enter Haven" else "Log In to Haven")
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
