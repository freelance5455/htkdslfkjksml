package com.example.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.assistant.NovaDeviceController
import com.example.assistant.NovaVoiceManager
import com.example.assistant.ParsedVoiceIntent
import com.example.data.model.AnswerLength
import com.example.data.model.AssistantMode
import com.example.data.model.ChatMessage
import com.example.data.model.ContactItem
import com.example.data.model.Conversation
import com.example.data.model.DeviceInfoSnapshot
import com.example.data.model.PendingAttachment
import com.example.data.model.UserMemory
import com.example.data.remote.GeminiService
import com.example.data.repository.NovaFirestoreRepository
import com.example.service.NovaWakeWordForegroundService
import com.example.util.AttachmentHelper
import com.google.firebase.Timestamp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
class NovaViewModel(
    private val appContext: Context,
    private val repository: NovaFirestoreRepository,
    private val currentUserId: String
) : ViewModel() {

    private val localPrefs = appContext.getSharedPreferences("nova_local_data_$currentUserId", Context.MODE_PRIVATE)

    val deviceController = NovaDeviceController(appContext)
    val voiceManager = NovaVoiceManager(appContext) { spokenTranscript ->
        onVoiceTranscriptReceived(spokenTranscript)
    }

    // Theme & Preferences
    private val _isDarkTheme = MutableStateFlow(localPrefs.getBoolean("dark_theme", true))
    val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    private val _selectedMode = MutableStateFlow(AssistantMode.GENERAL)
    val selectedMode: StateFlow<AssistantMode> = _selectedMode.asStateFlow()

    private val _answerLength = MutableStateFlow(AnswerLength.BALANCED)
    val answerLength: StateFlow<AnswerLength> = _answerLength.asStateFlow()

    private val _autoSpeakResponses = MutableStateFlow(false)
    val autoSpeakResponses: StateFlow<Boolean> = _autoSpeakResponses.asStateFlow()

    private val _wakePhrase = MutableStateFlow(localPrefs.getString("wake_phrase", "Hello Aura") ?: "Hello Aura")
    val wakePhrase: StateFlow<String> = _wakePhrase.asStateFlow()

    // Active Conversation & Search
    private val _activeConversationId = MutableStateFlow<String?>(null)
    val activeConversationId: StateFlow<String?> = _activeConversationId.asStateFlow()

    private val _historySearchQuery = MutableStateFlow("")
    val historySearchQuery: StateFlow<String> = _historySearchQuery.asStateFlow()

    // Composer & Attachments
    private val _composerText = MutableStateFlow("")
    val composerText: StateFlow<String> = _composerText.asStateFlow()

    private val _pendingAttachments = MutableStateFlow<List<PendingAttachment>>(emptyList())
    val pendingAttachments: StateFlow<List<PendingAttachment>> = _pendingAttachments.asStateFlow()

    private val _isUploadingAttachment = MutableStateFlow(false)
    val isUploadingAttachment: StateFlow<Boolean> = _isUploadingAttachment.asStateFlow()

    // Streaming & Generation State
    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _streamingPartialText = MutableStateFlow("")
    val streamingPartialText: StateFlow<String> = _streamingPartialText.asStateFlow()

    private val _uiBannerMessage = MutableStateFlow<String?>(null)
    val uiBannerMessage: StateFlow<String?> = _uiBannerMessage.asStateFlow()

    // Ambiguous Contact Call Confirmation State
    private val _pendingCallCandidates = MutableStateFlow<List<ContactItem>>(emptyList())
    val pendingCallCandidates: StateFlow<List<ContactItem>> = _pendingCallCandidates.asStateFlow()

    // Device Snapshot State
    private val _deviceSnapshot = MutableStateFlow(deviceController.captureDeviceSnapshot())
    val deviceSnapshot: StateFlow<DeviceInfoSnapshot> = _deviceSnapshot.asStateFlow()

    private var activeGenerationJob: Job? = null

    // Local Fallback Mirrors (Used when running without Google Play Services / Firebase Auth token)
    private val _localConversations = MutableStateFlow(loadLocalConversations())
    private val _localMessagesMap = MutableStateFlow(loadLocalMessagesMap())
    private val _localMemories = MutableStateFlow(loadLocalMemories())

    // Combined Real-time Flows (Cloud Firestore + Local Persistence)
    val conversations: StateFlow<List<Conversation>> = combine(
        flow {
            if (repository.isFirebaseAuthenticated()) {
                emitAll(repository.observeConversations(currentUserId).catch { emit(emptyList()) })
            } else {
                emit(emptyList())
            }
        },
        _localConversations
    ) { remote, local ->
        if (remote.isNotEmpty()) remote else local
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = _localConversations.value
    )

    val messages: StateFlow<List<ChatMessage>> = _activeConversationId
        .flatMapLatest { convId ->
            if (convId.isNullOrBlank()) {
                flowOf(emptyList())
            } else {
                combine(
                    flow {
                        if (repository.isFirebaseAuthenticated()) {
                            emitAll(repository.observeMessages(currentUserId, convId).catch { emit(emptyList()) })
                        } else {
                            emit(emptyList())
                        }
                    },
                    _localMessagesMap
                ) { remote, localMap ->
                    if (remote.isNotEmpty()) remote else (localMap[convId] ?: emptyList())
                }
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = emptyList()
        )

    val memories: StateFlow<List<UserMemory>> = combine(
        flow {
            if (repository.isFirebaseAuthenticated()) {
                emitAll(repository.observeMemories(currentUserId).catch { emit(emptyList()) })
            } else {
                emit(emptyList())
            }
        },
        _localMemories
    ) { remote, local ->
        if (remote.isNotEmpty()) remote else local
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000L),
        initialValue = _localMemories.value
    )

    fun refreshDeviceSnapshot() {
        _deviceSnapshot.value = deviceController.captureDeviceSnapshot()
    }

    fun setDarkTheme(enabled: Boolean) {
        _isDarkTheme.value = enabled
        localPrefs.edit().putBoolean("dark_theme", enabled).apply()
    }

    fun setAssistantMode(mode: AssistantMode) {
        _selectedMode.value = mode
    }

    fun setAnswerLength(length: AnswerLength) {
        _answerLength.value = length
    }

    fun setAutoSpeakResponses(enabled: Boolean) {
        _autoSpeakResponses.value = enabled
        if (!enabled) voiceManager.stopSpeaking()
    }

    fun updateWakePhrase(phrase: String) {
        _wakePhrase.value = phrase
        localPrefs.edit().putString("wake_phrase", phrase).apply()
    }

    fun updateComposerText(text: String) {
        _composerText.value = text
    }

    fun updateHistorySearchQuery(query: String) {
        _historySearchQuery.value = query
    }

    fun clearBannerMessage() {
        _uiBannerMessage.value = null
    }

    fun dismissPendingCallCandidates() {
        _pendingCallCandidates.value = emptyList()
    }

    fun startNewChat() {
        stopGeneration()
        _activeConversationId.value = null
        _composerText.value = ""
        _pendingAttachments.value = emptyList()
        _streamingPartialText.value = ""
    }

    fun selectConversation(conversationId: String) {
        stopGeneration()
        _activeConversationId.value = conversationId
        _streamingPartialText.value = ""
    }

    fun renameConversation(conversationId: String, newTitle: String) {
        viewModelScope.launch {
            val clean = newTitle.trim().ifEmpty { "Conversation" }.take(200)
            _localConversations.value = _localConversations.value.map {
                if (it.id == conversationId) it.copy(title = clean, updatedAt = Timestamp.now()) else it
            }
            saveLocalConversations(_localConversations.value)
            if (repository.isFirebaseAuthenticated()) {
                repository.renameConversation(conversationId, clean)
            }
        }
    }

    fun deleteConversation(conversationId: String) {
        viewModelScope.launch {
            if (_activeConversationId.value == conversationId) {
                _activeConversationId.value = null
            }
            _localConversations.value = _localConversations.value.filterNot { it.id == conversationId }
            val updatedMap = _localMessagesMap.value.toMutableMap()
            updatedMap.remove(conversationId)
            _localMessagesMap.value = updatedMap
            saveLocalConversations(_localConversations.value)
            saveLocalMessagesMap(_localMessagesMap.value)
            if (repository.isFirebaseAuthenticated()) {
                repository.deleteConversation(conversationId)
            }
        }
    }

    fun clearAllConversations() {
        viewModelScope.launch {
            _activeConversationId.value = null
            _localConversations.value = emptyList()
            _localMessagesMap.value = emptyMap()
            saveLocalConversations(emptyList())
            saveLocalMessagesMap(emptyMap())
            if (repository.isFirebaseAuthenticated()) {
                repository.clearAllConversations()
            }
            _uiBannerMessage.value = "All conversations cleared."
        }
    }

    // --- ATTACHMENTS ---

    fun attachFromUri(uri: Uri) {
        viewModelScope.launch {
            _isUploadingAttachment.value = true
            val res = AttachmentHelper.uriToPendingAttachment(appContext, uri)
            _isUploadingAttachment.value = false
            res.onSuccess { att ->
                _pendingAttachments.value = _pendingAttachments.value + att
            }.onFailure { err ->
                _uiBannerMessage.value = err.localizedMessage ?: "Failed to attach file."
            }
        }
    }

    fun attachCameraBitmap(bitmap: Bitmap) {
        val att = AttachmentHelper.bitmapToPendingAttachment(bitmap)
        _pendingAttachments.value = _pendingAttachments.value + att
    }

    fun removePendingAttachment(attachmentId: String) {
        _pendingAttachments.value = _pendingAttachments.value.filterNot { it.id == attachmentId }
    }

    // --- MEMORIES ---

    fun addMemory(fact: String, category: String = "Preference") {
        viewModelScope.launch {
            val cleanFact = fact.trim().take(1000)
            if (cleanFact.isEmpty()) return@launch
            val mem = UserMemory(
                id = "mem_" + UUID.randomUUID().toString().take(12),
                userId = currentUserId,
                fact = cleanFact,
                category = category.trim().ifEmpty { "Preference" },
                createdAt = Timestamp.now(),
                updatedAt = Timestamp.now()
            )
            _localMemories.value = listOf(mem) + _localMemories.value
            saveLocalMemories(_localMemories.value)
            if (repository.isFirebaseAuthenticated()) {
                repository.addMemory(cleanFact, category)
            }
        }
    }

    fun deleteMemory(memoryId: String) {
        viewModelScope.launch {
            _localMemories.value = _localMemories.value.filterNot { it.id == memoryId }
            saveLocalMemories(_localMemories.value)
            if (repository.isFirebaseAuthenticated()) {
                repository.deleteMemory(memoryId)
            }
        }
    }

    fun clearAllMemories() {
        viewModelScope.launch {
            _localMemories.value = emptyList()
            saveLocalMemories(emptyList())
            if (repository.isFirebaseAuthenticated()) {
                repository.clearAllMemories()
            }
        }
    }

    // --- WAKE-WORD FOREGROUND SERVICE ---

    fun toggleWakeWordService(enable: Boolean) {
        try {
            val intent = Intent(appContext, NovaWakeWordForegroundService::class.java).apply {
                putExtra(NovaWakeWordForegroundService.EXTRA_WAKE_PHRASE, _wakePhrase.value)
                if (!enable) {
                    action = NovaWakeWordForegroundService.ACTION_STOP_SERVICE
                }
            }
            if (enable) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    appContext.startForegroundService(intent)
                } else {
                    appContext.startService(intent)
                }
            } else {
                appContext.startService(intent)
            }
        } catch (e: Exception) {
            _uiBannerMessage.value = "Could not start Wake-Word service: ${e.localizedMessage}"
        }
    }

    private fun onVoiceTranscriptReceived(transcript: String) {
        if (transcript.isBlank()) return
        _autoSpeakResponses.value = true
        sendMessage(overridePrompt = transcript)
    }

    // --- LOCAL STORAGE HELPERS ---

    private fun createOrSaveConversationId(title: String, firstPreview: String): String {
        val id = "conv_" + System.currentTimeMillis()
        val now = Timestamp.now()
        val conv = Conversation(
            id = id,
            userId = currentUserId,
            title = title.trim().ifEmpty { "New Chat" }.take(200),
            lastMessagePreview = firstPreview.take(500),
            messageCount = 0L,
            createdAt = now,
            updatedAt = now
        )
        _localConversations.value = listOf(conv) + _localConversations.value
        saveLocalConversations(_localConversations.value)
        return id
    }

    private suspend fun recordMessage(
        conversationId: String,
        role: String,
        content: String,
        attachmentSummary: String? = null,
        generatedImageBase64: String? = null,
        citations: String? = null
    ) {
        val now = Timestamp.now()
        val msg = ChatMessage(
            id = "msg_" + System.currentTimeMillis() + "_" + UUID.randomUUID().toString().take(6),
            userId = currentUserId,
            conversationId = conversationId,
            role = role,
            content = content,
            attachmentSummary = attachmentSummary,
            generatedImageBase64 = generatedImageBase64,
            citations = citations,
            createdAt = now,
            updatedAt = now
        )
        val currentMap = _localMessagesMap.value.toMutableMap()
        val existingList = currentMap[conversationId] ?: emptyList()
        currentMap[conversationId] = existingList + msg
        _localMessagesMap.value = currentMap
        saveLocalMessagesMap(currentMap)

        if (repository.isFirebaseAuthenticated()) {
            repository.addMessage(
                conversationId = conversationId,
                role = role,
                content = content,
                attachmentSummary = attachmentSummary,
                generatedImageBase64 = generatedImageBase64,
                citations = citations
            )
        }
    }

    private suspend fun updateConvSummary(
        conversationId: String,
        title: String? = null,
        lastMessagePreview: String,
        messageCount: Long
    ) {
        _localConversations.value = _localConversations.value.map { c ->
            if (c.id == conversationId) {
                c.copy(
                    title = if (!title.isNullOrBlank()) title else c.title,
                    lastMessagePreview = lastMessagePreview.take(500),
                    messageCount = messageCount,
                    updatedAt = Timestamp.now()
                )
            } else c
        }
        saveLocalConversations(_localConversations.value)
        if (repository.isFirebaseAuthenticated()) {
            repository.updateConversationSummary(conversationId, title, lastMessagePreview, messageCount)
        }
    }

    // --- SEND, STREAM, EDIT, REGENERATE ---

    fun stopGeneration() {
        activeGenerationJob?.cancel()
        activeGenerationJob = null
        _isGenerating.value = false
        _streamingPartialText.value = ""
    }

    fun sendMessage(overridePrompt: String? = null) {
        if (_isGenerating.value) return
        val promptText = (overridePrompt ?: _composerText.value).trim()
        val attachmentsToSend = _pendingAttachments.value

        if (promptText.isEmpty() && attachmentsToSend.isEmpty()) {
            _uiBannerMessage.value = "Type a message, speak a command, or attach an image/file before sending."
            return
        }

        if (overridePrompt == null) {
            _composerText.value = ""
        }
        _pendingAttachments.value = emptyList()

        activeGenerationJob = viewModelScope.launch {
            _isGenerating.value = true
            _streamingPartialText.value = ""
            refreshDeviceSnapshot()

            try {
                val currentHistory = messages.value
                var convId = _activeConversationId.value
                val isFirstTurn = convId == null

                if (convId == null) {
                    val initialTitle = promptText.ifBlank {
                        attachmentsToSend.firstOrNull()?.fileName ?: "New Conversation"
                    }.take(45)

                    val remoteId = if (repository.isFirebaseAuthenticated()) {
                        repository.createConversation(initialTitle, promptText.take(120)).getOrNull()
                    } else null

                    convId = remoteId ?: createOrSaveConversationId(initialTitle, promptText.take(120))
                    _activeConversationId.value = convId
                }

                // 2. Save User Message (RIGHT SIDE)
                val attachmentSummary = if (attachmentsToSend.isNotEmpty()) {
                    attachmentsToSend.joinToString(", ") { "${it.fileName} (${AttachmentHelper.formatFileSize(it.fileSizeBytes)})" }
                } else null
                val firstImageBase64 = attachmentsToSend.firstOrNull { !it.base64Data.isNullOrBlank() }?.base64Data

                val displayUserContent = promptText.ifBlank {
                    "Analyze attached: ${attachmentsToSend.joinToString { it.fileName }}"
                }

                recordMessage(
                    conversationId = convId,
                    role = "user",
                    content = displayUserContent,
                    attachmentSummary = attachmentSummary,
                    generatedImageBase64 = firstImageBase64
                )

                // 3. Check if prompt is a direct Android device/call command first
                if (attachmentsToSend.isEmpty() && _selectedMode.value == AssistantMode.GENERAL) {
                    val parsedIntent = deviceController.parseNaturalCommand(promptText)
                    when (parsedIntent) {
                        is ParsedVoiceIntent.DeviceQuery -> {
                            recordMessage(
                                conversationId = convId,
                                role = "assistant",
                                content = parsedIntent.spokenResponse
                            )
                            updateConvSummary(
                                conversationId = convId,
                                title = if (isFirstTurn) parsedIntent.title else null,
                                lastMessagePreview = parsedIntent.spokenResponse.replace("**", ""),
                                messageCount = (currentHistory.size + 2).toLong()
                            )
                            if (_autoSpeakResponses.value) {
                                voiceManager.speak(parsedIntent.spokenResponse)
                            }
                            _isGenerating.value = false
                            return@launch
                        }
                        is ParsedVoiceIntent.OpenDialer -> {
                            deviceController.openDialer(parsedIntent.number)
                            val reply = "Opening the Android phone dialer${if (parsedIntent.number.isNotBlank()) " for **${parsedIntent.number}**" else ""}."
                            recordMessage(convId, "assistant", reply)
                            if (_autoSpeakResponses.value) voiceManager.speak(reply)
                            _isGenerating.value = false
                            return@launch
                        }
                        is ParsedVoiceIntent.CallContactQuery -> {
                            val reply = handleContactCallIntent(parsedIntent.rawNameOrNumber)
                            recordMessage(convId, "assistant", reply)
                            if (_autoSpeakResponses.value) voiceManager.speak(reply)
                            _isGenerating.value = false
                            return@launch
                        }
                        is ParsedVoiceIntent.SystemAction -> {
                            val ok = parsedIntent.execute()
                            val reply = if (ok) {
                                "Done! **${parsedIntent.description}**."
                            } else {
                                "Could not open the requested setting on this device."
                            }
                            recordMessage(convId, "assistant", reply)
                            if (_autoSpeakResponses.value) voiceManager.speak(reply)
                            _isGenerating.value = false
                            return@launch
                        }
                        ParsedVoiceIntent.None -> {
                            // Proceed to NOVA AI Engine
                        }
                    }
                }

                // 4. Stream or Generate AI Response (LEFT SIDE)
                val result = GeminiService.streamChatResponse(
                    history = currentHistory,
                    prompt = promptText,
                    attachments = attachmentsToSend,
                    mode = _selectedMode.value,
                    answerLength = _answerLength.value,
                    memories = memories.value,
                    deviceSnapshot = _deviceSnapshot.value,
                    onPartialText = { partial ->
                        _streamingPartialText.value = partial
                    }
                )

                result.onSuccess { gen ->
                    _streamingPartialText.value = ""
                    recordMessage(
                        conversationId = convId,
                        role = "assistant",
                        content = gen.text,
                        generatedImageBase64 = gen.generatedImageBase64,
                        citations = gen.citations
                    )

                    val autoTitle = if (isFirstTurn && promptText.isNotBlank()) {
                        GeminiService.generateConversationTitle(promptText)
                    } else null

                    updateConvSummary(
                        conversationId = convId,
                        title = autoTitle,
                        lastMessagePreview = gen.text.take(160),
                        messageCount = (currentHistory.size + 2).toLong()
                    )

                    if (_autoSpeakResponses.value) {
                        voiceManager.speak(gen.text)
                    }
                }.onFailure { err ->
                    _streamingPartialText.value = ""
                    val errorMsg = "⚠️ **Unable to complete response:** ${err.localizedMessage ?: "Network or API error"}. Tap **Regenerate** to retry."
                    recordMessage(
                        conversationId = convId,
                        role = "assistant",
                        content = errorMsg
                    )
                }
            } catch (_: CancellationException) {
                val partial = _streamingPartialText.value.trim()
                val convId = _activeConversationId.value
                if (partial.isNotEmpty() && convId != null) {
                    recordMessage(
                        conversationId = convId,
                        role = "assistant",
                        content = "$partial\n\n*(Generation stopped by user)*"
                    )
                }
            } catch (e: Exception) {
                _uiBannerMessage.value = e.localizedMessage ?: "An unexpected error occurred."
            } finally {
                _streamingPartialText.value = ""
                _isGenerating.value = false
            }
        }
    }

    private fun handleContactCallIntent(rawTarget: String): String {
        val digitsOnly = rawTarget.filter { it.isDigit() || it == '+' }
        if (digitsOnly.length >= 7) {
            deviceController.openDialer(digitsOnly)
            return "Opening phone dialer for **$digitsOnly**."
        }

        if (!deviceController.hasContactsPermission()) {
            return "Contacts permission (`READ_CONTACTS`) is required to look up **$rawTarget**. Please open the **Phone Assistant Hub** (phone icon in top bar) to grant contacts access, or dial directly."
        }

        val matches = deviceController.searchContacts(rawTarget)
        return when {
            matches.isEmpty() -> {
                "No saved contact found matching **\"$rawTarget\"**. Opening the phone dialer so you can dial manually."
                    .also { deviceController.openDialer("") }
            }
            matches.size == 1 -> {
                val c = matches.first()
                deviceController.openDialer(c.phoneNumber)
                "Found contact **${c.displayName}** (`${c.phoneNumber}`). Opening the native dialer now."
            }
            else -> {
                _pendingCallCandidates.value = matches.take(5)
                "Found **${matches.size}** contacts matching **\"$rawTarget\"**. Please select which contact to call from the confirmation banner above."
            }
        }
    }

    fun editAndResendUserMessage(message: ChatMessage, newText: String) {
        val convId = _activeConversationId.value ?: return
        viewModelScope.launch {
            val map = _localMessagesMap.value.toMutableMap()
            val list = map[convId] ?: emptyList()
            map[convId] = list.map { if (it.id == message.id) it.copy(content = newText) else it }
            _localMessagesMap.value = map
            saveLocalMessagesMap(map)
            if (repository.isFirebaseAuthenticated()) {
                repository.updateMessageContent(convId, message.id, newText)
            }
            sendMessage(overridePrompt = newText)
        }
    }

    fun regenerateAiResponse(aiMessage: ChatMessage) {
        val convId = _activeConversationId.value ?: return
        val currentList = messages.value
        val aiIndex = currentList.indexOfFirst { it.id == aiMessage.id }
        val precedingUserMsg = if (aiIndex > 0) {
            currentList.subList(0, aiIndex).lastOrNull { it.role == "user" }
        } else {
            currentList.lastOrNull { it.role == "user" }
        }
        val promptToRetry = precedingUserMsg?.content ?: return

        viewModelScope.launch {
            val map = _localMessagesMap.value.toMutableMap()
            map[convId] = (map[convId] ?: emptyList()).filterNot { it.id == aiMessage.id }
            _localMessagesMap.value = map
            saveLocalMessagesMap(map)
            if (repository.isFirebaseAuthenticated()) {
                repository.deleteMessage(convId, aiMessage.id)
            }
            sendMessage(overridePrompt = promptToRetry)
        }
    }

    // --- JSON SERIALIZATION FOR LOCAL PERSISTENCE ---

    private fun saveLocalConversations(list: List<Conversation>) {
        try {
            val arr = JSONArray()
            list.take(50).forEach { c ->
                arr.put(
                    JSONObject().apply {
                        put("id", c.id)
                        put("userId", c.userId)
                        put("title", c.title)
                        put("lastMessagePreview", c.lastMessagePreview)
                        put("messageCount", c.messageCount)
                        put("sec", (c.updatedAt ?: c.createdAt)?.seconds ?: (System.currentTimeMillis() / 1000))
                    }
                )
            }
            localPrefs.edit().putString("conversations_json", arr.toString()).apply()
        } catch (_: Exception) {}
    }

    private fun loadLocalConversations(): List<Conversation> {
        val raw = localPrefs.getString("conversations_json", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = mutableListOf<Conversation>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val ts = Timestamp(o.optLong("sec", System.currentTimeMillis() / 1000), 0)
                out.add(
                    Conversation(
                        id = o.optString("id"),
                        userId = o.optString("userId", currentUserId),
                        title = o.optString("title", "New Chat"),
                        lastMessagePreview = o.optString("lastMessagePreview", ""),
                        messageCount = o.optLong("messageCount", 0L),
                        createdAt = ts,
                        updatedAt = ts
                    )
                )
            }
            out
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun saveLocalMessagesMap(map: Map<String, List<ChatMessage>>) {
        try {
            val root = JSONObject()
            map.forEach { (convId, msgs) ->
                val arr = JSONArray()
                msgs.takeLast(80).forEach { m ->
                    arr.put(
                        JSONObject().apply {
                            put("id", m.id)
                            put("role", m.role)
                            put("content", m.content)
                            put("attachmentSummary", m.attachmentSummary ?: "")
                            put("citations", m.citations ?: "")
                            put("sec", (m.createdAt ?: m.updatedAt)?.seconds ?: (System.currentTimeMillis() / 1000))
                        }
                    )
                }
                root.put(convId, arr)
            }
            localPrefs.edit().putString("messages_map_json", root.toString()).apply()
        } catch (_: Exception) {}
    }

    private fun loadLocalMessagesMap(): Map<String, List<ChatMessage>> {
        val raw = localPrefs.getString("messages_map_json", null) ?: return emptyMap()
        return try {
            val root = JSONObject(raw)
            val out = mutableMapOf<String, List<ChatMessage>>()
            val keys = root.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val arr = root.getJSONArray(k)
                val list = mutableListOf<ChatMessage>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val ts = Timestamp(o.optLong("sec", System.currentTimeMillis() / 1000), 0)
                    list.add(
                        ChatMessage(
                            id = o.optString("id"),
                            userId = currentUserId,
                            conversationId = k,
                            role = o.optString("role", "user"),
                            content = o.optString("content", ""),
                            attachmentSummary = o.optString("attachmentSummary").ifBlank { null },
                            citations = o.optString("citations").ifBlank { null },
                            createdAt = ts,
                            updatedAt = ts
                        )
                    )
                }
                out[k] = list
            }
            out
        } catch (_: Exception) {
            emptyMap()
        }
    }

    private fun saveLocalMemories(list: List<UserMemory>) {
        try {
            val arr = JSONArray()
            list.take(50).forEach { m ->
                arr.put(
                    JSONObject().apply {
                        put("id", m.id)
                        put("fact", m.fact)
                        put("category", m.category)
                    }
                )
            }
            localPrefs.edit().putString("memories_json", arr.toString()).apply()
        } catch (_: Exception) {}
    }

    private fun loadLocalMemories(): List<UserMemory> {
        val raw = localPrefs.getString("memories_json", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = mutableListOf<UserMemory>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    UserMemory(
                        id = o.optString("id"),
                        userId = currentUserId,
                        fact = o.optString("fact"),
                        category = o.optString("category", "Preference")
                    )
                )
            }
            out
        } catch (_: Exception) {
            emptyList()
        }
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager.release()
    }
}
