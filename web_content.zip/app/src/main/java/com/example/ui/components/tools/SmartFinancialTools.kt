package com.example.ui.components.tools

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.pow

fun formatInr(num: Double): String {
    val formatter = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
    return formatter.format(num).replace("₹", "₹ ")
}

fun formatInr(num: Long): String {
    val formatter = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
    formatter.maximumFractionDigits = 0
    return formatter.format(num).replace("₹", "₹ ")
}

// 1. CASH COUNTER DIALOG (नकद गणना)
@Composable
fun CashCounterDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    val denominations = listOf(500, 200, 100, 50, 20, 10, 5, 2, 1)
    val counts = remember { mutableStateMapOf<Int, String>() }

    val totalAmount = denominations.sumOf { denom ->
        val count = counts[denom]?.toLongOrNull() ?: 0L
        denom * count
    }
    val totalNotes = denominations.sumOf { denom -> counts[denom]?.toLongOrNull() ?: 0L }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            modifier = Modifier.fillMaxWidth(0.94f).clip(RoundedCornerShape(20.dp)),
            color = Color.White,
            shadowElevation = 8.dp
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "💵 नकद गणना (Cash Counter)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                    Row {
                        IconButton(onClick = { counts.clear() }) {
                            Icon(imageVector = Icons.Default.Refresh, contentDescription = "Clear", tint = Color.Black)
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                        }
                    }
                }

                // Summary Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                    border = BorderStroke(1.dp, Color(0xFF81C784)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "कुल राशि (Total Amount):", fontSize = 11.sp, color = Color(0xFF2E7D32))
                            Text(text = formatInr(totalAmount), fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1B5E20))
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "कुल नोट/सिक्के:", fontSize = 11.sp, color = Color(0xFF555555))
                            Text(text = "$totalNotes पीस", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(modifier = Modifier.weight(1f, fill = false).height(320.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(denominations) { denom ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier.width(64.dp).height(38.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFFF0F0F0)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(text = "₹ $denom", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
                            }
                            Text(text = "✖", fontSize = 12.sp, color = Color.Gray)
                            OutlinedTextField(
                                value = counts[denom] ?: "",
                                onValueChange = { counts[denom] = it.filter { ch -> ch.isDigit() } },
                                placeholder = { Text("0", fontSize = 12.sp) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.weight(1f).height(48.dp),
                                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp, fontWeight = FontWeight.Bold),
                                shape = RoundedCornerShape(6.dp)
                            )
                            Text(text = "=", fontSize = 12.sp, color = Color.Gray)
                            val subtotal = denom * (counts[denom]?.toLongOrNull() ?: 0L)
                            Text(
                                text = "₹ $subtotal",
                                modifier = Modifier.width(80.dp),
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Color.Black
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = {
                        val summary = buildString {
                            append("--- नकद गणना पर्ची ---\n")
                            denominations.forEach { denom ->
                                val count = counts[denom]?.toLongOrNull() ?: 0L
                                if (count > 0) append("₹ $denom x $count = ₹ ${denom * count}\n")
                            }
                            append("--------------------\n")
                            append("कुल नोट: $totalNotes\n")
                            append("कुल राशि: ₹ $totalAmount\n")
                        }
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("Cash Summary", summary))
                        Toast.makeText(context, "विवरण कॉपी हो गया!", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxWidth().height(44.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Black, contentColor = Color.White)
                ) {
                    Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "पर्ची कॉपी करें (Copy Breakdown)", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// 2. SIMPLE & COMPOUND INTEREST DIALOG (साधारण व चक्रवृद्धि ब्याज)
@Composable
fun InterestCalculatorDialog(isCompound: Boolean, onDismiss: () -> Unit) {
    var principalStr by remember { mutableStateOf("100000") }
    var rateStr by remember { mutableStateOf("12") }
    var timeStr by remember { mutableStateOf("1") }
    var isMonthlyRate by remember { mutableStateOf(false) } // ₹ सैकड़ा vs वार्षिक %

    val p = principalStr.toDoubleOrNull() ?: 0.0
    val rawRate = rateStr.toDoubleOrNull() ?: 0.0
    val tYears = timeStr.toDoubleOrNull() ?: 0.0

    val annualRate = if (isMonthlyRate) rawRate * 12 else rawRate

    val (interest, total) = if (isCompound) {
        val totalAmt = p * (1 + (annualRate / 100)).pow(tYears)
        val intAmt = totalAmt - p
        intAmt to totalAmt
    } else {
        val intAmt = (p * annualRate * tYears) / 100.0
        val totalAmt = p + intAmt
        intAmt to totalAmt
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.fillMaxWidth(0.94f).clip(RoundedCornerShape(20.dp)),
            color = Color.White,
            shadowElevation = 8.dp
        ) {
            Column(modifier = Modifier.padding(18.dp).verticalScroll(rememberScrollState())) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isCompound) "📈 चक्रवृद्धि ब्याज (Compound)" else "💰 साधारण ब्याज (Simple Interest)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = principalStr,
                    onValueChange = { principalStr = it.filter { ch -> ch.isDigit() || ch == '.' } },
                    label = { Text("मूलधन राशि (Principal Amount ₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = rateStr,
                        onValueChange = { rateStr = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        label = { Text(if (isMonthlyRate) "दर (₹ प्रति सैकड़ा/माह)" else "ब्याज दर (% वार्षिक)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = timeStr,
                        onValueChange = { timeStr = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        label = { Text("समय (वर्ष में)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    FilterChip(
                        selected = !isMonthlyRate,
                        onClick = { isMonthlyRate = false },
                        label = { Text("वार्षिक % दर", fontSize = 11.sp) }
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    FilterChip(
                        selected = isMonthlyRate,
                        onClick = { isMonthlyRate = true },
                        label = { Text("मासिक (सैकड़ा) दर", fontSize = 11.sp) }
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F5F5)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "कुल ब्याज (Interest):", color = Color(0xFF555555), fontSize = 12.sp)
                            Text(text = formatInr(interest), fontWeight = FontWeight.Bold, color = Color(0xFFD84315), fontSize = 14.sp)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "कुल देय राशि (Maturity Amount):", color = Color(0xFF555555), fontSize = 12.sp)
                            Text(text = formatInr(total), fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32), fontSize = 16.sp)
                        }
                    }
                }
            }
        }
    }
}

// 3. EMI CALCULATOR DIALOG
@Composable
fun EmiCalculatorDialog(onDismiss: () -> Unit) {
    var loanStr by remember { mutableStateOf("500000") }
    var rateStr by remember { mutableStateOf("9.5") }
    var tenureMonthsStr by remember { mutableStateOf("36") }

    val p = loanStr.toDoubleOrNull() ?: 0.0
    val annualRate = rateStr.toDoubleOrNull() ?: 0.0
    val n = tenureMonthsStr.toDoubleOrNull() ?: 1.0

    val r = (annualRate / 12.0) / 100.0
    val emi = if (r > 0 && n > 0 && p > 0) {
        val factor = (1 + r).pow(n)
        (p * r * factor) / (factor - 1)
    } else 0.0

    val totalPayable = emi * n
    val totalInterest = totalPayable - p

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.fillMaxWidth(0.94f).clip(RoundedCornerShape(20.dp)),
            color = Color.White,
            shadowElevation = 8.dp
        ) {
            Column(modifier = Modifier.padding(18.dp).verticalScroll(rememberScrollState())) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "🏦 EMI कैलकुलेटर (Loan EMI)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = loanStr,
                    onValueChange = { loanStr = it.filter { ch -> ch.isDigit() || ch == '.' } },
                    label = { Text("लोन राशि (Loan Amount ₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = rateStr,
                        onValueChange = { rateStr = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        label = { Text("ब्याज दर (% Annual)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = tenureMonthsStr,
                        onValueChange = { tenureMonthsStr = it.filter { ch -> ch.isDigit() } },
                        label = { Text("अवधि (महीने)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFE3F2FD)),
                    border = BorderStroke(1.dp, Color(0xFF90CAF9)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "मासिक किश्त (Monthly EMI):", color = Color(0xFF1565C0), fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            Text(text = formatInr(emi), fontWeight = FontWeight.ExtraBold, color = Color(0xFF0D47A1), fontSize = 18.sp)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "कुल ब्याज (Total Interest):", color = Color(0xFF555555), fontSize = 12.sp)
                            Text(text = formatInr(totalInterest), fontWeight = FontWeight.Bold, color = Color(0xFFD84315), fontSize = 13.sp)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "कुल देय (Total Payable):", color = Color(0xFF555555), fontSize = 12.sp)
                            Text(text = formatInr(totalPayable), fontWeight = FontWeight.Bold, color = Color.Black, fontSize = 14.sp)
                        }
                    }
                }
            }
        }
    }
}

// 4. GST CALCULATOR DIALOG
@Composable
fun GstCalculatorDialog(onDismiss: () -> Unit) {
    var amountStr by remember { mutableStateOf("1000") }
    var selectedRate by remember { mutableStateOf(18.0) }
    var isAddGst by remember { mutableStateOf(true) }

    val amt = amountStr.toDoubleOrNull() ?: 0.0
    val gstRates = listOf(3.0, 5.0, 12.0, 18.0, 28.0)

    val (gstAmt, finalAmt) = if (isAddGst) {
        val gst = (amt * selectedRate) / 100.0
        gst to (amt + gst)
    } else {
        val original = amt / (1 + selectedRate / 100.0)
        val gst = amt - original
        gst to original
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.fillMaxWidth(0.94f).clip(RoundedCornerShape(20.dp)),
            color = Color.White,
            shadowElevation = 8.dp
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "📊 GST कैलकुलेटर", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = it.filter { ch -> ch.isDigit() || ch == '.' } },
                    label = { Text("राशि (Amount ₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(text = "GST स्लैब दर चुनें:", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    gstRates.forEach { rate ->
                        FilterChip(
                            selected = selectedRate == rate,
                            onClick = { selectedRate = rate },
                            label = { Text("${rate.toInt()}%", fontSize = 11.sp) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { isAddGst = true },
                        modifier = Modifier.weight(1f).height(38.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isAddGst) Color.Black else Color(0xFFF0F0F0),
                            contentColor = if (isAddGst) Color.White else Color.Black
                        )
                    ) {
                        Text("GST जोड़ें (+)", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = { isAddGst = false },
                        modifier = Modifier.weight(1f).height(38.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (!isAddGst) Color.Black else Color(0xFFF0F0F0),
                            contentColor = if (!isAddGst) Color.White else Color.Black
                        )
                    ) {
                        Text("GST घटाएं (-)", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F5F5)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "GST राशि (${selectedRate.toInt()}%):", fontSize = 12.sp, color = Color(0xFF555555))
                            Text(text = formatInr(gstAmt), fontWeight = FontWeight.Bold, color = Color(0xFFD84315), fontSize = 14.sp)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "CGST + SGST (प्रत्येक):", fontSize = 11.sp, color = Color(0xFF666666))
                            Text(text = formatInr(gstAmt / 2.0), fontSize = 11.5.sp, color = Color.Black)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = if (isAddGst) "कुल मूल्य (Total With GST):" else "मूल कीमत (Without GST):", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                            Text(text = formatInr(finalAmt), fontWeight = FontWeight.ExtraBold, color = Color(0xFF2E7D32), fontSize = 16.sp)
                        }
                    }
                }
            }
        }
    }
}

// 5. RD CALCULATOR DIALOG
@Composable
fun RdCalculatorDialog(onDismiss: () -> Unit) {
    var monthlyStr by remember { mutableStateOf("5000") }
    var rateStr by remember { mutableStateOf("7.2") }
    var monthsStr by remember { mutableStateOf("12") }

    val m = monthlyStr.toDoubleOrNull() ?: 0.0
    val r = (rateStr.toDoubleOrNull() ?: 0.0) / 100.0
    val n = monthsStr.toDoubleOrNull() ?: 1.0

    val totalInvestment = m * n
    // RD quarterly compound formula approximation
    val totalInterest = (m * n * (n + 1) * r) / 24.0
    val maturityAmount = totalInvestment + totalInterest

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.fillMaxWidth(0.94f).clip(RoundedCornerShape(20.dp)),
            color = Color.White,
            shadowElevation = 8.dp
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "📅 RD आवर्ती जमा कैलकुलेटर", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.Black)
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = monthlyStr,
                    onValueChange = { monthlyStr = it.filter { ch -> ch.isDigit() } },
                    label = { Text("मासिक जमा (Monthly Deposit ₹)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = rateStr,
                        onValueChange = { rateStr = it.filter { ch -> ch.isDigit() || ch == '.' } },
                        label = { Text("ब्याज दर (% Annual)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = monthsStr,
                        onValueChange = { monthsStr = it.filter { ch -> ch.isDigit() } },
                        label = { Text("अवधि (महीने)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF9FBE7)),
                    border = BorderStroke(1.dp, Color(0xFFDCE775)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "कुल जमा राशि:", fontSize = 12.sp, color = Color(0xFF555555))
                            Text(text = formatInr(totalInvestment), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Black)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "कुल ब्याज लाभ:", fontSize = 12.sp, color = Color(0xFF555555))
                            Text(text = formatInr(totalInterest), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFFD84315))
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "परिपक्वता मूल्य (Maturity):", fontSize = 12.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFF33691E))
                            Text(text = formatInr(maturityAmount), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = Color(0xFF33691E))
                        }
                    }
                }
            }
        }
    }
}
