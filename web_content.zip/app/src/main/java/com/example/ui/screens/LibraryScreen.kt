package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Song
import com.example.model.SongSortOption
import com.example.ui.components.SongTagDialog
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LibraryScreen(
    songs: List<Song>,
    allDistinctTags: List<String>,
    activeSong: Song?,
    isPlaying: Boolean,
    onSongSelected: (Song) -> Unit,
    onToggleFavorite: (String) -> Unit,
    onUpdateSongTags: (String, List<String>) -> Unit,
    onImportSong: (title: String, artist: String, uri: String, duration: Int) -> Unit,
    onNavigateToEqualizer: () -> Unit,
    onNavigateToSync: () -> Unit,
    onNavigateToNowPlaying: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedGenre by remember { mutableStateOf<String?>(null) }
    var selectedTag by remember { mutableStateOf<String?>(null) }
    var sortOption by remember { mutableStateOf(SongSortOption.TITLE_ASC) }
    var sortMenuExpanded by remember { mutableStateOf(false) }

    var editingSongForTags by remember { mutableStateOf<Song?>(null) }

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            val fileName = it.lastPathSegment?.substringAfterLast('/') ?: "Imported Track"
            onImportSong(fileName.replace(".mp3", "").replace(".wav", ""), "Local Audio", it.toString(), 210)
        }
    }

    // Filter and sort songs
    val filteredSongs = remember(songs, searchQuery, selectedGenre, selectedTag, sortOption) {
        val q = searchQuery.trim().lowercase()
        songs.filter { song ->
            val matchesQuery = q.isEmpty() ||
                    song.title.lowercase().contains(q) ||
                    song.artist.lowercase().contains(q) ||
                    song.album.lowercase().contains(q) ||
                    song.genre.lowercase().contains(q) ||
                    song.year.toString().contains(q) ||
                    song.customTags.any { it.lowercase().contains(q) }

            val matchesGenre = selectedGenre == null || song.genre.equals(selectedGenre, ignoreCase = true)
            val matchesTag = selectedTag == null || song.customTags.any { it.equals(selectedTag, ignoreCase = true) }

            matchesQuery && matchesGenre && matchesTag
        }.let { list ->
            when (sortOption) {
                SongSortOption.TITLE_ASC -> list.sortedBy { it.title.lowercase() }
                SongSortOption.TITLE_DESC -> list.sortedByDescending { it.title.lowercase() }
                SongSortOption.ARTIST -> list.sortedBy { it.artist.lowercase() }
                SongSortOption.ALBUM -> list.sortedBy { it.album.lowercase() }
                SongSortOption.GENRE -> list.sortedBy { it.genre.lowercase() }
                SongSortOption.YEAR_NEWEST -> list.sortedByDescending { it.year }
                SongSortOption.YEAR_OLDEST -> list.sortedBy { it.year }
                SongSortOption.CUSTOM_TAGS -> list.sortedByDescending { it.customTags.size }
                SongSortOption.DURATION -> list.sortedByDescending { it.durationSec }
                SongSortOption.MOST_PLAYED -> list.sortedByDescending { it.playCount }
                SongSortOption.FAVORITES -> list.sortedByDescending { it.isFavorite }
            }
        }
    }

    val genres = remember(songs) {
        listOf("All") + songs.map { it.genre }.distinct()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .padding(horizontal = 16.dp)
            .testTag("library_screen")
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Top App Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "PrismSound",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White
                )
                Text(
                    text = "Offline Master Library (${songs.size} tracks)",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }

            Row {
                IconButton(
                    onClick = onNavigateToEqualizer,
                    modifier = Modifier.testTag("library_eq_nav_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Equalizer,
                        contentDescription = "Equalizer",
                        tint = NeonCyan
                    )
                }
                IconButton(
                    onClick = onNavigateToSync,
                    modifier = Modifier.testTag("library_sync_nav_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Sync,
                        contentDescription = "Cross-Platform Sync",
                        tint = NeonPurple
                    )
                }
                IconButton(
                    onClick = { filePickerLauncher.launch(arrayOf("audio/*")) },
                    modifier = Modifier.testTag("import_audio_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Import Audio",
                        tint = Color.White
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Search Bar & Sort Button
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search by title, artist, genre, tag, year...") },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        tint = NeonCyan
                    )
                },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonCyan,
                    unfocusedBorderColor = SurfaceElevated,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("library_search_input")
            )

            Spacer(modifier = Modifier.width(8.dp))

            // Sort Dropdown Menu
            Box {
                IconButton(
                    onClick = { sortMenuExpanded = true },
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(SurfaceElevated)
                        .testTag("sort_menu_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Sort,
                        contentDescription = "Sort library",
                        tint = NeonCyan
                    )
                }

                DropdownMenu(
                    expanded = sortMenuExpanded,
                    onDismissRequest = { sortMenuExpanded = false },
                    modifier = Modifier.background(SurfaceDark)
                ) {
                    SongSortOption.values().forEach { option ->
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = option.displayName,
                                    color = if (sortOption == option) NeonCyan else Color.White,
                                    fontWeight = if (sortOption == option) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            onClick = {
                                sortOption = option
                                sortMenuExpanded = false
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Genre filter pills
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 4.dp)
        ) {
            items(genres) { g ->
                val isSelected = (g == "All" && selectedGenre == null) || (g == selectedGenre)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSelected) NeonCyan else SurfaceElevated)
                        .clickable { selectedGenre = if (g == "All") null else g }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = g,
                        color = if (isSelected) ObsidianBg else Color.White,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }

        // Custom tag filter pills if any tags exist
        if (allDistinctTags.isNotEmpty()) {
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                contentPadding = PaddingValues(vertical = 2.dp)
            ) {
                items(allDistinctTags) { tag ->
                    val isSelected = selectedTag == tag
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) NeonPurple else SurfaceElevated.copy(alpha = 0.6f))
                            .clickable { selectedTag = if (isSelected) null else tag }
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "#$tag",
                            color = if (isSelected) ObsidianBg else NeonPurple,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Song List
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            items(filteredSongs, key = { it.id }) { song ->
                val isCurrent = activeSong?.id == song.id
                SongItemCard(
                    song = song,
                    isActive = isCurrent,
                    isPlaying = isPlaying,
                    onClick = { onSongSelected(song) },
                    onFavoriteClick = { onToggleFavorite(song.id) },
                    onEditTagsClick = { editingSongForTags = song }
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
    }

    // Song Tag Editor Dialog
    editingSongForTags?.let { songToEdit ->
        SongTagDialog(
            song = songToEdit,
            onTagsUpdated = { updatedTags ->
                onUpdateSongTags(songToEdit.id, updatedTags)
                editingSongForTags = null
            },
            onDismiss = { editingSongForTags = null }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SongItemCard(
    song: Song,
    isActive: Boolean,
    isPlaying: Boolean,
    onClick: () -> Unit,
    onFavoriteClick: () -> Unit,
    onEditTagsClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("song_item_${song.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = if (isActive) SurfaceElevated else SurfaceDark),
        border = if (isActive) androidx.compose.foundation.BorderStroke(1.5.dp, NeonCyan) else null
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Album Art Gradient Box
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(Color(song.primaryColorHex), Color(song.secondaryColorHex))
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isActive && isPlaying) Icons.Default.Equalizer else Icons.Default.MusicNote,
                        contentDescription = null,
                        tint = ObsidianBg,
                        modifier = Modifier.size(26.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Title & Details
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = song.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = if (isActive) NeonCyan else Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${song.artist} • ${song.album} (${song.year})",
                        fontSize = 12.sp,
                        color = Color.LightGray,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = song.genre,
                            fontSize = 11.sp,
                            color = NeonPurple,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        // Poweramp Audiophile Codec Badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(NeonCyan.copy(alpha = 0.15f))
                                .border(0.6.dp, NeonCyan.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = "${song.codec} ${song.bitDepth}b",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = NeonCyan
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = song.durationFormatted,
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                }

                // Heart favorite
                IconButton(
                    onClick = onFavoriteClick,
                    modifier = Modifier.testTag("fav_btn_${song.id}")
                ) {
                    Icon(
                        imageVector = if (song.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (song.isFavorite) NeonPink else Color.Gray,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Tag editor button
                IconButton(
                    onClick = onEditTagsClick,
                    modifier = Modifier.testTag("tag_btn_${song.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.LocalOffer,
                        contentDescription = "Edit Tags",
                        tint = NeonCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Custom Tag chips on card
            if (song.customTags.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    song.customTags.forEach { tag ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(SurfaceDark.copy(alpha = 0.8f))
                                .border(0.8.dp, NeonPurple.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "#$tag",
                                color = NeonPurple,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }
    }
}
