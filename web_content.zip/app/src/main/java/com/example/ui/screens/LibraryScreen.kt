package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlaylistAdd
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SongEntity
import com.example.ui.LibraryFilter
import com.example.ui.SortOption
import com.example.ui.components.ArtworkImage
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkError
import com.example.ui.theme.DarkFavorite
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.OnEmeraldContainer
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.util.TimeUtils

@Composable
fun LibraryScreen(
    songs: List<SongEntity>,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    sortOption: SortOption,
    sortAscending: Boolean,
    onSortOptionChange: (SortOption) -> Unit,
    onSortAscendingToggle: () -> Unit,
    libraryFilter: LibraryFilter,
    onFilterChange: (LibraryFilter) -> Unit,
    isMultiSelectMode: Boolean,
    selectedSongIds: Set<Long>,
    onToggleSelectSong: (Long) -> Unit,
    onSelectAll: () -> Unit,
    onClearSelection: () -> Unit,
    onDeleteSelectedSongs: () -> Unit,
    onAddSelectedToPlaylist: () -> Unit,
    onSongClick: (SongEntity, List<SongEntity>) -> Unit,
    onPlayNext: (SongEntity) -> Unit,
    onAddToQueue: (SongEntity) -> Unit,
    onAddToPlaylist: (SongEntity) -> Unit,
    onEditMetadata: (SongEntity) -> Unit,
    onToggleFavorite: (SongEntity) -> Unit,
    onRemoveFromLibrary: (SongEntity) -> Unit,
    onAddSongs: (List<Uri>) -> Unit,
    modifier: Modifier = Modifier
) {
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            onAddSongs(uris)
        }
    }

    var showSortMenu by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .testTag("library_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            // Header or Multi-select toolbar
            if (isMultiSelectMode) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onClearSelection) {
                            Icon(Icons.Default.Close, contentDescription = "Cancel", tint = TextPrimary)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "${selectedSongIds.size} selected",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Row {
                        TextButton(onClick = onSelectAll) {
                            Text("Select All", color = EmeraldPrimary)
                        }
                        IconButton(onClick = onAddSelectedToPlaylist) {
                            Icon(Icons.Default.PlaylistAdd, contentDescription = "Add to Playlist", tint = EmeraldPrimary)
                        }
                        IconButton(onClick = onDeleteSelectedSongs) {
                            Icon(Icons.Default.Delete, contentDescription = "Remove from Library", tint = DarkError)
                        }
                    }
                }
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp, bottom = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Library",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )

                    Row {
                        IconButton(
                            onClick = { filePickerLauncher.launch(arrayOf("audio/*")) },
                            modifier = Modifier.testTag("library_add_songs_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Add Songs",
                                tint = EmeraldPrimary,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                    }
                }

                // Search Bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchQueryChange,
                    placeholder = { Text("Search songs, artists, albums", color = TextSecondary) },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = null, tint = TextSecondary)
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onSearchQueryChange("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextSecondary)
                            }
                        }
                    },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = DarkSurfaceElevated,
                        unfocusedContainerColor = DarkSurfaceElevated,
                        focusedBorderColor = EmeraldPrimary,
                        unfocusedBorderColor = DarkSurfaceBorder
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("library_search_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Filter & Sort Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(
                            selected = (libraryFilter == LibraryFilter.ALL),
                            onClick = { onFilterChange(LibraryFilter.ALL) },
                            label = { Text("All", fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = EmeraldContainer,
                                selectedLabelColor = OnEmeraldContainer,
                                containerColor = DarkSurfaceElevated,
                                labelColor = TextPrimary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = (libraryFilter == LibraryFilter.ALL),
                                borderColor = DarkSurfaceBorder,
                                selectedBorderColor = EmeraldPrimary
                            )
                        )
                        FilterChip(
                            selected = (libraryFilter == LibraryFilter.FAVORITES),
                            onClick = { onFilterChange(LibraryFilter.FAVORITES) },
                            label = { Text("Favorites", fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = EmeraldContainer,
                                selectedLabelColor = OnEmeraldContainer,
                                containerColor = DarkSurfaceElevated,
                                labelColor = TextPrimary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = (libraryFilter == LibraryFilter.FAVORITES),
                                borderColor = DarkSurfaceBorder,
                                selectedBorderColor = EmeraldPrimary
                            )
                        )
                        FilterChip(
                            selected = (libraryFilter == LibraryFilter.RECENTLY_ADDED),
                            onClick = { onFilterChange(LibraryFilter.RECENTLY_ADDED) },
                            label = { Text("Recent", fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = EmeraldContainer,
                                selectedLabelColor = OnEmeraldContainer,
                                containerColor = DarkSurfaceElevated,
                                labelColor = TextPrimary
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = (libraryFilter == LibraryFilter.RECENTLY_ADDED),
                                borderColor = DarkSurfaceBorder,
                                selectedBorderColor = EmeraldPrimary
                            )
                        )
                    }

                    // Sort button with dropdown
                    Box {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { showSortMenu = true }
                                .padding(horizontal = 6.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.Sort, contentDescription = "Sort", tint = TextSecondary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = when (sortOption) {
                                    SortOption.TITLE -> "Title"
                                    SortOption.ARTIST -> "Artist"
                                    SortOption.ALBUM -> "Album"
                                    SortOption.DATE_ADDED -> "Added"
                                    SortOption.PLAY_COUNT -> "Plays"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary
                            )
                            IconButton(
                                onClick = onSortAscendingToggle,
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = if (sortAscending) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                                    contentDescription = "Toggle sort order",
                                    tint = EmeraldPrimary,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = showSortMenu,
                            onDismissRequest = { showSortMenu = false },
                            modifier = Modifier.background(DarkSurfaceElevated)
                        ) {
                            DropdownMenuItem(
                                text = { Text("Title (A-Z)", color = TextPrimary) },
                                onClick = { onSortOptionChange(SortOption.TITLE); showSortMenu = false }
                            )
                            DropdownMenuItem(
                                text = { Text("Artist", color = TextPrimary) },
                                onClick = { onSortOptionChange(SortOption.ARTIST); showSortMenu = false }
                            )
                            DropdownMenuItem(
                                text = { Text("Album", color = TextPrimary) },
                                onClick = { onSortOptionChange(SortOption.ALBUM); showSortMenu = false }
                            )
                            DropdownMenuItem(
                                text = { Text("Date Added", color = TextPrimary) },
                                onClick = { onSortOptionChange(SortOption.DATE_ADDED); showSortMenu = false }
                            )
                            DropdownMenuItem(
                                text = { Text("Play Count", color = TextPrimary) },
                                onClick = { onSortOptionChange(SortOption.PLAY_COUNT); showSortMenu = false }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Songs list
            if (songs.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(bottom = 96.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = if (searchQuery.isNotBlank()) "No matching songs" else "No songs in library",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (searchQuery.isNotBlank()) "Try another keyword" else "Tap Add Songs to import music",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(songs, key = { it.id }) { song ->
                        SongRowItem(
                            song = song,
                            isMultiSelectMode = isMultiSelectMode,
                            isSelected = selectedSongIds.contains(song.id),
                            onToggleSelect = { onToggleSelectSong(song.id) },
                            onClick = {
                                if (isMultiSelectMode) {
                                    onToggleSelectSong(song.id)
                                } else {
                                    onSongClick(song, songs)
                                }
                            },
                            onLongClick = { onToggleSelectSong(song.id) },
                            onPlayNext = { onPlayNext(song) },
                            onAddToQueue = { onAddToQueue(song) },
                            onAddToPlaylist = { onAddToPlaylist(song) },
                            onEditMetadata = { onEditMetadata(song) },
                            onToggleFavorite = { onToggleFavorite(song) },
                            onRemoveFromLibrary = { onRemoveFromLibrary(song) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SongRowItem(
    song: SongEntity,
    isMultiSelectMode: Boolean,
    isSelected: Boolean,
    onToggleSelect: () -> Unit,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onPlayNext: () -> Unit,
    onAddToQueue: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onEditMetadata: () -> Unit,
    onToggleFavorite: () -> Unit,
    onRemoveFromLibrary: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) DarkSurfaceHighlight else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (isMultiSelectMode) {
            Checkbox(
                checked = isSelected,
                onCheckedChange = { onToggleSelect() },
                colors = CheckboxDefaults.colors(
                    checkedColor = EmeraldPrimary,
                    uncheckedColor = DarkSurfaceBorder,
                    checkmarkColor = DarkBackground
                ),
                modifier = Modifier.size(36.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
        }

        ArtworkImage(
            artworkPath = song.customArtworkPath,
            contentDescription = null,
            modifier = Modifier.size(46.dp),
            shape = RoundedCornerShape(8.dp)
        )

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = song.title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                color = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "${song.artist} • ${TimeUtils.formatDuration(song.durationMs)}",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        IconButton(
            onClick = onToggleFavorite,
            modifier = Modifier.size(40.dp)
        ) {
            Icon(
                imageVector = if (song.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = if (song.isFavorite) "Unfavorite" else "Favorite",
                tint = if (song.isFavorite) DarkFavorite else TextSecondary.copy(alpha = 0.6f),
                modifier = Modifier.size(20.dp)
            )
        }

        Box {
            IconButton(
                onClick = { showMenu = true },
                modifier = Modifier.size(40.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "Options",
                    tint = TextSecondary,
                    modifier = Modifier.size(20.dp)
                )
            }

            DropdownMenu(
                expanded = showMenu,
                onDismissRequest = { showMenu = false },
                modifier = Modifier.background(DarkSurfaceElevated)
            ) {
                DropdownMenuItem(
                    text = { Text("Play Next", color = TextPrimary) },
                    onClick = { onPlayNext(); showMenu = false },
                    leadingIcon = { Icon(Icons.Default.PlayArrow, contentDescription = null, tint = EmeraldPrimary) }
                )
                DropdownMenuItem(
                    text = { Text("Add to Queue", color = TextPrimary) },
                    onClick = { onAddToQueue(); showMenu = false },
                    leadingIcon = { Icon(Icons.Default.QueueMusic, contentDescription = null, tint = TextSecondary) }
                )
                DropdownMenuItem(
                    text = { Text("Add to Playlist", color = TextPrimary) },
                    onClick = { onAddToPlaylist(); showMenu = false },
                    leadingIcon = { Icon(Icons.Default.PlaylistAdd, contentDescription = null, tint = TextSecondary) }
                )
                DropdownMenuItem(
                    text = { Text("Edit Metadata & Cover", color = TextPrimary) },
                    onClick = { onEditMetadata(); showMenu = false },
                    leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, tint = TextSecondary) }
                )
                DropdownMenuItem(
                    text = { Text("Remove from Library", color = DarkError) },
                    onClick = { onRemoveFromLibrary(); showMenu = false },
                    leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = DarkError) }
                )
            }
        }
    }
}
