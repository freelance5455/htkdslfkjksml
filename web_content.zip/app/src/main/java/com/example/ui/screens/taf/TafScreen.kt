package com.example.ui.screens.taf

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.UiState
import com.example.ui.viewmodel.WeatherViewModel

@Composable
fun TafScreen(
  viewModel: WeatherViewModel,
  modifier: Modifier = Modifier
) {
  val selectedAirport by viewModel.selectedAirport.collectAsState()
  val tafState by viewModel.tafState.collectAsState()
  val isOffline by viewModel.isOffline.collectAsState()
  val clipboard = LocalClipboardManager.current
  val context = LocalContext.current

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp)
      .testTag("taf_screen"),
    verticalArrangement = Arrangement.spacedBy(14.dp),
    contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
  ) {
    if (isOffline) {
      item { OfflineNoticeBanner() }
    }

    // Header (English)
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "Terminal Aerodrome Forecast (RAW TAF)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = AtcTextMain
          )
          Text(
            text = "${selectedAirport.icao} (${selectedAirport.iata}) • ${selectedAirport.nameEn}",
            style = MaterialTheme.typography.bodySmall,
            color = AtcTextMuted
          )
        }

        IconButton(onClick = { viewModel.loadWeatherForSelectedAirport() }) {
          Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = OceanBlue)
        }
      }
    }

    when (val state = tafState) {
      is UiState.Success -> {
        val taf = state.data

        // PURE RAW TAF CARD - SOFT GREEN (سبز ملایم)
        // No explanation, no timeline breakdown, pure raw format for controllers
        item {
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = TafCardBg),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, TafCardBorder),
            modifier = Modifier.fillMaxWidth().testTag("raw_taf_card")
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(
                    imageVector = Icons.Default.Schedule,
                    contentDescription = null,
                    tint = TafCardText,
                    modifier = Modifier.size(22.dp)
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = "RAW TAF FORECAST",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TafCardText
                  )
                }

                IconButton(
                  onClick = {
                    clipboard.setText(AnnotatedString(taf.rawTaf))
                    Toast.makeText(context, "TAF copied to clipboard", Toast.LENGTH_SHORT).show()
                  },
                  modifier = Modifier.testTag("btn_copy_taf")
                ) {
                  Icon(
                    imageVector = Icons.Default.ContentCopy,
                    contentDescription = "Copy RAW TAF",
                    tint = TafCardText
                  )
                }
              }

              Spacer(modifier = Modifier.height(12.dp))

              // Technical Monospace Display for RAW TAF (Full soft green card body)
              Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color.White.copy(alpha = 0.25f),
                border = androidx.compose.foundation.BorderStroke(1.dp, TafCardBorder),
                modifier = Modifier.fillMaxWidth()
              ) {
                Text(
                  text = taf.rawTaf.ifBlank { "NO RAW TAF DATA AVAILABLE" },
                  style = MaterialTheme.typography.bodyLarge.copy(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 0.8.sp,
                    lineHeight = 24.sp
                  ),
                  color = TafCardText,
                  modifier = Modifier.padding(16.dp)
                )
              }

              Spacer(modifier = Modifier.height(12.dp))

              // Validity & Metadata Details
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Column {
                  Text(text = "Validity Period (UTC)", style = MaterialTheme.typography.labelSmall, color = TafCardText.copy(alpha = 0.7f))
                  Text(
                    text = "${taf.validFromUtc} - ${taf.validToUtc}",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = TafCardText
                  )
                }
                Column {
                  Text(text = "Issuance Time", style = MaterialTheme.typography.labelSmall, color = TafCardText.copy(alpha = 0.7f))
                  Text(text = taf.issueTimeUtc.ifBlank { "--" }, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = TafCardText)
                }
                Column {
                  Text(text = "Data Source", style = MaterialTheme.typography.labelSmall, color = TafCardText.copy(alpha = 0.7f))
                  Text(text = taf.source, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = TafCardText)
                }
              }
            }
          }
        }
      }

      is UiState.Loading -> {
        item {
          Card(modifier = Modifier.fillMaxWidth()) {
            Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
              CircularProgressIndicator(color = OceanBlue)
            }
          }
        }
      }

      is UiState.Error -> {
        item {
          Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
              Text("TAF Error: ${state.message}", color = StatusRed, fontWeight = FontWeight.Bold)
              Text("TAF data currently unavailable from OPMET feed.", style = MaterialTheme.typography.bodySmall)
            }
          }
        }
      }
    }

    item { OperationalDisclaimerCard() }
  }
}
