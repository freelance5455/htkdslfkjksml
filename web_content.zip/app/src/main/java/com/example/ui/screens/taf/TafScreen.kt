package com.example.ui.screens.taf

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.*
import com.example.ui.theme.StatusRed
import com.example.ui.viewmodel.UiState
import com.example.ui.viewmodel.WeatherViewModel

@Composable
fun TafScreen(
  viewModel: WeatherViewModel,
  modifier: Modifier = Modifier
) {
  val selectedAirport by viewModel.selectedAirport.collectAsState()
  val tafState by viewModel.tafState.collectAsState()
  val isOffline by viewModel.isOffline.collectAsState()

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp)
      .testTag("taf_screen"),
    verticalArrangement = Arrangement.spacedBy(14.dp),
    contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
  ) {
    if (isOffline) {
      item { OfflineNoticeBanner() }
    }

    // Screen Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "پیش‌بینی هوانوردی فرودگاه (TAF)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "${selectedAirport.icao} • ${selectedAirport.nameFa}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        IconButton(onClick = { viewModel.loadWeatherForSelectedAirport() }) {
          Icon(Icons.Default.Refresh, contentDescription = "به‌روزرسانی", tint = MaterialTheme.colorScheme.primary)
        }
      }
    }

    when (val state = tafState) {
      is UiState.Success -> {
        val taf = state.data

        // 1. ORIGINAL RAW TAF
        item {
          RawMessageCard(
            titleFa = "متن خام پیش‌بینی تف (RAW TAF)",
            rawText = taf.rawTaf,
            source = taf.source,
            issueTimeUtc = taf.issueTimeUtc
          )
        }

        // 2. TIMING & VALIDITY CARD
        item {
          Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            border = CardDefaults.outlinedCardBorder(),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Text(
                text = "زمان صدور و دوره اعتبار پیش‌بینی (Issuance & Validity)",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
              )
              Spacer(modifier = Modifier.height(10.dp))
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                  Text(text = "زمان صدور (Issue Time)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text(text = taf.issueTimeUtc.ifBlank { "مشخص شده در هدر" }, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                }
                Column {
                  Text(text = "دوره اعتبار (Validity Period)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text(
                    text = "${taf.validFromUtc} تا ${taf.validToUtc}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                  )
                }
                Column {
                  Text(text = "منبع پیام", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                  Text(text = taf.source, style = MaterialTheme.typography.labelMedium)
                }
              }
            }
          }
        }

        // 3. DECODED TIMELINE FORECAST
        item {
          Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            border = CardDefaults.outlinedCardBorder(),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(14.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Schedule, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = "خط زمانی تغییرات پیش‌بینی (FM / BECMG / TEMPO)",
                  style = MaterialTheme.typography.titleSmall,
                  fontWeight = FontWeight.Bold
                )
              }

              Spacer(modifier = Modifier.height(12.dp))

              if (taf.forecastsSummary.isNotBlank()) {
                val groups = taf.forecastsSummary.split("\n\n")
                groups.forEachIndexed { index, group ->
                  Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = CardDefaults.outlinedCardBorder(),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                  ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                      Text(
                        text = group,
                        style = MaterialTheme.typography.bodySmall.copy(
                          fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                        ),
                        color = MaterialTheme.colorScheme.onSurface
                      )
                    }
                  }
                }
              } else {
                Text(
                  text = "پیش‌بینی پایه پیوسته بدون تغییرات ناگهانی گزارش شده است.",
                  style = MaterialTheme.typography.bodyMedium,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }
        }
      }

      is UiState.Loading -> {
        item {
          Card(modifier = Modifier.fillMaxWidth()) {
            Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator()
                Spacer(modifier = Modifier.height(12.dp))
                Text("در حال دریافت پیش‌بینی TAF فرودگاه...")
              }
            }
          }
        }
      }

      is UiState.Error -> {
        item {
          Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Column(modifier = Modifier.padding(16.dp)) {
              Text("خطا در دریافت TAF: ${state.message}", color = StatusRed, fontWeight = FontWeight.Bold)
              Spacer(modifier = Modifier.height(8.dp))
              Text("برای این فرودگاه پیام TAF معتبر صادر نشده است یا ایستگاه خارج از چرخه صدور تف است.", style = MaterialTheme.typography.bodySmall)
            }
          }
        }
      }
    }

    item { OperationalDisclaimerCard() }
  }
}
