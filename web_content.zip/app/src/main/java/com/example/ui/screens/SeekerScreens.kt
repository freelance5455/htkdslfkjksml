package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.localization.LocalAppStrings
import com.example.model.JobApplication
import com.example.model.JobListing
import com.example.model.JobyConstants
import com.example.model.SideQuest
import com.example.model.UserProfile
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.JobCard
import com.example.ui.components.SideQuestCard
import com.example.ui.components.StatusPill
import com.example.ui.components.ZeroFeeTrustBanner
import com.example.ui.components.formatInr
import com.example.ui.viewmodel.JobFilterState

@Composable
fun SeekerHomeScreen(
  profile: UserProfile,
  jobs: List<JobListing>,
  quests: List<SideQuest>,
  applications: List<JobApplication>,
  isAdminUser: Boolean,
  onSeedSampleData: () -> Unit,
  onToggleSave: (String) -> Unit,
  onSelectJob: (JobListing) -> Unit,
  onNavigateExplore: () -> Unit,
  onNavigateSideQuests: () -> Unit,
  onNavigateProfileEdit: () -> Unit
) {
  val strings = LocalAppStrings.current
  val activeJobs = remember(jobs) { jobs.filter { it.isActive } }
  val nearbyJobs = remember(activeJobs, profile.state, profile.city) {
    activeJobs.filter {
      it.state.equals(profile.state, ignoreCase = true) ||
        it.city.equals(profile.city, ignoreCase = true) ||
        it.isRemote
    }
  }
  val openQuests = remember(quests) { quests.filter { it.questStatus == "OPEN" } }
  val completionPct = remember(profile) { profile.profileCompletionPercent() }

  LazyColumn(
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
    modifier = Modifier.fillMaxSize()
  ) {
    item {
      Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column {
          Image(
            painter = painterResource(id = R.drawable.img_joby_hero),
            contentDescription = "JOBY Pan-India Opportunities",
            contentScale = ContentScale.Crop,
            modifier = Modifier
              .fillMaxWidth()
              .height(130.dp)
              .clip(RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp))
          )
          Column(modifier = Modifier.padding(16.dp)) {
            Text(
              text = "Namaste, ${profile.displayName.substringBefore(" ")}!",
              style = MaterialTheme.typography.headlineSmall,
              color = MaterialTheme.colorScheme.onPrimary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "${profile.city}, ${profile.state} · PIN ${profile.pincode}",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "Profile strength: $completionPct%",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.secondaryContainer
              )
              if (completionPct < 100) {
                TextButton(onClick = onNavigateProfileEdit) {
                  Text(
                    text = "Complete Profile",
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    fontWeight = FontWeight.Bold
                  )
                }
              }
            }
            LinearProgressIndicator(
              progress = { completionPct / 100f },
              color = MaterialTheme.colorScheme.secondaryContainer,
              trackColor = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.2f),
              modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(4.dp))
            )
          }
        }
      }
    }

    item {
      ZeroFeeTrustBanner()
    }

    item {
      Row(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        QuickStatTile(
          label = "Open Jobs",
          value = activeJobs.size.toString(),
          onClick = onNavigateExplore,
          modifier = Modifier.weight(1f)
        )
        QuickStatTile(
          label = "Side Quests",
          value = openQuests.size.toString(),
          onClick = onNavigateSideQuests,
          modifier = Modifier.weight(1f)
        )
        QuickStatTile(
          label = "My Applied",
          value = applications.size.toString(),
          onClick = {},
          modifier = Modifier.weight(1f)
        )
      }
    }

    if (activeJobs.isEmpty() && openQuests.isEmpty()) {
      item {
        EmptyStateCard(
          title = "Marketplace Awaiting Approved Listings",
          subtitle = if (isAdminUser) {
            "Seed realistic pan-India jobs, Side Quests, and subscription plans into Firestore with one tap."
          } else {
            "New jobs and Side Quests appear here once verified by JOBY Moderation."
          },
          actionContent = if (isAdminUser) {
            {
              Button(
                onClick = onSeedSampleData,
                modifier = Modifier.testTag("seed_marketplace_button")
              ) {
                Text("Seed India Marketplace Data")
              }
            }
          } else null
        )
      }
    }

    if (openQuests.isNotEmpty()) {
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Bolt, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
            Spacer(modifier = Modifier.width(6.dp))
            Text(strings.activeSideQuests, style = MaterialTheme.typography.titleMedium)
          }
          TextButton(onClick = onNavigateSideQuests) { Text("View All") }
        }
      }
      items(openQuests.take(2), key = { "home_sq_${it.id}" }) { quest ->
        SideQuestCard(quest = quest, onClick = onNavigateSideQuests)
      }
    }

    if (nearbyJobs.isNotEmpty()) {
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(strings.nearYourCity, style = MaterialTheme.typography.titleMedium)
          TextButton(onClick = onNavigateExplore) { Text("Explore") }
        }
      }
      items(nearbyJobs.take(3), key = { "near_${it.id}" }) { job ->
        JobCard(
          job = job,
          isSaved = job.id in profile.savedJobIds,
          userAge = profile.age,
          onToggleSave = { onToggleSave(job.id) },
          onClick = { onSelectJob(job) }
        )
      }
    }

    if (activeJobs.isNotEmpty()) {
      item {
        Text(strings.recommendedForYou, style = MaterialTheme.typography.titleMedium)
      }
      items(activeJobs.take(5), key = { "rec_${it.id}" }) { job ->
        JobCard(
          job = job,
          isSaved = job.id in profile.savedJobIds,
          userAge = profile.age,
          onToggleSave = { onToggleSave(job.id) },
          onClick = { onSelectJob(job) }
        )
      }
    }
  }
}

@Composable
private fun QuickStatTile(
  label: String,
  value: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Card(
    onClick = onClick,
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    modifier = modifier
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Text(
        text = value,
        style = MaterialTheme.typography.headlineSmall,
        color = MaterialTheme.colorScheme.primary,
        fontWeight = FontWeight.Bold
      )
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ExploreJobsScreen(
  profile: UserProfile,
  jobs: List<JobListing>,
  filterState: JobFilterState,
  onUpdateFilter: ((JobFilterState) -> JobFilterState) -> Unit,
  onToggleSave: (String) -> Unit,
  onSelectJob: (JobListing) -> Unit
) {
  val strings = LocalAppStrings.current
  val filteredJobs = remember(jobs, filterState) {
    jobs.filter { job ->
      job.isActive &&
        (filterState.query.isBlank() ||
          job.title.contains(filterState.query, ignoreCase = true) ||
          job.companyName.contains(filterState.query, ignoreCase = true) ||
          job.city.contains(filterState.query, ignoreCase = true) ||
          job.pincode.contains(filterState.query, ignoreCase = true)) &&
        (filterState.selectedState == "All India" || job.state.equals(filterState.selectedState, ignoreCase = true)) &&
        (filterState.selectedCategory == "All" || job.category.equals(filterState.selectedCategory, ignoreCase = true)) &&
        (filterState.selectedJobType == "ALL" || job.jobType == filterState.selectedJobType) &&
        (!filterState.remoteOnly || job.isRemote)
    }
  }

  Column(modifier = Modifier.fillMaxSize()) {
    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
      OutlinedTextField(
        value = filterState.query,
        onValueChange = { q -> onUpdateFilter { it.copy(query = q) } },
        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
        trailingIcon = {
          if (filterState.query.isNotEmpty()) {
            IconButton(onClick = { onUpdateFilter { it.copy(query = "") } }) {
              Icon(Icons.Filled.Close, contentDescription = "Clear search")
            }
          }
        },
        placeholder = { Text(strings.searchHint) },
        singleLine = true,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth().testTag("explore_search_input")
      )

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.horizontalScroll(rememberScrollState())
      ) {
        JobyConstants.INDIAN_STATES.take(10).forEach { st ->
          FilterChip(
            selected = filterState.selectedState == st,
            onClick = { onUpdateFilter { it.copy(selectedState = st) } },
            label = { Text(st) }
          )
        }
      }

      Spacer(modifier = Modifier.height(6.dp))

      Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.horizontalScroll(rememberScrollState())
      ) {
        FilterChip(
          selected = filterState.remoteOnly,
          onClick = { onUpdateFilter { it.copy(remoteOnly = !it.remoteOnly) } },
          label = { Text("Remote / WFH") }
        )
        JobyConstants.JOB_TYPES.forEach { jt ->
          FilterChip(
            selected = filterState.selectedJobType == jt,
            onClick = { onUpdateFilter { it.copy(selectedJobType = jt) } },
            label = { Text(JobyConstants.jobTypeLabel(jt)) }
          )
        }
      }
    }

    LazyColumn(
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
      modifier = Modifier.fillMaxSize()
    ) {
      item {
        Text(
          text = "${filteredJobs.size} verified roles found",
          style = MaterialTheme.typography.labelMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
      if (filteredJobs.isEmpty()) {
        item {
          EmptyStateCard(
            title = "No matching jobs found",
            subtitle = "Try clearing your state, job type, or PIN code filters.",
            actionContent = {
              OutlinedButton(onClick = { onUpdateFilter { JobFilterState() } }) {
                Text("Reset Filters")
              }
            }
          )
        }
      } else {
        items(filteredJobs, key = { it.id }) { job ->
          JobCard(
            job = job,
            isSaved = job.id in profile.savedJobIds,
            userAge = profile.age,
            onToggleSave = { onToggleSave(job.id) },
            onClick = { onSelectJob(job) }
          )
        }
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun JobDetailBottomSheet(
  job: JobListing,
  profile: UserProfile,
  alreadyApplied: Boolean,
  isBusy: Boolean,
  onDismiss: () -> Unit,
  onApply: (String) -> Unit,
  onMessageEmployer: () -> Unit,
  onSubmitReport: (String, String) -> Unit
) {
  val strings = LocalAppStrings.current
  var coverNote by remember { mutableStateOf("") }
  var showReportDialog by remember { mutableStateOf(false) }
  var reportReason by remember { mutableStateOf("Application Fee Demanded") }
  var reportDetails by remember { mutableStateOf("") }

  val ageRestricted = profile.age < job.minAge || (job.isHazardousOrRestricted && profile.age < 18L)
  val isOwnJob = job.employerId == profile.userId

  ModalBottomSheet(onDismissRequest = onDismiss) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 20.dp, vertical = 10.dp)
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
          text = job.companyName,
          style = MaterialTheme.typography.titleSmall,
          color = MaterialTheme.colorScheme.primary
        )
        if (job.companyVerified) {
          Spacer(modifier = Modifier.width(6.dp))
          Icon(
            imageVector = Icons.Filled.Verified,
            contentDescription = "Verified Company",
            tint = MaterialTheme.colorScheme.tertiary,
            modifier = Modifier.size(16.dp)
          )
        }
      }
      Spacer(modifier = Modifier.height(4.dp))
      Text(text = job.title, style = MaterialTheme.typography.headlineSmall)
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = "${job.city}, ${job.state} (${job.pincode}) · ${if (job.isRemote) "Remote Eligible" else "On-Site"}",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )

      Spacer(modifier = Modifier.height(12.dp))
      FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        StatusPill(
          text = "${formatInr(job.salaryMinInr)}–${formatInr(job.salaryMaxInr)}${JobyConstants.salaryPeriodLabel(job.salaryPeriod)}",
          containerColor = MaterialTheme.colorScheme.primaryContainer,
          contentColor = MaterialTheme.colorScheme.onPrimaryContainer
        )
        StatusPill(
          text = JobyConstants.jobTypeLabel(job.jobType),
          containerColor = MaterialTheme.colorScheme.surfaceVariant,
          contentColor = MaterialTheme.colorScheme.onSurfaceVariant
        )
        StatusPill(
          text = JobyConstants.experienceLabel(job.experienceLevel),
          containerColor = MaterialTheme.colorScheme.surfaceVariant,
          contentColor = MaterialTheme.colorScheme.onSurfaceVariant
        )
        StatusPill(
          text = "₹0 Application Fee",
          containerColor = MaterialTheme.colorScheme.tertiaryContainer,
          contentColor = MaterialTheme.colorScheme.onTertiaryContainer
        )
      }

      Spacer(modifier = Modifier.height(16.dp))
      Text("Role Overview", style = MaterialTheme.typography.titleSmall)
      Spacer(modifier = Modifier.height(4.dp))
      Text(job.description, style = MaterialTheme.typography.bodyMedium)

      Spacer(modifier = Modifier.height(12.dp))
      Text("Requirements", style = MaterialTheme.typography.titleSmall)
      Spacer(modifier = Modifier.height(4.dp))
      Text(job.requirements, style = MaterialTheme.typography.bodyMedium)

      if (ageRestricted) {
        Spacer(modifier = Modifier.height(12.dp))
        Surface(
          color = MaterialTheme.colorScheme.errorContainer,
          shape = RoundedCornerShape(12.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Shield, contentDescription = null, tint = MaterialTheme.colorScheme.error)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "${strings.ageRestrictedLabel}. Your verified age (${profile.age}) is below the required ${job.minAge}+.",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onErrorContainer
            )
          }
        }
      } else if (!alreadyApplied && !isOwnJob) {
        Spacer(modifier = Modifier.height(14.dp))
        OutlinedTextField(
          value = coverNote,
          onValueChange = { coverNote = it.take(400) },
          label = { Text("Quick Note to Employer (Optional)") },
          minLines = 2,
          modifier = Modifier.fillMaxWidth().testTag("apply_cover_note_input")
        )
      }

      Spacer(modifier = Modifier.height(16.dp))
      Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
        if (!isOwnJob) {
          OutlinedButton(
            onClick = onMessageEmployer,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.weight(1f).height(48.dp)
          ) {
            Icon(Icons.Filled.Chat, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Message")
          }
        }
        Button(
          onClick = { onApply(coverNote) },
          enabled = !alreadyApplied && !ageRestricted && !isOwnJob && !isBusy,
          shape = RoundedCornerShape(14.dp),
          modifier = Modifier.weight(1.4f).height(48.dp).testTag("confirm_apply_button")
        ) {
          Text(
            when {
              isOwnJob -> "Your Listing"
              alreadyApplied -> "Already Applied"
              ageRestricted -> "18+ Restricted"
              isBusy -> "Submitting..."
              else -> strings.applyNow
            }
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))
      TextButton(
        onClick = { showReportDialog = true },
        modifier = Modifier.align(Alignment.CenterHorizontally)
      ) {
        Icon(Icons.Filled.Flag, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("Report Fake Job or Fee Demand")
      }
      Spacer(modifier = Modifier.height(20.dp))
    }
  }

  if (showReportDialog) {
    AlertDialog(
      onDismissRequest = { showReportDialog = false },
      title = { Text("Report Listing") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("Help keep JOBY 100% fee-free and safe across India.", style = MaterialTheme.typography.bodySmall)
          OutlinedTextField(
            value = reportReason,
            onValueChange = { reportReason = it },
            label = { Text("Reason") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
          OutlinedTextField(
            value = reportDetails,
            onValueChange = { reportDetails = it },
            label = { Text("Details *") },
            minLines = 2,
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (reportDetails.trim().length >= 5) {
              onSubmitReport(reportReason, reportDetails)
              showReportDialog = false
            }
          }
        ) { Text("Submit Report") }
      },
      dismissButton = {
        TextButton(onClick = { showReportDialog = false }) { Text("Cancel") }
      }
    )
  }
}
