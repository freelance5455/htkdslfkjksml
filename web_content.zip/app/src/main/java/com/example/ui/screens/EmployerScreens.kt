package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.WorkOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.model.JobApplication
import com.example.model.JobListing
import com.example.model.JobyConstants
import com.example.model.SideQuest
import com.example.model.SubscriptionPlan
import com.example.model.UserProfile
import com.example.ui.components.BarMetricChart
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.JobCard
import com.example.ui.components.SideQuestCard
import com.example.ui.components.StatusPill
import com.example.ui.components.formatInr

@Composable
fun EmployerDashboardScreen(
  profile: UserProfile,
  employerJobs: List<JobListing>,
  employerQuests: List<SideQuest>,
  applications: List<JobApplication>,
  plans: List<SubscriptionPlan>,
  isBusy: Boolean,
  onUpgradePlan: (SubscriptionPlan, String) -> Unit
) {
  var showUpgradeDialog by remember { mutableStateOf(false) }
  var selectedPayMethod by remember { mutableStateOf("UPI") }

  val activeVacancies = employerJobs.count { it.isActive && it.moderationStatus == "APPROVED" }
  val shortlisted = applications.count { it.status in listOf("SHORTLISTED", "INTERVIEW") }
  val selectedCount = applications.count { it.status == "SELECTED" }

  LazyColumn(
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp),
    modifier = Modifier.fillMaxSize()
  ) {
    item {
      Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = profile.companyName.ifBlank { profile.displayName },
              style = MaterialTheme.typography.titleLarge,
              color = MaterialTheme.colorScheme.onPrimary
            )
            if (profile.companyVerified) {
              Spacer(modifier = Modifier.width(6.dp))
              Icon(
                imageVector = Icons.Filled.Verified,
                contentDescription = "Verified",
                tint = MaterialTheme.colorScheme.secondaryContainer
              )
            }
          }
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "${profile.city}, ${profile.state} · Plan: ${profile.subscriptionTier}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f)
          )
          Spacer(modifier = Modifier.height(12.dp))
          OutlinedButton(
            onClick = { showUpgradeDialog = true },
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondaryContainer),
            modifier = Modifier.testTag("manage_subscription_button")
          ) {
            Text("Manage / Upgrade Plan", color = MaterialTheme.colorScheme.secondaryContainer)
          }
        }
      }
    }

    item {
      Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
        MetricBox("Active Jobs", activeVacancies.toString(), Modifier.weight(1f))
        MetricBox("Applicants", applications.size.toString(), Modifier.weight(1f))
        MetricBox("Shortlisted", shortlisted.toString(), Modifier.weight(1f))
        MetricBox("Hired", selectedCount.toString(), Modifier.weight(1f))
      }
    }

    item {
      BarMetricChart(
        title = "Hiring Funnel Analytics",
        bars = listOf(
          Triple("Applied", applications.count { it.status == "APPLIED" }, MaterialTheme.colorScheme.primary),
          Triple("Viewed", applications.count { it.status == "VIEWED" }, MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)),
          Triple("Shortlisted", applications.count { it.status == "SHORTLISTED" }, MaterialTheme.colorScheme.secondary),
          Triple("Interview", applications.count { it.status == "INTERVIEW" }, MaterialTheme.colorScheme.secondary.copy(alpha = 0.8f)),
          Triple("Selected", selectedCount, MaterialTheme.colorScheme.tertiary)
        )
      )
    }

    item {
      val pendingPayouts = employerQuests.count { it.questStatus == "COMPLETION_SUBMITTED" }
      Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text("Side Quests Escrow Summary", style = MaterialTheme.typography.titleSmall)
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "${employerQuests.size} total quests posted · $pendingPayouts awaiting completion payout verification.",
            style = MaterialTheme.typography.bodySmall
          )
        }
      }
    }
  }

  if (showUpgradeDialog) {
    AlertDialog(
      onDismissRequest = { showUpgradeDialog = false },
      title = { Text("Employer Subscription Plans") },
      text = {
        Column(
          verticalArrangement = Arrangement.spacedBy(10.dp),
          modifier = Modifier.verticalScroll(rememberScrollState())
        ) {
          Text(
            text = "Prices are dynamically configured by JOBY Admin.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = selectedPayMethod == "UPI", onClick = { selectedPayMethod = "UPI" }, label = { Text("UPI") })
            FilterChip(selected = selectedPayMethod == "RAZORPAY_SIM", onClick = { selectedPayMethod = "RAZORPAY_SIM" }, label = { Text("Razorpay") })
          }
          if (plans.isEmpty()) {
            Text("No plans configured yet. Ask Admin to configure or seed plans.", style = MaterialTheme.typography.bodySmall)
          } else {
            plans.filter { it.isActive }.forEach { plan ->
              Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
              ) {
                Column(modifier = Modifier.padding(12.dp)) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Text(plan.name, style = MaterialTheme.typography.titleSmall)
                    Text(
                      text = "${formatInr(plan.priceInr)}/${plan.billingCycle.lowercase()}",
                      style = MaterialTheme.typography.titleSmall,
                      color = MaterialTheme.colorScheme.primary
                    )
                  }
                  Text(
                    text = "Up to ${plan.maxActiveJobs} active jobs · ${plan.featuredBoosts} boosts",
                    style = MaterialTheme.typography.bodySmall
                  )
                  Spacer(modifier = Modifier.height(6.dp))
                  Button(
                    onClick = {
                      onUpgradePlan(plan, selectedPayMethod)
                      showUpgradeDialog = false
                    },
                    enabled = !isBusy && profile.subscriptionTier != plan.code,
                    modifier = Modifier.fillMaxWidth()
                  ) {
                    Text(if (profile.subscriptionTier == plan.code) "Current Plan" else "Activate ${plan.name}")
                  }
                }
              }
            }
          }
        }
      },
      confirmButton = {
        TextButton(onClick = { showUpgradeDialog = false }) { Text("Close") }
      }
    )
  }
}

@Composable
private fun MetricBox(label: String, value: String, modifier: Modifier = Modifier) {
  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    modifier = modifier
  ) {
    Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
      Text(value, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
      Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EmployerPostingsScreen(
  profile: UserProfile,
  employerJobs: List<JobListing>,
  employerQuests: List<SideQuest>,
  isBusy: Boolean,
  onCreateJob: (JobListing) -> Unit,
  onToggleJobActive: (String, Boolean) -> Unit,
  onCreateQuest: (SideQuest) -> Unit,
  onReleaseQuestPayout: (SideQuest) -> Unit
) {
  var activeTab by remember { mutableStateOf("JOBS") }
  var showCreateJobDialog by remember { mutableStateOf(false) }
  var showCreateQuestDialog by remember { mutableStateOf(false) }

  Scaffold(
    floatingActionButton = {
      FloatingActionButton(
        onClick = {
          if (activeTab == "JOBS") showCreateJobDialog = true else showCreateQuestDialog = true
        },
        containerColor = MaterialTheme.colorScheme.primary,
        modifier = Modifier.testTag("employer_create_fab")
      ) {
        Icon(Icons.Filled.Add, contentDescription = "Post Listing")
      }
    }
  ) { innerPadding ->
    LazyColumn(
      contentPadding = PaddingValues(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      item {
        Text("Manage Postings", style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          FilterChip(
            selected = activeTab == "JOBS",
            onClick = { activeTab = "JOBS" },
            label = { Text("Jobs (${employerJobs.size})") },
            leadingIcon = { Icon(Icons.Filled.WorkOutline, contentDescription = null) }
          )
          FilterChip(
            selected = activeTab == "QUESTS",
            onClick = { activeTab = "QUESTS" },
            label = { Text("Side Quests (${employerQuests.size})") },
            leadingIcon = { Icon(Icons.Filled.Bolt, contentDescription = null) }
          )
        }
      }

      if (activeTab == "JOBS") {
        if (employerJobs.isEmpty()) {
          item {
            EmptyStateCard(
              title = "No jobs posted yet",
              subtitle = "Tap + to post a fee-free job listing across any Indian state."
            )
          }
        } else {
          items(employerJobs, key = { it.id }) { job ->
            Column {
              JobCard(job = job, isSaved = false, userAge = 25L, onClick = {})
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = "${job.applicantCount} applicants · ${job.moderationStatus}",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Text("Active", style = MaterialTheme.typography.labelSmall)
                  Spacer(modifier = Modifier.width(6.dp))
                  Switch(
                    checked = job.isActive,
                    onCheckedChange = { onToggleJobActive(job.id, it) }
                  )
                }
              }
            }
          }
        }
      } else {
        if (employerQuests.isEmpty()) {
          item {
            EmptyStateCard(
              icon = Icons.Filled.Bolt,
              title = "No Side Quests posted",
              subtitle = "Tap + to create a quick paid micro-task."
            )
          }
        } else {
          items(employerQuests, key = { it.id }) { quest ->
            Column {
              SideQuestCard(quest = quest, onClick = {})
              if (quest.proofNote.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Card(
                  shape = RoundedCornerShape(14.dp),
                  colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                      text = "Submitted by ${quest.assignedSeekerName}: ${quest.proofNote}",
                      style = MaterialTheme.typography.bodySmall
                    )
                    if (quest.questStatus == "COMPLETION_SUBMITTED") {
                      Spacer(modifier = Modifier.height(8.dp))
                      Button(
                        onClick = { onReleaseQuestPayout(quest) },
                        modifier = Modifier.fillMaxWidth().testTag("release_payout_${quest.id}")
                      ) {
                        Icon(Icons.Filled.CheckCircle, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Verify & Release ${formatInr(quest.payoutInr)} Payout")
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  if (showCreateJobDialog) {
    CreateJobDialog(
      profile = profile,
      isBusy = isBusy,
      onDismiss = { showCreateJobDialog = false },
      onCreate = {
        onCreateJob(it)
        showCreateJobDialog = false
      }
    )
  }

  if (showCreateQuestDialog) {
    CreateSideQuestDialog(
      profile = profile,
      isBusy = isBusy,
      onDismiss = { showCreateQuestDialog = false },
      onCreate = {
        onCreateQuest(it)
        showCreateQuestDialog = false
      }
    )
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun CreateJobDialog(
  profile: UserProfile,
  isBusy: Boolean,
  onDismiss: () -> Unit,
  onCreate: (JobListing) -> Unit
) {
  var title by remember { mutableStateOf("") }
  var category by remember { mutableStateOf("Technology") }
  var jobType by remember { mutableStateOf("FULL_TIME") }
  var state by remember { mutableStateOf(profile.state.ifBlank { "Karnataka" }) }
  var city by remember { mutableStateOf(profile.city.ifBlank { "Bengaluru" }) }
  var pincode by remember { mutableStateOf(profile.pincode.ifBlank { "560001" }) }
  var isRemote by remember { mutableStateOf(false) }
  var salaryMin by remember { mutableStateOf("18000") }
  var salaryMax by remember { mutableStateOf("35000") }
  var description by remember { mutableStateOf("") }
  var requirements by remember { mutableStateOf("") }
  var isHazardous by remember { mutableStateOf(false) }
  var err by remember { mutableStateOf<String?>(null) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Post Job (₹0 Fee Enforced)") },
    text = {
      Column(
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.verticalScroll(rememberScrollState())
      ) {
        OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Job Title *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          listOf("FULL_TIME", "PART_TIME", "GIG", "INTERNSHIP", "DAILY_WAGE", "REMOTE").forEach { jt ->
            FilterChip(selected = jobType == jt, onClick = { jobType = jt }, label = { Text(JobyConstants.jobTypeLabel(jt)) })
          }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(value = city, onValueChange = { city = it }, label = { Text("City *") }, singleLine = true, modifier = Modifier.weight(1f))
          OutlinedTextField(value = pincode, onValueChange = { pincode = it.filter { c -> c.isDigit() }.take(6) }, label = { Text("PIN *") }, singleLine = true, modifier = Modifier.weight(0.8f))
        }
        OutlinedTextField(value = state, onValueChange = { state = it }, label = { Text("Indian State *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = salaryMin,
            onValueChange = { salaryMin = it.filter { c -> c.isDigit() } },
            label = { Text("Min ₹") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.weight(1f)
          )
          OutlinedTextField(
            value = salaryMax,
            onValueChange = { salaryMax = it.filter { c -> c.isDigit() } },
            label = { Text("Max ₹") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.weight(1f)
          )
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
          Text("Remote / WFH", style = MaterialTheme.typography.bodySmall)
          Switch(checked = isRemote, onCheckedChange = { isRemote = it })
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
          Text("18+ Restricted / Field-Hazardous", style = MaterialTheme.typography.bodySmall)
          Switch(checked = isHazardous, onCheckedChange = { isHazardous = it })
        }
        OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Description (10+ chars) *") }, minLines = 2, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = requirements, onValueChange = { requirements = it }, label = { Text("Requirements *") }, minLines = 2, modifier = Modifier.fillMaxWidth())
        if (err != null) {
          Text(err!!, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
        }
      }
    },
    confirmButton = {
      Button(
        enabled = !isBusy,
        onClick = {
          val sMin = salaryMin.toLongOrNull() ?: 0L
          val sMax = salaryMax.toLongOrNull() ?: 0L
          when {
            title.trim().length < 3 -> err = "Title must be at least 3 characters."
            description.trim().length < 10 -> err = "Description must be at least 10 characters."
            requirements.trim().length < 2 -> err = "Enter job requirements."
            sMax < sMin -> err = "Max salary must be >= Min salary."
            else -> onCreate(
              JobListing(
                employerId = profile.userId,
                companyName = profile.companyName.ifBlank { profile.displayName },
                companyVerified = profile.companyVerified,
                title = title.trim(),
                category = category,
                jobType = jobType,
                state = state.trim(),
                city = city.trim(),
                pincode = pincode.trim(),
                isRemote = isRemote,
                salaryMinInr = sMin,
                salaryMaxInr = sMax,
                salaryPeriod = if (jobType == "DAILY_WAGE") "DAY" else "MONTH",
                experienceLevel = "FRESHER",
                description = description.trim(),
                requirements = requirements.trim(),
                minAge = if (isHazardous) 18L else 16L,
                isHazardousOrRestricted = isHazardous,
                applicationFee = 0L
              )
            )
          }
        }
      ) { Text("Publish") }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Cancel") }
    }
  )
}

@Composable
private fun CreateSideQuestDialog(
  profile: UserProfile,
  isBusy: Boolean,
  onDismiss: () -> Unit,
  onCreate: (SideQuest) -> Unit
) {
  var title by remember { mutableStateOf("") }
  var deliverable by remember { mutableStateOf("") }
  var description by remember { mutableStateOf("") }
  var payout by remember { mutableStateOf("500") }
  var minutes by remember { mutableStateOf("45") }
  var isRemote by remember { mutableStateOf(true) }
  var err by remember { mutableStateOf<String?>(null) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Post Side Quest") },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Task Title *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          OutlinedTextField(
            value = payout,
            onValueChange = { payout = it.filter { c -> c.isDigit() } },
            label = { Text("Payout (₹50+) *") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.weight(1f)
          )
          OutlinedTextField(
            value = minutes,
            onValueChange = { minutes = it.filter { c -> c.isDigit() } },
            label = { Text("Est. Mins *") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.weight(1f)
          )
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
          Text("Remote Task", style = MaterialTheme.typography.bodySmall)
          Switch(checked = isRemote, onCheckedChange = { isRemote = it })
        }
        OutlinedTextField(value = deliverable, onValueChange = { deliverable = it }, label = { Text("Expected Deliverable *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Task Instructions (10+ chars) *") }, minLines = 2, modifier = Modifier.fillMaxWidth())
        if (err != null) {
          Text(err!!, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
        }
      }
    },
    confirmButton = {
      Button(
        enabled = !isBusy,
        onClick = {
          val p = payout.toLongOrNull() ?: 0L
          val m = minutes.toLongOrNull() ?: 0L
          when {
            title.trim().length < 3 -> err = "Enter a valid title."
            p < 50L -> err = "Minimum Side Quest payout is ₹50."
            m < 5L -> err = "Estimated duration must be >= 5 mins."
            deliverable.trim().length < 3 -> err = "Describe the deliverable."
            description.trim().length < 10 -> err = "Instructions must be at least 10 chars."
            else -> onCreate(
              SideQuest(
                employerId = profile.userId,
                posterName = profile.companyName.ifBlank { profile.displayName },
                title = title.trim(),
                category = "Micro-Task",
                description = description.trim(),
                deliverableSpec = deliverable.trim(),
                payoutInr = p,
                estimatedMinutes = m,
                city = if (isRemote) "Remote" else profile.city.ifBlank { "Bengaluru" },
                state = profile.state.ifBlank { "Karnataka" },
                isRemote = isRemote,
                minAge = 16L,
                isHazardousOrRestricted = false,
                applicationFee = 0L
              )
            )
          }
        }
      ) { Text("Post Quest") }
    },
    dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
  )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EmployerCandidatesScreen(
  applications: List<JobApplication>,
  onUpdateStatus: (JobApplication, String, String) -> Unit,
  onMessageCandidate: (JobApplication) -> Unit
) {
  var filterStatus by remember { mutableStateOf("ALL") }
  var interviewTarget by remember { mutableStateOf<JobApplication?>(null) }
  var interviewNote by remember { mutableStateOf("") }

  val filtered = remember(applications, filterStatus) {
    if (filterStatus == "ALL") applications else applications.filter { it.status == filterStatus }
  }

  LazyColumn(
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
    modifier = Modifier.fillMaxSize()
  ) {
    item {
      Text("Candidate Pipeline", style = MaterialTheme.typography.headlineSmall)
      Spacer(modifier = Modifier.height(8.dp))
      FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("ALL", "APPLIED", "SHORTLISTED", "INTERVIEW", "SELECTED").forEach { st ->
          FilterChip(selected = filterStatus == st, onClick = { filterStatus = st }, label = { Text(st) })
        }
      }
    }

    if (filtered.isEmpty()) {
      item {
        EmptyStateCard(
          title = "No candidates in this stage",
          subtitle = "Applicants to your approved jobs appear here in real time."
        )
      }
    } else {
      items(filtered, key = { it.id }) { app ->
        Card(
          shape = RoundedCornerShape(18.dp),
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(app.seekerName, style = MaterialTheme.typography.titleMedium)
                Text(
                  text = "${app.jobTitle} · Age ${app.seekerAge} · ${app.seekerCity}",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
              StatusPill(
                text = app.status,
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                contentColor = MaterialTheme.colorScheme.onPrimaryContainer
              )
            }
            if (app.seekerSkills.isNotEmpty()) {
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = "Skills: ${app.seekerSkills.joinToString(", ")}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
              )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text("Resume: ${app.resumeLabel}", style = MaterialTheme.typography.labelSmall)
            if (app.coverNote.isNotBlank()) {
              Spacer(modifier = Modifier.height(6.dp))
              Text(app.coverNote, style = MaterialTheme.typography.bodySmall)
            }

            Spacer(modifier = Modifier.height(10.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
              OutlinedButton(onClick = { onMessageCandidate(app) }) {
                Icon(Icons.Filled.Chat, contentDescription = null)
                Spacer(modifier = Modifier.width(4.dp))
                Text("Message")
              }
              if (app.status !in listOf("SELECTED", "REJECTED", "WITHDRAWN")) {
                OutlinedButton(onClick = { onUpdateStatus(app, "SHORTLISTED", "") }) {
                  Text("Shortlist")
                }
                OutlinedButton(onClick = {
                  interviewNote = ""
                  interviewTarget = app
                }) {
                  Text("Interview")
                }
                Button(onClick = { onUpdateStatus(app, "SELECTED", "Congratulations! Offer confirmed.") }) {
                  Text("Hire")
                }
                TextButton(onClick = { onUpdateStatus(app, "REJECTED", "") }) {
                  Text("Reject", color = MaterialTheme.colorScheme.error)
                }
              }
            }
          }
        }
      }
    }
  }

  if (interviewTarget != null) {
    AlertDialog(
      onDismissRequest = { interviewTarget = null },
      title = { Text("Schedule Interview") },
      text = {
        OutlinedTextField(
          value = interviewNote,
          onValueChange = { interviewNote = it },
          label = { Text("Date, Time & Meet Link / Address") },
          minLines = 2,
          modifier = Modifier.fillMaxWidth()
        )
      },
      confirmButton = {
        Button(onClick = {
          onUpdateStatus(interviewTarget!!, "INTERVIEW", interviewNote)
          interviewTarget = null
        }) { Text("Send Invite") }
      },
      dismissButton = { TextButton(onClick = { interviewTarget = null }) { Text("Cancel") } }
    )
  }
}
