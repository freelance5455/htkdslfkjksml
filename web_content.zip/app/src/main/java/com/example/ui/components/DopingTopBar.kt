package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ExamType
import com.example.ui.theme.DopingAmber
import com.example.ui.theme.DopingPrimary
import com.example.ui.theme.DopingPrimaryVariant

@Composable
fun DopingTopBar(
  selectedExam: ExamType,
  streakDays: Int,
  onExamSelected: (ExamType) -> Unit,
  modifier: Modifier = Modifier
) {
  val context = androidx.compose.ui.platform.LocalContext.current
  var examMenuExpanded by remember { mutableStateOf(false) }

  Surface(
    modifier = modifier.fillMaxWidth(),
    color = MaterialTheme.colorScheme.surface,
    tonalElevation = 3.dp,
    shadowElevation = 2.dp
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .statusBarsPadding()
        .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // App Logo & Brand
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.testTag("app_brand_header")
        ) {
          Box(
            modifier = Modifier
              .size(38.dp)
              .clip(RoundedCornerShape(10.dp))
              .background(
                Brush.linearGradient(
                  colors = listOf(DopingPrimary, DopingAmber)
                )
              ),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.Bolt,
              contentDescription = "Doping Hafıza Logo",
              tint = Color.White,
              modifier = Modifier.size(24.dp)
            )
          }

          Spacer(modifier = Modifier.width(10.dp))

          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = "DOPİNG",
                fontWeight = FontWeight.Black,
                fontSize = 16.sp,
                color = DopingPrimary,
                letterSpacing = 0.5.sp
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = "HAFIZA",
                fontWeight = FontWeight.Black,
                fontSize = 16.sp,
                color = DopingAmber,
                letterSpacing = 0.5.sp
              )
            }
            Text(
              text = "Akıllı Sınav Koçluğu",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        // Right side: Exam selector badge & Streak badge
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          // Exam selector pill with Dropdown
          Box {
            Surface(
              modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .clickable { examMenuExpanded = true }
                .testTag("exam_selector_button"),
              color = MaterialTheme.colorScheme.primaryContainer,
              shape = RoundedCornerShape(20.dp)
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = selectedExam.displayName,
                  fontWeight = FontWeight.Bold,
                  fontSize = 12.sp,
                  color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Icon(
                  imageVector = Icons.Default.ArrowDropDown,
                  contentDescription = "Sınav Seç",
                  tint = MaterialTheme.colorScheme.onPrimaryContainer,
                  modifier = Modifier.size(16.dp)
                )
              }
            }

            DropdownMenu(
              expanded = examMenuExpanded,
              onDismissRequest = { examMenuExpanded = false }
            ) {
              ExamType.values().forEach { exam ->
                DropdownMenuItem(
                  text = {
                    Column {
                      Text(
                        text = exam.displayName,
                        fontWeight = if (exam == selectedExam) FontWeight.Bold else FontWeight.Normal,
                        color = if (exam == selectedExam) DopingPrimary else MaterialTheme.colorScheme.onSurface
                      )
                      Text(
                        text = exam.subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                      )
                    }
                  },
                  onClick = {
                    onExamSelected(exam)
                    examMenuExpanded = false
                  }
                )
              }
            }
          }

          // Streak Badge (Fire 🔥)
          Surface(
            color = Color(0xFFFEF3C7),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.testTag("streak_badge")
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.LocalFireDepartment,
                contentDescription = "Çalışma Serisi",
                tint = Color(0xFFD97706),
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(3.dp))
              Text(
                text = "$streakDays Gün",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 11.sp,
                color = Color(0xFF92400E)
              )
            }
          }

          // Google Play Store Icon
          Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
            shape = CircleShape,
            modifier = Modifier
              .size(30.dp)
              .clip(CircleShape)
              .clickable {
                android.widget.Toast.makeText(
                  context,
                  "Google Play Store: Doping Hafıza En Güncel Sürüm (Android 15)",
                  android.widget.Toast.LENGTH_SHORT
                ).show()
              }
              .testTag("play_store_top_btn")
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                imageVector = Icons.Default.Notifications,
                contentDescription = "Google Play",
                tint = DopingPrimary,
                modifier = Modifier.size(16.dp)
              )
            }
          }
        }
      }
    }
  }
}
