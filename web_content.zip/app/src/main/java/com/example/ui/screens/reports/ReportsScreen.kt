package com.example.ui.screens.reports

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.report.ReportExporter
import com.example.ui.DeliveryViewModel
import com.example.ui.theme.DexterCyanPrimary
import com.example.ui.theme.DexterEmeraldSecondary
import com.example.ui.theme.DexterSurface
import com.example.ui.theme.DexterSurfaceVariant
import com.example.ui.theme.KamaiGreenGlow

@Composable
fun ReportsScreen(
    viewModel: DeliveryViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val summary by viewModel.dashboardSummary.collectAsStateWithLifecycle()
    val profile by viewModel.userProfile.collectAsStateWithLifecycle()
    val entries by viewModel.currentMonthEntries.collectAsStateWithLifecycle()

    var selectedCycleFilter by remember { mutableStateOf<Int?>(null) } // null = Full month, 1, 2, 3

    val filteredEntries = remember(entries, selectedCycleFilter) {
        if (selectedCycleFilter == null) entries
        else entries.filter { it.cycleNumber == selectedCycleFilter }
    }

    val periodDeliveries = remember(filteredEntries) { filteredEntries.sumOf { it.deliveriesCount } }
    val periodEarnings = remember(filteredEntries) { filteredEntries.sumOf { it.totalEarnings } }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Header
        Column {
            Text(
                text = "Report & Invoice Statements",
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White
            )
            Text(
                text = "Export and download official delivery payouts in PDF or Excel",
                fontSize = 12.sp,
                color = Color(0xFF94A3B8)
            )
        }

        // Invoice Cycle Filter Selection
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = DexterSurface),
            border = BorderStroke(1.dp, Color(0xFF1E293B)),
            elevation = CardDefaults.cardElevation(2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "SELECT INVOICE PERIOD",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF64748B),
                    letterSpacing = 0.6.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf<Pair<Int?, String>>(
                        null to "Full Month",
                        1 to "Cycle 1 (1-10)",
                        2 to "Cycle 2 (11-20)",
                        3 to "Cycle 3 (21-31)"
                    ).take(3).forEach { (cycle, label) ->
                        val isSelected = selectedCycleFilter == cycle
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedCycleFilter = cycle },
                            label = { Text(label, fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = DexterCyanPrimary,
                                selectedLabelColor = Color(0xFF001E2E),
                                containerColor = DexterSurfaceVariant,
                                labelColor = Color(0xFF94A3B8)
                            ),
                            border = BorderStroke(1.dp, if (isSelected) DexterCyanPrimary else Color(0xFF334155))
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val isSelected = selectedCycleFilter == 3
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedCycleFilter = 3 },
                        label = { Text("Cycle 3 (21-31)", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = DexterCyanPrimary,
                            selectedLabelColor = Color(0xFF001E2E),
                            containerColor = DexterSurfaceVariant,
                            labelColor = Color(0xFF94A3B8)
                        ),
                        border = BorderStroke(1.dp, if (isSelected) DexterCyanPrimary else Color(0xFF334155))
                    )
                }
            }
        }

        // Invoice Preview Card (Dexter High-Tech Preview)
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = DexterSurface),
            border = BorderStroke(1.5.dp, DexterCyanPrimary.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF0C243B),
                                Color(0xFF091424)
                            )
                        )
                    )
                    .padding(18.dp)
            ) {
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            Text(
                                text = if (selectedCycleFilter == null) "MONTH STATEMENT PREVIEW" else "CYCLE $selectedCycleFilter INVOICE PREVIEW",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = DexterCyanPrimary,
                                letterSpacing = 0.8.sp
                            )
                            Text(
                                text = if (selectedCycleFilter == null) "${summary.monthKey} (All Cycles)" else "Cycle $selectedCycleFilter (${when (selectedCycleFilter) { 1 -> "1st - 10th"; 2 -> "11th - 20th"; else -> "21st - 31st" }})",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = DexterCyanPrimary.copy(alpha = 0.2f),
                            border = BorderStroke(1.dp, DexterCyanPrimary.copy(alpha = 0.4f))
                        ) {
                            Text(
                                text = "${filteredEntries.size} Days Logged",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = DexterCyanPrimary,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            Text(text = "Total Deliveries", fontSize = 11.sp, color = Color(0xFF64748B))
                            Text(text = "$periodDeliveries Drops", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                        Column {
                            Text(text = "Agent Name", fontSize = 11.sp, color = Color(0xFF64748B))
                            Text(text = profile.agentName, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "Net Kamai Payable", fontSize = 11.sp, color = Color(0xFF64748B))
                            Text(text = "₹${periodEarnings.toInt()}", fontSize = 24.sp, fontWeight = FontWeight.Black, color = KamaiGreenGlow)
                        }
                    }
                }
            }
        }

        // Action Buttons: PDF Download & Share
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = DexterSurface),
            border = BorderStroke(1.dp, Color(0xFF1E293B)),
            elevation = CardDefaults.cardElevation(2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "PDF INVOICE STATEMENT",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF94A3B8),
                    letterSpacing = 0.6.sp
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            val pdfFile = viewModel.exportPdf(context, selectedCycleFilter)
                            if (pdfFile != null) {
                                val saved = ReportExporter.saveToDownloads(
                                    context,
                                    pdfFile,
                                    "application/pdf",
                                    pdfFile.name
                                )
                                if (saved) {
                                    Toast.makeText(context, "PDF Report saved successfully!", Toast.LENGTH_SHORT).show()
                                }
                            } else {
                                Toast.makeText(context, "Could not generate PDF", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE11D48)), // Vibrant Red/Rose
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("download_pdf_button")
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save PDF", fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = {
                            val pdfFile = viewModel.exportPdf(context, selectedCycleFilter)
                            if (pdfFile != null) {
                                ReportExporter.shareFile(
                                    context,
                                    pdfFile,
                                    "application/pdf",
                                    "Delivery Agent Invoice Report (${summary.monthKey})"
                                )
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, Color(0xFF475569)),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color(0xFFCBD5E1))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Share PDF", fontWeight = FontWeight.Bold, color = Color(0xFFCBD5E1))
                    }
                }
            }
        }

        // Action Buttons: Excel (CSV) Download & Share
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = DexterSurface),
            border = BorderStroke(1.dp, Color(0xFF1E293B)),
            elevation = CardDefaults.cardElevation(2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "EXCEL / SPREADSHEET (CSV) REPORT",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF94A3B8),
                    letterSpacing = 0.6.sp
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            val csvFile = viewModel.exportExcelCsv(context, selectedCycleFilter)
                            if (csvFile != null) {
                                val saved = ReportExporter.saveToDownloads(
                                    context,
                                    csvFile,
                                    "text/csv",
                                    csvFile.name
                                )
                                if (saved) {
                                    Toast.makeText(context, "Excel CSV saved to Downloads!", Toast.LENGTH_SHORT).show()
                                }
                            } else {
                                Toast.makeText(context, "Could not generate Excel file", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DexterEmeraldSecondary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("download_excel_button")
                    ) {
                        Icon(Icons.Default.TableChart, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color(0xFF003822))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save Excel", fontWeight = FontWeight.Bold, color = Color(0xFF003822))
                    }

                    OutlinedButton(
                        onClick = {
                            val csvFile = viewModel.exportExcelCsv(context, selectedCycleFilter)
                            if (csvFile != null) {
                                ReportExporter.shareFile(
                                    context,
                                    csvFile,
                                    "text/csv",
                                    "Delivery Agent Excel Report (${summary.monthKey})"
                                )
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, Color(0xFF475569)),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color(0xFFCBD5E1))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Share Excel", fontWeight = FontWeight.Bold, color = Color(0xFFCBD5E1))
                    }
                }
            }
        }
    }
}
