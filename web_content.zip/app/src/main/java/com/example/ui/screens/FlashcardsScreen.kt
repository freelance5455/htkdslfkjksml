package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.db.ReviewQuality
import com.example.data.db.SpacedRepetitionAlgorithm
import com.example.data.db.SrsWordEntity
import com.example.ui.LexicoUiState
import com.example.ui.LexicoViewModel
import com.example.ui.Screen
import com.example.ui.theme.HighlightGold
import com.example.ui.theme.HighlightGoldContainer
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SuccessGreenContainer
import com.example.ui.theme.WarningRed

enum class FlashcardFilter {
    PRIORITIZED, // Due or high priority
    ALL,         // All cards
    DUE_ONLY     // Strictly due
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FlashcardsScreen(
    uiState: LexicoUiState,
    viewModel: LexicoViewModel,
    srsWords: List<SrsWordEntity>,
    simulatedCurrentTime: Long,
    modifier: Modifier = Modifier
) {
    var selectedFilter by remember { mutableStateOf(FlashcardFilter.PRIORITIZED) }
    var isReverseMode by remember { mutableStateOf(false) } // False: Palabra -> Significado, True: Significado -> ¿Qué palabra es?
    var currentCardIndex by remember { mutableIntStateOf(0) }
    var isFlipped by remember { mutableStateOf(false) }

    // Filter cards according to user preference
    val filteredCards = remember(srsWords, selectedFilter, simulatedCurrentTime) {
        when (selectedFilter) {
            FlashcardFilter.DUE_ONLY -> srsWords.filter { it.nextReviewTimestamp <= simulatedCurrentTime }
            FlashcardFilter.ALL -> srsWords
            FlashcardFilter.PRIORITIZED -> {
                srsWords.sortedWith(
                    compareBy<SrsWordEntity> { if (it.nextReviewTimestamp <= simulatedCurrentTime) 0 else 1 }
                        .thenBy { it.nextReviewTimestamp }
                        .thenByDescending { it.timesForgotten }
                )
            }
        }
    }

    val totalCards = filteredCards.size
    val safeIndex = if (totalCards > 0) currentCardIndex.coerceIn(0, totalCards - 1) else 0
    val currentCard = filteredCards.getOrNull(safeIndex)

    val progress = if (totalCards > 0) (safeIndex + 1).toFloat() / totalCards.toFloat() else 0f

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Tarjetas de Estudio",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isReverseMode) "Modo Al Revés: Significado ➔ Palabra" else "Modo Directo: Palabra ➔ Significado",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateTo(Screen.Glossary) }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                    }
                },
                actions = {
                    // Open Rhythm Challenge Screen
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier
                            .padding(end = 6.dp)
                            .clickable { viewModel.navigateTo(Screen.RhythmChallenge) }
                            .testTag("open_rhythm_challenge_btn")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.MusicNote,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Ritmo",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    // Quick Simulation Chip: +15 minutes
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.tertiaryContainer,
                        modifier = Modifier
                            .padding(end = 10.dp)
                            .clickable { viewModel.advanceSimulatedTime(15L) }
                            .testTag("simulate_15min_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.FastForward,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onTertiaryContainer,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = "+15m",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onTertiaryContainer
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Direction Switch & Filter Section
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                // Direction Toggle: Al Derecho vs Al Revés
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = !isReverseMode,
                        onClick = {
                            isReverseMode = false
                            isFlipped = false
                        },
                        label = { Text("Palabra ➔ Significado", fontSize = 11.sp) },
                        leadingIcon = {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(14.dp))
                        }
                    )

                    FilterChip(
                        selected = isReverseMode,
                        onClick = {
                            isReverseMode = true
                            isFlipped = false
                        },
                        label = { Text("Al Revés: Significado ➔ Palabra", fontSize = 11.sp) },
                        leadingIcon = {
                            Icon(Icons.Default.SwapHoriz, contentDescription = null, modifier = Modifier.size(14.dp))
                        }
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Filter chips (Due vs All)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedFilter == FlashcardFilter.PRIORITIZED,
                        onClick = {
                            selectedFilter = FlashcardFilter.PRIORITIZED
                            currentCardIndex = 0
                            isFlipped = false
                        },
                        label = { Text("Priorizadas (${srsWords.size})", fontSize = 11.sp) }
                    )
                    FilterChip(
                        selected = selectedFilter == FlashcardFilter.DUE_ONLY,
                        onClick = {
                            selectedFilter = FlashcardFilter.DUE_ONLY
                            currentCardIndex = 0
                            isFlipped = false
                        },
                        label = {
                            val dueCount = srsWords.count { it.nextReviewTimestamp <= simulatedCurrentTime }
                            Text("Para repasar ($dueCount)", fontSize = 11.sp)
                        },
                        leadingIcon = {
                            Icon(Icons.Default.AccessTime, contentDescription = null, modifier = Modifier.size(14.dp))
                        }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Progress Bar
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(CircleShape),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.primaryContainer
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (totalCards > 0) "Tarjeta #${safeIndex + 1} de $totalCards" else "Sin tarjetas",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    currentCard?.let { card ->
                        val isDue = card.nextReviewTimestamp <= simulatedCurrentTime
                        val remainingText = SpacedRepetitionAlgorithm.formatRemainingTime(card.nextReviewTimestamp, simulatedCurrentTime)

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (isDue) SuccessGreenContainer else HighlightGoldContainer
                        ) {
                            Text(
                                text = if (isDue) "🟢 ¡Lista para repasar!" else "⏱️ $remainingText",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isDue) SuccessGreen else HighlightGold
                            )
                        }
                    }
                }
            }

            // Main Card Area
            if (currentCard != null) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Interactive Card View (Bidirectional: Normal & Reverse)
                    BidirectionalCardView(
                        card = currentCard,
                        cardNumber = safeIndex + 1,
                        isFlipped = isFlipped,
                        isReverseMode = isReverseMode,
                        onFlip = { isFlipped = !isFlipped },
                        onSpeak = { viewModel.speakText(currentCard.displayWord) }
                    )

                    // Performance Assessment Buttons (SRS Quality Rating)
                    if (isFlipped) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "¿Qué tal recordaste esta palabra?",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // DIFÍCIL (Intervalo: 15 min)
                                Button(
                                    onClick = {
                                        viewModel.answerFlashcardQuality(currentCard.id, ReviewQuality.AGAIN)
                                        isFlipped = false
                                        if (safeIndex + 1 < totalCards) currentCardIndex++
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(54.dp)
                                        .testTag("rate_again_button"),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = WarningRed)
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Difícil", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text("15 min", fontSize = 10.sp, color = Color.White.copy(alpha = 0.85f))
                                    }
                                }

                                // REGULAR (Intervalo: 1 hora)
                                Button(
                                    onClick = {
                                        viewModel.answerFlashcardQuality(currentCard.id, ReviewQuality.GOOD)
                                        isFlipped = false
                                        if (safeIndex + 1 < totalCards) currentCardIndex++
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(54.dp)
                                        .testTag("rate_good_button"),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = HighlightGold)
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Regular", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text("1 hora", fontSize = 10.sp, color = Color.White.copy(alpha = 0.85f))
                                    }
                                }

                                // FÁCIL (Intervalo Creciente)
                                Button(
                                    onClick = {
                                        viewModel.answerFlashcardQuality(currentCard.id, ReviewQuality.EASY)
                                        isFlipped = false
                                        if (safeIndex + 1 < totalCards) currentCardIndex++
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(54.dp)
                                        .testTag("rate_easy_button"),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen)
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("¡Fácil!", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text("Creciente", fontSize = 10.sp, color = Color.White.copy(alpha = 0.85f))
                                    }
                                }
                            }
                        }
                    } else {
                        // Flip Prompt Button
                        Button(
                            onClick = { isFlipped = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("flip_card_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(Icons.Default.Flip, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isReverseMode) "Voltear para revelar la palabra" else "Voltear para ver significado e imagen",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Navigation Controls (Anterior / Siguiente)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = {
                                if (safeIndex > 0) {
                                    currentCardIndex = safeIndex - 1
                                    isFlipped = false
                                }
                            },
                            enabled = safeIndex > 0,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Anterior")
                        }

                        Text(
                            text = "#${safeIndex + 1} / $totalCards",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                        )

                        OutlinedButton(
                            onClick = {
                                if (safeIndex + 1 < totalCards) {
                                    currentCardIndex = safeIndex + 1
                                    isFlipped = false
                                }
                            },
                            enabled = safeIndex + 1 < totalCards,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Siguiente")
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            } else {
                // Empty state
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = SuccessGreen,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "¡Al día con tus repasos!",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "No tienes tarjetas pendientes. Puedes simular el paso del tiempo o revisar todas las tarjetas.",
                            style = MaterialTheme.typography.bodyMedium,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.75f)
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(
                                onClick = { viewModel.advanceSimulatedTime(15L) },
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.FastForward, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Simular +15 min")
                            }

                            Button(
                                onClick = { selectedFilter = FlashcardFilter.ALL },
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Ver todas")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BidirectionalCardView(
    card: SrsWordEntity,
    cardNumber: Int,
    isFlipped: Boolean,
    isReverseMode: Boolean,
    onFlip: () -> Unit,
    onSpeak: () -> Unit
) {
    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onFlip() }
            .testTag("flashcard_item_$cardNumber"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(22.dp)
        ) {
            // Header Row: Card Number, SRS Level, Pronounce
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "#$cardNumber",
                        color = MaterialTheme.colorScheme.onPrimary,
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isReverseMode) HighlightGoldContainer else MaterialTheme.colorScheme.primaryContainer
                ) {
                    Text(
                        text = if (isReverseMode) "AL REVÉS 🔀" else "DIRECTO ➡️",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (isReverseMode) Color(0xFF78350F) else MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }

                IconButton(onClick = onSpeak, modifier = Modifier.size(36.dp)) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                        contentDescription = "Pronunciar",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            if (!isReverseMode) {
                // NORMAL MODE: Front = Word, Back = Meaning + Image + Sentence
                if (!isFlipped) {
                    // Front
                    Text(
                        text = card.displayWord,
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "📄 Frase original del documento PDF:",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            val sentence = card.originalSentence
                            val target = card.displayWord
                            val annotatedSentence = buildAnnotatedString {
                                val index = sentence.indexOf(target, ignoreCase = true)
                                if (index >= 0) {
                                    append(sentence.substring(0, index))
                                    withStyle(
                                        style = SpanStyle(
                                            background = HighlightGoldContainer,
                                            color = HighlightGold,
                                            fontWeight = FontWeight.Bold
                                        )
                                    ) {
                                        append(sentence.substring(index, index + target.length))
                                    }
                                    append(sentence.substring(index + target.length))
                                } else {
                                    append(sentence)
                                }
                            }

                            Text(
                                text = annotatedSentence,
                                style = MaterialTheme.typography.bodyMedium,
                                fontStyle = FontStyle.Italic,
                                lineHeight = 22.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(Icons.Default.Flip, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Toca para revelar definición e imagen", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                } else {
                    // Back
                    RevealedMeaningSection(card = card)
                }
            } else {
                // REVERSE MODE ("AL REVÉS"): Front = Meaning + Image + Blank Sentence, Back = Revealed Word!
                if (!isFlipped) {
                    // Front: Meaning + Image -> Prompt: ¿A qué palabra se refiere?
                    Text(
                        text = "¿A qué palabra se refiere este significado?",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Colloquial Definition
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Psychology, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Definición coloquial:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(text = card.colloquialMeaning, style = MaterialTheme.typography.bodyMedium, lineHeight = 21.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = "👉 En una sola palabra: \"${card.simpleSynonym}\"", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = HighlightGold)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Illustrative Image
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        AsyncImage(
                            model = ImageRequest.Builder(LocalContext.current)
                                .data(card.imageUrl)
                                .crossfade(true)
                                .build(),
                            contentDescription = "Pista visual",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Sentence with Blank
                    val sentence = card.originalSentence
                    val target = card.displayWord
                    val blankSentence = if (sentence.contains(target, ignoreCase = true)) {
                        val idx = sentence.indexOf(target, ignoreCase = true)
                        sentence.substring(0, idx) + "[  _______  ]" + sentence.substring(idx + target.length)
                    } else "...[  _______  ]..."

                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ) {
                        Text(
                            text = "📄 En el PDF: \"$blankSentence\"",
                            modifier = Modifier.padding(12.dp),
                            style = MaterialTheme.typography.bodySmall,
                            fontStyle = FontStyle.Italic,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Flip, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Toca para revelar la palabra", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                } else {
                    // Back: The word revealed in glory!
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = SuccessGreenContainer
                        ) {
                            Text(
                                text = "¡LA PALABRA ERA!",
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = SuccessGreen
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = card.displayWord,
                            style = MaterialTheme.typography.headlineLarge,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.primary
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        RevealedMeaningSection(card = card)
                    }
                }
            }
        }
    }
}

@Composable
private fun RevealedMeaningSection(card: SrsWordEntity) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // Simple Synonym
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            color = HighlightGoldContainer.copy(alpha = 0.7f),
            border = androidx.compose.foundation.BorderStroke(1.dp, HighlightGold.copy(alpha = 0.5f))
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "👉 En una palabra que ya conoces:",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = HighlightGold
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = card.simpleSynonym,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFF78350F)
                )
            }
        }

        // Colloquial Definition
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "Definición coloquial y simple:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = card.colloquialMeaning,
                    style = MaterialTheme.typography.bodyMedium,
                    lineHeight = 20.sp
                )
            }
        }

        // Image
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp),
            shape = RoundedCornerShape(14.dp)
        ) {
            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(card.imageUrl)
                    .crossfade(true)
                    .build(),
                contentDescription = "Pista visual",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }

        // Full Sentence
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ) {
            Text(
                text = "📄 En el PDF: \"${card.originalSentence}\"",
                modifier = Modifier.padding(10.dp),
                style = MaterialTheme.typography.bodySmall,
                fontStyle = FontStyle.Italic,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
