package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.BookingRepository
import com.example.model.Booking
import com.example.model.NepalLocations
import com.example.model.ServiceCategory
import com.example.ui.theme.AmberGold
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.NavyLight
import com.example.ui.theme.NavyPrimary
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.launch

@Composable
fun MyBookingsScreen(
    bookingRepository: BookingRepository,
    snackbarHostState: SnackbarHostState,
    onNavigateHome: () -> Unit
) {
    val currentUser = Firebase.auth.currentUser
    val coroutineScope = rememberCoroutineScope()

    val bookingsList by bookingRepository.observeCustomerBookings(currentUser?.uid ?: "")
        .collectAsStateWithLifecycle(initialValue = null)

    var bookingToCancel by remember { mutableStateOf<Booking?>(null) }
    var isCancelling by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("my_bookings_screen")
    ) {
        // Screen Header
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = NavyPrimary,
            shape = RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Text(
                    text = "मेरो सेवा अर्डरहरू (My Bookings)",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "तपाईंले अनुरोध गर्नुभएका सेवाहरूको प्रत्यक्ष स्थिति",
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.8f)
                )
            }
        }

        if (bookingsList == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(40.dp),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = NavyPrimary)
            }
        } else if (bookingsList!!.isEmpty()) {
            EmptyBookingsView(onBrowse = onNavigateHome)
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(bookingsList!!, key = { it.id }) { booking ->
                    BookingItemCard(
                        booking = booking,
                        onCancelClick = {
                            bookingToCancel = booking
                        }
                    )
                }
            }
        }
    }

    // Cancel confirmation dialog
    bookingToCancel?.let { booking ->
        AlertDialog(
            onDismissRequest = { if (!isCancelling) bookingToCancel = null },
            title = { Text("सेवा अनुरोध रद्द गर्ने?", fontWeight = FontWeight.Bold) },
            text = { Text("के तपाईं ${booking.providerName} का लागि गरिएको सेवा अनुरोध रद्द गर्न निश्चित हुनुहुन्छ?") },
            confirmButton = {
                Button(
                    onClick = {
                        isCancelling = true
                        coroutineScope.launch {
                            val result = bookingRepository.cancelBooking(booking.id)
                            isCancelling = false
                            bookingToCancel = null
                            if (result.isSuccess) {
                                snackbarHostState.showSnackbar("अनुरोध रद्द गरियो। (Booking cancelled)")
                            } else {
                                snackbarHostState.showSnackbar("रद्द गर्न सकिएन: ${result.exceptionOrNull()?.localizedMessage}")
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    enabled = !isCancelling
                ) {
                    if (isCancelling) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White)
                    } else {
                        Text("हो, रद्द गर्नुहोस्")
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { bookingToCancel = null },
                    enabled = !isCancelling
                ) {
                    Text("पर्खनुहोस्")
                }
            }
        )
    }
}

@Composable
private fun BookingItemCard(
    booking: Booking,
    onCancelClick: () -> Unit
) {
    val categoryMeta = ServiceCategory.fromId(booking.category)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("booking_card_${booking.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Top Row: Provider name & Status Chip
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = booking.providerName.ifBlank { "सेवा प्रदायक" },
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = NavyPrimary
                    )
                    Text(
                        text = "${categoryMeta.labelNepali} • ${NepalLocations.getNepaliName(booking.city)}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                    )
                }

                StatusChip(status = booking.status)
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Work details
            Text(
                text = "कामको विवरण:",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )
            Text(
                text = booking.description,
                fontSize = 13.sp,
                lineHeight = 18.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Location & Date
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Filled.LocationOn,
                    contentDescription = null,
                    tint = NavyLight,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = booking.address,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
            }

            if (booking.preferredDate.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Schedule,
                        contentDescription = null,
                        tint = NavyLight,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${booking.preferredDate} (${booking.preferredTime})",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                }
            }

            // Cancel button if pending
            if (booking.status.equals("pending", ignoreCase = true)) {
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedButton(
                    onClick = onCancelClick,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.error
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("cancel_booking_button_${booking.id}")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Cancel,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("अनुरोध रद्द गर्नुहोस् (Cancel Request)", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun StatusChip(status: String) {
    val (label, bgColor, textColor, icon) = when (status.lowercase()) {
        "accepted" -> Quadruple(
            "स्वीकृत (Accepted)",
            Color(0xFFDBEAFE),
            Color(0xFF1D4ED8),
            Icons.Filled.CheckCircle
        )
        "completed" -> Quadruple(
            "सम्पन्न (Completed)",
            Color(0xFFD1FAE5),
            EmeraldGreen,
            Icons.Filled.TaskAlt
        )
        "cancelled" -> Quadruple(
            "रद्द (Cancelled)",
            Color(0xFFFEE2E2),
            Color(0xFFDC2626),
            Icons.Filled.Cancel
        )
        else -> Quadruple(
            "प्रतीक्षारत (Pending)",
            Color(0xFFFEF3C7),
            AmberGold,
            Icons.Filled.HourglassTop
        )
    }

    Surface(
        shape = RoundedCornerShape(20.dp),
        color = bgColor
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = textColor,
                modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = textColor
            )
        }
    }
}

private data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

@Composable
private fun EmptyBookingsView(onBrowse: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(80.dp)
                .clip(CircleShape)
                .background(NavyPrimary.copy(alpha = 0.1f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.Assignment,
                contentDescription = null,
                tint = NavyPrimary,
                modifier = Modifier.size(40.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "कुनै सेवा अनुरोध छैन",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = NavyPrimary
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "तपाईंले अहिलेसम्म कुनै सेवा अनुरोध गर्नुभएको छैन। इलेक्ट्रिसियन, प्लम्बर वा अन्य मर्मतका लागि प्राविधिक खोज्नुहोस्।",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = onBrowse,
            shape = RoundedCornerShape(20.dp),
            colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
        ) {
            Text("सेवा प्रदायकहरू हेर्नुहोस्")
        }
    }
}
