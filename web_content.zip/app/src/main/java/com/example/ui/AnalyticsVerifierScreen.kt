package com.example.ui

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Cookie
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CopyableCodeBlock
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber
import com.example.viewmodel.TrafficSimulatorViewModel

@Composable
fun AnalyticsVerifierScreen(
    viewModel: TrafficSimulatorViewModel,
    modifier: Modifier = Modifier
) {
    val stats by viewModel.stats.collectAsState()
    val visits by viewModel.visits.collectAsState()
    val config by viewModel.config.collectAsState()
    val context = LocalContext.current
    val clipboardManager: ClipboardManager = LocalClipboardManager.current

    val uniqueAgents = visits.map { it.sessionProfile.browserName }.distinct().size
    val uniqueIps = visits.map { it.sessionProfile.simulatedIp }.distinct().size
    val uniqueReferrers = visits.mapNotNull { it.sessionProfile.referer }.distinct().size
    val visitsWithCookies = visits.count { it.cookiesReceived.isNotEmpty() }
    val cacheControlResponses = visits.count { it.responseHeadersReceived.containsKey("cache-control") || it.responseHeadersReceived.containsKey("Cache-Control") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Header Card
        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            ),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(CyberCyan.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.VerifiedUser,
                        contentDescription = null,
                        tint = CyberCyan,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(14.dp))
                Column {
                    Text(
                        text = "Analytics & Unique Counter Audit",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Verification suite to validate unique-view counts & server tracking",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // "Is It Really Visiting?" Developer Verification Card
        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
            ),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "🔍 How to Confirm It Is Really Visiting",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = CyberCyan
                )
                Text(
                    text = "1. Server Access Logs: Open your server terminal and run tail -f /var/log/nginx/access.log (or Apache access.log). You will see real-time inbound HTTP requests with their varied User-Agents and IP signatures.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 16.sp
                )
                Text(
                    text = "2. HTTP vs Browser Engine: Use 'High-Speed HTTP Engine' for backend server logs and counter endpoints. Switch to 'Full Browser Engine (WebView)' if your site relies on client-side JavaScript (e.g. Google Analytics gtag.js or Facebook Pixel).",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 16.sp
                )
                Text(
                    text = "3. Echo Verification: Set target URL to https://httpbin.org/get. Tap 'Verify Real Connection (Test 1 Ping)' to see the exact remote server JSON echo confirming the request headers received.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 16.sp
                )
            }
        }

        if (visits.isEmpty()) {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .padding(24.dp)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Analytics,
                        contentDescription = null,
                        tint = CyberCyan,
                        modifier = Modifier.size(36.dp)
                    )
                    Text(
                        text = "Run a Simulation to Audit Tracking",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall
                    )
                    Text(
                        text = "Start a 35-visit simulation from the Runner tab. The audit engine will analyze unique session creation, cookie isolation, and header variance.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 16.sp
                    )
                }
            }
        } else {
            // Audit Checklist
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Server Tracking Audit Checklist",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )

                // Check 1: Cookie & Session Isolation
                AuditItemCard(
                    title = "Session Isolation (Zero Cookie Bleed)",
                    status = if (config.isolatedCookies) "Verified Isolated" else "Shared Cookie Store",
                    passed = config.isolatedCookies,
                    description = if (config.isolatedCookies)
                        "Each visit was executed with a clean, empty cookie jar. Every request arrived at the server as a new unique visitor."
                    else
                        "Cookies were shared between requests.",
                    metric = "$visitsWithCookies of ${visits.size} responses assigned new Set-Cookie",
                    icon = Icons.Default.Cookie
                )

                // Check 2: Header & User-Agent Entropy
                AuditItemCard(
                    title = "Device & User-Agent Entropy",
                    status = if (uniqueAgents > 1) "Multi-Platform ($uniqueAgents variants)" else "Single Agent",
                    passed = uniqueAgents > 1,
                    description = "Varied across modern Chrome (Win11/macOS), Safari (iPhone/Mac), Firefox, and Samsung Internet with authentic Client-Hints (Sec-CH-UA).",
                    metric = "$uniqueAgents unique User-Agent signatures",
                    icon = Icons.Default.Fingerprint
                )

                // Check 3: IP & Geo Attribution
                AuditItemCard(
                    title = "IP Header Forwarding (X-Forwarded-For)",
                    status = if (uniqueIps > 1) "Geo-Distributed" else "Static IP",
                    passed = uniqueIps > 1,
                    description = "Distinct public IPs injected into X-Forwarded-For, Client-IP, X-Real-IP, and CF-Connecting-IP so backend load balancers and analytics log separate unique visitors.",
                    metric = "$uniqueIps distinct simulated IPs",
                    icon = Icons.Default.Analytics
                )

                // Check 4: Cache Defeat / Bypass
                AuditItemCard(
                    title = "Cache Defeat (Live Server Execution)",
                    status = if (stats.redirectCount == 0 && stats.successCount > 0) "Direct Execution" else "Cached / Redirected",
                    passed = stats.successCount > 0,
                    description = "Cache-Control: no-cache and Pragma headers were dispatched to prevent intermediary CDNs from returning cached hits without hitting the origin counter.",
                    metric = "${stats.successCount} full 200 OK server responses",
                    icon = Icons.Outlined.VerifiedUser
                )
            }

            // Latency & Latency Distribution Summary
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Latency Breakdown",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        LatencyMetricItem("Min Latency", "${stats.minLatencyMs}ms", SuccessGreen)
                        LatencyMetricItem("Avg Latency", "${stats.avgLatencyMs}ms", CyberCyan)
                        LatencyMetricItem("Max Latency", "${stats.maxLatencyMs}ms", WarningAmber)
                    }
                }
            }

            // Export & Share Report Actions
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Export Verification Report",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            val report = viewModel.generateMarkdownReport()
                            clipboardManager.setText(AnnotatedString(report))
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("copy_report_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = Color(0xFF003548))
                    ) {
                        Icon(imageVector = Icons.Outlined.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Copy Report", fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = {
                            val report = viewModel.generateMarkdownReport()
                            val sendIntent = Intent().apply {
                                action = Intent.ACTION_SEND
                                putExtra(Intent.EXTRA_TEXT, report)
                                type = "text/plain"
                            }
                            val shareIntent = Intent.createChooser(sendIntent, "Share Simulation Audit Report")
                            context.startActivity(shareIntent)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("share_report_button"),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Share")
                    }
                }

                CopyableCodeBlock(
                    label = "Formatted Markdown Summary",
                    text = viewModel.generateMarkdownReport()
                )
            }
        }
    }
}

@Composable
private fun AuditItemCard(
    title: String,
    status: String,
    passed: Boolean,
    description: String,
    metric: String,
    icon: ImageVector
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
        ),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(if (passed) SuccessGreen.copy(alpha = 0.15f) else WarningAmber.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (passed) Icons.Default.Check else Icons.Default.Close,
                            contentDescription = null,
                            tint = if (passed) SuccessGreen else WarningAmber,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = title,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                Surface(
                    color = if (passed) SuccessGreen.copy(alpha = 0.12f) else WarningAmber.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = status,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (passed) SuccessGreen else WarningAmber,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
            Text(
                text = description,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 16.sp
            )
            Text(
                text = "✓ $metric",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                color = CyberCyan
            )
        }
    }
}

@Composable
private fun LatencyMetricItem(label: String, value: String, color: Color) {
    Column {
        Text(
            text = label,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = color,
            fontFamily = FontFamily.Monospace
        )
    }
}
