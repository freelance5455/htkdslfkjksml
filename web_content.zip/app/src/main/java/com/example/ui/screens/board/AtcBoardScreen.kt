package com.example.ui.screens.board

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.*
import com.example.ui.navigation.Screen
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusRed
import com.example.ui.theme.StatusYellow
import com.example.ui.viewmodel.BoardAirportItem
import com.example.ui.viewmodel.WeatherViewModel

@Composable
fun AtcBoardScreen(
  viewModel: WeatherViewModel,
  onNavigateTo: (Screen) -> Unit,
  modifier: Modifier = Modifier
) {
  val boardAirports by viewModel.boardAirports.collectAsState()
  val isOffline by viewModel.isOffline.collectAsState()

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp)
      .testTag("atc_board_screen"),
    verticalArrangement = Arrangement.spacedBy(10.dp),
    contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
  ) {
    if (isOffline) {
      item { OfflineNoticeBanner() }
    }

    // Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "تابلوی وضعیت چندفرودگاهی (ATC Weather Board)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "خلاصه عملیاتی فرودگاه‌های کلیدی برای کنترلر مراقبت پرواز",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        IconButton(onClick = { viewModel.refreshBoardAirports() }) {
          Icon(Icons.Default.Refresh, contentDescription = "تازه‌سازی تابلو", tint = MaterialTheme.colorScheme.primary)
        }
      }
    }

    if (boardAirports.isEmpty()) {
      item {
        Card(modifier = Modifier.fillMaxWidth()) {
          Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
          }
        }
      }
    } else {
      items(boardAirports) { item ->
        AtcBoardRowCard(
          item = item,
          onClick = {
            viewModel.selectAirport(item.airport)
            onNavigateTo(Screen.AIRPORT_WEATHER)
          }
        )
      }
    }

    item { OperationalDisclaimerCard() }
  }
}

@Composable
private fun AtcBoardRowCard(
  item: BoardAirportItem,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val metar = item.metar

  Card(
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    border = CardDefaults.outlinedCardBorder(),
    modifier = modifier
      .fillMaxWidth()
      .clickable { onClick() }
      .testTag("atc_board_item_${item.airport.icao}")
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = item.airport.icao,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "(${item.airport.iata})",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = item.airport.nameFa,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium
          )
        }

        if (metar != null) {
          FlightCategoryBadge(category = metar.flightCategory)
        } else {
          Surface(
            shape = RoundedCornerShape(4.dp),
            color = MaterialTheme.colorScheme.surface
          ) {
            Text(
              text = "بدون داده",
              style = MaterialTheme.typography.labelSmall,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Compact Parameters Row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        // Wind
        Text(
          text = if (metar != null) "باد: ${metar.windDirDeg?.let { "$it°" } ?: "VRB"}/${metar.windSpeedKt ?: 0}KT" else "باد: --",
          style = MaterialTheme.typography.labelSmall,
          fontWeight = FontWeight.Bold
        )
        // Vis
        Text(
          text = if (metar != null) "دید: ${if (metar.isCavok) "CAVOK" else "${metar.visibilityMeters?.let { "${it}m" } ?: metar.visibilitySm ?: "--"}"}" else "دید: --",
          style = MaterialTheme.typography.labelSmall
        )
        // Temp
        Text(
          text = if (metar != null) "دما: ${metar.tempC ?: "--"}°C" else "دما: --",
          style = MaterialTheme.typography.labelSmall
        )
        // QNH
        Text(
          text = if (metar != null) "QNH: ${metar.altimeterHpa?.toInt()?.let { "$it" } ?: "--"}" else "QNH: --",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.primary
        )
      }

      Spacer(modifier = Modifier.height(6.dp))

      // Status indicator chips
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          BoardStatusPill("METAR", hasData = metar != null)
          BoardStatusPill("TAF", hasData = item.hasTaf)
          BoardStatusPill("SIGMET", hasData = item.hasSigmet)
          BoardStatusPill("SNOWTAM", hasData = false)
        }

        Text(
          text = "به‌روزرسانی: ${item.lastUpdateUtc}",
          style = MaterialTheme.typography.labelSmall,
          fontSize = 9.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }
  }
}

@Composable
private fun BoardStatusPill(label: String, hasData: Boolean) {
  Surface(
    shape = RoundedCornerShape(4.dp),
    color = if (hasData) StatusGreen.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface
  ) {
    Text(
      text = "$label: ${if (hasData) "OK" else "NONE"}",
      style = MaterialTheme.typography.labelSmall,
      fontSize = 9.sp,
      fontWeight = FontWeight.Medium,
      color = if (hasData) StatusGreen else MaterialTheme.colorScheme.onSurfaceVariant,
      modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
    )
  }
}
