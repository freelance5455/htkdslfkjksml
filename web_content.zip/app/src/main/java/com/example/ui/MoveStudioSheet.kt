package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessibilityNew
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.StageBackground

private val CUTE_MOVES = listOf(
    "wavecute" to "Cute Wave",
    "catpaw" to "Cat Paw",
    "hearthands" to "Heart Hands",
    "peacecute" to "Cute Peace",
    "blushcheeks" to "Blush",
    "ojigi" to "Polite Bow",
    "bunny" to "Bunny Hop",
    "idolpose" to "Idol Pose",
    "cheer" to "Cheer",
    "kirakira" to "Sparkle",
    "ganbare" to "Ganbare!",
    "bounce" to "Bounce"
)

private val DANCE_MOVES = listOf(
    "party" to "Party",
    "groove" to "Groove",
    "sway" to "Sway",
    "hop" to "Hop",
    "spin" to "Spin",
    "march" to "March"
)

private val REACTION_MOVES = listOf(
    "wave" to "Wave",
    "nod" to "Nod",
    "shake" to "Shake Head",
    "jump" to "Jump",
    "shy" to "Shy",
    "think" to "Think",
    "thinkcheek" to "Wonder",
    "shrug" to "Shrug",
    "facepalm" to "Facepalm",
    "scratch" to "Scratch",
    "silly" to "Silly"
)

private val ACTION_MOVES = listOf(
    "thumbsup" to "Thumbs Up",
    "thumbsboth" to "Double Thumbs",
    "present" to "Present",
    "offer" to "Offer",
    "point" to "Point",
    "pointside" to "Point Side",
    "hips" to "Hands on Hips",
    "power" to "Power Pose",
    "flex" to "Flex",
    "sneak" to "Sneak",
    "dash" to "Dash",
    "lunge" to "Lunge"
)

private val DRESS_SWATCHES = listOf(
    Triple("Original", "orig", null),
    Triple("Sakura Pink", "#ff7eb6", Color(0xFFFF7EB6)),
    Triple("Crimson", "#e5384a", Color(0xFFE5384A)),
    Triple("Violet", "#8f63e0", Color(0xFF8F63E0)),
    Triple("Sky Blue", "#3f86f2", Color(0xFF3F86F2)),
    Triple("Teal", "#18b8a4", Color(0xFF18B8A4)),
    Triple("Emerald", "#35c46a", Color(0xFF35C46A)),
    Triple("Gold", "#f6c945", Color(0xFFF6C945)),
    Triple("Snow White", "#f2f2f2", Color(0xFFF2F2F2)),
    Triple("Midnight", "#1a1a1f", Color(0xFF1A1A1F))
)

private val ARM_OPTIONS = listOf("down", "up", "side", "forward", "wave", "hip", "head", "cheek", "chest", "point", "back")
private val LEG_OPTIONS = listOf("down", "lift", "kick", "side", "bend", "back")
private val HEAD_OPTIONS = listOf("none", "left", "right", "tilt_left", "tilt_right", "up", "down", "nod")
private val BODY_OPTIONS = listOf("none", "lean_left", "lean_right", "twist_left", "twist_right", "forward", "back", "bow", "jump", "spin")
private val MOOD_OPTIONS = listOf("neutral", "happy", "shy", "surprised", "think", "sad", "angry")

private val AI_CHOREO_PROMPTS = listOf(
    "Idol Stage Dance" to "Choreograph an energetic 6-move kawaii idol dance with spins and cheers!",
    "3 Cute Poses" to "Strike 3 super cute idol poses one after another and say something sweet.",
    "Sakura Makeover" to "Change your dress to sakura pink, do a happy spin, and ask how you look!",
    "Teach Banzai Move" to "Learn a new move called banzai: first both arms up and jump, then both arms down, and perform it now!",
    "Shy Greeting" to "Act shy, tilt your head, blush at your cheeks, and greet me softly."
)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun MoveStudioSheet(
    stageState: StageUiState,
    onDismiss: () -> Unit,
    onPlayMoves: (List<String>) -> Unit,
    onApplyPose: (spec: String, mood: String?) -> Unit,
    onStopMotion: () -> Unit,
    onSelectBackground: (StageBackground) -> Unit,
    onSelectDress: (String) -> Unit,
    onAskAi: (String) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var selectedTab by remember(stageState.moveStudioInitialTab) {
        mutableIntStateOf(stageState.moveStudioInitialTab.coerceIn(0, 3))
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        modifier = Modifier.testTag("move_studio_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 640.dp)
                .align(Alignment.CenterHorizontally)
                .padding(bottom = 24.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Rounded.AccessibilityNew,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(
                            text = stringResource(R.string.action_move_studio),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Current motion: ${stageState.currentMove}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                OutlinedButton(
                    onClick = onStopMotion,
                    modifier = Modifier.testTag("stop_motion_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Stop,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(stringResource(R.string.action_stop_move))
                }
            }

            Spacer(Modifier.height(8.dp))

            PrimaryTabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text(stringResource(R.string.tab_moves), maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    modifier = Modifier.testTag("tab_moves")
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text(stringResource(R.string.tab_poser), maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    modifier = Modifier.testTag("tab_poser")
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text(stringResource(R.string.tab_stage), maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    modifier = Modifier.testTag("tab_stage")
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text(stringResource(R.string.tab_ai_choreo), maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    modifier = Modifier.testTag("tab_ai_choreo")
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f, fill = false)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                when (selectedTab) {
                    0 -> MovesTabContent(
                        learnedMoves = stageState.learnedMoves,
                        onPlayMoves = onPlayMoves
                    )
                    1 -> BodyPoserTabContent(
                        onApplyPose = onApplyPose,
                        onStopMotion = onStopMotion
                    )
                    2 -> StageTabContent(
                        selectedBackground = stageState.background,
                        selectedDressColor = stageState.dressColor,
                        onSelectBackground = onSelectBackground,
                        onSelectDress = onSelectDress
                    )
                    else -> AiChoreoTabContent(onAskAi = onAskAi)
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun StageTabContent(
    selectedBackground: StageBackground,
    selectedDressColor: String,
    onSelectBackground: (StageBackground) -> Unit,
    onSelectDress: (String) -> Unit
) {
    Text(
        text = "Stage Background",
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        fontWeight = FontWeight.SemiBold
    )

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        StageBackground.entries.forEach { bg ->
            val isSelected = selectedBackground == bg
            Card(
                onClick = { onSelectBackground(bg) },
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(
                    width = if (isSelected) 2.dp else 1.dp,
                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                ),
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) {
                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.32f)
                    } else {
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                    }
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("bg_option_${bg.id}")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(width = 88.dp, height = 56.dp)
                            .clip(RoundedCornerShape(10.dp))
                    ) {
                        when (bg) {
                            StageBackground.SAKURA_SHRINE -> Image(
                                painter = painterResource(id = R.drawable.img_bg_sakura_shrine_1795001136789),
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            StageBackground.STARLIGHT_STUDIO -> Image(
                                painter = painterResource(id = R.drawable.img_bg_starlight_studio_1795001137053),
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            StageBackground.LAVENDER_GLOW -> Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.radialGradient(
                                            colors = listOf(
                                                MaterialTheme.colorScheme.primaryContainer,
                                                MaterialTheme.colorScheme.surfaceVariant
                                            )
                                        )
                                    )
                            )
                        }
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = bg.label,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = bg.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (isSelected) {
                        Icon(
                            imageVector = Icons.Rounded.CheckCircle,
                            contentDescription = "Selected background",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }
        }
    }

    HorizontalDivider()

    Text(
        text = "Dress Color",
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        fontWeight = FontWeight.SemiBold
    )

    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        DRESS_SWATCHES.forEach { (label, hex, swatchColor) ->
            val isSelected = selectedDressColor.equals(hex, ignoreCase = true)
            val borderColor = if (isSelected) {
                MaterialTheme.colorScheme.primary
            } else {
                MaterialTheme.colorScheme.outlineVariant
            }
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .border(width = if (isSelected) 3.dp else 1.dp, color = borderColor, shape = CircleShape)
                    .clickable { onSelectDress(hex) }
                    .semantics { contentDescription = "Dress color $label" }
                    .testTag("dress_swatch_$hex")
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .then(
                            if (swatchColor != null) {
                                Modifier.background(swatchColor)
                            } else {
                                Modifier.background(
                                    Brush.linearGradient(
                                        colors = listOf(
                                            MaterialTheme.colorScheme.secondary,
                                            MaterialTheme.colorScheme.surfaceVariant
                                        )
                                    )
                                )
                            }
                        )
                ) {
                    if (isSelected) {
                        val iconTint = if (hex == "#f2f2f2" || hex == "#f6c945") {
                            MaterialTheme.colorScheme.onSurface
                        } else {
                            Color.White
                        }
                        Icon(
                            imageVector = Icons.Rounded.Check,
                            contentDescription = null,
                            tint = iconTint,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun MovesTabContent(
    learnedMoves: List<String>,
    onPlayMoves: (List<String>) -> Unit
) {
    if (learnedMoves.isNotEmpty()) {
        MoveGroup(
            title = "Learned Moves",
            moves = learnedMoves.map { it to it },
            onPlayMove = { onPlayMoves(listOf(it)) }
        )
    }
    MoveGroup(
        title = "Cute & Idol",
        moves = CUTE_MOVES,
        onPlayMove = { onPlayMoves(listOf(it)) }
    )
    MoveGroup(
        title = "Dance",
        moves = DANCE_MOVES,
        onPlayMove = { onPlayMoves(listOf(it)) }
    )
    MoveGroup(
        title = "Reactions",
        moves = REACTION_MOVES,
        onPlayMove = { onPlayMoves(listOf(it)) }
    )
    MoveGroup(
        title = "Actions & Poses",
        moves = ACTION_MOVES,
        onPlayMove = { onPlayMoves(listOf(it)) }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun MoveGroup(
    title: String,
    moves: List<Pair<String, String>>,
    onPlayMove: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.SemiBold
        )
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            moves.forEach { (id, label) ->
                AssistChip(
                    onClick = { onPlayMove(id) },
                    label = { Text(label) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Rounded.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    modifier = Modifier.testTag("move_chip_$id")
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun BodyPoserTabContent(
    onApplyPose: (spec: String, mood: String?) -> Unit,
    onStopMotion: () -> Unit
) {
    var leftArm by remember { mutableStateOf("down") }
    var rightArm by remember { mutableStateOf("down") }
    var leftLeg by remember { mutableStateOf("down") }
    var rightLeg by remember { mutableStateOf("down") }
    var head by remember { mutableStateOf("none") }
    var body by remember { mutableStateOf("none") }
    var mood by remember { mutableStateOf("happy") }

    Text(
        text = "Compose a direct 3D skeleton pose (her own left & right).",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )

    PoseSelectorGroup("Left Arm", ARM_OPTIONS, leftArm) { leftArm = it }
    PoseSelectorGroup("Right Arm", ARM_OPTIONS, rightArm) { rightArm = it }
    PoseSelectorGroup("Left Leg", LEG_OPTIONS, leftLeg) { leftLeg = it }
    PoseSelectorGroup("Right Leg", LEG_OPTIONS, rightLeg) { rightLeg = it }
    PoseSelectorGroup("Head", HEAD_OPTIONS, head) { head = it }
    PoseSelectorGroup("Torso / Body", BODY_OPTIONS, body) { body = it }
    PoseSelectorGroup("Facial Mood", MOOD_OPTIONS, mood) { mood = it }

    HorizontalDivider()

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        OutlinedButton(
            onClick = {
                leftArm = "down"
                rightArm = "down"
                leftLeg = "down"
                rightLeg = "down"
                head = "none"
                body = "none"
                mood = "neutral"
                onStopMotion()
            },
            modifier = Modifier
                .weight(1f)
                .testTag("reset_pose_button")
        ) {
            Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text(stringResource(R.string.action_reset_pose))
        }

        Button(
            onClick = {
                val parts = mutableListOf(
                    "left_arm=$leftArm",
                    "right_arm=$rightArm",
                    "left_leg=$leftLeg",
                    "right_leg=$rightLeg"
                )
                if (head != "none") parts.add("head=$head")
                if (body != "none") parts.add("body=$body")
                onApplyPose(parts.joinToString(", "), mood)
            },
            modifier = Modifier
                .weight(1.4f)
                .testTag("apply_pose_button")
        ) {
            Icon(Icons.Rounded.AccessibilityNew, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text(stringResource(R.string.action_apply_pose))
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PoseSelectorGroup(
    label: String,
    options: List<String>,
    selected: String,
    onSelect: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Medium
        )
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            options.forEach { option ->
                FilterChip(
                    selected = selected == option,
                    onClick = { onSelect(option) },
                    label = { Text(option.replace('_', ' ')) },
                    modifier = Modifier.testTag("pose_${label.lowercase().replace(' ', '_')}_$option")
                )
            }
        }
    }
}

@Composable
private fun AiChoreoTabContent(onAskAi: (String) -> Unit) {
    Text(
        text = "Let Gemini AI choreograph multi-step body animations, dress changes, and new learned moves.",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    AI_CHOREO_PROMPTS.forEachIndexed { idx, (title, prompt) ->
        FilledTonalButton(
            onClick = { onAskAi(prompt) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("ai_choreo_preset_$idx")
        ) {
            Icon(
                imageVector = if (idx == 0) Icons.Rounded.MusicNote else Icons.Rounded.AutoAwesome,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text(title, modifier = Modifier.weight(1f))
        }
    }
}
