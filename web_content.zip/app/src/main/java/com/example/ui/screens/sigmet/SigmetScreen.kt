package com.example.ui.screens.sigmet

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SigmetData
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.UiState
import com.example.ui.viewmodel.WeatherViewModel

@Composable
fun SigmetScreen(
  viewModel: WeatherViewModel,
  modifier: Modifier = Modifier
) {
  val selectedAirport by viewModel.selectedAirport.collectAsState()
  val sigmetsState by viewModel.sigmetsState.collectAsState()
  val isOffline by viewModel.isOffline.collectAsState()

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp)
      .testTag("sigmet_screen"),
    verticalArrangement = Arrangement.spacedBy(14.dp),
    contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
  ) {
    if (isOffline) {
      item { OfflineNoticeBanner() }
    }

    // Header (English)
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "En-Route Weather Hazards (RAW SIGMET)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = AtcTextMain
          )
          Text(
            text = "Active ICAO SIGMET messages for FIR ${selectedAirport.fir} and adjacent regions",
            style = MaterialTheme.typography.bodySmall,
            color = AtcTextMuted
          )
        }

        IconButton(onClick = { viewModel.loadSigmets() }) {
          Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = OceanBlue)
        }
      }
    }

    when (val state = sigmetsState) {
      is UiState.Success -> {
        val sigmets = state.data

        if (sigmets.isEmpty()) {
          item {
            Card(
              shape = RoundedCornerShape(14.dp),
              colors = CardDefaults.cardColors(containerColor = Color.White),
              border = CardDefaults.outlinedCardBorder(),
              modifier = Modifier.fillMaxWidth().testTag("no_active_sigmet_card")
            ) {
              Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
              ) {
                Surface(
                  shape = androidx.compose.foundation.shape.CircleShape,
                  color = StatusGreen.copy(alpha = 0.15f),
                  modifier = Modifier.size(54.dp)
                ) {
                  Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StatusGreen, modifier = Modifier.size(32.dp))
                  }
                }
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                  text = "NO ACTIVE SIGMET HAZARDS REPORTED",
                  style = MaterialTheme.typography.titleSmall,
                  fontWeight = FontWeight.Bold,
                  color = StatusGreen
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = "No severe turbulence, convective storms, or icing bulletins in current FIR coverage.",
                  style = MaterialTheme.typography.bodySmall,
                  color = AtcTextMuted
                )
              }
            }
          }
        } else {
          item {
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = SigmetCardBg,
              border = androidx.compose.foundation.BorderStroke(1.dp, SigmetCardBorder),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(Icons.Default.Warning, contentDescription = null, tint = SigmetCardText)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = "${sigmets.size} Active RAW SIGMET messages retrieved from OPMET network.",
                  style = MaterialTheme.typography.labelMedium,
                  fontWeight = FontWeight.Bold,
                  color = SigmetCardText
                )
              }
            }
          }

          items(sigmets) { sigmet ->
            RawSigmetItemCard(sigmet = sigmet)
          }
        }
      }

      is UiState.Loading -> {
        item {
          Card(modifier = Modifier.fillMaxWidth()) {
            Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
              CircularProgressIndicator(color = OceanBlue)
            }
          }
        }
      }

      is UiState.Error -> {
        item {
          Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
              Text("SIGMET Error: ${state.message}", color = StatusRed, fontWeight = FontWeight.Bold)
              Text("OPMET SIGMET source unavailable.", style = MaterialTheme.typography.bodySmall)
            }
          }
        }
      }
    }

    item { OperationalDisclaimerCard() }
  }
}

// PURE RAW SIGMET CARD - SOFT ORANGE (نارنجی ملایم)
// No explanations, no interpretations, pure raw message for controllers
@Composable
private fun RawSigmetItemCard(
  sigmet: SigmetData,
  modifier: Modifier = Modifier
) {
  val clipboard = LocalClipboardManager.current
  val context = LocalContext.current

  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = SigmetCardBg),
    border = androidx.compose.foundation.BorderStroke(1.5.dp, SigmetCardBorder),
    modifier = modifier.fillMaxWidth().testTag("sigmet_card_${sigmet.sigmetId}")
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            shape = RoundedCornerShape(4.dp),
            color = SigmetCardText
          ) {
            Text(
              text = sigmet.firId,
              color = Color.White,
              fontWeight = FontWeight.Bold,
              style = MaterialTheme.typography.labelSmall,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "RAW SIGMET: ${sigmet.hazard} (${sigmet.firId})",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = SigmetCardText
          )
        }

        IconButton(
          onClick = {
            clipboard.setText(AnnotatedString(sigmet.rawSigmet))
            Toast.makeText(context, "SIGMET copied to clipboard", Toast.LENGTH_SHORT).show()
          },
          modifier = Modifier.size(32.dp).testTag("btn_copy_sigmet_${sigmet.sigmetId}")
        ) {
          Icon(
            imageVector = Icons.Default.ContentCopy,
            contentDescription = "Copy RAW SIGMET",
            tint = SigmetCardText,
            modifier = Modifier.size(18.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Technical Monospace Display for RAW SIGMET (Full soft orange card body)
      Surface(
        shape = RoundedCornerShape(8.dp),
        color = Color.White.copy(alpha = 0.25f),
        border = androidx.compose.foundation.BorderStroke(1.dp, SigmetCardBorder),
        modifier = Modifier.fillMaxWidth()
      ) {
        Text(
          text = sigmet.rawSigmet,
          style = MaterialTheme.typography.bodyMedium.copy(
            fontFamily = FontFamily.Monospace,
            letterSpacing = 0.5.sp,
            lineHeight = 22.sp
          ),
          color = SigmetCardText,
          modifier = Modifier.padding(12.dp)
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Header Meta Details (No interpretation)
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column {
          Text(text = "FIR / Region", style = MaterialTheme.typography.labelSmall, color = SigmetCardText.copy(alpha = 0.7f))
          Text(text = sigmet.firName.ifBlank { sigmet.firId }, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = SigmetCardText)
        }
        Column {
          Text(text = "Valid Period (UTC)", style = MaterialTheme.typography.labelSmall, color = SigmetCardText.copy(alpha = 0.7f))
          Text(text = "${sigmet.validFromUtc} - ${sigmet.validToUtc}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = SigmetCardText)
        }
      }
    }
  }
}
