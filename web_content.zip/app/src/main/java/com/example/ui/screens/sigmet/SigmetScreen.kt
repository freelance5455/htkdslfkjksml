package com.example.ui.screens.sigmet

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SigmetData
import com.example.ui.components.*
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusRed
import com.example.ui.theme.StatusYellow
import com.example.ui.viewmodel.UiState
import com.example.ui.viewmodel.WeatherViewModel

@Composable
fun SigmetScreen(
  viewModel: WeatherViewModel,
  modifier: Modifier = Modifier
) {
  val sigmetsState by viewModel.sigmetsState.collectAsState()
  val isOffline by viewModel.isOffline.collectAsState()

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp)
      .testTag("sigmet_screen"),
    verticalArrangement = Arrangement.spacedBy(14.dp),
    contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
  ) {
    if (isOffline) {
      item { OfflineNoticeBanner() }
    }

    // Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "هشدارهای پدیده‌های جوی خطرناک (SIGMET)",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "شامل مناطق پروازی ایران (Tehran FIR OIIX) و بین‌المللی WIFS/ICAO",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }

        IconButton(onClick = { viewModel.loadSigmets() }) {
          Icon(Icons.Default.Refresh, contentDescription = "به‌روزرسانی", tint = MaterialTheme.colorScheme.primary)
        }
      }
    }

    when (val state = sigmetsState) {
      is UiState.Success -> {
        val sigmets = state.data

        if (sigmets.isEmpty()) {
          item {
            Card(
              shape = RoundedCornerShape(12.dp),
              colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
              border = CardDefaults.outlinedCardBorder(),
              modifier = Modifier.fillMaxWidth().testTag("no_active_sigmet_card")
            ) {
              Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
              ) {
                Surface(
                  shape = androidx.compose.foundation.shape.CircleShape,
                  color = StatusGreen.copy(alpha = 0.2f),
                  modifier = Modifier.size(54.dp)
                ) {
                  Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = StatusGreen, modifier = Modifier.size(32.dp))
                  }
                }
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                  text = "در حال حاضر هیچ پیام SIGMET فعالی در محدوده ثبت نشده است",
                  style = MaterialTheme.typography.titleSmall,
                  fontWeight = FontWeight.Bold,
                  color = StatusGreen
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = "شرایط پروازی در FIRهای بررسی شده فاقد پدیده‌های فوق‌العاده مخرب گزارش شده است.",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }
        } else {
          item {
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = MaterialTheme.colorScheme.primaryContainer,
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = "تعداد ${sigmets.size} پیام هوانوردی فعال SIGMET از منابع بین‌المللی OPMET دریافت شد.",
                  style = MaterialTheme.typography.labelMedium,
                  color = MaterialTheme.colorScheme.onPrimaryContainer
                )
              }
            }
          }

          items(sigmets) { sigmet ->
            SigmetItemCard(sigmet = sigmet)
          }
        }
      }

      is UiState.Loading -> {
        item {
          Card(modifier = Modifier.fillMaxWidth()) {
            Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator()
                Spacer(modifier = Modifier.height(12.dp))
                Text("در حال دریافت هشدارهای SIGMET جهانی...")
              }
            }
          }
        }
      }

      is UiState.Error -> {
        item {
          Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
              Text("خطا در دریافت هشدارهای SIGMET: ${state.message}", color = StatusRed, fontWeight = FontWeight.Bold)
              Text("منبع داده در دسترس نیست (DATA SOURCE UNAVAILABLE).", style = MaterialTheme.typography.bodySmall)
            }
          }
        }
      }
    }

    item { OperationalDisclaimerCard() }
  }
}

@Composable
private fun SigmetItemCard(
  sigmet: SigmetData,
  modifier: Modifier = Modifier
) {
  val hazardFa = when (sigmet.hazard) {
    "TS" -> "رعد و برق شدید (Thunderstorm)"
    "TURB" -> "توربولانس شدید (Severe Turbulence)"
    "ICE" -> "یخ‌زدگی شدید (Severe Icing)"
    "VA" -> "خاکستر آتشفشانی (Volcanic Ash)"
    "TC" -> "طوفان حاره‌ای (Tropical Cyclone)"
    "MTW" -> "امواج کوهستان (Mountain Waves)"
    "RDOACT" -> "مواد رادیواکتیو (Radioactive Cloud)"
    else -> "${sigmet.hazard} (${sigmet.qualifier})"
  }

  Card(
    shape = RoundedCornerShape(12.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    border = CardDefaults.outlinedCardBorder(),
    modifier = modifier.fillMaxWidth().testTag("sigmet_card_${sigmet.sigmetId}")
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Surface(
            shape = RoundedCornerShape(4.dp),
            color = StatusRed
          ) {
            Text(
              text = sigmet.firId,
              color = Color.White,
              fontWeight = FontWeight.Bold,
              style = MaterialTheme.typography.labelSmall,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = sigmet.firName,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold
          )
        }

        Surface(
          shape = RoundedCornerShape(4.dp),
          color = StatusYellow.copy(alpha = 0.2f)
        ) {
          Text(
            text = "معتبر: ${sigmet.validFromUtc} - ${sigmet.validToUtc}",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = "پدیده: $hazardFa",
        style = MaterialTheme.typography.bodyMedium,
        fontWeight = FontWeight.Bold,
        color = StatusRed
      )

      if (sigmet.baseFt != null || sigmet.topFt != null) {
        Text(
          text = "ارتفاع پدیده: از ${sigmet.baseFt?.let { "${it}ft" } ?: "سطح"} تا ${sigmet.topFt?.let { "${it}ft" } ?: "نامشخص"}",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.primary
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Raw Message
      Surface(
        shape = RoundedCornerShape(8.dp),
        color = MaterialTheme.colorScheme.surface,
        border = CardDefaults.outlinedCardBorder(),
        modifier = Modifier.fillMaxWidth()
      ) {
        Text(
          text = sigmet.rawSigmet,
          style = MaterialTheme.typography.bodySmall.copy(
            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
            lineHeight = 20.sp
          ),
          modifier = Modifier.padding(10.dp)
        )
      }

      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text(
          text = "منبع: ${sigmet.source}",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (sigmet.coordsJson.isNotBlank()) {
          Text(
            text = "مختصات چندضلعی پدیده موجود است",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.primary
          )
        }
      }
    }
  }
}
