package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.core.ByteSizeFormatter
import com.example.data.model.ApkPackageMetadata
import com.example.data.model.ConflictAction
import com.example.data.model.ConflictPrompt
import com.example.data.model.FileNode
import com.example.data.model.TransferProgress

@Composable
fun TextPromptDialog(
    title: String,
    initialValue: String,
    placeholder: String,
    confirmLabel: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var value by remember(initialValue) { mutableStateOf(initialValue) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, style = MaterialTheme.typography.titleLarge) },
        text = {
            OutlinedTextField(
                value = value,
                onValueChange = { value = it },
                placeholder = { Text(placeholder) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("prompt_text_input")
            )
        },
        confirmButton = {
            Button(
                onClick = { if (value.isNotBlank()) onConfirm(value.trim()) },
                enabled = value.isNotBlank(),
                modifier = Modifier.testTag("prompt_confirm_button")
            ) {
                Text(confirmLabel)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun TransferProgressDialog(
    progress: TransferProgress,
    onCancel: () -> Unit
) {
    val fraction = if (progress.totalBytes > 0L) {
        (progress.bytesProcessed.toFloat() / progress.totalBytes.toFloat()).coerceIn(0f, 1f)
    } else 0f

    AlertDialog(
        onDismissRequest = {},
        title = { Text(progress.operationLabel, style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = progress.currentFileName,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 1
                )
                LinearProgressIndicator(
                    progress = { fraction },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "${progress.processedCount + 1} / ${progress.totalCount}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "${(fraction * 100).toInt()}%",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        },
        confirmButton = {
            if (progress.isCancellable) {
                TextButton(
                    onClick = onCancel,
                    modifier = Modifier.testTag("transfer_cancel_button")
                ) {
                    Text("Cancel")
                }
            }
        }
    )
}

@Composable
fun ConflictResolutionDialog(
    prompt: ConflictPrompt,
    onResolve: (ConflictAction, Boolean) -> Unit
) {
    var applyToAll by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = {},
        title = { Text("File conflict detected", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "\"${prompt.fileName}\" already exists in this folder.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    text = "Existing: ${ByteSizeFormatter.format(prompt.existingSizeBytes)} • Incoming: ${ByteSizeFormatter.format(prompt.incomingSizeBytes)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    Checkbox(
                        checked = applyToAll,
                        onCheckedChange = { applyToAll = it }
                    )
                    Text("Apply to all conflicts", style = MaterialTheme.typography.bodyMedium)
                }
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                TextButton(
                    onClick = { onResolve(ConflictAction.SKIP, applyToAll) },
                    modifier = Modifier.testTag("conflict_skip_button")
                ) {
                    Text("Skip")
                }
                OutlinedButton(
                    onClick = { onResolve(ConflictAction.REPLACE, applyToAll) },
                    modifier = Modifier.testTag("conflict_replace_button")
                ) {
                    Text("Replace")
                }
                Button(
                    onClick = { onResolve(ConflictAction.KEEP_BOTH, applyToAll) },
                    modifier = Modifier.testTag("conflict_keep_both_button")
                ) {
                    Text("Keep both")
                }
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApkInspectorBottomSheet(
    metadata: ApkPackageMetadata,
    onShareInstaller: () -> Unit,
    onDismiss: () -> Unit
) {
    var showInstallInfoBanner by remember { mutableStateOf(false) }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.size(52.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Android,
                        contentDescription = "Android Package",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(12.dp)
                    )
                }
                Spacer(Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = metadata.appLabel ?: metadata.fileName,
                        style = MaterialTheme.typography.titleLarge
                    )
                    FileBadgePill(
                        text = if (metadata.isBundleFormat) "Split APK Bundle" else "Installation file"
                    )
                }
            }

            HorizontalDivider()

            MetadataRow("File name", metadata.fileName)
            MetadataRow("Size", ByteSizeFormatter.format(metadata.sizeBytes))
            MetadataRow("Package name", metadata.packageName ?: "Unparsed / Bundle archive")
            if (metadata.versionName != null || metadata.versionCode != null) {
                MetadataRow(
                    "Version",
                    "${metadata.versionName ?: "N/A"} (${metadata.versionCode ?: "-"})"
                )
            }
            if (metadata.minSdk != null || metadata.targetSdk != null) {
                MetadataRow(
                    "SDK Targets",
                    "minSdk ${metadata.minSdk ?: "?"} • targetSdk ${metadata.targetSdk ?: "?"}"
                )
            }
            MetadataRow("ZIP Entries", "${metadata.archiveEntriesCount} archive entries")

            if (showInstallInfoBanner) {
                Surface(
                    color = MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Info,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            text = metadata.installExplanation,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onShareInstaller,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Share Archive")
                }
                Button(
                    onClick = { showInstallInfoBanner = true },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("apk_install_stub_button")
                ) {
                    Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Install")
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileDetailsBottomSheet(
    node: FileNode,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                FileTypeThumbnail(node = node, size = 48.dp)
                Spacer(Modifier.width(14.dp))
                Column {
                    Text(node.name, style = MaterialTheme.typography.titleMedium)
                    Text(
                        node.kind.displayLabel,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            if (node.hasSuspiciousDoubleExtension && node.doubleExtensionWarning != null) {
                Surface(
                    color = MaterialTheme.colorScheme.error.copy(alpha = 0.12f),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Filled.Warning,
                            contentDescription = "Security Warning",
                            tint = MaterialTheme.colorScheme.error
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            node.doubleExtensionWarning,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
            HorizontalDivider()
            MetadataRow("Type", "${node.kind.displayLabel} (${node.mimeType})")
            if (node.magicSignature != null) {
                MetadataRow("Magic Signature", node.magicSignature)
            }
            MetadataRow("Size", ByteSizeFormatter.format(node.sizeBytes))
            MetadataRow("Last modified", ByteSizeFormatter.formatTimestamp(node.lastModified))
            MetadataRow("Path", node.path)
            MetadataRow("Access", if (node.isReadOnly) "Read-only" else "Read & Write")
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun MetadataRow(label: String, value: String) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium
        )
    }
}
