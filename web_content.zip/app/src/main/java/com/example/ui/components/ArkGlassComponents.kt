package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.ArkThemeTokens
import com.example.util.rememberDecodedImageBitmap

@Composable
fun ArkAuroraBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val colors = ArkThemeTokens.colors

    Box(
        modifier = modifier
            .fillMaxSize()
            .drawWithCache {
                val bgBrush = Brush.verticalGradient(
                    colors = listOf(colors.background, colors.backgroundBottom)
                )
                val accentCenter = Offset(size.width * 0.5f, 0f)
                val accentRadius = (size.width * 0.9f).coerceAtLeast(1f)
                val topWhisper = Brush.radialGradient(
                    colors = listOf(
                        colors.accent.copy(alpha = if (colors.isDark) 0.07f else 0.045f),
                        Color.Transparent
                    ),
                    center = accentCenter,
                    radius = accentRadius
                )
                onDrawBehind {
                    drawRect(brush = bgBrush)
                    drawCircle(brush = topWhisper, center = accentCenter, radius = accentRadius)
                }
            },
        content = content
    )
}

@Composable
fun LiquidGlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 20.dp,
    accentColor: Color? = null,
    useGlass: Boolean = false,
    onClick: (() -> Unit)? = null,
    contentPadding: PaddingValues = PaddingValues(16.dp),
    content: @Composable ColumnScope.() -> Unit
) {
    val colors = ArkThemeTokens.colors
    val effectiveRadius = if (useGlass) 22.dp else cornerRadius
    val shape = RoundedCornerShape(effectiveRadius)

    val containerColor = if (useGlass) colors.glass else colors.surface
    val borderBrush = if (useGlass) {
        Brush.verticalGradient(
            colors = listOf(
                colors.glassLine,
                (accentColor ?: colors.hairline).copy(alpha = 0.25f)
            )
        )
    } else {
        Brush.verticalGradient(
            colors = listOf(
                accentColor?.copy(alpha = 0.28f) ?: colors.hairline,
                accentColor?.copy(alpha = 0.14f) ?: colors.hairline
            )
        )
    }

    val shadowElevation = if (useGlass) {
        if (colors.isDark) 10.dp else 8.dp
    } else {
        if (colors.isDark) 0.dp else 1.dp
    }

    Surface(
        modifier = modifier
            .shadow(
                elevation = shadowElevation,
                shape = shape,
                ambientColor = Color.Black.copy(alpha = 0.08f),
                spotColor = Color.Black.copy(alpha = 0.08f)
            )
            .clip(shape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .border(width = 1.dp, brush = borderBrush, shape = shape),
        shape = shape,
        color = containerColor,
        tonalElevation = 0.dp
    ) {
        Column(
            modifier = Modifier.padding(contentPadding),
            content = content
        )
    }
}

@Composable
fun ArkGlassNestedSurface(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 16.dp,
    onClick: (() -> Unit)? = null,
    contentPadding: PaddingValues = PaddingValues(12.dp),
    content: @Composable ColumnScope.() -> Unit
) {
    val colors = ArkThemeTokens.colors
    val shape = RoundedCornerShape(cornerRadius)
    Surface(
        modifier = modifier
            .clip(shape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
        shape = shape,
        color = colors.glass2,
        border = BorderStroke(1.dp, colors.hairline.copy(alpha = 0.7f))
    ) {
        Column(
            modifier = Modifier.padding(contentPadding),
            content = content
        )
    }
}

@Composable
fun ArkCircleGlassButton(
    icon: ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color? = null,
    containerColor: Color? = null
) {
    val colors = ArkThemeTokens.colors
    Surface(
        onClick = onClick,
        shape = CircleShape,
        color = containerColor ?: colors.glass,
        border = BorderStroke(1.dp, colors.glassLine),
        modifier = modifier
            .size(46.dp)
            .shadow(
                elevation = if (colors.isDark) 6.dp else 4.dp,
                shape = CircleShape,
                ambientColor = Color.Black.copy(alpha = 0.08f),
                spotColor = Color.Black.copy(alpha = 0.08f)
            )
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = tint ?: colors.ink,
                modifier = Modifier.size(21.dp)
            )
        }
    }
}

@Composable
fun GlowingPillButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    isLoading: Boolean = false,
    accent: Color? = null
) {
    val colors = ArkThemeTokens.colors
    val primaryAccent = accent ?: colors.accent
    val fgColor = if (colors.isDark && primaryAccent == colors.accent) {
        Color(0xFF0E1326)
    } else {
        Color.White
    }
    Button(
        onClick = onClick,
        enabled = enabled && !isLoading,
        modifier = modifier.height(48.dp),
        shape = RoundedCornerShape(24.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = primaryAccent,
            contentColor = fgColor,
            disabledContainerColor = colors.surfaceSecondary,
            disabledContentColor = colors.ink3
        ),
        elevation = ButtonDefaults.buttonElevation(
            defaultElevation = 0.dp,
            pressedElevation = 0.dp
        ),
        contentPadding = PaddingValues(horizontal = 20.dp)
    ) {
        if (isLoading) {
            CircularProgressIndicator(
                modifier = Modifier.size(18.dp),
                strokeWidth = 2.dp,
                color = fgColor
            )
        } else {
            if (icon != null) {
                Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
            }
            Text(text = text, style = MaterialTheme.typography.labelLarge, maxLines = 1)
        }
    }
}

@Composable
fun ArkAvatarBadge(
    avatarPreset: String,
    username: String,
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    imageBase64: String? = null,
    isOnline: Boolean = false,
    showOnlineDot: Boolean = false
) {
    val colors = ArkThemeTokens.colors
    val bitmap = rememberDecodedImageBitmap(imageBase64)
    val (gradStart, gradEnd, icon) = when (avatarPreset) {
        "cyber_violet" -> Triple(Color(0xFF5D5FEF), Color(0xFF8B7BFF), Icons.Default.AutoAwesome)
        "solar_gold" -> Triple(Color(0xFFD9941E), Color(0xFFE56B55), Icons.Default.EmojiEvents)
        "emerald_nova" -> Triple(Color(0xFF269B68), Color(0xFF3E8E9E), Icons.Default.Shield)
        "coral_pulse" -> Triple(Color(0xFFE45454), Color(0xFF8B63E6), Icons.Default.RocketLaunch)
        else -> Triple(Color(0xFF4267D5), Color(0xFF6B8AE6), Icons.Default.Bolt)
    }

    Box(modifier = modifier.size(size)) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(gradStart, gradEnd)))
                .border(1.dp, colors.hairline.copy(alpha = 0.5f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (bitmap != null) {
                Image(
                    bitmap = bitmap,
                    contentDescription = "$username avatar",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Icon(
                    imageVector = icon,
                    contentDescription = "$username avatar",
                    tint = Color.White,
                    modifier = Modifier.size(size * 0.48f)
                )
            }
        }
        if (showOnlineDot && isOnline) {
            Box(
                modifier = Modifier
                    .size(size * 0.28f)
                    .align(Alignment.BottomEnd)
                    .clip(CircleShape)
                    .background(colors.success)
                    .border(2.dp, colors.surface, CircleShape)
            )
        }
    }
}

@Composable
fun LevelProgressPill(
    level: Long,
    xp: Long,
    points: Long,
    modifier: Modifier = Modifier
) {
    val colors = ArkThemeTokens.colors
    val xpInLevel = (xp % 200L).toFloat() / 200f
    LiquidGlassCard(
        modifier = modifier,
        cornerRadius = 18.dp,
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = colors.accentSoft
                ) {
                    Text(
                        text = "LVL $level",
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.accent,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
                Spacer(Modifier.width(10.dp))
                Text(
                    text = "${xp % 200L} / 200 XP",
                    style = MaterialTheme.typography.labelMedium,
                    color = colors.ink2
                )
            }
            Text(
                text = "$points PTS",
                style = MaterialTheme.typography.labelLarge,
                color = colors.gold
            )
        }
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator(
            progress = { xpInLevel.coerceIn(0f, 1f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(5.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = colors.accent,
            trackColor = colors.surfaceSecondary
        )
    }
}

@Composable
fun UserBadgeChip(
    label: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(50),
        color = accent.copy(alpha = 0.12f),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.25f))
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = accent,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun EmptyStateGlassCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    val colors = ArkThemeTokens.colors
    LiquidGlassCard(modifier = modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(CircleShape)
                    .background(colors.accentSoft),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = colors.accent, modifier = Modifier.size(26.dp))
            }
            Spacer(Modifier.height(12.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = colors.ink,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = colors.ink2,
                textAlign = TextAlign.Center
            )
            if (actionLabel != null && onAction != null) {
                Spacer(Modifier.height(14.dp))
                GlowingPillButton(text = actionLabel, onClick = onAction)
            }
        }
    }
}

