package com.example.ui

import android.content.Context
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SecurityPreferences
import com.example.ui.components.PinKeypad
import com.example.ui.theme.CyberCard
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberNavy
import com.example.ui.theme.CyberRed
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

class LockOverlayActivity : ComponentActivity() {

    companion object {
        const val EXTRA_REASON = "extra_reason"
        const val EXTRA_PACKAGE = "extra_package"
    }

    private lateinit var prefs: SecurityPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = SecurityPreferences.getInstance(this)

        // Setup lockscreen overlay flags
        setupWindowFlags()

        val reason = intent.getStringExtra(EXTRA_REASON) ?: "Acceso protegido por seguridad"
        val targetPkg = intent.getStringExtra(EXTRA_PACKAGE) ?: ""

        setContent {
            MyApplicationTheme {
                // Intercept back button to prevent thief escaping lockscreen
                BackHandler(enabled = true) {
                    Toast.makeText(
                        this@LockOverlayActivity,
                        "Introduce el PIN de 6 dígitos para continuar",
                        Toast.LENGTH_SHORT
                    ).show()
                }

                var currentPin by remember { mutableStateOf("") }
                var errorMessage by remember { mutableStateOf<String?>(null) }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = CyberNavy
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color(0xFF150A10),
                                        CyberNavy,
                                        Color(0xFF061324)
                                    )
                                )
                            )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(horizontal = 20.dp, vertical = 24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Spacer(modifier = Modifier.height(16.dp))

                            // Alert Banner
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(CyberRed.copy(alpha = 0.15f))
                                    .border(1.dp, CyberRed.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                                    .padding(16.dp)
                                    .testTag("lock_alert_banner")
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = null,
                                        tint = CyberRed,
                                        modifier = Modifier.size(28.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = "APARTADO BLOQUEADO",
                                            style = MaterialTheme.typography.labelLarge.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = CyberRed,
                                                letterSpacing = 1.sp
                                            )
                                        )
                                        Text(
                                            text = reason,
                                            style = MaterialTheme.typography.bodyMedium.copy(
                                                color = TextPrimary,
                                                fontWeight = FontWeight.Medium
                                            )
                                        )
                                        if (targetPkg.isNotBlank()) {
                                            Text(
                                                text = "Origen: $targetPkg",
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    color = TextMuted
                                                )
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(24.dp))

                            // PIN Keypad
                            PinKeypad(
                                currentPin = currentPin,
                                onPinChange = {
                                    currentPin = it
                                    if (errorMessage != null) errorMessage = null
                                },
                                onPinComplete = { enteredPin ->
                                    if (prefs.verifyPin(enteredPin)) {
                                        // PIN valid: grant 30-sec grace period so owner can proceed legitimately
                                        prefs.grantTemporaryAccess(durationSeconds = 30)
                                        Toast.makeText(
                                            this@LockOverlayActivity,
                                            "PIN correcto: Acceso concedido (30s)",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                        finish()
                                    } else {
                                        errorMessage = "PIN incorrecto. Reintenta."
                                        currentPin = ""
                                    }
                                },
                                errorMessage = errorMessage,
                                title = "Desbloquear con PIN",
                                subtitle = "Introduce tu PIN de 6 dígitos de TecnoGuard",
                                modifier = Modifier.testTag("lock_pin_keypad")
                            )

                            Spacer(modifier = Modifier.height(24.dp))

                            // Bottom Security Notice
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(CyberCard.copy(alpha = 0.5f))
                                    .padding(horizontal = 16.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Shield,
                                    contentDescription = null,
                                    tint = CyberCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "Protección Antirrobo activa en HiOS / Android 13.",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = TextSecondary,
                                        textAlign = TextAlign.Start
                                    )
                                )
                            }

                            Spacer(modifier = Modifier.height(16.dp))
                        }
                    }
                }
            }
        }
    }

    private fun setupWindowFlags() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
            WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
        )
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Prevent dismissal via back button
        Toast.makeText(this, "Introduce el PIN de 6 dígitos", Toast.LENGTH_SHORT).show()
    }
}
