package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SdCard
import androidx.compose.material.icons.filled.Shop
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.StorageBreakdown
import com.example.ui.theme.DopingAmber
import com.example.ui.theme.DopingAmberDark
import com.example.ui.theme.DopingGreen
import com.example.ui.theme.DopingPrimary
import com.example.ui.theme.DopingPrimaryVariant
import com.example.ui.theme.DopingRed

@Composable
fun StorageSettingsScreen(
  storageBreakdown: StorageBreakdown,
  onToggleOfflineDownload: () -> Unit,
  onClearCache: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val usedGb = storageBreakdown.totalCapacityGb - storageBreakdown.freeStorageGb
  val usedPercent = ((usedGb / storageBreakdown.totalCapacityGb).coerceIn(0.0, 1.0)).toFloat()

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .testTag("storage_settings_screen"),
    contentPadding = PaddingValues(16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // 1. 64 GB Storage Overview Hero Card
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("storage_hero_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
      ) {
        Box(
          modifier = Modifier
            .background(
              Brush.linearGradient(
                colors = listOf(
                  Color(0xFF0F172A),
                  Color(0xFF1E293B),
                  Color(0xFF334155)
                )
              )
            )
            .padding(18.dp)
        ) {
          Column(modifier = Modifier.fillMaxWidth()) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(DopingPrimary.copy(alpha = 0.3f)),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(imageVector = Icons.Default.SdCard, contentDescription = null, tint = DopingPrimary, modifier = Modifier.size(24.dp))
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                  Text("DAHİLİ HAFIZA", color = DopingAmber, fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                  Text("64 GB Depolama Kapasitesi", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
              }

              Surface(
                color = DopingGreen.copy(alpha = 0.2f),
                shape = RoundedCornerShape(10.dp)
              ) {
                Text(
                  text = "Android 15 Optimize",
                  color = DopingGreen,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
              }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Gauge Bar
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = "Kullanılan: ${String.format("%.1f", storageBreakdown.totalCapacityGb - storageBreakdown.freeStorageGb)} GB",
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = "Boş Alan: ${String.format("%.1f", storageBreakdown.freeStorageGb)} GB",
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 12.sp
              )
            }

            Spacer(modifier = Modifier.height(8.dp))

            LinearProgressIndicator(
              progress = { usedPercent },
              modifier = Modifier
                .fillMaxWidth()
                .height(10.dp)
                .clip(RoundedCornerShape(5.dp)),
              color = DopingPrimary,
              trackColor = Color.White.copy(alpha = 0.2f)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Breakdown snippets
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              StorageMetric(label = "Doping Çevrimdışı", value = "${storageBreakdown.offlineLecturesMb} MB", color = DopingAmber)
              StorageMetric(label = "Soru Önbelleği", value = "${storageBreakdown.questionBankCacheMb} MB", color = DopingPrimary)
              StorageMetric(label = "Sistem & Diğer", value = "${storageBreakdown.systemAndAppsGb} GB", color = Color.LightGray)
            }
          }
        }
      }
    }

    // 2. Offline Content Management
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text("Çevrimdışı Konu & Video Hafıza", fontWeight = FontWeight.Bold, fontSize = 14.sp)
              Text(
                text = if (storageBreakdown.isAllOfflineDownloaded) "Tüm dersler 64 GB hafızaya indirildi (İnternetsiz çalışılabilir)" else "İnternetsiz ders çalışma paketini indir",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
              onClick = {
                onToggleOfflineDownload()
                val msg = if (!storageBreakdown.isAllOfflineDownloaded) "1.4 GB çevrimdışı hafıza paketi indirildi!" else "Çevrimdışı paket kaldırıldı."
                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
              },
              colors = ButtonDefaults.buttonColors(
                containerColor = if (storageBreakdown.isAllOfflineDownloaded) DopingGreen else DopingPrimary
              ),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.weight(1f).testTag("toggle_offline_download_btn")
            ) {
              Icon(
                imageVector = if (storageBreakdown.isAllOfflineDownloaded) Icons.Default.DownloadDone else Icons.Default.CloudDownload,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = if (storageBreakdown.isAllOfflineDownloaded) "İndirildi (Hazır)" else "Tümünü İndir",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
              )
            }

            OutlinedButton(
              onClick = {
                onClearCache()
                Toast.makeText(context, "Soru bankası önbelleği temizlendi!", Toast.LENGTH_SHORT).show()
              },
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.weight(0.9f).testTag("clear_cache_btn")
            ) {
              Icon(imageVector = Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Önbelleği Boşalt", fontSize = 11.sp)
            }
          }
        }
      }
    }

    // 3. Android 15 & Google Play Store Status
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(imageVector = Icons.Default.Android, contentDescription = null, tint = DopingGreen, modifier = Modifier.size(24.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text("Android 15 (Target SDK 36)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            Surface(
              color = DopingGreen.copy(alpha = 0.15f),
              shape = RoundedCornerShape(6.dp)
            ) {
              Text(
                text = "Maksimum Güncel",
                color = DopingGreen,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          Text(
            text = "Bu uygulama Android 15'in getirdiği en yeni sistem mimarisine, Edge-to-Edge tam ekran deneyimine, 120Hz ekran yenileme akıcılığına ve düşük pil tüketimi optimizasyonuna tam uyumludur.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )

          Spacer(modifier = Modifier.height(14.dp))

          // Play Store Box
          Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(12.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Shop, contentDescription = null, tint = DopingPrimary, modifier = Modifier.size(22.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                  Text("Google Play Store", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                  Text("Sürüm 2.5 (Play Creator Onaylı)", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
              }

              Button(
                onClick = {
                  Toast.makeText(context, "⭐⭐⭐⭐⭐ Play Store değerlendirmesi için teşekkürler!", Toast.LENGTH_SHORT).show()
                },
                colors = ButtonDefaults.buttonColors(containerColor = DopingPrimary),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
              ) {
                Icon(imageVector = Icons.Default.Star, contentDescription = null, tint = DopingAmber, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Puan Ver", fontSize = 11.sp, fontWeight = FontWeight.Bold)
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun StorageMetric(label: String, value: String, color: Color) {
  Column {
    Text(text = label, color = Color.White.copy(alpha = 0.7f), fontSize = 10.sp)
    Spacer(modifier = Modifier.height(2.dp))
    Text(text = value, color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold)
  }
}
