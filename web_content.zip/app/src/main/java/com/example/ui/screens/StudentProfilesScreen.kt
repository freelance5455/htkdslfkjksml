package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.HifzClass
import com.example.data.model.Student

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentProfilesScreen(
    isAdmin: Boolean,
    classes: List<HifzClass>,
    selectedClassId: String,
    students: List<Student>,
    toastMessage: String?,
    errorMessage: String?,
    onSelectClass: (String) -> Unit,
    onAddStudentProfile: (name: String, fatherName: String, guardianPhone: String, currentPara: String, notes: String) -> Unit,
    onUpdateStudentProfile: (studentId: String, name: String, fatherName: String, guardianPhone: String, currentPara: String, notes: String) -> Unit,
    onMoveStudent: (index: Int, delta: Int) -> Unit,
    onDeleteStudent: (studentId: String) -> Unit,
    onClearToast: () -> Unit,
    onClearError: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    val snackbarHostState = remember { SnackbarHostState() }
    var searchQuery by remember { mutableStateOf("") }
    var showFormDialog by remember { mutableStateOf(false) }
    var editingStudent by remember { mutableStateOf<Student?>(null) }
    var studentPendingDelete by remember { mutableStateOf<Student?>(null) }

    LaunchedEffect(toastMessage) {
        if (!toastMessage.isNullOrBlank()) {
            snackbarHostState.showSnackbar(toastMessage)
            onClearToast()
        }
    }

    LaunchedEffect(errorMessage) {
        if (!errorMessage.isNullOrBlank()) {
            snackbarHostState.showSnackbar(errorMessage)
            onClearError()
        }
    }

    val currentClassName = classes.firstOrNull { it.id == selectedClassId }?.name ?: selectedClassId
    val filteredStudents by remember(students, searchQuery) {
        derivedStateOf {
            val q = searchQuery.trim()
            if (q.isEmpty()) students
            else students.filter {
                it.name.contains(q, ignoreCase = true) ||
                    it.fatherName.contains(q, ignoreCase = true) ||
                    it.currentPara.contains(q, ignoreCase = true) ||
                    it.guardianPhone.contains(q, ignoreCase = true)
            }
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("طلبہ پروفائلز · Student Profiles")
                        if (currentClassName.isNotBlank()) {
                            Text(
                                text = "کلاس: $currentClassName (${students.size} طلبہ)",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("profiles_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to Daily Report"
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    editingStudent = null
                    showFormDialog = true
                },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("نیا طالب علم") },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("add_student_profile_fab")
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Class Switcher for Admin, or Class Scope Badge for Teachers
            if (isAdmin && classes.size > 1) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    classes.forEach { cls ->
                        FilterChip(
                            selected = cls.id == selectedClassId,
                            onClick = { onSelectClass(cls.id) },
                            label = { Text(cls.name) },
                            modifier = Modifier.testTag("profiles_class_chip_${cls.id}")
                        )
                    }
                }
            } else {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Group,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "آپ صرف اپنی کلاس ($currentClassName) کے طلبہ کے پروفائلز شامل، ترمیم اور حذف کر سکتے ہیں۔",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("نام، ولدیت، پارہ یا فون نمبر تلاش کریں…") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("profile_search_input")
            )

            if (filteredStudents.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.65f),
                            modifier = Modifier.size(56.dp)
                        )
                        Text(
                            text = if (students.isEmpty()) {
                                "اس کلاس میں ابھی کوئی طالب علم شامل نہیں ہے۔"
                            } else {
                                "تلاش کے مطابق کوئی طالب علم نہیں ملا۔"
                            },
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "نیا طالب علم شامل کرنے کے لیے نیچے \"+ نیا طالب علم\" بٹن دبائیں۔",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentPadding = PaddingValues(bottom = 88.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    itemsIndexed(
                        items = filteredStudents,
                        key = { _, stu -> stu.id }
                    ) { visibleIdx, student ->
                        val actualIdx = students.indexOfFirst { it.id == student.id }
                        val canReorder = searchQuery.isBlank() && actualIdx >= 0
                        StudentProfileCard(
                            orderNumber = if (actualIdx >= 0) actualIdx + 1 else visibleIdx + 1,
                            student = student,
                            canMoveUp = canReorder && actualIdx > 0,
                            canMoveDown = canReorder && actualIdx < students.lastIndex,
                            onMoveUp = { if (canReorder) onMoveStudent(actualIdx, -1) },
                            onMoveDown = { if (canReorder) onMoveStudent(actualIdx, +1) },
                            onEdit = {
                                editingStudent = student
                                showFormDialog = true
                            },
                            onDelete = { studentPendingDelete = student }
                        )
                    }
                }
            }
        }
    }

    if (showFormDialog) {
        StudentProfileFormDialog(
            existing = editingStudent,
            onDismiss = {
                showFormDialog = false
                editingStudent = null
            },
            onSave = { name, fatherName, guardianPhone, currentPara, notes ->
                val target = editingStudent
                if (target == null) {
                    onAddStudentProfile(name, fatherName, guardianPhone, currentPara, notes)
                } else {
                    onUpdateStudentProfile(target.id, name, fatherName, guardianPhone, currentPara, notes)
                }
                showFormDialog = false
                editingStudent = null
            }
        )
    }

    val deleteTarget = studentPendingDelete
    if (deleteTarget != null) {
        AlertDialog(
            onDismissRequest = { studentPendingDelete = null },
            title = { Text("طالب علم حذف کریں؟") },
            text = {
                Text("کیا آپ واقعی \"${deleteTarget.name}\" کا پروفائل اس کلاس سے حذف کرنا چاہتے ہیں؟")
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteStudent(deleteTarget.id)
                        studentPendingDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError
                    ),
                    modifier = Modifier.testTag("confirm_delete_student_button")
                ) {
                    Text("حذف کریں")
                }
            },
            dismissButton = {
                TextButton(onClick = { studentPendingDelete = null }) {
                    Text("منسوخ کریں")
                }
            }
        )
    }
}

@Composable
private fun StudentProfileCard(
    orderNumber: Int,
    student: Student,
    canMoveUp: Boolean,
    canMoveDown: Boolean,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("student_profile_card_${student.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = orderNumber.toString(),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = student.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (student.fatherName.isNotBlank()) {
                        Text(
                            text = "ولدیت: ${student.fatherName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                if (student.currentPara.isNotBlank()) {
                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        shape = MaterialTheme.shapes.small
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Book,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp),
                                tint = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                            Text(
                                text = "پارہ ${student.currentPara}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                    }
                }
            }

            if (student.guardianPhone.isNotBlank() || student.notes.isNotBlank()) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (student.guardianPhone.isNotBlank()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Phone,
                                contentDescription = null,
                                modifier = Modifier.size(15.dp),
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = student.guardianPhone,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    if (student.notes.isNotBlank()) {
                        Text(
                            text = student.notes,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onMoveUp,
                    enabled = canMoveUp,
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(Icons.Default.ArrowUpward, contentDescription = "Move Up")
                }
                IconButton(
                    onClick = onMoveDown,
                    enabled = canMoveDown,
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(Icons.Default.ArrowDownward, contentDescription = "Move Down")
                }
                Spacer(Modifier.width(4.dp))
                IconButton(
                    onClick = onEdit,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("edit_student_button_${student.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Edit Student Profile",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("delete_student_button_${student.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete Student Profile",
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    }
}

@Composable
private fun StudentProfileFormDialog(
    existing: Student?,
    onDismiss: () -> Unit,
    onSave: (name: String, fatherName: String, guardianPhone: String, currentPara: String, notes: String) -> Unit
) {
    var name by remember(existing) { mutableStateOf(existing?.name ?: "") }
    var fatherName by remember(existing) { mutableStateOf(existing?.fatherName ?: "") }
    var guardianPhone by remember(existing) { mutableStateOf(existing?.guardianPhone ?: "") }
    var currentPara by remember(existing) { mutableStateOf(existing?.currentPara ?: "") }
    var notes by remember(existing) { mutableStateOf(existing?.notes ?: "") }
    var nameError by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (existing == null) "نیا طالب علم شامل کریں"
                else "طالب علم کا پروفائل تبدیل کریں"
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        if (it.length <= 100) {
                            name = it
                            nameError = null
                        }
                    },
                    label = { Text("طالب علم کا نام *") },
                    isError = nameError != null,
                    supportingText = nameError?.let { err -> { Text(err) } },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("student_name_input")
                )
                OutlinedTextField(
                    value = fatherName,
                    onValueChange = { if (it.length <= 100) fatherName = it },
                    label = { Text("ولدیت / Father's Name") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("student_father_name_input")
                )
                OutlinedTextField(
                    value = currentPara,
                    onValueChange = { if (it.length <= 20) currentPara = it },
                    label = { Text("موجودہ پارہ / Current Para") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("student_para_input")
                )
                OutlinedTextField(
                    value = guardianPhone,
                    onValueChange = { if (it.length <= 30) guardianPhone = it },
                    label = { Text("والد / سرپرست کا فون نمبر") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("student_phone_input")
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { if (it.length <= 300) notes = it },
                    label = { Text("نوٹ / کیفیت") },
                    minLines = 2,
                    maxLines = 4,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("student_notes_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val clean = name.trim()
                    if (clean.isEmpty()) {
                        nameError = "نام درج کرنا ضروری ہے"
                    } else {
                        onSave(
                            clean,
                            fatherName.trim(),
                            guardianPhone.trim(),
                            currentPara.trim(),
                            notes.trim()
                        )
                    }
                },
                modifier = Modifier.testTag("save_student_profile_button")
            ) {
                Text("محفوظ کریں")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("منسوخ کریں")
            }
        }
    )
}
