package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AdminConfig
import com.example.ui.ChaufalandViewModel
import com.example.ui.components.MinecraftButton
import com.example.ui.components.MinecraftCard
import com.example.ui.theme.MinecraftBorder
import com.example.ui.theme.MinecraftDiamond
import com.example.ui.theme.MinecraftEmerald
import com.example.ui.theme.MinecraftGold
import com.example.ui.theme.MinecraftGrass
import com.example.ui.theme.MinecraftRedstone
import com.example.ui.theme.MinecraftSurfaceVariant
import com.example.ui.theme.MinecraftText
import com.example.ui.theme.MinecraftTextDim

@Composable
fun AdminScreen(viewModel: ChaufalandViewModel, modifier: Modifier = Modifier) {
  val isUnlocked by viewModel.isAdminUnlocked.collectAsState()
  val adminConfig by viewModel.adminConfig.collectAsState()
  val passwordInput by viewModel.adminPasswordInput.collectAsState()

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .padding(12.dp),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    if (!isUnlocked) {
      item {
        MinecraftCard(borderColor = MinecraftRedstone) {
          Column(modifier = Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(text = "🛡️", fontSize = 24.sp)
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "ACCESO RESTRINGIDO - PANEL ADMIN",
                color = MinecraftRedstone,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
              )
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
              text = "Ingresa la clave secreta de creador de CHAUFALAND para desbloquear:",
              color = MinecraftTextDim,
              fontSize = 11.sp,
              fontFamily = FontFamily.Monospace
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
              value = passwordInput,
              onValueChange = { viewModel.setAdminPasswordInput(it) },
              placeholder = { Text("Clave secreta...", color = MinecraftTextDim) },
              visualTransformation = PasswordVisualTransformation(),
              singleLine = true,
              colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color(0xFF140F0C),
                unfocusedContainerColor = Color(0xFF140F0C),
                focusedBorderColor = MinecraftGold,
                unfocusedBorderColor = MinecraftBorder,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
              ),
              modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            MinecraftButton(
              text = "DESBLOQUEAR PANEL 🔑",
              containerColor = MinecraftGold,
              contentColor = Color.Black,
              onClick = { viewModel.submitAdminLogin() },
              modifier = Modifier.fillMaxWidth(),
              testTag = "btn_admin_unlock"
            )
          }
        }
      }
    } else {
      item {
        AdminConfigForm(
          config = adminConfig,
          onSave = { updated -> viewModel.updateAdminConfig(updated) },
          onLock = { viewModel.lockAdmin() }
        )
      }
    }
  }
}

@Composable
private fun AdminConfigForm(
  config: AdminConfig,
  onSave: (AdminConfig) -> Unit,
  onLock: () -> Unit
) {
  var serverType by remember(config) { mutableStateOf(config.serverType) }
  var exarotonToken by remember(config) { mutableStateOf(config.exarotonToken) }
  var exarotonServerId by remember(config) { mutableStateOf(config.exarotonServerId) }
  var secondaryIp by remember(config) { mutableStateOf(config.secondaryServerIp) }
  var wsBridgeUrl by remember(config) { mutableStateOf(config.wsBridgeUrl) }

  MinecraftCard(borderColor = MinecraftEmerald) {
    Column(modifier = Modifier.fillMaxWidth()) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "⚙️ CONFIGURACIÓN DEL SERVIDOR",
          color = MinecraftGold,
          fontSize = 14.sp,
          fontWeight = FontWeight.Bold,
          fontFamily = FontFamily.Monospace
        )
        MinecraftButton(
          text = "🔒 Bloquear",
          containerColor = Color(0xFF4A1A1A),
          onClick = onLock,
          modifier = Modifier.height(30.dp)
        )
      }

      Spacer(modifier = Modifier.height(14.dp))

      // SELECTOR DE SERVIDOR
      Text(
        text = "SERVIDOR ACTIVO:",
        color = MinecraftDiamond,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        fontFamily = FontFamily.Monospace
      )
      Spacer(modifier = Modifier.height(6.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        val isExaroton = serverType == "exaroton"
        MinecraftButton(
          text = "EXAROTON (API + WS)",
          containerColor = if (isExaroton) MinecraftEmerald else MinecraftSurfaceVariant,
          onClick = { serverType = "exaroton" },
          modifier = Modifier.weight(1f)
        )
        MinecraftButton(
          text = "ATERNOS / SRV",
          containerColor = if (!isExaroton) MinecraftEmerald else MinecraftSurfaceVariant,
          onClick = { serverType = "aternos" },
          modifier = Modifier.weight(1f)
        )
      }

      Spacer(modifier = Modifier.height(14.dp))

      // CAMPOS EXAROTON
      Text(
        text = "EXAROTON API TOKEN:",
        color = MinecraftEmerald,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        fontFamily = FontFamily.Monospace
      )
      Spacer(modifier = Modifier.height(4.dp))
      OutlinedTextField(
        value = exarotonToken,
        onValueChange = { exarotonToken = it },
        placeholder = { Text("Token de api.exaroton.com", color = MinecraftTextDim) },
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
          focusedContainerColor = Color(0xFF140F0C),
          unfocusedContainerColor = Color(0xFF140F0C),
          focusedBorderColor = MinecraftEmerald,
          unfocusedBorderColor = MinecraftBorder,
          focusedTextColor = Color.White,
          unfocusedTextColor = Color.White
        ),
        modifier = Modifier.fillMaxWidth()
      )

      Spacer(modifier = Modifier.height(10.dp))

      Text(
        text = "EXAROTON SERVER ID:",
        color = MinecraftEmerald,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        fontFamily = FontFamily.Monospace
      )
      Spacer(modifier = Modifier.height(4.dp))
      OutlinedTextField(
        value = exarotonServerId,
        onValueChange = { exarotonServerId = it },
        placeholder = { Text("Ej: abc123def456", color = MinecraftTextDim) },
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
          focusedContainerColor = Color(0xFF140F0C),
          unfocusedContainerColor = Color(0xFF140F0C),
          focusedBorderColor = MinecraftEmerald,
          unfocusedBorderColor = MinecraftBorder,
          focusedTextColor = Color.White,
          unfocusedTextColor = Color.White
        ),
        modifier = Modifier.fillMaxWidth()
      )

      Spacer(modifier = Modifier.height(14.dp))

      // IP ATERNOS / SECUNDARIO
      Text(
        text = "IP SERVIDOR ATERNOS / SECUNDARIO:",
        color = MinecraftGold,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        fontFamily = FontFamily.Monospace
      )
      Spacer(modifier = Modifier.height(4.dp))
      OutlinedTextField(
        value = secondaryIp,
        onValueChange = { secondaryIp = it },
        placeholder = { Text("Ej: chaufaland.aternos.me:19132", color = MinecraftTextDim) },
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
          focusedContainerColor = Color(0xFF140F0C),
          unfocusedContainerColor = Color(0xFF140F0C),
          focusedBorderColor = MinecraftGold,
          unfocusedBorderColor = MinecraftBorder,
          focusedTextColor = Color.White,
          unfocusedTextColor = Color.White
        ),
        modifier = Modifier.fillMaxWidth()
      )

      Spacer(modifier = Modifier.height(14.dp))

      // WEBSOCKET BRIDGE
      Text(
        text = "URL PUENTE WEBSOCKET BEDROCK:",
        color = MinecraftDiamond,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        fontFamily = FontFamily.Monospace
      )
      Spacer(modifier = Modifier.height(4.dp))
      OutlinedTextField(
        value = wsBridgeUrl,
        onValueChange = { wsBridgeUrl = it },
        placeholder = { Text("ws://10.0.2.2:3000/ws/minecraft", color = MinecraftTextDim) },
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
          focusedContainerColor = Color(0xFF140F0C),
          unfocusedContainerColor = Color(0xFF140F0C),
          focusedBorderColor = MinecraftDiamond,
          unfocusedBorderColor = MinecraftBorder,
          focusedTextColor = Color.White,
          unfocusedTextColor = Color.White
        ),
        modifier = Modifier.fillMaxWidth()
      )

      Spacer(modifier = Modifier.height(18.dp))

      MinecraftButton(
        text = "GUARDAR CONFIGURACIÓN 💾",
        containerColor = MinecraftGrass,
        onClick = {
          onSave(
            config.copy(
              serverType = serverType,
              exarotonToken = exarotonToken,
              exarotonServerId = exarotonServerId,
              secondaryServerIp = secondaryIp,
              wsBridgeUrl = wsBridgeUrl
            )
          )
        },
        modifier = Modifier.fillMaxWidth(),
        testTag = "btn_save_admin_config"
      )
    }
  }
}
