package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.PostAdd
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.MemberEntity
import com.example.ui.MainViewModel
import com.example.ui.theme.TextHint
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AdminScreen(
    viewModel: MainViewModel,
    onOpenAddCommitteeMember: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val isAdminLoggedIn by viewModel.isAdminLoggedIn.collectAsState()

    if (!isAdminLoggedIn) {
        // Password Verification Gate Screen
        AdminPasswordGateScreen(
            onUnlock = { pin -> viewModel.verifyAdminPassword(pin) }
        )
    } else {
        // Full Admin Dashboard Screen with Pull-to-Refresh
        AdminDashboardContent(
            viewModel = viewModel,
            onOpenAddCommitteeMember = onOpenAddCommitteeMember,
            modifier = modifier
        )
    }
}

/**
 * Password verification screen requiring administrative credentials before viewing database entries.
 */
@Composable
fun AdminPasswordGateScreen(
    onUnlock: (String) -> Boolean,
    modifier: Modifier = Modifier
) {
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF3F4F6))
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .clip(RoundedCornerShape(22.dp)),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Security Icon
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFDCFCE7))
                        .border(2.dp, Color(0xFF16A34A), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = "Admin Security",
                        tint = Color(0xFF15803D),
                        modifier = Modifier.size(36.dp)
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "এডমিন ড্যাশবোর্ড সিকিউরিটি",
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "সংরক্ষিত ডাটা প্রদর্শন, অনুসন্ধান এবং মুছে ফেলার জন্য এডমিন পাসওয়ার্ড প্রবেশ করান",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = TextSecondary,
                        textAlign = TextAlign.Center,
                        lineHeight = 17.sp
                    )
                }

                // Password Input Field
                OutlinedTextField(
                    value = password,
                    onValueChange = {
                        password = it
                        errorMessage = null
                    },
                    label = { Text("এডমিন পাসওয়ার্ড", fontWeight = FontWeight.SemiBold, color = TextSecondary) },
                    placeholder = { Text("পাসওয়ার্ড লিখুন", color = TextHint) },
                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.NumberPassword,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(onDone = {
                        val ok = onUnlock(password)
                        if (!ok) {
                            errorMessage = "ভুল পাসওয়ার্ড! অনুগ্রহ করে আবার চেষ্টা করুন।"
                        }
                    }),
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = "Toggle visibility",
                                tint = TextSecondary
                            )
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = Color(0xFF15803D),
                        unfocusedBorderColor = Color(0xFF6B7280),
                        focusedContainerColor = Color(0xFFF9FAFB),
                        unfocusedContainerColor = Color(0xFFF9FAFB)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_gate_password_input")
                )

                // Error Message if failed
                if (errorMessage != null) {
                    Text(
                        text = errorMessage.orEmpty(),
                        color = Color(0xFFDC2626),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center
                    )
                }

                // Unlock Submit Button
                Button(
                    onClick = {
                        val ok = onUnlock(password)
                        if (!ok) {
                            errorMessage = "ভুল পাসওয়ার্ড! অনুগ্রহ করে আবার চেষ্টা করুন।"
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("admin_gate_unlock_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.LockOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                        Text("ড্যাশবোর্ড আনলক করুন", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // Security Notice
                Surface(
                    color = Color(0xFFF0FDF4),
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBBF7D0))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = Color(0xFF15803D), modifier = Modifier.size(14.dp))
                        Text(
                            text = "শুধুমাত্র অনুমোদিত এডমিনদের জন্য সংরক্ষিত",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF15803D)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Authenticated Admin Dashboard:
 * - Pull-to-refresh to sync with Room Database & ensure fresh entries
 * - Stat counters
 * - Live search
 * - Filter by type (All, Committee, Worker)
 * - List view with phone call, Facebook launch, and entry deletion
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardContent(
    viewModel: MainViewModel,
    onOpenAddCommitteeMember: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val allMembers by viewModel.allMembers.collectAsState()
    val filteredRecords by viewModel.filteredRecords.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val currentFilter by viewModel.currentTypeFilter.collectAsState()
    val webhookUrl by viewModel.webhookUrl.collectAsState()
    val isSyncing by viewModel.isSyncing.collectAsState()
    val isRefreshing by viewModel.isRefreshing.collectAsState()

    var showSheetPanel by remember { mutableStateOf(false) }
    var webhookInput by remember(webhookUrl) { mutableStateOf(webhookUrl) }

    var recordToDelete by remember { mutableStateOf<MemberEntity?>(null) }
    var showChangePinDialog by remember { mutableStateOf(false) }
    var newPinText by remember { mutableStateOf("") }
    var newPinVisible by remember { mutableStateOf(false) }
    var showResetConfirmDialog by remember { mutableStateOf(false) }
    var showExportDialog by remember { mutableStateOf(false) }
    var exportScope by remember { mutableStateOf("all") }
    var pendingCsvContent by remember { mutableStateOf("") }

    val createDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/csv")
    ) { uri: Uri? ->
        uri?.let { targetUri ->
            try {
                context.contentResolver.openOutputStream(targetUri)?.use { stream ->
                    stream.write(pendingCsvContent.toByteArray(Charsets.UTF_8))
                }
                viewModel.showAlert("CSV ফাইল সফলভাবে ডিভাইসে সংরক্ষিত হয়েছে!", "success")
            } catch (e: Exception) {
                viewModel.showAlert("ফাইল সংরক্ষণ ব্যর্থ হয়েছে: ${e.message}", "danger")
            }
        }
    }

    val leaderCount = allMembers.count { it.type == "leader" }
    val workerCount = allMembers.count { it.type == "worker" }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF3F4F6))
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. Dashboard Top Header & Counters Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                // Title and Actions Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(imageVector = Icons.Default.Dashboard, contentDescription = null, tint = Color(0xFF15803D), modifier = Modifier.size(20.dp))
                        Text(
                            text = "এডমিন ড্যাশবোর্ড",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        // Google Sheet button
                        Button(
                            onClick = { showSheetPanel = !showSheetPanel },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEFF6FF)),
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBFDBFE)),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(imageVector = Icons.Default.TableChart, contentDescription = null, tint = Color(0xFF1D4ED8), modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text("গুগল শিট", fontSize = 11.sp, color = Color(0xFF1D4ED8), fontWeight = FontWeight.Bold)
                        }

                        // Logout button
                        Button(
                            onClick = { viewModel.logoutAdmin() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFEE2E2)),
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFECACA)),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.testTag("admin_logout_button")
                        ) {
                            Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = Color(0xFFB91C1C), modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text("লক করুন", fontSize = 11.sp, color = Color(0xFFB91C1C), fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Stats Counters Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFFF0FDF4))
                            .border(1.dp, Color(0xFFBBF7D0), RoundedCornerShape(10.dp))
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("মোট ডাটা", fontSize = 11.sp, color = Color(0xFF14532D), fontWeight = FontWeight.Bold)
                            Text("${allMembers.size}", fontSize = 16.sp, color = Color(0xFF15803D), fontWeight = FontWeight.Bold)
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFFEFF6FF))
                            .border(1.dp, Color(0xFFBFDBFE), RoundedCornerShape(10.dp))
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("দায়িত্বপ্রাপ্ত নেতা", fontSize = 11.sp, color = Color(0xFF1E3A8A), fontWeight = FontWeight.Bold)
                            Text("$leaderCount", fontSize = 16.sp, color = Color(0xFF1D4ED8), fontWeight = FontWeight.Bold)
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFFFAF5FF))
                            .border(1.dp, Color(0xFFE9D5FF), RoundedCornerShape(10.dp))
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("সাধারণ কর্মী", fontSize = 11.sp, color = Color(0xFF581C87), fontWeight = FontWeight.Bold)
                            Text("$workerCount", fontSize = 16.sp, color = Color(0xFF7E22CE), fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Google Sheet Configuration Panel (Collapsible)
                AnimatedVisibility(visible = showSheetPanel) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 10.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFEFF6FF))
                            .border(1.dp, Color(0xFFBFDBFE), RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Icon(imageVector = Icons.Default.Link, contentDescription = null, tint = Color(0xFF1E3A8A), modifier = Modifier.size(14.dp))
                                    Text("Google Web App Webhook URL:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E3A8A))
                                }
                                Surface(color = Color(0xFFBFDBFE), shape = RoundedCornerShape(4.dp)) {
                                    Text("Apps Script", fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = Color(0xFF1E40AF), modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                }
                            }

                            OutlinedTextField(
                                value = webhookInput,
                                onValueChange = { webhookInput = it },
                                placeholder = { Text("https://script.google.com/macros/s/.../exec", color = TextHint) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary,
                                    focusedContainerColor = Color.White,
                                    unfocusedContainerColor = Color.White
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("ডাটা সাবমিট হলে স্বয়ংক্রিয়ভাবে শিটে যাবে।", fontSize = 11.sp, color = TextMuted, fontWeight = FontWeight.Medium)

                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Button(
                                        onClick = { viewModel.testWebhook(webhookInput) },
                                        enabled = !isSyncing && webhookInput.isNotBlank(),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B82F6)),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text("টেস্ট", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                    }

                                    Button(
                                        onClick = {
                                            viewModel.saveWebhookUrl(webhookInput)
                                            showSheetPanel = false
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1D4ED8)),
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Text("সেভ করুন", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 1.5. Quick Action: Add Committee Member to Firestore
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onOpenAddCommitteeMember() }
                .testTag("open_add_committee_member_card"),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFDCFCE7)),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF86EFAC))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF15803D)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PostAdd,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "নতুন কমিটি সদস্য এন্ট্রি (Firestore)",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF14532D)
                        )
                        Text(
                            text = "নাম, পদবী, মোবাইল ও ওয়ার্ড নম্বর সহ ক্লাউড ফায়ারস্টোরে যুক্ত করুন",
                            fontSize = 11.sp,
                            color = Color(0xFF166534)
                        )
                    }
                }
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = null,
                    tint = Color(0xFF15803D),
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        // 2. Search & Filter Bar
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                // Search Input
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.searchQuery.value = it },
                    placeholder = { Text("ইউনিয়ন, ওয়ার্ড বা নাম দিয়ে খুঁজুন...", fontSize = 13.sp, color = TextHint, fontWeight = FontWeight.Medium) },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = TextSecondary, modifier = Modifier.size(18.dp))
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.searchQuery.value = "" }) {
                                Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear", tint = TextPrimary, modifier = Modifier.size(16.dp))
                            }
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedContainerColor = Color(0xFFF9FAFB),
                        unfocusedContainerColor = Color(0xFFF9FAFB),
                        focusedBorderColor = Color(0xFF15803D),
                        unfocusedBorderColor = Color(0xFFD1D5DB)
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_search_input")
                )

                // Filter Buttons Row (all, leader, worker)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val isAll = currentFilter == "all"
                    val isLeader = currentFilter == "leader"
                    val isWorker = currentFilter == "worker"

                    Button(
                        onClick = { viewModel.currentTypeFilter.value = "all" },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isAll) Color(0xFF15803D) else Color(0xFFE5E7EB)
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 5.dp)
                    ) {
                        Text(
                            text = "সব দেখাও",
                            fontSize = 12.sp,
                            color = if (isAll) Color.White else TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = { viewModel.currentTypeFilter.value = "leader" },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isLeader) Color(0xFF15803D) else Color(0xFFE5E7EB)
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 5.dp)
                    ) {
                        Text(
                            text = "দায়িত্বপ্রাপ্ত নেতা",
                            fontSize = 12.sp,
                            color = if (isLeader) Color.White else TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = { viewModel.currentTypeFilter.value = "worker" },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isWorker) Color(0xFF7E22CE) else Color(0xFFE5E7EB)
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 5.dp)
                    ) {
                        Text(
                            text = "সাধারণ কর্মী",
                            fontSize = 12.sp,
                            color = if (isWorker) Color.White else TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Secondary Utilities (Refresh Button, Export CSV, Change Password)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            OutlinedButton(
                onClick = { viewModel.refreshData() },
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 4.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF15803D))
            ) {
                Icon(imageVector = Icons.Default.Refresh, contentDescription = "Refresh", modifier = Modifier.size(15.dp))
                Spacer(modifier = Modifier.width(3.dp))
                Text("রিফ্রেশ", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
                onClick = { showExportDialog = true },
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .weight(1.1f)
                    .testTag("admin_export_csv_button"),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 4.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF15803D))
            ) {
                Icon(imageVector = Icons.Default.CloudDownload, contentDescription = null, tint = Color(0xFF15803D), modifier = Modifier.size(15.dp))
                Spacer(modifier = Modifier.width(3.dp))
                Text("CSV এক্সপোর্ট", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF15803D))
            }

            OutlinedButton(
                onClick = { showChangePinDialog = true },
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 4.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary)
            ) {
                Icon(imageVector = Icons.Default.Key, contentDescription = null, tint = TextPrimary, modifier = Modifier.size(15.dp))
                Spacer(modifier = Modifier.width(3.dp))
                Text("পাসওয়ার্ড", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            }
        }

        // 3. Entries List View with Pull-To-Refresh
        PullToRefreshBox(
            isRefreshing = isRefreshing,
            onRefresh = { viewModel.refreshData() },
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .testTag("admin_pull_to_refresh_box")
        ) {
            if (filteredRecords.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = TextSecondary,
                            modifier = Modifier.size(40.dp)
                        )
                        Text(
                            text = "কোনো তথ্য সংরক্ষিত নেই",
                            color = TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "নিচে টেনে রিফ্রেশ করুন অথবা নমুনা ডাটা লোড করুন",
                            color = TextSecondary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            textAlign = TextAlign.Center
                        )
                        Button(
                            onClick = { viewModel.loadSampleData() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(imageVector = Icons.Default.PostAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("নমুনা তথ্য লোড করুন")
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredRecords, key = { it.id }) { item ->
                        DashboardEntryCard(
                            item = item,
                            onDelete = { recordToDelete = item },
                            onCall = { phone -> dialPhone(context, phone) },
                            onOpenFb = { url -> openFacebook(context, url) }
                        )
                    }

                    item {
                        Spacer(modifier = Modifier.height(6.dp))
                        Button(
                            onClick = { showResetConfirmDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.DeleteSweep, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("সকল ডাটা রিসেট করুন")
                        }
                        Spacer(modifier = Modifier.height(20.dp))
                    }
                }
            }
        }
    }

    // Delete Record Confirmation Dialog
    if (recordToDelete != null) {
        val r = recordToDelete!!
        val leaderLoc = if (r.ward.isNotBlank() && r.ward != "উল্লেখ নেই") "${r.union} (${r.ward})" else r.union
        val nameToShow = if (r.type == "leader") {
            val leaderTitle = when {
                r.sovapotiName.isNotBlank() && r.sovapotiName != "উল্লেখ নেই" -> "সভাপতি: ${r.sovapotiName}"
                r.secretaryName.isNotBlank() && r.secretaryName != "উল্লেখ নেই" -> "সম্পাদক: ${r.secretaryName}"
                r.otherName.isNotBlank() && r.otherName != "উল্লেখ নেই" -> "${r.otherDesignation}: ${r.otherName}"
                else -> "কমিটি"
            }
            "$leaderLoc ($leaderTitle)"
        } else "${r.workerName} (${r.workerDesignation})"
        AlertDialog(
            onDismissRequest = { recordToDelete = null },
            title = { Text("মুছে ফেলতে চান?", fontWeight = FontWeight.Bold) },
            text = { Text("\"$nameToShow\" এর তথ্য ডাটাবেজ থেকে স্থায়ীভাবে মুছে ফেলা হবে। আপনি কি নিশ্চিত?") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteRecord(r)
                        recordToDelete = null
                        Toast.makeText(context, "তথ্যটি সফলভাবে মুছে ফেলা হয়েছে!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                    modifier = Modifier.testTag("confirm_delete_button")
                ) {
                    Text("হ্যাঁ, মুছুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { recordToDelete = null }) {
                    Text("বাতিল")
                }
            }
        )
    }

    // Change Password Dialog
    if (showChangePinDialog) {
        AlertDialog(
            onDismissRequest = {
                showChangePinDialog = false
                newPinText = ""
                newPinVisible = false
            },
            title = { Text("নতুন এডমিন পাসওয়ার্ড", fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = newPinText,
                    onValueChange = { if (it.length <= 16) newPinText = it },
                    label = { Text("নতুন গোপন পাসওয়ার্ড") },
                    placeholder = { Text("গোপন পাসওয়ার্ড লিখুন") },
                    visualTransformation = if (newPinVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    trailingIcon = {
                        IconButton(onClick = { newPinVisible = !newPinVisible }) {
                            Icon(
                                imageVector = if (newPinVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = "পাসওয়ার্ড প্রদর্শন/গোপন",
                                tint = TextSecondary
                            )
                        }
                    },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newPinText.isNotBlank()) {
                            viewModel.changeAdminPin(newPinText)
                            newPinText = ""
                            newPinVisible = false
                            showChangePinDialog = false
                            Toast.makeText(context, "পাসওয়ার্ড সফলভাবে পরিবর্তিত হয়েছে!", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D))
                ) {
                    Text("সংরক্ষণ")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showChangePinDialog = false
                    newPinText = ""
                    newPinVisible = false
                }) {
                    Text("বাতিল")
                }
            }
        )
    }

    // Reset Confirm Dialog
    if (showResetConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showResetConfirmDialog = false },
            title = { Text("সব ডাটা মুছে ফেলতে চান?", fontWeight = FontWeight.Bold) },
            text = { Text("ডাটাবেজে সংরক্ষিত সকল কমিটি ও কর্মীদের তালিকা স্থায়ীভাবে মুছে যাবে।") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearAllData()
                        showResetConfirmDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("হ্যাঁ, সব মুছুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirmDialog = false }) {
                    Text("বাতিল")
                }
            }
        )
    }

    // CSV Export Dialog
    if (showExportDialog) {
        val totalCount = allMembers.size
        val filteredCount = filteredRecords.size
        val targetMembers = if (exportScope == "filtered") filteredRecords else allMembers

        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.CloudDownload,
                    contentDescription = null,
                    tint = Color(0xFF15803D),
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text(
                    text = "CSV ডাটা এক্সপোর্ট",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = TextPrimary
                )
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "এক্সেল বা গুগল শিটে রিপোর্ট প্রস্তুত করার জন্য ডাটা এক্সপোর্ট করুন। UTF-8 BOM যুক্ত থাকায় বাংলা ফন্ট সরাসরি সঠিকভাবে প্রদর্শিত হবে।",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        lineHeight = 17.sp
                    )

                    Text(
                        text = "কোন তালিকা এক্সপোর্ট করবেন?",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = TextPrimary
                    )

                    // Option 1: All Records
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { exportScope = "all" },
                        color = if (exportScope == "all") Color(0xFFF0FDF4) else Color(0xFFF9FAFB),
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (exportScope == "all") Color(0xFF15803D) else Color(0xFFE5E7EB)
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            RadioButton(
                                selected = (exportScope == "all"),
                                onClick = null,
                                colors = RadioButtonDefaults.colors(
                                    selectedColor = Color(0xFF15803D),
                                    unselectedColor = TextMuted
                                )
                            )
                            Column {
                                Text(
                                    text = "সকল ডাটা ($totalCount টি)",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "ডাটাবেজের সকল নেতা ও কর্মীর পূর্ণাঙ্গ তালিকা",
                                    fontSize = 11.sp,
                                    color = TextSecondary
                                )
                            }
                        }
                    }

                    // Option 2: Filtered Records
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { exportScope = "filtered" },
                        color = if (exportScope == "filtered") Color(0xFFF0FDF4) else Color(0xFFF9FAFB),
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (exportScope == "filtered") Color(0xFF15803D) else Color(0xFFE5E7EB)
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            RadioButton(
                                selected = (exportScope == "filtered"),
                                onClick = null,
                                colors = RadioButtonDefaults.colors(
                                    selectedColor = Color(0xFF15803D),
                                    unselectedColor = TextMuted
                                )
                            )
                            Column {
                                Text(
                                    text = "ফিল্টারকৃত তালিকা ($filteredCount টি)",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "বর্তমান ফিল্টার বা সার্চ অনুযায়ী নির্বাচিত তালিকা",
                                    fontSize = 11.sp,
                                    color = TextSecondary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Action buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Save to device
                        Button(
                            onClick = {
                                if (targetMembers.isEmpty()) {
                                    Toast.makeText(context, "এক্সপোর্ট করার মতো কোনো ডাটা নেই!", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                val csv = if (exportScope == "filtered") viewModel.getFilteredCsvContent() else viewModel.getCsvContent()
                                pendingCsvContent = csv
                                showExportDialog = false
                                val dateStr = SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(Date())
                                createDocumentLauncher.launch("Charghat_BSL_Members_${dateStr}.csv")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("export_save_device_button"),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 10.dp)
                        ) {
                            Icon(imageVector = Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("ডিভাইসে সেভ", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        // Share via Apps
                        Button(
                            onClick = {
                                if (targetMembers.isEmpty()) {
                                    Toast.makeText(context, "এক্সপোর্ট করার মতো কোনো ডাটা নেই!", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                val csv = if (exportScope == "filtered") viewModel.getFilteredCsvContent() else viewModel.getCsvContent()
                                showExportDialog = false
                                shareCsvFile(context, csv)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1D4ED8)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("export_share_button"),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 10.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("শেয়ার করুন", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(
                    onClick = { showExportDialog = false },
                    modifier = Modifier.testTag("export_dialog_cancel_button")
                ) {
                    Text("বন্ধ করুন", color = TextSecondary, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

/**
 * Individual entry card in the Admin Dashboard list view.
 */
@Composable
fun DashboardEntryCard(
    item: MemberEntity,
    onDelete: () -> Unit,
    onCall: (String) -> Unit,
    onOpenFb: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val isLeader = item.type == "leader"

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFFE5E7EB), RoundedCornerShape(14.dp)),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF9FAFB)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Header Row: Title + Type Badge + Delete Action
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val leaderLoc = if (item.ward.isNotBlank() && item.ward != "উল্লেখ নেই") "${item.union} (${item.ward})" else item.union
                val cardTitle = if (isLeader) {
                    val primaryRole = when {
                        item.sovapotiName.isNotBlank() && item.sovapotiName != "উল্লেখ নেই" -> " (সভাপতি: ${item.sovapotiName})"
                        item.secretaryName.isNotBlank() && item.secretaryName != "উল্লেখ নেই" -> " (সম্পাদক: ${item.secretaryName})"
                        item.otherName.isNotBlank() && item.otherName != "উল্লেখ নেই" -> " (${item.otherDesignation}: ${item.otherName})"
                        else -> ""
                    }
                    "$leaderLoc$primaryRole"
                } else {
                    "${item.workerName} (${item.workerDesignation})"
                }
                Text(
                    text = cardTitle,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isLeader) Color(0xFF15803D) else Color(0xFF7E22CE),
                    modifier = Modifier.weight(1f)
                )

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Surface(
                        color = if (isLeader) Color(0xFFDCFCE7) else Color(0xFFF3E8FF),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = if (isLeader) "দায়িত্বপ্রাপ্ত নেতা" else "সাধারণ কর্মী",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isLeader) Color(0xFF166534) else Color(0xFF6B21A8),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }

                    // Delete Button (Red Trash)
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFFEE2E2))
                            .testTag("delete_item_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete entry",
                            tint = Color(0xFFDC2626),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            HorizontalDivider(color = Color(0xFFE5E7EB))

            if (isLeader) {
                val hasSovapoti = item.sovapotiName.isNotBlank() && item.sovapotiName != "উল্লেখ নেই"
                val hasSecretary = item.secretaryName.isNotBlank() && item.secretaryName != "উল্লেখ নেই"
                val hasOther = item.otherName.isNotBlank() && item.otherName != "উল্লেখ নেই"

                // Sovapoti Details
                if (hasSovapoti) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            val phoneSuffix = if (item.sovapotiMobile.isNotBlank() && item.sovapotiMobile != "উল্লেখ নেই") " (${item.sovapotiMobile})" else ""
                            Text(
                                text = "সভাপতি: ${item.sovapotiName}$phoneSuffix",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            if (item.sovapotiMobile.isNotBlank() && item.sovapotiMobile != "উল্লেখ নেই") {
                                IconButton(onClick = { onCall(item.sovapotiMobile) }, modifier = Modifier.size(28.dp)) {
                                    Icon(imageVector = Icons.Default.Call, contentDescription = "Call", tint = Color(0xFF15803D), modifier = Modifier.size(16.dp))
                                }
                            }
                            if (item.sovapotiFb.isNotBlank()) {
                                IconButton(onClick = { onOpenFb(item.sovapotiFb) }, modifier = Modifier.size(28.dp)) {
                                    Icon(imageVector = Icons.Default.OpenInBrowser, contentDescription = "FB Profile", tint = Color(0xFF2563EB), modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }

                // General Secretary Details
                if (hasSecretary) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            val phoneSuffix = if (item.secretaryMobile.isNotBlank() && item.secretaryMobile != "উল্লেখ নেই") " (${item.secretaryMobile})" else ""
                            Text(
                                text = "সাধারণ সম্পাদক: ${item.secretaryName}$phoneSuffix",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            if (item.secretaryMobile.isNotBlank() && item.secretaryMobile != "উল্লেখ নেই") {
                                IconButton(onClick = { onCall(item.secretaryMobile) }, modifier = Modifier.size(28.dp)) {
                                    Icon(imageVector = Icons.Default.Call, contentDescription = "Call", tint = Color(0xFF15803D), modifier = Modifier.size(16.dp))
                                }
                            }
                            if (item.secretaryFb.isNotBlank()) {
                                IconButton(onClick = { onOpenFb(item.secretaryFb) }, modifier = Modifier.size(28.dp)) {
                                    Icon(imageVector = Icons.Default.OpenInBrowser, contentDescription = "FB Profile", tint = Color(0xFF2563EB), modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }

                // Other Designation Details
                if (hasOther) {
                    val desig = if (item.otherDesignation.isNotBlank() && item.otherDesignation != "উল্লেখ নেই") item.otherDesignation else "অন্যান্য পদ"
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            val phoneSuffix = if (item.otherMobile.isNotBlank() && item.otherMobile != "উল্লেখ নেই") " (${item.otherMobile})" else ""
                            Text(
                                text = "$desig: ${item.otherName}$phoneSuffix",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary
                            )
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            if (item.otherMobile.isNotBlank() && item.otherMobile != "উল্লেখ নেই") {
                                IconButton(onClick = { onCall(item.otherMobile) }, modifier = Modifier.size(28.dp)) {
                                    Icon(imageVector = Icons.Default.Call, contentDescription = "Call", tint = Color(0xFF15803D), modifier = Modifier.size(16.dp))
                                }
                            }
                            if (item.otherFb.isNotBlank()) {
                                IconButton(onClick = { onOpenFb(item.otherFb) }, modifier = Modifier.size(28.dp)) {
                                    Icon(imageVector = Icons.Default.OpenInBrowser, contentDescription = "FB Profile", tint = Color(0xFF2563EB), modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            } else {
                // Worker Details
                Text(
                    text = "ঠিকানা: ${item.union}, ${item.ward}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "মোবাইল: ${item.workerMobile}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        if (item.workerMobile.isNotBlank() && item.workerMobile != "উল্লেখ নেই") {
                            IconButton(onClick = { onCall(item.workerMobile) }, modifier = Modifier.size(28.dp)) {
                                Icon(imageVector = Icons.Default.Call, contentDescription = "Call", tint = Color(0xFF15803D), modifier = Modifier.size(16.dp))
                            }
                        }
                        if (item.workerFb.isNotBlank()) {
                            IconButton(onClick = { onOpenFb(item.workerFb) }, modifier = Modifier.size(28.dp)) {
                                Icon(imageVector = Icons.Default.OpenInBrowser, contentDescription = "FB Profile", tint = Color(0xFF2563EB), modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }

            // Date footer
            Text(
                text = "তারিখ: ${item.createdAt}",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = TextSecondary
            )
        }
    }
}

private fun dialPhone(context: Context, number: String) {
    try {
        val intent = Intent(Intent.ACTION_DIAL).apply {
            data = Uri.parse("tel:$number")
        }
        context.startActivity(intent)
    } catch (_: Exception) {}
}

private fun openFacebook(context: Context, url: String) {
    try {
        var cleanUrl = url.trim()
        if (!cleanUrl.startsWith("http://") && !cleanUrl.startsWith("https://")) {
            cleanUrl = "https://$cleanUrl"
        }
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(cleanUrl))
        context.startActivity(intent)
    } catch (_: Exception) {}
}

private fun shareCsv(context: Context, csvText: String) {
    try {
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_SUBJECT, "Charghat_BSL_Data.csv")
            putExtra(Intent.EXTRA_TEXT, csvText)
        }
        context.startActivity(Intent.createChooser(sendIntent, "CSV ফাইল শেয়ার করুন"))
    } catch (_: Exception) {}
}

private fun shareCsvFile(context: Context, csvText: String) {
    try {
        val cacheFile = File(context.cacheDir, "Charghat_BSL_Members.csv")
        cacheFile.writeBytes(csvText.toByteArray(Charsets.UTF_8))
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", cacheFile)
        val sendIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "চারঘাট ছাত্রলীগ তথ্য তালিকা (CSV)")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(sendIntent, "CSV ফাইল শেয়ার করুন"))
    } catch (_: Exception) {
        shareCsv(context, csvText)
    }
}

