package com.example.ui.components

import android.app.Activity
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VideogameAsset
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ads.AdMobManager
import com.example.ads.AdNetworkMode
import com.example.ads.AdsManager
import com.example.ads.UnityAdsManager
import com.example.ads.findActivity
import com.example.ui.theme.GameAmber
import com.example.ui.theme.GameAmberBright
import com.example.ui.theme.GameDarkBackground
import com.example.ui.theme.GameEmerald
import com.example.ui.theme.GameOrange
import com.example.ui.theme.GameRose
import com.example.ui.theme.GameSurfaceDark
import com.example.ui.theme.GameSurfaceElevated
import com.example.ui.theme.GameViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun AdSettingsDialog(
    onRequestTestAd: () -> Unit = {},
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val activity = context.findActivity()

    var selectedMode by remember { mutableStateOf(AdsManager.networkMode) }
    var isTestMode by remember { mutableStateOf(AdsManager.isTestMode) }

    var admobAppId by remember { mutableStateOf(AdsManager.admobAppId) }
    var admobRewardedId by remember { mutableStateOf(AdsManager.admobRewardedUnitId) }
    var admobBannerId by remember { mutableStateOf(AdsManager.admobBannerUnitId) }

    var unityGameId by remember { mutableStateOf(AdsManager.unityGameId) }
    var unityPlacement by remember { mutableStateOf(AdsManager.unityRewardedPlacement) }

    var showInstructions by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf("") }

    val scrollState = rememberScrollState()

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .heightIn(max = 680.dp),
            shape = RoundedCornerShape(24.dp),
            color = GameDarkBackground,
            border = BorderStroke(1.5.dp, GameAmber.copy(alpha = 0.6f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
                    .verticalScroll(scrollState)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = GameAmber.copy(alpha = 0.2f),
                            border = BorderStroke(1.dp, GameAmber)
                        ) {
                            Icon(
                                imageVector = Icons.Default.MonetizationOn,
                                contentDescription = null,
                                tint = GameAmberBright,
                                modifier = Modifier
                                    .padding(8.dp)
                                    .size(24.dp)
                            )
                        }
                        Column {
                            Text(
                                text = "AdMob + Unity Monetization",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                color = TextPrimary
                            )
                            Text(
                                text = "Active: Dual Real Ads (AdMob + Unity)",
                                fontSize = 12.sp,
                                color = GameEmerald,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(36.dp)
                            .background(GameSurfaceDark, CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Account & Live Status Badge
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = Color(0xFF0F172A),
                    border = BorderStroke(1.dp, Color(0xFF1E293B))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Publisher Account:",
                                fontSize = 11.sp,
                                color = TextMuted,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = AdsManager.PUBLISHER_EMAIL,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = GameAmberBright
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .background(if (AdsManager.isAdMobReady()) GameEmerald else GameOrange, CircleShape)
                                )
                                Text(
                                    text = if (AdsManager.isAdMobReady()) "AdMob Ready" else "AdMob Active",
                                    fontSize = 11.sp,
                                    color = if (AdsManager.isAdMobReady()) GameEmerald else GameOrange,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .background(if (selectedMode == AdNetworkMode.ADMOB_ONLY) TextMuted else (if (AdsManager.isUnityReady()) GameEmerald else GameViolet), CircleShape)
                                )
                                Text(
                                    text = if (selectedMode == AdNetworkMode.ADMOB_ONLY) "Unity: Paused" else (if (AdsManager.isUnityReady()) "Unity Ready" else "Unity Active"),
                                    fontSize = 11.sp,
                                    color = if (selectedMode == AdNetworkMode.ADMOB_ONLY) TextMuted else (if (AdsManager.isUnityReady()) GameEmerald else GameViolet),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Mode Toggle: Live vs Test Mode
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = if (isTestMode) Color(0xFF1E293B) else Color(0xFF064E3B),
                    border = BorderStroke(1.dp, if (isTestMode) GameAmber.copy(alpha = 0.4f) else GameEmerald)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = if (isTestMode) Icons.Default.Shield else Icons.Default.MonetizationOn,
                                    contentDescription = null,
                                    tint = if (isTestMode) GameAmberBright else GameEmerald,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = if (isTestMode) "TEST ADS MODE" else "LIVE PRODUCTION ADS",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                            }
                            Text(
                                text = if (isTestMode)
                                    "Google AdMob official test units active (no policy violations during testing)"
                                else
                                    "Real revenue generation active via your real AdMob Publisher account",
                                fontSize = 11.sp,
                                color = if (isTestMode) TextSecondary else Color(0xFFA7F3D0)
                            )
                        }

                        Switch(
                            checked = !isTestMode,
                            onCheckedChange = { isLive -> isTestMode = !isLive },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = GameEmerald,
                                uncheckedThumbColor = TextMuted,
                                uncheckedTrackColor = GameDarkBackground
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Ad Network Selection (AdMob Only, Auto Mediation, Unity Only)
                Text(
                    text = "Ad Serving Strategy:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    NetworkOptionChip(
                        title = "Auto Dual",
                        subtitle = "🟢 AdMob + Unity",
                        selected = selectedMode == AdNetworkMode.AUTO,
                        color = GameEmerald,
                        modifier = Modifier.weight(1f),
                        onClick = { selectedMode = AdNetworkMode.AUTO }
                    )
                    NetworkOptionChip(
                        title = "Unity Only",
                        subtitle = "🎮 Direct APK",
                        selected = selectedMode == AdNetworkMode.UNITY_ONLY,
                        color = GameViolet,
                        modifier = Modifier.weight(1f),
                        onClick = { selectedMode = AdNetworkMode.UNITY_ONLY }
                    )
                    NetworkOptionChip(
                        title = "AdMob Only",
                        subtitle = "📢 Google Ads",
                        selected = selectedMode == AdNetworkMode.ADMOB_ONLY,
                        color = GameAmber,
                        modifier = Modifier.weight(1f),
                        onClick = { selectedMode = AdNetworkMode.ADMOB_ONLY }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // AdMob Configuration Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = GameSurfaceElevated),
                    border = BorderStroke(1.dp, Color(0xFF2E3A52)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(text = "🟢", fontSize = 14.sp)
                            Text(
                                text = "Google AdMob IDs (Live Configured)",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        CustomAdTextField(
                            label = "AdMob App ID",
                            value = admobAppId,
                            onValueChange = { admobAppId = it }
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        CustomAdTextField(
                            label = "Rewarded Video Ad Unit ID",
                            value = admobRewardedId,
                            onValueChange = { admobRewardedId = it }
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        CustomAdTextField(
                            label = "Banner Ad Unit ID",
                            value = admobBannerId,
                            onValueChange = { admobBannerId = it }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Unity Ads Configuration Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = GameSurfaceElevated),
                    border = BorderStroke(1.dp, Color(0xFF2E3A52)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(text = "🎮", fontSize = 14.sp)
                            Text(
                                text = "Unity Ads IDs (Live Configured)",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        CustomAdTextField(
                            label = "Unity Game ID (Android)",
                            value = unityGameId,
                            onValueChange = { unityGameId = it }
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        CustomAdTextField(
                            label = "Rewarded Placement ID",
                            value = unityPlacement,
                            onValueChange = { unityPlacement = it }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Quick Test Ad Buttons
                Text(
                    text = "Instant Ad Test (Watch & Earn Coins):",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            if (activity != null && UnityAdsManager.isAdReady()) {
                                UnityAdsManager.showRewardedAd(
                                    activity = activity,
                                    onUserEarnedReward = { amt, _ ->
                                        Toast.makeText(context, "Unity Ads Reward: +$amt Coins!", Toast.LENGTH_SHORT).show()
                                    },
                                    onAdFailed = {
                                        onDismiss()
                                        onRequestTestAd()
                                    }
                                )
                            } else {
                                UnityAdsManager.preloadRewardedAd(unityPlacement)
                                onDismiss()
                                onRequestTestAd()
                            }
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = GameViolet),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Unity Ad", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Black)
                    }

                    Button(
                        onClick = {
                            if (activity != null && AdMobManager.isAdLoaded()) {
                                AdMobManager.showRewardedAd(
                                    activity = activity,
                                    onUserEarnedReward = { amt, _ ->
                                        Toast.makeText(context, "Google AdMob Reward: +$amt Coins!", Toast.LENGTH_SHORT).show()
                                    },
                                    onFallbackToSimulatedAd = {
                                        onDismiss()
                                        onRequestTestAd()
                                    }
                                )
                            } else {
                                if (activity != null) AdMobManager.preloadRewardedAd(activity)
                                onDismiss()
                                onRequestTestAd()
                            }
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = GameEmerald),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("AdMob Ad", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Black)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Diagnostic Status Card
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF1E293B),
                    border = BorderStroke(1.dp, Color(0xFF334155))
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "Live Dual Network Diagnostics:",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = GameAmberBright
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "• Unity Ads (${unityGameId} / ${unityPlacement}): ${UnityAdsManager.lastStatus}",
                            fontSize = 11.sp,
                            color = Color.White,
                            lineHeight = 15.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "• Google AdMob: ${AdMobManager.lastStatus}",
                            fontSize = 11.sp,
                            color = Color.White,
                            lineHeight = 15.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Save & Reset Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            admobAppId = AdsManager.DEFAULT_ADMOB_APP_ID
                            admobRewardedId = AdsManager.DEFAULT_ADMOB_REWARDED_ID
                            admobBannerId = AdsManager.DEFAULT_ADMOB_BANNER_ID
                            unityGameId = AdsManager.DEFAULT_UNITY_GAME_ID
                            unityPlacement = AdsManager.DEFAULT_UNITY_REWARDED_ID
                            selectedMode = AdNetworkMode.AUTO
                            isTestMode = false
                            Toast.makeText(context, "Restored Your Real Production IDs!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(0.4f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary),
                        border = BorderStroke(1.dp, Color(0xFF334155)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Reset", fontSize = 12.sp)
                    }

                    Button(
                        onClick = {
                            AdsManager.saveSettings(
                                context = context,
                                mode = selectedMode,
                                testMode = isTestMode,
                                admobApp = admobAppId,
                                admobRewarded = admobRewardedId,
                                admobBanner = admobBannerId,
                                unityGame = unityGameId,
                                unityPlacement = unityPlacement
                            )
                            Toast.makeText(context, "Real Ad Settings Saved & Reloaded!", Toast.LENGTH_SHORT).show()
                            onDismiss()
                        },
                        modifier = Modifier.weight(0.6f),
                        colors = ButtonDefaults.buttonColors(containerColor = GameAmber),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Save, contentDescription = null, tint = GameDarkBackground, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save & Apply IDs", color = GameDarkBackground, fontWeight = FontWeight.Black, fontSize = 13.sp)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Bank Payout Guide Accordion
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showInstructions = !showInstructions },
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF0F172A),
                    border = BorderStroke(1.dp, Color(0xFF1E293B))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AccountBalance,
                                    contentDescription = null,
                                    tint = GameAmberBright,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "Bank Payouts & Setup Guide",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            }
                            Text(
                                text = if (showInstructions) "Hide ▲" else "Show ▼",
                                fontSize = 11.sp,
                                color = GameAmberBright
                            )
                        }

                        AnimatedVisibility(visible = showInstructions) {
                            Column(modifier = Modifier.padding(top = 10.dp)) {
                                Text(
                                    text = "1. Google AdMob:\n" +
                                           "• Visit admob.google.com with hazimqadir7@gmail.com\n" +
                                           "• Create your App and create a Rewarded Ad Unit.\n" +
                                           "• Copy your App ID and Rewarded Ad Unit ID into the fields above.\n" +
                                           "• In AdMob Console -> Payments -> Add Payment Method -> Wire Transfer to your Bank Account.\n\n" +
                                           "2. Unity Ads:\n" +
                                           "• Visit cloud.unity.com -> Monetization -> Projects.\n" +
                                           "• Find your 7-digit Android Game ID and paste above.\n" +
                                           "• In Payout Profile -> Enter your Bank details for monthly payouts.\n\n" +
                                           "3. Switch to 'LIVE PRODUCTION ADS' toggle above to earn real dollars!",
                                    fontSize = 11.sp,
                                    lineHeight = 16.sp,
                                    color = TextSecondary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NetworkOptionChip(
    title: String,
    subtitle: String,
    selected: Boolean,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        color = if (selected) color.copy(alpha = 0.2f) else GameSurfaceDark,
        border = BorderStroke(1.dp, if (selected) color else Color(0xFF2E3A52))
    ) {
        Column(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = if (selected) FontWeight.Black else FontWeight.SemiBold,
                color = if (selected) color else TextPrimary,
                maxLines = 1
            )
            Text(
                text = subtitle,
                fontSize = 9.sp,
                color = if (selected) color.copy(alpha = 0.9f) else TextMuted
            )
        }
    }
}

@Composable
private fun CustomAdTextField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit
) {
    Column {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = TextMuted
        )
        Spacer(modifier = Modifier.height(4.dp))
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            textStyle = androidx.compose.ui.text.TextStyle(
                fontSize = 12.sp,
                color = Color.White,
                fontWeight = FontWeight.Medium
            ),
            shape = RoundedCornerShape(10.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GameAmber,
                unfocusedBorderColor = Color(0xFF334155),
                focusedContainerColor = GameSurfaceDark,
                unfocusedContainerColor = GameSurfaceDark
            )
        )
    }
}
