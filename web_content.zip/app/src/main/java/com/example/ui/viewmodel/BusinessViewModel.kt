package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.BusinessSettings
import com.example.data.model.ExpenseEntity
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.data.repository.BusinessRepository
import com.example.util.BackupManager
import com.example.util.DateFilter
import com.example.util.DateRange
import com.example.util.DateUtils
import com.example.util.FinancialMath
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class DashboardSummary(
    val withdrawalVolume: Double = 0.0,
    val billPaymentVolume: Double = 0.0,
    val totalVolume: Double = 0.0,
    val totalPlatformFees: Double = 0.0,
    val withdrawalPlatformFees: Double = 0.0,
    val billPlatformFees: Double = 0.0,
    val totalCustomerCharges: Double = 0.0,
    val totalBillServiceCharges: Double = 0.0,
    val totalCommissionReceived: Double = 0.0,
    val withdrawalCommission: Double = 0.0,
    val billCommission: Double = 0.0,
    val totalTransactionCharges: Double = 0.0,
    val totalCustomerPayouts: Double = 0.0,
    val operatingExpenses: Double = 0.0,
    val paidExpenses: Double = 0.0,
    val unpaidExpenses: Double = 0.0,
    val grossProfit: Double = 0.0,
    val withdrawalGrossProfit: Double = 0.0,
    val billGrossProfit: Double = 0.0,
    val netProfit: Double = 0.0,
    val withdrawalCount: Int = 0,
    val billPaymentCount: Int = 0,
    val expenseCount: Int = 0
)

class BusinessViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: BusinessRepository

    init {
        val db = AppDatabase.getDatabase(application)
        repository = BusinessRepository(
            transactionDao = db.transactionDao(),
            expenseDao = db.expenseDao(),
            settingsDao = db.settingsDao()
        )
    }

    val settings: StateFlow<BusinessSettings> = repository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), BusinessSettings())

    private val _dateFilter = MutableStateFlow(DateFilter.ALL_TIME)
    val dateFilter: StateFlow<DateFilter> = _dateFilter.asStateFlow()

    private val _customDateRange = MutableStateFlow(DateRange(0L, Long.MAX_VALUE))
    val customDateRange: StateFlow<DateRange> = _customDateRange.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _statusFilter = MutableStateFlow("ALL")
    val statusFilter: StateFlow<String> = _statusFilter.asStateFlow()

    private val _typeFilter = MutableStateFlow("ALL")
    val typeFilter: StateFlow<String> = _typeFilter.asStateFlow()

    val allTransactions: StateFlow<List<TransactionEntity>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allExpenses: StateFlow<List<ExpenseEntity>> = repository.allExpenses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    data class TxFilterParams(
        val dateFilter: DateFilter,
        val customRange: DateRange,
        val query: String,
        val type: String,
        val status: String
    )

    private val _filterParams = combine(
        _dateFilter,
        _customDateRange,
        _searchQuery,
        _typeFilter,
        _statusFilter
    ) { filter, range, query, type, status ->
        TxFilterParams(filter, range, query, type, status)
    }

    // Filtered transactions based on DateFilter, search query, type, status
    val filteredTransactions: StateFlow<List<TransactionEntity>> = combine(
        allTransactions,
        _filterParams
    ) { txs, params ->
        val range = DateUtils.getDateRangeForFilter(params.dateFilter, params.customRange.startMillis, params.customRange.endMillis)
        txs.filter { tx ->
            val matchesDate = tx.timestamp in range.startMillis..range.endMillis
            val matchesType = params.type == "ALL" || tx.type.equals(params.type, ignoreCase = true)
            val matchesStatus = params.status == "ALL" || tx.status.equals(params.status, ignoreCase = true)
            val matchesQuery = params.query.isBlank() ||
                    tx.txId.contains(params.query, ignoreCase = true) ||
                    tx.notes.contains(params.query, ignoreCase = true) ||
                    tx.amount.toString().contains(params.query)
            matchesDate && matchesType && matchesStatus && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered expenses based on DateFilter
    val filteredExpenses: StateFlow<List<ExpenseEntity>> = combine(
        allExpenses,
        _dateFilter,
        _customDateRange
    ) { exps, filter, customRange ->
        val range = DateUtils.getDateRangeForFilter(filter, customRange.startMillis, customRange.endMillis)
        exps.filter { it.date in range.startMillis..range.endMillis }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Combined Dashboard metrics
    val dashboardSummary: StateFlow<DashboardSummary> = combine(
        filteredTransactions,
        filteredExpenses,
        settings
    ) { txs, exps, currentSettings ->
        var withdrawalVol = 0.0
        var billVol = 0.0
        var wPlatformFees = 0.0
        var bPlatformFees = 0.0
        var totalCustCharges = 0.0
        var totalBillServCharges = 0.0
        var wCommission = 0.0
        var bCommission = 0.0
        var totalTxCharges = 0.0
        var totalCustPayouts = 0.0
        var wGrossProfit = 0.0
        var bGrossProfit = 0.0
        var totalNetProfit = 0.0
        var wCount = 0
        var bCount = 0

        txs.forEach { tx ->
            if (tx.type == TransactionType.WITHDRAWAL.name) {
                wCount++
                withdrawalVol += tx.amount
                wPlatformFees += tx.platformFeeAmount
                wCommission += tx.commissionAmount
                totalTxCharges += tx.transactionCharge
                totalCustPayouts += tx.customerPayoutOrCharge
                wGrossProfit += tx.grossProfit
                totalNetProfit += tx.netProfit
            } else {
                bCount++
                billVol += tx.amount
                bPlatformFees += tx.platformFeeAmount
                bCommission += tx.commissionAmount
                totalBillServCharges += tx.serviceChargeAmount
                totalCustCharges += tx.customerPayoutOrCharge
                bGrossProfit += tx.grossProfit
                totalNetProfit += tx.netProfit
            }
        }

        var totalExpenses = 0.0
        var paidExp = 0.0
        var unpaidExp = 0.0
        exps.forEach { exp ->
            totalExpenses += exp.amount
            if (exp.isPaid) paidExp += exp.amount else unpaidExp += exp.amount
        }

        // Net profit after operating expenses
        val consolidatedNetProfit = totalNetProfit - totalExpenses
        val consolidatedGrossProfit = wGrossProfit + bGrossProfit

        DashboardSummary(
            withdrawalVolume = FinancialMath.roundToTwoDecimals(withdrawalVol),
            billPaymentVolume = FinancialMath.roundToTwoDecimals(billVol),
            totalVolume = FinancialMath.roundToTwoDecimals(withdrawalVol + billVol),
            totalPlatformFees = FinancialMath.roundToTwoDecimals(wPlatformFees + bPlatformFees),
            withdrawalPlatformFees = FinancialMath.roundToTwoDecimals(wPlatformFees),
            billPlatformFees = FinancialMath.roundToTwoDecimals(bPlatformFees),
            totalCustomerCharges = FinancialMath.roundToTwoDecimals(totalCustCharges),
            totalBillServiceCharges = FinancialMath.roundToTwoDecimals(totalBillServCharges),
            totalCommissionReceived = FinancialMath.roundToTwoDecimals(wCommission + bCommission),
            withdrawalCommission = FinancialMath.roundToTwoDecimals(wCommission),
            billCommission = FinancialMath.roundToTwoDecimals(bCommission),
            totalTransactionCharges = FinancialMath.roundToTwoDecimals(totalTxCharges),
            totalCustomerPayouts = FinancialMath.roundToTwoDecimals(totalCustPayouts),
            operatingExpenses = FinancialMath.roundToTwoDecimals(totalExpenses),
            paidExpenses = FinancialMath.roundToTwoDecimals(paidExp),
            unpaidExpenses = FinancialMath.roundToTwoDecimals(unpaidExp),
            grossProfit = FinancialMath.roundToTwoDecimals(consolidatedGrossProfit),
            withdrawalGrossProfit = FinancialMath.roundToTwoDecimals(wGrossProfit),
            billGrossProfit = FinancialMath.roundToTwoDecimals(bGrossProfit),
            netProfit = FinancialMath.roundToTwoDecimals(consolidatedNetProfit),
            withdrawalCount = wCount,
            billPaymentCount = bCount,
            expenseCount = exps.size
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardSummary())

    fun setDateFilter(filter: DateFilter) {
        _dateFilter.value = filter
    }

    fun setCustomDateRange(start: Long, end: Long) {
        _customDateRange.value = DateRange(start, end)
        _dateFilter.value = DateFilter.CUSTOM
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setTypeFilter(type: String) {
        _typeFilter.value = type
    }

    fun setStatusFilter(status: String) {
        _statusFilter.value = status
    }

    fun addWithdrawalTransaction(
        amount: Double,
        platformFeePercent: Double,
        commissionPercent: Double,
        transactionCharge: Double,
        otherCosts: Double,
        txId: String,
        status: String,
        notes: String
    ) {
        viewModelScope.launch {
            val s = repository.getSettingsSync()
            val calc = FinancialMath.calculateWithdrawal(
                amount = amount,
                platformFeePercent = platformFeePercent,
                commissionPercent = commissionPercent,
                transactionCharge = transactionCharge,
                otherCosts = otherCosts,
                retainChargeAsIncome = s.defaultWithdrawalRetainChargeAsIncome
            )
            val tx = TransactionEntity(
                txId = if (txId.isNotBlank()) txId else "WTH-${System.currentTimeMillis()}",
                type = TransactionType.WITHDRAWAL.name,
                timestamp = System.currentTimeMillis(),
                amount = calc.withdrawalAmount,
                platformFeePercent = calc.platformFeePercent,
                platformFeeAmount = calc.platformFeeAmount,
                isManualPlatformFee = false,
                commissionPercent = calc.commissionPercent,
                commissionAmount = calc.commissionAmount,
                transactionCharge = calc.transactionCharge,
                otherCosts = calc.otherCosts,
                customerPayoutOrCharge = calc.customerPayout,
                grossProfit = calc.grossProfit,
                netProfit = calc.netProfit,
                status = status,
                notes = notes,
                isTransactionChargeRetained = s.defaultWithdrawalRetainChargeAsIncome
            )
            repository.insertTransaction(tx)
        }
    }

    fun addBillPaymentTransaction(
        amount: Double,
        platformFeePercent: Double,
        isManualFee: Boolean,
        manualPlatformFee: Double,
        serviceChargePercent: Double,
        commissionPercent: Double,
        otherCosts: Double,
        txId: String,
        status: String,
        notes: String
    ) {
        viewModelScope.launch {
            val calc = FinancialMath.calculateBillPayment(
                billAmount = amount,
                platformFeePercent = platformFeePercent,
                isManualFee = isManualFee,
                manualPlatformFee = manualPlatformFee,
                serviceChargePercent = serviceChargePercent,
                commissionPercent = commissionPercent,
                otherCosts = otherCosts
            )
            val tx = TransactionEntity(
                txId = if (txId.isNotBlank()) txId else "BP-${System.currentTimeMillis()}",
                type = TransactionType.BILL_PAYMENT.name,
                timestamp = System.currentTimeMillis(),
                amount = calc.billAmount,
                platformFeePercent = calc.platformFeePercent,
                platformFeeAmount = calc.platformFeeAmount,
                isManualPlatformFee = isManualFee,
                commissionPercent = calc.commissionPercent,
                commissionAmount = calc.commissionAmount,
                serviceChargePercent = calc.serviceChargePercent,
                serviceChargeAmount = calc.serviceChargeAmount,
                otherCosts = calc.otherCosts,
                customerPayoutOrCharge = calc.totalCustomerCharge,
                grossProfit = calc.grossProfit,
                netProfit = calc.netProfit,
                status = status,
                notes = notes
            )
            repository.insertTransaction(tx)
        }
    }

    fun updateTransaction(tx: TransactionEntity) {
        viewModelScope.launch {
            repository.updateTransaction(tx)
        }
    }

    fun duplicateTransaction(tx: TransactionEntity) {
        viewModelScope.launch {
            val newTx = tx.copy(
                id = 0,
                txId = "${tx.txId}-COPY",
                timestamp = System.currentTimeMillis()
            )
            repository.insertTransaction(newTx)
        }
    }

    fun deleteTransaction(id: Long) {
        viewModelScope.launch {
            repository.deleteTransactionById(id)
        }
    }

    fun deleteTransactionsByType(type: String) {
        viewModelScope.launch {
            repository.deleteTransactionsByType(type)
        }
    }

    fun addExpense(
        name: String,
        category: String,
        amount: Double,
        date: Long,
        paymentMethod: String,
        isPaid: Boolean,
        notes: String,
        recurrence: String,
        startDate: Long,
        endDate: Long?,
        linkedTxId: String?
    ) {
        viewModelScope.launch {
            val exp = ExpenseEntity(
                name = name,
                category = category,
                amount = amount,
                date = date,
                paymentMethod = paymentMethod,
                isPaid = isPaid,
                notes = notes,
                recurrence = recurrence,
                startDate = startDate,
                endDate = endDate,
                isRecurringActive = true,
                linkedTransactionId = linkedTxId
            )
            repository.insertExpense(exp)
        }
    }

    fun updateExpense(expense: ExpenseEntity) {
        viewModelScope.launch {
            repository.updateExpense(expense)
        }
    }

    fun toggleExpensePaidStatus(expense: ExpenseEntity) {
        viewModelScope.launch {
            repository.updateExpense(expense.copy(isPaid = !expense.isPaid))
        }
    }

    fun toggleRecurringStatus(expense: ExpenseEntity) {
        viewModelScope.launch {
            repository.updateExpense(expense.copy(isRecurringActive = !expense.isRecurringActive))
        }
    }

    fun deleteExpense(id: Long) {
        viewModelScope.launch {
            repository.deleteExpenseById(id)
        }
    }

    fun updateSettings(newSettings: BusinessSettings) {
        viewModelScope.launch {
            repository.updateSettings(newSettings)
        }
    }

    fun clearAllData() {
        viewModelScope.launch {
            repository.clearAllData()
        }
    }

    fun restoreBackup(jsonContent: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val parseResult = BackupManager.parseBackupJson(jsonContent)
            if (parseResult.isSuccess) {
                val data = parseResult.getOrThrow()
                repository.restoreData(data.transactions, data.expenses, data.settings)
                onResult(true, "Successfully restored ${data.transactions.size} transactions and ${data.expenses.size} expenses.")
            } else {
                onResult(false, parseResult.exceptionOrNull()?.localizedMessage ?: "Invalid backup file.")
            }
        }
    }
}
