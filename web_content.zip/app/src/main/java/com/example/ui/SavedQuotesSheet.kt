package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SufiEntry
import com.example.data.SufiLanguage
import com.example.ui.theme.GoldGleam
import com.example.ui.theme.GoldLuster
import com.example.ui.theme.GoldLusterBright
import com.example.ui.theme.SufiMaroon
import com.example.ui.theme.SufiMutedText
import com.example.ui.theme.TerracottaBackground
import com.example.ui.theme.TerracottaDark

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SavedQuotesSheet(
    savedEntries: List<SufiEntry>,
    currentLanguage: SufiLanguage,
    onDismiss: () -> Unit,
    onSelectEntry: (SufiEntry) -> Unit,
    onUnsave: (String) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = TerracottaDark,
        modifier = Modifier.testTag("saved_quotes_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (currentLanguage == SufiLanguage.MALAYALAM) "സൂക്ഷിച്ച വരികൾ" else "Saved Reflections",
                    style = MaterialTheme.typography.titleLarge,
                    fontFamily = FontFamily.Serif,
                    color = GoldLusterBright,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = "${savedEntries.size} items",
                    style = MaterialTheme.typography.labelSmall,
                    color = SufiMutedText
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (savedEntries.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Filled.Favorite,
                            contentDescription = null,
                            tint = SufiMutedText.copy(alpha = 0.4f),
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (currentLanguage == SufiLanguage.MALAYALAM)
                                "നിങ്ങൾ ഇതുവരെ വരികൾ ഒന്നും സൂക്ഷിച്ചിട്ടില്ല"
                            else
                                "No saved reflections yet",
                            style = MaterialTheme.typography.bodyMedium,
                            fontFamily = FontFamily.Serif,
                            color = SufiMutedText,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(380.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(savedEntries, key = { it.id }) { entry ->
                        SavedEntryItem(
                            entry = entry,
                            currentLanguage = currentLanguage,
                            onClick = {
                                onSelectEntry(entry)
                                onDismiss()
                            },
                            onUnsave = { onUnsave(entry.id) }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SavedEntryItem(
    entry: SufiEntry,
    currentLanguage: SufiLanguage,
    onClick: () -> Unit,
    onUnsave: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .border(1.dp, GoldLuster.copy(alpha = 0.45f), RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = TerracottaBackground)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = when (currentLanguage) {
                        SufiLanguage.MALAYALAM -> entry.ml
                        SufiLanguage.ENGLISH -> "“${entry.en}”"
                        SufiLanguage.DUAL -> entry.ml
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    fontFamily = FontFamily.Serif,
                    color = GoldGleam,
                    fontSize = 14.sp,
                    maxLines = 2
                )
                if (entry.isQuote && !entry.author.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "— ${entry.author}",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Serif,
                        fontStyle = FontStyle.Italic,
                        color = GoldLusterBright,
                        fontSize = 11.sp
                    )
                }
            }

            IconButton(
                onClick = onUnsave,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Delete,
                    contentDescription = "Remove bookmark",
                    tint = SufiMutedText,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
