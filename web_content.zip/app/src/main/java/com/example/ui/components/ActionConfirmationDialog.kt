package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.ActionConfirmation
import com.example.data.model.ActionType
import com.example.ui.theme.XtraCardBorder
import com.example.ui.theme.XtraCardDark
import com.example.ui.theme.XtraCyanGlow
import com.example.ui.theme.XtraCyanPrimary
import com.example.ui.theme.XtraSurfaceDark
import com.example.ui.theme.XtraTextHigh
import com.example.ui.theme.XtraTextMed
import com.example.ui.theme.XtraWarningGold

@Composable
fun ActionConfirmationDialog(
    action: ActionConfirmation,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = XtraSurfaceDark,
            border = BorderStroke(1.5.dp, XtraCyanPrimary.copy(alpha = 0.6f)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("action_confirmation_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Header with Shield Icon
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(XtraCardDark)
                    ) {
                        val icon = when (action.actionType) {
                            ActionType.CALL_PHONE -> Icons.Default.Call
                            ActionType.SEND_SMS, ActionType.WHATSAPP -> Icons.Default.Message
                            else -> Icons.Default.Security
                        }
                        Icon(
                            imageVector = icon,
                            contentDescription = "Security Alert",
                            tint = XtraCyanPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = "SECURITY PROTOCOL",
                            color = XtraWarningGold,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = action.title,
                            color = XtraTextHigh,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Detail card
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = XtraCardDark,
                    border = BorderStroke(1.dp, XtraCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = action.description,
                            color = XtraTextHigh,
                            fontSize = 14.sp,
                            lineHeight = 20.sp
                        )

                        if (action.targetName.isNotBlank()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row {
                                Text(
                                    text = "Target: ",
                                    color = XtraTextMed,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "${action.targetName} (${action.targetValue})",
                                    color = XtraCyanGlow,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Privacy guarantee notice
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = XtraTextMed,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "XTRA requires explicit authorization before placing calls or sending messages.",
                        color = XtraTextMed,
                        fontSize = 11.sp
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Action buttons
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        border = BorderStroke(1.dp, XtraCardBorder),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("action_cancel_button")
                    ) {
                        Text(text = "Abort", color = XtraTextMed, fontWeight = FontWeight.SemiBold)
                    }

                    Button(
                        onClick = onConfirm,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = XtraCyanPrimary,
                            contentColor = Color(0xFF00363D)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("action_authorize_button")
                    ) {
                        Text(text = "Authorize", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
