package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Auction
import com.example.data.model.AuctionStatus
import com.example.data.model.Bid
import com.example.data.model.UiState
import com.example.data.model.UserProfile
import com.example.data.model.Wallet
import com.example.ui.components.BidderNumberChip
import com.example.ui.components.CommissionBreakdownCard
import com.example.ui.components.EmptyStateCard
import com.example.ui.components.FeaturedBadge
import com.example.ui.components.LiveCountdownPill
import com.example.ui.components.LotImageDisplay
import com.example.ui.theme.MonoFontFamily
import com.example.ui.viewmodel.AuctionDetailViewModel
import com.example.util.formatCountdown
import com.example.util.formatNaira
import com.example.util.formatTimestamp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuctionDetailScreen(
    detailViewModel: AuctionDetailViewModel,
    profile: UserProfile?,
    wallet: Wallet?,
    nowMillis: Long,
    currentUserId: String,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    val auctionState by detailViewModel.auctionState.collectAsStateWithLifecycle()
    val bidsState by detailViewModel.bidsState.collectAsStateWithLifecycle()
    val actionMessage by detailViewModel.actionMessage.collectAsStateWithLifecycle()
    val isSubmitting by detailViewModel.isSubmitting.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(actionMessage) {
        if (actionMessage != null) {
            snackbarHostState.showSnackbar(actionMessage!!)
            detailViewModel.clearMessage()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Live Auction Lot") },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("detail_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back to live floor")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            when (val state = auctionState) {
                is UiState.Loading -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
                is UiState.Error -> {
                    Box(modifier = Modifier.padding(20.dp)) {
                        EmptyStateCard(title = "Unable to load lot", subtitle = state.message)
                    }
                }
                is UiState.Success -> {
                    val auction = state.data
                    if (auction == null) {
                        Box(modifier = Modifier.padding(20.dp)) {
                            EmptyStateCard(
                                title = "Lot Not Found",
                                subtitle = "This auction lot may have been removed by an administrator."
                            )
                        }
                    } else {
                        val bids = (bidsState as? UiState.Success)?.data ?: emptyList()
                        AuctionDetailContent(
                            auction = auction,
                            bids = bids,
                            profile = profile,
                            wallet = wallet,
                            nowMillis = nowMillis,
                            currentUserId = currentUserId,
                            isSubmitting = isSubmitting,
                            onPlaceBid = { amount ->
                                if (profile != null) detailViewModel.placeBid(profile, amount)
                            },
                            onSettleAuction = { detailViewModel.settleAuction() },
                            onFeatureAuction = { detailViewModel.upgradeToFeatured(auction.title) },
                            onCancelBeforeBids = { detailViewModel.cancelBeforeBids() }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AuctionDetailContent(
    auction: Auction,
    bids: List<Bid>,
    profile: UserProfile?,
    wallet: Wallet?,
    nowMillis: Long,
    currentUserId: String,
    isSubmitting: Boolean,
    onPlaceBid: (Long) -> Unit,
    onSettleAuction: () -> Unit,
    onFeatureAuction: () -> Unit,
    onCancelBeforeBids: () -> Unit
) {
    val effectiveStatus = auction.effectiveStatus(nowMillis)
    val countdown = formatCountdown(auction.endsAt, nowMillis, auction.status)
    val minRequired = auction.minimumNextBid()
    var bidInput by remember(minRequired) { mutableStateOf(minRequired.toString()) }

    val isSeller = auction.sellerId == currentUserId
    val isHighestBidder = auction.highestBidderId == currentUserId && auction.bidCount > 0L

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .widthIn(max = 780.dp),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Gallery Images
        item {
            val images = auction.imageItems.ifEmpty { listOf("preset:chronograph") }
            if (images.size == 1) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(250.dp)
                        .clip(RoundedCornerShape(22.dp))
                ) {
                    LotImageDisplay(
                        imageSpec = images.first(),
                        contentDescription = auction.title,
                        modifier = Modifier.fillMaxSize()
                    )
                    if (auction.featured) {
                        FeaturedBadge(
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(14.dp)
                        )
                    }
                    LiveCountdownPill(
                        endsAt = auction.endsAt,
                        nowMillis = nowMillis,
                        status = auction.status,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(14.dp)
                    )
                }
            } else {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(images) { img ->
                        Box(
                            modifier = Modifier
                                .width(290.dp)
                                .height(230.dp)
                                .clip(RoundedCornerShape(20.dp))
                        ) {
                            LotImageDisplay(
                                imageSpec = img,
                                contentDescription = auction.title,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                }
            }
        }

        // Title, Category & Live Timer Banner
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        shape = RoundedCornerShape(50.dp)
                    ) {
                        Text(
                            text = auction.category.uppercase(),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                    Text(
                        text = "Seller: ${auction.sellerBidderNumber}",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Text(
                    text = auction.title,
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Text(
                    text = auction.description,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Live Bid Status & Highest Bidder Display
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (auction.bidCount > 0L) "HIGHEST LIVE BID" else "OPENING BID",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = formatNaira(if (auction.bidCount > 0L) auction.currentBid else auction.startingBid),
                                style = MaterialTheme.typography.displaySmall.copy(fontFamily = MonoFontFamily),
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Timer,
                                    contentDescription = "Countdown",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = countdown.label,
                                    style = MaterialTheme.typography.titleMedium.copy(fontFamily = MonoFontFamily),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = "${auction.bidCount} total bids • +${formatNaira(auction.minIncrement)} min step",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Transparent Highest Bidder",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (auction.highestBidderNumber.isNotBlank()) {
                            BidderNumberChip(
                                bidderNumber = auction.highestBidderNumber,
                                isLeadingMe = isHighestBidder
                            )
                        } else {
                            Text(
                                text = "Awaiting first bid",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // Live Bidding Action Panel OR Settlement / Seller Controls
        item {
            when {
                effectiveStatus == AuctionStatus.SETTLED -> {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Settled",
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Column {
                                Text(
                                    text = "Escrow Settled & Paid",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                Text(
                                    text = "Won by ${auction.highestBidderNumber} at ${formatNaira(auction.currentBid)}. Net seller payout: ${formatNaira(auction.sellerPayout)}.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                        }
                    }
                }

                effectiveStatus == AuctionStatus.ENDED && isHighestBidder -> {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "You Won This Auction!",
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                text = "Pay ${formatNaira(auction.currentBid)} from your True A wallet (${formatNaira(wallet?.availableBalance ?: 0L)} available) to settle escrow and credit the seller net of 3% commission.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Button(
                                onClick = onSettleAuction,
                                enabled = !isSubmitting,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                                    .testTag("settle_auction_button"),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                if (isSubmitting) {
                                    CircularProgressIndicator(Modifier.size(20.dp), color = MaterialTheme.colorScheme.onPrimary)
                                } else {
                                    Text("Pay & Settle ${formatNaira(auction.currentBid)}")
                                }
                            }
                        }
                    }
                }

                isSeller -> {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text("Seller Controls", style = MaterialTheme.typography.titleMedium)
                            if (!auction.featured && effectiveStatus == AuctionStatus.ACTIVE) {
                                Button(
                                    onClick = onFeatureAuction,
                                    enabled = !isSubmitting,
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                                ) {
                                    Icon(Icons.Default.Star, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text("Feature This Auction — ₦2,000")
                                }
                            }
                            if (auction.bidCount == 0L && effectiveStatus == AuctionStatus.ACTIVE) {
                                OutlinedButton(
                                    onClick = onCancelBeforeBids,
                                    enabled = !isSubmitting,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Cancel Listing (No Bids Yet)")
                                }
                            } else {
                                Text(
                                    text = "Live bidding is underway. You cannot bid on your own lot.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                effectiveStatus == AuctionStatus.ACTIVE -> {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.border(
                            1.dp,
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.25f),
                            RoundedCornerShape(20.dp)
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Place Live Bid", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    text = "As ${profile?.bidderNumber ?: "TA-…"}",
                                    style = MaterialTheme.typography.labelMedium.copy(fontFamily = MonoFontFamily),
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }

                            // Quick Increment Chips
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                val quickAmounts = listOf(
                                    minRequired,
                                    minRequired + auction.minIncrement,
                                    minRequired + (auction.minIncrement * 3L)
                                )
                                quickAmounts.forEach { amt ->
                                    OutlinedButton(
                                        onClick = { bidInput = amt.toString() },
                                        modifier = Modifier.weight(1f),
                                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text(
                                            text = formatNaira(amt),
                                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonoFontFamily),
                                            maxLines = 1
                                        )
                                    }
                                }
                            }

                            OutlinedTextField(
                                value = bidInput,
                                onValueChange = { bidInput = it.filter { ch -> ch.isDigit() } },
                                label = { Text("Your Bid Amount (₦) • Min ${formatNaira(minRequired)}") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("bid_amount_input")
                            )

                            val parsedBid = bidInput.toLongOrNull() ?: 0L
                            Button(
                                onClick = { onPlaceBid(parsedBid) },
                                enabled = !isSubmitting && parsedBid >= minRequired && profile != null,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(54.dp)
                                    .testTag("place_bid_button"),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                if (isSubmitting) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(20.dp),
                                        color = MaterialTheme.colorScheme.onPrimary,
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Icon(Icons.Default.Gavel, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        text = "Bid ${formatNaira(parsedBid)} Now",
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Transparent 3% Commission Preview
        item {
            CommissionBreakdownCard(
                grossAmount = if (auction.bidCount > 0L) auction.currentBid else auction.startingBid,
                title = "3% Commission & Escrow Transparency"
            )
        }

        // Live Bid Book
        item {
            Text(
                text = "Live Bid Ledger (${bids.size})",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        if (bids.isEmpty()) {
            item {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "No bids recorded yet. Be the first verified bidder on this lot!",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        } else {
            items(bids, key = { it.id }) { bid ->
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            BidderNumberChip(
                                bidderNumber = bid.bidderNumber,
                                isLeadingMe = bid.bidderId == currentUserId
                            )
                            Text(
                                text = formatTimestamp(bid.createdAt),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = formatNaira(bid.amount),
                            style = MaterialTheme.typography.titleMedium.copy(fontFamily = MonoFontFamily),
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }
    }
}
