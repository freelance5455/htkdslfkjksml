package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.xp.WindowsXpTheme

@Composable
fun SourceCodeDialog(
    url: String,
    sourceHtml: String,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
                .clip(RoundedCornerShape(6.dp))
                .background(Color.White)
                .border(2.dp, Color(0xFF0058EE), RoundedCornerShape(6.dp))
        ) {
            // Notepad Title Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(30.dp)
                    .background(WindowsXpTheme.TitleBarGradient)
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "view-source - Notepad",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )

                Box(
                    modifier = Modifier
                        .size(18.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(WindowsXpTheme.CloseRed)
                        .clickable { onDismiss() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = Color.White,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }

            // Notepad Menu Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(WindowsXpTheme.Background)
                    .border(1.dp, WindowsXpTheme.BorderDark)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                listOf("File", "Edit", "Format", "View", "Help").forEach { item ->
                    Text(
                        text = item,
                        fontSize = 11.sp,
                        color = Color.Black,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            // Text Content (Monospace, Selectable)
            SelectionContainer(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(Color.White)
                    .verticalScroll(rememberScrollState())
                    .padding(8.dp)
            ) {
                Text(
                    text = sourceHtml.ifEmpty { "<!-- Loading page source from: $url -->\n<html>\n  <head><title>Historical Web Standards</title></head>\n  <body>\n    <h1>Authentic Retro Browser Active</h1>\n    <p>Rendering with Adobe Flash Player v10 ActiveX Control.</p>\n  </body>\n</html>" },
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = Color.Black,
                    lineHeight = 15.sp
                )
            }

            // Footer
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(WindowsXpTheme.Background)
                    .border(1.dp, WindowsXpTheme.BorderDark)
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.End
            ) {
                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFECE9D8)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF7F9DB9)),
                    shape = RoundedCornerShape(3.dp)
                ) {
                    Text("Close Notepad", color = Color.Black, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun AboutBrowserDialog(onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(6.dp))
                .background(WindowsXpTheme.Background)
                .border(2.dp, Color(0xFF0058EE), RoundedCornerShape(6.dp))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(30.dp)
                    .background(WindowsXpTheme.TitleBarGradient)
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "About Retro Explorer",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )

                Box(
                    modifier = Modifier
                        .size(18.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(WindowsXpTheme.CloseRed)
                        .clickable { onDismiss() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = Color.White,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFF0058EE)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "e",
                            color = Color(0xFFFFD54F),
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Microsoft Internet Explorer 6.0",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF003399)
                        )
                        Text(
                            text = "Version 6.0.2900.5512 (xpsp.080413-2111)",
                            fontSize = 11.sp,
                            color = Color.DarkGray
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Featuring Built-in:",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )
                Text(
                    text = "• Dual Engine: Windows XP Luna IE6 & Google Chrome Modes\n" +
                            "• Adobe® Flash® Player v10.3 runtime support\n" +
                            "• Interactive Helicopter & ActionScript 3.0 Games\n" +
                            "• Wayback Machine & The Old Net Historical Archives\n" +
                            "• User-Agent Compatibility switcher (IE6, IE7, Netscape, Chrome)\n" +
                            "• Retro CRT Monitor Scanline Filter\n" +
                            "• Era Sites: Space Jam 1996, Yahoo! 2001, Google 1998, MSN Start",
                    fontSize = 11.sp,
                    color = Color(0xFF333333),
                    lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0058EE)),
                        shape = RoundedCornerShape(3.dp)
                    ) {
                        Text("OK", color = Color.White, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
