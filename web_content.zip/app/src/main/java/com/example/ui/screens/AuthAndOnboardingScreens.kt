package com.example.ui.screens

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.Color as AndroidColor
import android.os.Build
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.credentials.CredentialManager
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.R
import com.example.data.repository.AuthManager
import com.example.ui.components.ArkAuroraBackground
import com.example.ui.components.ArkAvatarBadge
import com.example.ui.components.GlowingPillButton
import com.example.ui.components.LiquidGlassCard
import com.example.ui.theme.ArkThemeTokens
import java.util.concurrent.atomic.AtomicBoolean
import org.json.JSONObject

private const val LOGIN_ASSET_URL = "file:///android_asset/ark_login.html"
private const val TAG_AUTH_WEBVIEW = "ArkAuthWebView"

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

private class ArkWebViewHolder {
    var webView: WebView? = null
    private val destroyed = java.util.Collections.newSetFromMap(java.util.IdentityHashMap<WebView, Boolean>())

    fun destroyOnce(wv: WebView) {
        if (!destroyed.add(wv)) return
        if (webView === wv) {
            webView = null
        }
        runCatching {
            wv.removeJavascriptInterface("Android")
            wv.stopLoading()
            (wv.parent as? ViewGroup)?.removeView(wv)
            wv.destroy()
        }
    }
}

private class ArkLoginJsBridge(
    private val onGoogleSignInRequested: () -> Unit
) {
    @JavascriptInterface
    fun signInWithGoogle() {
        onGoogleSignInRequested()
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun AuthScreen(
    onAuthSuccess: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val lifecycleOwner = LocalLifecycleOwner.current
    val view = LocalView.current
    val density = LocalDensity.current
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val currentOnAuthSuccess by rememberUpdatedState(onAuthSuccess)
    val isSigningIn = remember { AtomicBoolean(false) }

    val statusTopDp = with(density) { WindowInsets.statusBars.getTop(this).toDp().value }.toInt()
    val navBottomDp = with(density) { WindowInsets.navigationBars.getBottom(this).toDp().value }.toInt()

    val activityWindow = remember(context) { context.findActivity()?.window }
    DisposableEffect(activityWindow, view) {
        val controller = activityWindow?.let { WindowCompat.getInsetsController(it, view) }
        val prevLightStatus = controller?.isAppearanceLightStatusBars
        val prevLightNav = controller?.isAppearanceLightNavigationBars
        controller?.isAppearanceLightStatusBars = false
        controller?.isAppearanceLightNavigationBars = false
        onDispose {
            if (prevLightStatus != null) controller.isAppearanceLightStatusBars = prevLightStatus
            if (prevLightNav != null) controller.isAppearanceLightNavigationBars = prevLightNav
        }
    }

    val webViewHolder = remember { ArkWebViewHolder() }
    var rendererGeneration by remember { mutableIntStateOf(0) }
    var useFallbackNativeAuth by remember { mutableStateOf(false) }
    var fallbackLoading by remember { mutableStateOf(false) }
    var fallbackError by remember { mutableStateOf<String?>(null) }

    DisposableEffect(lifecycleOwner, rendererGeneration, useFallbackNativeAuth) {
        val observer = LifecycleEventObserver { _, event ->
            val wv = webViewHolder.webView ?: return@LifecycleEventObserver
            when (event) {
                Lifecycle.Event.ON_PAUSE -> {
                    wv.evaluateJavascript(
                        "window.ARKLogin && window.ARKLogin.pause && window.ARKLogin.pause();",
                        null
                    )
                    wv.onPause()
                }
                Lifecycle.Event.ON_RESUME -> {
                    wv.onResume()
                    wv.evaluateJavascript(
                        "window.ARKLogin && window.ARKLogin.resume && window.ARKLogin.resume();",
                        null
                    )
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF070B18))
    ) {
        if (useFallbackNativeAuth) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .windowInsetsPadding(WindowInsets.safeDrawing)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_ark_logo),
                    contentDescription = "ARK Logo",
                    modifier = Modifier
                        .size(104.dp)
                        .clip(RoundedCornerShape(26.dp)),
                    contentScale = ContentScale.Crop
                )
                Spacer(Modifier.height(20.dp))
                Text(
                    text = "Your World. Your People.",
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "Connect, share, play and grow together in one place.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.68f),
                    textAlign = TextAlign.Center
                )
                if (fallbackError != null) {
                    Spacer(Modifier.height(14.dp))
                    Text(
                        text = fallbackError ?: "",
                        style = MaterialTheme.typography.bodySmall,
                        color = ArkThemeTokens.colors.coral,
                        textAlign = TextAlign.Center
                    )
                }
                Spacer(Modifier.height(28.dp))
                GlowingPillButton(
                    text = "Sign in with Google",
                    icon = Icons.Default.RocketLaunch,
                    isLoading = fallbackLoading,
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 400.dp)
                        .testTag("google_sign_in_button"),
                    onClick = {
                        if (!isSigningIn.compareAndSet(false, true)) return@GlowingPillButton
                        fallbackError = null
                        fallbackLoading = true
                        val hostActivity = context.findActivity() ?: context
                        AuthManager.onGoogleSignInClicked(
                            context = hostActivity,
                            credentialManager = credentialManager,
                            scope = scope,
                            onAuthSuccess = {
                                isSigningIn.set(false)
                                fallbackLoading = false
                                currentOnAuthSuccess()
                            },
                            onAuthCancelled = {
                                isSigningIn.set(false)
                                fallbackLoading = false
                            },
                            onAuthError = { msg ->
                                isSigningIn.set(false)
                                fallbackLoading = false
                                fallbackError = msg
                            }
                        )
                    }
                )
            }
        } else {
            key(rendererGeneration) {
                AndroidView(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("ark_login_webview"),
                    factory = { ctx ->
                        WebView(ctx).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            setBackgroundColor(AndroidColor.parseColor("#070B18"))
                            overScrollMode = View.OVER_SCROLL_NEVER
                            isVerticalScrollBarEnabled = false
                            isHorizontalScrollBarEnabled = false
                            setLayerType(View.LAYER_TYPE_SOFTWARE, null)
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                setRendererPriorityPolicy(
                                    WebView.RENDERER_PRIORITY_IMPORTANT,
                                    false
                                )
                            }

                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = false
                                allowFileAccess = false
                                allowContentAccess = false
                                setSupportZoom(false)
                                builtInZoomControls = false
                                displayZoomControls = false
                                useWideViewPort = true
                                loadWithOverviewMode = true
                                mediaPlaybackRequiresUserGesture = false
                                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                            }

                            val triggerSignIn = {
                                post {
                                    if (!isSigningIn.compareAndSet(false, true)) return@post
                                    val hostActivity = ctx.findActivity() ?: ctx
                                    AuthManager.onGoogleSignInClicked(
                                        context = hostActivity,
                                        credentialManager = credentialManager,
                                        scope = scope,
                                        onAuthSuccess = {
                                            isSigningIn.set(false)
                                            post {
                                                evaluateJavascript(
                                                    "window.__arkResolveAuth && window.__arkResolveAuth();",
                                                    null
                                                )
                                            }
                                            currentOnAuthSuccess()
                                        },
                                        onAuthCancelled = {
                                            isSigningIn.set(false)
                                            post {
                                                evaluateJavascript(
                                                    "window.__arkResolveAuth && window.__arkResolveAuth();",
                                                    null
                                                )
                                            }
                                        },
                                        onAuthError = { msg ->
                                            isSigningIn.set(false)
                                            val quotedMsg = JSONObject.quote(msg)
                                            post {
                                                evaluateJavascript(
                                                    """
                                                    (function(){
                                                      var t = document.getElementById('toast');
                                                      if (t) {
                                                        t.textContent = $quotedMsg;
                                                        t.classList.add('show');
                                                        clearTimeout(window.__arkToastTimer);
                                                        window.__arkToastTimer = setTimeout(function(){
                                                          t.classList.remove('show');
                                                        }, 4000);
                                                      }
                                                      if (window.__arkResolveAuth) {
                                                        window.__arkResolveAuth();
                                                        window.__arkResolveAuth = null;
                                                        window.__arkRejectAuth = null;
                                                      }
                                                    })();
                                                    """.trimIndent(),
                                                    null
                                                )
                                            }
                                        }
                                    )
                                }
                            }

                            addJavascriptInterface(
                                ArkLoginJsBridge(onGoogleSignInRequested = { triggerSignIn() }),
                                "Android"
                            )

                            webViewClient = object : WebViewClient() {
                                override fun shouldOverrideUrlLoading(
                                    view: WebView?,
                                    request: WebResourceRequest?
                                ): Boolean {
                                    return request?.url?.toString() != LOGIN_ASSET_URL
                                }

                                override fun onPageFinished(view: WebView?, url: String?) {
                                    super.onPageFinished(view, url)
                                    val bridgeAndInsetsJs = """
                                        (function() {
                                          var sc = document.getElementById('screen');
                                          if (sc) {
                                            var cs = getComputedStyle(sc);
                                            var pt = parseFloat(cs.paddingTop) || 0;
                                            var pb = parseFloat(cs.paddingBottom) || 0;
                                            if ($statusTopDp > pt) sc.style.paddingTop = ($statusTopDp + 10) + 'px';
                                            if ($navBottomDp > pb) sc.style.paddingBottom = ($navBottomDp + 14) + 'px';
                                          }
                                          window.ARKAuth = {
                                            signInWithGoogle: function() {
                                              return new Promise(function(resolve, reject) {
                                                window.__arkResolveAuth = resolve;
                                                window.__arkRejectAuth = reject;
                                                if (window.Android && typeof window.Android.signInWithGoogle === 'function') {
                                                  window.Android.signInWithGoogle();
                                                } else {
                                                  reject(new Error('Google Sign-In bridge unavailable'));
                                                }
                                              });
                                            }
                                          };
                                        })();
                                    """.trimIndent()
                                    view?.evaluateJavascript(bridgeAndInsetsJs, null)
                                }

                                override fun onRenderProcessGone(
                                    view: WebView?,
                                    detail: RenderProcessGoneDetail?
                                ): Boolean {
                                    Log.w(
                                        TAG_AUTH_WEBVIEW,
                                        "WebView renderer gone: didCrash=${detail?.didCrash()}, gen=$rendererGeneration"
                                    )
                                    view?.let { webViewHolder.destroyOnce(it) }
                                    if (rendererGeneration == 0) {
                                        rendererGeneration = 1
                                    } else {
                                        useFallbackNativeAuth = true
                                    }
                                    return true
                                }
                            }

                            loadUrl(LOGIN_ASSET_URL)
                            webViewHolder.webView = this
                        }
                    },
                    onRelease = { wv ->
                        webViewHolder.destroyOnce(wv)
                    }
                )
            }
        }
    }
}

@Composable
fun OnboardingProfileScreen(
    onSubmit: (
        username: String,
        displayTag: String,
        bio: String,
        avatarPreset: String,
        ageBracket: String,
        parentalConsentApproved: Boolean,
        parentEmailHint: String
    ) -> Unit
) {
    val colors = ArkThemeTokens.colors
    var username by remember { mutableStateOf("") }
    var displayTag by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf("") }
    var avatarPreset by remember { mutableStateOf("prism_cyan") }
    var ageBracket by remember { mutableStateOf("teen_13_17") }
    var parentalConsent by remember { mutableStateOf(false) }
    var parentEmailHint by remember { mutableStateOf("") }
    var validationError by remember { mutableStateOf<String?>(null) }

    val presets = listOf(
        "prism_cyan" to "Cyan Prism",
        "cyber_violet" to "Violet Nova",
        "solar_gold" to "Solar Gold",
        "emerald_nova" to "Emerald Shield",
        "coral_pulse" to "Coral Rocket"
    )

    ArkAuroraBackground {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(modifier = Modifier.widthIn(max = 560.dp)) {
                Text("Create Your ARK Identity", style = MaterialTheme.typography.headlineMedium, color = colors.textPrimary)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Choose a unique handle (no real name required). Accounts start Private-by-Default for your safety.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = colors.textSecondary
                )

                Spacer(Modifier.height(16.dp))

                LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Avatar Preset", style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        presets.forEach { (key, _) ->
                            val selected = avatarPreset == key
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .border(
                                        width = if (selected) 2.dp else 1.dp,
                                        color = if (selected) colors.cyan else colors.glassBorder,
                                        shape = RoundedCornerShape(16.dp)
                                    )
                                    .clickable { avatarPreset = key }
                                    .padding(6.dp)
                            ) {
                                ArkAvatarBadge(avatarPreset = key, username = username.ifBlank { "ark" }, size = 44.dp)
                            }
                        }
                    }

                    Spacer(Modifier.height(16.dp))
                    OutlinedTextField(
                        value = username,
                        onValueChange = { username = it.lowercase().filter { c -> c.isLetterOrDigit() || c == '_' }.take(24) },
                        label = { Text("Username (e.g. aarav_spark)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("onboarding_username_input")
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = displayTag,
                        onValueChange = { displayTag = it.take(30) },
                        label = { Text("Gamer Tag / Nickname") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("onboarding_display_tag_input")
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = bio,
                        onValueChange = { bio = it.take(160) },
                        label = { Text("Optional Bio (Hobbies, Squad Vibe)") },
                        maxLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Spacer(Modifier.height(14.dp))

                LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text("Age & Child Safety Verification", style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "ARK adapts friend-discovery & safety defaults to your age group (compliant with Indian DPDP & child safety standards).",
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textSecondary
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = ageBracket == "under_13",
                            onClick = { ageBracket = "under_13" },
                            label = { Text("Under 13") }
                        )
                        FilterChip(
                            selected = ageBracket == "teen_13_17",
                            onClick = { ageBracket = "teen_13_17" },
                            label = { Text("13–17") }
                        )
                        FilterChip(
                            selected = ageBracket == "adult_18_plus",
                            onClick = { ageBracket = "adult_18_plus" },
                            label = { Text("18+") }
                        )
                    }

                    if (ageBracket != "adult_18_plus") {
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = parentEmailHint,
                            onValueChange = { parentEmailHint = it.take(120) },
                            label = { Text("Parent/Guardian Email (for consent notice)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Checkbox(
                                checked = parentalConsent,
                                onCheckedChange = { parentalConsent = it }
                            )
                            Text(
                                text = "Parent/guardian consent confirmed for safe social & group play.",
                                style = MaterialTheme.typography.bodySmall,
                                color = colors.textPrimary,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                if (validationError != null) {
                    Spacer(Modifier.height(10.dp))
                    Text(validationError!!, color = colors.coral, style = MaterialTheme.typography.bodySmall)
                }

                Spacer(Modifier.height(18.dp))
                GlowingPillButton(
                    text = "Launch ARK",
                    icon = Icons.Default.RocketLaunch,
                    modifier = Modifier.fillMaxWidth().testTag("onboarding_submit_button"),
                    onClick = {
                        val cleanUser = username.trim()
                        if (cleanUser.length < 3) {
                            validationError = "Username must be at least 3 characters."
                            return@GlowingPillButton
                        }
                        if (ageBracket != "adult_18_plus" && !parentalConsent) {
                            validationError = "Please confirm parent/guardian consent for under-18 safety."
                            return@GlowingPillButton
                        }
                        validationError = null
                        onSubmit(
                            cleanUser,
                            displayTag.ifBlank { cleanUser },
                            bio,
                            avatarPreset,
                            ageBracket,
                            ageBracket == "adult_18_plus" || parentalConsent,
                            parentEmailHint
                        )
                    }
                )
            }
        }
    }
}
